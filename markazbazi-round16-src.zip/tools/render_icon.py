"""3D gaming icon renderer: numpy SDF ray-marcher -> RGBA PNG.

usage: python3 -I render_icon.py client|server out.png [size]
"""
import sys, math
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

KIND = sys.argv[1]
OUT = sys.argv[2]
RES = int(sys.argv[3]) if len(sys.argv) > 3 else 1024

# ---------------------------------------------------------------- helpers
def v3(x, y, z): return np.stack([x, y, z], -1)
def length(p): return np.sqrt(np.sum(p * p, -1))
def norm(p): return p / (length(p)[..., None] + 1e-9)
def smin(a, b, k):
    h = np.clip(0.5 + 0.5 * (b - a) / k, 0, 1)
    return b * (1 - h) + a * h - k * h * (1 - h)

def sd_round_box(p, b, r):
    q = np.abs(p) - (np.array(b) - r)
    return length(np.maximum(q, 0)) + np.minimum(np.max(q, -1), 0) - r

def sd_box2(px, pz, bx, bz):
    qx = np.abs(px) - bx; qz = np.abs(pz) - bz
    return np.sqrt(np.maximum(qx, 0) ** 2 + np.maximum(qz, 0) ** 2) + np.minimum(np.maximum(qx, qz), 0)

def sd_seg2(px, pz, ax, az, bx, bz):
    pax, paz = px - ax, pz - az; bax, baz = bx - ax, bz - az
    h = np.clip((pax * bax + paz * baz) / (bax * bax + baz * baz), 0, 1)
    return np.sqrt((pax - bax * h) ** 2 + (paz - baz * h) ** 2)

def extrude_round(d2, y, h, r):
    wx = d2 + r; wy = np.abs(y) - h
    return np.sqrt(np.maximum(wx, 0) ** 2 + np.maximum(wy, 0) ** 2) + np.minimum(np.maximum(wx, wy), 0) - r

def sd_cyl(p, c, r, h):  # vertical cylinder at c, radius r, half-height h
    q = p - np.array(c)
    dx = np.sqrt(q[..., 0] ** 2 + q[..., 2] ** 2) - r
    dy = np.abs(q[..., 1]) - h
    return np.minimum(np.maximum(dx, dy), 0) + np.sqrt(np.maximum(dx, 0) ** 2 + np.maximum(dy, 0) ** 2)

def sd_sphere(p, c, r): return length(p - np.array(c)) - r

# ---------------------------------------------------------------- scene
# Material ids
M_BODY, M_DARK, M_A, M_B, M_X, M_Y, M_GLOW, M_RACK, M_LED_G, M_LED_B, M_STICKTOP = range(11)

TOP = 0.10  # body half height before rounding (top face y ~ TOP)

def gamepad(p, s=1.0, off=(0, 0, 0)):
    """Returns list of (dist, material)."""
    p = (p - np.array(off)) / s
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    # outline in XZ plane
    core = sd_box2(x, z + 0.04, 0.46, 0.17) - 0.13
    gl = sd_seg2(x, z, -0.42, -0.02, -0.60, 0.40) - 0.20
    gr = sd_seg2(x, z, 0.42, -0.02, 0.60, 0.40) - 0.20
    d2 = smin(smin(core, gl, 0.12), gr, 0.12)
    # notch between grips (front middle)
    notch = np.sqrt(x ** 2 + ((z - 0.42) / 0.8) ** 2) - 0.20
    d2 = -smin(-d2, notch, 0.08)
    dome = 0.025 * (1 - np.clip((x / 0.7) ** 2 + (z / 0.5) ** 2, 0, 1))
    body = extrude_round(d2, y - dome * 0.5, TOP + dome * 0.5 - 0.06, 0.06)
    yt = TOP + 0.01
    res = [(body * s, M_BODY)]
    # D-pad (left)
    q = p - np.array([-0.40, yt, -0.03])
    dp1 = sd_round_box(q, (0.10, 0.03, 0.032), 0.012)
    dp2 = sd_round_box(q, (0.032, 0.03, 0.10), 0.012)
    res.append((np.minimum(dp1, dp2) * s, M_DARK))
    # ABXY (right)
    c = np.array([0.40, yt + 0.005, -0.03]); o = 0.075; r = 0.043
    res.append((sd_sphere(p, c + [0, 0, o], r) * s, M_A))
    res.append((sd_sphere(p, c + [o, 0, 0], r) * s, M_B))
    res.append((sd_sphere(p, c + [-o, 0, 0], r) * s, M_X))
    res.append((sd_sphere(p, c + [0, 0, -o], r) * s, M_Y))
    # thumbsticks
    for sx in (-0.17, 0.17):
        base = sd_cyl(p, (sx, yt, 0.16), 0.085, 0.025) - 0.006
        stem = sd_cyl(p, (sx, yt + 0.04, 0.16), 0.03, 0.04)
        cap = sd_cyl(p, (sx, yt + 0.085, 0.16), 0.068, 0.018) - 0.012
        dish = sd_sphere(p, (sx, yt + 0.19, 0.16), 0.095)
        cap = np.maximum(cap, -dish)
        res.append((np.minimum(base, stem) * s, M_DARK))
        res.append((cap * s, M_STICKTOP))
    # center light bar + small buttons
    res.append((sd_round_box(p - np.array([0, yt, -0.15]), (0.10, 0.012, 0.025), 0.012) * s, M_GLOW))
    for sx in (-0.10, 0.10):
        res.append((sd_round_box(p - np.array([sx, yt, -0.04]), (0.03, 0.012, 0.014), 0.012) * s, M_DARK))
    return res

def rack(p):
    res = []
    for i, yy in enumerate((0.42, 0.14, -0.14)):
        q = p - np.array([0, yy, 0])
        slab = sd_round_box(q, (0.62, 0.115, 0.40), 0.05)
        # front groove
        groove = sd_round_box(q - np.array([-0.05, 0, 0.40]), (0.38, 0.03, 0.02), 0.01)
        slab = np.maximum(slab, -groove)
        res.append((slab, M_RACK))
        res.append((sd_sphere(q, (0.42, 0.0, 0.395), 0.032), M_LED_G))
        res.append((sd_sphere(q, (0.52, 0.0, 0.395), 0.032), M_LED_B if i != 1 else M_LED_G))
    return res

def rot_x(p, a):
    c, s = math.cos(a), math.sin(a)
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    return v3(x, c * y - s * z, s * y + c * z)

def rot_y(p, a):
    c, s = math.cos(a), math.sin(a)
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    return v3(c * x + s * z, y, -s * x + c * z)

def scene(pw):
    if KIND == "client":
        p = rot_x(pw - np.array([0, 0.07, 0]), -0.85)          # tilt pad so we see the top face
        parts = gamepad(p, 1.05, (0, 0, 0.02))
    else:
        pr = rot_y(rot_x(pw - np.array([0.0, 0.26, -0.3]), -0.38), -0.42)
        parts = rack(pr / 0.85)
        parts = [(d * 0.85, m) for d, m in parts]
        pg = rot_x(pw - np.array([0.02, -0.42, 0.75]), -0.85)
        parts += gamepad(pg, 0.82)
    d = parts[0][0]; m = np.full(d.shape, parts[0][1])
    for dd, mm in parts[1:]:
        sel = dd < d
        m = np.where(sel, mm, m); d = np.where(sel, dd, d)
    return d, m

def sdf(p): return scene(p)[0]

# ---------------------------------------------------------------- render
def render(res):
    ys, xs = np.mgrid[0:res, 0:res].astype(np.float64)
    u = (xs + 0.5) / res * 2 - 1
    v = 1 - (ys + 0.5) / res * 2
    ro = np.array([0, 0, 6.0])
    fov = 0.205 if KIND == "client" else 0.235
    rd = norm(v3(u * fov, v * fov, -np.ones_like(u)))
    rd = rd.reshape(-1, 3)
    n = rd.shape[0]
    t = np.full(n, 4.0); hit = np.zeros(n, bool); alive = np.ones(n, bool)
    idx = np.arange(n)
    for _ in range(160):
        a = idx[alive]
        if a.size == 0: break
        p = ro + rd[a] * t[a, None]
        d = sdf(p)
        t[a] += d * 0.9
        h = d < 0.0008
        hit[a[h]] = True
        dead = h | (t[a] > 8.5)
        alive[a[dead]] = False
    col = np.zeros((n, 3)); alpha = hit.astype(np.float64)
    a = idx[hit]
    p = ro + rd[a] * t[a, None]
    d, mat = scene(p)
    e = 0.0012
    nx = sdf(p + [e, 0, 0]) - sdf(p - [e, 0, 0])
    ny = sdf(p + [0, e, 0]) - sdf(p - [0, e, 0])
    nz = sdf(p + [0, 0, e]) - sdf(p - [0, 0, e])
    N = norm(np.stack([nx, ny, nz], -1))
    V = -rd[a]
    # ambient occlusion
    ao = np.ones(a.size)
    for k in range(1, 6):
        hh = 0.02 * k
        ao -= (hh - sdf(p + N * hh)) * (0.5 ** k) * 6
    ao = np.clip(ao, 0.25, 1)

    base = np.zeros((a.size, 3)); spec_k = np.zeros(a.size); rough = np.zeros(a.size); emis = np.zeros((a.size, 3))
    def setm(mid, c, sk, rg, em=(0, 0, 0)):
        s = mat == mid
        base[s] = c; spec_k[s] = sk; rough[s] = rg; emis[s] = em
    if KIND == "client":
        body_col = (0.05, 0.62, 0.95)
    else:
        body_col = (1.0, 0.45, 0.06)
    setm(M_BODY, body_col, 0.9, 60)
    setm(M_DARK, (0.07, 0.07, 0.10), 0.7, 40)
    setm(M_STICKTOP, (0.12, 0.12, 0.16), 0.6, 30)
    setm(M_A, (0.15, 0.85, 0.30), 1.0, 90, (0.03, 0.2, 0.05))
    setm(M_B, (0.95, 0.15, 0.20), 1.0, 90, (0.2, 0.02, 0.03))
    setm(M_X, (0.15, 0.40, 1.00), 1.0, 90, (0.02, 0.06, 0.2))
    setm(M_Y, (1.00, 0.80, 0.10), 1.0, 90, (0.2, 0.15, 0.0))
    setm(M_GLOW, (0.9, 0.95, 1.0), 0.6, 40, (0.6, 1.2, 1.6) if KIND == "client" else (1.6, 1.0, 0.4))
    setm(M_RACK, (0.16, 0.17, 0.22), 0.8, 50)
    setm(M_LED_G, (0.2, 1.0, 0.4), 0.5, 30, (0.4, 2.0, 0.7))
    setm(M_LED_B, (0.2, 0.7, 1.0), 0.5, 30, (0.3, 1.2, 2.2))

    lights = [  # dir, color
        (norm(np.array([-0.6, 0.8, 0.7])), np.array([1.0, 0.97, 0.92]) * 1.25),
        (norm(np.array([0.9, 0.3, -0.4])), (np.array([0.9, 0.3, 1.0]) if KIND == "client" else np.array([0.3, 0.7, 1.0])) * 0.9),
        (norm(np.array([0.2, -0.3, 1.0])), np.array([0.3, 0.35, 0.5]) * 0.4),
    ]
    c = np.zeros((a.size, 3))
    sky = np.array([0.55, 0.6, 0.8]); ground = np.array([0.12, 0.10, 0.16])
    hemi = (N[:, 1:2] * 0.5 + 0.5)
    c += base * (sky * hemi + ground * (1 - hemi)) * 0.35 * ao[:, None]
    for L, lc in lights:
        ndl = np.clip(np.sum(N * L, -1), 0, 1)
        H = norm(L + V)
        ndh = np.clip(np.sum(N * H, -1), 0, 1)
        spec = ndh ** rough * spec_k * (rough + 8) / 25
        c += (base * ndl[:, None] + spec[:, None]) * lc * (0.4 + 0.6 * ao[:, None])
    # fresnel env reflection (studio softbox)
    R = rd[a] - 2 * np.sum(rd[a] * N, -1)[:, None] * N
    fres = 0.04 + 0.96 * (1 - np.clip(np.sum(N * V, -1), 0, 1)) ** 5
    box = np.exp(-((R[:, 1] - 0.75) ** 2) * 14) * np.exp(-((R[:, 0] + 0.2) ** 2) * 3)
    env = (0.08 + 1.6 * box)[:, None] * np.array([1, 1, 1.05])
    c += env * (fres * spec_k)[:, None] * 1.4
    c += emis
    # ACES-ish tonemap
    c = np.clip((c * (2.51 * c + 0.03)) / (c * (2.43 * c + 0.59) + 0.14), 0, 1)
    col[a] = c
    return col.reshape(res, res, 3), alpha.reshape(res, res)

def tile(res):
    yy, xx = np.mgrid[0:res, 0:res].astype(np.float64) / res
    if KIND == "client":
        top, bot = np.array([0.36, 0.12, 0.72]), np.array([0.05, 0.03, 0.20])
        rim = np.array([0.30, 0.90, 1.0])
    else:
        top, bot = np.array([0.16, 0.18, 0.30]), np.array([0.03, 0.03, 0.07])
        rim = np.array([1.0, 0.55, 0.10])
    g = yy[..., None]
    rgb = top * (1 - g) + bot * g
    # radial glow behind the object
    r = np.sqrt((xx - 0.5) ** 2 + (yy - 0.47) ** 2)
    rgb += (rim * 0.45) * np.exp(-(r / 0.30) ** 2)[..., None]
    # squircle mask
    m = 0.06
    nx = np.abs(xx - 0.5) / (0.5 - m); ny = np.abs(yy - 0.5) / (0.5 - m)
    sq = (nx ** 5 + ny ** 5) ** (1 / 5)
    aa = 1.5 / res / (0.5 - m)
    mask = np.clip((1 - sq) / aa, 0, 1)
    # inner rim highlight
    edge = np.exp(-((1 - sq) / 0.025) ** 2) * (sq < 1)
    rgb = rgb * (1 - edge[..., None] * 0.6) + rim * edge[..., None] * 0.9
    # top gloss
    gloss = np.clip(1 - yy / 0.45, 0, 1) ** 2 * 0.10
    rgb += gloss[..., None]
    return np.clip(rgb, 0, 1), mask

SS = 2
big = RES * SS
col, a = render(big)
obj = Image.fromarray((np.dstack([col, a]) * 255).astype(np.uint8), "RGBA").resize((RES, RES), Image.LANCZOS)
trgb, tmask = tile(RES)
tile_img = Image.fromarray((np.dstack([trgb, tmask]) * 255).astype(np.uint8), "RGBA")
# drop shadow from object alpha
sh = obj.split()[3].filter(ImageFilter.GaussianBlur(RES * 0.025))
shadow = Image.new("RGBA", (RES, RES), (0, 0, 0, 0))
shadow.putalpha(sh.point(lambda v: int(v * 0.65)))
shadow = shadow.transform((RES, RES), Image.AFFINE, (1, 0, 0, 0, 1, -int(RES * 0.03)))
out = Image.alpha_composite(tile_img, shadow)
out = Image.alpha_composite(out, obj)
# keep everything inside the tile shape
final_a = np.minimum(np.array(out)[..., 3], (tmask * 255).astype(np.uint8))
arr = np.array(out); arr[..., 3] = final_a
Image.fromarray(arr, "RGBA").save(OUT)
print("ok", OUT)
