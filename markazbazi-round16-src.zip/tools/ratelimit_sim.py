#!/usr/bin/env python3
"""Policy model of GameNet.Server.Core.RateLimiter.CheckLimit (line-by-line port) and of the
three ways a pre-hello message can be keyed. This executes the POLICY, not the C# code:
no C# compiler is reachable from this sandbox."""
import heapq

class RateLimiter:
    def __init__(self, per_minute=30, per_hour=500, block_minutes=15):
        self.entries = {}
        self.per_minute = per_minute
        self.per_hour = per_hour
        self.block_minutes = block_minutes

    def check(self, key, now):
        if not key:
            key = "anonymous"                      # RateLimiter.CheckLimit: empty key -> shared bucket
        e = self.entries.setdefault(key, {"ts": [], "until": None})
        if e["until"] is not None:
            if now < e["until"]:
                return False                       # still blocked; the block is not extended
            e["until"] = None
        e["ts"] = [t for t in e["ts"] if now - t < 3600]
        minute_count = sum(1 for t in e["ts"] if now - t < 60)
        if minute_count >= self.per_minute or len(e["ts"]) >= self.per_hour:
            e["until"] = now + self.block_minutes * 60
            return False
        e["ts"].append(now)
        return True

def make(config):
    return {"config": config,
            "per_ip": RateLimiter(30, 500, 15),                     # existing limiter, unchanged values
            "group": RateLimiter(300, 5000, 1) if config == "B" else None}

def pre_hello_allowed(m, ip, now):
    c = m["config"]
    if c == "current":                             # ClientInfo is null before hello -> key ""
        return m["per_ip"].check("", now)
    if c == "A":                                   # applied: key = socket address
        return m["per_ip"].check(ip, now)
    ok = m["per_ip"].check(ip, now)                # B (not applied): address budget, then group cap
    if ok:
        ok = m["group"].check("anonymous", now)
    return ok

def startup_storm(config, kiosks=40, horizon=3600.0):
    """Kiosks start within 1 s. A refused hello gets no welcome: the kiosk waits 30 s (welcome
    watchdog), then reconnects after a backoff of 1 s doubling, capped at 30 s."""
    m = make(config)
    welcome, attempts = {}, {}
    heap = [(i * 0.02, i) for i in range(kiosks)]
    heapq.heapify(heap)
    while heap:
        t, i = heapq.heappop(heap)
        if t > horizon or i in welcome:
            continue
        if pre_hello_allowed(m, "10.0.0.%d" % (i + 1), t):
            welcome[i] = t
        else:
            n = attempts.get(i, 0) + 1
            attempts[i] = n
            heapq.heappush(heap, (t + 30 + min(2 ** (n - 1), 30), i))
    return welcome

def flood(config, attackers=400, window=60.0):
    """400 distinct addresses send one pre-hello message each within one minute, then two
    legitimate kiosks try: at 61 s and at 1000 s."""
    m = make(config)
    ok = 0
    for k in range(attackers):
        if pre_hello_allowed(m, "198.51.%d.%d" % (k // 250, k % 250 + 1), k * window / attackers):
            ok += 1
    return ok, pre_hello_allowed(m, "10.0.0.1", 61.0), pre_hello_allowed(m, "10.0.0.2", 1000.0)

def flapper(config, hellos=40):
    """One kiosk whose connection keeps failing sends 40 pre-hello messages in one minute,
    then a healthy kiosk tries at 61 s."""
    m = make(config)
    ok = sum(1 for k in range(hellos) if pre_hello_allowed(m, "10.0.0.99", k * 1.5))
    return ok, pre_hello_allowed(m, "10.0.0.1", 61.0)

if __name__ == "__main__":
    print("== Scenario 1: 40 kiosks start together ==")
    print("config  welcomed<=1s  welcomed<=60s  welcomed<=1000s  welcomed<=1h  all welcomed at")
    for c in ("current", "A", "B"):
        w = startup_storm(c)
        allw = max(w.values()) if len(w) == 40 else None
        print("%-7s %-13d %-14d %-16d %-13d %s" % (c,
              sum(1 for t in w.values() if t <= 1),
              sum(1 for t in w.values() if t <= 60),
              sum(1 for t in w.values() if t <= 1000),
              len(w),
              ("%.0f s" % allw) if allw is not None else "not within 1 h"))
    print()
    print("== Scenario 2: 400 addresses flood one minute, then kiosks try ==")
    print("config  flood messages allowed  kiosk at 61 s  kiosk at 1000 s")
    for c in ("current", "A", "B"):
        ok, l61, l1000 = flood(c)
        print("%-7s %-23d %-14s %s" % (c, ok, "allowed" if l61 else "BLOCKED", "allowed" if l1000 else "BLOCKED"))
    print()
    print("== Scenario 3: one failing kiosk sends 40 hellos in a minute ==")
    print("config  its messages allowed  healthy kiosk at 61 s")
    for c in ("current", "A", "B"):
        ok, l61 = flapper(c)
        print("%-7s %-22d %s" % (c, ok, "allowed" if l61 else "BLOCKED"))
