"""Build a Windows .ico: BMP (DIB) frames for <=64 px, PNG frames for 128/256.
usage: python3 -I make_ico.py master.png out.ico
"""
import sys, io, struct
from PIL import Image, ImageFilter

src = Image.open(sys.argv[1]).convert("RGBA")
BMP_SIZES = [16, 20, 24, 32, 40, 48, 64]
PNG_SIZES = [128, 256]

def frame(sz):
    im = src.resize((sz, sz), Image.LANCZOS)
    if sz <= 32:
        im = im.filter(ImageFilter.UnsharpMask(radius=0.6, percent=60, threshold=0))
    return im

def dib(im):
    w, h = im.size
    px = im.tobytes("raw", "BGRA")
    rows = [px[y * w * 4:(y + 1) * w * 4] for y in range(h)][::-1]  # bottom-up
    xor = b"".join(rows)
    mask_row = ((w + 31) // 32) * 4
    alpha = im.split()[3].tobytes()
    andm = bytearray()
    for y in range(h - 1, -1, -1):
        row = bytearray(mask_row)
        for x in range(w):
            if alpha[y * w + x] == 0:
                row[x // 8] |= 0x80 >> (x % 8)
        andm += row
    hdr = struct.pack("<IiiHHIIiiII", 40, w, h * 2, 1, 32, 0, len(xor) + len(andm), 0, 0, 0, 0)
    return hdr + xor + bytes(andm)

entries = []
for sz in BMP_SIZES:
    entries.append((sz, dib(frame(sz))))
for sz in PNG_SIZES:
    b = io.BytesIO(); frame(sz).save(b, "PNG", optimize=True); entries.append((sz, b.getvalue()))

out = bytearray(struct.pack("<HHH", 0, 1, len(entries)))
off = 6 + 16 * len(entries)
blobs = b""
for sz, data in entries:
    out += struct.pack("<BBBBHHII", sz % 256, sz % 256, 0, 0, 1, 32, len(data), off + len(blobs))
    blobs += data
out += blobs
open(sys.argv[2], "wb").write(out)
print(sys.argv[2], len(out), "bytes,", len(entries), "frames")
