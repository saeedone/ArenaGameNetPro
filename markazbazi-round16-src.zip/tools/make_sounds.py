"""Synthesizes the GameNet sound cues as 44.1 kHz 16-bit mono WAV files.
usage: python3 -I make_sounds.py <client_sounds_dir> <server_sounds_dir>
"""
import sys, os, wave
import numpy as np

SR = 44100
def n2f(n):  # note name like C5 -> Hz
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    k, o = n[:-1], int(n[-1])
    return 440.0 * 2 ** ((names[k] + (o - 4) * 12) / 12)

def tone(f, dur, kind="bell", vol=1.0, attack=0.005):
    t = np.arange(int(SR * dur)) / SR
    if kind == "bell":       # FM-ish bell: decaying partials
        s = (np.sin(2*np.pi*f*t) + 0.45*np.sin(2*np.pi*f*2.01*t)*np.exp(-t*6)
             + 0.25*np.sin(2*np.pi*f*3.02*t)*np.exp(-t*9) + 0.1*np.sin(2*np.pi*f*4.2*t)*np.exp(-t*14))
        env = np.exp(-t * 3.2)
    elif kind == "pluck":
        s = np.sin(2*np.pi*f*t) + 0.3*np.sin(2*np.pi*2*f*t) + 0.15*np.sin(2*np.pi*3*f*t)
        env = np.exp(-t * 9)
    elif kind == "square":   # retro chip tone (band-limited-ish)
        s = sum(np.sin(2*np.pi*f*k*t)/k for k in (1, 3, 5, 7))
        env = np.ones_like(t) * np.exp(-t * 2.5)
    elif kind == "pad":
        s = np.sin(2*np.pi*f*t) + 0.5*np.sin(2*np.pi*f*1.005*t) + 0.3*np.sin(2*np.pi*f*0.5*t)
        env = np.minimum(1, t / 0.08) * np.exp(-t * 1.6)
    elif kind == "blip":
        f_t = f * (1 + 0.6*np.exp(-t*40))
        s = np.sin(2*np.pi*np.cumsum(f_t)/SR)
        env = np.exp(-t * 18)
    a = np.minimum(1, t / attack)
    rel = np.minimum(1, (dur - t) / 0.01)
    return s * env * a * rel * vol

def seq(events, total):
    out = np.zeros(int(SR * total))
    for start, sig in events:
        i = int(SR * start); j = min(len(out), i + len(sig))
        out[i:j] += sig[:j - i]
    return out

def reverb(x, mix=0.18):
    y = x.copy()
    for d, g in ((0.031, 0.5), (0.047, 0.4), (0.071, 0.3), (0.113, 0.22)):
        k = int(SR * d)
        z = np.zeros_like(x); z[k:] = x[:-k] * g
        y += z * mix * 3
    return y

def save(path, x, peak_db=-3.0):
    x = reverb(x)
    x = x / (np.max(np.abs(x)) + 1e-9) * 10 ** (peak_db / 20)
    fade = int(SR * 0.02); x[-fade:] *= np.linspace(1, 0, fade)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())
    print("wrote", path, round(len(x) / SR, 2), "s")

def startup():   # power-on: rising arpeggio + shimmer
    notes = ["C5", "E5", "G5", "C6", "E6"]
    ev = [(i * 0.09, tone(n2f(n), 0.9, "bell", 0.8)) for i, n in enumerate(notes)]
    ev.append((0.0, tone(n2f("C3"), 1.3, "pad", 0.5)))
    ev.append((0.45, tone(n2f("G6"), 0.8, "bell", 0.35)))
    return seq(ev, 1.5)

def warn10():
    return seq([(0, tone(n2f("A5"), 0.8, "bell", 0.8))], 0.9)

def warn5():     # ding-dong x2
    ev = []
    for k in range(2):
        b = k * 0.62
        ev += [(b, tone(n2f("E6"), 0.55, "bell")), (b + 0.22, tone(n2f("C6"), 0.6, "bell"))]
    return seq(ev, 1.45)

def warn1():     # urgent triple
    ev = [(i * 0.17, tone(n2f("A5"), 0.14, "square", 0.6)) for i in range(3)]
    ev += [(0.55 + i * 0.17, tone(n2f("A5"), 0.14, "square", 0.6)) for i in range(3)]
    return seq(ev, 1.15)

def timeend():   # game over: descending + low tone
    ev = [(0.0, tone(n2f("G5"), 0.3, "square", 0.55)), (0.22, tone(n2f("E5"), 0.3, "square", 0.55)),
          (0.44, tone(n2f("C5"), 0.3, "square", 0.55)), (0.70, tone(n2f("G4"), 0.9, "square", 0.6)),
          (0.70, tone(n2f("G3"), 1.0, "pad", 0.6))]
    return seq(ev, 1.8)

def client_online():
    return seq([(0, tone(n2f("G5"), 0.4, "pluck")), (0.12, tone(n2f("D6"), 0.6, "bell", 0.8))], 0.85)

def customer_message():  # bubble pop pop
    return seq([(0, tone(n2f("C6"), 0.18, "blip")), (0.13, tone(n2f("G6"), 0.25, "blip")),
                (0.13, tone(n2f("G5"), 0.4, "bell", 0.3))], 0.65)

def time_request():  # coin
    return seq([(0, tone(n2f("B5"), 0.09, "square", 0.6)), (0.08, tone(n2f("E6"), 0.55, "square", 0.6)),
                (0.45, tone(n2f("B5"), 0.09, "square", 0.6)), (0.53, tone(n2f("E6"), 0.55, "square", 0.6))], 1.15)

cdir, sdir = sys.argv[1], sys.argv[2]
os.makedirs(cdir, exist_ok=True); os.makedirs(sdir, exist_ok=True)
save(os.path.join(cdir, "startup.wav"), startup())
save(os.path.join(cdir, "warn10.wav"), warn10())
save(os.path.join(cdir, "warn5.wav"), warn5())
save(os.path.join(cdir, "warn1.wav"), warn1())
save(os.path.join(cdir, "timeend.wav"), timeend())
save(os.path.join(sdir, "client_online.wav"), client_online())
save(os.path.join(sdir, "customer_message.wav"), customer_message())
save(os.path.join(sdir, "time_request.wav"), time_request())
save(os.path.join(sdir, "warn5.wav"), warn5())
save(os.path.join(sdir, "time_end.wav"), timeend())
