using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace GameNet.Shared
{
    public enum MessageType : int
    {
        // Phase 1: Core messages
        ClientHello = 1001, ClientLogin = 1002, ClientLogout = 1003,
        ClientHeartbeat = 1004, ClientRequestStart = 1005, ClientRequestStop = 1006,
        ClientGameLaunched = 1007, ClientGameClosed = 1008, ClientStatusUpdate = 1009,
        ClientTicketRedeem = 1010, ClientReconnect = 1011,
        ClientSessionInfo = 1012,            // client asks server to re-send balance/price after reconnect
        ServerWelcome = 2001, ServerLoginOk = 2002, ServerLoginFail = 2003,
        ServerStartSession = 2004, ServerStopSession = 2005, ServerTimeWarning = 2006,
        ServerTimeExpired = 2007, ServerForceLogout = 2008, ServerGameList = 2009,
        ServerAddCredit = 2010, ServerMessage = 2011, ServerLockClient = 2012,
        ServerUnlockClient = 2013, ServerShutdown = 2014, ServerRestart = 2015,
        ServerHeartbeatAck = 2016, ServerTicketResult = 2017, ServerPriceInfo = 2018,
        ServerSessionInfo = 2019,

        // Phase 3: Chat messages
        ClientChatSend = 3001, ClientChatHistory = 3002,
        ServerChatReceive = 3003, ServerChatHistory = 3004,

        // Phase 3: Announcement messages
        ClientAnnouncementList = 3010,
        ServerAnnouncementList = 3011, ServerAnnouncementNew = 3012,

        // Phase 3: Print/Scan messages
        ClientPrintRequest = 3020,
        ServerPrintResult = 3021,

        // Phase 3: Debt messages
        ClientDebtList = 3030,
        ServerDebtList = 3031, ServerDebtUpdate = 3032,

        // Phase 3: Session Package messages
        ClientPackageList = 3040, ClientPackagePurchase = 3041,
        ServerPackageList = 3042, ServerPackageResult = 3043,

        // Phase 3: Member Tier messages
        ClientTierInfo = 3050,
        ServerTierInfo = 3051, ServerTierUpgrade = 3052,

        // Phase 3: Backup & Report
        ServerBackupComplete = 3060,
        ServerReportData = 3061,

        // Phase 4: Security
        Client2FAVerify = 4001,
        Server2FAResult = 4002,
        ServerSecurityAlert = 4003,

        // Phase 5: UX & UI
        ClientThemeRequest = 5001,
        ServerThemeData = 5002,
        ClientLangChange = 5003,
        ServerNotification = 5004,

        // Phase 6: Intelligence
        ClientSmartPriceRequest = 6001,
        ServerSmartPriceInfo = 6002,
        ClientAutoRechargeConfig = 6003,
        ServerAutoRechargeResult = 6004,
        ClientGameDetection = 6005,
        ServerGameDetectionResult = 6006,
        ServerTrafficPrediction = 6007,

        // Phase 7: Expansion
        ClientMobileLogin = 7001,
        ServerMobileDashboard = 7002,
        ClientPaymentRequest = 7010,
        ServerPaymentUrl = 7011,
        ServerPaymentVerified = 7012,
        ClientBranchInfo = 7020,
        ServerBranchInfo = 7021,

        // Phase 8: Infrastructure
        ServerUpdateAvailable = 8001,
        ClientUpdateStatus = 8002,
        ServerConfigSync = 8003,

        // Phase 9: Remote monitoring
        ServerScreenshotRequest = 8100,
        ClientScreenshotResponse = 8101,

        // Phase 10: Auto-update + file transfer + crash report
        ServerUpdateOffer = 8200,           // server tells client a new version is available
        ClientUpdateAccept = 8201,          // client accepts the update
        ServerUpdateChunk = 8202,           // server streams a file chunk
        ClientUpdateProgress = 8203,        // client reports progress
        ClientUpdateComplete = 8204,        // client finished installing
        ClientCrashReport = 8210,           // client sends crash log
        ServerFileTransferOffer = 8220,     // server offers to send a file
        ClientFileTransferAccept = 8221,    // client accepts
        ServerFileTransferChunk = 8222,     // server streams file chunk
        ClientFileTransferComplete = 8223,  // client finished receiving

        // Phase 11: Quick top-up + sound alerts
        ClientTopupRequest = 8300,          // client asks operator for credit
        ServerTopupResponse = 8301,         // operator approves/denies
        ClientTopupStatusPoll = 8302,       // client polls for status

        // Phase 12: Quick time + sound control + bulk operations
        ServerSetSessionTime = 8400,        // operator sets/adds time to a session
        ServerMuteClient = 8401,            // mute/unmute client sound
        ServerUsbControl = 8402,            // enable/disable USB on client
        ServerInternetControl = 8403,       // enable/disable internet on client
        ServerRemoteDesktop = 8404,         // server requests RDP to client
        // Legacy: the kiosk client ignores this message (its game-close path was removed).
        // Payload: GameClosePayload { bool Force }.
        ServerCloseGame = 8405,
        // NEW FEATURE (live monitoring + remote input, per request): server
        // forwards a mouse/keyboard event to a client for injection. Uses
        // normalized (0.0–1.0) coordinates rather than pixels, since the
        // server's preview window and the client's actual screen resolution
        // are generally different sizes — normalized coordinates let the
        // client scale correctly to its own screen regardless of how large
        // the operator's preview window happens to be.
        ServerRemoteInput = 8406,

        // NEW FEATURE (real video+audio codec, per request): tells the
        // client to launch FFmpeg and stream H.264 video + AAC audio to the
        // server over a dedicated TCP connection (separate from this
        // control connection — video/audio is raw binary, not JSON
        // messages, so it doesn't belong in the same stream). The server
        // launches ffplay (bundled with FFmpeg) listening on that port
        // before sending this, so by the time the client's ffmpeg connects
        // out, something is already there to receive it.
        ServerStartVideoStream = 8407,
        ServerStopVideoStream = 8408,
        // Client reports whether it actually managed to launch ffmpeg
        // (e.g. "not found" if the operator hasn't installed it on that
        // specific kiosk PC yet — see the chat message alongside this
        // feature for why FFmpeg can't be bundled automatically).
        ClientVideoStreamStatus = 8409,

        // Phase 13: Client UX enhancements
        ClientFoodOrder = 8500,             // client orders food
        ServerFoodOrderResponse = 8501,     // server confirms/denies food order
        ClientSessionHistory = 8502,        // client requests own session history
        ServerSessionHistory = 8503,        // server sends history
        ClientGuestLogin = 8504,            // guest (no account) login
        ServerWallpaper = 8505,             // server sets client wallpaper
        ClientPrintFromKiosk = 8506,        // client requests print from kiosk
        ClientPauseSession = 8507,          // client requests pause
        ServerPauseResponse = 8508,         // server approves/denies pause
        ClientLeaderboard = 8509,           // client requests local leaderboard
        ServerLeaderboard = 8510,           // server sends leaderboard

        Error = 9001
    }

    public enum ClientState
    {
        Disconnected, Connected, WaitingForLogin, LoggedIn, InSession, Paused, Locked, Updating
    }

    [Flags]
    public enum OperatorPermission
    {
        None = 0, ViewClients = 1, StartStopSession = 2, AddCredit = 4,
        ManageUsers = 8, ManageGames = 16, ManagePricing = 32, ViewReports = 64,
        ManageOperators = 128, ManageTickets = 256, ShutdownClients = 512,
        ManageBackups = 1024, ManageAnnouncements = 2048, ManageDebts = 4096,
        ManagePackages = 8192, ManageTiers = 16384, ManagePrint = 32768,
        ChatAccess = 65536, ManageSecurity = 131072, ManageThemes = 262144,
        ManageBranches = 524288, ManagePayments = 1048576, SmartPricing = 2097152,
        ApiAccess = 4194304,
        FullAccess = ViewClients | StartStopSession | AddCredit | ManageUsers |
                     ManageGames | ManagePricing | ViewReports | ManageOperators |
                     ManageTickets | ShutdownClients | ManageBackups |
                     ManageAnnouncements | ManageDebts | ManagePackages |
                     ManageTiers | ManagePrint | ChatAccess | ManageSecurity |
                     ManageThemes | ManageBranches | ManagePayments | SmartPricing | ApiAccess
    }

    public class NetMessage
    {
        public MessageType Type { get; set; }
        public string Payload { get; set; }
        public long Timestamp { get; set; }
        public string SessionId { get; set; }
        public NetMessage() { Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(); SessionId = ""; }
        public NetMessage(MessageType type, object payload = null, string sessionId = "")
        { Type = type; Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(); SessionId = sessionId ?? ""; Payload = payload != null ? JsonConvert.SerializeObject(payload) : "{}"; }
        public T GetPayload<T>() => JsonConvert.DeserializeObject<T>(Payload);
        public string ToJson() => JsonConvert.SerializeObject(this);
        public static NetMessage FromJson(string json) => JsonConvert.DeserializeObject<NetMessage>(json);
    }

    public static class Protocol
    {
        public const int DefaultPort = 9090;
        public const int WebSocketPort = 9091;
        public const int MobileApiPort = 8080;
        public const int HeartbeatIntervalSeconds = 30;
        public const int ReconnectBaseDelayMs = 2000;
        public const int ReconnectMaxDelayMs = 60000;
        public const int MaxReconnectAttempts = 50;
        public const string ServerVersion = "1.0";

        public static NetMessage ReadMessage(Stream stream)
        {
            byte[] lenBuf = new byte[4];
            int read = 0;
            while (read < 4) { int n = stream.Read(lenBuf, read, 4 - read); if (n == 0) throw new IOException("Connection closed."); read += n; }
            if (BitConverter.IsLittleEndian) Array.Reverse(lenBuf);
            int len = BitConverter.ToInt32(lenBuf, 0);
            if (len <= 0 || len > 10 * 1024 * 1024) throw new IOException($"Invalid message length: {len}");
            byte[] jsonBuf = new byte[len];
            read = 0;
            while (read < len) { int n = stream.Read(jsonBuf, read, len - read); if (n == 0) throw new IOException("Connection closed."); read += n; }
            return NetMessage.FromJson(Encoding.UTF8.GetString(jsonBuf));
        }

        public static void WriteMessage(Stream stream, NetMessage message)
        {
            byte[] jsonBuf = Encoding.UTF8.GetBytes(message.ToJson());
            byte[] lenBuf = BitConverter.GetBytes(jsonBuf.Length);
            if (BitConverter.IsLittleEndian) Array.Reverse(lenBuf);
            stream.Write(lenBuf, 0, 4);
            stream.Write(jsonBuf, 0, jsonBuf.Length);
            stream.Flush();
        }
    }

    // Phase 1 & 2 Payload DTOs
    public class ClientHelloPayload { public string MachineName; public string MacAddress; public string ClientVersion; public string StationName; public string MachineFingerprint; public string LicenseToken; public string OsVersion; public bool PlayAndPay; public string SelfHash; public string ServerClientPassword; }
    public class ClientLoginPayload { public string Username; public string Password; public string StationName; public string TwoFactorCode; }
    public class ServerWelcomePayload { public string ServerVersion; public string ServerName; public string SessionId; }
    public class ServerLoginResultPayload { public bool Success; public string Message; public string DisplayName; public decimal Balance; public decimal PricePerHour; public int? SessionMinutesRemaining; public bool Requires2FA; }
    public class ServerSessionPayload { public string SessionId; public string Username; public string StationName; public DateTime StartTime; public int DurationMinutes; public decimal Cost; public decimal BalanceRemaining; }
    public class ServerTimeWarningPayload { public int MinutesRemaining; public string Message; public bool IsCritical; }
    public class ServerGameListPayload { public List<GameInfo> Games; }
    public class GameInfo { public int Id; public string Name; public string ExecutablePath; public string IconPath; public string Category; }
    public class ClientGameLaunchedPayload { public int GameId; public string GameName; public string ProcessName; }
    public class ClientStatusPayload { public string StationName; public ClientState State; public string CurrentGame; public double CpuUsage; public double MemoryUsage; public long DiskFreeMb; public bool IsOnline; public string ActiveWindowTitle; public string OsVersion;
        // FIX DEAD-CONFIG-2: seconds since the last keyboard/mouse input on
        // the kiosk PC (via GetLastInputInfo), reported every heartbeat so
        // the server can enforce OptionsForm's "خاموش کردن در بیکاری"
        // (IdleShutdownEnabled/Minutes) setting, which previously had no
        // consumer at all.
        public int IdleSeconds;
    }
    public class TicketRedeemPayload { public string TicketCode; }
    public class TicketResultPayload { public bool Success; public string Message; public decimal CreditAmount; public int DurationMinutes; }

    // Phase 1: Credit notification (server → client when operator adds credit)
    public class AddCreditPayload { public string Username; public decimal Amount; public decimal NewBalance; public string Reason; public DateTime AddedAt; }
    public class OperatorLoginPayload { public string Username; public string Password; public string TwoFactorCode; }
    public class OperatorInfoPayload { public int Id; public string Username; public string DisplayName; public OperatorPermission Permissions; public string RoleName; }
    public class PriceInfoPayload { public decimal PricePerHour; public string Currency; public decimal MinimumCharge; public int RoundingMinutes; }
    public class ServerMessagePayload { public string Title; public string Body; public string Level; }

    // Phase 3: Chat Payloads
    public class ChatSendPayload { public string SenderUsername; public string Message; public string TargetUsername; public bool IsBroadcast; }
    public class ChatReceivePayload { public string SenderUsername; public string SenderDisplayName; public string Message; public DateTime Timestamp; public bool IsBroadcast; public bool IsSystem; }
    public class ChatHistoryPayload { public List<ChatReceivePayload> Messages; }

    // Phase 3: Announcement Payloads
    public class AnnouncementPayload { public int Id; public string Title; public string Body; public string Level; public DateTime CreatedAt; public DateTime? ExpiresAt; public bool IsActive; public string CreatedByName; }
    public class AnnouncementListPayload { public List<AnnouncementPayload> Announcements; }

    // Phase 3: Print/Scan Payloads
    public class PrintRequestPayload { public string Username; public string StationName; public string DocumentName; public int Pages; public string PrintType; public string Notes; }
    public class PrintResultPayload { public bool Success; public string Message; public decimal Cost; public int JobId; }

    // Phase 3: Debt Payloads
    public class DebtPayload { public int Id; public string Username; public decimal Amount; public string Description; public DateTime CreatedAt; public DateTime? DueDate; public bool IsPaid; public DateTime? PaidAt; public string Notes; }
    public class DebtListPayload { public List<DebtPayload> Debts; public decimal TotalDebt; }

    // Phase 3: Session Package Payloads
    public class SessionPackage { public int Id; public string Name; public string Description; public int DurationMinutes; public decimal Price; public bool IsActive; public int MaxUses; public int CurrentUses; public string Category; }
    public class SessionPackagePayload { public int Id; public string Name; public string Description; public int DurationMinutes; public decimal Price; public bool IsActive; public int MaxUses; public int CurrentUses; public string Category; }
    public class PackageListPayload { public List<SessionPackagePayload> Packages; }
    public class PackagePurchasePayload { public int PackageId; public string Username; }
    public class PackageResultPayload { public bool Success; public string Message; public int DurationMinutes; public decimal PricePaid; }

    // Phase 3: Member Tier Payloads
    public class MemberTierPayload { public int Id; public string Name; public string Description; public decimal DiscountPercent; public int RequiredPoints; public decimal MinTopUp; public string Color; public string Icon; public bool IsActive; }
    public class TierInfoPayload { public MemberTierPayload CurrentTier; public MemberTierPayload NextTier; public int CurrentPoints; public int PointsToNextTier; public decimal TotalSpent; }

    // Phase 4: Security Payloads
    public class TwoFactorVerifyPayload { public string Username; public string Code; public bool IsOperator; }
    public class TwoFactorResultPayload { public bool Success; public string Message; public string Secret; public string OtpAuthUri; }
    public class SecurityAlertPayload { public string AlertType; public string Message; public string Severity; public DateTime Timestamp; public string SourceIp; }

    // Phase 5: UX Payloads
    public class ThemeDataPayload { public string ThemeName; public string BackgroundColor; public string SurfaceColor; public string PrimaryColor; public string TextColor; public string AccentColor; public string FontFamily; public float BaseFontSize; }
    public class NotificationPayload { public string Title; public string Body; public string Level; public string Category; public DateTime Timestamp; public bool IsPersistent; }

    // Phase 6: Intelligence Payloads
    public class SmartPricePayload { public decimal BasePrice; public decimal EffectivePrice; public List<AppliedDiscount> AppliedDiscounts; public decimal TrafficLevel; }
    public class AppliedDiscount { public string RuleName; public string RuleType; public decimal DiscountPercent; }
    public class AutoRechargeConfigPayload { public decimal ThresholdAmount; public decimal RechargeAmount; public bool Enabled; }
    public class AutoRechargeResultPayload { public bool Success; public string Message; public decimal NewBalance; }
    public class GameDetectionPayload { public string StationName; public List<DetectedGamePayload> RunningGames; }
    public class DetectedGamePayload { public string ProcessName; public string GameName; public long MemoryUsageMb; }
    public class TrafficPredictionPayload { public List<HourlyPredictionPayload> Predictions; }
    public class HourlyPredictionPayload { public int Hour; public int PredictedClients; }

    // Phase 7: Expansion Payloads
    public class MobileLoginPayload { public string Username; public string Password; public string DeviceId; }
    public class MobileDashboardPayload { public int OnlineClients; public decimal TrafficLevel; public decimal TodayRevenue; public int ActiveSessions; public List<ClientInfoPayload> ConnectedClients; }
    public class ClientInfoPayload { public string StationName; public string CurrentUser; public string State; public int MinutesElapsed; public decimal SessionCost; }
    public class PaymentRequestPayload { public string Username; public decimal Amount; public string Description; }
    public class PaymentUrlPayload { public bool Success; public string PaymentUrl; public string Authority; public string Message; }
    public class PaymentVerifiedPayload { public bool Success; public long RefId; public decimal Amount; public string Username; }
    public class BranchInfoPayload { public int Id; public string Name; public string Address; public string Phone; public int StationCount; public bool IsActive; }
    public class BranchListPayload { public List<BranchInfoPayload> Branches; }

    // Phase 8: Infrastructure Payloads
    public class ServerUpdatePayload { public string Version; public string DownloadUrl; public string ReleaseNotes; public bool IsMandatory; }
    public class ClientUpdateStatusPayload { public string StationName; public string CurrentVersion; public string Status; }
    public class ConfigSyncPayload { public string ServerVersion; public int HeartbeatInterval; public int SessionWarningMinutes; public string ThemeName; public string Language; public Dictionary<string, string> Settings; }

    // Phase 9: Remote monitoring payloads
    public class ScreenshotRequestPayload { public string StationName; public int Quality; } // Quality 1-100 (JPEG)
    public class ScreenshotResponsePayload { public string StationName; public bool Success; public string ImageBase64; public int Width; public int Height; public DateTime CapturedAt; public string Error; }
    // NEW FEATURE (remote input): InputType is one of
    // "mousemove" | "mousedown" | "mouseup" | "mousewheel" | "keydown" | "keyup".
    // NormX/NormY are 0.0–1.0, relative to the FULL screen the screenshot was
    // captured from (see the ServerRemoteInput comment in Protocol.cs for why).
    // Button is "left" | "right" | "middle" for mouse events. KeyCode is a
    // .NET Keys value (cast to int) for keyboard events.
    public class RemoteInputPayload { public string StationName; public string InputType; public double NormX; public double NormY; public string Button; public int WheelDelta; public int KeyCode; }
    // NEW FEATURE (real video+audio codec, per request). ServerIp/Port: where
    // the client's ffmpeg should connect to (the server's own ffplay,
    // already listening by the time this is sent). Quality knobs are
    // exposed here — deliberately adjustable rather than hardcoded — since
    // the right tradeoff between smoothness and load on a cheap kiosk PC's
    // CPU depends on hardware I have no way to test against.
    public class StartVideoStreamPayload { public string StationName; public string ServerIp; public int Port; public int FrameRate = 20; public int ScalePercent = 100; public int VideoBitrateKbps = 2000; public int AudioBitrateKbps = 128; public bool IncludeAudio = true; }
    public class StopVideoStreamPayload { public string StationName; }
    public class VideoStreamStatusPayload { public string StationName; public bool Started; public string Error; }

    // Phase 10: Auto-update + file transfer + crash report payloads
    public class UpdateOfferPayload { public string Version; public long FileSize; public string Sha256; public string ReleaseNotes; public bool IsMandatory; public string Filename; public string Signature; /* Fix 2: base64 RSA-SHA256 over the file, from <file>.sig */ }
    public class UpdateAcceptPayload { public string StationName; public bool Accept; }
    public class FileChunkPayload { public int Sequence; public int TotalSequences; public string Base64Data; public bool IsLast; }
    public class UpdateProgressPayload { public string StationName; public int Percent; public string Status; }
    public class UpdateCompletePayload { public string StationName; public bool Success; public string InstalledVersion; public string Error; }
    public class CrashReportPayload { public string StationName; public string MachineFingerprint; public string ClientVersion; public string ExceptionType; public string ExceptionMessage; public string StackTrace; public DateTime CrashedAt; public string LastAction; }
    public class FileTransferOfferPayload { public string StationName; public string Filename; public long FileSize; public string Sha256; public string TargetPath; public string Description; }
    public class FileTransferAcceptPayload { public string StationName; public bool Accept; }
    public class FileTransferCompletePayload { public string StationName; public bool Success; public string Filename; public string Error; }

    // Phase 11: Quick top-up + sound alerts payloads
    public class TopupRequestPayload { public string Username; public string StationName; public decimal Amount; public string PaymentMethod; public string Notes; public DateTime RequestedAt; }
    public class TopupResponsePayload { public string Username; public bool Approved; public decimal Amount; public string Message; public string ApprovedBy; public DateTime RespondedAt; }

    // Phase 12: Quick time + sound control payloads
    public class SetSessionTimePayload { public string StationName; public string Username; public int Action; public int Minutes; public decimal Amount; public string Reason; }
    // Action: 0=SetTime, 1=AddTime, 2=Unlimited, 3=EndNow
    public class MuteClientPayload { public string StationName; public bool Mute; }
    public class InternetControlPayload { public string StationName; public bool Enable; }
    public class UsbControlPayload { public string StationName; public bool Enable; }
    public class RemoteDesktopPayload { public string StationName; public string ClientIp; public int RdpPort; }
    // FIX FEATURE-1: see ServerCloseGame above.
    public class GameClosePayload { public string StationName; public bool Force; }

    // Phase 13: Client UX enhancement payloads
    public class FoodOrderPayload { public string Username; public string StationName; public List<FoodOrderItem> Items; public decimal TotalAmount; public string Notes; public DateTime OrderedAt; }
    public class FoodOrderItem { public string Name; public int Quantity; public decimal Price; }
    public class FoodOrderResponsePayload { public bool Success; public string Message; public int OrderId; public decimal TotalAmount; }
    public class SessionHistoryItemPayload { public DateTime StartTime; public DateTime? EndTime; public int DurationMinutes; public decimal Cost; public string StationName; public string CurrentGame; }
    public class SessionHistoryPayload { public List<SessionHistoryItemPayload> Sessions; public int TotalSessions; public decimal TotalSpent; public int TotalMinutes; }
    public class GuestLoginPayload { public string StationName; public string MachineName; public string MacAddress; public int Minutes; public decimal PrepaidAmount; }
    public class WallpaperPayload { public string ImageBase64; public int Mode; } // 0=stretch,1=center,2=fit
    public class PauseRequestPayload { public string Username; public string StationName; public int Minutes; public string Reason; }
    public class PauseResponsePayload { public bool Approved; public int Minutes; public string Message; }
    public class LeaderboardEntryPayload { public int Rank; public string Username; public string DisplayName; public int TotalMinutes; public decimal TotalSpent; public int Sessions; }
    public class LeaderboardPayload { public List<LeaderboardEntryPayload> Entries; public string Period; }

    // Models
    public class Operator { public int Id; public string Username; public string PasswordHash; public string Salt; public string DisplayName; public OperatorPermission Permissions; public string RoleName; public bool IsActive; public DateTime CreatedAt; public DateTime? LastLoginAt; public int FailedLoginAttempts; public DateTime? LockedUntil; public string TwoFactorSecret; public bool TwoFactorEnabled; }
    public class Ticket { public int Id; public string Code; public decimal CreditAmount; public int DurationMinutes; public string TicketType; public bool IsUsed; public DateTime CreatedAt; public DateTime? ExpiresAt; public DateTime? UsedAt; public string UsedByUsername; public int? CreatedByOperatorId; public string Notes; public int MaxUses; public int CurrentUses; }
    public class ClientSession { public int Id; public string SessionId; public string Username; public string StationName; public string MachineName; public string MacAddress; public ClientState State; public DateTime StartTime; public DateTime? EndTime; public decimal TotalCost; public int DurationMinutes; public string CurrentGame; public string ClientIp; public DateTime LastHeartbeat; public bool IsConnected; }
    public class ConnectedClient { public string SessionId; public string StationName; public string MachineName; public string ClientIp; public string MacAddress; public ClientState State; public DateTime ConnectedAt; public DateTime LastHeartbeat; public string CurrentUser; public string CurrentGame; public int SessionMinutesElapsed; public decimal SessionCost; public double CpuUsage; public double MemoryUsage; public string ActiveWindowTitle; public string OsVersion; public bool PlayAndPay;
        // FIX H2 — UTC time the user logged in (different from ConnectedAt,
        // which is the TCP connect time). Used by the live sidebar / monitor
        // grid to compute "Used Time" relative to the actual session start,
        // not the socket connect (which can precede login by minutes while
        // the kiosk shows the login panel).
        public DateTime SessionStart;
        // FIX DEAD-CONFIG-2: seconds since the last local input on the
        // kiosk, mirrored from ClientStatusPayload.IdleSeconds on every
        // heartbeat. Drives the IdleShutdownEnabled/Minutes check.
        public int IdleSeconds;
        // FIX M2 — client build version reported by the kiosk in
        // ClientHelloPayload.ClientVersion. Surfaced to the monitor grid so
        // the operator can spot kiosks running an outdated build.
        public string ClientVersion;
        // FIX L14 — per-station time cap (minutes) set by the operator via
        // ServerSetSessionTime action=0 (SetTime) or action=1 (AddTime). 0
        // means "نامحدود" (unlimited). Used by the sidebar live view to show
        // a real remaining time instead of always "نامحدود".
        public int TimeCapMinutes;
    }
}
