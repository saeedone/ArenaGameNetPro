using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace GameNet.Shared.Diagnostics
{
    /// <summary>
    /// One recorded fault. Stored as one JSON object per line in diagnostics.log.
    /// </summary>
    public sealed class FaultRecord
    {
        public DateTime TimeUtc { get; set; }
        /// <summary>"Client" or "Server".</summary>
        public string Side { get; set; }
        public string Code { get; set; }
        public string Severity { get; set; }
        public string Title { get; set; }
        public string Cause { get; set; }
        public string Action { get; set; }
        /// <summary>Technical detail (exception text, IP, station). Never contains passwords.</summary>
        public string Detail { get; set; }
        /// <summary>What the software repaired by itself for this fault ("" when nothing).</summary>
        public string Repair { get; set; }
    }

    /// <summary>
    /// Diagnostics journal: the "detect" and "explain" steps of the self-repair
    /// method. Each fault is kept in memory, appended to diagnostics.log next to
    /// the program, and announced through FaultRaised so the UI can show it.
    /// Every public method is safe to call from any thread and never throws.
    /// </summary>
    public static class FaultJournal
    {
        public const string LogFileName = "diagnostics.log";
        public const string PendingFileName = "pending_report.txt";

        private const long MaxLogBytes = 1024 * 1024;
        private const int MaxMemoryRecords = 300;
        private const int MaxThrottleKeys = 2000;

        private static readonly object _sync = new object();
        private static readonly List<FaultRecord> _recent = new List<FaultRecord>();
        private static readonly Dictionary<string, DateTime> _lastWritten = new Dictionary<string, DateTime>();
        private static string _side = "";
        private static string _directory; // folder that holds diagnostics.log (null = memory only)

        /// <summary>
        /// Raised after a record is written. Handlers run on the thread that
        /// raised the fault, so UI handlers must marshal with BeginInvoke.
        /// </summary>
        public static event Action<FaultRecord> FaultRaised;

        /// <summary>Full path of diagnostics.log, or null before Initialize.</summary>
        public static string LogPath
        {
            get
            {
                string dir;
                lock (_sync) { dir = _directory; }
                return dir == null ? null : Path.Combine(dir, LogFileName);
            }
        }

        /// <summary>
        /// Sets the side name ("Client" or "Server") and the folder for the log.
        /// Uses preferredDirectory when it is writable, otherwise %APPDATA%\GameNet.
        /// </summary>
        public static void Initialize(string side, string preferredDirectory)
        {
            try
            {
                string dir = PickWritableDirectory(preferredDirectory);
                lock (_sync)
                {
                    _side = side ?? "";
                    _directory = dir;
                }
            }
            catch { }
        }

        /// <summary>
        /// Records a fault. Returns the record, or null when it was suppressed
        /// because the same code and key were recorded within the throttle window.
        /// </summary>
        /// <param name="code">A code from FaultCatalog, e.g. "NET-001".</param>
        /// <param name="detail">Technical detail for the log.</param>
        /// <param name="throttleKey">Separates repeats of one code (e.g. per IP). Null = one key per code.</param>
        /// <param name="repair">What the software did automatically; null uses the catalogue text.</param>
        public static FaultRecord Raise(string code, string detail = null, string throttleKey = null, string repair = null)
        {
            try
            {
                FaultDefinition def = FaultCatalog.Get(code);
                string key = def.Code + "|" + (throttleKey ?? "");
                FaultRecord record;
                lock (_sync)
                {
                    DateTime now = DateTime.UtcNow;
                    DateTime last;
                    if (def.ThrottleSeconds > 0 && _lastWritten.TryGetValue(key, out last) &&
                        (now - last).TotalSeconds < def.ThrottleSeconds)
                        return null;

                    if (_lastWritten.Count >= MaxThrottleKeys) _lastWritten.Clear();
                    _lastWritten[key] = now;

                    record = new FaultRecord
                    {
                        TimeUtc = now,
                        Side = _side,
                        Code = def.Code,
                        Severity = def.Severity,
                        Title = def.Title,
                        Cause = def.Cause,
                        Action = def.Action,
                        Detail = Shorten(detail, 2000),
                        Repair = repair ?? def.AutoRepair ?? "",
                    };

                    _recent.Add(record);
                    if (_recent.Count > MaxMemoryRecords)
                        _recent.RemoveRange(0, _recent.Count - MaxMemoryRecords);

                    AppendToFile(record);
                }

                try { FaultRaised?.Invoke(record); } catch { }
                return record;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>Records from this run only, oldest first.</summary>
        public static List<FaultRecord> Recent()
        {
            lock (_sync) { return new List<FaultRecord>(_recent); }
        }

        /// <summary>
        /// Reads the newest records from diagnostics.log (and its .1 backup),
        /// oldest first. Uses shared access so the running program can keep writing.
        /// </summary>
        public static List<FaultRecord> ReadHistory(int maxRecords)
        {
            var result = new List<FaultRecord>();
            try
            {
                string path = LogPath;
                if (path == null) return result;

                var lines = new List<string>();
                AddLines(path + ".1", lines);
                AddLines(path, lines);

                int start = Math.Max(0, lines.Count - maxRecords);
                for (int i = start; i < lines.Count; i++)
                {
                    try
                    {
                        FaultRecord rec = JsonConvert.DeserializeObject<FaultRecord>(lines[i]);
                        if (rec != null) result.Add(rec);
                    }
                    catch { }
                }
            }
            catch { }
            return result;
        }

        /// <summary>
        /// Records a crash that ends the process and keeps a Persian explanation
        /// for the next start (see TakePendingReport).
        /// </summary>
        public static FaultRecord RecordCrash(string code, Exception ex, string source)
        {
            FaultRecord record = Raise(code, (source ?? "") + ": " + Describe(ex));
            try
            {
                string dir;
                lock (_sync) { dir = _directory; }
                if (record != null && dir != null)
                    File.WriteAllText(Path.Combine(dir, PendingFileName), BuildPendingText(record), new UTF8Encoding(false));
            }
            catch { }
            return record;
        }

        /// <summary>
        /// Returns the explanation written by RecordCrash, once, and deletes it.
        /// Returns null when there is nothing to show.
        /// </summary>
        public static string TakePendingReport()
        {
            try
            {
                string dir;
                lock (_sync) { dir = _directory; }
                if (dir == null) return null;

                string path = Path.Combine(dir, PendingFileName);
                if (!File.Exists(path)) return null;

                string text = File.ReadAllText(path, Encoding.UTF8);
                File.Delete(path);
                return text;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>Clears the in-memory state. For unit tests only.</summary>
        public static void ResetForTests()
        {
            lock (_sync)
            {
                _recent.Clear();
                _lastWritten.Clear();
            }
        }

        // ---- helpers (AppendToFile is called while _sync is held) ----

        private static void AppendToFile(FaultRecord record)
        {
            if (_directory == null) return;
            try
            {
                string path = Path.Combine(_directory, LogFileName);
                var info = new FileInfo(path);
                if (info.Exists && info.Length > MaxLogBytes)
                {
                    string backup = path + ".1";
                    try { if (File.Exists(backup)) File.Delete(backup); } catch { }
                    try { File.Move(path, backup); } catch { }
                }

                string line = JsonConvert.SerializeObject(record, Formatting.None);
                using (var fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete))
                using (var sw = new StreamWriter(fs, new UTF8Encoding(false)))
                {
                    sw.WriteLine(line);
                }
            }
            catch { }
        }

        private static void AddLines(string path, List<string> into)
        {
            if (!File.Exists(path)) return;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.Trim().Length > 0) into.Add(line);
                }
            }
        }

        private static string PickWritableDirectory(string preferred)
        {
            if (!string.IsNullOrEmpty(preferred) && CanWrite(preferred)) return preferred;

            string appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GameNet");
            try { Directory.CreateDirectory(appData); } catch { }
            return appData;
        }

        private static bool CanWrite(string dir)
        {
            try
            {
                if (!Directory.Exists(dir)) return false;
                string probe = Path.Combine(dir, LogFileName);
                using (new FileStream(probe, FileMode.Append, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete)) { }
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static string BuildPendingText(FaultRecord r)
        {
            var sb = new StringBuilder();
            sb.AppendLine("در اجرای قبلی برنامه یک خطای بحرانی رخ داد.");
            sb.AppendLine();
            sb.AppendLine("کد خطا: " + r.Code + " - " + r.Title);
            sb.AppendLine("علت احتمالی: " + r.Cause);
            sb.AppendLine("اقدام: " + r.Action);
            if (!string.IsNullOrEmpty(r.Repair)) sb.AppendLine("خودترمیمی: " + r.Repair);
            sb.AppendLine();
            sb.AppendLine("جزئیات فنی: " + Shorten(r.Detail, 600));
            sb.AppendLine("زمان: " + r.TimeUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("گزارش کامل: " + (LogPath ?? LogFileName));
            return sb.ToString();
        }

        private static string Describe(Exception ex)
        {
            if (ex == null) return "(no exception object)";
            return ex.GetType().Name + ": " + ex.Message;
        }

        private static string Shorten(string text, int max)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Length <= max ? text : text.Substring(0, max) + "...";
        }
    }
}
