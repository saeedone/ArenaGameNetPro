using System;

namespace GameNet.Shared.Diagnostics
{
    /// <summary>
    /// Retry timing shared by the client and the server (self-repair rule R1:
    /// retry with backoff and jitter, never in a tight loop).
    /// </summary>
    public static class RecoveryPolicy
    {
        private static readonly Random _random = new Random();
        private static readonly object _randomLock = new object();

        /// <summary>
        /// Exponential backoff: initial * 2^(attempt-1), never more than max.
        /// attempt is 1-based; values below 1 are treated as 1.
        /// </summary>
        public static TimeSpan Backoff(int attempt, TimeSpan initial, TimeSpan max)
        {
            if (attempt < 1) attempt = 1;
            double ms = initial.TotalMilliseconds * Math.Pow(2, Math.Min(attempt - 1, 30));
            if (ms > max.TotalMilliseconds) ms = max.TotalMilliseconds;
            if (ms < 0) ms = 0;
            return TimeSpan.FromMilliseconds(ms);
        }

        /// <summary>
        /// Removes a random share (0 .. fraction) of the delay, so that many
        /// kiosks restarted together do not all retry in the same instant.
        /// The result never exceeds the nominal delay.
        /// </summary>
        public static TimeSpan WithJitter(TimeSpan delay, double fraction)
        {
            if (fraction <= 0) return delay;
            if (fraction > 0.9) fraction = 0.9;
            double r;
            lock (_randomLock) { r = _random.NextDouble(); }
            return TimeSpan.FromMilliseconds(delay.TotalMilliseconds * (1.0 - fraction * r));
        }
    }
}
