using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;

namespace GameNet.Shared.Diagnostics
{
    /// <summary>
    /// Severity names, as they are stored in diagnostics.log.
    /// </summary>
    public static class FaultSeverity
    {
        public const string Info = "Info";
        public const string Warning = "Warning";
        public const string Error = "Error";
        public const string Critical = "Critical";
    }

    /// <summary>
    /// One row of the failure-mode catalogue. Title, cause and action are the
    /// texts that the operator or the kiosk user reads inside the software.
    /// </summary>
    public sealed class FaultDefinition
    {
        public string Code { get; set; }
        public string Severity { get; set; }
        public string Title { get; set; }
        /// <summary>Most likely reason, in plain Persian.</summary>
        public string Cause { get; set; }
        /// <summary>The manual step to take, if one is needed.</summary>
        public string Action { get; set; }
        /// <summary>What the software repairs by itself ("" = nothing automatic).</summary>
        public string AutoRepair { get; set; }
        /// <summary>Minimum seconds between two written records with the same key (0 = always write).</summary>
        public int ThrottleSeconds { get; set; }
        /// <summary>Also show a short, non-modal notice on the kiosk.</summary>
        public bool ShowOnClient { get; set; }
    }

    /// <summary>
    /// Failure-mode catalogue for the FMEA method (see the self-repair report).
    /// Every code the software can record is defined here exactly once. A code
    /// that is not in the catalogue is still recorded, with a generic text.
    /// </summary>
    public static class FaultCatalog
    {
        private static readonly Dictionary<string, FaultDefinition> _byCode = Build();

        /// <summary>Returns the definition for a code. Never returns null.</summary>
        public static FaultDefinition Get(string code)
        {
            FaultDefinition def;
            if (code != null && _byCode.TryGetValue(code, out def)) return def;
            return new FaultDefinition
            {
                Code = code ?? "UNKNOWN",
                Severity = FaultSeverity.Error,
                Title = "خطای ثبت‌نشده",
                Cause = "این کد در کاتالوگ خطاها تعریف نشده است.",
                Action = "کد و جزئیات را برای پشتیبانی بفرستید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            };
        }

        /// <summary>Every defined failure mode.</summary>
        public static IEnumerable<FaultDefinition> All()
        {
            return _byCode.Values;
        }

        /// <summary>
        /// Maps the reason text of a refused TLS handshake (NetworkClient.LastTlsError)
        /// to a catalogue code. Only the code is chosen here; the text stays as it is.
        /// </summary>
        public static string ClassifyTlsReason(string reason)
        {
            if (string.IsNullOrEmpty(reason)) return "NET-002";
            // Checked in this order: key mismatch first, then a pin that changed or was
            // damaged, then pin-file access problems. Anything else is a TLS handshake failure.
            if (Has(reason, "does not match the pinned certificate") || Has(reason, "tls_pin")) return "NET-003";
            if (Has(reason, "changed") || Has(reason, "damaged")) return "NET-004";
            if (Has(reason, "server_pin.txt") || Has(reason, "pinned certificate could not be read")) return "CFG-003";
            return "NET-002";
        }

        private static bool Has(string text, string part)
        {
            return text.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>
        /// Maps an unhandled exception to a crash code (APP-0xx), so that the
        /// explanation shown on the next start names the probable cause.
        /// </summary>
        public static string ClassifyException(Exception ex, bool isServer)
        {
            if (ex is NullReferenceException) return "APP-010";
            if (ex is ObjectDisposedException) return "APP-012";
            if (ex is SocketException) return "APP-014";
            if (ex is OutOfMemoryException) return "APP-015";
            if (ex is UnauthorizedAccessException || ex is IOException) return "APP-013";
            if (ex is InvalidOperationException && ex.Message != null &&
                (ex.Message.IndexOf("thread", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 ex.Message.IndexOf("Invoke", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 ex.Message.IndexOf("handle", StringComparison.OrdinalIgnoreCase) >= 0))
                return "APP-011";
            return isServer ? "APP-002" : "APP-001";
        }

        private static Dictionary<string, FaultDefinition> Build()
        {
            var d = new Dictionary<string, FaultDefinition>(StringComparer.OrdinalIgnoreCase);

            // ---- Network: client side ----
            Put(d, new FaultDefinition
            {
                Code = "NET-001",
                Severity = FaultSeverity.Warning,
                Title = "سرور در دسترس نیست",
                Cause = "اتصال TCP به نشانی و پورت سرور برقرار نشد. سرور خاموش یا در حال راه‌اندازی است، نشانی IP سرور عوض شده، یا فایروال یا کابل شبکه مشکل دارد.",
                Action = "برنامهٔ سرور را روی رایانهٔ سرور اجرا کنید. نشانی IP و پورت را در «تنظیمات اتصال» کیوسک بررسی کنید.",
                AutoRepair = "تلاش مجدد خودکار: اول ۱ ثانیه، سپس با فاصلهٔ افزایشی تا ۳۰ ثانیه، و بعد از ۵۰ تلاش، هر ۶۰ ثانیه.",
                ThrottleSeconds = 300,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-002",
                Severity = FaultSeverity.Error,
                Title = "هندشیک TLS ناموفق بود",
                Cause = "کیوسک و سرور روی TLS یکسان نیستند، یا گواهی سرور خوانده نمی‌شود، یا سرور پاسخ TLS نداد.",
                Action = "تنظیم TLS سرور و کیوسک را یکسان کنید (هر دو روشن یا هر دو خاموش). اگر گواهی سرور مشکل دارد، آن را در تب امنیت سرور بررسی کنید.",
                AutoRepair = "تلاش مجدد با فاصلهٔ افزایشی انجام می‌شود. TLS عمداً خودکار روشن یا خاموش نمی‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = true,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-003",
                Severity = FaultSeverity.Critical,
                Title = "کلید سرور با tls_pin مطابقت ندارد",
                Cause = "فایل tls_pin این کیوسک گواهی دیگری را نشان می‌دهد. یا سرور عوض شده، یا گواهی آن بازسازی شده، یا کسی در مسیر ارتباط است.",
                Action = "اگر سرور را عمداً عوض کرده‌اید، فایل tls_pin را با گواهی جدید به‌روز کنید. در غیر این صورت اتصال را قطع نگه دارید و شبکه را بررسی کنید.",
                AutoRepair = "خیر. اتصال رد می‌شود و پین بی‌صدا بازنویسی نمی‌شود.",
                ThrottleSeconds = 300,
                ShowOnClient = true,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-004",
                Severity = FaultSeverity.Critical,
                Title = "کلید سرور از اولین اتصال تغییر کرده",
                Cause = "کلید عمومی سرور با مقدار ذخیره‌شده در server_pin.txt فرق دارد، یا فایل پین خراب است. دلیل معمول تعویض سرور یا بازسازی گواهی است؛ دلیل نادر، حمله در شبکه.",
                Action = "فقط اگر تعویض سرور را خودتان انجام داده‌اید، فایل server_pin.txt را روی همین کیوسک حذف کنید تا دوباره ثبت شود. در غیر این صورت شبکه را بررسی کنید.",
                AutoRepair = "خیر. پین به‌صورت خودکار بازنویسی نمی‌شود.",
                ThrottleSeconds = 300,
                ShowOnClient = true,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-005",
                Severity = FaultSeverity.Warning,
                Title = "سرور به درخواست ورود پاسخ نداد",
                Cause = "اتصال برقرار شد، اما سرور در ۳۰ ثانیه پاسخ ورود را نداد. دلیل‌های محتمل: محدودیت تعداد پیام (SRV-004)، سرور پرباری، یا قفل پایگاه داده.",
                Action = "چند دقیقه صبر کنید. اگر ادامه داشت، در سرور «عیب‌یابی و گزارش خطاها» را باز کنید و دنبال SRV-004 یا AUTH بگردید.",
                AutoRepair = "اتصال بسته می‌شود و با فاصلهٔ افزایشی دوباره برقرار می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-006",
                Severity = FaultSeverity.Warning,
                Title = "اتصال مجدد کند شد",
                Cause = "۵۰ تلاش سریع متوالی ناموفق بود؛ معمولاً یعنی سرور مدت طولانی در دسترس نبوده است.",
                Action = "نیازی به کار دستی نیست. کیوسک هر ۶۰ ثانیه دوباره تلاش می‌کند. اگر سرور روشن است، تنظیمات اتصال را بررسی کنید.",
                AutoRepair = "تلاش آهسته هر ۶۰ ثانیه تا برقراری اتصال.",
                ThrottleSeconds = 600,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-007",
                Severity = FaultSeverity.Warning,
                Title = "ارتباط با سرور پس از برقراری قطع شد",
                Cause = "اتصال فعال با سرور قطع شد. دلیل‌های محتمل: ری‌استارت یا به‌روزرسانی سرور، قطع شبکه یا کابل، خاموش شدن کارت شبکه، یا بستن اتصال توسط آنتی‌ویروس یا فایروال. متن دلیل فنی در جزئیات ثبت شده است.",
                Action = "اگر سرور همان لحظه ری‌استارت شده، کار خاصی لازم نیست. اگر تکرار شد، کابل و Wi-Fi کیوسک و تنظیمات فایروال را بررسی کنید.",
                AutoRepair = "اتصال با تلاش‌های افزایشی دوباره برقرار می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-008",
                Severity = FaultSeverity.Error,
                Title = "سرور کیوسک را پیش از پذیرش بست",
                Cause = "اتصال TCP برقرار شد، ولی سرور قبل از ServerWelcome آن را بست. دلیل‌های معمول: کیوسک خارج از فهرست مجاز (AUTH-001)، نسخهٔ تغییرکردهٔ کلاینت (AUTH-002)، رمز اتصال کیوسک نادرست (AUTH-003)، یا کیوسکی که بدون TLS وصل شده و سرور TLS را لازم دارد (NET-011). متن دلیل سرور در جزئیات همین خطا ثبت شده است.",
                Action = "متن «دسترسی کیوسک» را بخوانید. در سرور، در «عیب‌یابی و گزارش خطاها»، رکورد AUTH-001، AUTH-002 یا AUTH-003 همان نشانی IP را ببینید؛ علت دقیق همان‌جاست.",
                AutoRepair = "تلاش مجدد با فاصلهٔ افزایشی. اگر دلیل برطرف شود، کیوسک خودکار وصل می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = true,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-900",
                Severity = FaultSeverity.Info,
                Title = "اتصال برقرار شد",
                Cause = "پس از یک قطعی، اتصال دوباره برقرار شد.",
                Action = "اقدامی لازم نیست.",
                AutoRepair = "بازیابی خودکار انجام شد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            // ---- Network: server side ----
            Put(d, new FaultDefinition
            {
                Code = "NET-010",
                Severity = FaultSeverity.Error,
                Title = "کیوسک با TLS وصل شده، سرور بدون TLS است",
                Cause = "بایت‌های ابتدای یک ClientHello با TLS به‌عنوان طول پیام خوانده شد. یعنی کیوسک TLS را روشن دارد و سرور خاموش.",
                Action = "گزینهٔ TLS را در سرور یا کیوسک طوری تنظیم کنید که هر دو یکی شوند.",
                AutoRepair = "خیر. اتصال مانند قبل بسته می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-011",
                Severity = FaultSeverity.Warning,
                Title = "هندشیک TLS در سرور ناموفق بود",
                Cause = "کیوسک بدون TLS یا با نسخهٔ ناسازگار وصل شد، یا هندشیک TLS وسط کار قطع شد.",
                Action = "کیوسک را با نسخهٔ فعلی و تنظیم TLS یکسان به‌روز کنید.",
                AutoRepair = "خیر. اتصال بسته می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "SRV-001",
                Severity = FaultSeverity.Error,
                Title = "خطا در پذیرش اتصال",
                Cause = "حلقهٔ پذیرش اتصال سرور با خطای سوکت روبه‌رو شد.",
                Action = "نیازی به کار دستی نیست. اگر تکرار شد، کارت شبکهٔ سرور و درایور آن را بررسی کنید.",
                AutoRepair = "شنونده با فاصلهٔ افزایشی (تا ۳۰ ثانیه) دوباره راه‌اندازی می‌شود؛ بعد از ۳ خطای پشت‌سرهم سوکت از نو ساخته می‌شود.",
                ThrottleSeconds = 60,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "SRV-003",
                Severity = FaultSeverity.Error,
                Title = "پورت سرور در حال استفاده است",
                Cause = "پورت سرور توسط برنامهٔ دیگری یا نمونهٔ قبلی GameNet.Server اشغال است.",
                Action = "نمونهٔ قبلی GameNet.Server.exe را در Task Manager ببندید، یا پورت را در تنظیمات تغییر دهید و کیوسک‌ها را هم به‌روز کنید.",
                AutoRepair = "سرور با فاصلهٔ افزایشی (۱ تا ۳۰ ثانیه) دوباره تلاش می‌کند و به‌محض آزاد شدن پورت، خودکار وصل می‌شود.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "DB-002",
                Severity = FaultSeverity.Warning,
                Title = "بررسی یکپارچگی کیوسک اجرا نشد",
                Cause = "پایگاه داده در لحظهٔ بررسی «client_known_hash» پاسخ نداد. طبق سیاست فعلی، اتصال کیوسک ادامه می‌یابد (fail-open) و بررسی نسخهٔ کلاینت انجام نمی‌شود.",
                Action = "پایگاه داده را بررسی کنید (قفل یا خرابی فایل gamenet.db). در صورت تکرار، پشتیبان را بازگردانی کنید.",
                AutoRepair = "خیر. تصمیم fail-open عمداً تغییر داده نشده است.",
                ThrottleSeconds = 120,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "SRV-004",
                Severity = FaultSeverity.Warning,
                Title = "محدودیت تعداد پیام برای یک کیوسک",
                Cause = "تعداد پیام‌های یک نشانی از حد مجاز (۳۰ در دقیقه یا ۵۰۰ در ساعت) گذشت. پیام‌های این نشانی تا پایان مسدودی پاسخ داده نمی‌شوند.",
                Action = "معمولاً پس از ۱۵ دقیقه خودبه‌خود باز می‌شود. اگر چند کیوسک پشت یک نشانی هستند، حد نرخ را بالا ببرید یا کیوسک‌ها را جدا کنید.",
                AutoRepair = "مسدودی موقت ۱۵ دقیقه‌ای؛ پس از آن خودکار رفع می‌شود.",
                ThrottleSeconds = 60,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "SRV-900",
                Severity = FaultSeverity.Info,
                Title = "شنونده دوباره برقرار شد",
                Cause = "پس از خطا، پورت سرور دوباره باز شد.",
                Action = "اقدامی لازم نیست.",
                AutoRepair = "بازیابی خودکار انجام شد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            // ---- TLS certificate ----
            Put(d, new FaultDefinition
            {
                Code = "TLS-001",
                Severity = FaultSeverity.Critical,
                Title = "گواهی TLS بارگذاری نشد",
                Cause = "فایل گواهی سرور (server.pfx) خوانده نشد یا گذرواژه‌اش اشتباه است. با TLS روشن، همهٔ اتصال‌ها رد می‌شوند.",
                Action = "در تب امنیت، گواهی را بررسی یا دوباره بسازید و گواهی جدید را طبق راهنما روی کیوسک‌ها جایگزین کنید.",
                AutoRepair = "خیر. گواهی به‌صورت بی‌صدا ساخته یا جایگزین نمی‌شود.",
                ThrottleSeconds = 300,
                ShowOnClient = false,
            });

            // ---- Access control and integrity (server side) ----
            Put(d, new FaultDefinition
            {
                Code = "AUTH-001",
                Severity = FaultSeverity.Warning,
                Title = "کیوسک در فهرست مجاز نیست",
                Cause = "نشانی IP یا MAC کیوسک در فهرست مجاز (whitelist) یا در محدودهٔ CIDR نیست.",
                Action = "اگر کیوسک مجاز است، MAC آن را در تب امنیت به فهرست مجاز اضافه کنید.",
                AutoRepair = "خیر. دسترسی بدون تأیید اپراتور باز نمی‌شود.",
                ThrottleSeconds = 60,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "AUTH-002",
                Severity = FaultSeverity.Error,
                Title = "نسخهٔ کلاینت رسمی نیست",
                Cause = "هش خود کلاینت با مقدار client_known_hash در تنظیمات سرور یکی نیست. یعنی فایل کلاینت تغییر کرده یا نسخهٔ دیگری است.",
                Action = "نسخهٔ رسمی کلاینت را نصب کنید. اگر تغییر را عمداً انجام داده‌اید، client_known_hash را به‌روز کنید.",
                AutoRepair = "خیر. اتصال رد می‌شود.",
                ThrottleSeconds = 60,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "AUTH-003",
                Severity = FaultSeverity.Error,
                Title = "رمز اتصال کیوسک نادرست است",
                Cause = "ServerClientPassword کیوسک با رمز تنظیم‌شده در سرور یکی نیست.",
                Action = "رمز را در تنظیمات سرور و گزینه‌های کلاینت یکسان کنید.",
                AutoRepair = "خیر. اتصال رد می‌شود.",
                ThrottleSeconds = 60,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "CFG-002",
                Severity = FaultSeverity.Critical,
                Title = "فایل تنظیمات سرور (options.json) خوانده نشد",
                Cause = "options.json خراب یا قفل است. تا رفع مشکل، بررسی رمز اتصال کیوسک ممکن است انجام نشود. این رفتار عمداً هنوز تغییر داده نشده است.",
                Action = "فایل options.json را از نسخهٔ پشتیبان برگردانید و برنامهٔ سرور را دوباره اجرا کنید.",
                AutoRepair = "خیر.",
                ThrottleSeconds = 300,
                ShowOnClient = false,
            });

            // ---- Local configuration (client side) ----
            Put(d, new FaultDefinition
            {
                Code = "CFG-001",
                Severity = FaultSeverity.Warning,
                Title = "فایل تنظیمات کیوسک خراب بود",
                Cause = "server_settings.txt خوانده نشد یا هیچ مقدار معتبری نداشت. مثلاً با حساب ویندوز دیگری نوشته شده یا آسیب دیده است.",
                Action = "فایل خراب کنار گذاشته شد. برنامه آدرس سرور را دوباره می‌پرسد یا خودکار پیدا می‌کند. فایل پین (server_pin.txt) دست‌نخورده ماند.",
                AutoRepair = "فایل خراب تغییرنام داده شد (حذف نشد) و تنظیم دوباره انجام می‌شود.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "CFG-003",
                Severity = FaultSeverity.Error,
                Title = "فایل پین کیوسک قابل خواندن یا نوشتن نیست",
                Cause = "server_pin.txt در پوشهٔ برنامه و در %APPDATA%\\GameNet خوانده یا نوشته نمی‌شود. معمولاً مشکل مجوز دسترسی است.",
                Action = "دسترسی نوشتن به پوشهٔ برنامه یا %APPDATA%\\GameNet را به حساب کاربری کیوسک بدهید.",
                AutoRepair = "خیر. پین بدون تأیید دوباره ساخته نمی‌شود.",
                ThrottleSeconds = 300,
                ShowOnClient = true,
            });

            // ---- Database ----
            Put(d, new FaultDefinition
            {
                Code = "DB-001",
                Severity = FaultSeverity.Critical,
                Title = "پایگاه داده باز نشد",
                Cause = "فایل gamenet.db قفل یا خراب است، یا تنظیمات MySQL نادرست است.",
                Action = "نمونه‌های دیگر سرور را ببندید. اگر فایل خراب است، از پشتیبان بازگردانی کنید.",
                AutoRepair = "خیر. سرور بدون پایگاه داده اجرا نمی‌شود.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            // ---- Crashes (both sides) ----
            Put(d, new FaultDefinition
            {
                Code = "APP-001",
                Severity = FaultSeverity.Critical,
                Title = "خطای نامشخص در کلاینت",
                Cause = "یک استثنای مدیریت‌نشده در کلاینت رخ داد.",
                Action = "جزئیات در diagnostics.log، client_crash_log.txt و پوشهٔ crash_logs ثبت شد. اگر تکرار شد، این فایل‌ها را برای پشتیبانی بفرستید.",
                AutoRepair = "اگر وظیفهٔ زمان‌بندی‌شدهٔ GameNetClientWatchdog نصب باشد، کیوسک حداکثر ۶۰ ثانیه بعد از بسته‌شدن دوباره اجرا می‌شود.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-002",
                Severity = FaultSeverity.Critical,
                Title = "خطای نامشخص در سرور",
                Cause = "یک استثنای مدیریت‌نشدهٔ سرور رخ داد.",
                Action = "جزئیات در crash_log.txt و diagnostics.log ثبت شد. سرور را دوباره اجرا کنید؛ اگر تکرار شد، گزارش را بفرستید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-010",
                Severity = FaultSeverity.Error,
                Title = "ارجاع به مقدار خالی",
                Cause = "برنامه به داده‌ای دسترسی پیدا کرد که وجود نداشت. معمولاً داده ناقص یا حالتی است که پیش‌بینی نشده بود.",
                Action = "نسخه را به‌روز کنید و گزارش را بفرستید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-011",
                Severity = FaultSeverity.Error,
                Title = "دسترسی بین‌رشته‌ای به رابط کاربری",
                Cause = "یک رشتهٔ پس‌زمینه مستقیماً به کنترل‌های صفحه دست زد.",
                Action = "گزارش را بفرستید؛ معمولاً با به‌روزرسانی برطرف می‌شود.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-012",
                Severity = FaultSeverity.Error,
                Title = "استفاده از منبع بسته‌شده",
                Cause = "کد برنامه به منبعی دسترسی یافت که قبلاً بسته شده بود.",
                Action = "گزارش را بفرستید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-013",
                Severity = FaultSeverity.Error,
                Title = "خطای فایل یا دسترسی",
                Cause = "فایلی قفل است یا حساب کاربری مجوز لازم را ندارد.",
                Action = "قفل فایل‌ها را بررسی کنید و مجوز پوشهٔ برنامه را بدهید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-014",
                Severity = FaultSeverity.Error,
                Title = "خطای شبکه در برنامه",
                Cause = "یک عملیات شبکه به‌طور غیرمنتظره شکست خورد.",
                Action = "اتصال شبکه و سرور را بررسی کنید. برنامه خودکار دوباره تلاش می‌کند.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "APP-015",
                Severity = FaultSeverity.Critical,
                Title = "کمبود حافظه",
                Cause = "حافظهٔ در دسترس برنامه تمام شد.",
                Action = "برنامه‌های دیگر را ببندید. اگر تکرار شد، رایانه را راه‌اندازی مجدد کنید و گزارش بدهید.",
                AutoRepair = "",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            // ---- Round 15: connection ----
            Put(d, new FaultDefinition
            {
                Code = "HEAL-007",
                Severity = FaultSeverity.Warning,
                Title = "قانون فایروال «قطع اینترنت» اتصال به سرور را هم می‌بست؛ درست شد",
                Cause = "نسخه‌های قبلی برای «نت قطع» همهٔ اتصال‌های خروجی را می‌بستند، از جمله اتصال به سرور GameNet.",
                Action = "کاری لازم نیست.",
                AutoRepair = "قانون قدیمی با قانونی جایگزین شد که فقط اینترنت را می‌بندد؛ شبکهٔ داخلی و سرور وصل می‌مانند.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-012",
                Severity = FaultSeverity.Critical,
                Title = "قانون فایروال «قطع اینترنت» اتصال به سرور را می‌بندد",
                Cause = "یک قانون GameNet_BlockInternet از نسخهٔ قبلی همهٔ اتصال‌های خروجی این کیوسک را می‌بندد و کیوسک دسترسی مدیر ندارد که آن را عوض کند.",
                Action = "کیوسک را یک بار «Run as administrator» اجرا کنید، یا در cmd مدیر بزنید: netsh advfirewall firewall delete rule name=\"GameNet_BlockInternet\"",
                AutoRepair = "خیر (دسترسی مدیر لازم است).",
                ThrottleSeconds = 0,
                ShowOnClient = true,
            });
            Put(d, new FaultDefinition
            {
                Code = "NET-013",
                Severity = FaultSeverity.Critical,
                Title = "فایروال ویندوز سرور ممکن است اتصال کیوسک‌ها را ببندد",
                Cause = "برای برنامهٔ سرور قانون «اجازهٔ ورود» نیست، یا قانون «مسدود» هست (معمولاً وقتی در پیام ویندوز Cancel زده شده یا فقط شبکهٔ Private تیک خورده).",
                Action = "در پیام سرور «بله» بزنید و تأیید مدیر ویندوز را بدهید، یا تب «🩺 عیب‌یابی اتصال» › «درست کردن فایروال».",
                AutoRepair = "با تأیید شما: قانون‌های مسدود برنامهٔ سرور پاک و قانون اجازه برای برنامه و پورت (و ffmpeg) ساخته می‌شود.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            // ---- Round 12: self-repair ----
            Put(d, new FaultDefinition
            {
                Code = "HEAL-001",
                Severity = FaultSeverity.Warning,
                Title = "برنامه بسته شد و خودکار دوباره باز شد",
                Cause = "برنامه بدون خروج عمدی بسته شد: کرش، بسته شدن با Task Manager یا خروج مشتری.",
                Action = "اگر زیاد تکرار شد، گزارش کرش را در «تشخیص خطا» ببینید و برای پشتیبانی بفرستید.",
                AutoRepair = "نگهبان برنامه را ۲ ثانیه بعد دوباره باز کرد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "HEAL-002",
                Severity = FaultSeverity.Warning,
                Title = "برنامه هنگ کرد و دوباره باز شد",
                Cause = "پنجرهٔ برنامه مدتی طولانی به ویندوز جواب نداد.",
                Action = "اگر تکرار شد، برنامه‌های سنگین هم‌زمان، آنتی‌ویروس یا کمبود حافظه را بررسی کنید.",
                AutoRepair = "نگهبان برنامهٔ هنگ‌کرده را بست و دوباره باز کرد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "HEAL-003",
                Severity = FaultSeverity.Error,
                Title = "برنامه پشت سر هم کرش کرد؛ تنظیمات سالم قبلی برگردانده شد",
                Cause = "برنامه در ۵ دقیقه سه بار یا بیشتر بسته شد. ممکن است تنظیمات خراب شده باشد.",
                Action = "اگر باز هم تکرار شد، گزارش کرش را برای پشتیبانی بفرستید.",
                AutoRepair = "آخرین نسخهٔ سالم فایل‌های تنظیمات برگردانده شد؛ فایل‌های قبلی با نام damaged نگه داشته شدند. بعد از شش بار در ۱۰ دقیقه، فاصلهٔ تلاش‌ها ۶۰ ثانیه می‌شود.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "HEAL-004",
                Severity = FaultSeverity.Warning,
                Title = "فایل تنظیمات خراب بود و از نسخهٔ سالم قبلی برگردانده شد",
                Cause = "فایل تنظیمات خوانده نشد یا محتوای معتبری نداشت.",
                Action = "کاری لازم نیست. تنظیماتی که بعد از آخرین اجرای سالم عوض شده بود را دوباره بررسی کنید.",
                AutoRepair = "نسخهٔ سالم قبلی برگردانده شد؛ فایل خراب با نام damaged نگه داشته شد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "HEAL-005",
                Severity = FaultSeverity.Error,
                Title = "پایگاه داده خراب بود و از پشتیبان برگردانده شد",
                Cause = "بررسی یکپارچگی gamenet.db هنگام باز شدن سرور خطا داد (مثلاً قطع برق وسط ذخیره).",
                Action = "تراکنش‌های بعد از زمان آن پشتیبان را دستی بررسی و در صورت نیاز دوباره ثبت کنید.",
                AutoRepair = "آخرین پشتیبان سالم برگردانده شد؛ فایل خراب با نام damaged کنار پایگاه داده نگه داشته شد.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });
            Put(d, new FaultDefinition
            {
                Code = "HEAL-006",
                Severity = FaultSeverity.Critical,
                Title = "پایگاه داده خراب است و پشتیبان سالمی پیدا نشد",
                Cause = "gamenet.db از بررسی یکپارچگی رد شد و هیچ فایل سالمی در پوشهٔ Backups نبود.",
                Action = "فایل gamenet.db را برای پشتیبانی بفرستید. از آن کپی بگیرید و پاکش نکنید.",
                AutoRepair = "خیر.",
                ThrottleSeconds = 0,
                ShowOnClient = false,
            });

            return d;
        }

        private static void Put(Dictionary<string, FaultDefinition> d, FaultDefinition def)
        {
            d[def.Code] = def;
        }
    }
}
