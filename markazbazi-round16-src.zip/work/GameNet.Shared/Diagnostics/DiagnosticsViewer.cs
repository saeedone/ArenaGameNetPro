using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace GameNet.Shared.Diagnostics
{
    /// <summary>
    /// Read-only window that lists the diagnostics journal: when a fault happened,
    /// what it is, the probable cause, what to do, and what the software repaired
    /// by itself. Opened from the server's Tools menu, and on a kiosk by
    /// "GameNet.Client.exe --diagnose".
    /// </summary>
    public sealed class DiagnosticsViewer : Form
    {
        private readonly Label _summary;
        private readonly ListView _list;
        private readonly TextBox _details;
        private List<FaultRecord> _records = new List<FaultRecord>();

        public DiagnosticsViewer()
        {
            Text = "عیب‌یابی GameNet";
            Size = new Size(960, 600);
            MinimumSize = new Size(720, 420);
            StartPosition = FormStartPosition.CenterScreen;
            RightToLeft = RightToLeft.Yes;
            Font = new Font("Segoe UI", 9F);

            _summary = new Label
            {
                Dock = DockStyle.Top,
                Height = 34,
                Padding = new Padding(8, 8, 8, 0),
                Text = "این صفحه فقط خواندنی است و هیچ تنظیمی را تغییر نمی‌دهد.",
            };

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                HideSelection = false,
                MultiSelect = false,
                GridLines = true,
            };
            _list.Columns.Add("زمان", 150);
            _list.Columns.Add("کد", 80);
            _list.Columns.Add("شدت", 80);
            _list.Columns.Add("عنوان", 540);
            _list.SelectedIndexChanged += (s, e) => ShowSelected();

            _details = new TextBox
            {
                Dock = DockStyle.Bottom,
                Height = 210,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = SystemColors.Window,
                Font = new Font("Segoe UI", 9.5F),
            };

            var buttons = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 48,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(8, 6, 8, 6),
            };
            buttons.Controls.Add(MakeButton("بارگذاری مجدد", (s, e) => Reload()));
            buttons.Controls.Add(MakeButton("کپی متن گزارش", (s, e) => CopyDetails()));
            buttons.Controls.Add(MakeButton("باز کردن پوشهٔ گزارش", (s, e) => OpenFolder()));
            buttons.Controls.Add(MakeButton("بستن", (s, e) => Close()));

            // Dock order: the control added last is docked first, so the
            // list (added first) takes whatever space is left.
            Controls.Add(_list);
            Controls.Add(_details);
            Controls.Add(buttons);
            Controls.Add(_summary);

            Reload();
        }

        private void Reload()
        {
            _records = FaultJournal.ReadHistory(500);
            _records.Reverse(); // newest first

            _list.BeginUpdate();
            try
            {
                _list.Items.Clear();
                foreach (FaultRecord r in _records)
                {
                    var item = new ListViewItem(LocalTime(r));
                    item.SubItems.Add(r.Code ?? "");
                    item.SubItems.Add(SeverityText(r.Severity));
                    item.SubItems.Add(r.Title ?? "");
                    item.ForeColor = SeverityColor(r.Severity);
                    item.Tag = r;
                    _list.Items.Add(item);
                }
            }
            finally
            {
                _list.EndUpdate();
            }

            string path = FaultJournal.LogPath ?? "";
            _summary.Text = _records.Count == 0
                ? "هیچ خطایی ثبت نشده است.   فایل گزارش: " + path
                : "تعداد رویدادهای ثبت‌شده: " + _records.Count + "   فایل گزارش: " + path;

            if (_list.Items.Count > 0) _list.Items[0].Selected = true;
            else _details.Text = "";
        }

        private void ShowSelected()
        {
            if (_list.SelectedItems.Count == 0)
            {
                _details.Text = "";
                return;
            }
            var r = _list.SelectedItems[0].Tag as FaultRecord;
            _details.Text = r == null ? "" : BuildText(r);
            _details.SelectionStart = 0;
        }

        private void CopyDetails()
        {
            try
            {
                if (_details.Text.Length > 0) Clipboard.SetText(_details.Text);
            }
            catch { }
        }

        private void OpenFolder()
        {
            try
            {
                string path = FaultJournal.LogPath;
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                    Process.Start("explorer.exe", "/select,\"" + path + "\"");
                else
                    Process.Start("explorer.exe", "\"" + AppDomain.CurrentDomain.BaseDirectory + "\"");
            }
            catch { }
        }

        private static string BuildText(FaultRecord r)
        {
            var sb = new StringBuilder();
            sb.AppendLine("کد: " + r.Code + "    شدت: " + SeverityText(r.Severity) + "    طرف: " + (r.Side ?? ""));
            sb.AppendLine("زمان: " + LocalTime(r));
            sb.AppendLine("عنوان: " + r.Title);
            sb.AppendLine();
            sb.AppendLine("علت احتمالی: " + r.Cause);
            sb.AppendLine("اقدام: " + r.Action);
            if (!string.IsNullOrEmpty(r.Repair)) sb.AppendLine("خودترمیمی: " + r.Repair);
            if (!string.IsNullOrEmpty(r.Detail))
            {
                sb.AppendLine();
                sb.AppendLine("جزئیات فنی: " + r.Detail);
            }
            return sb.ToString();
        }

        private static string LocalTime(FaultRecord r)
        {
            return r.TimeUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss");
        }

        private static string SeverityText(string severity)
        {
            switch (severity)
            {
                case FaultSeverity.Critical: return "بحرانی";
                case FaultSeverity.Error: return "خطا";
                case FaultSeverity.Warning: return "هشدار";
                default: return "اطلاع";
            }
        }

        private static Color SeverityColor(string severity)
        {
            switch (severity)
            {
                case FaultSeverity.Critical: return Color.FromArgb(150, 0, 30);
                case FaultSeverity.Error: return Color.FromArgb(190, 40, 40);
                case FaultSeverity.Warning: return Color.FromArgb(150, 100, 0);
                default: return Color.FromArgb(40, 90, 150);
            }
        }

        private static Button MakeButton(string text, EventHandler onClick)
        {
            var b = new Button { Text = text, AutoSize = true, Padding = new Padding(10, 2, 10, 2) };
            b.Click += onClick;
            return b;
        }
    }
}
