using System;
using System.IO;

namespace GameNet.Shared.SelfHeal
{
    /// <summary>
    /// Round 12 self-repair: keeps a copy of a settings file as it was the last time the
    /// program worked ("name.lastgood" next to it). When the file is damaged, or the
    /// program keeps crashing, that copy is put back instead of falling back to factory
    /// defaults. The damaged file is never deleted: it is renamed "*.damaged-&lt;time&gt;".
    /// </summary>
    public static class LastGoodConfig
    {
        public static string CopyPath(string file) { return file + ".lastgood"; }

        /// <summary>Saves the current file as the last-good copy (only if it has content).</summary>
        public static bool Snapshot(string file)
        {
            try
            {
                if (string.IsNullOrEmpty(file) || !File.Exists(file)) return false;
                if (new FileInfo(file).Length == 0) return false;
                string tmp = CopyPath(file) + ".tmp";
                File.Copy(file, tmp, true);
                if (File.Exists(CopyPath(file))) File.Delete(CopyPath(file));
                File.Move(tmp, CopyPath(file));
                return true;
            }
            catch { return false; }
        }

        public static bool HasCopy(string file)
        {
            try { return !string.IsNullOrEmpty(file) && File.Exists(CopyPath(file)) && new FileInfo(CopyPath(file)).Length > 0; }
            catch { return false; }
        }

        /// <summary>
        /// Puts the last-good copy back. A current file that differs is kept as
        /// "*.damaged-&lt;time&gt;". Returns false when there is no copy.
        /// </summary>
        public static bool Restore(string file)
        {
            try
            {
                if (!HasCopy(file)) return false;
                if (File.Exists(file))
                {
                    if (SameBytes(file, CopyPath(file))) return false; // nothing to repair
                    string aside = file + ".damaged-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
                    File.Move(file, aside);
                }
                File.Copy(CopyPath(file), file, true);
                return true;
            }
            catch { return false; }
        }

        private static bool SameBytes(string a, string b)
        {
            try
            {
                var x = File.ReadAllBytes(a); var y = File.ReadAllBytes(b);
                if (x.Length != y.Length) return false;
                for (int i = 0; i < x.Length; i++) if (x[i] != y[i]) return false;
                return true;
            }
            catch { return false; }
        }
    }
}
