using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Principal;
using System.Text;

namespace GameNet.Shared.SelfHeal
{
    /// <summary>
    /// Round 15: small helpers around Windows Firewall (netsh), used by the kiosk's
    /// "internet off" switch and by the server's firewall check.
    /// </summary>
    public static class FirewallHelper
    {
        public const string KioskBlockRule = "GameNet_BlockInternet";
        public const string KioskBlockRule6 = "GameNet_BlockInternet6";

        public static bool IsElevated()
        {
            try
            {
                using (var id = WindowsIdentity.GetCurrent())
                    return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        /// <summary>Runs netsh; returns the exit code (-1 when it could not run) and its output.</summary>
        public static int Netsh(string args, out string output, int timeoutMs = 8000)
        {
            output = "";
            try
            {
                var psi = new ProcessStartInfo("netsh", args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8,
                };
                using (var p = Process.Start(psi))
                {
                    if (p == null) return -1;
                    string o = p.StandardOutput.ReadToEnd();
                    string e = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(timeoutMs)) { try { p.Kill(); } catch { } return -1; }
                    output = (o + e).Trim();
                    return p.ExitCode;
                }
            }
            catch (Exception ex) { output = ex.Message; return -1; }
        }

        /// <summary>True when a rule with this exact name exists (netsh exits 0 then).</summary>
        public static bool RuleExists(string name)
        {
            string o;
            return Netsh("advfirewall firewall show rule name=\"" + name + "\"", out o) == 0;
        }

        /// <summary>
        /// Runs several netsh commands in one elevated cmd window (Windows asks the
        /// administrator once). Returns false when the user declined or it failed to start.
        /// </summary>
        public static bool RunElevated(IList<string> netshCommands)
        {
            try
            {
                var sb = new StringBuilder();
                foreach (var c in netshCommands) { if (sb.Length > 0) sb.Append(" & "); sb.Append("netsh ").Append(c); }
                var psi = new ProcessStartInfo("cmd.exe", "/c " + sb)
                {
                    UseShellExecute = true,
                    Verb = "runas",
                    WindowStyle = ProcessWindowStyle.Hidden,
                };
                using (var p = Process.Start(psi))
                {
                    if (p == null) return false;
                    p.WaitForExit(30000);
                    return true;
                }
            }
            catch { return false; } // the user pressed "No" on the Windows prompt
        }

        // ---------------------------------------------------------------- kiosk internet block
        // Private / local ranges stay reachable: the GameNet server, the router, printers.
        private static readonly string[][] KeepIPv4 =
        {
            new[] { "0.0.0.0", "0.255.255.255" },
            new[] { "10.0.0.0", "10.255.255.255" },
            new[] { "100.64.0.0", "100.127.255.255" },
            new[] { "127.0.0.0", "127.255.255.255" },
            new[] { "169.254.0.0", "169.254.255.255" },
            new[] { "172.16.0.0", "172.31.255.255" },
            new[] { "192.168.0.0", "192.168.255.255" },
            new[] { "224.0.0.0", "255.255.255.255" },
        };

        private static uint ToUInt(IPAddress a)
        {
            var b = a.GetAddressBytes();
            return ((uint)b[0] << 24) | ((uint)b[1] << 16) | ((uint)b[2] << 8) | b[3];
        }

        private static string FromUInt(uint v)
        {
            return ((v >> 24) & 255) + "." + ((v >> 16) & 255) + "." + ((v >> 8) & 255) + "." + (v & 255);
        }

        /// <summary>
        /// The IPv4 "internet" ranges to block: everything except private/local ranges and
        /// except the server's own address (when the server has a public address).
        /// </summary>
        public static string PublicIPv4Ranges(string serverHost)
        {
            var keep = new List<KeyValuePair<uint, uint>>();
            foreach (var r in KeepIPv4) keep.Add(new KeyValuePair<uint, uint>(ToUInt(IPAddress.Parse(r[0])), ToUInt(IPAddress.Parse(r[1]))));
            try
            {
                foreach (var a in Dns.GetHostAddresses(serverHost ?? ""))
                    if (a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        uint v = ToUInt(a);
                        keep.Add(new KeyValuePair<uint, uint>(v, v));
                    }
            }
            catch { }
            keep.Sort((x, y) => x.Key.CompareTo(y.Key));
            var ranges = new List<string>();
            ulong cursor = 0;
            foreach (var k in keep)
            {
                if (k.Key > cursor) ranges.Add(FromUInt((uint)cursor) + "-" + FromUInt(k.Key - 1));
                if ((ulong)k.Value + 1 > cursor) cursor = (ulong)k.Value + 1;
            }
            if (cursor <= uint.MaxValue) ranges.Add(FromUInt((uint)cursor) + "-255.255.255.255");
            return string.Join(",", ranges);
        }

        /// <summary>
        /// Round 15: "internet off" blocks the internet only. The old rule blocked every
        /// outgoing connection, including the one to the GameNet server, so after
        /// "🚫 نت قطع" the kiosk could never reach the server again (the rule also
        /// survives a reboot) and disappeared from the server for good.
        /// </summary>
        public static bool SetKioskInternet(bool enable, string serverHost, out string error)
        {
            error = null;
            string o;
            Netsh("advfirewall firewall delete rule name=\"" + KioskBlockRule + "\"", out o);
            Netsh("advfirewall firewall delete rule name=\"" + KioskBlockRule6 + "\"", out o);
            if (enable) return true;
            int c1 = Netsh("advfirewall firewall add rule name=\"" + KioskBlockRule + "\" dir=out action=block enable=yes profile=any remoteip=" + PublicIPv4Ranges(serverHost), out o);
            if (c1 != 0) { error = o; return false; }
            int c2 = Netsh("advfirewall firewall add rule name=\"" + KioskBlockRule6 + "\" dir=out action=block enable=yes profile=any remoteip=2000::/3", out o);
            if (c2 != 0) error = o; // IPv4 is blocked; IPv6 rule failed (rare)
            return true;
        }

        /// <summary>
        /// Round 15, at kiosk start: an existing block rule may be the old one that blocks
        /// the server too. It is replaced by the internet-only rule (needs administrator
        /// rights, like the original rule). Returns: 0 nothing to do, 1 repaired,
        /// 2 an old rule exists but could not be replaced (no administrator rights).
        /// </summary>
        public static int RepairKioskBlockRule(string serverHost)
        {
            if (!RuleExists(KioskBlockRule)) return 0;
            string err;
            if (SetKioskInternet(false, serverHost, out err) && RuleExists(KioskBlockRule)) return 1;
            return 2;
        }

        // ---------------------------------------------------------------- server inbound rules
        public const string ServerRuleProgram = "GameNet Server";
        public const string ServerRulePort = "GameNet Server port";
        public const string ServerRuleFfmpeg = "GameNet ffmpeg (live view)";

        public static string FindOnPath(string exe)
        {
            try
            {
                foreach (var dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
                {
                    if (string.IsNullOrWhiteSpace(dir)) continue;
                    string f = Path.Combine(dir.Trim().Trim('"'), exe);
                    if (File.Exists(f)) return f;
                }
            }
            catch { }
            return null;
        }

        /// <summary>The netsh commands that open the server to the kiosks.</summary>
        public static List<string> ServerAllowCommands(string serverExe, int tcpPort)
        {
            var list = new List<string>
            {
                // removes every rule for this exe, including the BLOCK rules Windows creates
                // when someone pressed "Cancel" on its "allow access" prompt
                "advfirewall firewall delete rule name=all program=\"" + serverExe + "\"",
                "advfirewall firewall delete rule name=\"" + ServerRuleProgram + "\"",
                "advfirewall firewall delete rule name=\"" + ServerRulePort + "\"",
                "advfirewall firewall add rule name=\"" + ServerRuleProgram + "\" dir=in action=allow enable=yes profile=any program=\"" + serverExe + "\"",
                "advfirewall firewall add rule name=\"" + ServerRulePort + "\" dir=in action=allow enable=yes profile=any protocol=TCP localport=" + tcpPort,
            };
            string ff = FindOnPath("ffmpeg.exe");
            if (ff != null)
            {
                list.Add("advfirewall firewall delete rule name=\"" + ServerRuleFfmpeg + "\"");
                list.Add("advfirewall firewall add rule name=\"" + ServerRuleFfmpeg + "\" dir=in action=allow enable=yes profile=any program=\"" + ff + "\"");
            }
            return list;
        }

        /// <summary>
        /// True when this program's own allow rule exists and no block rule names it.
        /// The block check reads the rules for this program (works without admin rights).
        /// </summary>
        public static bool ServerRulesOk(string serverExe, out string why)
        {
            why = null;
            if (!RuleExists(ServerRuleProgram)) { why = "قانون «اجازهٔ ورود» برای سرور در فایروال ویندوز وجود ندارد."; return false; }
            string o;
            if (Netsh("advfirewall firewall show rule name=all dir=in verbose", out o, 20000) == 0 && o.Length > 0)
            {
                // A block rule for this exe beats any allow rule.
                var blocks = o.Split(new[] { "\r\n\r\n", "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var block in blocks)
                {
                    if (block.IndexOf(serverExe, StringComparison.OrdinalIgnoreCase) < 0) continue;
                    if (block.IndexOf("Block", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        why = "یک قانون «مسدود» برای برنامهٔ سرور در فایروال ویندوز هست (معمولاً وقتی در پیام ویندوز «Cancel» زده شده).";
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
