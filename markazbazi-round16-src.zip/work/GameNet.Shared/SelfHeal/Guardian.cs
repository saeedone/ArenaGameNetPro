using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace GameNet.Shared.SelfHeal
{
    /// <summary>Settings for the guard of one program (kiosk or server).</summary>
    public sealed class GuardOptions
    {
        /// <summary>"Client" or "Server": names the guard's mutex and state folder.</summary>
        public string Key = "App";
        /// <summary>Seconds the main window may stop answering before the program is restarted (0 = never).</summary>
        public int HangSeconds = 45;
        /// <summary>Settings files restored from their last-good copy when the program keeps crashing.</summary>
        public Func<string[]> ConfigFiles;
    }

    /// <summary>
    /// Round 12 self-repair: a small guard process that brings the program back.
    ///
    /// The program starts a second copy of its own exe with "--guard &lt;pid&gt;". That copy
    /// opens no window. It waits for the program:
    ///  - the program closed without saying it was on purpose (crash, killed, closed by a
    ///    customer) → started again after 2 seconds;
    ///  - its window stopped answering for HangSeconds → ended and started again;
    ///  - three restarts within 5 minutes → the last settings that worked are put back
    ///    before the next start; six within 10 minutes → it waits 60 s between tries.
    /// An exit is "on purpose" only after <see cref="MarkIntentionalExit"/> (kiosk: the
    /// admin column's exit, a self-update, Windows logging off or shutting down; server:
    /// the operator closing it). The program checks every 30 s that its guard is alive
    /// and starts a new one if not, so each watches the other.
    /// What happened is written to guard_event.txt; the program reads it at the next
    /// start (<see cref="TakeEvents"/>) and records it in the fault journal.
    /// </summary>
    public static class Guardian
    {
        public const string GuardArg = "--guard";
        public const string RestartedArg = "--restarted";

        private static Timer _watchTimer;
        private static string _watchKey;

        [DllImport("user32.dll")]
        private static extern int GetSystemMetrics(int nIndex);
        private const int SM_SHUTTINGDOWN = 0x2000;

        // ------------------------------------------------------------ shared paths
        public static string StateDir(string key)
        {
            string dir;
            try
            {
                string pd = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                dir = Path.Combine(string.IsNullOrEmpty(pd) ? AppDomain.CurrentDomain.BaseDirectory : pd, "GameNet", key ?? "App");
                Directory.CreateDirectory(dir);
                return dir;
            }
            catch
            {
                dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "selfheal_" + (key ?? "App"));
                try { Directory.CreateDirectory(dir); } catch { }
                return dir;
            }
        }

        private static string MutexName(string key) { return "Global\\GameNet-" + key + "-Guard"; }
        private static string IntentFile(string key) { return Path.Combine(StateDir(key), "exit_intent.flag"); }
        private static string EventFile(string key) { return Path.Combine(StateDir(key), "guard_event.txt"); }
        private static string LogFile(string key) { return Path.Combine(StateDir(key), "guard_log.txt"); }
        public static string MaintenanceFile(string key) { return Path.Combine(StateDir(key), "maintenance.flag"); }

        public static bool IsGuardInvocation(string[] args)
        {
            return args != null && args.Length >= 2 && string.Equals(args[0], GuardArg, StringComparison.OrdinalIgnoreCase);
        }

        public static bool WasRestarted(string[] args)
        {
            if (args == null) return false;
            foreach (var a in args) if (string.Equals(a, RestartedArg, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        // ------------------------------------------------------------ program side
        /// <summary>Starts the guard now (if none is running) and checks it every 30 seconds.</summary>
        public static void StartWatching(string key)
        {
            _watchKey = key;
            try { File.Delete(IntentFile(key)); } catch { }
            EnsureGuard(key);
            try { _watchTimer?.Dispose(); } catch { }
            _watchTimer = new Timer(_ => EnsureGuard(_watchKey), null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));
        }

        private static void EnsureGuard(string key)
        {
            try
            {
                var self = Process.GetCurrentProcess();
                // This program is exiting on purpose (an intent file written by another,
                // refused copy has a different pid and does not count).
                try
                {
                    string f = IntentFile(key);
                    if (File.Exists(f) && File.ReadAllText(f).Trim() == self.Id.ToString()) return;
                }
                catch { }
                Mutex m;
                if (Mutex.TryOpenExisting(MutexName(key), out m)) { m.Dispose(); return; }
                string exe = self.MainModule.FileName;
                var psi = new ProcessStartInfo(exe, GuardArg + " " + self.Id)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                };
                using (Process.Start(psi)) { }
            }
            catch { }
        }

        /// <summary>
        /// The program is about to close on purpose: the guard lets it go. Also stops the
        /// 30-second check so a new guard is not started during the exit.
        /// </summary>
        public static void MarkIntentionalExit(string key)
        {
            try { _watchTimer?.Dispose(); _watchTimer = null; } catch { }
            try { File.WriteAllText(IntentFile(key), Process.GetCurrentProcess().Id.ToString()); } catch { }
        }

        /// <summary>Kiosk maintenance (admin exit): the scheduled restart task also leaves it closed.</summary>
        public static void SetMaintenance(string key, bool on)
        {
            try
            {
                if (on) File.WriteAllText(MaintenanceFile(key), DateTime.Now.ToString("o"));
                else if (File.Exists(MaintenanceFile(key))) File.Delete(MaintenanceFile(key));
            }
            catch { }
        }

        /// <summary>Returns and removes what the guard recorded since the last start.</summary>
        public static List<string> TakeEvents(string key)
        {
            var list = new List<string>();
            try
            {
                string f = EventFile(key);
                if (!File.Exists(f)) return list;
                foreach (var line in File.ReadAllLines(f, Encoding.UTF8))
                    if (!string.IsNullOrWhiteSpace(line)) list.Add(line.Trim());
                File.Delete(f);
            }
            catch { }
            return list;
        }

        // ------------------------------------------------------------ guard side
        /// <summary>The guard's main loop. Returns the guard's exit code.</summary>
        public static int RunGuard(string[] args, GuardOptions opt)
        {
            int pid;
            if (!int.TryParse(args[1], out pid)) return 2;
            bool createdNew;
            using (var mutex = new Mutex(true, MutexName(opt.Key), out createdNew))
            {
                if (!createdNew) return 0; // another guard is already watching
                Log(opt.Key, "guard started for pid " + pid);

                Process target = null;
                try { target = Process.GetProcessById(pid); IntPtr h0 = target.Handle; } catch { target = null; }
                var restarts = new List<DateTime>();
                string exe = null;
                try { exe = Process.GetCurrentProcess().MainModule.FileName; } catch { }
                if (string.IsNullOrEmpty(exe)) return 3;

                while (true)
                {
                    bool hung = false;
                    if (target != null)
                    {
                        DateTime? notRespondingSince = null;
                        while (true)
                        {
                            bool exited;
                            try { exited = target.WaitForExit(2000); } catch { exited = true; }
                            if (exited) break;
                            if (opt.HangSeconds <= 0) continue;
                            bool responding = true;
                            try
                            {
                                target.Refresh();
                                if (target.MainWindowHandle != IntPtr.Zero) responding = target.Responding;
                            }
                            catch { responding = true; }
                            if (responding) { notRespondingSince = null; continue; }
                            if (notRespondingSince == null) notRespondingSince = DateTime.UtcNow;
                            else if ((DateTime.UtcNow - notRespondingSince.Value).TotalSeconds >= opt.HangSeconds)
                            {
                                hung = true;
                                Log(opt.Key, "pid " + target.Id + " not responding for " + opt.HangSeconds + " s: ended");
                                try { target.Kill(); target.WaitForExit(5000); } catch { }
                                break;
                            }
                        }
                    }

                    int targetPid = -1, exitCode = int.MinValue;
                    try { targetPid = target.Id; } catch { }
                    try { exitCode = target.ExitCode; } catch { }
                    try { target?.Dispose(); } catch { }
                    target = null;

                    // On purpose? (the intent file holds the pid that wrote it)
                    if (!hung)
                    {
                        try
                        {
                            string f = IntentFile(opt.Key);
                            if (File.Exists(f))
                            {
                                string who = File.ReadAllText(f).Trim();
                                File.Delete(f);
                                if (who == targetPid.ToString() || targetPid < 0)
                                {
                                    Log(opt.Key, "pid " + targetPid + " closed on purpose: guard ends");
                                    return 0;
                                }
                            }
                        }
                        catch { }
                    }
                    if (ShuttingDown()) { Log(opt.Key, "Windows is shutting down: guard ends"); return 0; }

                    DateTime now = DateTime.UtcNow;
                    restarts.Add(now);
                    restarts.RemoveAll(t => (now - t).TotalMinutes > 10);
                    int inFive = 0; foreach (var ts in restarts) if ((now - ts).TotalMinutes <= 5) inFive++;

                    string code = hung ? "HEAL-002" : "HEAL-001";
                    string detail = hung ? "پنجرهٔ برنامه " + opt.HangSeconds + " ثانیه جواب نداد"
                                         : "برنامه بسته شد (کد خروج " + (exitCode == int.MinValue ? "نامعلوم" : exitCode.ToString()) + ")";
                    if (inFive >= 3)
                    {
                        int n = 0;
                        try
                        {
                            var files = opt.ConfigFiles != null ? opt.ConfigFiles() : new string[0];
                            foreach (var file in files) if (LastGoodConfig.Restore(file)) n++;
                        }
                        catch { }
                        WriteEvent(opt.Key, "HEAL-003", inFive + " بار در ۵ دقیقه؛ " + n + " فایل تنظیمات از آخرین نسخهٔ سالم برگردانده شد");
                    }
                    WriteEvent(opt.Key, code, detail);
                    Log(opt.Key, code + " " + detail);

                    int wait = restarts.Count >= 6 ? 60 : 2;
                    for (int i = 0; i < wait; i++)
                    {
                        Thread.Sleep(1000);
                        if (ShuttingDown()) return 0;
                        if (File.Exists(IntentFile(opt.Key))) { try { File.Delete(IntentFile(opt.Key)); } catch { } return 0; }
                    }

                    try
                    {
                        var psi = new ProcessStartInfo(exe, RestartedArg)
                        {
                            UseShellExecute = false,
                            WorkingDirectory = Path.GetDirectoryName(exe),
                        };
                        target = Process.Start(psi);
                        try { IntPtr h1 = target.Handle; } catch { }
                        Log(opt.Key, "started again: pid " + (target != null ? target.Id.ToString() : "?"));
                        // Give the new program time to open its window before hang checks.
                        Thread.Sleep(15000);
                    }
                    catch (Exception ex)
                    {
                        Log(opt.Key, "start failed: " + ex.Message);
                        target = null;
                        Thread.Sleep(10000);
                    }
                }
            }
        }

        private static bool ShuttingDown()
        {
            try { return GetSystemMetrics(SM_SHUTTINGDOWN) != 0 || Environment.HasShutdownStarted; } catch { return false; }
        }

        private static void WriteEvent(string key, string code, string detail)
        {
            try
            {
                File.AppendAllText(EventFile(key), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\t" + code + "\t" +
                    (detail ?? "").Replace('\t', ' ').Replace('\n', ' ') + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private static void Log(string key, string msg)
        {
            try
            {
                string f = LogFile(key);
                var fi = new FileInfo(f);
                if (fi.Exists && fi.Length > 512 * 1024) { try { File.Delete(f + ".old"); } catch { } File.Move(f, f + ".old"); }
                File.AppendAllText(f, DateTime.Now.ToString("o") + "  " + msg + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }
    }
}
