using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace GameNet.Shared
{
    /// <summary>
    /// Round 11: the program icon on every window (title bar, taskbar, Alt+Tab),
    /// not only on the .exe file. Loads the multi-size .ico copied next to the exe;
    /// falls back to the icon compiled into the exe (ApplicationIcon in the csproj).
    /// </summary>
    public static class AppIcon
    {
        private static Icon _icon;
        private static bool _loaded;

        public static Icon Get(string icoFileName)
        {
            if (_loaded) return _icon;
            _loaded = true;
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, icoFileName ?? "");
                if (!string.IsNullOrEmpty(icoFileName) && File.Exists(path)) _icon = new Icon(path);
            }
            catch { _icon = null; }
            if (_icon == null)
            {
                try { _icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { _icon = null; }
            }
            return _icon;
        }

        /// <summary>
        /// Makes every window that does not set its own Icon use the program icon.
        /// Call once at startup, before the first form is created. WinForms has no
        /// public setting for this, so it sets Form's private static default icon;
        /// if that field is not there (another framework build), main forms still
        /// get the icon through <see cref="Apply"/>.
        /// </summary>
        public static void InstallAsDefault(string icoFileName)
        {
            var ic = Get(icoFileName);
            if (ic == null) return;
            try
            {
                var f = typeof(Form).GetField("defaultIcon", BindingFlags.NonPublic | BindingFlags.Static);
                if (f != null && f.FieldType == typeof(Icon)) f.SetValue(null, ic);
            }
            catch { }
        }

        public static void Apply(Form form)
        {
            try
            {
                if (form != null && _icon != null) form.Icon = _icon;
            }
            catch { }
        }
    }
}
