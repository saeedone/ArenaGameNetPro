<#
.SYNOPSIS
    Creates the RSA-2048 key pair that signs client self-updates. Run ONCE.

.DESCRIPTION
    The PRIVATE key is written to a folder outside the source tree. Never copy
    it to the server, to a kiosk, or into a repository. Keep an encrypted backup:
    without it you cannot publish updates that the existing kiosks will accept.

    The PUBLIC key is printed as one line. Paste it into
    GameNet.Client\UpdateTrust.cs in place of the PLACEHOLDER text, then rebuild
    the client. Kiosks only accept updates signed with this key pair.

.PARAMETER KeyDir
    Folder that receives update_private_key.xml and update_public_key.xml.
#>
[CmdletBinding()]
param(
    [string]$KeyDir = (Join-Path $env:USERPROFILE 'GameNetUpdateKeys')
)

$ErrorActionPreference = 'Stop'

$privatePath = Join-Path $KeyDir 'update_private_key.xml'
$publicPath  = Join-Path $KeyDir 'update_public_key.xml'

if (Test-Path -LiteralPath $privatePath) {
    throw "A private key already exists at $privatePath. Refusing to overwrite it."
}

New-Item -ItemType Directory -Force -Path $KeyDir | Out-Null

$rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider -ArgumentList 2048
try {
    $privateXml = $rsa.ToXmlString($true)
    $publicXml  = $rsa.ToXmlString($false)
}
finally {
    $rsa.Dispose()
}

$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($privatePath, $privateXml, $utf8NoBom)
[System.IO.File]::WriteAllText($publicPath, $publicXml, $utf8NoBom)

Write-Host ''
Write-Host "PRIVATE key (secret, back it up): $privatePath" -ForegroundColor Yellow
Write-Host "PUBLIC key  (goes into the client): $publicPath" -ForegroundColor Green
Write-Host ''
Write-Host 'Replace the PLACEHOLDER line in GameNet.Client\UpdateTrust.cs with:'
Write-Host ('        private const string PublicKeyXml = @"' + $publicXml + '";')
