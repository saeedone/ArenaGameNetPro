<#
.SYNOPSIS
    Signs a client build so that kiosks accept it as an update.

.DESCRIPTION
    Writes <exe>.sig next to the exe: base64 RSA-SHA256 over the whole file.
    Copy BOTH files into the server's updates folder. Sign the final build only:
    changing the exe after signing makes the signature invalid.

    Run this on the developer's machine, where the private key lives.

.PARAMETER ExePath
    The client build to publish, normally GameNet.Client.exe from the build output.

.PARAMETER KeyPath
    The private key written by New-UpdateKey.ps1.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ExePath,

    [string]$KeyPath = (Join-Path $env:USERPROFILE 'GameNetUpdateKeys\update_private_key.xml')
)

$ErrorActionPreference = 'Stop'

$exe = (Resolve-Path -LiteralPath $ExePath).ProviderPath
if (-not (Test-Path -LiteralPath $KeyPath)) {
    throw "Private key not found: $KeyPath"
}

$bytes  = [System.IO.File]::ReadAllBytes($exe)
$keyXml = [System.IO.File]::ReadAllText($KeyPath)

$rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
try {
    $rsa.FromXmlString($keyXml)
    $signature = $rsa.SignData($bytes, 'SHA256')
    if (-not $rsa.VerifyData($bytes, 'SHA256', $signature)) {
        throw 'Self-check failed: the new signature does not verify.'
    }
}
finally {
    $rsa.Dispose()
}

$sigPath = $exe + '.sig'
[System.IO.File]::WriteAllText($sigPath, [System.Convert]::ToBase64String($signature))

Write-Host "Signed : $exe" -ForegroundColor Green
Write-Host "Written: $sigPath"
Write-Host 'Copy both files to the updates folder next to the server exe.'
