using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Tests
{
    // ===== Phase 1 & 2 Tests =====

    [TestFixture]
    public class DatabaseTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        [Test] public void Execute_Insert() { Database.Instance.Execute("INSERT INTO users (username, display_name, balance, is_active) VALUES (@u, @d, @b, 1)", c => { c.Parameters.AddWithValue("@u", "test"); c.Parameters.AddWithValue("@d", "Test"); c.Parameters.AddWithValue("@b", 50000m); }); Assert.AreEqual(1, Database.Instance.QueryOne("SELECT COUNT(*) FROM users", null, r => r.GetInt32(0))); }
        [Test] public void QueryPaged_Works() { for (int i = 0; i < 30; i++) Database.Instance.Execute("INSERT INTO users (username, display_name, balance, is_active) VALUES (@u, @d, @b, 1)", c => { c.Parameters.AddWithValue("@u", $"u{i}"); c.Parameters.AddWithValue("@d", $"U{i}"); c.Parameters.AddWithValue("@b", 10000m); }); var r = Database.Instance.QueryPaged("SELECT id, username FROM users", "SELECT COUNT(*) FROM users", 2, 10, null, r2 => r2.GetString(1)); Assert.AreEqual(10, r.Items.Count); Assert.AreEqual(30, r.TotalCount); }
    }

    [TestFixture]
    public class UserManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private UserManager _m = new UserManager();
        [Test] public void Create() { var id = _m.CreateUser("user1", "pass1234", "User One", 50000m); var u = _m.FindByUsername("user1"); Assert.AreEqual("user1", u.Username); Assert.AreEqual(50000m, u.Balance); }
        [Test] public void AddCredit() { _m.CreateUser("cr", "pass1234", "Credit", 10000m); _m.AddCredit("cr", 20000m); Assert.AreEqual(30000m, _m.FindByUsername("cr").Balance); }
        [Test] public void DeductCredit() { _m.CreateUser("ded", "pass1234", "Deduct", 50000m); _m.DeductCredit("ded", 10000m); Assert.AreEqual(40000m, _m.FindByUsername("ded").Balance); }
        [Test] public void Transfer() { _m.CreateUser("from", "pass1234", "From", 50000m); _m.CreateUser("to", "pass1234", "To", 0m); _m.TransferCredit("from", "to", 20000m); Assert.AreEqual(30000m, _m.FindByUsername("from").Balance); Assert.AreEqual(20000m, _m.FindByUsername("to").Balance); }
        [Test] public void Transfer_Insufficient_Throws() { _m.CreateUser("poor", "pass1234", "Poor", 1000m); _m.CreateUser("rich", "pass1234", "Rich", 0m); Assert.Throws<InvalidOperationException>(() => _m.TransferCredit("poor", "rich", 5000m)); }
        [Test] public void Authenticate_Ok() { _m.CreateUser("auth", "pass1234", "Auth"); Assert.IsTrue(_m.Authenticate("auth", "pass1234")); }
        [Test] public void Authenticate_Fail() { _m.CreateUser("noauth", "pass1234", "No"); Assert.IsFalse(_m.Authenticate("noauth", "wrong")); }
    }

    [TestFixture]
    public class PricingManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private PricingManager _m = new PricingManager();
        [Test] public void GetDefault() { var p = _m.GetDefaultPlan(); Assert.IsNotNull(p); Assert.IsTrue(p.PricePerHour > 0); }
        [Test] public void Create() { var id = _m.CreatePlan("VIP", 25000m, 5000m, 15); var p = _m.GetPlan(id); Assert.AreEqual("VIP", p.Name); }
        [Test] public void CalculateCost() { var p = _m.GetDefaultPlan(); var cost = _m.CalculateCost(p.Id, 60); Assert.IsTrue(cost > 0); }
    }

    [TestFixture]
    public class OperatorManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private OperatorManager _m = new OperatorManager();
        [Test] public void Create() { var op = _m.CreateOperator("admin2", "pass123456", "Admin 2", OperatorPermission.FullAccess); Assert.AreEqual("admin2", op.Username); }
        [Test] public void Authenticate_Ok() { _m.CreateOperator("auth", "secret123", "Auth", OperatorPermission.FullAccess); Assert.IsNotNull(_m.Authenticate("auth", "secret123")); }
        [Test] public void Authenticate_Fail() { _m.CreateOperator("noauth", "pass123", "No", OperatorPermission.FullAccess); Assert.Throws<UnauthorizedAccessException>(() => _m.Authenticate("noauth", "wrong")); }
        [Test] public void HasPermission() { var op = _m.CreateOperator("perm", "pass123", "Perm", OperatorPermission.ViewClients | OperatorPermission.AddCredit); Assert.IsTrue(_m.HasPermission(op.Id, OperatorPermission.ViewClients)); Assert.IsFalse(_m.HasPermission(op.Id, OperatorPermission.ManageUsers)); }
    }

    [TestFixture]
    public class TicketManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); Database.Instance.Execute("INSERT INTO users (username, display_name, balance, is_active) VALUES (@u, @d, @b, 1)", c => { c.Parameters.AddWithValue("@u", "testuser"); c.Parameters.AddWithValue("@d", "Test"); c.Parameters.AddWithValue("@b", 10000m); }); }
        private TicketManager _m = new TicketManager();
        [Test] public void Create() { var t = _m.CreateTicket(50000m, 60); Assert.AreEqual(50000m, t.CreditAmount); }
        [Test] public void Redeem() { var t = _m.CreateTicket(50000m, 0); var r = _m.RedeemTicket(t.Code, "testuser"); Assert.IsTrue(r.Success); }
        [Test] public void Redeem_Invalid() => Assert.IsFalse(_m.RedeemTicket("BADCODE", "testuser").Success);
        [Test] public void Batch() => Assert.AreEqual(5, _m.CreateBatch(5, 10000m, 30).Count);
    }

    [TestFixture]
    public class StationManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private StationManager _m = new StationManager();
        [Test] public void Create() { int id = _m.CreateStation("PC-01", "192.168.1.10", "AA:BB:CC:DD:EE:01"); Assert.Greater(id, 0); }
        [Test] public void GetAll() { _m.CreateStation("PC-01"); _m.CreateStation("PC-02"); Assert.AreEqual(2, _m.GetAllStations().Count); }
    }

    [TestFixture]
    public class AuditLogTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        [Test] public void Log_Writes() { AuditLog.Log("Cat", "Action"); Assert.AreEqual(1, Database.Instance.QueryOne("SELECT COUNT(*) FROM audit_log", null, r => r.GetInt32(0))); }
    }

    [TestFixture]
    public class ProtocolTests
    {
        [Test] public void Roundtrip() { var orig = new NetMessage(MessageType.ClientHello, new ClientHelloPayload { MachineName = "PC1", StationName = "S1" }); using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, orig); ms.Position = 0; var read = Protocol.ReadMessage(ms); Assert.AreEqual(MessageType.ClientHello, read.Type); var p = read.GetPayload<ClientHelloPayload>(); Assert.AreEqual("PC1", p.MachineName); } }
    }

    // ===== Phase 3 Tests =====

    [TestFixture]
    public class ReportEngineTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private ReportEngine _engine = new ReportEngine();
        [Test] public void GetRevenueReport_ReturnsReport() { var report = _engine.GetRevenueReport(DateTime.UtcNow.AddDays(-30), DateTime.UtcNow); Assert.IsNotNull(report); Assert.AreEqual(0, report.TotalSessions); }
        [Test] public void GetTopUsers_ReturnsList() { var report = _engine.GetTopUsers(DateTime.UtcNow.AddDays(-30), DateTime.UtcNow); Assert.IsNotNull(report); }
    }

    [TestFixture]
    public class ChatManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("chatter1", "pass1234", "Chatter One", 50000m); new UserManager().CreateUser("chatter2", "pass1234", "Chatter Two", 50000m); }
        private ChatManager _m = new ChatManager();
        [Test] public void SendMessage_Direct() { var msg = _m.SendMessage("chatter1", "سلام!", "chatter2"); Assert.AreEqual("سلام!", msg.Message); Assert.IsFalse(msg.IsBroadcast); }
        [Test] public void SendMessage_Broadcast() { var msg = _m.SendMessage("chatter1", "سلام به همه!", null, true); Assert.IsTrue(msg.IsBroadcast); }
        [Test] public void SendSystemMessage() { var msg = _m.SendSystemMessage("سرور ری‌استارت می‌شود"); Assert.IsTrue(msg.IsSystem); }
        [Test] public void GetHistory_ReturnsMessages() { _m.SendMessage("chatter1", "پیام ۱", "chatter2"); _m.SendMessage("chatter2", "پیام ۲", "chatter1"); var history = _m.GetHistory("chatter1"); Assert.GreaterOrEqual(history.Messages.Count, 2); }
        [Test] public void EmptyMessage_Throws() { Assert.Throws<ArgumentException>(() => _m.SendMessage("chatter1", "", "chatter2")); }
    }

    [TestFixture]
    public class AnnouncementManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private AnnouncementManager _m = new AnnouncementManager();
        [Test] public void Create() { var a = _m.CreateAnnouncement("تست", "این یک اطلاعیه تست است", "info"); Assert.AreEqual("تست", a.Title); Assert.IsTrue(a.IsActive); }
        [Test] public void GetActiveAnnouncements() { _m.CreateAnnouncement("فعال", "اطلاعیه فعال", "info"); var active = _m.GetActiveAnnouncements(); Assert.AreEqual(1, active.Announcements.Count); }
        [Test] public void DeleteAnnouncement() { var a = _m.CreateAnnouncement("حذف", "حذف شود", "info"); _m.DeleteAnnouncement(a.Id); Assert.AreEqual(0, _m.GetActiveAnnouncements().Announcements.Count); }
    }

    [TestFixture]
    public class SessionPackageManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("pkguser", "pass1234", "Package User", 200000m); }
        private SessionPackageManager _m = new SessionPackageManager();
        [Test] public void CreatePackage() { var pkg = _m.CreatePackage("۳ ساعته", "بسته ویژه", 180, 40000m, "عادی"); Assert.AreEqual("۳ ساعته", pkg.Name); Assert.AreEqual(180, pkg.DurationMinutes); }
        [Test] public void PurchasePackage_Success() { var pkg = _m.CreatePackage("تست خرید", "", 120, 30000m); var result = _m.PurchasePackage(pkg.Id, "pkguser"); Assert.IsTrue(result.Success); }
        [Test] public void PurchasePackage_InsufficientBalance() { new UserManager().CreateUser("pooruser", "pass1234", "Poor", 1000m); var pkg = _m.CreatePackage("گران", "", 120, 50000m); var result = _m.PurchasePackage(pkg.Id, "pooruser"); Assert.IsFalse(result.Success); }
    }

    [TestFixture]
    public class MemberTierManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("tieruser", "pass1234", "Tier User", 100000m); }
        private MemberTierManager _m = new MemberTierManager();
        [Test] public void GetAllTiers() { var tiers = _m.GetAllTiers(); Assert.GreaterOrEqual(tiers.Count, 4); }
        [Test] public void GetUserTierInfo() { var info = _m.GetUserTierInfo("tieruser"); Assert.IsNotNull(info); Assert.AreEqual("برنزی", info.CurrentTier.Name); }
        [Test] public void AddPointsForSpending() { _m.AddPointsForSpending("tieruser", 100000m); var info = _m.GetUserTierInfo("tieruser"); Assert.AreEqual(10, info.CurrentPoints); }
        [Test] public void GetUserDiscount() { decimal discount = _m.GetUserDiscount("tieruser"); Assert.AreEqual(0m, discount); }
    }

    [TestFixture]
    public class DebtManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("debtuser", "pass1234", "Debt User", 100000m); }
        private DebtManager _m = new DebtManager();
        [Test] public void CreateDebt() { var debt = _m.CreateDebt("debtuser", 50000m, "بدهی تست"); Assert.AreEqual(50000m, debt.Amount); Assert.IsFalse(debt.IsPaid); }
        [Test] public void PayDebt() { var debt = _m.CreateDebt("debtuser", 50000m, "بدهی قابل پرداخت"); bool paid = _m.PayDebt(debt.Id); Assert.IsTrue(paid); }
        [Test] public void PartialPayDebt() { var debt = _m.CreateDebt("debtuser", 50000m, "پرداخت جزئی"); bool paid = _m.PartialPayDebt(debt.Id, 20000m); Assert.IsTrue(paid); var updated = _m.GetDebt(debt.Id); Assert.AreEqual(30000m, updated.Amount); }
        [Test] public void ZeroAmount_Throws() { Assert.Throws<ArgumentException>(() => _m.CreateDebt("debtuser", 0, "صفر")); }
    }

    [TestFixture]
    public class PrintManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("printuser", "pass1234", "Print User", 200000m); }
        private PrintManager _m = new PrintManager();
        [Test] public void CreatePrintJob() { var result = _m.CreatePrintJob("printuser", "PC-01", "document.pdf", 10, "bw"); Assert.IsTrue(result.Success); Assert.AreEqual(20000m, result.Cost); }
        [Test] public void CreateColorPrintJob() { var result = _m.CreatePrintJob("printuser", "PC-01", "color.pdf", 5, "color"); Assert.IsTrue(result.Success); Assert.AreEqual(25000m, result.Cost); }
        [Test] public void ZeroPages_Throws() { Assert.Throws<ArgumentException>(() => _m.CreatePrintJob("printuser", "PC-01", "test.pdf", 0)); }
    }

    // ===== Phase 4 Tests: Security =====

    [TestFixture]
    public class TwoFactorAuthTests
    {
        private TwoFactorAuth _2fa = new TwoFactorAuth();

        [Test] public void GenerateSecret_NotEmpty()
        {
            string secret = _2fa.GenerateSecret();
            Assert.IsNotNull(secret);
            Assert.Greater(secret.Length, 10);
        }

        [Test] public void ValidateCode_Valid()
        {
            string secret = _2fa.GenerateSecret();
            string code = _2fa.GenerateCurrentCode(secret);
            Assert.IsTrue(_2fa.ValidateCode(secret, code));
        }

        [Test] public void ValidateCode_Invalid()
        {
            string secret = _2fa.GenerateSecret();
            Assert.IsFalse(_2fa.ValidateCode(secret, "000000"));
        }

        [Test] public void ValidateCode_EmptySecret()
        {
            Assert.IsFalse(_2fa.ValidateCode("", "123456"));
        }

        [Test] public void GenerateOtpAuthUri()
        {
            string secret = _2fa.GenerateSecret();
            string uri = _2fa.GenerateOtpAuthUri("testuser", secret);
            Assert.IsTrue(uri.StartsWith("otpauth://totp/"));
            Assert.IsTrue(uri.Contains("secret="));
        }

        [Test] public void ValidateCode_WrongLength()
        {
            string secret = _2fa.GenerateSecret();
            Assert.IsFalse(_2fa.ValidateCode(secret, "12345"));
            Assert.IsFalse(_2fa.ValidateCode(secret, "1234567"));
        }
    }

    [TestFixture]
    public class RateLimiterTests
    {
        private RateLimiter _limiter;

        [SetUp] public void Setup() { _limiter = new RateLimiter(maxPerMinute: 5, maxPerHour: 100, blockDuration: 1); }

        [Test] public void Allow_UnderLimit()
        {
            var result = _limiter.CheckLimit("192.168.1.1");
            Assert.IsTrue(result.Allowed);
        }

        [Test] public void Block_OverMinuteLimit()
        {
            for (int i = 0; i < 5; i++) _limiter.CheckLimit("192.168.1.2");
            var result = _limiter.CheckLimit("192.168.1.2");
            Assert.IsFalse(result.Allowed);
        }

        [Test] public void DifferentKeys_Independent()
        {
            for (int i = 0; i < 5; i++) _limiter.CheckLimit("10.0.0.1");
            var result = _limiter.CheckLimit("10.0.0.2");
            Assert.IsTrue(result.Allowed);
        }

        [Test] public void EmptyKey_Allowed()
        {
            var result = _limiter.CheckLimit("");
            Assert.IsTrue(result.Allowed);
        }

        [Test] public void ManualBlock()
        {
            _limiter.Block("192.168.1.3", 10);
            var result = _limiter.CheckLimit("192.168.1.3");
            Assert.IsFalse(result.Allowed);
        }

        [Test] public void Unblock()
        {
            _limiter.Block("192.168.1.4", 10);
            _limiter.Unblock("192.168.1.4");
            var result = _limiter.CheckLimit("192.168.1.4");
            Assert.IsTrue(result.Allowed);
        }
    }

    [TestFixture]
    public class TlsWrapperTests
    {
        [Test] public void NoCertificate_IsDisabled()
        {
            var tls = new TlsWrapper();
            Assert.IsFalse(tls.IsEnabled);
        }

        [Test] public void CertificateInfo_NotLoaded()
        {
            var tls = new TlsWrapper();
            var info = tls.GetCertificateInfo();
            Assert.IsFalse(info.IsLoaded);
        }
    }

    [TestFixture]
    public class EnhancedAuditLogTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }

        [Test] public void Log_Writes()
        {
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Auth, "Login", "test login", EnhancedAuditLog.AuditLevel.Info, "admin", "127.0.0.1", "PC-01");
            var entries = EnhancedAuditLog.Query();
            Assert.AreEqual(1, entries.Count);
            Assert.AreEqual("Login", entries[0].Action);
        }

        [Test] public void Query_ByCategory()
        {
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Auth, "Login", "", EnhancedAuditLog.AuditLevel.Info);
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "Charge", "", EnhancedAuditLog.AuditLevel.Info);
            var entries = EnhancedAuditLog.Query(category: EnhancedAuditLog.AuditCategory.Auth);
            Assert.AreEqual(1, entries.Count);
        }

        [Test] public void Query_ByLevel()
        {
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.System, "Info", "", EnhancedAuditLog.AuditLevel.Info);
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Security, "Breach", "", EnhancedAuditLog.AuditLevel.Critical);
            var entries = EnhancedAuditLog.Query(minLevel: EnhancedAuditLog.AuditLevel.Error);
            Assert.AreEqual(1, entries.Count);
        }

        [Test] public void CleanupOldEntries()
        {
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.System, "Old", "", EnhancedAuditLog.AuditLevel.Info);
            int deleted = EnhancedAuditLog.CleanupOldEntries(0);
            Assert.GreaterOrEqual(deleted, 0);
        }
    }

    // ===== Phase 5 Tests: UX =====

    [TestFixture]
    public class ThemeBuilderTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }

        [Test] public void GetCurrentTheme_Default()
        {
            var builder = new ThemeBuilder();
            var theme = builder.GetCurrentTheme();
            Assert.IsNotNull(theme);
            Assert.AreEqual("Catppuccin Mocha", theme.Name);
        }

        [Test] public void GetPresetThemes()
        {
            var builder = new ThemeBuilder();
            var presets = builder.GetPresetThemes();
            Assert.GreaterOrEqual(presets.Count, 5);
        }

        [Test] public void SaveTheme()
        {
            var builder = new ThemeBuilder();
            var theme = AppThemePreset.CatppuccinMocha();
            theme.Name = "TestTheme";
            builder.SaveTheme(theme);
            var loaded = builder.GetCurrentTheme();
            Assert.AreEqual("TestTheme", loaded.Name);
        }
    }

    [TestFixture]
    public class LocalizationManagerTests
    {
        [Test] public void DefaultLanguage_IsFarsi()
        {
            var loc = new LocalizationManager();
            Assert.AreEqual("fa", loc.CurrentLanguage);
        }

        [Test] public void Get_FarsiKey()
        {
            var loc = new LocalizationManager();
            string val = loc.Get("app.title");
            Assert.AreEqual("مدیریت گیم‌نت", val);
        }

        [Test] public void SwitchToEnglish()
        {
            var loc = new LocalizationManager();
            loc.CurrentLanguage = "en";
            string val = loc.Get("app.title");
            Assert.AreEqual("GameNet Manager", val);
        }

        [Test] public void MissingKey_ReturnsKey()
        {
            var loc = new LocalizationManager();
            string val = loc.Get("nonexistent.key.xyz");
            Assert.AreEqual("nonexistent.key.xyz", val);
        }

        [Test] public void GetAvailableLanguages()
        {
            var loc = new LocalizationManager();
            var langs = loc.GetAvailableLanguages();
            Assert.Contains("fa", langs);
            Assert.Contains("en", langs);
        }

        [Test] public void AddCustomTranslation()
        {
            var loc = new LocalizationManager();
            loc.AddTranslation("fa", "custom.key", "مقدار سفارشی");
            Assert.AreEqual("مقدار سفارشی", loc.Get("custom.key"));
        }
    }

    // ===== Phase 6 Tests: Intelligence =====

    [TestFixture]
    public class SmartPricingTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }

        [Test] public void CalculateEffectivePrice_NoRules()
        {
            var sp = new SmartPricing();
            decimal price = sp.CalculateEffectivePrice("user1", "PC-01", 15000m);
            Assert.AreEqual(15000m, price);
        }

        [Test] public void CreateRule()
        {
            var sp = new SmartPricing();
            var rule = sp.CreateRule("Night Discount", "time_of_day", @"{""StartHour"":22,""EndHour"":8}", 20m);
            Assert.IsNotNull(rule);
            Assert.AreEqual("Night Discount", rule.Name);
            Assert.AreEqual(20m, rule.DiscountPercent);
        }

        [Test] public void CreateRule_EmptyName_Throws()
        {
            var sp = new SmartPricing();
            Assert.Throws<ArgumentException>(() => sp.CreateRule("", "time_of_day", "{}", 10m));
        }

        [Test] public void CreateRule_InvalidDiscount_Throws()
        {
            var sp = new SmartPricing();
            Assert.Throws<ArgumentException>(() => sp.CreateRule("Test", "time_of_day", "{}", 0m));
            Assert.Throws<ArgumentException>(() => sp.CreateRule("Test", "time_of_day", "{}", 101m));
        }

        [Test] public void DeleteRule()
        {
            var sp = new SmartPricing();
            var rule = sp.CreateRule("ToDelete", "low_traffic", "{}", 15m);
            sp.DeleteRule(rule.Id);
            Assert.AreEqual(0, sp.GetActiveRules().Count);
        }

        [Test] public void GetCurrentTrafficLevel()
        {
            var sp = new SmartPricing();
            decimal traffic = sp.GetCurrentTrafficLevel();
            Assert.GreaterOrEqual(traffic, 0m);
            Assert.LessOrEqual(traffic, 1m);
        }

        [Test] public void PredictTraffic()
        {
            var sp = new SmartPricing();
            var pred = sp.PredictTraffic(24);
            Assert.IsNotNull(pred);
            Assert.AreEqual(24, pred.HourlyPredictions.Count);
        }
    }

    [TestFixture]
    public class AutoRechargeTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); new UserManager().CreateUser("rechargeuser", "pass1234", "Recharge User", 100000m); }

        [Test] public void SetAutoRecharge()
        {
            var ar = new AutoRecharge();
            ar.SetAutoRecharge("rechargeuser", 10000m, 50000m);
            var config = ar.GetAutoRecharge("rechargeuser");
            Assert.IsTrue(config.Enabled);
            Assert.AreEqual(10000m, config.ThresholdAmount);
            Assert.AreEqual(50000m, config.RechargeAmount);
        }

        [Test] public void DisableAutoRecharge()
        {
            var ar = new AutoRecharge();
            ar.SetAutoRecharge("rechargeuser", 10000m, 50000m);
            ar.DisableAutoRecharge("rechargeuser");
            var config = ar.GetAutoRecharge("rechargeuser");
            Assert.IsFalse(config.Enabled);
        }

        [Test] public void SetAutoRecharge_InvalidThreshold_Throws()
        {
            var ar = new AutoRecharge();
            Assert.Throws<ArgumentException>(() => ar.SetAutoRecharge("rechargeuser", 0, 50000m));
        }
    }

    [TestFixture]
    public class GameDetectorTests
    {
        [Test] public void DetectRunningGames_ReturnsList()
        {
            var detector = new GameDetector();
            var games = detector.DetectRunningGames();
            Assert.IsNotNull(games);
        }

        [Test] public void BuildGameLibrary_InvalidPath()
        {
            var detector = new GameDetector();
            var games = detector.BuildGameLibrary("/nonexistent/path");
            Assert.IsNotNull(games);
            Assert.AreEqual(0, games.Count);
        }
    }

    // ===== Phase 7 Tests: Expansion =====

    [TestFixture]
    public class BranchManagerTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }
        private BranchManager _m = new BranchManager();

        [Test] public void CreateBranch()
        {
            var branch = _m.CreateBranch("شعبه مرکزی", "تهران، مرکز", "02112345678", "علی", 20);
            Assert.AreEqual("شعبه مرکزی", branch.Name);
            Assert.AreEqual(20, branch.StationCount);
            Assert.IsTrue(branch.IsActive);
        }

        [Test] public void GetAllBranches()
        {
            _m.CreateBranch("شعبه ۱", "تهران", "0211", "مدیر", 10);
            _m.CreateBranch("شعبه ۲", "اصفهان", "0311", "مدیر", 15);
            var branches = _m.GetAllBranches();
            Assert.AreEqual(2, branches.Count);
        }

        [Test] public void DeleteBranch()
        {
            var branch = _m.CreateBranch("حذفی", "مشهد", "0511", "مدیر", 5);
            _m.DeleteBranch(branch.Id);
            Assert.AreEqual(0, _m.GetAllBranches().Count);
        }

        [Test] public void EmptyName_Throws()
        {
            Assert.Throws<ArgumentException>(() => _m.CreateBranch("", "آدرس", "تلفن", "مدیر"));
        }
    }

    [TestFixture]
    public class PaymentGatewayTests
    {
        [Test] public void NoMerchantId_Throws()
        {
            var gw = new PaymentGateway("");
            Assert.Throws<InvalidOperationException>(() => gw.RequestPayment("user1", 50000m));
        }

        [Test] public void LowAmount_Throws()
        {
            var gw = new PaymentGateway("test-merchant");
            Assert.Throws<ArgumentException>(() => gw.RequestPayment("user1", 500m));
        }

        [Test] public void GetTransactions_Empty()
        {
            Database.Initialize("Data Source=:memory:");
            var gw = new PaymentGateway("test-merchant");
            var txs = gw.GetTransactions();
            Assert.IsNotNull(txs);
        }
    }

    [TestFixture]
    public class MobileApiControllerTests
    {
        [Test] public void ApiKey_NotEmpty()
        {
            Database.Initialize("Data Source=:memory:");
            var api = new MobileApiController(null, 8080, "test-key");
            Assert.AreEqual("test-key", api.GetApiKey());
        }

        [Test] public void ApiKey_AutoGenerated()
        {
            Database.Initialize("Data Source=:memory:");
            var api = new MobileApiController(null);
            Assert.Greater(api.GetApiKey().Length, 10);
        }
    }

    // ===== Phase 8 Tests: Infrastructure =====

    [TestFixture]
    public class AutoUpdaterTests
    {
        [Test] public void CheckForUpdates_NoUrl()
        {
            var updater = new AutoUpdater();
            var info = updater.CheckForUpdates();
            Assert.IsFalse(info.HasUpdate);
            Assert.AreEqual("8.0", info.CurrentVersion);
        }
    }

    [TestFixture]
    public class PgDatabaseTests
    {
        [Test] public void GeneratePgSchema_ContainsTables()
        {
            var pg = new PgDatabase("Host=localhost");
            string schema = pg.GeneratePgSchema();
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS users"));
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS operators"));
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS branches"));
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS payment_transactions"));
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS smart_pricing_rules"));
            Assert.IsTrue(schema.Contains("CREATE TABLE IF NOT EXISTS enhanced_audit_log"));
        }
    }

    // ===== Cross-Phase Protocol Tests =====

    [TestFixture]
    public class Phase4ProtocolTests
    {
        [Test] public void TwoFactorResultPayload_Serialization()
        {
            var msg = new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = true, Message = "تأیید شد", Secret = "JBSWY3DPEHPK3PXP" });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); Assert.AreEqual(MessageType.Server2FAResult, read.Type); var p = read.GetPayload<TwoFactorResultPayload>(); Assert.IsTrue(p.Success); Assert.AreEqual("JBSWY3DPEHPK3PXP", p.Secret); } }
    }

    [TestFixture]
    public class Phase6ProtocolTests
    {
        [Test] public void SmartPricePayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerSmartPriceInfo, new SmartPricePayload { BasePrice = 15000m, EffectivePrice = 12000m, TrafficLevel = 0.3m });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<SmartPricePayload>(); Assert.AreEqual(15000m, p.BasePrice); Assert.AreEqual(12000m, p.EffectivePrice); } }

        [Test] public void TrafficPredictionPayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerTrafficPrediction, new TrafficPredictionPayload { Predictions = new List<HourlyPredictionPayload> { new HourlyPredictionPayload { Hour = 14, PredictedClients = 8 } } });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<TrafficPredictionPayload>(); Assert.AreEqual(1, p.Predictions.Count); Assert.AreEqual(14, p.Predictions[0].Hour); } }
    }

    [TestFixture]
    public class Phase7ProtocolTests
    {
        [Test] public void PaymentUrlPayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerPaymentUrl, new PaymentUrlPayload { Success = true, PaymentUrl = "https://sandbox.zarinpal.com/pg/StartPay/abc123", Authority = "abc123" });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<PaymentUrlPayload>(); Assert.IsTrue(p.Success); Assert.AreEqual("abc123", p.Authority); } }

        [Test] public void MobileDashboardPayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerMobileDashboard, new MobileDashboardPayload { OnlineClients = 5, TrafficLevel = 0.5m, TodayRevenue = 500000m, ActiveSessions = 3, ConnectedClients = new List<ClientInfoPayload>() });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<MobileDashboardPayload>(); Assert.AreEqual(5, p.OnlineClients); Assert.AreEqual(500000m, p.TodayRevenue); } }
    }

    [TestFixture]
    public class Phase8ProtocolTests
    {
        [Test] public void UpdatePayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerUpdateAvailable, new ServerUpdatePayload { Version = "8.1", DownloadUrl = "https://update.gamenet.ir/v8.1.zip", IsMandatory = false });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<ServerUpdatePayload>(); Assert.AreEqual("8.1", p.Version); Assert.IsFalse(p.IsMandatory); } }

        [Test] public void ConfigSyncPayload_Serialization()
        {
            var msg = new NetMessage(MessageType.ServerConfigSync, new ConfigSyncPayload { ServerVersion = "8.0", HeartbeatInterval = 30, SessionWarningMinutes = 15, ThemeName = "Catppuccin Mocha", Language = "fa", Settings = new Dictionary<string, string> { { "key1", "val1" } } });
            using (var ms = new MemoryStream()) { Protocol.WriteMessage(ms, msg); ms.Position = 0; var read = Protocol.ReadMessage(ms); var p = read.GetPayload<ConfigSyncPayload>(); Assert.AreEqual("8.0", p.ServerVersion); Assert.AreEqual("fa", p.Language); } }
    }
}
