using System;
using NUnit.Framework;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Tests
{
    /// <summary>Round 14: full rights for the system administrator; activity journal.</summary>
    [TestFixture]
    public class Round14Tests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); ActivityJournal.CurrentOperator = ""; }

        [Test]
        public void SuperAdmin_WithOldRights_HasNewRights()
        {
            var m = new OperatorManager();
            // an admin from an older version: no ApiAccess / SmartPricing bits
            var op = m.CreateOperator("boss", "pass123", "مدیر سیستم", OperatorPermission.ViewClients | OperatorPermission.ManageUsers, "SuperAdmin");
            Assert.IsTrue(m.HasPermission(op, OperatorPermission.ApiAccess));
            Assert.IsTrue(m.HasPermission(op.Id, OperatorPermission.ManagePricing));
        }

        [Test]
        public void NormalOperator_KeepsLimits()
        {
            var m = new OperatorManager();
            var op = m.CreateOperator("staff1", "pass123", "Staff", OperatorPermission.ViewClients, "Operator");
            Assert.IsTrue(m.HasPermission(op, OperatorPermission.ViewClients));
            Assert.IsFalse(m.HasPermission(op, OperatorPermission.ApiAccess));
        }

        [Test]
        public void Journal_RecordsAndFilters()
        {
            ActivityJournal.CurrentOperator = "علی (ali)";
            ActivityJournal.Record(ActivityJournal.Station, "سیستم روشن / وصل شد", "PC-01");
            ActivityJournal.Record(ActivityJournal.TimeCredit, "افزودن 30 دقیقه", "PC-01");
            ActivityJournal.Record(ActivityJournal.Operator, "خروج اپراتور «علی (ali)»");
            var all = ActivityJournal.Query(DateTime.UtcNow.AddMinutes(-5), DateTime.UtcNow.AddMinutes(5));
            Assert.AreEqual(3, all.Count);
            Assert.AreEqual("علی (ali)", all[0].Operator);
            var onlyTime = ActivityJournal.Query(DateTime.UtcNow.AddMinutes(-5), DateTime.UtcNow.AddMinutes(5), ActivityJournal.TimeCredit);
            Assert.AreEqual(1, onlyTime.Count);
            var search = ActivityJournal.Query(DateTime.UtcNow.AddMinutes(-5), DateTime.UtcNow.AddMinutes(5), null, "PC-01");
            Assert.AreEqual(2, search.Count);
            Assert.IsTrue(ActivityJournal.LastLeaveOf("علی (ali)").HasValue);
            Assert.IsFalse(ActivityJournal.LastLeaveOf("someone else").HasValue);
        }
    }
}
