using NUnit.Framework;
using GameNet.Shared.SelfHeal;

namespace GameNet.Server.Tests
{
    /// <summary>Round 15: the kiosk's "internet off" rule must never cover the LAN or the server.</summary>
    [TestFixture]
    public class KioskInternetRuleTests
    {
        [Test]
        public void PrivateRanges_AreNotBlocked()
        {
            string r = FirewallHelper.PublicIPv4Ranges("192.168.1.10");
            StringAssert.StartsWith("1.0.0.0-9.255.255.255,11.0.0.0-100.63.255.255", r);
            StringAssert.DoesNotContain("192.168.0.0", r);
            StringAssert.Contains("192.169.0.0-223.255.255.255", r);
            Assert.AreEqual(7, r.Split(',').Length);
        }

        [Test]
        public void PublicServerAddress_IsKeptOpen()
        {
            string r = FirewallHelper.PublicIPv4Ranges("5.6.7.8");
            StringAssert.Contains("1.0.0.0-5.6.7.7,5.6.7.9-9.255.255.255", r);
        }
    }
}
