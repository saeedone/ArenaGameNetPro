using System;
using System.IO;
using NUnit.Framework;
using GameNet.Server.Core;
using GameNet.Shared.SelfHeal;

namespace GameNet.Server.Tests
{
    /// <summary>Round 12: self-repair building blocks.</summary>
    [TestFixture]
    public class SelfRepairTests
    {
        private string _dir;

        [SetUp] public void Setup() { _dir = Path.Combine(Path.GetTempPath(), "gn_selfheal_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(_dir); }
        [TearDown] public void TearDown() { try { Directory.Delete(_dir, true); } catch { } }

        [Test]
        public void LastGood_RestoresDamagedFile_AndKeepsIt()
        {
            string f = Path.Combine(_dir, "options.json");
            File.WriteAllText(f, "{\"a\":\"1\"}");
            Assert.IsTrue(LastGoodConfig.Snapshot(f));
            File.WriteAllText(f, "{garbage");
            Assert.IsTrue(LastGoodConfig.Restore(f));
            Assert.AreEqual("{\"a\":\"1\"}", File.ReadAllText(f));
            Assert.AreEqual(1, Directory.GetFiles(_dir, "options.json.damaged-*").Length);
        }

        [Test]
        public void LastGood_NoCopyOrSame_DoesNothing()
        {
            string f = Path.Combine(_dir, "x.txt");
            File.WriteAllText(f, "abc");
            Assert.IsFalse(LastGoodConfig.Restore(f));           // no copy yet
            LastGoodConfig.Snapshot(f);
            Assert.IsFalse(LastGoodConfig.Restore(f));           // identical: nothing to repair
            Assert.AreEqual(0, Directory.GetFiles(_dir, "*.damaged-*").Length);
        }

        [Test]
        public void LastGood_EmptyFileIsNotSnapshotted()
        {
            string f = Path.Combine(_dir, "e.txt");
            File.WriteAllText(f, "");
            Assert.IsFalse(LastGoodConfig.Snapshot(f));
        }

        [Test]
        public void DatabaseCheck_GoodAndDamaged()
        {
            string good = Path.Combine(_dir, "good.db");
            using (var c = new System.Data.SQLite.SQLiteConnection("Data Source=" + good + ";Version=3;"))
            {
                c.Open();
                using (var cmd = new System.Data.SQLite.SQLiteCommand("CREATE TABLE t(x); INSERT INTO t VALUES (1);", c)) cmd.ExecuteNonQuery();
            }
            System.Data.SQLite.SQLiteConnection.ClearAllPools();
            Assert.AreEqual("ok", DatabaseSelfRepair.Check(good));

            string bad = Path.Combine(_dir, "bad.db");
            File.WriteAllBytes(bad, new byte[4096]); // not a database
            Assert.AreNotEqual("ok", DatabaseSelfRepair.Check(bad));
        }

        [Test]
        public void Guardian_Arguments()
        {
            Assert.IsTrue(Guardian.IsGuardInvocation(new[] { "--guard", "123" }));
            Assert.IsFalse(Guardian.IsGuardInvocation(new[] { "--guard" }));
            Assert.IsFalse(Guardian.IsGuardInvocation(null));
            Assert.IsTrue(Guardian.WasRestarted(new[] { "--restarted" }));
            Assert.IsFalse(Guardian.WasRestarted(new string[0]));
        }
    }
}
