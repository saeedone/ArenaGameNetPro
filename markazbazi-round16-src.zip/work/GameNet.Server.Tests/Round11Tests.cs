using System;
using NUnit.Framework;
using GameNet.Server.Core;

namespace GameNet.Server.Tests
{
    /// <summary>Round 11: the quick reservation of the monitoring right-click menu.</summary>
    [TestFixture]
    public class QuickReservationTests
    {
        [SetUp] public void Setup() { Database.Initialize("Data Source=:memory:"); }

        [Test]
        public void CreateQuick_WalkInCustomer_NoAccountNeeded()
        {
            var start = DateTime.Now.AddHours(1);
            int id = new ReservationManager().CreateQuick("علی", "PC-03", start, start.AddMinutes(60), "0912");
            Assert.Greater(id, 0);
            var list = new ReservationManager().GetUpcoming("PC-03");
            Assert.AreEqual(1, list.Count);
            Assert.AreEqual("علی", list[0].Name);
            Assert.AreEqual(start.ToString("HH:mm"), list[0].Start.ToString("HH:mm"));
        }

        [Test]
        public void CreateQuick_Overlap_IsRefused()
        {
            var m = new ReservationManager();
            var start = DateTime.Now.AddHours(2);
            m.CreateQuick("a", "PC-01", start, start.AddMinutes(60));
            Assert.Throws<InvalidOperationException>(() => m.CreateQuick("b", "PC-01", start.AddMinutes(30), start.AddMinutes(90)));
            // another PC at the same time is fine
            Assert.DoesNotThrow(() => m.CreateQuick("b", "PC-02", start.AddMinutes(30), start.AddMinutes(90)));
        }

        [Test]
        public void CreateQuick_PastOrEmpty_IsRefused()
        {
            var m = new ReservationManager();
            Assert.Throws<ArgumentException>(() => m.CreateQuick("a", "PC-01", DateTime.Now.AddHours(-3), DateTime.Now.AddHours(-2)));
            Assert.Throws<ArgumentException>(() => m.CreateQuick(" ", "PC-01", DateTime.Now.AddHours(1), DateTime.Now.AddHours(2)));
        }

        [Test]
        public void Cancel_RemovesFromUpcoming()
        {
            var m = new ReservationManager();
            var start = DateTime.Now.AddHours(1);
            int id = m.CreateQuick("a", "PC-05", start, start.AddMinutes(30));
            m.Cancel(id, "test");
            Assert.AreEqual(0, m.GetUpcoming("PC-05").Count);
        }
    }
}
