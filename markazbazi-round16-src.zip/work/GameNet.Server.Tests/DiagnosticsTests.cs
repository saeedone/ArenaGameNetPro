using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using GameNet.Shared.Diagnostics;
using NUnit.Framework;

namespace GameNet.Server.Tests
{
    /// <summary>
    /// Checks for the self-repair layer: the FMEA catalogue, failure classification,
    /// the retry policy, the diagnostics journal and the crash explanation kept for the
    /// next start. Every test writes to its own temporary folder.
    /// </summary>
    [TestFixture]
    public class DiagnosticsTests
    {
        private string _dir;

        [SetUp]
        public void SetUp()
        {
            FaultJournal.ResetForTests();
            _dir = Path.Combine(Path.GetTempPath(), "gamenet-diag-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_dir);
            FaultJournal.Initialize("Server", _dir);
        }

        [TearDown]
        public void TearDown()
        {
            FaultJournal.ResetForTests();
            try { if (Directory.Exists(_dir)) Directory.Delete(_dir, true); } catch { }
        }

        // ---- Retry policy (self-repair rule R1) ----

        [Test]
        public void Backoff_DoublesFromTheInitialDelay()
        {
            TimeSpan initial = TimeSpan.FromSeconds(1);
            TimeSpan max = TimeSpan.FromSeconds(30);
            Assert.AreEqual(TimeSpan.FromSeconds(1), RecoveryPolicy.Backoff(1, initial, max));
            Assert.AreEqual(TimeSpan.FromSeconds(2), RecoveryPolicy.Backoff(2, initial, max));
            Assert.AreEqual(TimeSpan.FromSeconds(4), RecoveryPolicy.Backoff(3, initial, max));
            Assert.AreEqual(TimeSpan.FromSeconds(16), RecoveryPolicy.Backoff(5, initial, max));
        }

        [Test]
        public void Backoff_NeverExceedsTheMaximum()
        {
            TimeSpan initial = TimeSpan.FromSeconds(1);
            TimeSpan max = TimeSpan.FromSeconds(30);
            Assert.AreEqual(max, RecoveryPolicy.Backoff(6, initial, max));    // 32 s, capped to 30 s
            Assert.AreEqual(max, RecoveryPolicy.Backoff(50, initial, max));   // the reconnect ceiling
        }

        [Test]
        public void Backoff_AttemptBelowOneIsTreatedAsOne()
        {
            TimeSpan initial = TimeSpan.FromSeconds(1);
            TimeSpan max = TimeSpan.FromSeconds(30);
            Assert.AreEqual(initial, RecoveryPolicy.Backoff(0, initial, max));
            Assert.AreEqual(initial, RecoveryPolicy.Backoff(-5, initial, max));
        }

        [Test]
        public void WithJitter_ZeroFractionKeepsTheDelay()
        {
            TimeSpan delay = TimeSpan.FromSeconds(10);
            Assert.AreEqual(delay, RecoveryPolicy.WithJitter(delay, 0));
        }

        [Test]
        public void WithJitter_RemovesAtMostTwentyPercent()
        {
            TimeSpan delay = TimeSpan.FromSeconds(10);
            for (int i = 0; i < 500; i++)
            {
                double ms = RecoveryPolicy.WithJitter(delay, 0.2).TotalMilliseconds;
                Assert.IsTrue(ms >= 7999 && ms <= 10000, "out of range: " + ms);
            }
        }

        [Test]
        public void WithJitter_FractionAboveNinetyPercentIsCapped()
        {
            TimeSpan delay = TimeSpan.FromSeconds(10);
            for (int i = 0; i < 200; i++)
            {
                double ms = RecoveryPolicy.WithJitter(delay, 5.0).TotalMilliseconds;
                Assert.IsTrue(ms >= 999 && ms <= 10000, "cap not applied: " + ms);
            }
        }

        // ---- Failure catalogue and classification ----

        [Test]
        public void Catalog_GetNeverReturnsNull()
        {
            Assert.IsNotNull(FaultCatalog.Get(null));
            Assert.IsNotNull(FaultCatalog.Get("NOPE-999"));
            Assert.AreEqual("UNKNOWN", FaultCatalog.Get(null).Code);
        }

        [Test]
        public void Catalog_UnknownCodeKeepsItsCodeWithGenericText()
        {
            FaultDefinition def = FaultCatalog.Get("NOPE-999");
            Assert.AreEqual("NOPE-999", def.Code);
            Assert.AreEqual(FaultSeverity.Error, def.Severity);
            Assert.IsFalse(string.IsNullOrEmpty(def.Title));
        }

        [Test]
        public void Catalog_LookupIgnoresCase()
        {
            Assert.AreEqual("NET-001", FaultCatalog.Get("net-001").Code);
        }

        [Test]
        public void Catalog_EveryEntryHasTextAndAKnownSeverity()
        {
            var severities = new HashSet<string>
            {
                FaultSeverity.Info, FaultSeverity.Warning, FaultSeverity.Error, FaultSeverity.Critical
            };
            foreach (FaultDefinition def in FaultCatalog.All())
            {
                Assert.IsFalse(string.IsNullOrEmpty(def.Code), "entry without a code");
                Assert.IsTrue(severities.Contains(def.Severity), def.Code + ": unknown severity " + def.Severity);
                Assert.IsFalse(string.IsNullOrEmpty(def.Title), def.Code + ": no title");
                Assert.IsFalse(string.IsNullOrEmpty(def.Cause), def.Code + ": no cause");
                Assert.IsFalse(string.IsNullOrEmpty(def.Action), def.Code + ": no action");
                Assert.GreaterOrEqual(def.ThrottleSeconds, 0, def.Code + ": negative throttle");
            }
        }

        [Test]
        public void Catalog_DefinesEveryCodeTheSoftwareRaises()
        {
            string generic = FaultCatalog.Get("NOPE-999").Title;
            string[] raised =
            {
                "NET-001", "NET-002", "NET-003", "NET-004", "NET-005", "NET-006", "NET-007", "NET-008",
                "NET-010", "NET-011", "NET-900",
                "SRV-001", "SRV-003", "SRV-004", "SRV-900",
                "TLS-001", "AUTH-001", "AUTH-002", "AUTH-003",
                "CFG-001", "CFG-002", "CFG-003", "DB-001", "DB-002",
                "APP-001", "APP-002", "APP-010", "APP-011", "APP-012", "APP-013", "APP-014", "APP-015",
                "HEAL-001", "HEAL-002", "HEAL-003", "HEAL-004", "HEAL-005", "HEAL-006",
                "HEAL-007", "NET-012", "NET-013",
            };
            foreach (string code in raised)
            {
                FaultDefinition def = FaultCatalog.Get(code);
                Assert.AreEqual(code, def.Code);
                Assert.AreNotEqual(generic, def.Title, code + " is missing from the catalogue");
            }
        }

        [Test]
        public void ClassifyTlsReason_MapsEachRealReasonToItsCode()
        {
            Assert.AreEqual("NET-002", FaultCatalog.ClassifyTlsReason(null));
            Assert.AreEqual("NET-002", FaultCatalog.ClassifyTlsReason(""));
            Assert.AreEqual("NET-002", FaultCatalog.ClassifyTlsReason("the server sent no certificate"));
            Assert.AreEqual("NET-002", FaultCatalog.ClassifyTlsReason("the server certificate could not be read (bad data)"));
            Assert.AreEqual("NET-003", FaultCatalog.ClassifyTlsReason("the server key does not match the pinned certificate (tls_pin)"));
            Assert.AreEqual("NET-004", FaultCatalog.ClassifyTlsReason("the server key changed since first contact (man-in-the-middle, or the server was replaced). If the server was replaced on purpose, delete server_pin.txt on this station."));
            Assert.AreEqual("NET-004", FaultCatalog.ClassifyTlsReason("server_pin.txt is damaged - delete it to pin the server again"));
            Assert.AreEqual("CFG-003", FaultCatalog.ClassifyTlsReason("server_pin.txt could not be read (access denied)"));
            Assert.AreEqual("CFG-003", FaultCatalog.ClassifyTlsReason("server_pin.txt could not be written, so the server key cannot be remembered"));
            Assert.AreEqual("CFG-003", FaultCatalog.ClassifyTlsReason("the pinned certificate could not be read (file not found)"));
        }

        [Test]
        public void ClassifyException_MapsCommonFailuresToCrashCodes()
        {
            Assert.AreEqual("APP-010", FaultCatalog.ClassifyException(new NullReferenceException(), false));
            Assert.AreEqual("APP-012", FaultCatalog.ClassifyException(new ObjectDisposedException("listener"), true));
            Assert.AreEqual("APP-014", FaultCatalog.ClassifyException(new SocketException(10061), true));
            Assert.AreEqual("APP-015", FaultCatalog.ClassifyException(new OutOfMemoryException(), false));
            Assert.AreEqual("APP-013", FaultCatalog.ClassifyException(new IOException("file in use"), false));
            Assert.AreEqual("APP-013", FaultCatalog.ClassifyException(new UnauthorizedAccessException(), false));
            Assert.AreEqual("APP-011", FaultCatalog.ClassifyException(
                new InvalidOperationException("Cross-thread operation not valid: control accessed from a thread other than the one it was created on."), false));
        }

        [Test]
        public void ClassifyException_GenericFailureDependsOnTheSide()
        {
            Assert.AreEqual("APP-001", FaultCatalog.ClassifyException(new Exception("boom"), false));
            Assert.AreEqual("APP-002", FaultCatalog.ClassifyException(new Exception("boom"), true));
            Assert.AreEqual("APP-002", FaultCatalog.ClassifyException(null, true)); // no exception object
        }

        // ---- Diagnostics journal (detect and explain) ----

        [Test]
        public void Raise_WritesToTheLogAndReadHistoryReturnsIt()
        {
            FaultRecord written = FaultJournal.Raise("AUTH-003", "station=PC-07");
            Assert.IsNotNull(written);
            Assert.IsTrue(File.Exists(Path.Combine(_dir, FaultJournal.LogFileName)));

            List<FaultRecord> history = FaultJournal.ReadHistory(50);
            Assert.AreEqual(1, history.Count);
            Assert.AreEqual("AUTH-003", history[0].Code);
            Assert.AreEqual("Server", history[0].Side);
            Assert.AreEqual(FaultSeverity.Error, history[0].Severity);
            StringAssert.Contains("PC-07", history[0].Detail);
            Assert.IsFalse(string.IsNullOrEmpty(history[0].Cause));
        }

        [Test]
        public void ReadHistory_ReturnsRecordsOldestFirstAndHonoursTheLimit()
        {
            for (int i = 0; i < 5; i++) FaultJournal.Raise("CFG-001", "n=" + i);
            List<FaultRecord> newestTwo = FaultJournal.ReadHistory(2);
            Assert.AreEqual(2, newestTwo.Count);
            StringAssert.Contains("n=3", newestTwo[0].Detail);
            StringAssert.Contains("n=4", newestTwo[1].Detail);
        }

        [Test]
        public void ReadHistory_IsEmptyWhenNothingWasRecorded()
        {
            Assert.AreEqual(0, FaultJournal.ReadHistory(50).Count);
        }

        [Test]
        public void Raise_SameCodeAndKeyInsideTheWindowIsSuppressed()
        {
            // NET-001 is throttled for 300 s per key.
            Assert.IsNotNull(FaultJournal.Raise("NET-001", "first", "10.0.0.5:9000"));
            Assert.IsNull(FaultJournal.Raise("NET-001", "again", "10.0.0.5:9000"));
            Assert.AreEqual(1, FaultJournal.ReadHistory(50).Count);
        }

        [Test]
        public void Raise_DifferentKeyIsNotSuppressed()
        {
            Assert.IsNotNull(FaultJournal.Raise("SRV-004", "a", "10.0.0.5"));
            Assert.IsNotNull(FaultJournal.Raise("SRV-004", "b", "10.0.0.6"));
        }

        [Test]
        public void Raise_CodeWithoutThrottleIsAlwaysWritten()
        {
            // CFG-001 has ThrottleSeconds = 0.
            Assert.IsNotNull(FaultJournal.Raise("CFG-001"));
            Assert.IsNotNull(FaultJournal.Raise("CFG-001"));
        }

        [Test]
        public void ResetForTests_ClearsTheThrottle()
        {
            Assert.IsNotNull(FaultJournal.Raise("NET-001"));
            Assert.IsNull(FaultJournal.Raise("NET-001"));
            FaultJournal.ResetForTests();
            Assert.IsNotNull(FaultJournal.Raise("NET-001"));
        }

        [Test]
        public void Raise_AcceptsMissingDetailAndUnknownCodes()
        {
            Assert.IsNotNull(FaultJournal.Raise("CFG-001", null));
            FaultRecord unknown = FaultJournal.Raise("NOPE-999", "detail");
            Assert.IsNotNull(unknown);
            Assert.AreEqual("NOPE-999", unknown.Code);
        }

        [Test]
        public void Raise_CapsTheDetailSoOneRecordCannotFillTheLog()
        {
            FaultRecord record = FaultJournal.Raise("CFG-001", new string('a', 5000));
            Assert.IsTrue(record.Detail.Length <= 2003);
        }

        [Test]
        public void FaultRaised_IsAnnouncedOnlyForWrittenRecords()
        {
            var seen = new List<string>();
            Action<FaultRecord> handler = r => seen.Add(r.Code);
            FaultJournal.FaultRaised += handler;
            try
            {
                FaultJournal.Raise("CFG-001");
                FaultJournal.Raise("NET-001", "first");
                FaultJournal.Raise("NET-001", "throttled"); // suppressed, so not announced
            }
            finally
            {
                FaultJournal.FaultRaised -= handler;
            }
            CollectionAssert.AreEqual(new[] { "CFG-001", "NET-001" }, seen);
        }

        [Test]
        public void Recent_HoldsOnlyThisRunsRecords()
        {
            FaultJournal.Raise("CFG-001");
            FaultJournal.ResetForTests();
            Assert.AreEqual(0, FaultJournal.Recent().Count);
            FaultJournal.Raise("SRV-900");
            Assert.AreEqual(1, FaultJournal.Recent().Count);
        }

        [Test]
        public void Log_RotatesToABackupFileWhenItGrowsPastOneMegabyte()
        {
            string filler = new string('x', 1500);
            for (int i = 0; i < 1000; i++) FaultJournal.Raise("CFG-001", filler + i);
            Assert.IsTrue(File.Exists(Path.Combine(_dir, FaultJournal.LogFileName + ".1")));
        }

        // ---- Explanation kept for the next start ----

        [Test]
        public void RecordCrash_IsExplainedOnceOnTheNextStart()
        {
            var ex = new NullReferenceException("object reference test");
            FaultRecord record = FaultJournal.RecordCrash(FaultCatalog.ClassifyException(ex, true), ex, "UI");
            Assert.IsNotNull(record);
            Assert.AreEqual("APP-010", record.Code);
            StringAssert.Contains("NullReferenceException", record.Detail);

            string explanation = FaultJournal.TakePendingReport();
            Assert.IsNotNull(explanation);
            StringAssert.Contains("APP-010", explanation);
            Assert.IsNull(FaultJournal.TakePendingReport(), "the explanation must be shown only once");
        }

        [Test]
        public void TakePendingReport_IsNullWhenNoCrashWasRecorded()
        {
            Assert.IsNull(FaultJournal.TakePendingReport());
        }
    }
}
