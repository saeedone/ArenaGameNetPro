namespace GameNet.Client
{
    partial class KioskForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        // Vertical sidebar menu
        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnNavHome, btnNavGames, btnNavSettings, btnNavLogout;
        private System.Windows.Forms.Button btnNavChat, btnNavAnnounce, btnNavLoyalty, btnNavProfile, btnNavStats;
        private System.Windows.Forms.Button btnNavTopup;
        // REAPPLY-KIOSK-CHANGES-1 (Part C): handyCafe-style "⚙️ تنظیمات" button.
        private System.Windows.Forms.Button btnNavOptions;
        private System.Windows.Forms.Button btnToggleSidebar;

        // Panels (one per nav item)
        private GradientPanel pnlLogin;
        private System.Windows.Forms.Panel pnlSession;

        // Login controls
        private GlowLabel lblTitle;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogin;
        // REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket removed — the handyCafe
        // sidebar no longer exposes a ticket button on the login panel.
        private System.Windows.Forms.Label lblStatus;

        // Session controls
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblLoyalty;
        private TimerDisplayControl timerDisplayControl;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnQuickTopup;
        private System.Windows.Forms.Button btnFood;
        private System.Windows.Forms.Button btnMusic;

        // News/announcement ticker at the bottom of the session panel
        private System.Windows.Forms.Panel pnlTicker;
        private System.Windows.Forms.Label lblTicker;

        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.btnNavHome = new System.Windows.Forms.Button();
            this.btnNavGames = new System.Windows.Forms.Button();
            // REAPPLY-KIOSK-CHANGES-1 (Part A): btnNavTicket removed.
            this.btnNavOptions = new System.Windows.Forms.Button();
            this.btnNavSettings = new System.Windows.Forms.Button();
            this.btnNavLogout = new System.Windows.Forms.Button();
            this.btnToggleSidebar = new System.Windows.Forms.Button();
            this.pnlLogin = new GradientPanel();
            this.pnlSession = new System.Windows.Forms.Panel();
            this.lblTitle = new GlowLabel();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            // BUG FIX (per report: "clicking Login does nothing at all"):
            // this was a RoundedButton (custom Region-based hit-area) —
            // switched to a completely plain, stock Button with no custom
            // subclass, no custom Region, no custom OnPaint at all. This
            // removes every possible custom-rendering source of the click
            // problem, at the cost of square corners instead of rounded.
            this.btnLogin = new System.Windows.Forms.Button();
            // REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket creation removed.
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblLoyalty = new System.Windows.Forms.Label();
            this.timerDisplayControl = new GameNet.Client.TimerDisplayControl();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnQuickTopup = new System.Windows.Forms.Button();
            this.btnFood = new System.Windows.Forms.Button();
            this.btnMusic = new System.Windows.Forms.Button();
            this.pnlTicker = new System.Windows.Forms.Panel();
            this.lblTicker = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // === Sidebar (vertical menu) ===
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Right; // RTL → right is "left" visually
            this.pnlSidebar.Width = 200;
            this.pnlSidebar.Padding = new System.Windows.Forms.Padding(10);

            this.btnToggleSidebar = new System.Windows.Forms.Button
            {
                Text = "☰ منو",
                Dock = System.Windows.Forms.DockStyle.Top,
                Height = 45,
                BackColor = System.Drawing.Color.FromArgb(220, 220, 225),
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(137, 180, 250),
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
            };

            this.btnNavHome = MkNavBtn("🏠 خانه", System.Drawing.Color.FromArgb(137, 180, 250));
            this.btnNavGames = MkNavBtn("+۱۰ دقیقه", System.Drawing.Color.FromArgb(166, 227, 161));
            this.btnNavChat = MkNavBtn("💬 چت", System.Drawing.Color.FromArgb(203, 166, 247));
            this.btnNavAnnounce = MkNavBtn("📢 اطلاعیه‌ها", System.Drawing.Color.FromArgb(249, 226, 175));
            this.btnNavLoyalty = MkNavBtn("🏆 امتیازات", System.Drawing.Color.FromArgb(250, 179, 135));
            this.btnNavProfile = MkNavBtn("👤 پروفایل", System.Drawing.Color.FromArgb(148, 226, 213));
            this.btnNavStats = MkNavBtn("📊 آمار", System.Drawing.Color.FromArgb(137, 180, 250));
            this.btnNavTopup = MkNavBtn("💳 شارژ سریع", System.Drawing.Color.FromArgb(166, 227, 161));
            // REAPPLY-KIOSK-CHANGES-1 (Part A): btnNavTicket removed.
            // REAPPLY-KIOSK-CHANGES-1 (Part C): new handyCafe-style ⚙️ Options button.
            this.btnNavOptions = MkNavBtn("⚙️ تنظیمات", System.Drawing.Color.FromArgb(148, 226, 213));
            // REAPPLY-KIOSK-CHANGES-1 (Part C): btnNavSettings is now the ⏻ خروج
            // (logout) button — the old "⚙️ تنظیمات" label is owned by
            // btnNavOptions above.
            this.btnNavSettings = MkNavBtn("⏻ خروج", System.Drawing.Color.FromArgb(243, 139, 168));

            // FIX H1: nav-button Click handlers are wired in KioskForm.cs
            // (SetupEngine). The previous ShowPanel(...) wiring here was a
            // duplicate that fought with the SwapToPanel handlers — clicking
            // "Home" showed the login screen without logging out, and clicking
            // "Games" after visiting another panel showed an empty session
            // panel. Only btnNavLogout is wired here (it has no KioskForm.cs
            // counterpart and is a simple "logout" action).
            this.btnNavLogout.Click += new System.EventHandler(this.btnLogout_Click);

            int navY = 55;
            this.btnNavHome.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavGames.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavChat.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavAnnounce.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavLoyalty.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavProfile.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavStats.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavTopup.Location = new System.Drawing.Point(10, navY); navY += 50;
            // REAPPLY-KIOSK-CHANGES-1 (Part C): btnNavOptions placed where
            // btnNavTicket used to sit.
            this.btnNavOptions.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavSettings.Location = new System.Drawing.Point(10, navY); navY += 50;
            this.btnNavLogout.Location = new System.Drawing.Point(10, navY + 30);

            this.pnlSidebar.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnToggleSidebar, this.btnNavHome, this.btnNavGames, this.btnNavChat,
                this.btnNavAnnounce, this.btnNavLoyalty, this.btnNavProfile, this.btnNavStats,
                this.btnNavTopup, this.btnNavOptions, this.btnNavSettings, this.btnNavLogout
            });

            // === Login panel ===
            // Beautiful gradient background (dark → accent blue) — task 1.
            // DARK TURQUOISE THEME: the login screen was a flat light-grey
            // (240,240,240) background with light-grey input boxes and dark
            // text. Changed to a dark teal/turquoise gradient per request —
            // deep teal at the top fading to near-black at the bottom, with
            // turquoise accents on the title, inputs and button below.
            this.pnlLogin.ColorTop = System.Drawing.Color.FromArgb(13, 42, 50);
            this.pnlLogin.ColorBottom = System.Drawing.Color.FromArgb(8, 22, 28);
            this.pnlLogin.GradientAngle = 90F;
            this.pnlLogin.Dock = System.Windows.Forms.DockStyle.Fill;

            // Title: 36pt bold with glow (drawn by GlowLabel) — task 1.
            this.lblTitle.Text = "🎮 markazbazi";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold);
            // DARK TURQUOISE THEME: bright turquoise title with a deep teal glow.
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(64, 224, 208);
            this.lblTitle.GlowColor = System.Drawing.Color.FromArgb(0, 90, 100);
            this.lblTitle.GlowOffset = 4;
            this.lblTitle.AutoSize = false;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Size = new System.Drawing.Size(500, 70);

            // Subtitle: 14pt accent color — task 1.
            this.lblSubtitle = new System.Windows.Forms.Label
            {
                Text = "مرکز بازی",
                Font = new System.Drawing.Font("Segoe UI", 14F),
                // DARK TURQUOISE THEME: soft aqua subtitle.
                ForeColor = System.Drawing.Color.FromArgb(126, 200, 197),
                AutoSize = false,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Size = new System.Drawing.Size(400, 30),
                BackColor = System.Drawing.Color.Transparent,
            };

            this.txtUsername = new System.Windows.Forms.TextBox
            {
                Size = new System.Drawing.Size(400, 45),
                Font = new System.Drawing.Font("Segoe UI", 16F),
                // DARK TURQUOISE THEME: dark teal input with light aqua text.
                BackColor = System.Drawing.Color.FromArgb(22, 58, 66),
                ForeColor = System.Drawing.Color.FromArgb(205, 240, 238),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                Visible = true,
            };
            SetPlaceholder(txtUsername, "نام کاربری");

            this.txtPassword = new System.Windows.Forms.TextBox
            {
                Size = new System.Drawing.Size(400, 45),
                Font = new System.Drawing.Font("Segoe UI", 16F),
                // SECURITY: UseSystemPasswordChar marks the underlying Win32
                // edit control as a password field (ES_PASSWORD), which is
                // stronger than PasswordChar — the latter only changes how
                // the text is painted, leaving the real value readable by
                // other processes via WM_GETTEXT.
                UseSystemPasswordChar = true,
                BackColor = System.Drawing.Color.FromArgb(22, 58, 66),
                ForeColor = System.Drawing.Color.FromArgb(205, 240, 238),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                Visible = true,
            };
            SetPlaceholder(txtPassword, "رمز عبور");

            // Rounded login button — task 1.
            this.btnLogin.Text = "▶️ ورود";
            this.btnLogin.Size = new System.Drawing.Size(400, 55);
            // DARK TURQUOISE THEME: turquoise button with dark text for contrast.
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(38, 166, 154);
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.FromArgb(8, 30, 34);
            // CornerRadius removed along with RoundedButton — see the note
            // above where btnLogin is constructed.
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);

            // REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket + Click handler
            // wiring removed — the login panel no longer shows the
            // "🎫 استفاده از کد تیکت" button. The handyCafe sidebar's
            // "➕ اعتبار" button covers the same quick-credit UX.
            this.lblStatus = new System.Windows.Forms.Label
            {
                Font = new System.Drawing.Font("Segoe UI", 11F),
                ForeColor = System.Drawing.Color.FromArgb(166, 227, 161),
                AutoSize = false,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Size = new System.Drawing.Size(400, 24),
                Text = "🟢 در حال اتصال...",
                BackColor = System.Drawing.Color.Transparent,
            };

            // REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket removed from the
            // login panel's Controls.AddRange.
            this.pnlLogin.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblTitle, this.lblSubtitle, this.txtUsername, this.txtPassword,
                this.btnLogin, this.lblStatus
            });

            // === Session panel ===
            this.pnlSession.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.pnlSession.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSession.Visible = false;
            // FIX LEFT-MENU-REMOVE: all the old session controls (lblWelcome,
            // lblBalance, lblLoyalty, timerDisplayControl, btnQuickTopup,
            // btnFood, btnMusic, pnlTicker) are NOT added to
            // pnlSession. Only the right-column buttons remain. The left/middle
            // area is empty — the user clicks "🖥️ دسکتاپ" to see the desktop.

            this.pnlSession.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnNavHome, this.btnNavGames, this.btnNavChat,
                this.btnNavAnnounce, this.btnNavLoyalty, this.btnNavProfile,
                this.btnNavStats, this.btnNavTopup, this.btnNavOptions,
                this.btnNavSettings, this.btnLogout,
                // FIX CLEAN-UI: removed timerDisplayControl,
                // lblWelcome, lblBalance, lblLoyalty, btnQuickTopup, btnFood,
                // btnMusic, pnlTicker — everything moved to the right column.
                // The session panel is now EMPTY except for the right-column
                // buttons, so the desktop is visible through the kiosk.
                // (The kiosk itself gets minimized when the user clicks
                // "🖥️ دسکتاپ" so they can launch games from the desktop.)
            });

            // === Main form ===
            // Z-order: LAST added = FRONT. We want pnlLogin on top at startup
            // (it's the first thing the user sees). pnlSession is behind it
            // (hidden until login). ShowLoginPanel sets pnlLogin.Visible=true
            // and hides pnlSession.
            //
            // FIX SIDEBAR-REMOVE: pnlSidebar is no longer added to Controls.
            // The navigation buttons are now integrated into pnlSession as a
            // compact horizontal bar at the top (see LayoutSessionControls
            // in KioskForm.cs). This removes the separate right-side menu
            // that was "attached to" the info panel and confusing the user.
            this.ClientSize = new System.Drawing.Size(1280, 800);
            this.Controls.Add(this.pnlSession);   // back (hidden)
            this.Controls.Add(this.pnlLogin);     // FRONT (visible by default)
            this.Name = "KioskForm";
            this.Text = "GameNet Client";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button MkNavBtn(string text, System.Drawing.Color bg)
        {
            return new System.Windows.Forms.Button
            {
                Text = text,
                Size = new System.Drawing.Size(170, 42),
                BackColor = bg,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(240, 240, 240),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                Padding = new System.Windows.Forms.Padding(10, 0, 15, 0),
            };
        }

        private void SetPlaceholder(System.Windows.Forms.TextBox tb, string placeholder)
        {
            // DARK TURQUOISE THEME: the placeholder grey (128,128,128) and
            // the "real text" colour (40,40,40 — near-black) were both
            // chosen for the old light background; on the new dark teal
            // fields the near-black typed text would have been effectively
            // invisible. Both are now light aqua tones sized for contrast
            // against the dark input background.
            bool isPasswordField = tb.UseSystemPasswordChar;
            tb.UseSystemPasswordChar = false; // keep the hint readable
            tb.Text = placeholder;
            tb.ForeColor = System.Drawing.Color.FromArgb(110, 150, 152);
            tb.Tag = placeholder; // store placeholder for comparison
            tb.GotFocus += (s, e) => { if (tb.Text == (string)tb.Tag) { tb.Text = ""; tb.ForeColor = System.Drawing.Color.FromArgb(205, 240, 238); tb.UseSystemPasswordChar = isPasswordField; } };
            tb.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(tb.Text)) { tb.UseSystemPasswordChar = false; tb.Text = (string)tb.Tag; tb.ForeColor = System.Drawing.Color.FromArgb(110, 150, 152); } };
        }

        /// <summary>Returns true if the textbox still shows the placeholder text.</summary>
        public static bool IsPlaceholder(System.Windows.Forms.TextBox tb)
        {
            return tb.Text == (string)tb.Tag;
        }

        /// <summary>
        /// BUG FIX ("login only worked once"): ShowLoginPanel never cleared
        /// the username/password boxes when returning to the login screen
        /// after a logout. The previous user's text stayed in the fields,
        /// and — critically — the password box kept its real typed value
        /// while the placeholder/ForeColor state no longer matched it. On
        /// the next login attempt the stale text was submitted (or the
        /// IsPlaceholder guards misfired), so the second and subsequent
        /// logins failed while the first one worked. This resets both boxes
        /// to a clean placeholder state, exactly as they are at startup.
        /// </summary>
        public void ResetLoginFields()
        {
            try
            {
                foreach (var tb in new[] { txtUsername, txtPassword })
                {
                    if (tb == null || tb.IsDisposed) continue;
                    // Assigning Text directly (rather than relying on the
                    // GotFocus/LostFocus handlers) guarantees a clean state
                    // regardless of which control currently has focus.
                    // UseSystemPasswordChar is turned off so the placeholder
                    // hint stays readable, matching SetPlaceholder's behavior.
                    tb.UseSystemPasswordChar = false;
                    tb.Text = (string)tb.Tag ?? "";
                    tb.ForeColor = System.Drawing.Color.FromArgb(110, 150, 152);
                }
            }
            catch { }
        }
    }
}
