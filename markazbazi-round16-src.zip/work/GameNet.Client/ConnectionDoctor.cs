using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;
using GameNet.Shared.Diagnostics;
using GameNet.Shared.SelfHeal;

namespace GameNet.Client
{
    /// <summary>
    /// Round 15: "🩺 تست اتصال به سرور" in the kiosk's admin column. Checks, step by
    /// step, everything between this kiosk and the server and says in plain Persian
    /// which step fails and what to do: address, network, TCP port, TLS on both sides,
    /// the remembered server key (server_pin.txt), the "internet off" rule, and the
    /// last connection problems the kiosk recorded. It only reads and probes; it changes
    /// nothing (the TLS probe accepts any certificate only to look at it).
    /// </summary>
    internal static class ConnectionDoctor
    {
        public static string Run(string host, int port, bool useTls, string kioskStatus)
        {
            var sb = new StringBuilder();
            Action<string, string> line = (icon, text) => sb.Append(icon).Append("  ").Append(text).Append("\r\n");
            line("ℹ️", "سرور در تنظیمات این کیوسک: " + host + " : " + port + "   ·   TLS: " + (useTls ? "روشن" : "خاموش"));
            line("ℹ️", "وضعیت فعلی کیوسک: " + (string.IsNullOrWhiteSpace(kioskStatus) ? "—" : kioskStatus.Replace("\n", " ")));

            // 1. address
            if (string.IsNullOrWhiteSpace(host) || host == "127.0.0.1" || host.Equals("localhost", StringComparison.OrdinalIgnoreCase))
                line("⚠️", "آدرس سرور «خود همین سیستم» است. اگر سرور روی سیستم دیگری است، IP آن را در «⚙️ تنظیمات کلاینت › General» بنویسید (IP سرور در تب «🩺 عیب‌یابی اتصال» سرور نوشته شده).");
            IPAddress target = null;
            try
            {
                foreach (var a in Dns.GetHostAddresses(host))
                    if (a.AddressFamily == AddressFamily.InterNetwork) { target = a; break; }
                if (target == null) line("❌", "نام «" + host + "» به هیچ آدرس IPv4 تبدیل نشد. به‌جای نام، IP سرور را بنویسید.");
            }
            catch (Exception ex) { line("❌", "آدرس سرور پیدا نشد: " + ex.Message); }

            // 2. same network?
            try
            {
                var mine = new List<string>();
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address))
                            mine.Add(ua.Address.ToString());
                }
                line("ℹ️", "آدرس‌های این کیوسک: " + (mine.Count == 0 ? "هیچ (کابل یا وای‌فای وصل نیست؟)" : string.Join("، ", mine)));
                if (target != null && mine.Count > 0)
                {
                    string t3 = string.Join(".", target.ToString().Split('.'), 0, 3);
                    bool same = mine.Exists(m => m.StartsWith(t3 + ".", StringComparison.Ordinal));
                    if (!same && !IPAddress.IsLoopback(target))
                        line("⚠️", "سرور (" + target + ") در شبکهٔ دیگری است (سه بخش اول IP یکی نیست). اگر همه در یک مغازه‌اند، IP سرور احتمالاً اشتباه است یا عوض شده.");
                }
            }
            catch { }

            // 3. the kiosk's own "internet off" rule
            try
            {
                if (FirewallHelper.RuleExists(FirewallHelper.KioskBlockRule))
                    line("ℹ️", "اینترنت این کیوسک با «نت قطع» بسته است (نسخهٔ تازه فقط اینترنت را می‌بندد؛ شبکهٔ داخلی و سرور باز است).");
            }
            catch { }

            // 4. TCP, and 5. TLS on the same connection. One connection only, so the test
            // itself does not leave a false "handshake failed" line in the server's list.
            if (target != null)
            {
                var sw = Stopwatch.StartNew();
                using (var tcp = new TcpClient(AddressFamily.InterNetwork))
                {
                    bool tcpOk = false;
                    try
                    {
                        var ar = tcp.BeginConnect(target, port, null, null);
                        if (!ar.AsyncWaitHandle.WaitOne(4000))
                            line("❌", "سرور در ۴ ثانیه جواب نداد. یعنی یکی از این‌ها: (۱) فایروال ویندوز روی سیستم سرور — روی سرور تب «🩺 عیب‌یابی اتصال» › «درست کردن فایروال»؛ (۲) IP سرور اشتباه یا عوض شده؛ (۳) سیستم سرور خاموش یا در شبکهٔ دیگر.");
                        else
                        {
                            tcp.EndConnect(ar);
                            tcpOk = true;
                            line("✅", "اتصال به پورت " + port + " سرور برقرار شد (" + sw.ElapsedMilliseconds + " میلی‌ثانیه).");
                        }
                    }
                    catch (SocketException se)
                    {
                        if (se.SocketErrorCode == SocketError.ConnectionRefused)
                            line("❌", "سیستم سرور در دسترس است ولی روی پورت " + port + " کسی گوش نمی‌دهد: برنامهٔ سرور بسته است، هنوز از صفحهٔ ورود اپراتور رد نشده، یا پورت در «Options › Advanced» سرور عدد دیگری است.");
                        else if (se.SocketErrorCode == SocketError.HostUnreachable || se.SocketErrorCode == SocketError.NetworkUnreachable)
                            line("❌", "شبکه به سرور راه ندارد (کابل، وای‌فای، یا IP در شبکهٔ دیگر): " + se.SocketErrorCode);
                        else
                            line("❌", "اتصال به سرور نشد: " + se.SocketErrorCode + " — " + se.Message);
                    }
                    catch (Exception ex) { line("❌", "اتصال به سرور نشد: " + ex.Message); }

                    if (tcpOk && useTls)
                    {
                        X509Certificate2 seen = null;
                        bool tlsOk = false; string tlsErr = null;
                        try
                        {
                            tcp.ReceiveTimeout = 5000; tcp.SendTimeout = 5000;
                            using (var ssl = new SslStream(tcp.GetStream(), true, (s, cert, chain, err) =>
                            {
                                try { if (cert != null) seen = new X509Certificate2(cert); } catch { }
                                return true; // probe only: we look at the key, we do not trust it
                            }))
                            {
                                ssl.AuthenticateAsClient(host, null, SslProtocols.Tls12, false);
                                tlsOk = true;
                            }
                        }
                        catch (Exception ex) { tlsErr = ex.GetType().Name + ": " + ex.Message; }

                        if (!tlsOk)
                            line("❌", "سرور اتصال را پذیرفت ولی TLS جواب نداد (" + tlsErr + "). یا TLS سرور خاموش است و TLS این کیوسک روشن (هر دو باید یکی باشند)، یا سرور گواهی ندارد (وقتی سرور از پوشهٔ دیگری باز شود، server.pfx را پیدا نمی‌کند و همهٔ کیوسک‌ها را رد می‌کند). تب «🩺 عیب‌یابی اتصال» سرور را ببینید.");
                        else
                        {
                            line("✅", "TLS در هر دو طرف روشن است.");
                            try
                            {
                                string fp = seen != null ? NetworkClient.ComputePublicKeySha256(seen) : null;
                                string pin = null;
                                try { pin = ConnectionSettings.ReadServerPin(); } catch (Exception ex) { line("❌", "فایل server_pin.txt خوانده نشد: " + ex.Message); }
                                if (fp == null) line("⚠️", "گواهی سرور خوانده نشد.");
                                else if (string.IsNullOrEmpty(pin)) line("✅", "این کیوسک هنوز کلید سرور را ذخیره نکرده؛ در اولین اتصال ذخیره می‌کند.");
                                else if (string.Equals(pin.Trim(), fp, StringComparison.OrdinalIgnoreCase)) line("✅", "کلید سرور همان کلیدی است که این کیوسک ذخیره کرده.");
                                else
                                    line("❌", "کلید امنیتی سرور عوض شده، پس کیوسک برای امنیت وصل نمی‌شود. معمولاً یعنی سرور دوباره نصب شده، یا از پوشهٔ دیگری (مثلاً با اجرای خودکار ویندوز) باز شده و گواهی تازه ساخته (تب «🩺 عیب‌یابی اتصال» سرور، خط «گواهی»). اگر سرور را خودتان عوض کرده‌اید، فایل server_pin.txt را روی این کیوسک پاک کنید تا کلید تازه ذخیره شود.");
                            }
                            catch { }
                        }
                    }
                    else if (tcpOk)
                    {
                        // Kiosk TLS off: a plain heartbeat. A server with TLS off answers it; a
                        // server with TLS on closes the connection (it expected a TLS hello).
                        try
                        {
                            var ns = tcp.GetStream();
                            ns.ReadTimeout = 3000;
                            GameNet.Shared.Protocol.WriteMessage(ns, new GameNet.Shared.NetMessage(GameNet.Shared.MessageType.ClientHeartbeat, new GameNet.Shared.ClientStatusPayload()));
                            var reply = GameNet.Shared.Protocol.ReadMessage(ns);
                            line("✅", "سرور بدون TLS است، مثل این کیوسک (پاسخ: " + reply.Type + ").");
                        }
                        catch (IOException io) when ((io.InnerException as SocketException)?.SocketErrorCode == SocketError.TimedOut)
                        {
                            line("⚠️", "سرور در ۳ ثانیه به پیام آزمایشی جواب نداد (شاید سرور خیلی شلوغ است یا این سیستم به‌خاطر پیام زیاد موقتاً نادیده گرفته می‌شود).");
                        }
                        catch (IOException)
                        {
                            line("❌", "سرور اتصال بدون TLS را بست: TLS سرور روشن است ولی TLS این کیوسک خاموش. در تنظیمات اتصال کیوسک TLS را روشن کنید (یا در سرور خاموش کنید؛ هر دو باید یکی باشند).");
                        }
                        catch (Exception ex) { line("⚠️", "پاسخ سرور خوانده نشد: " + ex.Message); }
                    }
                }
            }

            // 6. what the kiosk itself recorded lately
            try
            {
                var recent = FaultJournal.Recent();
                int shown = 0;
                for (int i = recent.Count - 1; i >= 0 && shown < 6; i--)
                {
                    var r = recent[i];
                    if (r.Code == null) continue;
                    if (!(r.Code.StartsWith("NET") || r.Code.StartsWith("TLS") || r.Code.StartsWith("AUTH") || r.Code.StartsWith("CFG"))) continue;
                    if (shown == 0) line("ℹ️", "آخرین مشکلات اتصالی که کیوسک ثبت کرده:");
                    line("   •", r.TimeUtc.ToLocalTime().ToString("HH:mm:ss") + "  " + r.Code + "  " + r.Title + (string.IsNullOrEmpty(r.Detail) ? "" : " — " + Shorten(r.Detail, 160)));
                    shown++;
                }
            }
            catch { }

            line("ℹ️", "اگر همهٔ خط‌ها ✅ است ولی کیوسک در سرور دیده نمی‌شود: در سرور تب «🩺 عیب‌یابی اتصال» را ببینید (رمز اتصال کیوسک، مسدود شدن به‌خاطر پیام زیاد، اتصال‌های ردشده).");
            return sb.ToString();
        }

        private static string Shorten(string s, int n) { s = s ?? ""; return s.Length > n ? s.Substring(0, n) + "…" : s; }

        /// <summary>The result window (text can be copied and sent to support).</summary>
        public static Form MakeDialog(string text)
        {
            var f = new Form
            {
                Text = "🩺 تست اتصال به سرور",
                StartPosition = FormStartPosition.CenterScreen,
                Size = new Size(820, 560),
                RightToLeft = RightToLeft.Yes,
                RightToLeftLayout = true,
                BackColor = Color.White,
                TopMost = true,
                ShowInTaskbar = false,
            };
            var box = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10.5F), Text = text, BackColor = Color.White, RightToLeft = RightToLeft.Yes };
            var bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8, 6, 8, 6) };
            var btnCopy = new Button { Text = "📋 کپی", Width = 110, Height = 30 };
            var btnClose = new Button { Text = "بستن", Width = 110, Height = 30, DialogResult = DialogResult.OK };
            btnCopy.Click += (s, e) => { try { Clipboard.SetText(text); } catch { } };
            bar.Controls.AddRange(new Control[] { btnClose, btnCopy });
            f.Controls.Add(box); f.Controls.Add(bar);
            f.AcceptButton = btnClose;
            return f;
        }
    }
}
