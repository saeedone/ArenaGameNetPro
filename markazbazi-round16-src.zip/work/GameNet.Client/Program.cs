﻿using System;
using System.Threading;
using System.Windows.Forms;
using GameNet.Shared.Diagnostics;

namespace GameNet.Client
{
    internal static class Program
    {
        private static int _restored; // 0 = not yet restored, 1 = restored (Interlocked)
        private static readonly System.Collections.Generic.List<DateTime> _uiErrors = new System.Collections.Generic.List<DateTime>(); // round 12

        [STAThread]
        static void Main(string[] args)
        {
            // Round 12 self-repair: "GameNet.Client.exe --guard <pid>" is the kiosk's guard
            // (no window). It restarts the kiosk after a crash or hang. It runs before
            // everything else and does not open the diagnostics journal (one writer only).
            if (GameNet.Shared.SelfHeal.Guardian.IsGuardInvocation(args))
            {
                Environment.ExitCode = GameNet.Shared.SelfHeal.Guardian.RunGuard(args, new GameNet.Shared.SelfHeal.GuardOptions
                {
                    Key = "Client",
                    HangSeconds = 45,
                    ConfigFiles = () =>
                    {
                        var files = new System.Collections.Generic.List<string>(ConnectionSettings.AllSettingsFiles());
                        files.Add(ClientOptions.GetFilePath());
                        return files.ToArray();
                    },
                });
                return;
            }

            // Self-repair: the diagnostics journal starts first, so every later step can
            // record what it did. The log goes next to the exe, or to %APPDATA%\GameNet
            // when that folder is read-only.
            FaultJournal.Initialize("Client", AppDomain.CurrentDomain.BaseDirectory);

            // Self-repair: "GameNet.Client.exe --diagnose" opens the read-only fault viewer
            // without starting the kiosk (for the operator and for support).
            if (args != null && args.Length > 0 && string.Equals(args[0], "--diagnose", StringComparison.OrdinalIgnoreCase))
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new DiagnosticsViewer());
                return;
            }

            // FIX FEATURE-2: "بازگرداندن به حالت اولیه" for the client.
            // Run as: GameNet.Client.exe --repair (e.g. from a "Repair
            // Client" shortcut an operator creates). Deliberately checked
            // before anything else starts (mutex, hooks, network) so it
            // works even if a previous run left something in a bad state.
            // Round 12: "--uninstall" removes the automatic start (scheduled task, Run key);
            // the kiosk no longer removes it on every exit (P11).
            if (args != null && args.Length > 0 && string.Equals(args[0], "--uninstall", StringComparison.OrdinalIgnoreCase))
            {
                try { AutoStartup.Uninstall(); } catch { }
                try { MessageBox.Show("اجرای خودکار کلاینت حذف شد.", "GameNet", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch { }
                return;
            }

            if (args != null && args.Length > 0 && string.Equals(args[0], "--repair", StringComparison.OrdinalIgnoreCase))
            {
                ClientRepair.ResetToDefaults();
                MessageBox.Show(
                    "تنظیمات محلی کلاینت به حالت پیش‌فرض بازگردانده شد.\nحالا برنامه را به‌صورت عادی اجرا کنید.",
                    "بازنشانی انجام شد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // FIX-MONITOR-ADD5 TASK B1: Global exception handlers + crash
            // logger (client side). Logs to client_crash_log.txt next to the
            // client exe. Same pattern as the server's Program.cs but with
            // a distinct filename so server-side crash logs and client-side
            // crash logs are easy to tell apart when an operator ships both
            // log files to support. Added at the very top of Main so the
            // handlers are attached before anything else can throw.
            AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
            {
                try {
                    var ex = e.ExceptionObject as Exception;
                    System.IO.File.AppendAllText(
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_crash_log.txt"),
                        DateTime.Now.ToString("o") + " | FATAL | " + ex?.ToString() + "\n" + new string('=', 80) + "\n");
                } catch { }
            };

            Application.ThreadException += (sender, e) =>
            {
                try {
                    System.IO.File.AppendAllText(
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_crash_log.txt"),
                        DateTime.Now.ToString("o") + " | UI | " + e.Exception?.ToString() + "\n" + new string('=', 80) + "\n");
                } catch { }
            };

            // FIX B8: single-instance guard. The kiosk runs in full-screen
            // locked-down mode (SecurityLock disables Task Manager, hides
            // the taskbar, hooks the keyboard). If a second instance starts
            // while the first is still running, both will fight over the
            // keyboard hook + the auto-startup registry key + the server
            // connection, and the operator's screen will flicker between
            // two kiosk windows. The mutex prevents the second instance
            // from starting at all.
            bool createdNew;
            using (var mutex = new Mutex(true, "Global\\GameNet-Client-Singleton", out createdNew))
            {
                if (!createdNew)
                {
                    // Round 12: on purpose, so a guard does not keep starting a second copy.
                    try { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Client"); } catch { }
                    try { MessageBox.Show("کلاینت GameNet از قبل در حال اجراست.", "GameNet", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch { }
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                // Round 11: the 3D program icon on every window.
                GameNet.Shared.AppIcon.InstallAsDefault("client.ico");

                // Round 11: the start-up splash (a fixed 2-second wait, nothing loaded
                // meanwhile) was removed at the user's request.

                // H6: Global exception handlers. Any unhandled exception — whether on
                // the UI thread (Application.ThreadException) or on a threadpool /
                // background thread (AppDomain.CurrentDomain.UnhandledException) — must
                // restore the system (re-enable Task Manager, show the taskbar, unhook
                // the keyboard hook, delete the autostart key) before the process dies.
                // Without this, an unhandled exception on a threadpool thread (e.g. from
                // a ClientEngine send call) leaves the kiosk machine locked forever.
                // Round 12: an error on the UI thread no longer unlocks the PC. Before, the
                // first such error restored Task Manager and the taskbar while the kiosk kept
                // running, and a message box waited for a click. Now it is recorded and the
                // kiosk carries on; three within a minute end the kiosk, and the guard opens
                // it again, clean, 2 seconds later.
                Application.ThreadException += (s, e) =>
                {
                    try { CrashReporter.Report(e.Exception, "ThreadException"); } catch { }
                    var now = DateTime.UtcNow;
                    lock (_uiErrors)
                    {
                        _uiErrors.Add(now);
                        _uiErrors.RemoveAll(t => (now - t).TotalSeconds > 60);
                        if (_uiErrors.Count < 3) return;
                    }
                    try { RestoreSystemOnce(); } catch { }
                    Environment.Exit(3);
                };
                // The process ends after this handler. No message box any more: on an
                // unattended kiosk it kept the dying process open until someone clicked it,
                // so the guard could not start a new kiosk.
                AppDomain.CurrentDomain.UnhandledException += (s, e) =>
                {
                    try { CrashReporter.Report(e.ExceptionObject as Exception, "UnhandledException"); } catch { }
                    try { RestoreSystemOnce(); } catch { }
                };

                try
                {
                    // Phase — Start the anti-debug watchdog before anything
                    // else so a debugger attached during startup is caught.
                    // FIX 5: skip the watchdog entirely in DEBUG builds — it
                    // fires false-positives whenever the developer attaches a
                    // debugger (which is the normal dev workflow) and bricks
                    // the kiosk by Environment.Exit(13).
#if !DEBUG
                    ClientIntegrity.StartAntiDebugWatchdog();
#endif
                    // FIX L1: removed the unused `string selfHash = ...` local.
                    // ComputeSelfHash is now called (and its result actually
                    // sent) inside ClientEngine.TryConnect when building the
                    // ClientHelloPayload (see the SelfHash field added in the
                    // H1 fix). Computing it here was dead code that only
                    // populated the cache early — harmless but produced a
                    // compiler warning and confused readers.

                    // FIX M11: clean up the previous self-update backup. The
                    // self-update batch (HandleUpdateChunk) renames the old
                    // GameNet.Client.exe to GameNet.Client.exe.old, copies the
                    // new exe in, then deletes the .old — but the delete step
                    // runs in the batch AFTER this process exits, so if the
                    // batch is interrupted (power loss, hard reset) the .old
                    // file is left behind forever. Delete it on every startup
                    // so the kiosk's directory doesn't accumulate stale exes
                    // (which also confuses the integrity self-hash check).
                    try
                    {
                        string oldBackup = System.IO.Path.Combine(
                            AppDomain.CurrentDomain.BaseDirectory,
                            "GameNet.Client.exe.old");
                        if (System.IO.File.Exists(oldBackup))
                        {
                            System.IO.File.Delete(oldBackup);
                        }
                    }
                    catch { /* best-effort — don't block startup */ }

                    // Install auto-startup so the kiosk relaunches after reboot
                    // or crash. Safe to call on every run.
                    try { AutoStartup.Install(); } catch { }

                    // ADD-CLIENT-25 — Task 21: load settings BEFORE deciding
                    // whether to show the splash. The splash used to be shown
                    // unconditionally at the top of Main, which delayed the
                    // kiosk's UI by ~2s on every launch even when the server
                    // was already reachable. Now we only show the splash if
                    // (a) the server is unreachable AND (b) the user isn't in
                    // low-perf mode (low-perf skips the splash entirely).
                    // Load saved server settings (or use defaults = localhost).
                    ConnectionSettings.Load();

                    // If no settings file exists yet (first launch), OR the saved
                    // server is 127.0.0.1 and a quick test shows nothing is
                    // listening there, prompt the user for the server IP. This
                    // fixes the "client can't connect" issue when the server is on
                    // a different machine and the user never set the IP.
                    bool needPrompt = false;
                    bool serverUnreachable = false; // round 16
                    string exeSettings = System.IO.Path.Combine(
                        AppDomain.CurrentDomain.BaseDirectory, "server_settings.txt");
                    string appDataSettings = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "GameNet", "server_settings.txt");
                    if (!System.IO.File.Exists(exeSettings) && !System.IO.File.Exists(appDataSettings))
                    {
                        needPrompt = true;
                    }
                    else
                    {
                        // Settings exist — test if the server is reachable. If not,
                        // prompt the user to re-enter the IP.
                        try
                        {
                            using (var tcp = new System.Net.Sockets.TcpClient())
                            {
                                var ar = tcp.BeginConnect(ConnectionSettings.ServerHost, ConnectionSettings.ServerPort, null, null);
                                // FIX M13: explicitly close the WaitHandle so the
                                // underlying OS handle is released immediately,
                                // rather than waiting for GC finalization. Was
                                // leaking one WaitHandle per timed-out connect
                                // attempt on every kiosk startup.
                                // Round 16: a saved server that does not answer is NOT a reason
                                // to stop at the address window. After a power cut the kiosks
                                // start before the server, and every kiosk waited at that window
                                // for someone to click — none of them ever connected. The kiosk
                                // now starts and keeps retrying in the background; the LAN
                                // search below still runs if Auto is on.
                                if (!ar.AsyncWaitHandle.WaitOne(2000))
                                {
                                    serverUnreachable = true;
                                    try { ar.AsyncWaitHandle.Close(); } catch { }
                                }
                                else
                                {
                                    try { tcp.EndConnect(ar); } catch { serverUnreachable = true; }
                                    try { ar.AsyncWaitHandle.Close(); } catch { }
                                }
                            }
                        }
                        catch { serverUnreachable = true; }
                    }

                    // Round 10: the Options dialog's "Auto (Server Discovery)" switch decides
                    // whether the LAN is searched before the address is asked for.
                    try { ClientOptions.Load(); } catch { }
                    if ((needPrompt || serverUnreachable) && ClientOptions.AutoDiscovery)
                    {
                        // NEW FEATURE (per request: "can this be made
                        // automatic so I never have to check it"): before
                        // ever bothering the user with a splash screen and a
                        // manual IP-entry dialog, silently try the exact
                        // same subnet scan the dialog's own "جستجوی سرور"
                        // button already does. If it finds exactly one
                        // server, save it and skip the dialog entirely —
                        // the common case (server and clients on the same
                        // LAN, one server) now needs zero manual steps ever,
                        // on first launch or if the server's IP later
                        // changes (e.g. DHCP reassigned it). The manual
                        // dialog remains as a fallback for the cases this
                        // can't handle (multiple servers on the same LAN,
                        // or the server on a different subnet entirely).
                        string autoFound = null;
                        try { autoFound = ConnectionSettingsForm.FindServerOnLan(ConnectionSettings.ServerPort); }
                        catch { }

                        if (autoFound != null)
                        {
                            ConnectionSettings.ServerHost = autoFound;
                            try { ConnectionSettings.Save(); } catch { }
                            needPrompt = false;
                        }
                    }

                    if (needPrompt)
                    {
                        // Round 11: the second splash (SplashScreen) shown before the
                        // server-address dialog was removed with the other one; the
                        // dialog now opens at once.

                        // FIX M12: wrap in `using` so the ConnectionSettingsForm's
                        // window handle (and its inline-created Font objects) are
                        // released deterministically. Was leaking a form handle per
                        // first-launch prompt until GC.
                        // FIX B10: pass the current UseTls value so the checkbox
                        // shows the saved state, and persist the user's choice.
                        using (var dlg = new ConnectionSettingsForm(ConnectionSettings.ServerHost, ConnectionSettings.ServerPort, ConnectionSettings.UseTls))
                        {
                            if (dlg.ShowDialog() == DialogResult.OK)
                            {
                                ConnectionSettings.ServerHost = dlg.Host;
                                ConnectionSettings.ServerPort = dlg.Port;
                                ConnectionSettings.UseTls = dlg.UseTls;
                                // ADD-CLIENT-25 — Task 24: persist LowPerformanceMode.
                                ConnectionSettings.LowPerformanceMode = dlg.LowPerf;
                                ConnectionSettings.Save();
                            }
                            // If the user cancels, we proceed with whatever settings we have
                            // (default 127.0.0.1:9090) — the kiosk will show "در حال اتصال..."
                            // and retry in the background.
                        }
                    }

                    // Round 12 self-repair: start (or find) the guard, leave maintenance, and
                    // record what the guard did since the last start; the next connection
                    // sends it to the server, which tells the operator.
                    try
                    {
                        GameNet.Shared.SelfHeal.Guardian.SetMaintenance("Client", false);
                        foreach (var ev in GameNet.Shared.SelfHeal.Guardian.TakeEvents("Client"))
                        {
                            var parts = ev.Split('\t');
                            if (parts.Length < 3) continue;
                            try { FaultJournal.Raise(parts[1], parts[0] + " " + parts[2]); } catch { }
                            try { CrashReporter.ReportRestart(parts[1], parts[2]); } catch { }
                        }
                        GameNet.Shared.SelfHeal.Guardian.StartWatching("Client");
                        Microsoft.Win32.SystemEvents.SessionEnding += (s2, e2) =>
                        {
                            try { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Client"); } catch { }
                        };
                    }
                    catch { }

                    // Round 15: an "internet off" rule from an older version blocks the
                    // connection to the server as well; it is replaced by the internet-only
                    // rule before the kiosk connects.
                    try
                    {
                        int fw = GameNet.Shared.SelfHeal.FirewallHelper.RepairKioskBlockRule(ConnectionSettings.ServerHost);
                        if (fw == 1) FaultJournal.Raise("HEAL-007", "GameNet_BlockInternet replaced by the internet-only rule");
                        else if (fw == 2) FaultJournal.Raise("NET-012", "GameNet_BlockInternet exists and could not be replaced (no administrator rights)");
                    }
                    catch { }

                    // Watchdog.Start is inside the try so a failure (e.g. registry
                    // access denied) still allows the finally to run RestoreAll.
                    Watchdog.Start();
                    Application.Run(new KioskForm(ConnectionSettings.ServerHost, ConnectionSettings.ServerPort));
                }
                catch (Exception ex)
                {
                    try { MessageBox.Show("خطای راه‌اندازی: " + ex.Message, "GameNet"); } catch { }
                }
                finally
                {
                    // Always restore the system on exit, even if Application.Run threw.
                    try { ClientIntegrity.StopAntiDebugWatchdog(); } catch { }
                    RestoreSystemOnce();
                    // Round 12 (P11): the automatic start is no longer removed on every exit.
                    // It made the kiosk stay closed after any exit, even a crash or the
                    // customer's exit button, until someone started it by hand. To remove it,
                    // run "GameNet.Client.exe --uninstall". An admin exit sets maintenance, so
                    // the scheduled task leaves the kiosk closed until it is started again.
                }
            } // end using mutex
        }

        /// <summary>
        /// Restores Task Manager, the taskbar, and the keyboard hook, and removes
        /// the autostart registry entry. Safe to call multiple times — only the
        /// first call performs the actual work.
        /// </summary>
        internal static void RestoreSystemOnce()
        {
            if (System.Threading.Interlocked.CompareExchange(ref _restored, 1, 0) != 0)
                return;
            try { Watchdog.Stop(); } catch { }
            try { SecurityLock.RestoreAll(); } catch { }
        }
    }
}
