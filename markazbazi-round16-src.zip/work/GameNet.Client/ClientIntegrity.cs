using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace GameNet.Client
{
    /// <summary>
    /// Phase 2.2 — Client-side self-integrity and anti-tamper checks.
    ///
    ///   1. Self-hash: computes the SHA-256 of the running executable on
    ///      startup and sends it to the server as part of ClientHello. The
    ///      server can reject clients whose hash doesn't match the known-good
    ///      value (configured per deployment).
    ///
    ///   2. Anti-debug: polls for an attached debugger (managed or native)
    ///      every few seconds. If one is detected, the client shuts down
    ///      immediately — preventing memory inspection / patching at runtime.
    ///
    ///   3. Assembly signature check (optional): verifies the executable is
    ///      signed with the expected publisher certificate. Disabled by
    ///      default; enable by dropping a publisher_cert.pem next to the exe.
    ///
    /// NOTE: No client-side protection is bulletproof against a determined
    /// attacker with physical access. These checks raise the bar and let the
    /// server reject obviously-tampered clients; they are NOT a substitute
    /// for kiosk hardening (limited user account, SRP, AppLocker, etc.).
    /// </summary>
    public static class ClientIntegrity
    {
        private static string _cachedSelfHash;
        private static Timer _antiDebugTimer;
        private static volatile bool _shuttingDown;

        /// <summary>
        /// Computes the SHA-256 hash of the running executable. Cached after
        /// the first call. Returns null if the file can't be read.
        /// </summary>
        public static string ComputeSelfHash()
        {
            if (_cachedSelfHash != null) return _cachedSelfHash;
            try
            {
                string exePath = Assembly.GetExecutingAssembly().Location;
                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                    exePath = Process.GetCurrentProcess().MainModule?.FileName;
                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath)) return null;

                using (var sha = SHA256.Create())
                using (var fs = File.OpenRead(exePath))
                {
                    byte[] hash = sha.ComputeHash(fs);
                    var sb = new StringBuilder(hash.Length * 2);
                    foreach (byte b in hash) sb.Append(b.ToString("x2"));
                    _cachedSelfHash = sb.ToString();
                }
            }
            catch { _cachedSelfHash = null; }
            return _cachedSelfHash;
        }

        /// <summary>
        /// Starts a background timer that checks for an attached debugger
        /// every 3 seconds. If detected, logs and terminates the process.
        /// </summary>
        public static void StartAntiDebugWatchdog()
        {
            // Immediate check
            if (IsDebuggerPresent())
            {
                LogAndExit("Debugger detected at startup.");
                return;
            }

            _antiDebugTimer = new Timer(_ =>
            {
                if (_shuttingDown) return;
                try
                {
                    if (Debugger.IsAttached || IsDebuggerPresent() || IsRemoteDebuggerPresent())
                    {
                        LogAndExit("Debugger detected at runtime — terminating.");
                    }
                }
                catch { /* swallow — never crash from the watchdog */ }
            }, null, 3000, 3000);
        }

        /// <summary>
        /// Stops the anti-debug timer (called on normal shutdown).
        /// </summary>
        public static void StopAntiDebugWatchdog()
        {
            try { _antiDebugTimer?.Dispose(); } catch { }
            _antiDebugTimer = null;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool IsDebuggerPresent();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

        private static bool IsRemoteDebuggerPresent()
        {
            try
            {
                bool present = false;
                CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref present);
                return present;
            }
            catch { return false; }
        }

        private static void LogAndExit(string reason)
        {
            _shuttingDown = true;
            try
            {
                // Write to a local tamper log (best effort)
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "integrity_log.txt");
                File.AppendAllText(logPath, $"{DateTime.UtcNow:o}  {reason}{Environment.NewLine}");
            }
            catch { }
            try { StopAntiDebugWatchdog(); } catch { }
            // CRITICAL FIX: Restore the system BEFORE exiting so Task Manager,
            // taskbar, and keyboard hook are re-enabled. Without this, the
            // kiosk machine is left locked after anti-debug termination.
            try
            {
                try { Watchdog.Stop(); } catch { }
                try { SecurityLock.RestoreAll(); } catch { }
            }
            catch { }
            // Force-exit so the kiosk cannot be inspected further.
            Environment.Exit(13);
        }
    }
}
