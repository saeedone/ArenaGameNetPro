using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// REAPPLY-KIOSK-CHANGES-1 (Part E): handyCafe-style client options
    /// dialog. Tabs: General / Options / customer page / Network / Events /
    /// Advanced (round 10: the Language tab was removed, there are no
    /// translations), after the handyCafe reference screenshots. Window title
    /// is "Options"; bottom bar holds OK + Cancel + a version label (round 9:
    /// the Uninstall Client button was removed); RTL layout; light gray
    /// background.
    ///
    /// OK button copies every control's value back onto the static
    /// <see cref="ClientOptions"/> fields, calls <see cref="ClientOptions.Save"/>,
    /// and sets <see cref="Form.DialogResult"/> to OK. Cancel just sets
    /// DialogResult.Cancel without touching the persisted store. Uninstall is
    /// not offered here: the full flow is owned by <c>AutoStartup.Uninstall</c>
    /// (see the worklog's M10 note; calling it here would nuke the watchdog
    /// batch + scheduled task mid-session, which is dangerous while a session
    /// is active).
    /// </summary>
    public class ClientOptionsForm : Form
    {
        // === Palette ===
        private static readonly Color _bg     = Color.FromArgb(245, 245, 248);
        private static readonly Color _panel  = Color.FromArgb(255, 255, 255);
        private static readonly Color _input  = Color.FromArgb(255, 255, 255);
        private static readonly Color _fg     = Color.FromArgb(40, 40, 40);
        private static readonly Color _accent = Color.FromArgb(51, 95, 189);
        private static readonly Color _footer = Color.FromArgb(225, 225, 230);
        private static readonly Color _header = Color.FromArgb(51, 95, 189);
        private static readonly Font  _f  = new Font("Segoe UI", 9F);
        private static readonly Font  _fb = new Font("Segoe UI", 9F, FontStyle.Bold);
        private static readonly Font  _fh = new Font("Segoe UI", 10F, FontStyle.Bold);

        private TabControl _tabs;
        private TabPage _tabGeneral, _tabOptions, _tabNetwork, _tabEvents, _tabAdvanced;

        /// <summary>Round 10: true after OK when the General tab saved a new server address.</summary>
        public bool ServerAddressChanged { get; private set; }

        // --- General controls ---
        private TextBox _txtAdminUser, _txtAdminPass, _txtAdminPass2, _txtServerIp;
        private CheckBox _chkAuto;

        // --- Options controls ---
        private TextBox _txtWallpaper;
        private Button _btnBrowseWall;
        private CheckBox _chkDisableCafeteria, _chkDisableHide, _chkDisableLogout,
                         _chkDisableAltEnter, _chkDisableLoginRequest, _chkUsbProtection,
                         _chkTerminateOnLogout, _chkHideUsedTime, _chkHideCost,
                         _chkHideRemainingTime, _chkHideStartTime;
        private TextBox _txtGameFolders; // round 10

        // --- Network controls ---
        private ListView _lvAdapters;
        private Button _btnRefreshAdapters;

        // --- Events controls ---
        private ListBox _lbEvents;
        private NumericUpDown _numOnTimeEndMinutes;
        private TextBox _txtOnTimeEndMessage, _txtOnLoginMessage, _txtOnLogoutMessage;
        private TextBox _txtOnTimeEndSound, _txtOnLoginSound, _txtOnLogoutSound;
        private CheckBox _chkBuiltInSounds; // round 11
        private Button _btnBrowseTimeEnd, _btnBrowseLogin, _btnBrowseLogout;
        // Tracks which event is currently selected so the right pane knows which
        // fields to write back to when focus changes.
        private int _selectedEventIdx = 0;

        // --- Advanced controls ---
        // Round 10: the UDP port fields were removed (see BuildAdvancedTab).
        private TextBox _txtServerClientPassword;
        private Button _btnLoadDefaultsPwd;

        // Round 10: the Language tab was removed (there are no translations).

        // --- Right column controls (round 6) ---
        private TabPage _tabColumn;
        private ColumnItem[] _columnItems;
        private CheckBox[] _columnChecks;
        // Set while one box updates its twin, so the twin's handler does not echo back.
        private bool _syncingTwins;

        public ClientOptionsForm()
        {
            // Make sure the persisted store has been loaded before we seed
            // the UI — KioskForm already calls ClientOptions.Load() in its
            // ctor, but a standalone open of this dialog (e.g. from a future
            // tray icon) might run before then.
            try { ClientOptions.Load(); } catch { }

            this.Text = "Options";
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = _bg;
            this.ForeColor = _fg;
            this.RightToLeft = RightToLeft.Yes;
            this.ClientSize = new Size(640, 520);

            BuildTabs();
            BuildBottomBar();
            SeedFromStore();
        }

        // =====================================================================
        // === Tab strip + 6 tabs ===
        // =====================================================================
        private void BuildTabs()
        {
            _tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = _f,
                Appearance = TabAppearance.Normal,
                Alignment = TabAlignment.Top,
                Padding = new Point(16, 6),
            };
            _tabGeneral   = new TabPage("General")   { BackColor = _bg, Font = _f };
            _tabOptions   = new TabPage("Options")   { BackColor = _bg, Font = _f };
            _tabNetwork   = new TabPage("Network")   { BackColor = _bg, Font = _f };
            _tabEvents    = new TabPage("Events")    { BackColor = _bg, Font = _f };
            _tabAdvanced  = new TabPage("Advanced")  { BackColor = _bg, Font = _f };
            // Round 6: right-column switches (see BuildColumnTab). Round 8: renamed
            // from "ستون راست"; the admin column is on the right of the screen too.
            _tabColumn    = new TabPage("صفحهٔ مشتری") { BackColor = _bg, Font = _f };
            _tabs.TabPages.AddRange(new TabPage[]
            {
                _tabGeneral, _tabOptions, _tabColumn, _tabNetwork, _tabEvents, _tabAdvanced
            });

            BuildGeneralTab();
            BuildOptionsTab();
            BuildColumnTab(); // after BuildOptionsTab: it links to the Options tab's boxes
            BuildNetworkTab();
            BuildEventsTab();
            BuildAdvancedTab();

            // The bottom bar is anchored below the tab strip — create it first
            // and Dock=Top for the tab control would cover it. Use a panel for
            // the bottom bar with Dock=Bottom and let the TabControl Dock=Fill
            // fill the remaining space.
            this.Controls.Add(_tabs);
        }

        // =====================================================================
        // === Bottom bar: Version + Cancel + OK (round 9: no Uninstall) =======
        // =====================================================================
        private void BuildBottomBar()
        {
            var bottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 44,
                BackColor = _footer,
            };
            var lblVersion = new Label
            {
                Text = "Version 1.0.0",
                Font = _f,
                ForeColor = _fg,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleLeft,
                Dock = DockStyle.Left,
                Width = 120,
                Padding = new Padding(8, 0, 0, 0),
            };
            // Round 9: the "Uninstall Client" button at the left is removed. It only
            // showed a message saying uninstall is done elsewhere.

            var btnCancel = new Button
            {
                Text = "Cancel",
                DialogResult = DialogResult.Cancel,
                Size = new Size(90, 28),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(220, 220, 225),
                Font = _fb,
                Dock = DockStyle.Right,
            };
            var btnOk = new Button
            {
                Text = "OK",
                Size = new Size(90, 28),
                FlatStyle = FlatStyle.Flat,
                BackColor = _accent,
                ForeColor = Color.White,
                Font = _fb,
                Dock = DockStyle.Right,
            };
            btnOk.Click += (s, e) => OnOk();

            bottom.Controls.AddRange(new Control[] { lblVersion, btnCancel, btnOk });
            this.Controls.Add(bottom);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }

        // =====================================================================
        // === Tab 1: General ===================================================
        // =====================================================================
        private void BuildGeneralTab()
        {
            var lblAdmin = new Label
            {
                Text = "Admin Username:",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = _f,
            };
            _txtAdminUser = new TextBox
            {
                Location = new Point(160, 17),
                Size = new Size(220, 24),
                Font = _f,
                BackColor = _input,
            };

            var lblPass = new Label
            {
                Text = "Admin Password:",
                Location = new Point(20, 55),
                AutoSize = true,
                Font = _f,
            };
            _txtAdminPass = new TextBox
            {
                Location = new Point(160, 52),
                Size = new Size(220, 24),
                Font = _f,
                UseSystemPasswordChar = true,
                BackColor = _input,
            };

            var lblPass2 = new Label
            {
                Text = "Re-type Password:",
                Location = new Point(20, 90),
                AutoSize = true,
                Font = _f,
            };
            _txtAdminPass2 = new TextBox
            {
                Location = new Point(160, 87),
                Size = new Size(220, 24),
                Font = _f,
                UseSystemPasswordChar = true,
                BackColor = _input,
            };

            var lblServer = new Label
            {
                Text = "Server IP / Host:",
                Location = new Point(20, 140),
                AutoSize = true,
                Font = _f,
            };
            _txtServerIp = new TextBox
            {
                Location = new Point(160, 137),
                Size = new Size(220, 24),
                Font = _f,
                BackColor = _input,
            };

            _chkAuto = new CheckBox
            {
                Text = "Auto (Server Discovery)",
                Location = new Point(160, 175),
                Size = new Size(220, 24),
                Font = _f,
                Checked = ClientOptions.AutoDiscovery,
            };

            // Round 10: the three admin fields set the offline admin login (the one that
            // opens admin mode); they used to pre-fill the login boxes. Server IP / Host
            // is the address in server_settings.txt, and Auto means the LAN search.
            var lblAdminHint = new Label
            {
                Text = "رمز «ورود مدیر». برای نگه داشتن رمز فعلی، دو خانهٔ رمز را خالی بگذارید.",
                Location = new Point(20, 114),
                Size = new Size(580, 20),
                Font = _f,
                ForeColor = Color.FromArgb(90, 90, 90),
            };
            var lblAutoHint = new Label
            {
                Text = "اگر سرور ذخیره‌شده هنگام روشن شدن کیوسک جواب ندهد، سرور در شبکه جست‌وجو می‌شود.",
                Location = new Point(20, 202),
                Size = new Size(580, 34),
                Font = _f,
                ForeColor = Color.FromArgb(90, 90, 90),
            };

            _tabGeneral.Controls.AddRange(new Control[]
            {
                lblAdmin, _txtAdminUser, lblPass, _txtAdminPass,
                lblPass2, _txtAdminPass2, lblServer, _txtServerIp, _chkAuto,
                lblAdminHint, lblAutoHint
            });
        }

        // =====================================================================
        // === Tab 2: Options ===================================================
        // =====================================================================
        private void BuildOptionsTab()
        {
            var lblWall = new Label
            {
                Text = "Default Wallpaper:",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = _f,
            };
            _txtWallpaper = new TextBox
            {
                Location = new Point(150, 17),
                Size = new Size(280, 24),
                Font = _f,
                BackColor = _input,
            };
            _btnBrowseWall = new Button
            {
                Text = "Browse...",
                Location = new Point(440, 16),
                Size = new Size(90, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            _btnBrowseWall.Click += (s, e) =>
            {
                using (var ofd = new OpenFileDialog
                {
                    Filter = "Image files|*.bmp;*.jpg;*.jpeg;*.png|All files|*.*",
                    Title = "Select default wallpaper"
                })
                {
                    if (ofd.ShowDialog(this) == DialogResult.OK)
                        _txtWallpaper.Text = ofd.FileName;
                }
            };

            int y = 60;
            int xCol1 = 30;
            int xCol2 = 330;
            var chkDefs = new[]
            {
                new { Ctl = new CheckBox(), Lbl = "Disable Cafeteria" },
                new { Ctl = new CheckBox(), Lbl = "Disable Hide" },
                new { Ctl = new CheckBox(), Lbl = "Disable Logout" },
                new { Ctl = new CheckBox(), Lbl = "Disable Alt+Enter" },
                new { Ctl = new CheckBox(), Lbl = "Disable Login Request" },
                new { Ctl = new CheckBox(), Lbl = "USB Protection" },
                new { Ctl = new CheckBox(), Lbl = "Terminate on Logout" },
                new { Ctl = new CheckBox(), Lbl = "Hide Used Time" },
                new { Ctl = new CheckBox(), Lbl = "Hide Cost" },
                new { Ctl = new CheckBox(), Lbl = "Hide Remaining Time" },
                new { Ctl = new CheckBox(), Lbl = "Hide Start Time" },
            };
            _chkDisableCafeteria    = chkDefs[0].Ctl; _chkDisableCafeteria.Text    = chkDefs[0].Lbl;
            _chkDisableHide         = chkDefs[1].Ctl; _chkDisableHide.Text         = chkDefs[1].Lbl;
            _chkDisableLogout       = chkDefs[2].Ctl; _chkDisableLogout.Text       = chkDefs[2].Lbl;
            _chkDisableAltEnter      = chkDefs[3].Ctl; _chkDisableAltEnter.Text    = chkDefs[3].Lbl;
            _chkDisableLoginRequest  = chkDefs[4].Ctl; _chkDisableLoginRequest.Text = chkDefs[4].Lbl;
            _chkUsbProtection        = chkDefs[5].Ctl; _chkUsbProtection.Text       = chkDefs[5].Lbl;
            _chkTerminateOnLogout   = chkDefs[6].Ctl; _chkTerminateOnLogout.Text   = chkDefs[6].Lbl;
            _chkHideUsedTime        = chkDefs[7].Ctl; _chkHideUsedTime.Text        = chkDefs[7].Lbl;
            _chkHideCost            = chkDefs[8].Ctl; _chkHideCost.Text            = chkDefs[8].Lbl;
            _chkHideRemainingTime   = chkDefs[9].Ctl; _chkHideRemainingTime.Text   = chkDefs[9].Lbl;
            _chkHideStartTime       = chkDefs[10].Ctl; _chkHideStartTime.Text      = chkDefs[10].Lbl;

            var orderedChks = new[]
            {
                _chkDisableCafeteria, _chkDisableHide, _chkDisableLogout,
                _chkDisableAltEnter, _chkDisableLoginRequest, _chkUsbProtection,
                _chkTerminateOnLogout, _chkHideUsedTime, _chkHideCost,
                _chkHideRemainingTime, _chkHideStartTime
            };
            for (int i = 0; i < orderedChks.Length; i++)
            {
                var c = orderedChks[i];
                c.AutoSize = false;
                c.Size = new Size(280, 24);
                c.Font = _f;
                c.FlatStyle = FlatStyle.Flat;
                int col = i % 2;
                int row = i / 2;
                c.Location = new Point(col == 0 ? xCol1 : xCol2, y + row * 26);
            }

            // Round 10: folders whose programs "Terminate on Logout" and the end of time
            // close (GameKiller); before, only C:\Games and D:\Games were checked.
            var lblGames = new Label
            {
                Text = "Game Folders:",
                Location = new Point(20, 232),
                AutoSize = true,
                Font = _f,
            };
            _txtGameFolders = new TextBox
            {
                Location = new Point(150, 229),
                Size = new Size(450, 24),
                Font = _f,
                BackColor = _input,
                RightToLeft = RightToLeft.No,
            };
            var lblGamesHint = new Label
            {
                Text = "پوشه‌های بازی، جدا با ; — برنامه‌های داخل این پوشه‌ها با Terminate on Logout و در پایان زمان بسته می‌شوند.",
                Location = new Point(20, 258),
                Size = new Size(580, 34),
                Font = _f,
                ForeColor = Color.FromArgb(90, 90, 90),
            };

            _tabOptions.Controls.AddRange(new Control[]
            {
                lblWall, _txtWallpaper, _btnBrowseWall,
                _chkDisableCafeteria, _chkDisableHide, _chkDisableLogout,
                _chkDisableAltEnter, _chkDisableLoginRequest, _chkUsbProtection,
                _chkTerminateOnLogout, _chkHideUsedTime, _chkHideCost,
                _chkHideRemainingTime, _chkHideStartTime,
                lblGames, _txtGameFolders, lblGamesHint
            });
        }

        // =====================================================================
        // === Tab: Right column (round 6) =====================================
        // =====================================================================

        /// <summary>
        /// One item of the kiosk's right column for the "ستون راست" tab: its label,
        /// how to read and write its ClientOptions field (stored as Hide*/Disable*,
        /// so the value means "hidden"), and, for an item that already had a box on
        /// the Options tab, that box (checked = hidden).
        /// </summary>
        private sealed class ColumnItem
        {
            public readonly string Text;
            public readonly Func<bool> IsHidden;
            public readonly Action<bool> SetHidden;
            public readonly CheckBox Twin;

            public ColumnItem(string text, Func<bool> isHidden, Action<bool> setHidden, CheckBox twin = null)
            {
                Text = text;
                IsHidden = isHidden;
                SetHidden = setHidden;
                Twin = twin;
            }
        }

        /// <summary>
        /// Round 6: the "ستون راست" tab. One box per item of the kiosk's right
        /// column after login (8 info rows, then 17 buttons in column order);
        /// checked = shown. Items that already had a box on the Options tab
        /// (Disable Hide, Disable Cafeteria, Hide Start/Remaining/Used Time,
        /// Hide Cost) are the same settings, and the two boxes follow each other
        /// both ways. Runs after BuildOptionsTab, which creates those boxes.
        /// </summary>
        private void BuildColumnTab()
        {
            _columnItems = new[]
            {
                // Info rows (indices 0-7)
                new ColumnItem("آدرس IP",        () => ClientOptions.HideIpAddress,        v => ClientOptions.HideIpAddress = v),
                new ColumnItem("قیمت هر ساعت",   () => ClientOptions.HidePricePerHour,     v => ClientOptions.HidePricePerHour = v),
                new ColumnItem("شروع",           () => ClientOptions.HideStartTime,        v => ClientOptions.HideStartTime = v,        _chkHideStartTime),
                new ColumnItem("باقی‌مانده",      () => ClientOptions.HideRemainingTime,    v => ClientOptions.HideRemainingTime = v,    _chkHideRemainingTime),
                new ColumnItem("استفاده شده",    () => ClientOptions.HideUsedTime,         v => ClientOptions.HideUsedTime = v,         _chkHideUsedTime),
                new ColumnItem("هزینه",          () => ClientOptions.HideCost,             v => ClientOptions.HideCost = v,             _chkHideCost),
                new ColumnItem("اعتبار",         () => ClientOptions.HideBalance,          v => ClientOptions.HideBalance = v),
                new ColumnItem("امتیاز",         () => ClientOptions.HideLoyaltyPoints,    v => ClientOptions.HideLoyaltyPoints = v),
                // Buttons (indices 8-24), in the order they appear in the column
                new ColumnItem("🖥️ دسکتاپ",       () => ClientOptions.DisableHide,          v => ClientOptions.DisableHide = v,          _chkDisableHide),
                new ColumnItem("⏱️ +۱۰ دقیقه",    () => ClientOptions.HideBtnAdd10,         v => ClientOptions.HideBtnAdd10 = v),
                new ColumnItem("⏱️ +۳۰ دقیقه",    () => ClientOptions.HideBtnAdd30,         v => ClientOptions.HideBtnAdd30 = v),
                new ColumnItem("⏱️ +۶۰ دقیقه",    () => ClientOptions.HideBtnAdd60,         v => ClientOptions.HideBtnAdd60 = v),
                new ColumnItem("⏹️ پایان نشست",   () => ClientOptions.HideBtnEndSession,    v => ClientOptions.HideBtnEndSession = v),
                new ColumnItem("📷 اسکرین‌شات",   () => ClientOptions.HideBtnScreenshot,    v => ClientOptions.HideBtnScreenshot = v),
                new ColumnItem("💬 پیام",         () => ClientOptions.HideBtnMessage,       v => ClientOptions.HideBtnMessage = v),
                new ColumnItem("➕ اعتبار",       () => ClientOptions.DisableCafeteria,     v => ClientOptions.DisableCafeteria = v,     _chkDisableCafeteria),
                new ColumnItem("🗨️ چت",           () => ClientOptions.HideBtnChat,          v => ClientOptions.HideBtnChat = v),
                new ColumnItem("📢 اطلاعیه‌ها",   () => ClientOptions.HideBtnAnnouncements, v => ClientOptions.HideBtnAnnouncements = v),
                new ColumnItem("🏆 امتیازات",     () => ClientOptions.HideBtnLoyalty,       v => ClientOptions.HideBtnLoyalty = v),
                new ColumnItem("👤 پروفایل",      () => ClientOptions.HideBtnProfile,       v => ClientOptions.HideBtnProfile = v),
                new ColumnItem("📊 آمار",         () => ClientOptions.HideBtnStats,         v => ClientOptions.HideBtnStats = v),
                new ColumnItem("🍔 سفارش غذا",    () => ClientOptions.HideBtnFood,          v => ClientOptions.HideBtnFood = v),
                new ColumnItem("🎵 موسیقی",       () => ClientOptions.HideBtnMusic,         v => ClientOptions.HideBtnMusic = v),
                new ColumnItem("⚙️ تنظیمات",      () => ClientOptions.HideBtnOptions,       v => ClientOptions.HideBtnOptions = v),
                new ColumnItem("⏻ خروج",          () => ClientOptions.HideBtnExit,          v => ClientOptions.HideBtnExit = v),
            };

            var lblRows = new Label
            {
                Text = "ردیف‌های اطلاعات (تیک = نمایش در صفحهٔ مشتری)",
                Location = new Point(215, 8),
                Size = new Size(395, 20),
                Font = _fb,
            };
            var lblButtons = new Label
            {
                Text = "دکمه‌ها",
                Location = new Point(20, 126),
                Size = new Size(590, 20),
                Font = _fb,
            };
            var lblNote = new Label
            {
                Text = "• اگر قابلیتی در سرور (صفحهٔ «قابلیت‌ها») خاموش باشد، دکمه‌اش با تیک این‌جا هم نمایش داده نمی‌شود.\n" +
                       "• در صفحهٔ مشتری، «⚙️ تنظیمات» و کلید F3 اول رمز مدیر را می‌پرسند؛ از ستون مدیر بدون رمز باز می‌شود.\n" +
                       "• تغییرات بعد از OK روی صفحهٔ مشتری اعمال می‌شوند.",
                Location = new Point(20, 362),
                Size = new Size(590, 74),
                Font = _f,
            };

            var controls = new List<Control> { lblRows, lblButtons, lblNote };
            _columnChecks = new CheckBox[_columnItems.Length];
            for (int i = 0; i < _columnItems.Length; i++)
            {
                bool isRow = i < 8;
                int k = isRow ? i : i - 8;
                int baseY = isRow ? 30 : 148;
                var chk = new CheckBox
                {
                    Text = _columnItems[i].Text,
                    AutoSize = false,
                    Size = new Size(280, 22),
                    Font = _f,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(k % 2 == 0 ? 30 : 330, baseY + (k / 2) * 23),
                };
                _columnChecks[i] = chk;
                controls.Add(chk);

                // Same setting as a box on the Options tab (checked = hidden there):
                // keep the two opposite, whichever one the operator changes.
                CheckBox twin = _columnItems[i].Twin;
                if (twin != null)
                {
                    chk.CheckedChanged += (s, e) =>
                    {
                        if (_syncingTwins) return;
                        _syncingTwins = true;
                        try { twin.Checked = !chk.Checked; }
                        finally { _syncingTwins = false; }
                    };
                    twin.CheckedChanged += (s, e) =>
                    {
                        if (_syncingTwins) return;
                        _syncingTwins = true;
                        try { chk.Checked = !twin.Checked; }
                        finally { _syncingTwins = false; }
                    };
                }
            }
            // Round 8: tick or clear every box at once. The twin boxes on the
            // Options tab follow through their CheckedChanged handlers.
            var btnAll = new Button
            {
                Text = "تیک همه",
                Location = new Point(20, 4),
                Size = new Size(90, 24),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            var btnNone = new Button
            {
                Text = "برداشتن همه",
                Location = new Point(116, 4),
                Size = new Size(90, 24),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            btnAll.Click += (s, e) => { foreach (CheckBox c in _columnChecks) c.Checked = true; };
            btnNone.Click += (s, e) => { foreach (CheckBox c in _columnChecks) c.Checked = false; };
            controls.Add(btnAll);
            controls.Add(btnNone);
            _tabColumn.Controls.AddRange(controls.ToArray());
        }

        /// <summary>
        /// Round 8: selects the "صفحهٔ مشتری" tab. The kiosk's admin column calls
        /// this before showing the dialog, so the customer-page switches come first.
        /// </summary>
        public void ShowCustomerPageTab()
        {
            if (_tabs != null && _tabColumn != null) _tabs.SelectedTab = _tabColumn;
        }

        // =====================================================================
        // === Tab 3: Network (adapter picker) ==================================
        // =====================================================================
        private void BuildNetworkTab()
        {
            var lblAdapter = new Label
            {
                Text = "Select Adapter:",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = _f,
            };
            _lvAdapters = new ListView
            {
                View = View.Details,
                FullRowSelect = true,
                MultiSelect = false,
                GridLines = true,
                Location = new Point(20, 40),
                Size = new Size(580, 280),
                Font = _f,
                BackColor = _input,
            };
            _lvAdapters.Columns.Add("MAC", 130);
            _lvAdapters.Columns.Add("Description", 280);
            _lvAdapters.Columns.Add("IP", 150);

            _btnRefreshAdapters = new Button
            {
                Text = "Refresh",
                Location = new Point(20, 330),
                Size = new Size(100, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            _btnRefreshAdapters.Click += (s, e) => PopulateAdapters();

            _tabNetwork.Controls.AddRange(new Control[] { lblAdapter, _lvAdapters, _btnRefreshAdapters });
            PopulateAdapters();
        }

        private void PopulateAdapters()
        {
            try
            {
                _lvAdapters.Items.Clear();
                foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.OperationalStatus != OperationalStatus.Up &&
                        nic.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    string mac = nic.GetPhysicalAddress().ToString();
                    if (string.IsNullOrEmpty(mac)) continue;
                    // Insert colons for readability: 00:11:22:33:44:55.
                    if (mac.Length == 12)
                    {
                        var parts = new List<string>(6);
                        for (int i = 0; i < 12; i += 2) parts.Add(mac.Substring(i, 2));
                        mac = string.Join(":", parts);
                    }
                    string desc = nic.Description ?? nic.Name;
                    string ip = "";
                    try
                    {
                        var props = nic.GetIPProperties();
                        foreach (var unicast in props.UnicastAddresses)
                        {
                            if (unicast.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                            {
                                ip = unicast.Address.ToString();
                                break;
                            }
                        }
                    }
                    catch { }
                    var item = new ListViewItem(mac) { Tag = mac };
                    item.SubItems.Add(desc);
                    item.SubItems.Add(ip);
                    _lvAdapters.Items.Add(item);
                }
                // Pre-select the configured adapter (if any) so the operator sees
                // what's currently in effect.
                if (!string.IsNullOrWhiteSpace(ClientOptions.SelectedAdapterMac))
                {
                    string target = ClientOptions.SelectedAdapterMac.Replace(":", "").ToLowerInvariant();
                    foreach (ListViewItem lvi in _lvAdapters.Items)
                    {
                        string mac = (lvi.Tag as string ?? "").Replace(":", "").ToLowerInvariant();
                        if (mac == target) { lvi.Selected = true; break; }
                    }
                }
            }
            catch { /* best-effort — don't crash the dialog if NIC enumeration fails */ }
        }

        // =====================================================================
        // === Tab 4: Events (3 sound-driven events) ============================
        // =====================================================================
        private void BuildEventsTab()
        {
            var lblEvents = new Label
            {
                Text = "Events:",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = _f,
            };
            _lbEvents = new ListBox
            {
                Location = new Point(20, 40),
                Size = new Size(160, 200),
                Font = _f,
            };
            _lbEvents.Items.AddRange(new object[] { "On Time End", "On Login", "On Logout" });
            _lbEvents.SelectedIndex = 0;
            _lbEvents.SelectedIndexChanged += (s, e) => OnEventSelected();

            // Right-pane: minutes + message + sound — shared for all three
            // events. We re-seed the controls when the user picks an event
            // from the ListBox (see OnEventSelected).
            var lblMinutes = new Label
            {
                Text = "On Last Minutes:",
                Location = new Point(200, 45),
                AutoSize = true,
                Font = _f,
            };
            _numOnTimeEndMinutes = new NumericUpDown
            {
                Location = new Point(330, 42),
                Size = new Size(70, 24),
                Minimum = 0,
                Maximum = 60,
                Font = _f,
            };

            var lblMessage = new Label
            {
                Text = "Warn User Message:",
                Location = new Point(200, 80),
                AutoSize = true,
                Font = _f,
            };
            _txtOnTimeEndMessage = new TextBox
            {
                Location = new Point(330, 77),
                Size = new Size(250, 24),
                Font = _f,
                BackColor = _input,
            };
            _txtOnLoginMessage = new TextBox
            {
                Location = new Point(330, 77),
                Size = new Size(250, 24),
                Font = _f,
                BackColor = _input,
                Visible = false,
            };
            _txtOnLogoutMessage = new TextBox
            {
                Location = new Point(330, 77),
                Size = new Size(250, 24),
                Font = _f,
                BackColor = _input,
                Visible = false,
            };

            var lblSound = new Label
            {
                Text = "Play Sound:",
                Location = new Point(200, 115),
                AutoSize = true,
                Font = _f,
            };
            _txtOnTimeEndSound = new TextBox
            {
                Location = new Point(330, 112),
                Size = new Size(200, 24),
                Font = _f,
                BackColor = _input,
            };
            _txtOnLoginSound = new TextBox
            {
                Location = new Point(330, 112),
                Size = new Size(200, 24),
                Font = _f,
                BackColor = _input,
                Visible = false,
            };
            _txtOnLogoutSound = new TextBox
            {
                Location = new Point(330, 112),
                Size = new Size(200, 24),
                Font = _f,
                BackColor = _input,
                Visible = false,
            };
            _btnBrowseTimeEnd = new Button
            {
                Text = "Browse...",
                Location = new Point(540, 111),
                Size = new Size(80, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            _btnBrowseTimeEnd.Click += (s, e) => BrowseSound(_txtOnTimeEndSound);
            _btnBrowseLogin = new Button
            {
                Text = "Browse...",
                Location = new Point(540, 111),
                Size = new Size(80, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
                Visible = false,
            };
            _btnBrowseLogin.Click += (s, e) => BrowseSound(_txtOnLoginSound);
            _btnBrowseLogout = new Button
            {
                Text = "Browse...",
                Location = new Point(540, 111),
                Size = new Size(80, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
                Visible = false,
            };
            _btnBrowseLogout.Click += (s, e) => BrowseSound(_txtOnLogoutSound);

            // Round 11: built-in sounds, with a test button for each so the operator
            // can hear them on this PC (speakers, volume, missing Sounds folder).
            _chkBuiltInSounds = new CheckBox
            {
                Text = "پخش صداهای داخلی برنامه (روشن‌شدن سیستم، ۱۰/۵/۱ دقیقه مانده، پایان زمان)",
                Location = new Point(200, 160),
                Size = new Size(430, 24),
                Font = _f,
                RightToLeft = RightToLeft.Yes,
            };
            var lblTest = new Label { Text = "تست صدا:", Location = new Point(200, 196), AutoSize = true, Font = _f };
            var tests = new[]
            {
                new { T = "روشن‌شدن", F = SoundAlert.StartupSound },
                new { T = "۱۰ دقیقه", F = SoundAlert.Warn10Sound },
                new { T = "۵ دقیقه",  F = SoundAlert.Warn5Sound },
                new { T = "۱ دقیقه",  F = SoundAlert.Warn1Sound },
                new { T = "پایان",    F = SoundAlert.TimeEndSound },
            };
            var testButtons = new List<Control>();
            int tx = 270;
            foreach (var t in tests)
            {
                string file = t.F;
                var b = new Button
                {
                    Text = "▶ " + t.T,
                    Location = new Point(tx, 191),
                    Size = new Size(66, 28),
                    Font = _f,
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(225, 225, 230),
                };
                b.Click += (s, e) =>
                {
                    string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sounds", file);
                    if (!System.IO.File.Exists(path))
                    {
                        MessageBox.Show(this, "فایل صدا پیدا نشد:\n" + path, "تست صدا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SoundAlert.PlayFile(path);
                };
                testButtons.Add(b);
                tx += 68;
            }

            _tabEvents.Controls.AddRange(new Control[]
            {
                lblEvents, _lbEvents, lblMinutes, _numOnTimeEndMinutes,
                lblMessage, _txtOnTimeEndMessage, _txtOnLoginMessage, _txtOnLogoutMessage,
                lblSound, _txtOnTimeEndSound, _txtOnLoginSound, _txtOnLogoutSound,
                _btnBrowseTimeEnd, _btnBrowseLogin, _btnBrowseLogout,
                _chkBuiltInSounds, lblTest
            });
            _tabEvents.Controls.AddRange(testButtons.ToArray());
            OnEventSelected();
        }

        private void BrowseSound(TextBox target)
        {
            using (var ofd = new OpenFileDialog
            {
                Filter = "Sound files|*.wav;*.mp3|All files|*.*",
                Title = "Select sound file"
            })
            {
                if (ofd.ShowDialog(this) == DialogResult.OK)
                    target.Text = ofd.FileName;
            }
        }

        private void OnEventSelected()
        {
            _selectedEventIdx = _lbEvents.SelectedIndex;
            // Hide all of the event-specific message/sound controls first,
            // then unhide the ones for the newly-selected event. We re-seat
            // the label text + numeric value each time so the right pane shows
            // the right persisted value.
            _txtOnTimeEndMessage.Visible = false;
            _txtOnLoginMessage.Visible = false;
            _txtOnLogoutMessage.Visible = false;
            _txtOnTimeEndSound.Visible = false;
            _txtOnLoginSound.Visible = false;
            _txtOnLogoutSound.Visible = false;
            _btnBrowseTimeEnd.Visible = false;
            _btnBrowseLogin.Visible = false;
            _btnBrowseLogout.Visible = false;

            switch (_selectedEventIdx)
            {
                case 0:
                    _numOnTimeEndMinutes.Value = ClientOptions.OnTimeEndMinutes;
                    _txtOnTimeEndMessage.Text = ClientOptions.OnTimeEndMessage;
                    _txtOnTimeEndSound.Text = ClientOptions.OnTimeEndSound;
                    _txtOnTimeEndMessage.Visible = true;
                    _txtOnTimeEndSound.Visible = true;
                    _btnBrowseTimeEnd.Visible = true;
                    break;
                case 1:
                    _numOnTimeEndMinutes.Enabled = true; // minutes field kept for symmetry but only Time End uses it
                    _txtOnLoginMessage.Text = ClientOptions.OnLoginMessage;
                    _txtOnLoginSound.Text = ClientOptions.OnLoginSound;
                    _txtOnLoginMessage.Visible = true;
                    _txtOnLoginSound.Visible = true;
                    _btnBrowseLogin.Visible = true;
                    break;
                case 2:
                    _txtOnLogoutMessage.Text = ClientOptions.OnLogoutMessage;
                    _txtOnLogoutSound.Text = ClientOptions.OnLogoutSound;
                    _txtOnLogoutMessage.Visible = true;
                    _txtOnLogoutSound.Visible = true;
                    _btnBrowseLogout.Visible = true;
                    break;
            }
        }

        // =====================================================================
        // === Tab 5: Advanced (UDP ports + password + load-defaults) ===========
        // =====================================================================
        private void BuildAdvancedTab()
        {
            // Round 10: the Server UDP Port / Client UDP Port fields were removed. The
            // client port was never read, and the server port only served a UDP
            // discovery that no server answered.
            var lblPwd = new Label
            {
                Text = "Server/Client Password:",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = _f,
            };
            _txtServerClientPassword = new TextBox
            {
                Location = new Point(160, 17),
                Size = new Size(200, 24),
                Font = _f,
                BackColor = _input,
            };
            _btnLoadDefaultsPwd = new Button
            {
                Text = "Load Default",
                Location = new Point(380, 16),
                Size = new Size(120, 26),
                Font = _f,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(225, 225, 230),
            };
            _btnLoadDefaultsPwd.Click += (s, e) =>
            {
                _txtServerClientPassword.Text = "HANDYCAFE";
            };
            var lblPwdHint = new Label
            {
                Text = "باید با «رمز سرور/کلاینت» در تنظیمات برنامهٔ سرور یکی باشد. اگر آن‌جا خالی باشد، بررسی نمی‌شود.",
                Location = new Point(20, 55),
                Size = new Size(580, 40),
                Font = _f,
                ForeColor = Color.FromArgb(90, 90, 90),
            };

            _tabAdvanced.Controls.AddRange(new Control[]
            {
                lblPwd, _txtServerClientPassword, _btnLoadDefaultsPwd, lblPwdHint
            });
        }

        // Round 10: BuildLanguageTab was removed with the Language tab.

        // =====================================================================
        // === Seed UI from persisted store + write UI back to store on OK =====
        // =====================================================================
        private void SeedFromStore()
        {
            // Round 10: the offline admin login (the password boxes start empty, which
            // keeps the current password) and the real server address.
            _txtAdminUser.Text = ClientOptions.SuperAdminUsername;
            _txtAdminPass.Text = "";
            _txtAdminPass2.Text = "";
            _txtServerIp.Text = ConnectionSettings.ServerHost;
            _chkAuto.Checked = ClientOptions.AutoDiscovery;

            _txtWallpaper.Text = ClientOptions.DefaultWallpaper;
            _chkDisableCafeteria.Checked    = ClientOptions.DisableCafeteria;
            _chkDisableHide.Checked         = ClientOptions.DisableHide;
            _chkDisableLogout.Checked       = ClientOptions.DisableLogout;
            _chkDisableAltEnter.Checked     = ClientOptions.DisableAltEnter;
            _chkDisableLoginRequest.Checked = ClientOptions.DisableLoginRequest;
            _chkUsbProtection.Checked       = ClientOptions.UsbProtection;
            _chkTerminateOnLogout.Checked  = ClientOptions.TerminateOnLogout;
            _chkHideUsedTime.Checked        = ClientOptions.HideUsedTime;
            _chkHideCost.Checked            = ClientOptions.HideCost;
            _chkHideRemainingTime.Checked   = ClientOptions.HideRemainingTime;
            _chkHideStartTime.Checked       = ClientOptions.HideStartTime;
            _txtGameFolders.Text = ClientOptions.GameFolders;

            _txtServerClientPassword.Text = ClientOptions.ServerClientPassword;

            _numOnTimeEndMinutes.Value = ClampToRange(ClientOptions.OnTimeEndMinutes, 0, 60);
            _txtOnTimeEndMessage.Text = ClientOptions.OnTimeEndMessage;
            _txtOnTimeEndSound.Text = ClientOptions.OnTimeEndSound;
            _txtOnLoginMessage.Text = ClientOptions.OnLoginMessage;
            _txtOnLoginSound.Text = ClientOptions.OnLoginSound;
            _txtOnLogoutMessage.Text = ClientOptions.OnLogoutMessage;
            _txtOnLogoutSound.Text = ClientOptions.OnLogoutSound;
            _chkBuiltInSounds.Checked = ClientOptions.BuiltInSounds;

            // Round 6: right-column tab (checked = shown).
            for (int i = 0; i < _columnItems.Length; i++)
                _columnChecks[i].Checked = !_columnItems[i].IsHidden();
        }

        private static decimal ClampToRange(int value, int min, int max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        /// <summary>
        /// Validates the password re-entry, then copies every control's value
        /// back onto the static <see cref="ClientOptions"/> store, calls
        /// <see cref="ClientOptions.Save"/>, and closes the dialog with OK.
        /// On validation failure the dialog stays open so the operator can
        /// fix the typo.
        /// </summary>
        private void OnOk()
        {
            if (_txtAdminPass.Text != _txtAdminPass2.Text)
            {
                MessageBox.Show(this, "The two password entries do not match.",
                    "Options", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtAdminPass2.Focus();
                return;
            }

            // Round 10: the offline admin login and the server address, checked first.
            string adminUser = _txtAdminUser.Text.Trim();
            if (adminUser.Length == 0)
            {
                MessageBox.Show(this, "نام کاربری مدیر نمی‌تواند خالی باشد.",
                    "Options", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtAdminUser.Focus();
                return;
            }
            if (_txtAdminPass.Text.Length > 0 && _txtAdminPass.Text.Length < 4)
            {
                MessageBox.Show(this, "رمز مدیر باید دست‌کم ۴ حرف باشد.",
                    "Options", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtAdminPass.Focus();
                return;
            }
            string serverHost = _txtServerIp.Text.Trim();
            if (Uri.CheckHostName(serverHost) == UriHostNameType.Unknown)
            {
                MessageBox.Show(this, "آدرس سرور معتبر نیست.",
                    "Options", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtServerIp.Focus();
                return;
            }

            ClientOptions.SetSuperAdmin(adminUser, _txtAdminPass.Text);
            if (!string.Equals(serverHost, ConnectionSettings.ServerHost, StringComparison.OrdinalIgnoreCase))
            {
                ConnectionSettings.ServerHost = serverHost;
                if (!ConnectionSettings.Save())
                    MessageBox.Show(this, "آدرس سرور ذخیره نشد: " + ConnectionSettings.LastError,
                        "Options", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ServerAddressChanged = true;
            }
            ClientOptions.AutoDiscovery = _chkAuto.Checked;

            ClientOptions.DefaultWallpaper = _txtWallpaper.Text;
            ClientOptions.DisableCafeteria    = _chkDisableCafeteria.Checked;
            ClientOptions.DisableHide         = _chkDisableHide.Checked;
            ClientOptions.DisableLogout       = _chkDisableLogout.Checked;
            ClientOptions.DisableAltEnter     = _chkDisableAltEnter.Checked;
            ClientOptions.DisableLoginRequest = _chkDisableLoginRequest.Checked;
            ClientOptions.UsbProtection       = _chkUsbProtection.Checked;
            ClientOptions.TerminateOnLogout   = _chkTerminateOnLogout.Checked;
            ClientOptions.HideUsedTime        = _chkHideUsedTime.Checked;
            ClientOptions.HideCost            = _chkHideCost.Checked;
            ClientOptions.HideRemainingTime   = _chkHideRemainingTime.Checked;
            ClientOptions.HideStartTime       = _chkHideStartTime.Checked;
            ClientOptions.GameFolders = _txtGameFolders.Text.Trim();

            if (_lvAdapters.SelectedItems.Count > 0)
            {
                string mac = _lvAdapters.SelectedItems[0].Tag as string;
                if (!string.IsNullOrEmpty(mac)) ClientOptions.SelectedAdapterMac = mac;
            }

            ClientOptions.OnTimeEndMinutes = (int)_numOnTimeEndMinutes.Value;
            // The OnTimeEnd/OnLogin/OnLogout message + sound textboxes are
            // always current — they hold the latest persisted value, updated
            // when the operator switches events.
            ClientOptions.OnTimeEndMessage = _txtOnTimeEndMessage.Text;
            ClientOptions.OnTimeEndSound = _txtOnTimeEndSound.Text;
            ClientOptions.OnLoginMessage = _txtOnLoginMessage.Text;
            ClientOptions.OnLoginSound = _txtOnLoginSound.Text;
            ClientOptions.OnLogoutMessage = _txtOnLogoutMessage.Text;
            ClientOptions.OnLogoutSound = _txtOnLogoutSound.Text;
            ClientOptions.BuiltInSounds = _chkBuiltInSounds.Checked;

            ClientOptions.ServerClientPassword = _txtServerClientPassword.Text;

            // Round 6: right-column tab. The boxes that share a setting with the
            // Options tab are kept opposite to it, so both write the same value.
            for (int i = 0; i < _columnItems.Length; i++)
                _columnItems[i].SetHidden(!_columnChecks[i].Checked);

            ClientOptions.Save();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
