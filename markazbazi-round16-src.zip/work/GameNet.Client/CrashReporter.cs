using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using Newtonsoft.Json;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;

namespace GameNet.Client
{
    /// <summary>
    /// Phase 10.5 — Crash reporter. When an unhandled exception occurs,
    /// builds a CrashReportPayload and sends it to the server via a
    /// best-effort UDP "fire and forget" packet (so we don't depend on the
    /// TCP connection still being alive). Also writes the crash log to a
    /// local file so it can be retried on the next successful connection.
    ///
    /// The crash payload includes:
    ///   - Station name + machine fingerprint
    ///   - Client version
    ///   - Exception type + message + stack trace
    ///   - Last action (from a static tracker that other modules update)
    ///   - Crash timestamp
    /// </summary>
    public static class CrashReporter
    {
        /// <summary>
        /// The last significant action the client performed (e.g.
        /// "Login", "Logout"). Other modules should update this so the
        /// crash report has context about what was happening when the
        /// crash occurred. No module updates it yet, so every crash
        /// report currently shows "startup".
        /// </summary>
        public static string LastAction = "startup";
        private static readonly object _flushLock = new object(); // round 14

        private const string CrashLogDir = "crash_logs";
        private const int MaxSavedCrashes = 20;
        // FIX M11: per-field size caps so a crash-looping kiosk can't fill
        // the disk with 50KB+ stack traces. 8KB is enough for ~100 stack
        // frames (far more than any real exception produces).
        private const int MaxStackTraceLength = 8 * 1024;       // 8 KB
        private const int MaxExceptionMessageLength = 2 * 1024;  // 2 KB

        /// <summary>
        /// Reports a crash. Writes to the local crash log dir AND attempts
        /// to send to the server if a connection is available.
        /// </summary>
        public static void Report(Exception ex, string source = "Unhandled")
        {
            if (ex == null) return;

            // Self-repair: record the diagnosis first (code + Persian explanation). The
            // explanation is shown on the next start (FaultJournal.TakePendingReport).
            try { FaultJournal.RecordCrash(FaultCatalog.ClassifyException(ex, false), ex, "Client " + source); } catch { }

            try
            {
                var payload = new CrashReportPayload
                {
                    StationName = Environment.MachineName,
                    MachineFingerprint = ClientLicenseFingerprint.Generate(),
                    ClientVersion = Protocol.ServerVersion,
                    ExceptionType = ex.GetType().Name,
                    ExceptionMessage = ex.Message ?? "",
                    StackTrace = ex.StackTrace ?? "",
                    CrashedAt = DateTime.UtcNow,
                    LastAction = LastAction
                };

                // 1. Write to local crash log
                SaveLocally(payload, source);

                // 2. Try to send to server via TCP (best-effort)
                TrySendToServer(payload);
            }
            catch { /* never throw from the crash reporter */ }
        }

        /// <summary>
        /// Called by ClientEngine after a successful reconnect to flush any
        /// saved crash logs that couldn't be sent at crash time.
        /// FIX 25: takes a Func that returns bool (true = send succeeded).
        /// The crash file is deleted ONLY on success — previously it was
        /// deleted unconditionally, so transient network failures or server
        /// rejections silently lost crash reports forever.
        /// </summary>
        /// <summary>
        /// Round 12: the guard restarted the kiosk. Saved like a crash report, so the
        /// server receives it at the next connection and tells the operator.
        /// </summary>
        public static void ReportRestart(string code, string detail)
        {
            try
            {
                var payload = new CrashReportPayload
                {
                    StationName = Environment.MachineName,
                    MachineFingerprint = ClientLicenseFingerprint.Generate(),
                    ClientVersion = Protocol.ServerVersion,
                    ExceptionType = "GuardRestart:" + (code ?? ""),
                    ExceptionMessage = detail ?? "",
                    StackTrace = "",
                    CrashedAt = DateTime.UtcNow,
                    LastAction = LastAction
                };
                SaveLocally(payload, "Restart");
            }
            catch { }
        }

        /// <summary>
        /// Round 14: a local kiosk event for the server's activity journal ("settings" or
        /// "station"). Saved like a crash report and sent on the existing message, so the
        /// operator sees it even if the kiosk was offline at the time.
        /// </summary>
        public static void ReportEvent(string kind, string text)
        {
            try
            {
                var payload = new CrashReportPayload
                {
                    StationName = Environment.MachineName,
                    MachineFingerprint = "",
                    ClientVersion = Protocol.ServerVersion,
                    ExceptionType = "Event:" + (kind ?? "station"),
                    ExceptionMessage = text ?? "",
                    StackTrace = "",
                    CrashedAt = DateTime.UtcNow,
                    LastAction = LastAction
                };
                SaveLocally(payload, "Event");
            }
            catch { }
        }

        /// <param name="max">Round 15: at most this many per call. The server accepts 30
        /// messages a minute from a station and then ignores it for 15 minutes, so a
        /// backlog of saved reports must not go out in one burst.</param>
        public static void FlushPendingCrashes(Func<CrashReportPayload, bool> sendAction, int max = 5)
        {
            // Round 14: one flush at a time (connect and a new kiosk event can overlap).
            lock (_flushLock)
            {
                try
                {
                    string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, CrashLogDir);
                    if (!Directory.Exists(dir)) return;

                    var files = Directory.GetFiles(dir, "*.json");
                    Array.Sort(files, StringComparer.Ordinal); // round 14: oldest first (names start with the time)
                    int sentCount = 0;
                    foreach (var file in files)
                    {
                        if (sentCount >= max) break; // the rest goes with the next heartbeat
                        try
                        {
                            string json = File.ReadAllText(file);
                            var payload = JsonConvert.DeserializeObject<CrashReportPayload>(json);
                            if (payload != null)
                            {
                                bool sent = sendAction(payload);
                                sentCount++;
                                if (sent)
                                {
                                    try { File.Delete(file); } catch { }
                                }
                                // else: leave the file on disk for the next attempt.
                            }
                        }
                        catch { }
                    }
                }
                catch { }
        
            }
        }

        private static void SaveLocally(CrashReportPayload payload, string source)
        {
            try
            {
                string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, CrashLogDir);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);

                // FIX M11: cap the StackTrace + ExceptionMessage length so a
                // crash-looping kiosk can't fill the disk. A full StackTrace
                // can be 50KB+ on deeply-nested exceptions; with MaxSavedCrashes
                // = 20 that's up to 1MB per crash-loop episode, and a tight
                // crash loop can produce 20 crashes in seconds. Truncating to
                // 8KB for the stack trace and 2KB for the message keeps each
                // file under ~10KB (20 files = 200KB max — negligible).
                if (payload.StackTrace != null && payload.StackTrace.Length > MaxStackTraceLength)
                    payload.StackTrace = payload.StackTrace.Substring(0, MaxStackTraceLength)
                        + "\n... [truncated — full trace was "
                        + payload.StackTrace.Length + " chars]";
                if (payload.ExceptionMessage != null && payload.ExceptionMessage.Length > MaxExceptionMessageLength)
                    payload.ExceptionMessage = payload.ExceptionMessage.Substring(0, MaxExceptionMessageLength)
                        + "... [truncated]";

                // Round 14: milliseconds + a short random part, so two reports in the same
                // second (a kiosk event and an exit) no longer overwrite each other.
                string filename = $"crash_{DateTime.UtcNow:yyyyMMdd_HHmmss_fff}_{source}_{Guid.NewGuid().ToString("N").Substring(0, 6)}.json";
                string path = Path.Combine(dir, filename);
                string json = JsonConvert.SerializeObject(payload, Formatting.Indented);
                File.WriteAllText(path, json, Encoding.UTF8);

                // Prune old crash logs
                var files = Directory.GetFiles(dir, "*.json");
                if (files.Length > MaxSavedCrashes)
                {
                    Array.Sort(files, (a, b) => File.GetCreationTimeUtc(a).CompareTo(File.GetCreationTimeUtc(b)));
                    for (int i = 0; i < files.Length - MaxSavedCrashes; i++)
                        try { File.Delete(files[i]); } catch { }
                }
            }
            catch { }
        }

        private static void TrySendToServer(CrashReportPayload payload)
        {
            // Best-effort: if the ClientEngine has an active connection,
            // it will flush the crash log on next connect. We don't try
            // to open a new TCP connection here because the process may
            // be dying. The local file ensures the report is never lost.
        }
    }
}
