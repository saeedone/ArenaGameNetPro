using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using GameNet.Shared;

namespace GameNet.Client
{
    // === CRITICAL: Auto-close games on time expire ===
    public static class GameKiller
    {
        private static List<string> _killedProcesses = new List<string>();

        public static void KillAllGames()
        {
            try
            {
                // Round 10: the folders come from the Options dialog (ClientOptions.GameFolders);
                // before, only C:\Games and D:\Games were checked.
                var allowedRoots = GameRoots();

                foreach (var proc in Process.GetProcesses())
                {
                    try
                    {
                        if (proc.MainWindowHandle == IntPtr.Zero) continue;
                        string name = proc.ProcessName.ToLower();
                        if (name == "gamenet.client" || name == "explorer" || name == "csrss" || name == "svchost") continue;

                        string exePath = "";
                        try { exePath = proc.MainModule?.FileName ?? ""; } catch { }

                        if (!string.IsNullOrEmpty(exePath))
                        {
                            foreach (var root in allowedRoots)
                            {
                                if (exePath.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                                {
                                    try { proc.Kill(); _killedProcesses.Add(name); }
                                    catch { }
                                    break;
                                }
                            }
                        }
                    }
                    catch { }
                }
                AuditLogSafe($"KillAllGames: killed { _killedProcesses.Count} processes");
            }
            catch { }
        }

        /// <summary>
        /// Round 10: ClientOptions.GameFolders split on ';'. Each folder ends in a
        /// backslash, so "C:\Games" does not also match "C:\GamesOld"; a bare drive such
        /// as "C:\" is skipped, so a slip cannot close every program on the disk.
        /// </summary>
        private static string[] GameRoots()
        {
            var roots = new List<string>();
            foreach (string part in (ClientOptions.GameFolders ?? "").Split(';'))
            {
                string root = part.Trim().Trim('"').TrimEnd('\\', '/');
                if (root.Length <= 2) continue;
                roots.Add(root + "\\");
            }
            return roots.ToArray();
        }

        private static void AuditLogSafe(string msg)
        {
            try { File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_log.txt"), $"{DateTime.UtcNow:o}  {msg}{Environment.NewLine}"); } catch { }
        }
    }

    // === CRITICAL: Pause session panel ===
    public class PausePanel : UserControl
    {
        private ClientEngine _engine;
        private Label _lblInfo;
        private NumericUpDown _numMinutes;
        private Button _btnPause;

        public PausePanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "⏸️ توقف موقت نشست", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(249, 226, 175), Location = new Point(20, 15), AutoSize = true };

            _lblInfo = new Label { Text = "می‌توانید نشست خود را تا ۵ دقیقه متوقف کنید.\nهزینه در این مدت متوقف می‌شود.\n(مثلاً برای استراحت یا دستشویی)", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 55), Size = new Size(700, 60) };

            var lblMin = new Label { Text = "مدت توقف (دقیقه):", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 130), AutoSize = true };
            _numMinutes = new NumericUpDown { Location = new Point(200, 127), Size = new Size(100, 30), Minimum = 1, Maximum = 5, Value = 3, Font = new Font("Segoe UI", 12F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };

            _btnPause = new Button { Text = "⏸️ توقف موقت", Location = new Point(20, 170), Size = new Size(200, 40), BackColor = Color.FromArgb(249, 226, 175), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnPause.Click += (s, e) =>
            {
                try
                {
                    // Send pause request to server
                    _engine.SendSafe(new NetMessage(MessageType.ClientPauseSession,
                        new PauseRequestPayload { Username = _engine.Username ?? "", StationName = Environment.MachineName, Minutes = (int)_numMinutes.Value, Reason = "درخواست کاربر" }, _engine.SessionId));
                    MessageBox.Show(this, "درخواست توقف ارسال شد.\nمنتظر تأیید اپراتور بمانید.", "توقف موقت", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch { }
            };

            this.Controls.AddRange(new Control[] { lblTitle, _lblInfo, lblMin, _numMinutes, _btnPause });
        }
    }

    // === HIGH: Food ordering panel ===
    public class FoodPanel : UserControl
    {
        private ClientEngine _engine;
        private ListView _lvItems;
        private NumericUpDown _numQty;
        private ListView _lvCart;
        private Label _lblTotal;
        private Button _btnOrder;
        private List<FoodOrderItem> _cart = new List<FoodOrderItem>();

        public FoodPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "🍔 سفارش غذا", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(166, 227, 161), Location = new Point(20, 15), AutoSize = true };

            // Sample menu (in production, fetched from server)
            _lvItems = new ListView { Location = new Point(20, 55), Size = new Size(350, 350), View = View.Details, FullRowSelect = true, BackColor = Color.FromArgb(40, 40, 60), ForeColor = Color.FromArgb(40, 40, 40) };
            _lvItems.Columns.Add("نام", 200);
            _lvItems.Columns.Add("قیمت", 100);
            _lvItems.Items.Add(new ListViewItem(new[] { "پیتزا", "80,000" }));
            _lvItems.Items.Add(new ListViewItem(new[] { "برگر", "65,000" }));
            _lvItems.Items.Add(new ListViewItem(new[] { "نوشابه", "15,000" }));
            _lvItems.Items.Add(new ListViewItem(new[] { "چای", "10,000" }));
            _lvItems.Items.Add(new ListViewItem(new[] { "قهوه", "25,000" }));
            _lvItems.Items.Add(new ListViewItem(new[] { "ساندویچ", "50,000" }));

            var lblQty = new Label { Text = "تعداد:", Location = new Point(20, 420), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _numQty = new NumericUpDown { Location = new Point(80, 417), Size = new Size(60, 30), Minimum = 1, Maximum = 20, Value = 1, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnAdd = new Button { Text = "➕ افزودن", Location = new Point(150, 415), Size = new Size(100, 35), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            btnAdd.Click += (s, e) => AddToCart();

            _lvCart = new ListView { Location = new Point(400, 55), Size = new Size(350, 350), View = View.Details, FullRowSelect = true, BackColor = Color.FromArgb(40, 40, 60), ForeColor = Color.FromArgb(40, 40, 40) };
            _lvCart.Columns.Add("آیتم", 200);
            _lvCart.Columns.Add("تعداد", 50);
            _lvCart.Columns.Add("قیمت", 80);

            _lblTotal = new Label { Text = "💰 مجموع: 0 تومان", Location = new Point(400, 420), AutoSize = true, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(166, 227, 161) };

            _btnOrder = new Button { Text = "📤 سفارش", Location = new Point(600, 415), Size = new Size(150, 35), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnOrder.Click += (s, e) => PlaceOrder();

            this.Controls.AddRange(new Control[] { lblTitle, _lvItems, lblQty, _numQty, btnAdd, _lvCart, _lblTotal, _btnOrder });
        }

        private void AddToCart()
        {
            if (_lvItems.SelectedItems.Count == 0) return;
            var item = _lvItems.SelectedItems[0];
            string name = item.SubItems[0].Text;
            decimal price = decimal.Parse(item.SubItems[1].Text.Replace(",", ""), System.Globalization.NumberStyles.Any);
            int qty = (int)_numQty.Value;

            _cart.Add(new FoodOrderItem { Name = name, Quantity = qty, Price = price });
            _lvCart.Items.Add(new ListViewItem(new[] { name, qty.ToString(), (price * qty).ToString("N0") }));
            UpdateTotal();
        }

        private void UpdateTotal()
        {
            decimal total = _cart.Sum(i => i.Price * i.Quantity);
            _lblTotal.Text = $"💰 مجموع: {total:N0} تومان";
        }

        private void PlaceOrder()
        {
            if (_cart.Count == 0) { MessageBox.Show("سبد خالی است."); return; }
            decimal total = _cart.Sum(i => i.Price * i.Quantity);
            try
            {
                _engine.SendSafe(new NetMessage(MessageType.ClientFoodOrder,
                    new FoodOrderPayload { Username = _engine.Username ?? "", StationName = Environment.MachineName, Items = _cart, TotalAmount = total, Notes = "", OrderedAt = DateTime.UtcNow }, _engine.SessionId));
                MessageBox.Show("✅ سفارش ارسال شد!\nمبلغ از اعتبار شما کسر خواهد شد.", "سفارش غذا", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _cart.Clear();
                _lvCart.Items.Clear();
                UpdateTotal();
            }
            catch { }
        }
    }

    // === HIGH: Session history panel ===
    public class HistoryPanel : UserControl
    {
        private ClientEngine _engine;
        private DataGridView _dgv;
        private Label _lblSummary;
        // FIX (FIX-CLIENT-BUGS B6): store the handler so we can unsubscribe in
        // Dispose and so we can subscribe BEFORE sending the request.
        private Action<SessionHistoryPayload> _historyHandler;

        public HistoryPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "📋 تاریخچه نشست‌ها", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(137, 180, 250), Location = new Point(20, 15), AutoSize = true };

            _dgv = new DataGridView { Location = new Point(20, 55), Size = new Size(750, 350), BackgroundColor = Color.FromArgb(40, 40, 60), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false, DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(40, 40, 60), ForeColor = Color.FromArgb(40, 40, 40) }, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(137, 180, 250), Font = new Font("Segoe UI", 9F, FontStyle.Bold) }, EnableHeadersVisualStyles = false };
            _dgv.Columns.Add("colDate", "تاریخ");
            _dgv.Columns.Add("colDur", "مدت (دقیقه)");
            _dgv.Columns.Add("colCost", "هزینه");
            _dgv.Columns.Add("colStation", "ایستگاه");
            _dgv.Columns.Add("colGame", "بازی");

            _lblSummary = new Label { Text = "📊 خلاصه: در حال بارگذاری...", Location = new Point(20, 420), AutoSize = true, Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(166, 227, 161) };

            // FIX (FIX-CLIENT-BUGS B6): subscribe to OnSessionHistory BEFORE
            // sending the request — the previous order (SendSafe → +=) had a
            // race where the server's reply could arrive on the read thread
            // and raise OnSessionHistory BEFORE the += line executed, so the
            // panel would silently miss the history update and stay on
            // "در حال بارگذاری..." forever.
            if (_engine != null)
            {
                _historyHandler = (hist) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        _dgv.Rows.Clear();
                        foreach (var s in hist.Sessions)
                            _dgv.Rows.Add(s.StartTime.ToLocalTime().ToString("yyyy/MM/dd HH:mm"), s.DurationMinutes, s.Cost.ToString("N0") + " ت", s.StationName, s.CurrentGame ?? "-");
                        _lblSummary.Text = $"📊 کل نشست‌ها: {hist.TotalSessions} | کل زمان: {hist.TotalMinutes} دقیقه | کل هزینه: {hist.TotalSpent:N0} تومان";
                    }
                    catch { /* disposed */ }
                }));
                _engine.OnSessionHistory += _historyHandler;
                // Request history from server
                try { _engine.SendSafe(new NetMessage(MessageType.ClientSessionHistory, null, _engine.SessionId)); } catch { }
            }

            this.Controls.AddRange(new Control[] { lblTitle, _dgv, _lblSummary });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _engine != null && _historyHandler != null)
            {
                try { _engine.OnSessionHistory -= _historyHandler; } catch { }
            }
            base.Dispose(disposing);
        }
    }

    // === HIGH: Guest login button ===
    public class GuestLoginButton
    {
        public static void Show(ClientEngine engine)
        {
            var dlg = new Form
            {
                Text = "🎮 ورود مهمان",
                Size = new Size(400, 250),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                RightToLeft = RightToLeft.Yes,
            };

            var lbl = new Label { Text = "🎮 ورود مهمان\n\nبا این روش بدون حساب کاربری می‌توانید بازی کنید.\nمبلغ را پیشاپیش پرداخت می‌کنید.", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 15), Size = new Size(350, 60) };
            var lblMin = new Label { Text = "مدت (دقیقه):", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var numMin = new NumericUpDown { Location = new Point(150, 77), Size = new Size(80, 30), Minimum = 10, Maximum = 300, Value = 60, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnOk = new Button { Text = "🎮 شروع", Location = new Point(50, 130), Size = new Size(140, 38), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.OK };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(210, 130), Size = new Size(140, 38), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.Cancel };

            dlg.Controls.AddRange(new Control[] { lbl, lblMin, numMin, btnOk, btnCancel });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    engine.SendSafe(new NetMessage(MessageType.ClientGuestLogin,
                        new GuestLoginPayload { StationName = Environment.MachineName, MachineName = Environment.MachineName, MacAddress = NetworkClient.GetMacAddress(), Minutes = (int)numMin.Value, PrepaidAmount = 0 }, engine.SessionId));
                }
                catch { }
            }
        }
    }

    // === MEDIUM: Leaderboard panel ===
    public class LeaderboardPanel : UserControl
    {
        private ClientEngine _engine;

        public LeaderboardPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "🏆 رتبه‌بندی برترین کاربران", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(250, 179, 135), Location = new Point(20, 15), AutoSize = true };

            var dgv = new DataGridView { Location = new Point(20, 55), Size = new Size(750, 400), BackgroundColor = Color.FromArgb(40, 40, 60), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false, DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(40, 40, 60), ForeColor = Color.FromArgb(40, 40, 40) }, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(250, 179, 135), Font = new Font("Segoe UI", 9F, FontStyle.Bold) }, EnableHeadersVisualStyles = false };
            dgv.Columns.Add("colRank", "رتبه");
            dgv.Columns.Add("colName", "نام");
            dgv.Columns.Add("colMin", "کل زمان (دقیقه)");
            dgv.Columns.Add("colSpent", "کل هزینه");
            dgv.Columns.Add("colSess", "تعداد نشست");

            // Sample data (in production from server)
            dgv.Rows.Add("🥇 1", "علی", "1250", "350,000", "28");
            dgv.Rows.Add("🥈 2", "رضا", "980", "280,000", "22");
            dgv.Rows.Add("🥉 3", "سارا", "750", "210,000", "18");
            dgv.Rows.Add("4", "محمد", "600", "180,000", "15");
            dgv.Rows.Add("5", "زهرا", "500", "150,000", "12");

            this.Controls.AddRange(new Control[] { lblTitle, dgv });
        }
    }

    // === MEDIUM: Night mode ===
    public static class NightMode
    {
        public static bool Enabled = false;

        public static void Toggle(Form form)
        {
            Enabled = !Enabled;
            if (Enabled)
            {
                form.BackColor = Color.FromArgb(10, 10, 20);
                form.Opacity = 0.85;
            }
            else
            {
                form.BackColor = Color.FromArgb(240, 240, 240);
                form.Opacity = 1.0;
            }
        }
    }

    // === MEDIUM: Volume slider ===
    public class VolumePanel : UserControl
    {
        [DllImport("user32.dll")]
        private static extern int waveOutSetVolume(IntPtr hwo, uint dwVolume);

        public VolumePanel()
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "🔊 تنظیم صدا", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(203, 166, 247), Location = new Point(20, 15), AutoSize = true };

            var lblVolume = new Label { Text = "سطح صدا:", Location = new Point(20, 60), AutoSize = true, Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(40, 40, 40) };

            var slider = new TrackBar { Location = new Point(120, 55), Size = new Size(400, 50), Minimum = 0, Maximum = 100, Value = 50, TickFrequency = 10 };

            var lblPct = new Label { Text = "50%", Location = new Point(540, 60), AutoSize = true, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(166, 227, 161) };

            var btnMute = new Button { Text = "🔇 قطع کامل", Location = new Point(20, 120), Size = new Size(150, 38), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            btnMute.Click += (s, e) => { slider.Value = 0; lblPct.Text = "0% (بی‌صدا)"; SetVolume(0); };

            slider.Scroll += (s, e) =>
            {
                lblPct.Text = slider.Value + "%";
                SetVolume(slider.Value);
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblVolume, slider, lblPct, btnMute });
        }

        private void SetVolume(int percent)
        {
            try
            {
                uint vol = (uint)(percent * 65535 / 100);
                vol = (vol & 0xFFFF) | (vol << 16);
                waveOutSetVolume(IntPtr.Zero, vol);
            }
            catch { }
        }
    }

}
