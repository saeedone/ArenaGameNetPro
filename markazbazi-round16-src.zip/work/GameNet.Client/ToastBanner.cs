using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// A small non-modal toast banner shown over the top-right of the kiosk
    /// form. Used by the time-warning system (5-min / 1-min / 0-min) so the
    /// player sees a visible banner without being blocked by a modal dialog
    /// (which would interrupt the running game).
    ///
    /// The banner is:
    ///   - topmost, no activation (doesn't steal focus from the game)
    ///   - auto-dismisses after `autoCloseMs` (default 5s)
    ///   - colored by Level (info / warning / critical)
    ///   - pulses briefly to grab attention
    /// </summary>
    public class ToastBanner : Form
    {
        private Timer _pulseTimer;
        private Timer _autoCloseTimer;
        private int _pulsePhase;
        private string _title;
        private string _body;
        private Color _bannerColor;
        private Color _textColor = Color.White;

        public ToastBanner(string title, string body, string level, int autoCloseMs = 5000)
        {
            _title = title ?? "";
            _body = body ?? "";

            switch ((level ?? "info").ToLowerInvariant())
            {
                case "critical":
                case "error":
                    _bannerColor = Color.FromArgb(220, 38, 38);
                    break;
                case "warning":
                    _bannerColor = Color.FromArgb(234, 179, 8);
                    _textColor = Color.FromArgb(20, 20, 20);
                    break;
                default:
                    _bannerColor = Color.FromArgb(56, 189, 248);
                    _textColor = Color.FromArgb(20, 20, 20);
                    break;
            }

            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.TopMost = true;
            this.ShowInTaskbar = false;
            this.Width = 360;
            this.Height = 90;
            this.DoubleBuffered = true;
            // Position at top-right of the primary screen (RTL → top-left visually
            // because the kiosk sidebar is on the right).
            try
            {
                var area = Screen.PrimaryScreen.WorkingArea;
                this.Location = new Point(area.Right - this.Width - 20, area.Top + 20);
            }
            catch { this.Location = new Point(20, 20); }

            _pulseTimer = new Timer { Interval = 200 };
            _pulseTimer.Tick += (s, e) => { _pulsePhase++; this.Invalidate(); };
            _pulseTimer.Start();

            _autoCloseTimer = new Timer { Interval = autoCloseMs };
            _autoCloseTimer.Tick += (s, e) =>
            {
                try { _pulseTimer.Stop(); _autoCloseTimer.Stop(); this.Close(); } catch { }
            };
            _autoCloseTimer.Start();
        }

        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW — doesn't steal focus
                // from the running game, and doesn't show in Alt-Tab.
                cp.ExStyle |= 0x08000000 | 0x80;
                return cp;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            // Pulse the banner color slightly so the user notices it.
            float pulse = (float)(0.85 + 0.15 * Math.Sin(_pulsePhase * 0.5));
            Color c = Color.FromArgb(
                Math.Min(255, (int)(_bannerColor.R * pulse)),
                Math.Min(255, (int)(_bannerColor.G * pulse)),
                Math.Min(255, (int)(_bannerColor.B * pulse)));

            // Rounded background.
            try
            {
                using (var path = RoundedRect(this.ClientRectangle, 14))
                using (var brush = new SolidBrush(c))
                {
                    g.FillPath(brush, path);
                }
                // Border.
                using (var path = RoundedRect(this.ClientRectangle, 14))
                using (var pen = new Pen(Color.FromArgb(80, 80, 80), 1))
                {
                    g.DrawPath(pen, path);
                }
            }
            catch
            {
                using (var brush = new SolidBrush(c))
                    g.FillRectangle(brush, this.ClientRectangle);
            }

            // Title.
            using (var fontTitle = new Font("Segoe UI", 11F, FontStyle.Bold))
            using (var brushTitle = new SolidBrush(_textColor))
            {
                var sf = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Near };
                if (this.RightToLeft == RightToLeft.Yes) sf.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
                var titleRect = new RectangleF(15, 8, this.Width - 30, 25);
                g.DrawString(_title, fontTitle, brushTitle, titleRect, sf);
            }

            // Body.
            using (var fontBody = new Font("Segoe UI", 12F))
            using (var brushBody = new SolidBrush(_textColor))
            {
                var sf = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center };
                if (this.RightToLeft == RightToLeft.Yes) sf.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
                var bodyRect = new RectangleF(15, 35, this.Width - 30, 45);
                g.DrawString(_body, fontBody, brushBody, bodyRect, sf);
            }
        }

        private static GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { _pulseTimer?.Stop(); _pulseTimer?.Dispose(); } catch { }
            try { _autoCloseTimer?.Stop(); _autoCloseTimer?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }
}
