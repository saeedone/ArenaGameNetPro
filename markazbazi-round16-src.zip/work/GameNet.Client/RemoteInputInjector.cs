using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using GameNet.Shared;

namespace GameNet.Client
{
    /// <summary>
    /// NEW FEATURE (remote input, per request): injects mouse and keyboard
    /// events received from the operator's live monitoring view, using the
    /// Win32 SendInput API. This is what makes "remote control" a real,
    /// built-in feature rather than a launcher for Windows' own Remote
    /// Desktop (mstsc.exe) — which requires the client to run Windows
    /// Pro/Enterprise to even accept an incoming session; Home editions
    /// can't, silently, with nothing in this codebase checking for or
    /// reporting that. SendInput works on every Windows edition, since it
    /// only requires this process to be running — no incoming-connection
    /// server role on the client at all.
    ///
    /// SECURITY NOTE: this only runs when the server the client is already
    /// connected to (over the same authenticated, already-established TCP
    /// connection used for everything else) sends a ServerRemoteInput
    /// message — it doesn't open any new listening port or accept
    /// connections from anyone else. The same trust boundary already
    /// covers everything else this server can do to a client (locking the
    /// station, adding credit, shutting it down), so this doesn't introduce
    /// a new one.
    /// </summary>
    internal static class RemoteInputInjector
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public InputUnion U;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        private const uint INPUT_MOUSE = 0;
        private const uint INPUT_KEYBOARD = 1;
        private const uint MOUSEEVENTF_MOVE = 0x0001;
        private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const uint MOUSEEVENTF_LEFTUP = 0x0004;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const uint MOUSEEVENTF_RIGHTUP = 0x0010;
        private const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        private const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
        private const uint MOUSEEVENTF_WHEEL = 0x0800;
        private const uint KEYEVENTF_KEYUP = 0x0002;

        public static void Inject(RemoteInputPayload ri)
        {
            try
            {
                switch (ri.InputType)
                {
                    case "mousemove":
                    case "mousedown":
                    case "mouseup":
                        MoveTo(ri.NormX, ri.NormY);
                        if (ri.InputType == "mousedown") SendMouseButton(ri.Button, down: true);
                        else if (ri.InputType == "mouseup") SendMouseButton(ri.Button, down: false);
                        break;
                    case "mousewheel":
                        MoveTo(ri.NormX, ri.NormY);
                        SendMouseWheel(ri.WheelDelta);
                        break;
                    case "keydown":
                        SendKey((Keys)ri.KeyCode, down: true);
                        break;
                    case "keyup":
                        SendKey((Keys)ri.KeyCode, down: false);
                        break;
                }
            }
            catch { /* best-effort — a malformed or out-of-range event should
                       never crash the client */ }
        }

        /// <summary>
        /// Moves the cursor using absolute, normalized (0..65535) screen
        /// coordinates — SendInput's own coordinate system for
        /// MOUSEEVENTF_ABSOLUTE, chosen so this is correct regardless of
        /// the client's actual screen resolution, matching the 0.0–1.0
        /// normalized coordinates the server sends.
        /// </summary>
        private static void MoveTo(double normX, double normY)
        {
            normX = Clamp01(normX);
            normY = Clamp01(normY);
            var input = new INPUT
            {
                type = INPUT_MOUSE,
                U = new InputUnion
                {
                    mi = new MOUSEINPUT
                    {
                        dx = (int)(normX * 65535),
                        dy = (int)(normY * 65535),
                        dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE,
                    }
                }
            };
            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private static void SendMouseButton(string button, bool down)
        {
            uint flag;
            switch (button)
            {
                case "right": flag = down ? MOUSEEVENTF_RIGHTDOWN : MOUSEEVENTF_RIGHTUP; break;
                case "middle": flag = down ? MOUSEEVENTF_MIDDLEDOWN : MOUSEEVENTF_MIDDLEUP; break;
                default: flag = down ? MOUSEEVENTF_LEFTDOWN : MOUSEEVENTF_LEFTUP; break;
            }
            var input = new INPUT { type = INPUT_MOUSE, U = new InputUnion { mi = new MOUSEINPUT { dwFlags = flag } } };
            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private static void SendMouseWheel(int delta)
        {
            var input = new INPUT
            {
                type = INPUT_MOUSE,
                U = new InputUnion { mi = new MOUSEINPUT { dwFlags = MOUSEEVENTF_WHEEL, mouseData = unchecked((uint)delta) } }
            };
            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        [DllImport("user32.dll")]
        private static extern uint MapVirtualKey(uint uCode, uint uMapType);
        private const uint MAPVK_VK_TO_VSC = 0;
        private const uint KEYEVENTF_EXTENDEDKEY = 0x0001;

        // Round 11: the hardware scan code goes with the virtual key. With wScan = 0
        // many games (DirectInput / raw input read scan codes) ignored the operator's
        // keys, and the arrows, Insert/Delete/Home/End/PageUp/PageDown arrived as
        // numeric-keypad keys because the "extended" flag was missing.
        private static bool IsExtended(Keys k)
        {
            switch (k)
            {
                case Keys.Left: case Keys.Right: case Keys.Up: case Keys.Down:
                case Keys.Insert: case Keys.Delete: case Keys.Home: case Keys.End:
                case Keys.PageUp: case Keys.PageDown: case Keys.NumLock: case Keys.Divide:
                case Keys.RControlKey: case Keys.RMenu: case Keys.LWin: case Keys.RWin:
                case Keys.Apps: case Keys.PrintScreen:
                    return true;
                default:
                    return false;
            }
        }

        private static void SendKey(Keys key, bool down)
        {
            ushort vk = (ushort)((int)key & 0xFF);
            if (vk == 0) return;
            ushort scan = 0;
            try { scan = (ushort)MapVirtualKey(vk, MAPVK_VK_TO_VSC); } catch { }
            uint flags = down ? 0u : KEYEVENTF_KEYUP;
            if (IsExtended((Keys)vk)) flags |= KEYEVENTF_EXTENDEDKEY;
            var input = new INPUT
            {
                type = INPUT_KEYBOARD,
                U = new InputUnion { ki = new KEYBDINPUT { wVk = vk, wScan = scan, dwFlags = flags } }
            };
            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private static double Clamp01(double v) => v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
