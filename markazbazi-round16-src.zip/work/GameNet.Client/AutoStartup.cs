using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace GameNet.Client
{
    /// <summary>
    /// Phase — Auto-startup + self-restart watchdog.
    ///
    /// Two layers of protection so the kiosk always comes back:
    ///
    /// 1. AUTOSTART REGISTRY ENTRY
    ///    Registers GameNet.Client.exe in HKLM\...\Run (preferred) or
    ///    HKCU\...\Run (fallback) so Windows launches it at every login.
    ///
    /// 2. SCHEDULED TASK (preferred over Run key on Win10+)
    ///    Creates a scheduled task "GameNetClientWatchdog" that:
    ///      - triggers at logon
    ///      - repeats every 1 minute
    ///      - launches the client only if it isn't already running
    ///    This survives even if someone deletes the Run key.
    ///
    /// 3. IN-PROCESS SELF-RESTART
    ///    If the client process exits unexpectedly (crash, kill via
    ///    non-protected task manager), the scheduled task relaunches it
    ///    within 60 seconds.
    /// </summary>
    public static class AutoStartup
    {
        private const string AppName = "GameNetClient";
        private const string TaskName = "GameNetClientWatchdog";

        /// <summary>
        /// Installs all auto-startup mechanisms. Safe to call multiple times.
        /// </summary>
        public static void Install()
        {
            string exePath = GetExePath();
            if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
            {
                AuditLogSafe("AutoStartup: exe path not found, skipping install.");
                return;
            }

            // 1. Registry Run key (HKLM preferred, HKCU fallback)
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    key?.SetValue(AppName, "\"" + exePath + "\"");
                    AuditLogSafe("AutoStartup: registered in HKLM Run key.");
                }
            }
            catch
            {
                // HKLM needs admin; fall back to HKCU
                try
                {
                    using (var key = Registry.CurrentUser.OpenSubKey(
                        @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                    {
                        key?.SetValue(AppName, "\"" + exePath + "\"");
                        AuditLogSafe("AutoStartup: registered in HKCU Run key (admin denied).");
                    }
                }
                catch (Exception ex) { AuditLogSafe("AutoStartup: registry failed: " + ex.Message); }
            }

            // 2. Scheduled task (most reliable on Win10+) — runs every minute
            try
            {
                InstallScheduledTask(exePath);
            }
            catch (Exception ex) { AuditLogSafe("AutoStartup: scheduled task failed: " + ex.Message); }

            // 3. Make a small watchdog batch file next to the exe so even if
            //    the scheduled task is deleted, double-clicking the watchdog
            //    restores the kiosk. The batch loops forever, checking every
            //    10s if the client is running and relaunching it if not.
            try { InstallWatchdogBatch(exePath); }
            catch (Exception ex) { AuditLogSafe("AutoStartup: watchdog batch failed: " + ex.Message); }
        }

        /// <summary>Removes all auto-startup mechanisms (for uninstall).</summary>
        public static void Uninstall()
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                    key?.DeleteValue(AppName, false);
            }
            catch { }
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                    key?.DeleteValue(AppName, false);
            }
            catch { }

            try { RunSchtasks($"/delete /tn \"{TaskName}\" /f"); } catch { }

            try
            {
                string batch = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet_watchdog.bat");
                if (File.Exists(batch)) File.Delete(batch);
            }
            catch { }
            AuditLogSafe("AutoStartup: uninstalled.");
        }

        // ---- Scheduled task ----

        private static void InstallScheduledTask(string exePath)
        {
            // Delete existing task if present (so we always have a fresh config)
            try { RunSchtasks($"/delete /tn \"{TaskName}\" /f"); } catch { }

            // Build the XML definition — a task that:
            //   - triggers at user logon
            //   - repeats every 1 minute indefinitely
            //   - runs the client (with a guard so multiple instances don't pile up)
            string guardScript = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet_launch.cmd");
            // Round 12: leave the kiosk closed while the admin's maintenance flag exists.
            string maint = GameNet.Shared.SelfHeal.Guardian.MaintenanceFile("Client");
            File.WriteAllText(guardScript,
                "@echo off\r\n" +
                "if exist \"" + maint + "\" exit /b 0\r\n" +
                "tasklist /fi \"imagename eq GameNet.Client.exe\" 2>nul | find /i \"GameNet.Client.exe\" >nul\r\n" +
                "if errorlevel 1 (\r\n" +
                "    start \"\" \"" + exePath + "\"\r\n" +
                ")\r\n");

            string xml = "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                "  <Triggers>\r\n" +
                "    <LogonTrigger>\r\n" +
                "      <Enabled>true</Enabled>\r\n" +
                "    </LogonTrigger>\r\n" +
                "    <TimeTrigger>\r\n" +
                "      <Repetition>\r\n" +
                "        <Interval>PT1M</Interval>\r\n" +
                "        <StopAtDurationEnd>false</StopAtDurationEnd>\r\n" +
                "      </Repetition>\r\n" +
                "      <StartBoundary>2020-01-01T00:00:00</StartBoundary>\r\n" +
                "      <Enabled>true</Enabled>\r\n" +
                "    </TimeTrigger>\r\n" +
                "  </Triggers>\r\n" +
                "  <Principals>\r\n" +
                "    <Principal id=\"Author\">\r\n" +
                "      <LogonType>InteractiveToken</LogonType>\r\n" +
                "      <RunLevel>LeastPrivilege</RunLevel>\r\n" +
                "    </Principal>\r\n" +
                "  </Principals>\r\n" +
                "  <Settings>\r\n" +
                "    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>\r\n" +
                "    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>\r\n" +
                "    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>\r\n" +
                "    <ExecutionTimeLimit>PT5M</ExecutionTimeLimit>\r\n" +
                "    <Enabled>true</Enabled>\r\n" +
                "  </Settings>\r\n" +
                "  <Actions Context=\"Author\">\r\n" +
                "    <Exec>\r\n" +
                "      <Command>\"" + guardScript + "\"</Command>\r\n" +
                "    </Exec>\r\n" +
                "  </Actions>\r\n" +
                "</Task>";

            string xmlPath = Path.Combine(Path.GetTempPath(), "gamenet_task.xml");
            File.WriteAllText(xmlPath, xml, System.Text.Encoding.Unicode);

            // Register the task
            // FIX AUDIT-FIX-POSTUPDATE (carried forward from worklog H5):
            // quote TaskName so a future rename that includes spaces doesn't
            // silently break schtasks parsing.
            RunSchtasks($"/create /tn \"{TaskName}\" /xml \"{xmlPath}\" /f");
            try { File.Delete(xmlPath); } catch { }
            AuditLogSafe("AutoStartup: scheduled task installed.");
        }

        private static void InstallWatchdogBatch(string exePath)
        {
            string batch = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet_watchdog.bat");
            File.WriteAllText(batch,
                "@echo off\r\n" +
                "title GameNet Watchdog\r\n" +
                ":loop\r\n" +
                "if exist \"" + GameNet.Shared.SelfHeal.Guardian.MaintenanceFile("Client") + "\" goto wait\r\n" +
                "tasklist /fi \"imagename eq GameNet.Client.exe\" 2>nul | find /i \"GameNet.Client.exe\" >nul\r\n" +
                "if errorlevel 1 (\r\n" +
                "    start \"\" \"" + exePath + "\"\r\n" +
                "    echo [%date% %time%] Relaunched GameNet.Client.exe\r\n" +
                ")\r\n" +
                ":wait\r\n" +
                "timeout /t 10 /nobreak >nul\r\n" +
                "goto loop\r\n");
        }

        // ---- Helpers ----

        private static string GetExePath()
        {
            try
            {
                var exe = Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(exe) && File.Exists(exe)) return exe;
            }
            catch { }
            try
            {
                var asm = System.Reflection.Assembly.GetExecutingAssembly().Location;
                if (!string.IsNullOrEmpty(asm) && File.Exists(asm)) return asm;
            }
            catch { }
            return "";
        }

        private static void RunSchtasks(string args)
        {
            var psi = new ProcessStartInfo("schtasks.exe", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                WindowStyle = ProcessWindowStyle.Hidden,
            };
            // FIX 18: dispose the Process and kill it on timeout — previously
            // `p` was never disposed (handle leak) and on timeout the orphan
            // schtasks.exe kept running. AutoStartup.Install calls this twice
            // per run and Watchdog.Monitor every 5 min, so this was leaking
            // ~576 processes/day per kiosk.
            using (var p = Process.Start(psi))
            {
                if (p != null && !p.WaitForExit(5000))
                {
                    try { p.Kill(); } catch { }
                }
            }
        }

        private static void AuditLogSafe(string msg)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "startup_log.txt");
                File.AppendAllText(logPath, $"{DateTime.UtcNow:o}  {msg}{Environment.NewLine}");
            }
            catch { }
        }
    }
}
