using System;
using System.IO;
using System.Text;

namespace GameNet.Client
{
    /// <summary>
    /// A simple best-effort activity logger that writes structured events to
    /// `client_activity.log` next to the client exe. Used to track:
    ///   - Login/logout time + username
    ///   - Game launched + duration
    ///   - Topup request + response
    ///   - Chat messages sent
    ///   - USB toggle
    ///
    /// Format: `timestamp | event | details`
    ///
    /// Rotates when the file exceeds 500KB — renames the current file to
    /// `client_activity.log.bak` and starts a new one. Never throws — every
    /// call is wrapped in try/catch so a logging failure can never break
    /// the calling code.
    /// </summary>
    public static class ActivityLogger
    {
        private const long MaxFileBytes = 500 * 1024; // 500 KB
        private static readonly object _lock = new object();

        private static string LogPath => Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "client_activity.log");

        private static string BackupPath => Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "client_activity.log.bak");

        public static void Log(string evt, string details)
        {
            try
            {
                lock (_lock)
                {
                    // Rotate if the file is too large.
                    try
                    {
                        if (File.Exists(LogPath))
                        {
                            var fi = new FileInfo(LogPath);
                            if (fi.Length > MaxFileBytes)
                            {
                                try { if (File.Exists(BackupPath)) File.Delete(BackupPath); } catch { }
                                try { File.Move(LogPath, BackupPath); } catch { }
                            }
                        }
                    }
                    catch { /* ignore rotation failures */ }

                    string line = $"{DateTime.UtcNow:o} | {evt ?? ""} | {details ?? ""}{Environment.NewLine}";
                    File.AppendAllText(LogPath, line, Encoding.UTF8);
                }
            }
            catch { /* best-effort: never throw */ }
        }

        public static void Login(string username)
            => Log("LOGIN", $"username={username ?? ""}");

        public static void Logout(string username, int minutesPlayed)
            => Log("LOGOUT", $"username={username ?? ""}, minutes_played={minutesPlayed}");

        public static void GameLaunched(string gameName)
            => Log("GAME_LAUNCH", $"game={gameName ?? ""}");

        public static void GameClosed(string gameName, int durationMinutes)
            => Log("GAME_CLOSE", $"game={gameName ?? ""}, duration_min={durationMinutes}");

        public static void TopupRequested(decimal amount, string method)
            => Log("TOPUP_REQUEST", $"amount={amount}, method={method ?? ""}");

        public static void TopupResponse(bool approved, decimal amount, string msg)
            => Log("TOPUP_RESPONSE", $"approved={approved}, amount={amount}, msg={msg ?? ""}");

        public static void ChatSent(string preview)
        {
            string p = preview ?? "";
            if (p.Length > 80) p = p.Substring(0, 80);
            Log("CHAT_SEND", $"preview={p}");
        }

        public static void UsbToggled(bool enabled)
            => Log("USB_TOGGLE", $"enabled={enabled}");

        public static void FoodOrdered(string items, decimal total)
            => Log("FOOD_ORDER", $"items={items ?? ""}, total={total}");

        public static void Info(string evt, string details)
            => Log(evt, details);
    }
}
