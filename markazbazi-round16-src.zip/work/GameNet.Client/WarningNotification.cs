﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GameNet.Client
{
    public class WarningNotification : Form
    {
        public WarningNotification(int min, string msg, bool critical)
        {
            this.Text = "هشدار"; this.Size = new Size(400, 280);
            this.BackColor = critical ? Color.FromArgb(80, 30, 30) : Color.FromArgb(60, 50, 20);
            this.FormBorderStyle = FormBorderStyle.None; this.StartPosition = FormStartPosition.CenterParent; this.TopMost = true;
            var icon = new Label { Text = critical ? "⚠" : "⏰", Font = new Font("Segoe UI", 32F), ForeColor = critical ? Color.FromArgb(243, 139, 168) : Color.FromArgb(249, 226, 175), Location = new Point(150, 15), AutoSize = true };
            var title = new Label { Text = critical ? "هشدار بحرانی!" : "هشدار زمان", Font = new Font("Segoe UI", 18F, FontStyle.Bold), ForeColor = critical ? Color.FromArgb(243, 139, 168) : Color.FromArgb(249, 226, 175), Location = new Point(80, 70), AutoSize = true };
            var time = new Label { Text = $"{min} دقیقه باقی‌مانده", Font = new Font("Segoe UI", 24F, FontStyle.Bold), ForeColor = critical ? Color.FromArgb(243, 139, 168) : Color.FromArgb(249, 226, 175), Location = new Point(60, 110), AutoSize = true };
            var body = new Label { Text = msg, Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(50, 165), AutoSize = true };
            var btn = new Button { Text = "تایید", Location = new Point(120, 210), Size = new Size(160, 45), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            btn.Click += (s, e) => Close();
            Controls.AddRange(new Control[] { icon, title, time, body, btn });
        }
    }
}
