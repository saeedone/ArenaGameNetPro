using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// Full-screen overlay that warns the user when their session time is
    /// running low or has expired. Shows a big countdown + color-coded
    /// message so the player cannot miss it.
    ///   - Green: more than 10 minutes left (no overlay)
    ///   - Yellow: 5-10 minutes left (small banner)
    ///   - Orange: 2-5 minutes left (medium banner + pulse)
    ///   - Red: under 2 minutes (big countdown + pulse)
    ///   - Expired: full-screen red "TIME EXPIRED" message
    /// </summary>
    public class TimeWarningOverlay : Form
    {
        private Timer _timer;
        private int _minutesRemaining;
        private bool _expired;
        private Color _currentColor;
        private int _pulsePhase;

        public TimeWarningOverlay()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.Bounds.Size;
            this.TopMost = true;
            this.ShowInTaskbar = false;
            this.BackColor = Color.FromArgb(0, 0, 0);
            this.Opacity = 0; // starts hidden
            this.DoubleBuffered = true;

            _timer = new Timer { Interval = 250 };
            _timer.Tick += (s, e) => { _pulsePhase++; this.Invalidate(); };
        }

        /// <summary>
        /// Updates the overlay with the current minutes remaining. Called
        /// by KioskForm's session timer.
        /// </summary>
        public void UpdateTime(int minutesRemaining)
        {
            _minutesRemaining = minutesRemaining;
            _expired = minutesRemaining <= 0;

            if (_expired)
            {
                _currentColor = Color.FromArgb(220, 38, 38); // red
                this.Opacity = 0.85;
                _timer.Start();
            }
            else if (minutesRemaining <= 2)
            {
                _currentColor = Color.FromArgb(239, 68, 68); // red
                this.Opacity = 0.75;
                _timer.Start();
            }
            else if (minutesRemaining <= 5)
            {
                _currentColor = Color.FromArgb(249, 115, 22); // orange
                this.Opacity = 0.6;
                _timer.Start();
            }
            else if (minutesRemaining <= 10)
            {
                _currentColor = Color.FromArgb(234, 179, 8); // yellow
                this.Opacity = 0.45;
                _timer.Stop();
                _pulsePhase = 0;
            }
            else
            {
                // More than 10 min — hide the overlay
                this.Opacity = 0;
                _timer.Stop();
                return;
            }

            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (this.Opacity <= 0) return;

            // Pulse effect: vary opacity slightly
            float pulse = _timer.Enabled ? (float)(0.85 + 0.15 * Math.Sin(_pulsePhase * 0.3)) : 1f;

            // Background gradient
            using (var brush = new LinearGradientBrush(this.ClientRectangle,
                Color.FromArgb((int)(_currentColor.R * pulse), (int)(_currentColor.G * pulse), (int)(_currentColor.B * pulse)),
                Color.FromArgb(20, 20, 30), 90f))
            {
                g.FillRectangle(brush, this.ClientRectangle);
            }

            // Center content
            string title, subtitle, bigText;
            if (_expired)
            {
                title = "⏰ زمان شما به پایان رسید!";
                subtitle = "لطفاً با اپراتور تماس بگیرید";
                bigText = "TIME\nEXPIRED";
            }
            else if (_minutesRemaining <= 2)
            {
                title = "⚠️ هشدار بحرانی!";
                subtitle = "زمان شما رو به اتمام است";
                bigText = $"{_minutesRemaining}:00";
            }
            else if (_minutesRemaining <= 5)
            {
                title = "⚠️ توجه!";
                subtitle = "زمان کم است — شارژ کنید";
                bigText = $"{_minutesRemaining} دقیقه";
            }
            else
            {
                title = "⏱️ یادآوری";
                subtitle = "زمان در حال اتمام";
                bigText = $"{_minutesRemaining} دقیقه";
            }

            var center = new PointF(this.Width / 2f, this.Height / 2f);

            // Big countdown text
            using (var fontBig = new Font("Segoe UI", 120F, FontStyle.Bold))
            using (var fontTitle = new Font("Segoe UI", 36F, FontStyle.Bold))
            using (var fontSub = new Font("Segoe UI", 20F))
            {
                var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };

                // Big text (above center)
                g.DrawString(bigText, fontBig, Brushes.White, new PointF(center.X, center.Y - 60), sf);

                // Title (below center)
                g.DrawString(title, fontTitle, Brushes.White, new PointF(center.X, center.Y + 80), sf);

                // Subtitle
                g.DrawString(subtitle, fontSub, Brushes.White, new PointF(center.X, center.Y + 130), sf);
            }
        }

        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW — doesn't steal focus
                cp.ExStyle |= 0x08000000 | 0x80;
                return cp;
            }
        }

        public void ShowOverlay()
        {
            if (!this.Visible) this.Show();
        }

        public void HideOverlay()
        {
            this.Opacity = 0;
            _timer.Stop();
            if (this.Visible) this.Hide();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop();
            _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
