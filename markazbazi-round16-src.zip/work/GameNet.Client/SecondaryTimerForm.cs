using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// A borderless, topmost, click-through form shown on the SECOND monitor
    /// (when the kiosk detects 2+ displays) so the customer can see the
    /// remaining session time, cost, and balance at a glance while the game
    /// runs full-screen on the primary monitor.
    ///
    /// Shows ONLY: timer (large), cost, balance — no nav, no input.
    /// Updated via UpdateDisplay(el, cost, rem, balance).
    /// </summary>
    public class SecondaryTimerForm : Form
    {
        private string _timeText = "00:00:00";
        private string _costText = "هزینه: ---";
        private string _balanceText = "اعتبار: ---";
        private Color _timeColor = Color.FromArgb(137, 180, 250);
        private Timer _pulseTimer;
        private int _pulsePhase;
        private bool _pulse;

        public SecondaryTimerForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.ShowInTaskbar = false;
            this.BackColor = Color.FromArgb(10, 10, 20);
            this.DoubleBuffered = true;

            // Position on the secondary monitor's bounds.
            try
            {
                var screens = Screen.AllScreens;
                if (screens.Length > 1)
                {
                    var b = screens[1].Bounds;
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new Point(b.X, b.Y);
                    this.Size = new Size(b.Width, b.Height);
                }
            }
            catch { }

            _pulseTimer = new Timer { Interval = 500 };
            _pulseTimer.Tick += (s, e) => { _pulsePhase++; this.Invalidate(); };
        }

        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW — doesn't steal focus
                // and doesn't appear in Alt-Tab.
                cp.ExStyle |= 0x08000000 | 0x80;
                return cp;
            }
        }

        public void UpdateDisplay(TimeSpan elapsed, decimal cost, int? remaining, decimal balance)
        {
            // Round 10: the Options dialog's Hide settings apply on the second monitor too.
            _timeText = ClientOptions.HideUsedTime ? "" : $"{(int)elapsed.TotalHours:D2}:{elapsed.Minutes:D2}:{elapsed.Seconds:D2}";
            _costText = ClientOptions.HideCost ? "" : $"💰 هزینه: {cost:N0} تومان";
            _balanceText = ClientOptions.HideBalance ? "" : $"💳 اعتبار: {balance:N0} تومان";

            // Color code by remaining time.
            if (!remaining.HasValue || ClientOptions.HideRemainingTime)
            {
                _timeColor = Color.FromArgb(137, 180, 250); // blue = unlimited
                _pulse = false;
            }
            else if (remaining.Value <= 1)
            {
                // Pulse between red and dark-red.
                _pulse = true;
                _timeColor = (_pulsePhase % 2 == 0) ? Color.FromArgb(243, 139, 168) : Color.FromArgb(120, 30, 50);
            }
            else if (remaining.Value <= 5)
            {
                _timeColor = Color.FromArgb(243, 139, 168); // red
                _pulse = false;
            }
            else if (remaining.Value <= 10)
            {
                _timeColor = Color.FromArgb(249, 226, 175); // yellow
                _pulse = false;
            }
            else
            {
                _timeColor = Color.FromArgb(166, 227, 161); // green
                _pulse = false;
            }

            if (_pulse && !_pulseTimer.Enabled) _pulseTimer.Start();
            else if (!_pulse && _pulseTimer.Enabled) { _pulseTimer.Stop(); _pulsePhase = 0; }

            try { this.Invalidate(); } catch { }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            var sf = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
            if (this.RightToLeft == RightToLeft.Yes) sf.FormatFlags |= StringFormatFlags.DirectionRightToLeft;

            // Timer (huge).
            using (var fontTime = new Font("Consolas", 96F, FontStyle.Bold))
            using (var brushTime = new SolidBrush(_timeColor))
            {
                g.DrawString(_timeText, fontTime, brushTime,
                    new RectangleF(0, this.Height / 2f - 200, this.Width, 220), sf);
            }

            // Cost.
            using (var fontCost = new Font("Segoe UI", 36F, FontStyle.Bold))
            using (var brushCost = new SolidBrush(Color.FromArgb(249, 226, 175)))
            {
                g.DrawString(_costText, fontCost, brushCost,
                    new RectangleF(0, this.Height / 2f + 50, this.Width, 80), sf);
            }

            // Balance.
            using (var fontBal = new Font("Segoe UI", 32F, FontStyle.Bold))
            using (var brushBal = new SolidBrush(Color.FromArgb(166, 227, 161)))
            {
                g.DrawString(_balanceText, fontBal, brushBal,
                    new RectangleF(0, this.Height / 2f + 150, this.Width, 80), sf);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { _pulseTimer?.Stop(); _pulseTimer?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }
}
