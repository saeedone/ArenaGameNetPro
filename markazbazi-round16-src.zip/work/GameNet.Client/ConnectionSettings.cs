using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using GameNet.Shared.Diagnostics;

namespace GameNet.Client
{
    /// <summary>
    /// Persists the client's server connection settings (IP + port) to a small
    /// settings file. Tries multiple locations so the settings survive even if
    /// the exe folder is read-only (e.g. Program Files).
    ///
    /// FIX M12: the settings file is now encrypted with DPAPI (ProtectedData
    /// with CurrentUser scope) so that another user / process on the same
    /// machine cannot read or tamper with the server IP. Previously the file
    /// was plain text — any process with file access could change host=... to
    /// redirect the kiosk to a malicious server (which would capture the
    /// kiosk's fingerprint and license token). DPAPI ties decryption to the
    /// Windows user who saved the file, so only the kiosk's own user account
    /// can read the settings. Old plain-text files are auto-migrated on the
    /// next Save (read as plain text, re-saved encrypted).
    /// </summary>
    public static class ConnectionSettings
    {
        // Try the exe folder first, then %APPDATA%\GameNet as a fallback.
        private static readonly string SettingsFileExe = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "server_settings.txt");
        private static readonly string SettingsFileAppData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "GameNet", "server_settings.txt");

        public static string ServerHost { get; set; } = "127.0.0.1";
        public static int ServerPort { get; set; } = 9090;
        public static string LastError { get; private set; } = "";

        /// <summary>
        /// Fix 1 - TLS is ON by default. When true, the client negotiates TLS
        /// with the server after TCP connect and checks the server's key
        /// (trust-on-first-use, or tls_pin). Must match the server's UseTls.
        /// Persisted to server_settings.txt as a "tls=on"/"tls=off" line.
        /// </summary>
        public static bool UseTls { get; set; } = true;

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 6: optional path to a pinned server
        /// certificate (PEM). When set and existing, the client requires the
        /// server's public-key SHA-256 to match the pin. Persisted as
        /// "tls_pin=path" line in server_settings.txt.
        /// </summary>
        public static string PinnedCertPath { get; set; } = "";

        /// <summary>
        /// ADD-CLIENT-25 — Task 24: LowPerformanceMode. When true, the kiosk
        /// disables splash / screensaver / ambient music, reduces the timer
        /// refresh from 1s to 5s, hides the music button, and would disable
        /// game cover images / animations. Useful for weak kiosk hardware or
        /// VMs where the extra GDI churn hurts the game. Persisted as
        /// "low_perf=on"/"low_perf=off" line in server_settings.txt.
        /// </summary>
        public static bool LowPerformanceMode { get; set; } = false;

        // Fix 1 - trust-on-first-use pin: the SHA-256 of the server's public key.
        // Stored like server_settings.txt: program folder first, then %APPDATA%\GameNet.
        private static readonly string PinFileExe = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "server_pin.txt");
        private static readonly string PinFileAppData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "GameNet", "server_pin.txt");

        /// <summary>
        /// Returns the stored server-key fingerprint, or null when no pin exists
        /// yet. Throws when a pin file exists but cannot be read (the caller
        /// then fails closed).
        /// </summary>
        public static string ReadServerPin()
        {
            string path = File.Exists(PinFileExe) ? PinFileExe :
                          File.Exists(PinFileAppData) ? PinFileAppData : null;
            if (path == null) return null;
            return File.ReadAllText(path).Trim();
        }

        /// <summary>
        /// Stores the server-key fingerprint. Returns false when neither the
        /// program folder nor %APPDATA%\GameNet can be written.
        /// </summary>
        public static bool WriteServerPin(string fingerprint)
        {
            try
            {
                File.WriteAllText(PinFileExe, fingerprint + Environment.NewLine);
                return true;
            }
            catch
            {
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(PinFileAppData));
                    File.WriteAllText(PinFileAppData, fingerprint + Environment.NewLine);
                    return true;
                }
                catch { return false; }
            }
        }

        /// <summary>
        /// Fix 3 - server-sent command execution (run-cmd, run-powershell,
        /// run-bat) is OFF unless the file remote_cmd.enabled exists in this
        /// program folder. A technician creates that file on a station only
        /// when remote commands are needed there. The server cannot create it:
        /// file transfer refuses that name (see ClientEngine).
        /// </summary>
        public static bool RemoteCommandsEnabled
        {
            get
            {
                try { return File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "remote_cmd.enabled")); }
                catch { return false; }
            }
        }

        /// <summary>Loads settings from disk (or keeps defaults if missing).
        /// FIX M12: decrypts the file with DPAPI (CurrentUser scope). Falls
        /// back to plain-text parsing if the file is an old unencrypted
        /// version (auto-migrated on next Save).</summary>
        /// <summary>Round 12: every settings file the kiosk guard may restore.</summary>
        public static string[] AllSettingsFiles() { return new[] { SettingsFileExe, SettingsFileAppData }; }

        /// <summary>
        /// Round 12: the server accepted this kiosk, so the current settings work: keep a
        /// copy to put back if the file is damaged later.
        /// </summary>
        public static void SnapshotLastGood()
        {
            foreach (var f in AllSettingsFiles())
                try { GameNet.Shared.SelfHeal.LastGoodConfig.Snapshot(f); } catch { }
        }

        private static bool _restoring;

        public static void Load()
        {
            string file = null;
            try
            {
                // Try exe folder first, then AppData.
                file = File.Exists(SettingsFileExe) ? SettingsFileExe :
                       File.Exists(SettingsFileAppData) ? SettingsFileAppData : null;
                if (file == null) return;

                // FIX M12: try to read + decrypt with DPAPI. If decryption
                // fails (the file is old plain-text format, or the file was
                // created by a different Windows user), fall back to reading
                // it as plain text so old kiosks still connect after the
                // upgrade. The next Save() will re-write it encrypted.
                string content = ReadDecryptedOrPlain(file);
                int recognised = 0;
                foreach (var line in content.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var p = line.Split(new[] { '=' }, 2);
                    if (p.Length != 2) continue;
                    string key = p[0].Trim();
                    string val = p[1].Trim();
                    if (key == "host" || key == "port" || key == "tls" || key == "tls_pin" || key == "low_perf") recognised++;
                    if (key == "host" && !string.IsNullOrEmpty(val)) ServerHost = val;
                    else if (key == "port" && int.TryParse(val, out int port)) ServerPort = port;
                    else if (key == "tls") UseTls = (val == "on" || val == "true" || val == "1");
                    else if (key == "tls_pin") PinnedCertPath = val;
                    else if (key == "low_perf") LowPerformanceMode = (val == "on" || val == "true" || val == "1");
                }
                // Self-repair (CFG-001): a file with no recognised setting is damaged (for
                // example written by another Windows account, or cut short). It is moved aside,
                // never deleted, and the kiosk asks for the server again.
                if (recognised == 0)
                {
                    // Round 12: a last-good copy goes back first (copy kept by
                    // SnapshotLastGood after the server accepted the kiosk); only without
                    // one is the file moved aside and the server asked for again.
                    if (!_restoring && GameNet.Shared.SelfHeal.LastGoodConfig.HasCopy(file) &&
                        GameNet.Shared.SelfHeal.LastGoodConfig.Restore(file))
                    {
                        FaultJournal.Raise("HEAL-004", file);
                        _restoring = true;
                        try { Load(); } finally { _restoring = false; }
                        return;
                    }
                    QuarantineSettingsFile(file, "no recognised setting in the file");
                }
            }
            catch (Exception ex)
            {
                // Could not be read at all (locked, access denied): keep the file and use defaults.
                FaultJournal.Raise("CFG-001", (file ?? "") + ": " + ex.GetType().Name + ": " + ex.Message, null, "");
            }
        }

        /// <summary>
        /// Moves a damaged settings file aside as server_settings.damaged-yyyyMMdd-HHmmss.txt
        /// and records CFG-001. Nothing is deleted.
        /// </summary>
        private static void QuarantineSettingsFile(string file, string why)
        {
            try
            {
                string dir = Path.GetDirectoryName(file);
                string target = Path.Combine(dir, Path.GetFileNameWithoutExtension(file) + ".damaged-" +
                    DateTime.Now.ToString("yyyyMMdd-HHmmss") + Path.GetExtension(file));
                File.Move(file, target);
                FaultJournal.Raise("CFG-001", file + " -> " + target + " (" + why + ")");
            }
            catch (Exception ex)
            {
                FaultJournal.Raise("CFG-001", file + " could not be moved aside: " + ex.Message, null,
                    "تغییرنام انجام نشد؛ فایل دست‌نخورده ماند و برنامه با تنظیمات پیش‌فرض کار می‌کند.");
            }
        }

        /// <summary>
        /// FIX M12: reads the settings file and attempts DPAPI decryption.
        /// If the file is not a valid DPAPI blob (old plain-text format from
        /// a previous version, or created by a different user), falls back
        /// to returning the raw file content as UTF-8 text. This ensures a
        /// smooth upgrade path — old settings are read, then re-saved
        /// encrypted on the next Save().
        /// </summary>
        private static string ReadDecryptedOrPlain(string path)
        {
            byte[] raw = File.ReadAllBytes(path);
            // Try DPAPI decryption first.
            try
            {
                byte[] dec = ProtectedData.Unprotect(raw, null, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(dec);
            }
            catch
            {
                // Not a DPAPI blob (old plain-text format) or different user.
                // Fall back to plain text.
                return Encoding.UTF8.GetString(raw);
            }
        }

        /// <summary>Saves the current settings to disk, encrypted with DPAPI
        /// (CurrentUser scope). Tries the exe folder first; if that fails
        /// (read-only / permission denied), falls back to %APPDATA%\GameNet.
        /// Records any error in LastError so the caller can surface it to the
        /// user. FIX M12: the file is now DPAPI-encrypted so only the current
        /// Windows user can read it.</summary>
        public static bool Save()
        {
            LastError = "";
            string content = $"host={ServerHost}{Environment.NewLine}port={ServerPort}{Environment.NewLine}tls={(UseTls ? "on" : "off")}{Environment.NewLine}tls_pin={PinnedCertPath}{Environment.NewLine}low_perf={(LowPerformanceMode ? "on" : "off")}{Environment.NewLine}";
            byte[] plain = Encoding.UTF8.GetBytes(content);
            // FIX M12: encrypt with DPAPI so only the current Windows user
            // can decrypt. Any other user/process that reads the file gets
            // ciphertext — they cannot change host=... to redirect the
            // kiosk to a malicious server.
            byte[] enc;
            try
            {
                enc = ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser);
            }
            catch (Exception ex)
            {
                // DPAPI unavailable (e.g. service account with no user profile).
                // Fall back to plain text so the kiosk can still save settings.
                LastError = "dpapi-encrypt: " + ex.Message;
                enc = plain;
            }
            // Try exe folder first.
            try
            {
                File.WriteAllBytes(SettingsFileExe, enc);
                return true;
            }
            catch (Exception ex1)
            {
                LastError = "exe-folder: " + ex1.Message;
                // Fallback to AppData.
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(SettingsFileAppData));
                    File.WriteAllBytes(SettingsFileAppData, enc);
                    return true;
                }
                catch (Exception ex2)
                {
                    LastError += " | appdata: " + ex2.Message;
                    return false;
                }
            }
        }
    }

    /// <summary>
    /// Modal dialog that asks the operator for the server IP and port. Shown
    /// at first launch or when the user clicks "تنظیمات اتصال". Now also shows
    /// the current connection status and a test-connection button so the user
    /// can verify the settings before saving.
    /// </summary>
    public class ConnectionSettingsForm : Form
    {
        public string Host { get; private set; }
        public int Port { get; private set; }
        // FIX B10: TLS toggle for the client. When checked, the client will
        // negotiate TLS with the server after TCP connect. The server must
        // also have UseTls=true (set in its OptionsForm Advanced panel).
        public bool UseTls { get; private set; }
        // ADD-CLIENT-25 — Task 24: LowPerformanceMode toggle persisted to
        // server_settings.txt as "low_perf=on/off".
        public bool LowPerf { get; private set; }

        private TextBox txtHost, txtPort;
        private Label lblStatus;
        private CheckBox chkUseTls;
        // ADD-CLIENT-25 — Task 24: LowPerformanceMode toggle.
        private CheckBox chkLowPerf;

        public ConnectionSettingsForm(string currentHost, int currentPort) : this(currentHost, currentPort, false)
        {
        }

        public ConnectionSettingsForm(string currentHost, int currentPort, bool currentUseTls)
            : this(currentHost, currentPort, currentUseTls, ConnectionSettings.LowPerformanceMode)
        {
        }

        public ConnectionSettingsForm(string currentHost, int currentPort, bool currentUseTls, bool currentLowPerf)
        {
            Host = currentHost;
            Port = currentPort;
            UseTls = currentUseTls;
            LowPerf = currentLowPerf;

            this.Text = "تنظیمات اتصال به سرور";
            // FIX (FIX-FINAL-10 B9): previously this constructor set
            //   this.Size = new Size(480, 380)
            // here, and then near the bottom of the method (after the
            // LowPerf checkbox is created) it set
            //   this.ClientSize = new Size(460, 400)
            // — a contradiction. WinForms applies BOTH in order: setting Size
            // first (which sets ClientSize to ~460×340 because of the title
            // bar + borders), then setting ClientSize=460×400 second
            // (which forces Size to ~480×440). The net effect was that the
            // dialog opened at 480×440 — bigger than either single value
            // implied — and the layout coords of the controls (computed for
            // a 460-wide client) sat slightly off-center, with a too-tall
            // blank strip below the bottom button. Setting ClientSize once,
            // at the END of the constructor (after all controls are placed),
            // is the correct WinForms idiom: WinForms recomputes Size from
            // ClientSize + borders, so the dialog ends up exactly the size
            // needed to show the client area the controls were laid out for.
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.ForeColor = System.Drawing.Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lblTitle = new Label
            {
                Text = "🔌 اتصال به سرور GameNet",
                Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(137, 180, 250),
                Location = new System.Drawing.Point(30, 15),
                AutoSize = true,
            };

            var lblHost = new Label
            {
                Text = "آدرس IP سرور (مثال: 192.168.1.100):",
                Font = new System.Drawing.Font("Segoe UI", 10F),
                Location = new System.Drawing.Point(30, 55),
                AutoSize = true,
            };
            txtHost = new TextBox
            {
                Text = currentHost,
                Location = new System.Drawing.Point(30, 80),
                Size = new System.Drawing.Size(400, 30),
                Font = new System.Drawing.Font("Consolas", 12F),
                BackColor = System.Drawing.Color.FromArgb(45, 45, 65),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40),
            };

            var lblPort = new Label
            {
                Text = "پورت سرور (پیش‌فرض: 9090):",
                Font = new System.Drawing.Font("Segoe UI", 10F),
                Location = new System.Drawing.Point(30, 120),
                AutoSize = true,
            };
            txtPort = new TextBox
            {
                Text = currentPort.ToString(),
                Location = new System.Drawing.Point(30, 145),
                Size = new System.Drawing.Size(400, 30),
                Font = new System.Drawing.Font("Consolas", 12F),
                BackColor = System.Drawing.Color.FromArgb(45, 45, 65),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40),
            };

            // Status label — shows test-connection result.
            lblStatus = new Label
            {
                Text = "",
                Font = new System.Drawing.Font("Segoe UI", 9F),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40),
                Location = new System.Drawing.Point(30, 185),
                Size = new System.Drawing.Size(400, 20),
                AutoSize = false,
            };

            // Test-connection button — lets the user verify before saving.
            var btnTest = new Button
            {
                Text = "🧪 تست اتصال",
                Location = new System.Drawing.Point(30, 215),
                Size = new System.Drawing.Size(130, 34),
                BackColor = System.Drawing.Color.FromArgb(137, 180, 250),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(240, 240, 240),
            };
            btnTest.Click += (s, e) => TestConnection();

            // FIX B10: TLS checkbox. Lets the operator toggle TLS on the client
            // side. Server must also have UseTls=true for the connection to
            // succeed (otherwise the TLS handshake will fail).
            chkUseTls = new CheckBox
            {
                Text = "استفاده از TLS (رمزنگاری ارتباط)",
                Checked = currentUseTls,
                Location = new System.Drawing.Point(30, 255),
                Size = new System.Drawing.Size(280, 24),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F),
            };
            // Resize the form to fit the new checkbox.
            this.ClientSize = new System.Drawing.Size(460, 400);

            // ADD-CLIENT-25 — Task 24: LowPerformanceMode checkbox.
            chkLowPerf = new CheckBox
            {
                Text = "حالت کم‌مصرف (غیرفعال‌سازی اسپلش/اسکرین‌سیور/موسیقی، تایمر ۵ ثانیه)",
                Checked = currentLowPerf,
                Location = new System.Drawing.Point(30, 285),
                Size = new System.Drawing.Size(400, 30),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F),
            };

            var btnOk = new Button
            {
                Text = "✓ ذخیره و اتصال",
                Location = new System.Drawing.Point(170, 215),
                Size = new System.Drawing.Size(140, 34),
                BackColor = System.Drawing.Color.FromArgb(166, 227, 161),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(240, 240, 240),
                DialogResult = DialogResult.OK,
            };
            var btnCancel = new Button
            {
                Text = "انصراف",
                Location = new System.Drawing.Point(320, 215),
                Size = new System.Drawing.Size(110, 34),
                BackColor = System.Drawing.Color.FromArgb(243, 139, 168),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F),
                ForeColor = System.Drawing.Color.FromArgb(240, 240, 240),
                DialogResult = DialogResult.Cancel,
            };

            // Scan-network button — finds servers on the local network.
            var btnScan = new Button
            {
                Text = "🔍 جستجوی سرور",
                Location = new System.Drawing.Point(30, 325),
                Size = new System.Drawing.Size(180, 34),
                BackColor = System.Drawing.Color.FromArgb(203, 166, 247),
                FlatStyle = FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(240, 240, 240),
            };
            btnScan.Click += (s, e) => ScanNetwork();

            // Hint label at the bottom.
            var lblHint = new Label
            {
                Text = "💡 اگر سرور روی همین کامپیوتر است، IP را 127.0.0.1 بگذارید.\n" +
                       "اگر روی کامپیوتر دیگری در شبکه است، IP آن کامپیوتر را وارد کنید.",
                Font = new System.Drawing.Font("Segoe UI", 8F),
                ForeColor = System.Drawing.Color.FromArgb(249, 226, 175),
                Location = new System.Drawing.Point(30, 365),
                Size = new System.Drawing.Size(420, 35),
                AutoSize = false,
            };

            btnOk.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtHost.Text))
                { MessageBox.Show("آدرس سرور را وارد کنید."); return; }
                if (!int.TryParse(txtPort.Text, out int port) || port <= 0)
                { MessageBox.Show("پورت معتبر وارد کنید."); return; }
                Host = txtHost.Text.Trim();
                Port = port;
                // FIX B10: capture the TLS checkbox state.
                UseTls = chkUseTls.Checked;
                // ADD-CLIENT-25 — Task 24: capture LowPerf state.
                LowPerf = chkLowPerf.Checked;
                this.DialogResult = DialogResult.OK;
                this.Close();
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblHost, txtHost, lblPort, txtPort,
                lblStatus, btnTest, btnOk, btnCancel, btnScan, lblHint, chkUseTls, chkLowPerf });
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }

        /// <summary>Tests the connection to the host:port in the textboxes.</summary>
        private void TestConnection()
        {
            string host = txtHost.Text.Trim();
            if (!int.TryParse(txtPort.Text, out int port) || port <= 0)
            {
                lblStatus.Text = "❌ پورت معتبر نیست.";
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(243, 139, 168);
                return;
            }
            lblStatus.Text = "⏳ در حال تست اتصال...";
            lblStatus.ForeColor = System.Drawing.Color.FromArgb(249, 226, 175);
            Application.DoEvents();
            try
            {
                using (var tcp = new System.Net.Sockets.TcpClient())
                {
                    var ar = tcp.BeginConnect(host, port, null, null);
                    if (ar.AsyncWaitHandle.WaitOne(3000))
                    {
                        tcp.EndConnect(ar);
                        lblStatus.Text = "✅ اتصال موفق بود! سرور در دسترس است.";
                        lblStatus.ForeColor = System.Drawing.Color.FromArgb(166, 227, 161);
                    }
                    else
                    {
                        lblStatus.Text = "❌_TIMEOUT: سرور در ۳ ثانیه پاسخ نداد. IP/پورت/فایروال را بررسی کنید.";
                        lblStatus.ForeColor = System.Drawing.Color.FromArgb(243, 139, 168);
                    }
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "❌ خطا: " + ex.Message;
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(243, 139, 168);
            }
        }

        /// <summary>Scans the local network for a GameNet server on port 9090.</summary>
        private void ScanNetwork()
        {
            lblStatus.Text = "🔍 در حال جستجوی سرور در شبکه محلی...";
            lblStatus.ForeColor = System.Drawing.Color.FromArgb(249, 226, 175);
            Application.DoEvents();
            int port;
            if (!int.TryParse(txtPort.Text, out port) || port <= 0) port = 9090;
            string found = FindServerOnLan(port);
            if (found != null)
            {
                txtHost.Text = found;
                lblStatus.Text = "✅ سرور پیدا شد: " + found;
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(166, 227, 161);
            }
            else
            {
                lblStatus.Text = "❌ هیچ سروری روی پورت " + port + " در شبکه محلی پیدا نشد.";
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(243, 139, 168);
            }
        }

        /// <summary>
        /// NEW FEATURE (per request: "can this be made automatic so I never
        /// have to check it"): the actual subnet-scanning logic, extracted
        /// out of ScanNetwork() (used by this dialog's "جستجوی سرور" button)
        /// into its own public static method so Program.cs can also call it
        /// automatically at startup — before ever showing this dialog at
        /// all — instead of only being reachable by a manual button click
        /// inside it. Returns the found server's IP, or null if none
        /// responded within the scan.
        /// </summary>
        public static string FindServerOnLan(int port)
        {
            try
            {
                string localIp = NetworkClient.GetLocalIp();
                if (string.IsNullOrEmpty(localIp) || localIp == "UNKNOWN") return null;
                var parts = localIp.Split('.');
                if (parts.Length != 4) return null;
                string baseIp = parts[0] + "." + parts[1] + "." + parts[2] + ".";

                string found = null;
                var opts = new System.Threading.Tasks.ParallelOptions { MaxDegreeOfParallelism = 30 };
                System.Threading.Tasks.Parallel.For(1, 255, opts, (i, state) =>
                {
                    if (state.IsStopped) return;
                    string ip = baseIp + i;
                    try
                    {
                        using (var tcp = new System.Net.Sockets.TcpClient())
                        {
                            var ar = tcp.BeginConnect(ip, port, null, null);
                            if (ar.AsyncWaitHandle.WaitOne(400))
                            {
                                try { tcp.EndConnect(ar); } catch { return; }
                                if (!state.IsStopped)
                                {
                                    found = ip;
                                    state.Stop();
                                }
                            }
                            try { ar.AsyncWaitHandle.Close(); } catch { }
                        }
                    }
                    catch { }
                });
                return found;
            }
            catch { return null; }
        }
    }
}

