﻿using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using GameNet.Shared;

namespace GameNet.Client
{
    /// <summary>
    /// Owns the TCP socket, the reader thread, and length-prefixed message framing.
    /// All sends are serialized through a dedicated <c>_sendLock</c> object (never
    /// lock on <c>_stream</c> — it is a mutable, disposable field).
    /// </summary>
    public sealed class NetworkClient : IDisposable
    {
        private const int ConnectTimeoutMs = 10000;

        private TcpClient _tcp;
        private NetworkStream _networkStream; // raw TCP stream (pre-TLS)
        private Stream _stream;                // effective stream (TLS or raw)
        private Thread _readThread;
        private volatile bool _connected;

        // H3: dedicated lock object — never lock on _stream (mutable/disposable).
        private readonly object _sendLock = new object();

        public event Action<NetMessage> OnMessageReceived;
        public event Action OnDisconnected;
        public bool IsConnected => _connected;

        /// <summary>
        /// Fix 1 - TLS is ON by default. When true, the client wraps the TCP
        /// stream in an SslStream after connect and checks the server's
        /// certificate (see ValidateServerCert): by default the server's key is
        /// trust-on-first-use (server_pin.txt); with <see cref="PinnedCertPath"/>
        /// set, the key must match that file. The server must also run with
        /// UseTls=true. A plaintext server is refused with a clear error; the
        /// client never falls back to plaintext.
        /// </summary>
        public bool UseTls { get; set; } = true;

        /// <summary>
        /// Optional path to a pinned server certificate (PEM). When set, the
        /// server's public-key SHA-256 must match the pinned certificate's, and
        /// a missing or unreadable file refuses the connection. Leave empty to
        /// use trust-on-first-use.
        /// </summary>
        public string PinnedCertPath { get; set; } = null;

        /// <summary>
        /// Host name to use as the SNI target during TLS handshake. Defaults
        /// to the host argument passed to Connect. Host names are not checked:
        /// the server's key is what is trusted (pinned or first-use).
        /// </summary>
        public string TlsTargetHost { get; set; } = null;

        /// <summary>Why the last TLS handshake was refused (null when none).</summary>
        public string LastTlsError { get; private set; }

        /// <summary>Why the read loop of the current link ended (null while it is up or when it ended cleanly). Used by the self-repair diagnosis.</summary>
        public string LastError { get; private set; }

        /// <summary>Security events from the TLS check, for the client audit log.</summary>
        public event Action<string> OnTlsLog;

        /// <summary>
        /// Connects to the remote host with a 10-second timeout. Throws
        /// <see cref="TimeoutException"/> on timeout or the underlying socket
        /// exception on connection refused.
        /// </summary>
        public void Connect(string host, int port)
        {
            LastError = null;
            LastTlsError = null;
            _tcp = new TcpClient();
            IAsyncResult ar;
            try
            {
                ar = _tcp.BeginConnect(host, port, null, null);
            }
            catch
            {
                try { _tcp.Close(); } catch { }
                throw;
            }

            // FIX 22: close the WaitHandle on timeout — it's a native handle
            // that was previously leaked per timed-out connect attempt (relies
            // on finalization otherwise).
            using (var wh = ar.AsyncWaitHandle)
            {
                if (!wh.WaitOne(ConnectTimeoutMs))
                {
                    try { _tcp.Close(); } catch { }
                    throw new TimeoutException($"Connection to {host}:{port} timed out after {ConnectTimeoutMs} ms.");
                }
            }
            try
            {
                _tcp.EndConnect(ar);
            }
            catch (Exception)
            {
                try { _tcp.Close(); } catch { }
                throw;
            }

            // FIX L13: enable TCP keepalive so a half-open connection (remote
            // crashed / network cable pulled) is detected within ~30s instead
            // of waiting 90s for the server's heartbeat timeout. Without
            // keepalive, a send to a dead peer succeeds (buffered by the OS)
            // and the client only discovers the failure when the next recv
            // times out — which can take minutes. Keepalive probes at 30s
            // intervals with 5s retries ensure the OS marks the socket dead
            // promptly, triggering the read-thread IOException → OnDisconnected
            // → reconnect.
            try
            {
                _tcp.Client.SetSocketOption(
                    System.Net.Sockets.SocketOptionLevel.Socket,
                    System.Net.Sockets.SocketOptionName.KeepAlive, true);
                // Set keepalive timing via the per-connection IOControl (TCP_KEEPIDLE/TCP_KEEPINTVL).
                // 30s idle before first probe, 5s between probes, 3 probes = dead in ~45s.
                // The 12-byte structure: on/off(4) + idle ms(4) + interval ms(4), big-endian.
                byte[] keepaliveValues = new byte[12];
                BitConverter.GetBytes(1u).CopyTo(keepaliveValues, 0);           // on
                BitConverter.GetBytes(30000u).CopyTo(keepaliveValues, 4);       // 30s idle
                BitConverter.GetBytes(5000u).CopyTo(keepaliveValues, 8);        // 5s interval
                _tcp.Client.IOControl(System.Net.Sockets.IOControlCode.KeepAliveValues, keepaliveValues, null);
            }
            catch { /* best-effort — keepalive is an optimization, not required */ }

            lock (_sendLock)
            {
                _networkStream = _tcp.GetStream();
                // ADD-MULTI-FEATURES Feature 6: wrap the raw stream with SslStream
                // when UseTls is true. The server must also have UseTls=true and a
                // valid (auto-generated self-signed is fine) certificate — otherwise
                // the TLS handshake will fail and Connect will throw, which the
                // caller surfaces as a connection error.
                if (UseTls)
                {
                    // Round 16: 15 s for the handshake. Without a timeout a server that took
                    // the connection but never answered kept this kiosk waiting forever, and
                    // it never tried again.
                    try { _networkStream.ReadTimeout = 15000; _networkStream.WriteTimeout = 15000; } catch { }
                    var ssl = new SslStream(_networkStream, false, ValidateServerCert, null);
                    string targetHost = !string.IsNullOrEmpty(TlsTargetHost) ? TlsTargetHost : (host ?? "gamenet-server");
                    LastTlsError = null;
                    try
                    {
                        ssl.AuthenticateAsClient(targetHost, null, SslProtocols.Tls12, checkCertificateRevocation: false);
                    }
                    catch (Exception ex)
                    {
                        try { ssl.Dispose(); } catch { }
                        try { _networkStream.Dispose(); } catch { }
                        try { _tcp.Close(); } catch { }
                        string reason = LastTlsError ?? ex.Message;
                        throw new IOException("TLS handshake failed: " + reason +
                            " (the server's UseTls and this station's tls setting must match)", ex);
                    }
                    try { _networkStream.ReadTimeout = System.Threading.Timeout.Infinite; _networkStream.WriteTimeout = 30000; } catch { }
                    _stream = ssl;
                }
                else
                {
                    _stream = _networkStream;
                }
                _connected = true;
            }
            _readThread = new Thread(ReadLoop) { IsBackground = true, Name = "GameNet-ReadLoop" };
            _readThread.Start();
        }

        /// <summary>
        /// Fix 1 - server certificate check. Both modes fail closed:
        ///   - PinnedCertPath set: the server's public-key SHA-256 must equal
        ///     the pinned certificate's. A missing or unreadable pin file
        ///     refuses the connection; it is never silently ignored.
        ///   - Otherwise trust-on-first-use: the first key seen is stored in
        ///     server_pin.txt. A different key later is refused until a
        ///     technician deletes that file.
        /// Chain and host-name errors are ignored on purpose: the server uses
        /// a self-signed certificate, and the key pin is the trust anchor.
        /// </summary>
        private bool ValidateServerCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (certificate == null)
            {
                LastTlsError = "the server sent no certificate";
                return false;
            }
            if (!string.IsNullOrEmpty(PinnedCertPath))
                return ValidateAgainstPinnedFile(certificate);
            return ValidateTrustOnFirstUse(certificate);
        }

        private bool ValidateAgainstPinnedFile(X509Certificate serverCert)
        {
            try
            {
                using (var pinned = new X509Certificate2(PinnedCertPath))
                using (var actual = new X509Certificate2(serverCert))
                {
                    if (ConstantTimeEquals(ComputePublicKeySha256(pinned), ComputePublicKeySha256(actual)))
                        return true;
                }
            }
            catch (Exception ex)
            {
                LastTlsError = "the pinned certificate could not be read (" + ex.Message + ")";
                return false;
            }
            LastTlsError = "the server key does not match the pinned certificate (tls_pin)";
            OnTlsLog?.Invoke("TLS: REJECTED - server key does not match tls_pin");
            return false;
        }

        private bool ValidateTrustOnFirstUse(X509Certificate serverCert)
        {
            string fingerprint;
            try
            {
                using (var cert = new X509Certificate2(serverCert))
                {
                    fingerprint = ComputePublicKeySha256(cert);
                }
            }
            catch (Exception ex)
            {
                LastTlsError = "the server certificate could not be read (" + ex.Message + ")";
                return false;
            }

            string stored;
            try
            {
                stored = ConnectionSettings.ReadServerPin();
            }
            catch (Exception ex)
            {
                LastTlsError = "server_pin.txt could not be read (" + ex.Message + ")";
                return false;
            }

            if (stored == null)
            {
                // First contact from this station: remember the server's key.
                if (!ConnectionSettings.WriteServerPin(fingerprint))
                {
                    LastTlsError = "server_pin.txt could not be written, so the server key cannot be remembered";
                    return false;
                }
                OnTlsLog?.Invoke("TLS: first contact - server key pinned, sha256=" + fingerprint);
                return true;
            }

            if (!IsSha256Hex(stored))
            {
                LastTlsError = "server_pin.txt is damaged - delete it to pin the server again";
                return false;
            }
            if (ConstantTimeEquals(stored, fingerprint)) return true;

            LastTlsError = "the server key changed since first contact (man-in-the-middle, or the server was replaced). If the server was replaced on purpose, delete server_pin.txt on this station.";
            OnTlsLog?.Invoke("TLS: REJECTED - server key changed, now sha256=" + fingerprint + ", pinned=" + stored);
            return false;
        }

        private static bool IsSha256Hex(string s)
        {
            if (s == null || s.Length != 64) return false;
            foreach (char c in s)
            {
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
            }
            return true;
        }

        internal static string ComputePublicKeySha256(X509Certificate2 cert) // round 15: also used by the connection test
        {
            byte[] pubKey = cert.GetPublicKey();
            using (var sha = System.Security.Cryptography.SHA256.Create())
            {
                byte[] digest = sha.ComputeHash(pubKey);
                var sb = new System.Text.StringBuilder(digest.Length * 2);
                foreach (byte b in digest) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= (int)a[i] ^ (int)b[i];
            return diff == 0;
        }

        public void Disconnect()
        {
            _connected = false;
            lock (_sendLock)
            {
                try { _stream?.Close(); } catch { }
                // _networkStream is the same underlying stream when not using
                // TLS (we just alias _stream = _networkStream). When TLS is
                // on, _stream is the SslStream that wraps _networkStream;
                // closing the SslStream also closes the underlying, so disposing
                // _stream above is enough. The explicit dispose below is for
                // safety in case _stream was swapped out mid-call.
                try { _networkStream?.Dispose(); } catch { }
                try { _tcp?.Close(); } catch { }
                _stream = null;
                _networkStream = null;
                _tcp = null;
            }
        }

        /// <summary>
        /// Sends a message. Throws <see cref="InvalidOperationException"/> if not
        /// connected — callers (ClientEngine) are expected to wrap in try/catch.
        /// FIX L13: also checks _tcp.Connected before writing. A half-open TCP
        /// (send succeeds but recv is blocked) won't be detected until the
        /// server's heartbeat timeout (90s); checking _tcp.Connected catches
        /// the common case where the remote has closed the socket but the read
        /// thread hasn't processed the FIN yet. TCP keepalive is enabled on
        /// connect (see Connect) so truly-idle half-open connections are
        /// detected within ~30s by the OS instead of waiting 90s.
        /// </summary>
        public void SendMessage(NetMessage msg)
        {
            if (msg == null) return;
            lock (_sendLock)
            {
                if (!_connected || _stream == null)
                    throw new InvalidOperationException("Not connected");
                // FIX L13: check _tcp.Connected — if the remote closed the
                // socket, _tcp.Connected returns false even before the read
                // thread processes the FIN. This lets us fail fast instead
                // of letting Protocol.WriteMessage throw an IOException that
                // may take seconds to surface.
                if (_tcp != null && !_tcp.Connected)
                {
                    _connected = false;
                    throw new InvalidOperationException("Socket closed by remote");
                }
                // _stream is reassigned only inside this lock, so it cannot be
                // closed mid-write by Disconnect.
                Protocol.WriteMessage(_stream, msg);
            }
        }

        private void ReadLoop()
        {
            try
            {
                while (_connected)
                {
                    Stream s;
                    lock (_sendLock) { s = _stream; }
                    if (s == null) break;
                    try
                    {
                        var msg = Protocol.ReadMessage(s);
                        OnMessageReceived?.Invoke(msg);
                    }
                    catch (IOException ex) { LastError = "read: " + ex.Message; break; }
                    catch (ObjectDisposedException) { LastError = "closed locally"; break; }
                    catch (Exception ex) { LastError = "read: " + ex.GetType().Name + ": " + ex.Message; break; }
                }
            }
            finally
            {
                _connected = false;
                OnDisconnected?.Invoke();
            }
        }

        public static string GetMacAddress()
        {
            try
            {
                foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                    if (nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up &&
                        (nic.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Ethernet ||
                         nic.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211))
                        return nic.GetPhysicalAddress().ToString();
            }
            catch { }
            // FIX (FIX-B1-B4 B4, HIGH): return null (was "UNKNOWN") so the
            // fingerprint code in ClientLicenseFingerprint.Generate can
            // detect "no MAC available" via `?? ""` and skip it cleanly.
            // Previously this returned the sentinel string "UNKNOWN", which
            // was concatenated into the fingerprint hash verbatim — so
            // every kiosk with no Up Ethernet/Wi-Fi NIC (e.g. a VM with
            // only a loopback adapter, or a machine where
            // GetAllNetworkInterfaces threw) produced the IDENTICAL
            // "...|UNKNOWN|<serial>" component, causing fingerprint
            // collisions. With B3's Base64 fix for DigitalProductId the
            // serial is now unique per-machine, but returning null here is
            // still correct: it lets Generate() emit "machineName||serial"
            // (empty MAC segment) instead of "machineName|UNKNOWN|serial",
            // which is more honest and avoids encoding a misleading
            // literal in the hash.
            return null;
        }

        /// <summary>
        /// Returns the first non-loopback IPv4 address of this machine. Used
        /// by the connection-settings dialog to scan the local /24 subnet for
        /// a GameNet server. Returns "UNKNOWN" if no suitable address is found.
        /// </summary>
        public static string GetLocalIp()
        {
            try
            {
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var addr in host.AddressList)
                {
                    if (addr.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                        !addr.ToString().StartsWith("127."))
                        return addr.ToString();
                }
            }
            catch { }
            return "UNKNOWN";
        }

        public void Dispose()
        {
            Disconnect();
        }
    }
}
