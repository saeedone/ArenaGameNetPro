using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// Phase 11.1 — Sound alerts for time warnings. Plays system sounds
    /// (beeps) at configurable thresholds so the player hears the warning
    /// even if they're wearing headphones focused on a game.
    ///
    ///   - 10 min left: short single beep (info)
    ///   - 5 min left: double beep (warning)
    ///   - 2 min left: triple beep (urgent)
    ///   - time expired: long continuous beep (critical)
    ///
    /// Round 11: plays the WAV files in the Sounds folder (MessageBeep if missing).
    /// </summary>
    public static class SoundAlert
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool MessageBeep(uint uType);

        private const uint MB_OK = 0x00000000;
        private const uint MB_ICONEXCLAMATION = 0x00000030;
        private const uint MB_ICONHAND = 0x00000010;
        private const uint MB_ICONQUESTION = 0x00000020;

        // Round 11: built-in sounds are WAV files in the "Sounds" folder next to the
        // exe (copied there by the build). The operator can replace any of them with
        // their own .wav of the same name. They play asynchronously: the old
        // Console.Beep calls blocked the UI thread for up to 1.5 s on every warning.
        public const string StartupSound = "startup.wav";
        public const string Warn10Sound = "warn10.wav";
        public const string Warn5Sound = "warn5.wav";
        public const string Warn1Sound = "warn1.wav";
        public const string TimeEndSound = "timeend.wav";

        private static readonly object _gate = new object();
        private static string _lastName;
        private static DateTime _lastAt = DateTime.MinValue;

        /// <summary>
        /// Plays a built-in sound by file name. The same sound asked for twice within
        /// 3 seconds plays once (the server's expiry message and the local timer often
        /// arrive together). Returns false when built-in sounds are turned off.
        /// </summary>
        public static bool PlayBuiltIn(string fileName, uint fallbackBeep = MB_OK)
        {
            if (!ClientOptions.BuiltInSounds) return false;
            lock (_gate)
            {
                if (fileName == _lastName && (DateTime.UtcNow - _lastAt).TotalSeconds < 3) return true;
                _lastName = fileName; _lastAt = DateTime.UtcNow;
            }
            try
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sounds", fileName);
                if (System.IO.File.Exists(path))
                {
                    using (var sp = new System.Media.SoundPlayer(path)) sp.Play(); // async
                    return true;
                }
            }
            catch { }
            try { MessageBeep(fallbackBeep); } catch { }
            return true;
        }

        /// <summary>Kiosk program started (station switched on).</summary>
        public static void PlayStartup() { PlayBuiltIn(StartupSound, MB_OK); }

        /// <summary>10 minutes left.</summary>
        public static void PlayInfo() { PlayBuiltIn(Warn10Sound, MB_ICONQUESTION); }

        /// <summary>5 minutes left.</summary>
        public static void PlayWarning() { PlayBuiltIn(Warn5Sound, MB_ICONEXCLAMATION); }

        /// <summary>1–2 minutes left.</summary>
        public static void PlayUrgent() { PlayBuiltIn(Warn1Sound, MB_ICONHAND); }

        /// <summary>Time is over.</summary>
        public static void PlayExpired() { PlayBuiltIn(TimeEndSound, MB_ICONHAND); }

        /// <summary>
        /// Plays the sound for the given minutes remaining (10, 5, 2 or less, 0).
        /// Kept for callers that pass exact minute values; the kiosk timer now uses
        /// threshold crossings instead.
        /// </summary>
        public static bool PlayForMinutesRemaining(int minutes, bool isExpired)
        {
            if (isExpired || minutes <= 0) { PlayExpired(); return true; }
            if (minutes == 10) { PlayInfo(); return true; }
            if (minutes == 5) { PlayWarning(); return true; }
            if (minutes <= 2) { PlayUrgent(); return true; }
            return false;
        }

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part F): plays an arbitrary audio file at
        /// the given path. Used by the OnLogin / OnLogout / OnTimeEnd event
        /// hooks (operator-configured via ClientOptionsForm). Wraps
        /// System.Media.SoundPlayer — only .wav files are supported by the
        /// underlying API. Best-effort: never throws (a missing or invalid
        /// file is silently ignored).
        /// </summary>
        public static void PlayFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            try
            {
                if (!System.IO.File.Exists(path)) return;
                if (path.EndsWith(".wav", StringComparison.OrdinalIgnoreCase))
                {
                    using (var sp = new System.Media.SoundPlayer(path))
                    {
                        sp.Play();
                    }
                    return;
                }
                // Round 10: other formats (.mp3 and the like) through the Windows MCI
                // player. SoundPlayer plays only .wav, but the Options dialog offers .mp3.
                mciSendString("close " + MciAlias, null, 0, IntPtr.Zero);
                if (mciSendString("open \"" + path + "\" type mpegvideo alias " + MciAlias, null, 0, IntPtr.Zero) == 0)
                    mciSendString("play " + MciAlias, null, 0, IntPtr.Zero);
            }
            catch { }
        }

        private const string MciAlias = "gamenet_sound";

        [DllImport("winmm.dll", CharSet = CharSet.Unicode)]
        private static extern int mciSendString(string command, System.Text.StringBuilder returnValue, int returnLength, IntPtr hwndCallback);
    }
}
