﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

namespace GameNet.Client
{
    public static class Watchdog
    {
        // ADD-CLIENT-25 — Task 12: monitor interval is 3 seconds (was 10).
        // Faster cadence so a customer who launches Process Hacker / procexp
        // is killed before they can use it to bypass the kiosk. The 10s
        // interval was too slow — by the time we noticed, the bypass tool
        // had already killed the kiosk process.
        private const int MonitorIntervalSeconds = 3;
        private const int SW_RESTORE = 9, SW_MAXIMIZE = 3;

        private static Timer _timer;
        private static volatile bool _running;

        // Round 7: set by the kiosk while it is in admin mode (KioskForm.EnterAdminMode,
        // cleared by ClearAdminMode). The focus check below then leaves cmd, PowerShell,
        // regedit and the other listed tools in the foreground, so a technician can use
        // them. The autostart check and the keyboard-hook check keep running.
        public static volatile bool SuspendFocusSteal;

        private static int _pid;
        private static string _exePath;

        // Known bypass tools — these are killed and we DO steal focus from them.
        // Anything else with a foreground window (a game, a browser) is left
        // alone so the user can actually play.
        // ADD-CLIENT-25 — Task 12: expanded with the Sysinternals suite + the
        // popular process-killer tools that customers can use to bypass the
        // kiosk (ProcessHacker, procexp, Unlocker, handle/autoruns/procmon).
        private static readonly HashSet<string> _bypassTools =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "Taskmgr", "cmd", "powershell", "regedit",
                "ProcessHacker", "procexp", "procexp64",
                "Unlocker", "UnlockerAssistant", "ProcessExplorer",
                "handle", "handle64", "autoruns", "autoruns64",
                "procmon", "procmon64"
            };

        public static void Start()
        {
            _running = true;
            _pid = Process.GetCurrentProcess().Id;
            // FIX L15: null-check MainModule.FileName — MainModule can throw
            // Win32Exception (access denied) on rare configurations (e.g.
            // running under a restricted service account). Wrap in try/catch
            // so the watchdog still starts (with a null _exePath) instead of
            // crashing the kiosk startup. The _exePath is only used for the
            // ShouldStealFocus / AutoStartup.Install paths, which already
            // guard against null.
            try { _exePath = Process.GetCurrentProcess().MainModule?.FileName; }
            catch { _exePath = null; }
            _timer = new Timer(Monitor, null,
                TimeSpan.FromSeconds(MonitorIntervalSeconds),
                TimeSpan.FromSeconds(MonitorIntervalSeconds));
            // NOTE: Do NOT call BlockCtrlAltDel / HideTaskbar / HideDesktopIcons
            // here — they cause the desktop to freeze on some Windows versions.
            // The kiosk form is already fullscreen + TopMost, which is enough
            // to prevent the customer from accessing the desktop.
            //
            // FIX L9: removed the HKCU\...\Run\GameNetClient write here — it
            // was redundant with AutoStartup.Install (called from Program.cs
            // before Watchdog.Start), which writes the same Run key (HKLM
            // preferred, HKCU fallback) plus the scheduled task + batch file.
            // Two code paths writing the same Run key risked conflicts if one
            // changed the value format. The Watchdog.Stop cleanup (below) and
            // SecurityLock.RestoreAll (M9 fix) both delete this key on exit.
        }

        public static void Stop()
        {
            _running = false;
            try { _timer?.Dispose(); } catch { }
            _timer = null;
            // Restore taskbar (was hidden by BlockCtrlAltDel in older versions)
            try { SecurityLock.ShowTaskbar(); } catch { }
            // Restore desktop icons (was hidden by HideDesktopIcons in older versions)
            try { SecurityLock.RestoreDesktopIcons(); } catch { }
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true)) k?.DeleteValue("GameNetClient", false); } catch { }
        }

        private static void Monitor(object state)
        {
            if (!_running) return;

            // NOTE: KillTaskManager / KillBypassTools removed — they cause
            // desktop freezes and interfere with legitimate processes.
            // The kiosk form is fullscreen + TopMost which is sufficient.
            //
            // FIX (FIX-B1-B4 B1, CRITICAL): DO NOT touch the keyboard hook
            // from the Watchdog. The previous code called
            // `SecurityLock.ReinstallHook()` here, which in turn called
            // `SetWindowsHookEx` — but `Watchdog._timer` is a
            // `System.Threading.Timer`, so `Monitor()` runs on a threadpool
            // thread, NOT the UI thread. `SetWindowsHookEx` for
            // `WH_KEYBOARD_LL` installs the hook on the calling thread,
            // and the hook callback is dispatched through that thread's
            // message pump. A threadpool thread has NO message pump, so:
            //   1. The freshly-installed hook is installed on a thread
            //      that will never pump messages → Windows silently drops
            //      it after LowLevelHooksTimeout (300ms default) → the
            //      hook is dead.
            //   2. Worse: `ReinstallHook()` first calls
            //      `UnhookWindowsHookEx` on the EXISTING (perfectly good)
            //      hook that `BlockSpecialKeys()` installed on the UI
            //      thread in the `KioskForm` constructor — so every 3s
            //      the watchdog was DESTROYING the working hook and
            //      replacing it with a dead one installed on a threadpool
            //      thread. Net effect: the keyboard hook (Win key, Alt+Tab,
            //      Ctrl+Esc, Ctrl+Shift+Esc blocking) was being killed by
            //      the watchdog on every tick.
            // The hook installed once by `BlockSpecialKeys()` in the
            // `KioskForm` ctor is sufficient. If it ever does die (very
            // rare — Windows silently unhooking a LL hook only happens
            // after a 300ms message-pump stall on the hooking thread,
            // which doesn't happen on the UI thread of a fullscreen
            // TopMost WinForms app), the kiosk process will be restarted
            // by the `AutoStartup` scheduled-task watchdog anyway.
            // (See SecurityLock.EnsureHookInstalled / HookCallback for the
            // hook lifecycle — it is NOT touched from this threadpool
            // callback anymore.)

            // Anti-kill: verify the auto-startup scheduled task + batch file
            // are still present. If someone deleted them, reinstall so the
            // kiosk can always recover from a kill.
            try
            {
                // FIX (FIX-CLIENT-BUGS B9): the watchdog interval was
                // reduced from 10s to 3s (task 12 — faster bypass-tool
                // detection). The original comment said "30 ticks at 10s
                // interval = 5 minutes", but with the new 3s interval, 30
                // ticks is only 90 seconds — AutoStartup.Install() was
                // running every 90s, which writes registry keys + a .bat
                // file + registers a scheduled task (excessive disk + RPC
                // churn, and on locked-down kiosks the schtasks call can
                // take 1-2s, briefly delaying the next Monitor tick).
                // Bumped to 100 ticks to restore the ~5-minute cadence
                // (100 × 3s = 300s = 5min) while keeping the 3s bypass-tool
                // kill cadence.
                //
                // FIX (M7 from prior review): use Interlocked.Increment
                // instead of `_tickCount++` — System.Threading.Timer
                // callbacks CAN overlap if the previous callback is still
                // running when the next period fires. The increment is the
                // only shared-state mutation here, so making it atomic
                // closes the race.
                int tick = System.Threading.Interlocked.Increment(ref _tickCount);
                if (tick % 100 == 0)
                {
                    try { AutoStartup.Install(); } catch { }
                }
            }
            catch { }

            // FIX H3: check keyboard hook health. CheckHookHealth just sets a
            // flag — it does NOT re-install the hook itself (because this
            // runs on a threadpool thread with no message pump, and
            // SetWindowsHookEx for WH_KEYBOARD_LL must be installed on the UI
            // thread). The KioskForm session timer calls
            // EnsureHookInstalledIfStale() which does the actual re-install
            // on the UI thread if CheckHookHealth flagged the hook as stale.
            try { SecurityLock.CheckHookHealth(); } catch { }

            // C5: only steal focus / maximize when no game (or other foreground
            // app) is in the foreground. If a bypass tool slipped through and is
            // foreground, we kill it (above) AND steal focus back to the kiosk.
            // Round 7: not while the kiosk is in admin mode (SuspendFocusSteal).
            if (SuspendFocusSteal) return;
            try
            {
                if (!ShouldStealFocus()) return;
                using (var p = Process.GetProcessById(_pid))
                {
                    if (p == null || p.HasExited) return;
                    if (p.MainWindowHandle == IntPtr.Zero) return;
                    ShowWindow(p.MainWindowHandle, SW_RESTORE);
                    SetForegroundWindow(p.MainWindowHandle);
                }
            }
            catch { }
        }

        private static int _tickCount;

        /// <summary>
        /// Returns true if the watchdog should bring the kiosk to the foreground.
        /// The kiosk is brought forward only when:
        ///   • it is NOT already in the foreground, AND
        ///   • the foreground window belongs to a known bypass tool (which we
        ///     just killed and want to cover), OR no window is in the foreground.
        /// Otherwise — i.e. a game or any other non-kiosk app has the foreground
        /// — we leave it alone so the user can play/use it.
        /// </summary>
        private static bool ShouldStealFocus()
        {
            IntPtr foreground = GetForegroundWindow();
            if (foreground == IntPtr.Zero) return true; // nothing focused → grab it

            int fgPid;
            GetWindowThreadProcessId(foreground, out fgPid);
            if (fgPid == 0) return true;
            if (fgPid == _pid) return false; // kiosk already foreground

            // The foreground window belongs to another process. Only steal focus
            // if it's a known bypass tool (which we just killed). For any other
            // process (a game, the InputBox, etc.) leave it alone.
            try
            {
                using (var fgProc = Process.GetProcessById(fgPid))
                {
                    string name = fgProc.ProcessName;
                    if (_bypassTools.Contains(name)) return true;
                    return false;
                }
            }
            catch
            {
                // Process exited between GetWindowThreadProcessId and here —
                // nothing to steal from.
                return false;
            }
        }

        [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int cmd);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);
    }
}
