using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;

namespace GameNet.Client
{
    /// <summary>
    /// REAPPLY-KIOSK-CHANGES-1 (Part D): handyCafe-style client configuration
    /// store. Mirrors the operator-visible "Options" dialog (see
    /// <see cref="ClientOptionsForm"/>) and persists to
    /// <c>%APPDATA%\GameNet\client_options.json</c> using Newtonsoft.Json so
    /// the operator can hand-edit / deploy / diff it.
    ///
    /// All settings are public static fields with sensible defaults so the
    /// kiosk boots even when no file is present yet (first-run). <see cref="Load"/>
    /// merges stored values back on top of those defaults; <see cref="Save"/>
    /// serializes the current state back to disk. The KioskForm ctor calls
    /// <see cref="Load"/> before constructing the engine and the Options dialog
    /// calls <see cref="Save"/> whenever the operator clicks OK.
    /// </summary>
    public static class ClientOptions
    {
        // === General ===
        // Round 10: AdminUsername / AdminPassword (a pre-fill of the login boxes) and
        // ServerHost (never used for the connection) were removed. The General tab now
        // edits the offline admin login below (SetSuperAdmin) and the server address in
        // server_settings.txt (ConnectionSettings). Their old keys in client_options.json
        // are ignored by Load and dropped by the next Save.
        // AutoDiscovery: when the saved server does not answer at start-up, look for it
        // on the LAN before asking for the address (Program.cs).
        public static bool AutoDiscovery = true;

        // === Offline emergency access (per request) ===
        // NEW FEATURE: the offline admin login (since round 7 it opens admin mode).
        // Round 10: its username and password are set on the Options dialog's General
        // tab (SetSuperAdmin below); only the hash of the password is stored.
        //
        // This is a genuinely separate, fully OFFLINE check — verified
        // entirely on this machine, no network call at all — so a
        // technician can regain access to a kiosk even with zero server
        // connectivity. The password is stored as a SHA-256 hash, not
        // plaintext, so a casual look at this file (or client_options.json)
        // doesn't hand over the credential directly.
        //
        // DEFAULT CREDENTIALS (documented here deliberately, so you have
        // them — same combination as the server's own default operator
        // account, per request):
        //   username: admin
        //   password: password
        //
        // WORTH KNOWING: this is a widely-known default combination (it's
        // also this project's server-side default), so it offers close to
        // no protection on its own — anyone with physical access who knows
        // this project could try it. That may be an acceptable tradeoff for
        // your deployment (easy to remember during setup), but it's worth
        // changing to something unique once the kiosk is actually deployed.
        //
        // IMPORTANT LIMITATION, stated plainly: unlike server-side auth,
        // ANY client-side check can eventually be extracted by someone with
        // enough access to the compiled .exe and enough effort (decompiling,
        // memory inspection). This is standard for "offline admin override"
        // features in kiosk software generally — it trades some security
        // for the ability to recover a machine with no network at all. Keep
        // physical access to kiosk PCs restricted, and change this password
        // from the default.
        public static string SuperAdminUsername = "admin";
        public static string SuperAdminPasswordHash = "5E884898DA28047151D0E56F8DC6292773603D0D6AABBDD62A11EF721D1542D8"; // SHA-256 of "password"

        /// <summary>
        /// Checks the given credentials against the offline super-admin
        /// account. Entirely local — never touches the network.
        /// </summary>
        public static bool VerifySuperAdmin(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) return false;
            // DEFENSIVE FIX: this whole app runs with RightToLeft.Yes. In an
            // RTL-layout textbox, Windows' text input can sometimes insert
            // invisible bidirectional control characters (e.g. U+200E
            // LEFT-TO-RIGHT MARK, U+200F RIGHT-TO-LEFT MARK) around Latin
            // text — invisible to the eye, but enough to make an exact
            // string comparison fail even though "admin" looks identical
            // to what was actually typed. Stripped before comparing.
            username = StripBidiMarks(username).Trim();
            password = StripBidiMarks(password);
            if (!string.Equals(username, SuperAdminUsername, StringComparison.OrdinalIgnoreCase)) return false;
            string hash = HashPassword(password);
            return string.Equals(hash, SuperAdminPasswordHash, StringComparison.OrdinalIgnoreCase);
        }

        private static string StripBidiMarks(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            var sb = new System.Text.StringBuilder(s.Length);
            foreach (char c in s)
            {
                // U+200B ZERO WIDTH SPACE, U+200C/200D ZWNJ/ZWJ, U+200E/200F
                // LRM/RLM, U+202A–U+202E embedding/override controls.
                if (c == '\u200B' || c == '\u200C' || c == '\u200D' || c == '\u200E' || c == '\u200F'
                    || (c >= '\u202A' && c <= '\u202E')) continue;
                sb.Append(c);
            }
            return sb.ToString();
        }

        private static string HashPassword(string password)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                var sb = new System.Text.StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("X2"));
                return sb.ToString();
            }
        }

        /// <summary>
        /// Round 10: sets the offline admin login from the Options dialog's General tab.
        /// An empty username or password keeps the current one. Bidi marks are stripped as
        /// in VerifySuperAdmin, and only the SHA-256 hash of the password is kept.
        /// </summary>
        public static void SetSuperAdmin(string username, string password)
        {
            string user = StripBidiMarks(username ?? "").Trim();
            if (user.Length > 0) SuperAdminUsername = user;
            if (!string.IsNullOrEmpty(password))
                SuperAdminPasswordHash = HashPassword(StripBidiMarks(password));
        }

        // === Options (operator-visible behaviour toggles) ===
        public static string DefaultWallpaper = "";
        public static bool DisableCafeteria = false;
        public static bool DisableHide = false;
        public static bool DisableLogout = false;
        public static bool DisableAltEnter = false;
        public static bool DisableLoginRequest = false;
        public static bool UsbProtection = true;
        public static bool TerminateOnLogout = false;
        public static bool HideUsedTime = false;
        public static bool HideCost = false;
        public static bool HideRemainingTime = false;
        public static bool HideStartTime = false;
        // Round 10: folders whose programs GameKiller closes on "Terminate on Logout" and
        // at the end of time, separated by ';'. Before, only C:\Games and D:\Games.
        public static string GameFolders = @"C:\Games;D:\Games;C:\Program Files (x86)\Steam\steamapps\common;C:\Program Files\Epic Games;C:\Riot Games";

        // === Right column (round 6) ===
        // One switch per item of the kiosk's right column after login, set on the
        // "ستون راست" tab of the Options dialog. false = shown, so a kiosk whose
        // client_options.json has none of these keys keeps every item visible.
        // Items that already had a switch keep it: HideStartTime, HideRemainingTime,
        // HideUsedTime and HideCost (rows), DisableHide (desktop button) and
        // DisableCafeteria (credit button). DisableLogout still blocks logout; the
        // exit button's visibility is HideBtnExit.
        public static bool HideIpAddress = false;
        public static bool HidePricePerHour = false;
        public static bool HideBalance = false;
        public static bool HideLoyaltyPoints = false;
        public static bool HideBtnAdd10 = false;
        public static bool HideBtnAdd30 = false;
        public static bool HideBtnAdd60 = false;
        public static bool HideBtnEndSession = false;
        public static bool HideBtnScreenshot = false;
        public static bool HideBtnMessage = false;
        public static bool HideBtnChat = false;
        public static bool HideBtnAnnouncements = false;
        public static bool HideBtnLoyalty = false;
        public static bool HideBtnProfile = false;
        public static bool HideBtnStats = false;
        public static bool HideBtnFood = false;
        public static bool HideBtnMusic = false;
        public static bool HideBtnOptions = false;
        public static bool HideBtnExit = false;

        // === Admin mode (round 7) ===
        // After the offline admin login the kiosk shows the right column in admin mode
        // (KioskForm.EnterAdminMode). With no keyboard or mouse input on the PC for this
        // many minutes it returns to the locked login screen. 0 = never. Not on the
        // Options dialog; set it in client_options.json.
        public static int AdminIdleLockMinutes = 10;

        // === Network ===
        public static string SelectedAdapterMac = "";

        // === Events ===
        public static int OnTimeEndMinutes = 5;
        public static string OnTimeEndMessage = "زمان شما رو به اتمام است...";
        public static string OnTimeEndSound = "";
        public static string OnLoginMessage = "";
        public static string OnLoginSound = "";
        public static string OnLogoutMessage = "";
        public static string OnLogoutSound = "";
        // Round 11: built-in sounds (station start, 10/5/1 minutes left, time over).
        public static bool BuiltInSounds = true;

        // === Advanced ===
        // Round 10: ServerUdpPort / ClientUdpPort removed. The client port was never read;
        // the server port only served a UDP discovery that no server answered.
        public static string ServerClientPassword = "HANDYCAFE";

        // === Language ===
        // Round 10: no tab any more (there are no translations). ApplyLanguage still uses
        // it for number and date formats; the default stays Persian.
        public static string Language = "فارسی";

        /// <summary>
        /// Path used for the JSON store. Lives under %APPDATA%\GameNet so the
        /// settings survive a kiosk exe overwrite / uninstall-reinstall.
        /// </summary>
        public static string GetFilePath()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                if (string.IsNullOrEmpty(appData))
                    appData = AppDomain.CurrentDomain.BaseDirectory;
                string dir = Path.Combine(appData, "GameNet");
                try { Directory.CreateDirectory(dir); } catch { }
                return Path.Combine(dir, "client_options.json");
            }
            catch
            {
                return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_options.json");
            }
        }

        /// <summary>
        /// Loads the persisted JSON file (if any) and copies every recognized
        /// field onto the static fields above. Unknown keys are ignored. Any
        /// read failure is swallowed — the kiosk must boot even with a corrupt
        /// or partial options file. Returns true if the file was actually
        /// read (false = no file or read failure).
        /// </summary>
        /// <summary>Round 14: every setting as text, for the server's activity journal.</summary>
        public static Dictionary<string, string> SnapshotForJournal()
        {
            var d = new Dictionary<string, string>();
            foreach (var fi in typeof(ClientOptions).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                if (fi.IsLiteral || fi.IsInitOnly) continue;
                object v = null;
                try { v = fi.GetValue(null); } catch { }
                d[fi.Name] = Convert.ToString(v) ?? "";
            }
            return d;
        }

        /// <summary>
        /// Round 14: "Name: old → new" for each changed setting. Passwords and hashes are
        /// never sent; they show as "تغییر کرد".
        /// </summary>
        public static string DescribeChanges(Dictionary<string, string> before, Dictionary<string, string> after)
        {
            var parts = new List<string>();
            foreach (var kv in after)
            {
                string old;
                if (!before.TryGetValue(kv.Key, out old)) old = "";
                if (old == kv.Value) continue;
                bool secret = kv.Key.IndexOf("Password", StringComparison.OrdinalIgnoreCase) >= 0 ||
                              kv.Key.IndexOf("Hash", StringComparison.OrdinalIgnoreCase) >= 0;
                if (secret) parts.Add(kv.Key + ": تغییر کرد");
                else parts.Add(kv.Key + ": " + Short(old) + " ← " + Short(kv.Value));
            }
            return string.Join("، ", parts);
        }

        private static string Short(string s)
        {
            s = s ?? "";
            if (s.Length == 0) return "(خالی)";
            return s.Length > 40 ? s.Substring(0, 40) + "…" : s;
        }

        public static bool Load()
        {
            bool ok = LoadOnce();
            if (ok)
            {
                // Round 12: the file was read: keep it as the last-good copy.
                try { GameNet.Shared.SelfHeal.LastGoodConfig.Snapshot(GetFilePath()); } catch { }
                return true;
            }
            // Round 12: the file exists but could not be read (damaged JSON): put the
            // last-good copy back (the damaged file is kept as *.damaged-<time>).
            try
            {
                string path = GetFilePath();
                if (File.Exists(path) && GameNet.Shared.SelfHeal.LastGoodConfig.Restore(path))
                {
                    try { GameNet.Shared.Diagnostics.FaultJournal.Raise("HEAL-004", path); } catch { }
                    return LoadOnce();
                }
            }
            catch { }
            return false;
        }

        private static bool LoadOnce()
        {
            try
            {
                string path = GetFilePath();
                if (!File.Exists(path)) return false;
                string json = File.ReadAllText(path);
                if (string.IsNullOrWhiteSpace(json)) return false;
                var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json)
                           ?? new Dictionary<string, string>();
                foreach (var kv in dict)
                {
                    if (kv.Value == null) continue;
                    string key = kv.Key;
                    string val = kv.Value;
                    FieldInfo fi = typeof(ClientOptions).GetField(key,
                        BindingFlags.Public | BindingFlags.Static);
                    if (fi == null) continue;
                    try
                    {
                        object converted = ConvertToFieldType(val, fi.FieldType);
                        fi.SetValue(null, converted);
                    }
                    catch { /* keep default on bad value */ }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Serializes every public static field to a JSON string and writes it
        /// to <see cref="GetFilePath"/>. Returns true on success, false on any
        /// IO failure (the caller may surface the error to the operator).
        /// </summary>
        public static bool Save()
        {
            try
            {
                var dict = new Dictionary<string, string>();
                foreach (FieldInfo fi in typeof(ClientOptions)
                             .GetFields(BindingFlags.Public | BindingFlags.Static))
                {
                    object v = fi.GetValue(null);
                    dict[fi.Name] = v == null ? "" : v.ToString();
                }
                string json = JsonConvert.SerializeObject(dict, Formatting.Indented);
                string path = GetFilePath();
                try { Directory.CreateDirectory(Path.GetDirectoryName(path) ?? "."); } catch { }
                File.WriteAllText(path, json);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Converts a string value (read from the JSON store) into the field's
        /// native type. Handles every type used by ClientOptions today
        /// (string, bool, int). Anything else falls back to Convert.ChangeType.
        /// </summary>
        private static object ConvertToFieldType(string val, Type t)
        {
            if (t == typeof(string)) return val ?? "";
            if (t == typeof(bool))
            {
                if (val == null) return false;
                string v = val.Trim().ToLowerInvariant();
                return v == "1" || v == "true" || v == "on" || v == "yes" || v == "بله";
            }
            if (t == typeof(int))
            {
                int parsed;
                if (int.TryParse(val, out parsed)) return parsed;
                return 0;
            }
            return Convert.ChangeType(val, t);
        }
    }
}
