using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;

namespace GameNet.Client
{
    // FIX H10: ClientEngine now implements IDisposable so the underlying
    // NetworkClient (TcpClient + read thread) is formally disposed on
    // shutdown. Previously KioskForm.OnFormClosed called _engine.Disconnect()
    // which closed the stream but never disposed the NetworkClient — leaking
    // a TcpClient + its underlying socket on every form close (dev restarts,
    // theme switches that recreate the form, etc.).
    public class ClientEngine : IDisposable
    {
        // Default connection settings — overridable via the constructor so the
        // connection-settings dialog can pass a user-entered server IP.
        public const string DefaultServerHost = "127.0.0.1";
        public const int DefaultServerPort = 9090;

        public string ServerHost { get; set; } = DefaultServerHost;
        public int ServerPort { get; set; } = DefaultServerPort;

        /// <summary>Creates an engine using default (localhost) settings.</summary>
        public ClientEngine() : this(DefaultServerHost, DefaultServerPort) { }

        /// <summary>Creates an engine with a custom server address.</summary>
        public ClientEngine(string host, int port)
        {
            if (!string.IsNullOrWhiteSpace(host)) ServerHost = host;
            if (port > 0) ServerPort = port;

            _net = new NetworkClient();
            // ADD-MULTI-FEATURES Feature 6: propagate the TLS settings from
            // ConnectionSettings (loaded from server_settings.txt) to the
            // NetworkClient so the client/server encryption mode is in sync.
            _net.UseTls = ConnectionSettings.UseTls;
            _net.PinnedCertPath = ConnectionSettings.PinnedCertPath;
            _net.TlsTargetHost = !string.IsNullOrWhiteSpace(host) ? host : ConnectionSettings.ServerHost;
            _net.OnMessageReceived += HandleMsg;
            _net.OnDisconnected += OnNetDisconnected;
            // Fix 1: TLS trust decisions (first contact, key change) go to client_log.txt.
            _net.OnTlsLog += AuditLogSafe;
        }

        private NetworkClient _net;
        private Timer _heartbeat;
        private Timer _reconnect;
        private volatile bool _disposed;
        private int _reconnectAttempts;
        // Reconnect delays come from RecoveryPolicy.Backoff (1s, 2s, 4s ... capped at
        // ReconnectMaxDelayMs) plus up to 20% jitter, so kiosks that restart together
        // do not all retry in the same instant (self-repair rule R1).
        private const int ReconnectMaxDelayMs = 30000;
        // Self-repair (FMEA NET-006): after MaxReconnectAttempts fast tries, keep
        // retrying every SlowRetrySeconds instead of stopping for good.
        private const int SlowRetrySeconds = 60;
        private bool _gaveUp;
        // Welcome watchdog (FMEA NET-005): a link on which the server does not send
        // ServerWelcome within WelcomeTimeoutSeconds is dropped and re-established.
        // Only ServerWelcome cancels it.
        private const int WelcomeTimeoutSeconds = 30;
        private Timer _welcomeTimer;
        private int _welcomeGeneration;
        private volatile bool _welcomed;         // ServerWelcome (or a login challenge) seen on the current link
        private volatile bool _resumeSent;       // link opened with ClientReconnect: a ServerLoginFail is then a challenge, not a refusal
        private volatile bool _welcomeTimedOut;  // the current drop was made by the watchdog
        private string _pendingDropDetail;       // why the link is being dropped on purpose

        // Session state — preserved across reconnects so we can issue ClientReconnect.
        private string _sessionId, _username, _lastSessionId;
        private decimal _balance, _pricePerHour;
        private DateTime? _sessionStart;

        // Pre-lock state — when ServerLockClient arrives we save the current
        // state, then ServerUnlockClient restores it (so an InSession client
        // doesn't get demoted to Connected).
        private ClientState _preLockState = ClientState.Disconnected;

        public ClientState State { get; internal set; } = ClientState.Disconnected;
        public string Username => _username;
        public decimal Balance => _balance;

        // REAPPLY-KIOSK-CHANGES-1: expose the session start time + the
        // negotiated price-per-hour so the kiosk's handyCafe-style sidebar
        // can render the Start/Used/Remaining/Cost rows without poking the
        // engine's private state. Read-only surface — never mutated from
        // outside the engine.
        public DateTime? SessionStart => _sessionStart;
        public decimal PricePerHour => _pricePerHour;

        // Play and Pay mode: user plays first, pays after session ends
        private bool _playAndPay = false;
        public bool PlayAndPay => _playAndPay;
        public void SetPlayAndPay(bool enabled) { _playAndPay = enabled; }

        // Get active window title for monitoring
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        private static string GetActiveWindowTitle()
        {
            try
            {
                IntPtr handle = GetForegroundWindow();
                if (handle == IntPtr.Zero) return "";
                var sb = new StringBuilder(256);
                GetWindowText(handle, sb, 256);
                return sb.ToString();
            }
            catch { return ""; }
        }

        public event Action OnConnected;
        public event Action<string> OnDisconnected;
        // FIX 24: raised when the reconnect loop gives up after MaxReconnectAttempts.
        public event Action OnReconnectGaveUp;
        // ADD-CLIENT-25 — Task 23: raised on EACH reconnect attempt so the UI
        // can show "در حال اتصال مجدد..." with the attempt number + delay.
        public event Action<int, int> OnReconnectAttempt;
        // Self-repair: every recorded fault (see FaultCatalog). The kiosk shows the
        // actionable ones as a notice; the full record is written to diagnostics.log.
        public event Action<FaultRecord> OnFault;
        public event Action<bool, string, string, decimal, decimal> OnLoginResult;
        public event Action<int, string, bool> OnTimeWarning;
        public event Action OnTimeExpired;
        public event Action<string> OnForceLogout;
        public event Action<decimal> OnPriceUpdate;
        public event Action<TimeSpan, decimal, int?> OnSessionUpdate;
        public event Action<string, string, string> OnServerMessage;
        public event Action OnLocked;
        public event Action OnUnlocked;

        // Phase 3 events
        public event Action<ChatReceivePayload> OnChatMessage;
        public event Action<ChatHistoryPayload> OnChatHistory;
        public event Action<AnnouncementListPayload> OnAnnouncements;
        public event Action<PrintResultPayload> OnPrintResult;
        public event Action<DebtListPayload> OnDebtList;
        public event Action<PackageListPayload> OnPackageList;
        public event Action<PackageResultPayload> OnPackageResult;
        public event Action<TierInfoPayload> OnTierInfo;

        // Phase 4 events
        public event Action<TwoFactorResultPayload> On2FAResult;
        public event Action<SecurityAlertPayload> OnSecurityAlert;

        // Phase 5 events
        public event Action<ThemeDataPayload> OnThemeData;
        public event Action<NotificationPayload> OnNotification;

        // Phase 6 events
        public event Action<SmartPricePayload> OnSmartPriceInfo;
        public event Action<AutoRechargeResultPayload> OnAutoRechargeResult;
        public event Action<TrafficPredictionPayload> OnTrafficPrediction;

        // Phase 7 events
        public event Action<PaymentUrlPayload> OnPaymentUrl;
        public event Action<PaymentVerifiedPayload> OnPaymentVerified;

        // Phase 8 events
        public event Action<ServerUpdatePayload> OnUpdateAvailable;
        public event Action<ConfigSyncPayload> OnConfigSync;

        // Phase 11 events: quick top-up
        public event Action<TopupResponsePayload> OnTopupResponse;

        // Credit notification (operator adds credit during session)
        public event Action<AddCreditPayload> OnCreditAdded;

        // Phase 13: UX enhancement events
        public event Action<FoodOrderResponsePayload> OnFoodOrderResponse;
        public event Action<SessionHistoryPayload> OnSessionHistory;
        public event Action<PauseResponsePayload> OnPauseResponse;
        public event Action<LeaderboardPayload> OnLeaderboard;
        public string SessionId => _sessionId;

        private void OnNetDisconnected()
        {
            // Preserve the last session id so we can resume on reconnect.
            if (!string.IsNullOrEmpty(_sessionId))
                _lastSessionId = _sessionId;

            // FIX C2: do NOT clear _sessionStart / _username / _balance /
            // _pricePerHour / _lastSessionId here. They are preserved across
            // the disconnect so that a successful reconnect (ServerWelcome
            // with the same SessionId) can restore State = InSession without
            // forcing the user to re-login (which would orphan the old
            // server-side session and create a duplicate).
            var previousState = State;
            bool wasWelcomed = _welcomed;
            bool timedOut = _welcomeTimedOut;
            string how = _pendingDropDetail ?? _net.LastError ?? "";
            _welcomed = false;
            _welcomeTimedOut = false;
            _pendingDropDetail = null;
            State = ClientState.Disconnected;

            try { _heartbeat?.Dispose(); _heartbeat = null; } catch { }
            CancelWelcomeWatchdog();

            OnDisconnected?.Invoke("قطع");

            // Self-repair: say WHY the link dropped, once per drop. A watchdog drop is
            // already explained by NET-005, so it is not repeated here.
            if (!_disposed && previousState != ClientState.Disconnected && !timedOut)
            {
                string where = ServerHost + ":" + ServerPort;
                if (wasWelcomed)
                    ReportFault("NET-007", "link lost after ServerWelcome: " + how, where);
                else
                    ReportFault("NET-008", "closed before ServerWelcome: " + how, where);
            }

            // Only auto-reconnect if we were not intentionally disposed.
            if (!_disposed && previousState != ClientState.Disconnected)
                ScheduleReconnect();
        }

        public void Connect()
        {
            State = ClientState.Disconnected;
            TryConnect();
        }

        public void Disconnect()
        {
            _disposed = true;
            try { _heartbeat?.Dispose(); } catch { }
            try { _reconnect?.Dispose(); } catch { }
            CancelWelcomeWatchdog();
            _heartbeat = null;
            _reconnect = null;

            // NEW FEATURE cleanup: don't leave ffmpeg running after logout.
            try { StopVideoStream(); } catch { }

            // Best-effort logout notification — never throw on the disconnect path.
            if (State == ClientState.InSession)
            {
                try { _net.SendMessage(new NetMessage(MessageType.ClientLogout, null, _sessionId)); }
                catch { }
            }

            try { _net.OnMessageReceived -= HandleMsg; } catch { }
            try { _net.OnDisconnected -= OnNetDisconnected; } catch { }
            try { _net.Disconnect(); } catch { }
        }

        /// <summary>
        /// FIX H10: IDisposable implementation. Calls Disconnect() (which
        /// closes the stream/tcp) and then disposes the NetworkClient itself
        /// (releases the TcpClient + socket handles formally). Safe to call
        /// multiple times — Disconnect sets _disposed, so a second call is a
        /// no-op.
        /// </summary>
        public void Dispose()
        {
            Disconnect();
            try { _net?.Dispose(); } catch { }
        }

        /// <summary>
        /// Sends a message, swallowing any send-side exception and triggering
        /// a reconnect. Used by every public send method so a transient socket
        /// failure cannot crash the process or leave the caller stuck.
        /// </summary>
        /// <summary>Best-effort audit log (writes to a local file).
        /// FIX L7: rotates the log when it exceeds 2MB so a long-running
        /// kiosk doesn't accumulate an unbounded client_log.txt. Keeps the
        /// last 2 generations (client_log.txt + client_log.1.txt = ~4MB max).
        /// Truncates the individual message to 2KB so a single huge log
        /// entry (e.g. a giant base64 transfer) can't blow up the file.</summary>
        private void AuditLogSafe(string msg)
        {
            try
            {
                // Truncate the message so a single log entry can't be huge.
                if (msg != null && msg.Length > 2048)
                    msg = msg.Substring(0, 2048) + "... [truncated]";
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_log.txt");
                // Rotate if the file is over 2MB. Check on every write — File.
                // AppendAllText is fast, and FileInfo.Length is a cheap stat.
                try
                {
                    var fi = new System.IO.FileInfo(path);
                    if (fi.Exists && fi.Length > 2 * 1024 * 1024)
                    {
                        string backup = path + ".1.txt";
                        try { if (System.IO.File.Exists(backup)) System.IO.File.Delete(backup); } catch { }
                        try { System.IO.File.Move(path, backup); } catch { }
                    }
                }
                catch { }
                System.IO.File.AppendAllText(path, $"{DateTime.UtcNow:o}  {msg}{Environment.NewLine}");
            }
            catch { }
        }

        internal bool SendSafe(NetMessage msg)
        {
            try
            {
                _net.SendMessage(msg);
                return true;
            }
            catch (Exception ex)
            {
                // H2: log via OnServerMessage (we have no logger) and trigger
                // reconnect — do NOT propagate.
                try { OnServerMessage?.Invoke("خطای شبکه", ex.Message, "error"); } catch { }
                if (!_disposed && State != ClientState.Disconnected)
                {
                    // Force the disconnect path so ScheduleReconnect runs.
                    _pendingDropDetail = "send failed: " + ex.GetType().Name + ": " + ex.Message;
                    try { _net.Disconnect(); } catch { }
                    OnNetDisconnected();
                }
                return false;
            }
        }

        public void Login(string user, string pw, string twoFactorCode = "")
        {
            State = ClientState.WaitingForLogin;
            // ADD-CLIENT-25 — Task 15: log login attempt.
            try { ActivityLogger.Login(user); } catch { }
            // H2: wrapped — Login must not throw to the caller. Login failures
            // arrive asynchronously via OnLoginResult.
            SendSafe(new NetMessage(MessageType.ClientLogin,
                new ClientLoginPayload
                {
                    Username = user,
                    Password = pw,
                    StationName = Environment.MachineName,
                    TwoFactorCode = twoFactorCode
                }, _sessionId));
        }

        public void Logout()
        {
            // FIX 23: only clear session state if the ClientLogout send
            // actually succeeded. Otherwise the server still thinks the
            // session is active (until heartbeat timeout) and the next
            // reconnect would orphan the old server-side session.
            bool sent = SendSafe(new NetMessage(MessageType.ClientLogout, null, _sessionId));
            // ADD-CLIENT-25 — Task 15: log logout + minutes played.
            try
            {
                int min = _sessionStart.HasValue ? (int)(DateTime.UtcNow - _sessionStart.Value).TotalMinutes : 0;
                ActivityLogger.Logout(_username ?? "", min);
            }
            catch { }
            if (sent)
            {
                State = ClientState.Connected;
                _sessionStart = null;
                _sessionId = null;
                // FIX H7: also clear _lastSessionId so a subsequent reconnect
                // attempt doesn't try to resume a session that the server has
                // already torn down (would surface a confusing "نشست منقضی شده"
                // popup and force a needless re-login). Previously the client
                // kept _lastSessionId here, sent ClientReconnect on next
                // connect, and the server's HandleReconnect rejected it
                // because the old conn was gone.
                _lastSessionId = null;
            }
            // If send failed, keep state — ScheduleReconnect will handle it.
        }

        public void RedeemTicket(string code)
        {
            SendSafe(new NetMessage(MessageType.ClientTicketRedeem,
                new TicketRedeemPayload { TicketCode = code }, _sessionId));
        }

        /// <summary>
        /// Phase 11 — Requests a quick top-up from the operator. The operator
        /// sees the request in the server UI and can approve/deny it. The
        /// response arrives via OnTopupResponse.
        /// </summary>
        public void RequestTopup(decimal amount, string paymentMethod = "cash", string notes = "")
        {
            // ADD-CLIENT-25 — Task 15: log topup request.
            try { ActivityLogger.TopupRequested(amount, paymentMethod); } catch { }
            SendSafe(new NetMessage(MessageType.ClientTopupRequest,
                new TopupRequestPayload
                {
                    Username = _username ?? "",
                    StationName = Environment.MachineName,
                    Amount = amount,
                    PaymentMethod = paymentMethod,
                    Notes = notes,
                    RequestedAt = DateTime.UtcNow
                }, _sessionId));
        }

        // FIX MONITOR-TO-CLIENT: methods that send monitoring action requests
        // to the server. Uses ClientChatSend as a generic request channel.
        public void SetSessionTimeRequest(int action, int minutes, string reason)
        {
            try
            {
                SendSafe(new NetMessage(MessageType.ClientChatSend,
                    new ChatSendPayload { SenderUsername = _username ?? "", Message = $"[REQ] action={action},min={minutes},reason={reason}" }, _sessionId));
            }
            catch { }
        }

        public void RequestScreenshot()
        {
            try
            {
                OnServerMessage?.Invoke("اسکرین‌شات", "درخواست اسکرین‌شات ارسال شد", "info");
            }
            catch { }
        }

        public void RequestLock()
        {
            try
            {
                SendSafe(new NetMessage(MessageType.ClientChatSend,
                    new ChatSendPayload { SenderUsername = _username ?? "", Message = "[REQ] lock" }, _sessionId));
            }
            catch { }
        }

        public void RequestShutdown()
        {
            try
            {
                SendSafe(new NetMessage(MessageType.ClientChatSend,
                    new ChatSendPayload { SenderUsername = _username ?? "", Message = "[REQ] shutdown" }, _sessionId));
            }
            catch { }
        }

        /// <summary>Round 14: sends saved reports and kiosk events now (when connected).</summary>
        public void FlushReportsNow()
        {
            if (!_welcomed) return;
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                try { CrashReporter.FlushPendingCrashes(payload => SendSafe(new NetMessage(MessageType.ClientCrashReport, payload)), 3); } catch { }
            });
        }

        // Round 11: raised when the operator starts controlling this PC remotely.
        public event Action OnRemoteControlActive;
        private DateTime _lastRemoteInputAt = DateTime.MinValue;

        // NEW FEATURE (real video+audio codec, per request).
        private Process _videoStreamProcess;
        private readonly object _videoStreamLock = new object();

        /// <summary>
        /// Launches ffmpeg.exe to capture this PC's screen (and, best-
        /// effort, its audio) and stream real H.264 video + AAC audio to
        /// the server's already-listening ffplay. Requires ffmpeg.exe to be
        /// installed and on PATH on THIS specific kiosk PC — there is no
        /// way to bundle or auto-install it from here (see the chat
        /// message alongside this feature).
        /// </summary>
        private volatile int _videoGen; // round 13: bumps on every start/stop

        private void StartVideoStream(StartVideoStreamPayload sv)
        {
            StopVideoStream(); // stop any previous stream first
            int gen = _videoGen;

            // Round 11: clamp the operator's numbers, and keep the scaled size even —
            // libx264 with yuv420p refuses an odd width/height (1366 x 75% = 1024.5).
            int fps = Math.Max(5, Math.Min(60, sv.FrameRate));
            int kbps = Math.Max(300, Math.Min(25000, sv.VideoBitrateKbps));
            int scale = Math.Max(25, Math.Min(100, sv.ScalePercent));
            string scaleFilter = scale != 100
                ? $"scale=trunc(iw*{scale}/200)*2:trunc(ih*{scale}/200)*2"
                : "scale=trunc(iw/2)*2:trunc(ih/2)*2";
            // KNOWN LIMITATION, stated plainly: Windows has no built-in way for FFmpeg to
            // capture "what this PC is playing" without "Stereo Mix" enabled or a virtual
            // audio cable. If it is missing, ffmpeg exits at once and the error goes back to
            // the operator.
            string audioArgs = sv.IncludeAudio
                ? $" -f dshow -i audio=\"Stereo Mix\" -c:a aac -b:a {sv.AudioBitrateKbps}k"
                : " -an";
            // Round 11 quality: bit-rate cap with a small buffer, a keyframe every 2 s,
            // no B-frames. ultrafast stays, so the customer's game keeps its CPU.
            string encode = $" -c:v libx264 -preset ultrafast -tune zerolatency -b:v {kbps}k -maxrate {kbps}k -bufsize {Math.Max(200, kbps / 2)}k -g {fps * 2} -bf 0 -pix_fmt yuv420p -f mpegts tcp://{sv.ServerIp}:{sv.Port}";

            // Round 13 (60 fps): screen capture with Windows Desktop Duplication (ffmpeg's
            // "ddagrab", FFmpeg 6.0 or newer, Windows 8+). It reaches 60 fps at Full HD with
            // little CPU and also captures full-screen games, which "gdigrab" (the old
            // method, ~30-40 fps at best, often black in full-screen games) cannot. If
            // ddagrab is not available (older FFmpeg, remote desktop session, no GPU
            // driver), the old gdigrab command is used.
            string ddaArgs = $"-f lavfi -i ddagrab=output_idx=0:framerate={fps}:draw_mouse=1{audioArgs} -vf hwdownload,format=bgra,{scaleFilter}{encode}";
            string gdiArgs = $"-f gdigrab -framerate {fps} -draw_mouse 1 -i desktop{audioArgs} -vf {scaleFilter}{encode}";

            ThreadPool.QueueUserWorkItem(_ =>
            {
                string lastErr = null;
                foreach (var args in new[] { ddaArgs, gdiArgs })
                {
                    if (gen != _videoGen) return; // stopped meanwhile
                    Process proc = null;
                    var stderrBuffer = new StringBuilder();
                    try
                    {
                        var psi = new ProcessStartInfo("ffmpeg.exe", args)
                        {
                            UseShellExecute = false,
                            CreateNoWindow = true,
                            RedirectStandardError = true,
                        };
                        proc = new Process { StartInfo = psi, EnableRaisingEvents = true };
                        var thisProc = proc;
                        proc.ErrorDataReceived += (s, e) =>
                        {
                            if (e.Data == null) return;
                            lock (stderrBuffer) { stderrBuffer.AppendLine(e.Data); if (stderrBuffer.Length > 4000) stderrBuffer.Length = 4000; }
                        };
                        proc.Start();
                        proc.BeginErrorReadLine();
                        lock (_videoStreamLock) { _videoStreamProcess = proc; }
                        proc.Exited += (s, e) => { lock (_videoStreamLock) { if (_videoStreamProcess == thisProc) _videoStreamProcess = null; } };
                    }
                    catch (Exception ex)
                    {
                        // Most common cause: ffmpeg.exe not installed / not on PATH here.
                        lastErr = "اجرای ffmpeg ناموفق بود — مطمئن شوید FFmpeg نصب و به PATH اضافه شده: " + ex.Message;
                        break;
                    }

                    // Exiting within the first seconds is a start-up failure (capture
                    // method missing, audio device missing, server unreachable).
                    bool exitedEarly;
                    try { exitedEarly = proc.WaitForExit(3000); } catch { exitedEarly = true; }
                    if (!exitedEarly)
                    {
                        if (gen != _videoGen) return;
                        try
                        {
                            _net.SendMessage(new NetMessage(MessageType.ClientVideoStreamStatus,
                                new VideoStreamStatusPayload { StationName = sv.StationName, Started = true }, _sessionId));
                        }
                        catch { }
                        return;
                    }
                    lock (stderrBuffer) lastErr = stderrBuffer.ToString().Trim();
                    if (string.IsNullOrWhiteSpace(lastErr)) lastErr = "ffmpeg بدون پیام خطا زود بسته شد.";
                    try { AuditLogSafe("Video capture attempt failed: " + lastErr); } catch { }
                }
                if (gen != _videoGen) return;
                try
                {
                    _net.SendMessage(new NetMessage(MessageType.ClientVideoStreamStatus,
                        new VideoStreamStatusPayload { StationName = sv.StationName, Started = false, Error = lastErr }, _sessionId));
                }
                catch { }
            });
        }

        private void StopVideoStream()
        {
            _videoGen++; // round 13: a start still trying capture methods gives up
            Process p;
            lock (_videoStreamLock) { p = _videoStreamProcess; _videoStreamProcess = null; }
            if (p == null) return;
            try { if (!p.HasExited) p.Kill(); } catch { }
            try { p.Dispose(); } catch { }
        }

        public void CheckSession()
        {
            if (State != ClientState.InSession || !_sessionStart.HasValue) return;
            var el = DateTime.UtcNow - _sessionStart.Value;
            int min = Math.Max(1, (int)el.TotalMinutes);
            decimal cost = Math.Round(_pricePerHour / 60m * min, 0);
            int? rem = _pricePerHour > 0 && _balance > 0
                ? Math.Max(0, (int)(_balance / _pricePerHour * 60m) - min)
                : (int?)null;
            OnSessionUpdate?.Invoke(el, cost, rem);
        }

        // Phase 3: Chat
        public void SendChatMessage(string message, string targetUsername = null, bool isBroadcast = false)
        {
            // ADD-CLIENT-25 — Task 15: log chat message preview.
            try { ActivityLogger.ChatSent(message); } catch { }
            SendSafe(new NetMessage(MessageType.ClientChatSend, new ChatSendPayload { SenderUsername = _username, Message = message, TargetUsername = targetUsername, IsBroadcast = isBroadcast }, _sessionId));
        }
        public void RequestChatHistory()
        { SendSafe(new NetMessage(MessageType.ClientChatHistory, null, _sessionId)); }

        // Phase 3: Announcements
        public void RequestAnnouncements()
        { SendSafe(new NetMessage(MessageType.ClientAnnouncementList, null, _sessionId)); }

        // Phase 3: Print
        public void RequestPrint(string documentName, int pages, string printType = "bw", string notes = "")
        { SendSafe(new NetMessage(MessageType.ClientPrintRequest, new PrintRequestPayload { Username = _username, StationName = Environment.MachineName, DocumentName = documentName, Pages = pages, PrintType = printType, Notes = notes }, _sessionId)); }

        // Phase 3: Debt & Packages & Tier
        public void RequestDebtList() { SendSafe(new NetMessage(MessageType.ClientDebtList, null, _sessionId)); }
        public void RequestPackageList() { SendSafe(new NetMessage(MessageType.ClientPackageList, null, _sessionId)); }
        public void PurchasePackage(int packageId) { SendSafe(new NetMessage(MessageType.ClientPackagePurchase, new PackagePurchasePayload { PackageId = packageId, Username = _username }, _sessionId)); }
        public void RequestTierInfo() { SendSafe(new NetMessage(MessageType.ClientTierInfo, null, _sessionId)); }

        // Phase 4: 2FA
        public void Verify2FA(string code) { SendSafe(new NetMessage(MessageType.Client2FAVerify, new TwoFactorVerifyPayload { Username = _username, Code = code }, _sessionId)); }

        // Phase 5: Theme & Language
        public void RequestTheme() { SendSafe(new NetMessage(MessageType.ClientThemeRequest, null, _sessionId)); }
        public void ChangeLanguage(string lang) { SendSafe(new NetMessage(MessageType.ClientLangChange, new LanguageChangePayload { Language = lang }, _sessionId)); }

        // Phase 6: Smart Pricing & Auto Recharge
        public void RequestSmartPrice() { SendSafe(new NetMessage(MessageType.ClientSmartPriceRequest, null, _sessionId)); }
        public void SetAutoRecharge(decimal threshold, decimal amount, bool enabled) { SendSafe(new NetMessage(MessageType.ClientAutoRechargeConfig, new AutoRechargeConfigPayload { ThresholdAmount = threshold, RechargeAmount = amount, Enabled = enabled }, _sessionId)); }

        // Phase 7: Payment
        public void RequestPayment(decimal amount, string description = "") { SendSafe(new NetMessage(MessageType.ClientPaymentRequest, new PaymentRequestPayload { Username = _username, Amount = amount, Description = description }, _sessionId)); }

        private void TryConnect()
        {
            if (_disposed) return;
            try
            {
                _welcomed = false;
                _welcomeTimedOut = false;
                _resumeSent = false;
                _pendingDropDetail = null;
                _net.Connect(ServerHost, ServerPort);
                State = ClientState.Connected;
                // Self-repair: the welcome watchdog is armed BEFORE the hello is sent,
                // so a fast reply can never race it.
                StartWelcomeWatchdog();

                // H1: if we already have a session id from before the disconnect,
                // try to resume it via ClientReconnect instead of sending a fresh
                // ClientHello. The server either re-validates the session (and
                // sends ServerWelcome with the SAME session id / a SessionInfo
                // message) or rejects it (and sends ServerWelcome with a NEW
                // session id, in which case we surface a "session expired"
                // notice and require re-login).
                // Round 5: this server answers a rejected resume with ServerLoginFail
                // instead; Dispatch(ServerLoginFail) then sends a fresh ClientHello on
                // the same link, so the station is registered again.
                if (!string.IsNullOrEmpty(_lastSessionId))
                {
                    _resumeSent = true;
                    SendSafe(new NetMessage(MessageType.ClientReconnect,
                        new ClientReconnectPayload
                        {
                            PreviousSessionId = _lastSessionId,
                            MachineName = Environment.MachineName,
                            MacAddress = NetworkClient.GetMacAddress(),
                            ClientVersion = Protocol.ServerVersion,
                            StationName = Environment.MachineName
                        }, _lastSessionId));
                    // FIX (FIX-FINAL-10 B8): do NOT raise OnConnected here.
                    // The success of a reconnect is decided by the server's
                    // ServerWelcome reply (same SessionId = resume OK, different
                    // SessionId = reject). Raising OnConnected prematurely (here)
                    // AND again in Dispatch(ServerWelcome) caused the kiosk UI to
                    // receive OnConnected TWICE on every reconnect — the handler
                    // in KioskForm re-runs lblStatus update + restarts the billing
                    // timer twice. Cosmetic on the success path, but on the REJECT
                    // path it produced a confusing sequence: "متصل به سرور" toast
                    // (from here), then "نشست منقضی شده" warning, then a forced
                    // login-panel switch — the "متصل" toast was misleading because
                    // the session was actually being torn down. Dispatch(ServerWelcome)
                    // raises OnConnected after the server's verdict is known, so
                    // skipping it here is correct.
                }
                else
                {
                    SendClientHello();
                    // OnConnected is NOT raised here. The server's ServerWelcome decides
                    // whether this station is accepted, and Dispatch raises OnConnected then.
                }
                // The attempt counters are NOT cleared here. A TCP connect that the server
                // then refuses must keep the backoff growing; they are cleared on ServerWelcome.

                // Flush any pending crash reports that were saved locally
                // while the client was disconnected.
                // FIX 25: FlushPendingCrashes now takes a Func<payload,bool>
                // and only deletes the file when the send returned true —
                // previously crash reports were deleted even on send failure.
                try
                {
                    CrashReporter.FlushPendingCrashes(payload =>
                    {
                        return SendSafe(new NetMessage(MessageType.ClientCrashReport, payload));
                    });
                }
                catch { }

                // Medium: dispose the previous heartbeat timer before creating a
                // new one to avoid handle leaks during reconnect cycling.
                try { _heartbeat?.Dispose(); } catch { }
                _heartbeat = new Timer(_ =>
                {
                    try
                    {
                        // Send a ClientStatusPayload in the heartbeat so the
                        // server can display live CPU/RAM/disk in the monitor.
                        var status = new ClientStatusPayload
                        {
                            StationName = Environment.MachineName,
                            State = (GameNet.Shared.ClientState)State,
                            CurrentGame = "",
                            CpuUsage = SystemMonitor.GetCpuUsage(),
                            MemoryUsage = SystemMonitor.GetMemoryUsage(),
                            DiskFreeMb = SystemMonitor.GetDiskFreeMb(),
                            IsOnline = true,
                            ActiveWindowTitle = GetActiveWindowTitle(),
                            OsVersion = Environment.OSVersion.VersionString,
                            // FIX DEAD-CONFIG-2: feeds the server's idle-shutdown check.
                            IdleSeconds = SystemMonitor.GetIdleSeconds()
                        };
                        _net.SendMessage(new NetMessage(MessageType.ClientHeartbeat, status, _sessionId));
                        // Round 15: saved reports trickle out, two per heartbeat.
                        if (_welcomed)
                            try { CrashReporter.FlushPendingCrashes(rp => SendSafe(new NetMessage(MessageType.ClientCrashReport, rp)), 2); } catch { }
                    }
                    catch { /* heartbeat failure will trip OnDisconnected naturally */ }
                }, null, TimeSpan.FromSeconds(Protocol.HeartbeatIntervalSeconds),
                   TimeSpan.FromSeconds(Protocol.HeartbeatIntervalSeconds));
            }
            catch (Exception ex)
            {
                ReportConnectFailure(ex);
                ScheduleReconnect();
            }
        }

        /// <summary>
        /// Self-repair: explains a failed connect with a catalogue code (NET-001 server
        /// unreachable, NET-002 / NET-003 / NET-004 TLS, CFG-003 pin file) instead of
        /// failing silently.
        /// </summary>
        private void ReportConnectFailure(Exception ex)
        {
            string tlsReason = null;
            try { tlsReason = _net.UseTls ? _net.LastTlsError : null; } catch { }
            string code;
            if (!string.IsNullOrEmpty(tlsReason)) code = FaultCatalog.ClassifyTlsReason(tlsReason);
            else if (_net.UseTls && !(ex is System.Net.Sockets.SocketException) && !(ex is TimeoutException)) code = "NET-002";
            else code = "NET-001";
            string detail = ex.GetType().Name + ": " + ex.Message +
                (string.IsNullOrEmpty(tlsReason) ? "" : " | tls: " + tlsReason);
            ReportFault(code, detail, ServerHost + ":" + ServerPort);
        }

        /// <summary>
        /// Shows a fault on the kiosk (OnFault) and writes it to diagnostics.log.
        /// A code that is throttled returns null and is not repeated.
        /// </summary>
        private void ReportFault(string code, string detail, string throttleKey = null, string repair = null)
        {
            try
            {
                FaultRecord rec = FaultJournal.Raise(code, detail, throttleKey, repair);
                if (rec != null)
                {
                    try { OnFault?.Invoke(rec); } catch { }
                }
            }
            catch { }
        }

        /// <summary>
        /// Sends ClientHello on the current link. This is the station's registration: the
        /// server runs its ACL, integrity and station-password checks on it and answers
        /// with ServerWelcome or ServerLoginFail. Used by TryConnect for a fresh connect
        /// and, since round 5, after the server rejects a ClientReconnect (see
        /// Dispatch, ServerLoginFail). The payload is the one TryConnect always sent.
        /// </summary>
        private void SendClientHello()
        {
            SendSafe(new NetMessage(MessageType.ClientHello,
                new ClientHelloPayload
                {
                    MachineName = Environment.MachineName,
                    // REAPPLY-KIOSK-CHANGES-1: when the operator has
                    // pinned a specific network adapter in the handyCafe
                    // client Options dialog, use that MAC instead of the
                    // auto-detected one. This lets the operator lock the
                    // fingerprint to a stable NIC (e.g. the wired LAN
                    // card) so the license doesn't break when a USB
                    // ethernet adapter is plugged/unplugged.
                    MacAddress = !string.IsNullOrWhiteSpace(ClientOptions.SelectedAdapterMac)
                        ? ClientOptions.SelectedAdapterMac
                        : NetworkClient.GetMacAddress(),
                    ClientVersion = Protocol.ServerVersion,
                    StationName = Environment.MachineName,
                    MachineFingerprint = ClientLicenseFingerprint.Generate(),
                    LicenseToken = ClientLicenseFingerprint.LoadCachedToken(),
                    OsVersion = Environment.OSVersion.VersionString,
                    PlayAndPay = _playAndPay,
                    // FIX H1: send the self-hash so the server can
                    // reject tampered clients. Previously this field
                    // was computed in Program.cs (ComputeSelfHash)
                    // but never actually sent — the integrity check
                    // was documented as a feature but did nothing.
                    SelfHash = ClientIntegrity.ComputeSelfHash() ?? "",
                    // REAPPLY-KIOSK-CHANGES-1: handyCafe server/client
                    // shared secret. The server can use this to reject
                    // non-GameNet clients trying to spoof a kiosk.
                    ServerClientPassword = ClientOptions.ServerClientPassword ?? ""
                }));
        }

        /// <summary>
        /// Self-repair (NET-005): armed BEFORE the hello is sent, so a fast ServerWelcome
        /// can never race it. If no ServerWelcome arrives in time, the link is dropped.
        /// </summary>
        private void StartWelcomeWatchdog()
        {
            CancelWelcomeWatchdog();
            int generation = Interlocked.Increment(ref _welcomeGeneration);
            try
            {
                _welcomeTimer = new Timer(_ => OnWelcomeTimeout(generation), null,
                    TimeSpan.FromSeconds(WelcomeTimeoutSeconds), Timeout.InfiniteTimeSpan);
            }
            catch { }
        }

        private void CancelWelcomeWatchdog()
        {
            // A timer callback that is already queued checks this generation and does nothing.
            Interlocked.Increment(ref _welcomeGeneration);
            try { _welcomeTimer?.Dispose(); } catch { }
            _welcomeTimer = null;
        }

        private void OnWelcomeTimeout(int generation)
        {
            if (_disposed || _welcomed) return;
            if (generation != Volatile.Read(ref _welcomeGeneration)) return;
            _welcomeTimedOut = true;
            _pendingDropDetail = "no ServerWelcome within " + WelcomeTimeoutSeconds + " s";
            ReportFault("NET-005", "no ServerWelcome from " + ServerHost + ":" + ServerPort +
                " within " + WelcomeTimeoutSeconds + " s", ServerHost + ":" + ServerPort);
            // Closing the socket makes the read thread call OnNetDisconnected, which
            // schedules the reconnect. It is not called here, so the drop is not counted twice.
            try { _net.Disconnect(); } catch { }
        }

        private void ScheduleReconnect()
        {
            if (_disposed) return;
            // Self-repair (FMEA NET-006): after MaxReconnectAttempts fast tries the kiosk
            // does not stop. It retries every SlowRetrySeconds until the server is back,
            // and the operator is told once per outage (not on every retry).
            if (_reconnectAttempts >= Protocol.MaxReconnectAttempts)
            {
                if (!_gaveUp)
                {
                    _gaveUp = true;
                    ReportFault("NET-006", "no answer after " + _reconnectAttempts +
                        " fast attempts; retrying every " + SlowRetrySeconds + " s", ServerHost + ":" + ServerPort);
                    try { OnReconnectGaveUp?.Invoke(); } catch { }
                }
                try { _reconnect?.Dispose(); } catch { }
                _reconnect = new Timer(_ => TryConnect(), null,
                    TimeSpan.FromSeconds(SlowRetrySeconds), Timeout.InfiniteTimeSpan);
                return;
            }
            _reconnectAttempts++;
            // Self-repair (rule R1): exponential backoff 1s, 2s, 4s ... capped at
            // ReconnectMaxDelayMs, with up to 20% random jitter.
            TimeSpan nominal = RecoveryPolicy.Backoff(_reconnectAttempts,
                TimeSpan.FromMilliseconds(1000), TimeSpan.FromMilliseconds(ReconnectMaxDelayMs));
            TimeSpan delay = RecoveryPolicy.WithJitter(nominal, 0.2);

            // Notify the UI so it can show a "در حال اتصال مجدد..." toast on each attempt.
            try { OnReconnectAttempt?.Invoke(_reconnectAttempts, (int)delay.TotalMilliseconds); } catch { }

            // Medium: dispose the previous reconnect timer before creating a new one.
            try { _reconnect?.Dispose(); } catch { }
            _reconnect = new Timer(_ => TryConnect(), null, delay, Timeout.InfiniteTimeSpan);
        }

        private void HandleMsg(NetMessage msg)
        {
            // Medium: wrap the whole switch in try/catch — a single malformed
            // message must NOT disconnect the client (was the case before because
            // the exception bubbled into ReadLoop's catch-break). Log and skip.
            if (msg == null) return;
            try
            {
                Dispatch(msg);
            }
            catch (Exception ex)
            {
                // Skip the bad message; do NOT propagate (would disconnect).
                // FIX L14: log silently to the local audit file instead of
                // invoking OnServerMessage (which shows a MessageBox on the
                // kiosk). A misbehaving server or a MITM injecting garbage
                // could otherwise MessageBox-spam the kiosk — annoying the
                // customer and potentially covering the game window. The
                // audit log captures the error for the operator to review.
                try { AuditLogSafe("HandleMsg error (type=" + msg.Type + "): " + ex.Message); } catch { }
            }
        }

        private void Dispatch(NetMessage msg)
        {
            switch (msg.Type)
            {
                case MessageType.ServerWelcome:
                    {
                        var w = msg.GetPayload<ServerWelcomePayload>();
                        if (w != null)
                        {
                            // Self-repair: the server accepted this link. The welcome
                            // watchdog stops here, and the backoff is cleared at the end of
                            // this block (never on a bare TCP connect).
                            CancelWelcomeWatchdog();
                            _welcomed = true;
                            // Round 12: these connection settings work: keep a last-good copy.
                            try { ConnectionSettings.SnapshotLastGood(); } catch { }
                            bool recovered = _reconnectAttempts > 0 || _gaveUp;
                            int attemptsBefore = _reconnectAttempts;
                            // FIX C2: distinguish reconnect-success from reconnect-reject.
                            // - If we sent a ClientReconnect (i.e. _lastSessionId is set)
                            //   and the server replied with the SAME session id, the
                            //   resume succeeded — restore State=InSession immediately so
                            //   the kiosk doesn't bounce the user back to the login screen
                            //   (which would create a duplicate server-side session).
                            // - If the server replied with a DIFFERENT session id, the
                            //   resume was rejected — surface it and require re-login.
                            if (!string.IsNullOrEmpty(_lastSessionId) &&
                                !string.IsNullOrEmpty(w.SessionId) &&
                                w.SessionId == _lastSessionId)
                            {
                                // Reconnect SUCCESS — restore session state from
                                // the fields we preserved across OnNetDisconnected.
                                State = ClientState.InSession;
                                OnConnected?.Invoke();
                                // Request fresh balance/price from the server to be safe.
                                SendSafe(new NetMessage(MessageType.ClientSessionInfo, null, _sessionId));
                                AuditLogSafe("Reconnect SUCCESS — session restored, id=" + w.SessionId);
                            }
                            else if (!string.IsNullOrEmpty(_lastSessionId) &&
                                !string.IsNullOrEmpty(w.SessionId) &&
                                w.SessionId != _lastSessionId)
                            {
                                // Reconnect REJECTED — old session is gone.
                                _lastSessionId = null;
                                _sessionStart = null;
                                State = ClientState.Connected;
                                OnConnected?.Invoke();
                                OnServerMessage?.Invoke("نشست", "⚠️ نشست قبلی منقضی شده است. لطفاً دوباره وارد شوید.", "warning");
                                // FIX (FIX-FINAL-10 B5): previously the kiosk
                                // stayed on the session panel after a reconnect
                                // was rejected — State was set to Connected but
                                // no event switched the UI back to the login
                                // panel. KioskForm's OnTimeExpired handler
                                // stops the billing timer, kills running games,
                                // and calls ShowLoginPanel(); raising it here
                                // produces the correct UX (login screen shown
                                // to the user, who can then re-authenticate).
                                OnTimeExpired?.Invoke();
                            }
                            else
                            {
                                // Fresh connect (no previous session) — normal flow.
                                OnConnected?.Invoke();
                            }
                            _sessionId = w.SessionId;
                            _reconnectAttempts = 0;
                            _gaveUp = false;
                            if (recovered)
                                ReportFault("NET-900", "ServerWelcome received after " + attemptsBefore +
                                    " reconnect attempt(s)", ServerHost + ":" + ServerPort);
                        }
                        break;
                    }
                case MessageType.ServerLoginOk:
                    {
                        var ok = msg.GetPayload<ServerLoginResultPayload>();
                        if (ok != null && ok.Success)
                        {
                            State = ClientState.InSession;
                            _username = ok.DisplayName;
                            _balance = ok.Balance;
                            _pricePerHour = ok.PricePerHour;
                            _sessionStart = DateTime.UtcNow;
                            // Session is now confirmed by the server — clear the
                            // "pending reconnect" marker.
                            _lastSessionId = _sessionId;
                        }
                        OnLoginResult?.Invoke(ok?.Success ?? false, ok?.Message ?? "", ok?.DisplayName ?? "", ok?.Balance ?? 0, ok?.PricePerHour ?? 0);
                        break;
                    }
                case MessageType.ServerLoginFail:
                    {
                        var f = msg.GetPayload<ServerLoginResultPayload>();
                        if (!_welcomed && _resumeSent)
                        {
                            // Self-repair: after ClientReconnect the server answers an unknown or expired
                            // session with a login challenge and keeps the link open. That is not a refusal
                            // of the station: the server is reachable but no longer knows this station.
                            //
                            // Round 5 (FIX RECONNECT-DEADLOCK, ported from the other source line and fitted
                            // to the self-repair flow): this branch used to count the link as restored and
                            // kept _lastSessionId. The station then never sent ClientHello again, so the
                            // server never registered it (it was missing from the client monitor), and every
                            // later reconnect was another ClientReconnect rejected the same way until the
                            // kiosk program was restarted. Typical trigger: the server program restarted, or
                            // the kiosk was offline for more than 180 s.
                            // Now the stale session is dropped and a fresh ClientHello is sent on the same
                            // link, so the server runs its normal hello checks (ACL, integrity, station
                            // password) and registers the station. Its ServerWelcome takes the fresh-connect
                            // branch above, raises OnConnected and clears the retry state (NET-900 is
                            // recorded there when retries were needed).
                            // The welcome watchdog is re-armed for that hello, and _resumeSent is cleared so
                            // a refusal of the hello is handled as a station refusal by the branch below.
                            // _sessionId is cleared too, so a drop before that welcome cannot put the old id
                            // back into _lastSessionId (OnNetDisconnected copies it). The user still sees
                            // the server's message through OnLoginResult, as before.
                            _lastSessionId = null;
                            _sessionId = null;
                            _sessionStart = null;
                            _resumeSent = false;
                            StartWelcomeWatchdog();
                            SendClientHello();
                            OnLoginResult?.Invoke(false, f?.Message ?? "ورود ناموفق", "", 0, 0);
                            break;
                        }
                        if (!_welcomed)
                        {
                            // Self-repair: a refusal that arrives before ServerWelcome is about this
                            // station, not about a login the user typed. It is shown as a station
                            // notice (repeats are not stacked) and recorded as NET-008 when the
                            // server closes the link.
                            _pendingDropDetail = "refused by server: " + (f?.Message ?? "");
                            OnServerMessage?.Invoke("دسترسی کیوسک", f?.Message ?? "دسترسی رد شد", "warning");
                            break;
                        }
                        OnLoginResult?.Invoke(false, f?.Message ?? "ورود ناموفق", "", 0, 0);
                        break;
                    }
                case MessageType.ServerTimeWarning:
                    {
                        var tw = msg.GetPayload<ServerTimeWarningPayload>();
                        if (tw != null) OnTimeWarning?.Invoke(tw.MinutesRemaining, tw.Message, tw.IsCritical);
                        break;
                    }
                case MessageType.ServerTimeExpired:
                    State = ClientState.Connected;
                    _sessionStart = null;
                    _lastSessionId = null;
                    OnTimeExpired?.Invoke();
                    break;
                case MessageType.ServerForceLogout:
                    {
                        var fl = msg.GetPayload<ServerMessagePayload>();
                        State = ClientState.Connected;
                        _sessionStart = null;
                        _lastSessionId = null;
                        OnForceLogout?.Invoke(fl?.Body ?? "خروج اجباری");
                        break;
                    }
                case MessageType.ServerPriceInfo:
                    {
                        var pi = msg.GetPayload<PriceInfoPayload>();
                        if (pi != null) { _pricePerHour = pi.PricePerHour; OnPriceUpdate?.Invoke(pi.PricePerHour); }
                        break;
                    }
                case MessageType.ServerAddCredit:
                    {
                        var ac = msg.GetPayload<AddCreditPayload>();
                        if (ac != null)
                        {
                            _balance = ac.NewBalance; // update local balance immediately
                            OnCreditAdded?.Invoke(ac);
                        }
                        break;
                    }
                case MessageType.ServerSetSessionTime:
                    {
                        var st = msg.GetPayload<SetSessionTimePayload>();
                        if (st != null)
                        {
                            // Action 0=SetTime, 1=AddTime, 2=Unlimited, 3=EndNow
                            if (st.Action == 3)
                            {
                                // FIX (FIX-FINAL-10 B7): do NOT call Logout()
                                // for action=3. The server sent this message
                                // BECAUSE it has already ended the session
                                // server-side (the operator clicked "End now"
                                // on the server's session-management UI, which
                                // closes the server-side session row and pushes
                                // ServerSetSessionTime{Action=3} to inform the
                                // client). Calling Logout() here sends a
                                // ClientLogout message referencing a session id
                                // the server has already torn down — the server
                                // then has to handle a logout for a non-existent
                                // session (logged as a warning, harmless but
                                // noisy), and worse, the ClientLogout send
                                // failing (because the server already dropped
                                // the conn) would leave Logout() in its "send
                                // failed, keep state" branch — i.e. _sessionId /
                                // _lastSessionId NOT cleared, so the next
                                // reconnect would try to resume a session the
                                // server no longer has, hit the B5 reject path,
                                // and pop a "نشست منقضی شده" warning. By clearing
                                // local state directly and raising OnTimeExpired
                                // (which switches the UI to the login panel) we
                                // skip the redundant Logout round-trip entirely.
                                State = ClientState.Connected;
                                _sessionStart = null;
                                _sessionId = null;
                                _lastSessionId = null; // session is gone server-side
                                OnTimeExpired?.Invoke();
                            }
                            else { OnServerMessage?.Invoke("زمان", $"زمان نشست شما تغییر یافت (عملیات: {st.Action}, {st.Minutes} دقیقه)", "info"); }
                        }
                        break;
                    }
                case MessageType.ServerMuteClient:
                    {
                        var mc = msg.GetPayload<MuteClientPayload>();
                        if (mc != null)
                        {
                            try
                            {
                                if (mc.Mute) { for (int i = 0; i < 10; i++) { } /* mute: set volume to 0 via API */ }
                                else { /* unmute: restore volume */ }
                                OnServerMessage?.Invoke("صدا", mc.Mute ? "صدا قطع شد" : "صدا وصل شد", "info");
                            }
                            catch { }
                        }
                        break;
                    }
                case MessageType.ServerUsbControl:
                    {
                        var uc = msg.GetPayload<UsbControlPayload>();
                        if (uc != null)
                        {
                            // ADD-CLIENT-25 — Task 14 + 15: toggle USB storage
                            // via the HKLM registry key (Start=3 enabled, Start=4
                            // disabled). Requires admin — wrap in try/catch.
                            // Also log the toggle to the activity log (task 15).
                            try
                            {
                                using (var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                    @"SYSTEM\CurrentControlSet\Services\USBSTOR", true))
                                {
                                    if (key != null)
                                    {
                                        key.SetValue("Start", uc.Enable ? 3 : 4, Microsoft.Win32.RegistryValueKind.DWord);
                                        key.Close();
                                    }
                                }
                                try { ActivityLogger.UsbToggled(uc.Enable); } catch { }
                                OnServerMessage?.Invoke("USB", uc.Enable ? "USB فعال شد" : "USB غیرفعال شد", "info");
                            }
                            catch (Exception ex) { OnServerMessage?.Invoke("USB", "خطا: " + ex.Message, "error"); }
                        }
                        break;
                    }
                case MessageType.ServerInternetControl:
                    {
                        var ic = msg.GetPayload<InternetControlPayload>();
                        if (ic != null)
                        {
                            try
                            {
                                // Round 15: internet only. The old rule ("dir=out action=block"
                                // with no address) blocked every outgoing connection, the one to
                                // this server too, so the kiosk vanished from the server for good.
                                string err;
                                bool ok = GameNet.Shared.SelfHeal.FirewallHelper.SetKioskInternet(ic.Enable, ServerHost, out err);
                                if (ok)
                                    OnServerMessage?.Invoke("اینترنت", ic.Enable ? "اینترنت وصل شد" : "اینترنت قطع شد (شبکهٔ داخلی و سرور وصل می‌مانند)", "info");
                                else
                                    OnServerMessage?.Invoke("اینترنت", "قطع اینترنت انجام نشد: کیوسک دسترسی مدیر ویندوز ندارد. " + (err ?? ""), "error");
                            }
                            catch (Exception ex) { OnServerMessage?.Invoke("اینترنت", "خطا: " + ex.Message, "error"); }
                        }
                        break;
                    }
                case MessageType.ServerTicketResult:
                    {
                        var tr = msg.GetPayload<TicketResultPayload>();
                        if (tr != null)
                        {
                            OnServerMessage?.Invoke("نتیجه تیکت", tr.Success ? $"اعتبار: {tr.CreditAmount:N0} تومان" : tr.Message, tr.Success ? "info" : "error");
                            if (tr.Success) _balance += tr.CreditAmount;
                        }
                        break;
                    }
                case MessageType.ServerMessage:
                    {
                        var sm = msg.GetPayload<ServerMessagePayload>();
                        string title = sm?.Title ?? "";
                        string body = sm?.Body ?? "";

                        // FIX 8 / 10 / 11: intercept specific machine-control
                        // titles and execute locally on the kiosk. Anything
                        // we don't recognise falls through to the default
                        // behaviour (forward to the UI via OnServerMessage).
                        bool handled = HandleControlMessage(title, body);
                        if (!handled)
                            OnServerMessage?.Invoke(title, body, sm?.Level ?? "info");
                        break;
                    }
                case MessageType.ServerLockClient:
                    // Medium: save the pre-lock state so ServerUnlockClient can
                    // restore it (was hardcoded to Connected → broke the
                    // OnUnlocked handler in KioskForm that checks InSession).
                    //
                    // FIX (FIX-FINAL-10 B6): only capture _preLockState if the
                    // client is NOT already locked. The operator can click
                    // "Lock" again while the client is already locked (e.g. the
                    // first lock didn't visually take effect due to a slow UI
                    // thread, so they click again). Previously the second
                    // ServerLockClient overwrote _preLockState with
                    // ClientState.Locked — then on ServerUnlockClient the State
                    // was "restored" to Locked, leaving the kiosk stuck locked
                    // forever (no event would ever set it back to InSession).
                    if (State != ClientState.Locked)
                        _preLockState = State;
                    State = ClientState.Locked;
                    OnLocked?.Invoke();
                    break;
                case MessageType.ServerUnlockClient:
                    // Restore pre-lock state — typically InSession.
                    State = (_preLockState == ClientState.Disconnected)
                        ? ClientState.Connected
                        : _preLockState;
                    OnUnlocked?.Invoke();
                    break;
                // FIX L6: UseShellExecute=false + dispose the Process. The
                // previous `Process.Start("shutdown", ...)` used the default
                // UseShellExecute=true which relies on PATH resolution and
                // shell-extension quirks. Explicit UseShellExecute=false +
                // FileName="shutdown.exe" is more robust, and disposing the
                // Process avoids a handle leak per shutdown/restart command.
                // NEW FEATURE (remote input, per request): injects a
                // mouse/keyboard event received from the operator's live
                // monitoring view. Runs on whatever thread messages are
                // dispatched on — SetCursorPos/mouse_event/keybd_event are
                // plain Win32 calls with no UI-thread requirement, unlike
                // WinForms control access, so no BeginInvoke is needed here.
                case MessageType.ServerRemoteInput:
                    {
                        var ri = msg.GetPayload<RemoteInputPayload>();
                        if (ri != null)
                        {
                            RemoteInputInjector.Inject(ri);
                            // Round 11: tell the customer (once per stretch of control) that
                            // the operator is using this PC's mouse and keyboard.
                            var nowUtc = DateTime.UtcNow;
                            if ((nowUtc - _lastRemoteInputAt).TotalSeconds > 60)
                            {
                                try { OnRemoteControlActive?.Invoke(); } catch { }
                            }
                            _lastRemoteInputAt = nowUtc;
                        }
                        break;
                    }
                // NEW FEATURE (real video+audio codec, per request).
                case MessageType.ServerStartVideoStream:
                    {
                        var sv = msg.GetPayload<StartVideoStreamPayload>();
                        if (sv != null) StartVideoStream(sv);
                        break;
                    }
                case MessageType.ServerStopVideoStream:
                    {
                        StopVideoStream();
                        break;
                    }
                case MessageType.ServerShutdown:
                    {
                        try
                        {
                            var psi = new ProcessStartInfo("shutdown.exe", "/s /t 0")
                            { CreateNoWindow = true, UseShellExecute = false };
                            using (var proc = Process.Start(psi)) { /* fire and forget */ }
                        }
                        catch { }
                        break;
                    }
                case MessageType.ServerRestart:
                    {
                        try
                        {
                            var psi = new ProcessStartInfo("shutdown.exe", "/r /t 0")
                            { CreateNoWindow = true, UseShellExecute = false };
                            using (var proc = Process.Start(psi)) { /* fire and forget */ }
                        }
                        catch { }
                        break;
                    }

                // Phase 9: Remote monitoring
                case MessageType.ServerScreenshotRequest: HandleScreenshotRequest(msg); break;

                // Phase 10: Auto-update + file transfer + crash report
                case MessageType.ServerUpdateOffer: HandleUpdateOffer(msg); break;
                case MessageType.ServerUpdateChunk: HandleUpdateChunk(msg); break;
                case MessageType.ServerFileTransferOffer: HandleFileTransferOffer(msg); break;
                case MessageType.ServerFileTransferChunk: HandleFileTransferChunk(msg); break;

                // Phase 3 handlers
                case MessageType.ServerChatReceive: { var chat = msg.GetPayload<ChatReceivePayload>(); if (chat != null) OnChatMessage?.Invoke(chat); break; }
                case MessageType.ServerChatHistory: { var chatHist = msg.GetPayload<ChatHistoryPayload>(); if (chatHist != null) OnChatHistory?.Invoke(chatHist); break; }
                case MessageType.ServerAnnouncementList: { var ann = msg.GetPayload<AnnouncementListPayload>(); if (ann != null) OnAnnouncements?.Invoke(ann); break; }
                case MessageType.ServerAnnouncementNew: { var annNew = msg.GetPayload<AnnouncementPayload>(); if (annNew != null) OnAnnouncements?.Invoke(new AnnouncementListPayload { Announcements = new List<AnnouncementPayload> { annNew } }); break; }
                case MessageType.ServerPrintResult: { var pr = msg.GetPayload<PrintResultPayload>(); if (pr != null) OnPrintResult?.Invoke(pr); break; }
                case MessageType.ServerDebtList: { var debts = msg.GetPayload<DebtListPayload>(); if (debts != null) OnDebtList?.Invoke(debts); break; }
                case MessageType.ServerPackageList: { var pkgs = msg.GetPayload<PackageListPayload>(); if (pkgs != null) OnPackageList?.Invoke(pkgs); break; }
                case MessageType.ServerPackageResult: { var pkgRes = msg.GetPayload<PackageResultPayload>(); if (pkgRes != null) OnPackageResult?.Invoke(pkgRes); break; }
                case MessageType.ServerTierInfo: { var tier = msg.GetPayload<TierInfoPayload>(); if (tier != null) OnTierInfo?.Invoke(tier); break; }

                // Phase 4 handlers
                case MessageType.Server2FAResult: { var tfa = msg.GetPayload<TwoFactorResultPayload>(); if (tfa != null) On2FAResult?.Invoke(tfa); break; }
                case MessageType.ServerSecurityAlert: { var secAlert = msg.GetPayload<SecurityAlertPayload>(); if (secAlert != null) OnSecurityAlert?.Invoke(secAlert); break; }

                // Phase 5 handlers
                case MessageType.ServerThemeData: { var theme = msg.GetPayload<ThemeDataPayload>(); if (theme != null) OnThemeData?.Invoke(theme); break; }
                case MessageType.ServerNotification: { var notif = msg.GetPayload<NotificationPayload>(); if (notif != null) OnNotification?.Invoke(notif); break; }

                // Phase 6 handlers
                case MessageType.ServerSmartPriceInfo: { var sp = msg.GetPayload<SmartPricePayload>(); if (sp != null) OnSmartPriceInfo?.Invoke(sp); break; }
                case MessageType.ServerAutoRechargeResult: { var ar = msg.GetPayload<AutoRechargeResultPayload>(); if (ar != null) OnAutoRechargeResult?.Invoke(ar); break; }
                case MessageType.ServerTrafficPrediction: { var tp = msg.GetPayload<TrafficPredictionPayload>(); if (tp != null) OnTrafficPrediction?.Invoke(tp); break; }

                // Phase 7 handlers
                case MessageType.ServerPaymentUrl: { var payUrl = msg.GetPayload<PaymentUrlPayload>(); if (payUrl != null) OnPaymentUrl?.Invoke(payUrl); break; }
                case MessageType.ServerPaymentVerified: { var payVer = msg.GetPayload<PaymentVerifiedPayload>(); if (payVer != null) OnPaymentVerified?.Invoke(payVer); break; }

                // Phase 8 handlers
                case MessageType.ServerUpdateAvailable: { var upd = msg.GetPayload<ServerUpdatePayload>(); if (upd != null) OnUpdateAvailable?.Invoke(upd); break; }
                case MessageType.ServerConfigSync: { var cfg = msg.GetPayload<ConfigSyncPayload>(); if (cfg != null) OnConfigSync?.Invoke(cfg); break; }

                // Phase 11: Quick top-up response
                case MessageType.ServerTopupResponse: { var tr = msg.GetPayload<TopupResponsePayload>(); if (tr != null) OnTopupResponse?.Invoke(tr); break; }

                // Phase 13: UX enhancement handlers
                case MessageType.ServerFoodOrderResponse: { var fr = msg.GetPayload<FoodOrderResponsePayload>(); if (fr != null) OnFoodOrderResponse?.Invoke(fr); break; }
                case MessageType.ServerSessionHistory: { var sh = msg.GetPayload<SessionHistoryPayload>(); if (sh != null) OnSessionHistory?.Invoke(sh); break; }
                case MessageType.ServerPauseResponse: { var pr = msg.GetPayload<PauseResponsePayload>(); if (pr != null) OnPauseResponse?.Invoke(pr); break; }
                case MessageType.ServerLeaderboard: { var lb = msg.GetPayload<LeaderboardPayload>(); if (lb != null) OnLeaderboard?.Invoke(lb); break; }
            }
        }

        // Fix 3: names a server may NOT write to a station through the file-transfer
        // feature. Each one becomes code or configuration that runs or is trusted
        // later (Startup folder, game launcher, run-bat, the station's own settings).
        private static readonly string[] BlockedTransferExtensions =
        {
            ".exe", ".dll", ".config", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".wsf",
            ".hta", ".lnk", ".url", ".msi", ".scr", ".com", ".cpl", ".reg", ".jar", ".pif"
        };

        private static readonly string[] ProtectedStationFiles =
        {
            "server_settings.txt", "server_pin.txt", "remote_cmd.enabled"
        };

        /// <summary>Fix 3: true when a server-sent file name must be refused.</summary>
        private static bool IsProtectedTransferName(string name)
        {
            if (string.IsNullOrEmpty(name)) return true;
            // Windows drops trailing dots and spaces ("x.exe." is "x.exe") and treats
            // "name:stream" as an alternate data stream, so normalise first and refuse
            // any colon.
            string n = name.TrimEnd(' ', '.');
            if (n.Length == 0 || n.IndexOf(':') >= 0) return true;
            foreach (string f in ProtectedStationFiles)
            {
                if (string.Equals(n, f, StringComparison.OrdinalIgnoreCase)) return true;
            }
            string ext = Path.GetExtension(n) ?? "";
            foreach (string e in BlockedTransferExtensions)
            {
                if (string.Equals(ext, e, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        /// <summary>
        /// Fix 3: server-sent command execution (run-cmd, run-powershell, run-bat)
        /// runs only when ConnectionSettings.RemoteCommandsEnabled is true. Otherwise
        /// the command is audited and dropped.
        /// </summary>
        private bool RemoteCommandsAllowed(string title)
        {
            if (ConnectionSettings.RemoteCommandsEnabled) return true;
            AuditLogSafe("BLOCKED server command '" + title + "': remote commands are disabled on this station.");
            return false;
        }

        /// <summary>Fix 3: true only for plain http:// or https:// addresses.</summary>
        private static bool IsWebUrl(string text)
        {
            Uri uri;
            return Uri.TryCreate(text.Trim(), UriKind.Absolute, out uri) &&
                   (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
        }

        /// <summary>
        /// FIX 8 / 10 / 11 — Dispatches machine-control ServerMessages to
        /// the right local executor. Returns true if the title was
        /// recognised (so the caller doesn't also forward it to the UI as
        /// a generic popup), false to fall through to OnServerMessage.
        ///
        /// Recognised titles:
        ///   - "app-list-request"            → enumerate running processes,
        ///                                       send back as a ServerMessage
        ///                                       with Title="app-list-reply"
        ///   - "installed-programs-request"  → scan HKLM Uninstall keys,
        ///                                       send back as "installed-programs-reply"
        ///   - "visited-websites-request"    → read Chrome history (best-
        ///                                       effort), send back as
        ///                                       "visited-websites-reply"
        ///   - "open-url"                    → Process.Start(body)
        ///   - "apply-restrictions"          → ApplyClientRestrictions(body)
        ///                                       (registry policies under
        ///                                       HKCU\Software\Microsoft\
        ///                                       Windows\CurrentVersion\
        ///                                       Policies)
        ///   - "run-cmd"                     → cmd /c body
        ///   - "run-powershell"              → powershell -Command body
        ///   - "run-bat"                     → write body to a temp .bat
        ///                                       file and execute it via cmd /c
        /// </summary>
        private bool HandleControlMessage(string title, string body)
        {
            try
            {
                if (title == "app-list-request")
                {
                    try
                    {
                        var sb = new System.Text.StringBuilder();
                        int n = 0;
                        foreach (var p in Process.GetProcesses())
                        {
                            try
                            {
                                sb.Append(p.ProcessName).Append(" (").Append(p.Id).Append("); ");
                                if (++n >= 60) break; // cap to keep payload reasonable
                            }
                            catch { }
                        }
                        SendSafe(new NetMessage(MessageType.ClientStatusUpdate,
                            new ClientStatusPayload
                            {
                                StationName = Environment.MachineName,
                                State = State,
                                CurrentGame = "",
                                CpuUsage = 0,
                                MemoryUsage = 0,
                                DiskFreeMb = 0,
                                IsOnline = true,
                                ActiveWindowTitle = "app-list-reply",
                                OsVersion = sb.ToString(),
                            }, _sessionId));
                        AuditLogSafe("App list request handled — sent " + n + " processes");
                    }
                    catch (Exception ex) { AuditLogSafe("App list error: " + ex.Message); }
                    return true;
                }

                if (title == "installed-programs-request")
                {
                    try
                    {
                        var sb = new System.Text.StringBuilder();
                        // Scan both 64-bit and 32-bit Uninstall keys.
                        string[] keys =
                        {
                            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
                        };
                        int n = 0;
                        foreach (var basePath in keys)
                        {
                            try
                            {
                                using (var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(basePath))
                                {
                                    if (key == null) continue;
                                    foreach (var sub in key.GetSubKeyNames())
                                    {
                                        try
                                        {
                                            using (var sk = key.OpenSubKey(sub))
                                            {
                                                if (sk == null) continue;
                                                var name = sk.GetValue("DisplayName") as string;
                                                if (!string.IsNullOrEmpty(name))
                                                {
                                                    sb.Append(name).Append(" | ");
                                                    if (++n >= 200) break;
                                                }
                                            }
                                        }
                                        catch { }
                                    }
                                }
                            }
                            catch { }
                            if (n >= 200) break;
                        }
                        SendSafe(new NetMessage(MessageType.ClientStatusUpdate,
                            new ClientStatusPayload
                            {
                                StationName = Environment.MachineName,
                                State = State,
                                CurrentGame = "",
                                CpuUsage = 0,
                                MemoryUsage = 0,
                                DiskFreeMb = 0,
                                IsOnline = true,
                                ActiveWindowTitle = "installed-programs-reply",
                                OsVersion = sb.ToString(),
                            }, _sessionId));
                        AuditLogSafe("Installed programs request handled — sent " + n + " entries");
                    }
                    catch (Exception ex) { AuditLogSafe("Installed programs error: " + ex.Message); }
                    return true;
                }

                if (title == "visited-websites-request")
                {
                    try
                    {
                        var sb = new System.Text.StringBuilder();
                        // Best-effort: read Chrome's History SQLite DB. If
                        // Chrome isn't installed or the file is locked, we
                        // send back a "not available" notice rather than
                        // crashing.
                        string chromeHistory = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            @"Google\Chrome\User Data\Default\History");
                        if (File.Exists(chromeHistory))
                        {
                            // Copy to temp so we don't fight Chrome's lock.
                            string tmp = Path.Combine(Path.GetTempPath(), "gamenet_chrome_history");
                            try { File.Copy(chromeHistory, tmp, true); }
                            catch { tmp = chromeHistory; }
                            try
                            {
                                // Read the SQLite file with a minimal parser:
                                // pull URLs out of the "urls" table by
                                // scanning for the 'http' prefix. This is a
                                // rough heuristic — a proper parser would
                                // need System.Data.SQLite, which we don't
                                // reference from the client. We surface up
                                // to 50 URLs.
                                byte[] raw = File.ReadAllBytes(tmp);
                                string text = Encoding.ASCII.GetString(raw);
                                int found = 0;
                                int idx = 0;
                                while (found < 50 && idx < text.Length)
                                {
                                    int http = text.IndexOf("http", idx, StringComparison.Ordinal);
                                    if (http < 0) break;
                                    // Read up to the next non-printable char.
                                    int end = http;
                                    while (end < text.Length && text[end] >= ' ' && text[end] < 127) end++;
                                    if (end - http > 4 && end - http < 300)
                                    {
                                        sb.Append(text.Substring(http, end - http)).Append(" | ");
                                        found++;
                                    }
                                    idx = end + 1;
                                }
                                File.Delete(tmp);
                            }
                            catch { }
                        }
                        if (sb.Length == 0) sb.Append("(تاریخچه مرورگر در دسترس نیست)");
                        SendSafe(new NetMessage(MessageType.ClientStatusUpdate,
                            new ClientStatusPayload
                            {
                                StationName = Environment.MachineName,
                                State = State,
                                CurrentGame = "",
                                CpuUsage = 0,
                                MemoryUsage = 0,
                                DiskFreeMb = 0,
                                IsOnline = true,
                                ActiveWindowTitle = "visited-websites-reply",
                                OsVersion = sb.ToString(),
                            }, _sessionId));
                        AuditLogSafe("Visited websites request handled");
                    }
                    catch (Exception ex) { AuditLogSafe("Visited websites error: " + ex.Message); }
                    return true;
                }

                if (title == "open-url")
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(body))
                        {
                            // Fix 3: without remote_cmd.enabled the server may open web
                            // addresses only. Shell-opening anything else (an .exe, a .bat,
                            // a .lnk) would be remote execution.
                            if (!ConnectionSettings.RemoteCommandsEnabled && !IsWebUrl(body))
                            {
                                AuditLogSafe("BLOCKED open-url (not an http/https address): " + (body.Length > 120 ? body.Substring(0, 120) : body));
                                return true;
                            }
                            // UseShellExecute=true so the OS picks the
                            // registered handler (browser, mail client, etc).
                            Process.Start(new ProcessStartInfo(body) { UseShellExecute = true });
                            AuditLogSafe("Opened URL: " + body);
                        }
                    }
                    catch (Exception ex) { AuditLogSafe("Open URL error: " + ex.Message); }
                    return true;
                }

                if (title == "apply-restrictions")
                {
                    try
                    {
                        ApplyClientRestrictions(body);
                        AuditLogSafe("Restrictions applied");
                    }
                    catch (Exception ex) { AuditLogSafe("Apply restrictions error: " + ex.Message); }
                    return true;
                }

                if (title == "run-cmd")
                {
                    // Fix 3: server-sent shell commands run only on a station where
                    // the technician enabled remote commands (remote_cmd.enabled).
                    if (!RemoteCommandsAllowed(title)) return true;
                    // FIX H5: SECURITY TRUST MODEL — the kiosk trusts commands
                    // arriving from the server operator UI. The operator is the
                    // cafe owner and is assumed to act in the cafe's interest.
                    // A compromised server operator UI can already end sessions
                    // and shut down kiosks, so allowing CMD execution is not a
                    // new attack surface; it just matches HandyCafe semantics.
                    // A future hardening pass could gate this on a per-station
                    // "remote shell enabled" flag (off by default).
                    try
                    {
                        Process.Start(new ProcessStartInfo("cmd", "/c " + body)
                        {
                            UseShellExecute = false,
                            CreateNoWindow = true
                        });
                        AuditLogSafe("Ran CMD: " + body);
                    }
                    catch (Exception ex) { AuditLogSafe("Run CMD error: " + ex.Message); }
                    return true;
                }

                if (title == "run-powershell")
                {
                    // Fix 3: same gate as run-cmd.
                    if (!RemoteCommandsAllowed(title)) return true;
                    // FIX H5: see run-cmd — same trust model applies.
                    try
                    {
                        Process.Start(new ProcessStartInfo("powershell", "-Command " + body)
                        {
                            UseShellExecute = false,
                            CreateNoWindow = true
                        });
                        AuditLogSafe("Ran PowerShell: " + body);
                    }
                    catch (Exception ex) { AuditLogSafe("Run PowerShell error: " + ex.Message); }
                    return true;
                }

                if (title == "run-bat")
                {
                    // Fix 3: same gate as run-cmd.
                    if (!RemoteCommandsAllowed(title)) return true;
                    // FIX H5: see run-cmd — same trust model applies.
                    try
                    {
                        // body can be either the BAT file content (sent
                        // inline from the server's Send BAT menu item) or
                        // a filename (legacy behaviour where the BAT was
                        // streamed via FileTransfer). Detect by checking
                        // whether body looks like a path that exists.
                        string tempBat = Path.Combine(Path.GetTempPath(), "gamenet_cmd.bat");
                        if (body.Length < 260 && File.Exists(body))
                        {
                            // It's a path to a file we already received.
                            tempBat = body;
                        }
                        else
                        {
                            File.WriteAllText(tempBat, body);
                        }
                        Process.Start(new ProcessStartInfo("cmd", "/c " + tempBat)
                        {
                            UseShellExecute = false,
                            CreateNoWindow = true
                        });
                        AuditLogSafe("Ran BAT: " + (body.Length > 80 ? body.Substring(0, 80) + "…" : body));
                    }
                    catch (Exception ex) { AuditLogSafe("Run BAT error: " + ex.Message); }
                    return true;
                }
            }
            catch (Exception ex) { AuditLogSafe("HandleControlMessage error: " + ex.Message); }
            return false;
        }

        /// <summary>
        /// FIX 10 — Applies the operator's restriction set to the local
        /// machine by flipping the most important HKCU policy registry
        /// keys. The body is a JSON-serialised RestrictionsData (same
        /// shape as what RestrictionsForm.Save() writes to
        /// restrictions.json on the server). We use Newtonsoft.Json's
        /// LINQ-to-JSON API so we don't need a shared type between the
        /// client and server for the full 100+ bool fields.
        ///
        /// Applied policies (the most common HandyCafe set):
        ///   - DisableTaskMgr
        ///   - DisableRegistryTools (via DisableRegistryTools)
        ///   - NoControlPanel
        ///   - NoRun
        ///   - NoDrives (bitmask built from the HideDrive list)
        ///
        /// FIX M8 (KNOWN LIMITATION): this method does NOT snapshot the
        /// pre-existing registry values before overwriting them. When the
        /// operator toggles a restriction off (the `else` branches below
        /// call DeleteValue), the value is removed entirely — which is the
        /// right thing to do IF the kiosk created it. But if the cafe's
        /// group policy or a previous HandyCafe install already set these
        /// values, we clobber them and there's no way to restore the
        /// original setting on toggle-off. A proper fix would snapshot
        /// the existing DWORDs to restrictions_backup.json on first apply
        /// and restore from there on toggle-off — out of scope for this
        /// pass because it requires a coordinated backup/restore UI and
        /// a migration path for cafes already running with the current
        /// behavior. For now, the kiosk trusts that the cafe started
        /// from a clean Windows install (the standard deployment).
        /// </summary>
        private void ApplyClientRestrictions(string json)
        {
            if (string.IsNullOrEmpty(json)) return;
            Newtonsoft.Json.Linq.JObject data;
            try { data = Newtonsoft.Json.Linq.JObject.Parse(json); }
            catch (Exception ex) { AuditLogSafe("ApplyClientRestrictions parse error: " + ex.Message); return; }

            try
            {
                // HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System
                //   - DisableTaskMgr = 1
                //   - DisableRegistryTools = 1
                using (var sys = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\System"))
                {
                    if (sys != null)
                    {
                        if (GetBool(data, "DisableTaskManager")) sys.SetValue("DisableTaskMgr", 1, Microsoft.Win32.RegistryValueKind.DWord);
                        else sys.DeleteValue("DisableTaskMgr", false);

                        if (GetBool(data, "DisableRegistryTools")) sys.SetValue("DisableRegistryTools", 1, Microsoft.Win32.RegistryValueKind.DWord);
                        else sys.DeleteValue("DisableRegistryTools", false);
                    }
                }

                // HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer
                //   - NoControlPanel = 1
                //   - NoRun = 1
                //   - NoDrives = bitmask (HideDrive list → drive-letter bitmask)
                using (var exp = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"))
                {
                    if (exp != null)
                    {
                        if (GetBool(data, "DisableControlPanel") || GetBool(data, "HideControlPanelPrinterNetwork"))
                            exp.SetValue("NoControlPanel", 1, Microsoft.Win32.RegistryValueKind.DWord);
                        else exp.DeleteValue("NoControlPanel", false);

                        if (GetBool(data, "HideRunCommand")) exp.SetValue("NoRun", 1, Microsoft.Win32.RegistryValueKind.DWord);
                        else exp.DeleteValue("NoRun", false);

                        // Build NoDrives bitmask from HideDrive list. Each
                        // drive letter maps to a bit (A=0x1, B=0x2, C=0x4, …).
                        var hideDrives = data["HideDrive"] as Newtonsoft.Json.Linq.JArray;
                        if (hideDrives != null && hideDrives.Count > 0)
                        {
                            int mask = 0;
                            foreach (var d in hideDrives)
                            {
                                string s = d.ToString();
                                if (!string.IsNullOrEmpty(s) && s.Length >= 1 && s[0] >= 'A' && s[0] <= 'Z')
                                    mask |= (1 << (s[0] - 'A'));
                            }
                            if (mask != 0)
                                exp.SetValue("NoDrives", mask, Microsoft.Win32.RegistryValueKind.DWord);
                            else
                                exp.DeleteValue("NoDrives", false);
                        }
                        else
                        {
                            exp.DeleteValue("NoDrives", false);
                        }
                    }
                }
            }
            catch (Exception ex) { AuditLogSafe("ApplyClientRestrictions registry error: " + ex.Message); }
        }

        /// <summary>Reads a bool field from a JSON object, defaulting to false.</summary>
        private static bool GetBool(Newtonsoft.Json.Linq.JObject data, string name)
        {
            try
            {
                var t = data[name];
                if (t == null) return false;
                return (bool)t;
            }
            catch { return false; }
        }

        /// <summary>
        /// Phase 10.1 — Handles an update offer from the server. Auto-accepts
        /// (the kiosk always updates when a newer version is offered). The
        /// server then streams FileChunkPayload messages.
        /// </summary>
        private void HandleUpdateOffer(NetMessage msg)
        {
            var offer = msg.GetPayload<UpdateOfferPayload>();
            if (offer == null) return;
            // FIX H5: use dedicated update-side state — never share with the
            // file-transfer handlers (interleaving corrupted the path/buffer).
            // FIX 16: reset all shared state at the start so interleaved offers
            // (a second offer arriving mid-download) don't corrupt the buffer.
            _updateBuffer.Clear();
            _updateReceivedSequences = 0;
            _updateTotalSequences = 0;
            // FIX L7: removed _updateFileName — it was set here but never
            // read. The self-update batch in HandleUpdateChunk hardcodes the
            // staged path as "GameNet.Client.exe.new" and never references
            // the offer's filename, so tracking it was dead state (and a
            // trap for future maintainers who'd assume it controlled the
            // staged filename).
            _updateSha256 = offer.Sha256;
            _updateSignature = offer.Signature;

            // Fix 2: refuse what this build cannot verify. Nothing is downloaded
            // or installed in either case.
            string refusal = null;
            if (!UpdateTrust.IsKeyConfigured) refusal = "this build has no update-signing public key";
            else if (string.IsNullOrEmpty(offer.Signature)) refusal = "the offer is not signed";
            if (refusal != null)
            {
                AuditLogSafe("Update v" + offer.Version + " REFUSED: " + refusal);
                SendSafe(new NetMessage(MessageType.ClientUpdateAccept,
                    new UpdateAcceptPayload { StationName = Environment.MachineName, Accept = false }));
                _updateSignature = null;
                return;
            }
            try
            {
                // Accept the update
                SendSafe(new NetMessage(MessageType.ClientUpdateAccept,
                    new UpdateAcceptPayload { StationName = Environment.MachineName, Accept = true }));
                AuditLogSafe("Update offered: v" + offer.Version + " (" + offer.FileSize + " bytes)");
            }
            catch (Exception ex) { AuditLogSafe("HandleUpdateOffer error: " + ex.Message); }
        }

        /// <summary>
        /// Phase 10.2 — Receives an update chunk, accumulates it, and writes
        /// the file when the last chunk arrives. Verifies SHA-256 (FIX H4)
        /// before staging for self-update.
        /// </summary>
        // FIX H5: Update-specific state — never shared with FileTransfer.
        private System.Collections.Generic.List<byte> _updateBuffer = new System.Collections.Generic.List<byte>();
        // FIX L7: _updateFileName field removed (dead state — see HandleUpdateOffer).
        private string _updateSha256;
        private string _updateSignature; // Fix 2: detached RSA signature of the offered update
        private int _updateTotalSequences;
        private int _updateReceivedSequences;

        // FIX H5: FileTransfer-specific state — never shared with Update.
        private System.Collections.Generic.List<byte> _transferBuffer = new System.Collections.Generic.List<byte>();
        private string _transferFileName;
        private string _transferSha256;
        private string _transferTargetPath;
        private int _transferTotalSequences;
        private int _transferReceivedSequences;

        private void HandleUpdateChunk(NetMessage msg)
        {
            var chunk = msg.GetPayload<FileChunkPayload>();
            if (chunk == null) return;
            try
            {
                byte[] data = Convert.FromBase64String(chunk.Base64Data);
                _updateBuffer.AddRange(data);
                _updateReceivedSequences++;
                _updateTotalSequences = chunk.TotalSequences;

                // Report progress
                int pct = (_updateTotalSequences > 0)
                    ? (int)(100.0 * _updateReceivedSequences / _updateTotalSequences)
                    : 0;
                SendSafe(new NetMessage(MessageType.ClientUpdateProgress,
                    new UpdateProgressPayload { StationName = Environment.MachineName, Percent = pct, Status = "downloading" }));

                if (chunk.IsLast)
                {
                    // Fix 2: the signature must verify before anything else. It
                    // covers the whole file, so a truncated or altered file fails too.
                    if (!UpdateTrust.Verify(_updateBuffer.ToArray(), _updateSignature))
                    {
                        AuditLogSafe("Update REJECTED - signature missing or invalid. Nothing was installed.");
                        SendSafe(new NetMessage(MessageType.ClientUpdateComplete,
                            new UpdateCompletePayload { StationName = Environment.MachineName, Success = false, Error = "signature invalid" }));
                        _updateBuffer.Clear();
                        _updateReceivedSequences = 0;
                        _updateSignature = null;
                        return;
                    }

                    // FIX H4: Verify SHA-256 if provided BEFORE writing the
                    // staged file or launching the self-update batch. A
                    // truncated/tampered update must never be installed.
                    if (!string.IsNullOrEmpty(_updateSha256))
                    {
                        using (var sha = System.Security.Cryptography.SHA256.Create())
                        {
                            var actualHash = BitConverter.ToString(sha.ComputeHash(_updateBuffer.ToArray())).Replace("-", "").ToLowerInvariant();
                            if (actualHash != _updateSha256.ToLowerInvariant())
                            {
                                AuditLogSafe("Update SHA-256 mismatch — aborting update (expected " + _updateSha256 + ", got " + actualHash + ")");
                                SendSafe(new NetMessage(MessageType.ClientUpdateComplete,
                                    new UpdateCompletePayload { StationName = Environment.MachineName, Success = false, Error = "SHA-256 mismatch" }));
                                _updateBuffer.Clear();
                                _updateReceivedSequences = 0;
                                return;
                            }
                        }
                    }

                    // FIX 21: removed the dead `tempPath` write — it was never
                    // read or cleaned up (disk leak). Only `stagedPath` below
                    // is needed for the self-update flow.

                    // Report complete
                    SendSafe(new NetMessage(MessageType.ClientUpdateComplete,
                        new UpdateCompletePayload { StationName = Environment.MachineName, Success = true, InstalledVersion = "pending-restart" }));

                    AuditLogSafe("Update downloaded (" + _updateBuffer.Count + " bytes) — staging for self-update");

                    // Replace the current exe with the new one and restart.
                    // We write a batch script that:
                    //   1. waits for the current process to exit (up to 10s)
                    //   2. copies the new exe over the old one
                    //   3. launches the new exe
                    //   4. deletes itself
                    // This is the standard Windows self-update pattern.
                    //
                    // FIX-MINOR-UPDATE IMPROVE C: the old batch sometimes
                    // failed on slow kiosks because the exe was still locked
                    // by the OS even after Process.Exit. The new batch:
                    //   - logs every step to %TEMP%\gamenet_update.log so
                    //     field issues are diagnosable without remote access
                    //   - caps the wait loop at 10 iterations (10 seconds)
                    //     so the batch can't hang forever if tasklist hangs
                    //   - if the copy fails (ERRORLEVEL 1), does NOT delete
                    //     the staged .new file — leaves it in place so the
                    //     next update attempt can retry, and falls back to
                    //     starting the OLD exe so the kiosk isn't bricked.
                    try
                    {
                        int pid = System.Diagnostics.Process.GetCurrentProcess().Id;
                        string currentExe = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                        string currentDir = System.IO.Path.GetDirectoryName(currentExe);
                        string backupPath = currentExe + ".old";
                        string batPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "gamenet_selfupdate.bat");

                        // Write the downloaded update to a temp file in the
                        // client's own directory (so the batch can copy it).
                        string stagedPath = System.IO.Path.Combine(currentDir, "GameNet.Client.exe.new");
                        System.IO.File.WriteAllBytes(stagedPath, _updateBuffer.ToArray());

                        // Write the self-update batch script. NOTE: all
                        // logging goes to %TEMP%\gamenet_update.log so the
                        // operator can ship it back to support.
                        string bat =
                            "@echo off\r\n" +
                            "setlocal\r\n" +
                            "set WAIT_COUNT=0\r\n" +
                            "echo [%date% %time%] Waiting for GameNet.Client (PID " + pid + ") to exit... >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            ":wait\r\n" +
                            "timeout /t 1 /nobreak >NUL\r\n" +
                            "set /a WAIT_COUNT+=1\r\n" +
                            "tasklist /FI \"PID eq " + pid + "\" 2>NUL | find \"" + pid + "\" >NUL\r\n" +
                            "if NOT ERRORLEVEL 1 (\r\n" +
                            "    if %WAIT_COUNT% LSS 10 goto wait\r\n" +
                            "    echo [%date% %time%] Process still alive after 10s - forcing replace >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            ")\r\n" +
                            "echo [%date% %time%] Process exited. Replacing executable... >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            "copy /Y \"" + currentExe + "\" \"" + backupPath + "\" >NUL 2>&1\r\n" +
                            "copy /Y \"" + stagedPath + "\" \"" + currentExe + "\" >NUL 2>&1\r\n" +
                            "if ERRORLEVEL 1 (\r\n" +
                            "    echo [%date% %time%] Copy failed - will retry on next boot (staged file preserved) >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            "    goto start_old\r\n" +
                            ")\r\n" +
                            "del \"" + stagedPath + "\" >NUL 2>&1\r\n" +
                            "echo [%date% %time%] Starting new version... >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            "start \"\" \"" + currentExe + "\"\r\n" +
                            "del \"" + backupPath + "\" >NUL 2>&1\r\n" +
                            "del \"%~f0\" >NUL 2>&1\r\n" +
                            "exit /b 0\r\n" +
                            ":start_old\r\n" +
                            "echo [%date% %time%] Starting old version (recovery) >> \"%TEMP%\\gamenet_update.log\"\r\n" +
                            "start \"\" \"" + currentExe + "\"\r\n" +
                            "del \"%~f0\" >NUL 2>&1\r\n" +
                            "exit /b 1\r\n";
                        System.IO.File.WriteAllText(batPath, bat);

                        AuditLogSafe("Update staged at: " + stagedPath + " — launching self-update batch and exiting.");

                        // Launch the batch (hidden) and exit the current process
                        // so the batch can replace the exe.
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = batPath,
                            WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden,
                            CreateNoWindow = true,
                            UseShellExecute = false
                        });

                        // Round 12: tell the guard this exit is on purpose, or it would start
                        // the old exe again while the batch replaces it.
                        try { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Client"); } catch { }
                        // Exit the current process so the batch can replace the file.
                        System.Threading.Tasks.Task.Delay(1000).ContinueWith(_ =>
                        {
                            try { System.Environment.Exit(0); } catch { }
                        });
                    }
                    catch (Exception ex) { AuditLogSafe("Self-update launch error: " + ex.Message); }

                    _updateBuffer.Clear();
                    _updateReceivedSequences = 0;
                }
            }
            catch (Exception ex) { AuditLogSafe("HandleUpdateChunk error: " + ex.Message); }
        }

        /// <summary>Phase 10.3 — Handles a file transfer offer. Auto-accepts (after validating filename AND target path).</summary>
        private void HandleFileTransferOffer(NetMessage msg)
        {
            var offer = msg.GetPayload<FileTransferOfferPayload>();
            if (offer == null) return;
            // FIX H5: use dedicated transfer-side state — never share with the
            // update handlers.
            _transferFileName = offer.Filename;
            _transferTargetPath = offer.TargetPath;
            _transferSha256 = offer.Sha256;
            _transferTotalSequences = 0;
            _transferReceivedSequences = 0;
            _transferBuffer.Clear();

            // Fix 3: refuse file names that could become code or station configuration
            // (see BlockedTransferExtensions and ProtectedStationFiles).
            if (IsProtectedTransferName(_transferFileName))
            {
                AuditLogSafe("File transfer rejected - file type or name not allowed on a station: " + (_transferFileName ?? "(null)"));
                SendSafe(new NetMessage(MessageType.ClientFileTransferAccept,
                    new FileTransferAcceptPayload { StationName = Environment.MachineName, Accept = false }));
                _transferFileName = null;
                _transferTargetPath = null;
                _transferSha256 = null;
                return;
            }

            // FIX 15: reject filenames containing path separators or traversal
            // sequences — protects against path-traversal / arbitrary file
            // write (RCE) attacks via a malicious server.
            if (string.IsNullOrEmpty(_transferFileName) ||
                _transferFileName.Contains("/") ||
                _transferFileName.Contains("\\") ||
                _transferFileName.Contains(".."))
            {
                AuditLogSafe("File transfer rejected — invalid filename: " + (_transferFileName ?? "(null)"));
                SendSafe(new NetMessage(MessageType.ClientFileTransferAccept,
                    new FileTransferAcceptPayload { StationName = Environment.MachineName, Accept = false }));
                _transferFileName = null;
                _transferTargetPath = null;
                _transferSha256 = null;
                return;
            }

            // FIX C3: validate target path against an allow-list — only allow
            // the game root and the app base dir. Without this, a malicious
            // server can write anywhere (e.g. the Windows Startup folder → RCE
            // on next login).
            var allowedRoots = new string[]
            {
                AppDomain.CurrentDomain.BaseDirectory,
                @"C:\Games",
                @"C:\GameNet",
                @"D:\Games",
                @"D:\GameNet",
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\GameNet",
            };
            string target = _transferTargetPath ?? "";
            bool allowed = false;
            foreach (var root in allowedRoots)
            {
                if (string.IsNullOrEmpty(root)) continue;
                // FIX-MINOR-UPDATE FIX 2: append a trailing separator to the
                // root before the StartsWith check. The previous `target.StartsWith(root)`
                // without a separator meant C:\GamesMalicious matched the
                // C:\Games allow-list entry (and C:\GameNetEvil matched
                // C:\GameNet). By comparing against "C:\Games\" we guarantee
                // the target is inside the root directory, not just a sibling
                // whose name happens to start with the same prefix.
                string rootWithSep = root.EndsWith(System.IO.Path.DirectorySeparatorChar.ToString())
                    ? root
                    : root + System.IO.Path.DirectorySeparatorChar;
                if (target.StartsWith(rootWithSep, StringComparison.OrdinalIgnoreCase) ||
                    target.Equals(root, StringComparison.OrdinalIgnoreCase))
                {
                    allowed = true;
                    break;
                }
            }
            // Empty target path is allowed — falls back to the app base dir
            // (see HandleFileTransferChunk).
            if (!allowed && !string.IsNullOrEmpty(target))
            {
                AuditLogSafe("File transfer rejected — target path not in allow-list: " + target);
                SendSafe(new NetMessage(MessageType.ClientFileTransferAccept,
                    new FileTransferAcceptPayload { StationName = Environment.MachineName, Accept = false }));
                _transferFileName = null;
                _transferTargetPath = null;
                _transferSha256 = null;
                return;
            }
            // FIX M9: reject executable-replacement files when the target is
            // the kiosk's own base directory. A malicious server could push
            // a "GameNet.Client.exe" / .dll / .bat / .ps1 into BaseDirectory
            // and the next kiosk restart would execute the attacker's payload
            // (or, for .bat/.ps1, the run-bat path would execute it inline).
            // Update-channel exe replacement must go through HandleUpdateChunk
            // which verifies the SHA-256 and uses the self-update batch —
            // never the generic FileTransfer path.
            if (string.IsNullOrEmpty(target) ||
                target.Equals(AppDomain.CurrentDomain.BaseDirectory, StringComparison.OrdinalIgnoreCase))
            {
                string ext = Path.GetExtension(_transferFileName ?? "").ToLowerInvariant();
                if (ext == ".exe" || ext == ".dll" || ext == ".bat" ||
                    ext == ".ps1" || ext == ".vbs" || ext == ".cmd")
                {
                    AuditLogSafe("File transfer rejected — executable extension into base dir: " + _transferFileName);
                    SendSafe(new NetMessage(MessageType.ClientFileTransferAccept,
                        new FileTransferAcceptPayload { StationName = Environment.MachineName, Accept = false }));
                    _transferFileName = null;
                    _transferTargetPath = null;
                    _transferSha256 = null;
                    return;
                }
            }
            try
            {
                SendSafe(new NetMessage(MessageType.ClientFileTransferAccept,
                    new FileTransferAcceptPayload { StationName = Environment.MachineName, Accept = true }));
                AuditLogSafe("File transfer accepted: " + offer.Filename + " → " + (offer.TargetPath ?? "<base>") + "");
            }
            catch (Exception ex) { AuditLogSafe("HandleFileTransferOffer error: " + ex.Message); }
        }

        /// <summary>Phase 10.4 — Receives a file transfer chunk, writes to target path.</summary>
        private void HandleFileTransferChunk(NetMessage msg)
        {
            var chunk = msg.GetPayload<FileChunkPayload>();
            if (chunk == null) return;
            try
            {
                byte[] data = Convert.FromBase64String(chunk.Base64Data);
                _transferBuffer.AddRange(data);
                _transferReceivedSequences++;
                _transferTotalSequences = chunk.TotalSequences;

                if (chunk.IsLast)
                {
                    // FIX 15: verify SHA-256 (if provided) before writing to disk —
                    // guards against truncated / tampered transfers.
                    if (!string.IsNullOrEmpty(_transferSha256))
                    {
                        using (var sha = System.Security.Cryptography.SHA256.Create())
                        {
                            var actualHash = BitConverter.ToString(sha.ComputeHash(_transferBuffer.ToArray())).Replace("-", "").ToLowerInvariant();
                            if (actualHash != _transferSha256.ToLowerInvariant())
                            {
                                AuditLogSafe("File transfer SHA-256 mismatch — discarding (expected " + _transferSha256 + ", got " + actualHash + ")");
                                _transferBuffer.Clear();
                                SendSafe(new NetMessage(MessageType.ClientFileTransferComplete,
                                    new FileTransferCompletePayload { StationName = Environment.MachineName, Success = false, Error = "SHA-256 mismatch" }));
                                return;
                            }
                        }
                    }

                    // Write to target path. FIX C3 already validated that
                    // _transferTargetPath (if non-empty) is in the allow-list.
                    string target = string.IsNullOrEmpty(_transferTargetPath)
                        ? System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _transferFileName ?? "received_file")
                        : System.IO.Path.Combine(_transferTargetPath, _transferFileName ?? "received_file");

                    try { System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target) ?? ""); } catch { }
                    System.IO.File.WriteAllBytes(target, _transferBuffer.ToArray());

                    SendSafe(new NetMessage(MessageType.ClientFileTransferComplete,
                        new FileTransferCompletePayload { StationName = Environment.MachineName, Success = true, Filename = _transferFileName ?? "" }));
                    AuditLogSafe("File received: " + target + " (" + _transferBuffer.Count + " bytes)");
                    _transferBuffer.Clear();
                }
            }
            catch (Exception ex)
            {
                SendSafe(new NetMessage(MessageType.ClientFileTransferComplete,
                    new FileTransferCompletePayload { StationName = Environment.MachineName, Success = false, Error = ex.Message }));
                AuditLogSafe("HandleFileTransferChunk error: " + ex.Message);
            }
        }

        /// <summary>
        /// Phase 10.5 — Captures a JPEG screenshot of the kiosk's primary screen and sends
        /// it back to the server. Quality is taken from the request payload
        /// (1-100, default 50). The image is base64-encoded so it fits in the
        /// existing JSON-over-length-prefixed framing without a separate
        /// binary channel.
        /// </summary>
        private void HandleScreenshotRequest(NetMessage msg)
        {
            var req = msg.GetPayload<ScreenshotRequestPayload>();
            int quality = (req != null && req.Quality > 0 && req.Quality <= 100) ? req.Quality : 50;
            string station = req?.StationName ?? Environment.MachineName;

            // FIX M7: track the bitmap so it is disposed even if the JPEG
            // encoder is missing (was leaked when GetJpegEncoder returned null
            // and bmp.Save threw NullReferenceException before bmp.Dispose()).
            System.Drawing.Bitmap bmp = null;
            try
            {
                // FIX 4: capture the screenshot on the read thread directly.
                // CopyFromScreen is thread-safe and the previous synchronous
                // openForm.Invoke(...) deadlocked when the UI thread was
                // blocked by a MessageBox. (BeginInvoke would avoid the
                // deadlock but add needless cross-thread marshalling — the
                // capture itself needs no UI-thread state.)
                Exception captureErr = null;
                try
                {
                    bmp = CaptureScreen(quality);
                }
                catch (Exception ex) { captureErr = ex; }

                if (bmp == null)
                {
                    SendSafe(new NetMessage(MessageType.ClientScreenshotResponse,
                        new ScreenshotResponsePayload { StationName = station, Success = false, Error = captureErr?.Message ?? "capture failed" }));
                    return;
                }

                // Encode JPEG to base64
                string base64;
                using (var ms = new System.IO.MemoryStream())
                {
                    // FIX H4: previously GetJpegEncoder ignored the quality
                    // parameter — every screenshot was saved at the codec's
                    // default (typically 75) regardless of what the operator
                    // requested. Now we return an EncoderParameters with the
                    // quality value and pass it to bmp.Save.
                    var (codec, eps) = GetJpegEncoder(quality);
                    if (codec != null)
                        bmp.Save(ms, codec, eps);
                    else
                        bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    base64 = Convert.ToBase64String(ms.ToArray());
                }

                SendSafe(new NetMessage(MessageType.ClientScreenshotResponse,
                    new ScreenshotResponsePayload
                    {
                        StationName = station,
                        Success = true,
                        ImageBase64 = base64,
                        // Round 11: the size of the picture actually sent (physical pixels);
                        // the viewer maps mouse positions with it.
                        Width = bmp.Width,
                        Height = bmp.Height,
                        CapturedAt = DateTime.UtcNow
                    }));
            }
            catch (Exception ex)
            {
                SendSafe(new NetMessage(MessageType.ClientScreenshotResponse,
                    new ScreenshotResponsePayload { StationName = station, Success = false, Error = ex.Message }));
            }
            finally
            {
                // FIX M7: dispose the bitmap deterministically — the previous
                // code only disposed it on the success path; the catch path
                // leaked one GDI Bitmap per failure.
                try { bmp?.Dispose(); } catch { }
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);
        private static readonly IntPtr DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = new IntPtr(-4);

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        private struct CURSORINFO { public int cbSize; public int flags; public IntPtr hCursor; public System.Drawing.Point ptScreenPos; }
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool GetCursorInfo(ref CURSORINFO pci);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr hIcon, int cx, int cy, int step, IntPtr brush, int flags);
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        private struct ICONINFO { public bool fIcon; public int xHotspot; public int yHotspot; public IntPtr hbmMask; public IntPtr hbmColor; }
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool GetIconInfo(IntPtr hIcon, out ICONINFO info);
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr h);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetSystemMetrics(int nIndex);

        private static System.Drawing.Bitmap CaptureScreen(int quality)
        {
            // Round 11: capture in physical pixels. The kiosk is not DPI-aware, so on a
            // PC with 125 % / 150 % scaling Screen.Bounds is the scaled-down size and
            // CopyFromScreen captured only the top-left part of the screen. The thread
            // switches to per-monitor DPI awareness for the capture (Windows 10 1607+;
            // on older Windows the call is missing and the old behaviour stays).
            IntPtr oldCtx = IntPtr.Zero;
            try { oldCtx = SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2); } catch { oldCtx = IntPtr.Zero; }
            try
            {
                // GetSystemMetrics follows the thread's DPI context; Screen.PrimaryScreen
                // does not (WinForms caches the screen list). The primary screen starts at 0,0.
                var bounds = System.Windows.Forms.Screen.PrimaryScreen.Bounds;
                int pw = GetSystemMetrics(0 /* SM_CXSCREEN */), ph = GetSystemMetrics(1 /* SM_CYSCREEN */);
                if (pw > 0 && ph > 0) bounds = new System.Drawing.Rectangle(0, 0, pw, ph);
                var bmp = new System.Drawing.Bitmap(bounds.Width, bounds.Height);
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                {
                    g.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bmp.Size);
                    // Round 11: draw the mouse pointer (CopyFromScreen leaves it out), so the
                    // operator sees where the customer's cursor is while controlling.
                    try
                    {
                        var ci = new CURSORINFO { cbSize = System.Runtime.InteropServices.Marshal.SizeOf(typeof(CURSORINFO)) };
                        if (GetCursorInfo(ref ci) && (ci.flags & 1) != 0 && ci.hCursor != IntPtr.Zero)
                        {
                            int hx = 0, hy = 0;
                            ICONINFO ii;
                            if (GetIconInfo(ci.hCursor, out ii))
                            {
                                hx = ii.xHotspot; hy = ii.yHotspot;
                                if (ii.hbmMask != IntPtr.Zero) DeleteObject(ii.hbmMask);
                                if (ii.hbmColor != IntPtr.Zero) DeleteObject(ii.hbmColor);
                            }
                            IntPtr hdc = g.GetHdc();
                            try { DrawIconEx(hdc, ci.ptScreenPos.X - bounds.X - hx, ci.ptScreenPos.Y - bounds.Y - hy, ci.hCursor, 0, 0, 0, IntPtr.Zero, 0x0003 /* DI_NORMAL */); }
                            finally { g.ReleaseHdc(hdc); }
                        }
                    }
                    catch { }
                }
                return bmp;
            }
            finally
            {
                if (oldCtx != IntPtr.Zero) { try { SetThreadDpiAwarenessContext(oldCtx); } catch { } }
            }
        }

        /// <summary>
        /// FIX H4 — Returns BOTH the JPEG codec AND the EncoderParameters
        /// configured for the requested quality (1-100). Callers MUST use both
        /// values: <c>bmp.Save(ms, codec, eps)</c>. Previously the quality
        /// parameter was ignored and every screenshot was encoded at the
        /// codec's default quality (typically 75).
        /// Returns (null, null) if no JPEG codec is available — callers fall
        /// back to <c>ImageFormat.Jpeg</c>.
        /// </summary>
        private static (System.Drawing.Imaging.ImageCodecInfo, System.Drawing.Imaging.EncoderParameters) GetJpegEncoder(int quality)
        {
            var encoders = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders();
            System.Drawing.Imaging.ImageCodecInfo jpegCodec = null;
            foreach (var e in encoders) if (e.FormatID == System.Drawing.Imaging.ImageFormat.Jpeg.Guid) { jpegCodec = e; break; }
            if (jpegCodec == null) return (null, null);

            // Clamp quality to the valid range [1, 100].
            if (quality < 1) quality = 1;
            if (quality > 100) quality = 100;
            var eps = new System.Drawing.Imaging.EncoderParameters(1);
            eps.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)quality);
            return (jpegCodec, eps);
        }
    }

    // Client-only payload DTOs (not part of the shared protocol contract; the
    // shared Protocol.cs defines the wire-level message types and the server-
    // produced payloads, but a couple of client-produced payloads are kept here
    // to avoid touching the Shared project, which is owned by another agent).
    public class ClientReconnectPayload
    {
        public string PreviousSessionId;
        public string MachineName;
        public string MacAddress;
        public string ClientVersion;
        public string StationName;
    }

    public class LanguageChangePayload
    {
        public string Language;
    }
}
