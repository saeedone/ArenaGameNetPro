using System;
using System.IO;

namespace GameNet.Client
{
    /// <summary>
    /// FIX FEATURE-2: client-side counterpart to the server's
    /// SettingsResetManager — "بازگرداندن به حالت اولیه" for the kiosk
    /// client. The client holds no financial/customer data itself (that
    /// all lives server-side), so this is much lower-risk than the server
    /// version: it just clears local config/cache files so the client
    /// starts completely fresh, as if freshly installed.
    ///
    /// Clears:
    ///  - server_settings.txt (both possible locations — exe dir and
    ///    %APPDATA%\GameNet) — ConnectionSettings falls back to its
    ///    compiled-in defaults (127.0.0.1:9090) when this file is missing.
    ///
    /// Deliberately does NOT touch client_log.txt / client_crash_log.txt /
    /// integrity_log.txt / startup_log.txt — those are diagnostic history
    /// that's actively useful for troubleshooting exactly the kind of
    /// problem that would lead someone to run a repair in the first place.
    /// </summary>
    public static class ClientRepair
    {
        public static void ResetToDefaults()
        {
            TryDelete(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server_settings.txt"));
            TryDelete(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "GameNet", "server_settings.txt"));

            try
            {
                File.AppendAllText(
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_log.txt"),
                    DateTime.Now.ToString("o") + " | REPAIR | Client settings reset to defaults via --repair" + Environment.NewLine);
            }
            catch { }
        }

        private static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
