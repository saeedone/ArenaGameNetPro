using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

namespace GameNet.Client
{
    public static class SecurityLock
    {
        [DllImport("user32.dll")] private static extern IntPtr SetWindowsHookEx(int id, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll")] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("kernel32.dll")] private static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int vKey);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr FindWindow(string cls, string text);
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hwnd, int cmd);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        private static readonly object _hookLock = new object();
        private static IntPtr _hookId;
        private static LowLevelKeyboardProc _hookProc; // kept alive to prevent GC of the callback
        // FIX H3: track whether the hook callback has actually fired recently.
        // Windows can silently unhook a WH_KEYBOARD_LL hook after
        // LowLevelHooksTimeout (300ms default) if the installing thread
        // doesn't pump messages fast enough. When this happens, _hookId
        // is still non-zero (the variable is never cleared by Windows),
        // so the old EnsureHookInstalled `if (_hookId != IntPtr.Zero) return`
        // guard would skip re-installation — leaving the hook dead forever.
        // _hookAlive is set to true in HookCallback (every keystroke) and
        // periodically reset to false by a watchdog tick. If the watchdog
        // sees _hookAlive still false after a grace period, it forces a
        // full re-install (unhook + reinstall).
        private static volatile bool _hookAlive;
        private static DateTime _lastHookCheck = DateTime.UtcNow;

        private const int WH_KEYBOARD_LL = 13, WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104;
        private const int VK_LWIN = 0x5B, VK_RWIN = 0x5C, VK_TAB = 0x09, VK_F4 = 0x73, VK_ESCAPE = 0x1B;
        // ADD-CLIENT-25 — Task 11: extra keys to block in combos.
        private const int VK_SHIFT = 0x10, VK_CONTROL = 0x11, VK_MENU = 0x12; // Alt
        private const int VK_R = 0x52, VK_E = 0x45, VK_L = 0x4C;
        private const int VK_RETURN = 0x0D; // round 10: Alt+Enter

        // ADD-CLIENT-25 — Task 13: desktop hide/refresh constants.
        private const int SW_HIDE = 0, SW_SHOW = 5;
        private const uint WM_COMMAND = 0x0111;
        // ToggleDesktopIcons command id sent to the Progman shell window.
        private const uint TOGGLE_DESKTOP_ICONS = 0x7402;
        private const uint SMTO_NORMAL = 0x0000;

        /// <summary>
        /// Installs the low-level keyboard hook. Idempotent — calling it again
        /// unhooks the previous hook first (was a leak, LOW #34). Safe to call
        /// from the Watchdog to re-arm the hook if Windows silently unhooks it.
        /// FIX H3: also checks _hookAlive — if the hook callback hasn't fired
        /// in a while (meaning Windows silently dropped the hook), forces a
        /// full re-install instead of returning early.
        /// </summary>
        public static void BlockSpecialKeys()
        {
            EnsureHookInstalled();
        }

        /// <summary>
        /// Re-installs the hook if it has been removed (Windows can silently
        /// unhook a low-level hook after a timeout or via a foreground timeout).
        /// Called by the Watchdog on its monitor tick.
        /// FIX H3: previously this method checked `if (_hookId != IntPtr.Zero)
        /// return;` — but Windows never clears _hookId when it silently unhooks
        /// the hook, so the guard always returned early and a dead hook stayed
        /// dead. Now we also check _hookAlive: if the callback hasn't fired in
        /// the last 60 seconds (a generous grace period — the kiosk always has
        /// some keyboard activity from the customer), we assume the hook is
        /// dead and force a full UnhookWindowsHookEx + re-install.
        /// </summary>
        public static void EnsureHookInstalled()
        {
            lock (_hookLock)
            {
                // If the hook is installed AND we've seen recent callback
                // activity, it's alive — nothing to do.
                if (_hookId != IntPtr.Zero && _hookAlive) return;

                // If the hook handle is non-zero but we haven't seen activity,
                // Windows may have silently unhooked it. Force-unhook the stale
                // handle before re-installing so we don't leak the old hook.
                if (_hookId != IntPtr.Zero && !_hookAlive)
                {
                    try { UnhookWindowsHookEx(_hookId); } catch { }
                    _hookId = IntPtr.Zero;
                }

                if (_hookProc == null) _hookProc = HookCallback;
                try
                {
                    using (var p = Process.GetCurrentProcess())
                    using (var m = p.MainModule)
                        _hookId = SetWindowsHookEx(WH_KEYBOARD_LL, _hookProc, GetModuleHandle(m.ModuleName), 0);
                    _hookAlive = false; // reset; will be set true on first callback
                    _lastHookCheck = DateTime.UtcNow;
                }
                catch { /* fall through; Watchdog will retry on next tick */ }
            }
        }

        /// <summary>
        /// FIX H3: called by the Watchdog periodically to check hook health.
        /// Sets a flag if the hook appears dead (no callback in the interval).
        /// The UI thread must call EnsureHookInstalledIfStale() (e.g. from
        /// Application.Idle or a UI timer) to actually re-install the hook,
        /// because SetWindowsHookEx for WH_KEYBOARD_LL installs the hook on
        /// the calling thread and the callback is dispatched through that
        /// thread's message pump — a threadpool thread has no message pump,
        /// so installing from there would create a dead hook.
        /// </summary>
        public static void CheckHookHealth()
        {
            lock (_hookLock)
            {
                if (_hookId == IntPtr.Zero) { _hookStale = true; return; }
                // If the hook is alive (recent callback), just reset the flag
                // for the next interval and return.
                if (_hookAlive)
                {
                    _hookAlive = false;
                    _lastHookCheck = DateTime.UtcNow;
                    _hookStale = false;
                    return;
                }
                // Hook handle is non-zero but no callback in the interval —
                // the hook is probably dead. Flag for UI-thread re-install.
                _hookStale = true;
            }
        }

        /// <summary>
        /// FIX H3: called from the UI thread (KioskForm timer) to re-install
        /// the hook if CheckHookHealth flagged it as stale. Safe to call
        /// frequently — does nothing if the hook is healthy.
        /// </summary>
        public static void EnsureHookInstalledIfStale()
        {
            if (!_hookStale) return;
            EnsureHookInstalled();
            _hookStale = false;
        }

        private static volatile bool _hookStale;

        /// <summary>
        /// Re-installs the hook unconditionally, replacing any existing hook.
        /// </summary>
        public static void ReinstallHook()
        {
            lock (_hookLock)
            {
                if (_hookId != IntPtr.Zero)
                {
                    try { UnhookWindowsHookEx(_hookId); } catch { }
                    _hookId = IntPtr.Zero;
                }
            }
            EnsureHookInstalled();
        }

        private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            // FIX H3: mark the hook as alive so CheckHookHealth knows it's
            // still receiving callbacks (Windows can silently unhook a LL
            // hook after a message-pump stall, leaving _hookId non-zero but
            // the hook dead).
            _hookAlive = true;
            if (nCode >= 0 && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN))
            {
                int vk = Marshal.ReadInt32(lParam);
                bool alt = (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
                bool ctrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
                bool shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
                bool win = (GetAsyncKeyState(VK_LWIN) & 0x8000) != 0 ||
                           (GetAsyncKeyState((int)VK_RWIN) & 0x8000) != 0;

                // Block left/right Win key.
                if (vk == VK_LWIN || vk == VK_RWIN) return (IntPtr)1;
                // Block Alt+Tab.
                if (vk == VK_TAB && alt) return (IntPtr)1;
                // Block Alt+F4.
                if (vk == VK_F4 && alt) return (IntPtr)1;
                // Block Ctrl+Esc (Start menu).
                if (vk == VK_ESCAPE && ctrl && !shift) return (IntPtr)1;
                // C4: block Ctrl+Shift+Esc (Task Manager direct shortcut).
                if (vk == VK_ESCAPE && ctrl && shift) return (IntPtr)1;

                // ADD-CLIENT-25 — Task 11: block Win+R (Run), Win+E (Explorer),
                // Win+L (Lock). The Win key itself is already blocked above (so
                // the combo can never actually be sent by the keyboard), but we
                // also block the letter part when Win is held down — defense in
                // depth in case a future Windows update changes the way the OS
                // routes Win+key combos, or if a 3rd-party tool injects them.
                if (win)
                {
                    if (vk == VK_R || vk == VK_E || vk == VK_L) return (IntPtr)1;
                }

                // Round 10: the Options dialog's "Disable Alt+Enter". The kiosk window's own
                // KeyDown handler never saw keys typed in a game; this system-wide hook does.
                if (vk == VK_RETURN && alt && ClientOptions.DisableAltEnter) return (IntPtr)1;
            }
            return CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        public static void DisableTaskManager()
        {
            try { var k = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System"); k?.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord); k?.Close(); } catch { }
            // ADD-CLIENT-25 — Task 11: also try HKLM (all users). Requires
            // admin rights — wrap in try/catch. Best-effort: if it fails
            // (non-admin kiosk user), the HKCU block above still applies for
            // the current user.
            try
            {
                using (var k = Registry.LocalMachine.CreateSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\System"))
                {
                    k?.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                }
            }
            catch { /* non-admin or group-policy-locked — fall back to HKCU only */ }
        }
        public static void EnableTaskManager()
        {
            // DELETE the registry values (not set to 0) so Windows returns
            // to its default state. Setting to 0 can interfere with GPO.
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System", true))
                {
                    if (k != null) { k.DeleteValue("DisableTaskMgr", false); k.Close(); }
                }
            }
            catch { }
            try
            {
                using (var k = Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System", true))
                {
                    if (k != null) { k.DeleteValue("DisableTaskMgr", false); }
                }
            }
            catch { }
        }
        public static void BlockCtrlAltDel()
        {
            try
            {
                var k = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
                if (k != null)
                {
                    k.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                    k.SetValue("DisableChangePassword", 1, RegistryValueKind.DWord);
                    k.SetValue("DisableLockWorkstation", 1, RegistryValueKind.DWord);
                    k.SetValue("DisableRegistryTools", 1, RegistryValueKind.DWord);
                    k.Close();
                }
            }
            catch { }
        }

        public static void KillTaskManager()
        {
            foreach (var p in Process.GetProcessesByName("Taskmgr"))
            { try { p.Kill(); } catch { } finally { try { p.Dispose(); } catch { } } }
        }

        /// <summary>
        /// ADD-CLIENT-25 — Task 12: kills known bypass tools. Expanded with
        /// the Sysinternals suite + popular process-killer tools that
        /// customers can use to bypass the kiosk:
        ///   - ProcessHacker / procexp / procexp64 (Process Explorer)
        ///   - Unlocker / UnlockerAssistant
        ///   - ProcessExplorer
        ///   - handle / handle64 (Sysinternals handle.exe)
        ///   - autoruns / autoruns64 (Sysinternals Autoruns)
        ///   - procmon / procmon64 (Sysinternals Process Monitor)
        /// explorer was REMOVED from this list — killing the Windows shell
        /// restarts the taskbar/tray, disrupts file dialogs, and destabilizes
        /// the session. Task Manager is killed here, and the keyboard hook +
        /// registry block provide additional coverage.
        /// </summary>
        public static void KillBypassTools()
        {
            var names = new[]
            {
                "Taskmgr", "cmd", "powershell", "regedit",
                // ADD-CLIENT-25 — Task 12: process killer / Sysinternals suite.
                "ProcessHacker", "procexp", "procexp64",
                "Unlocker", "UnlockerAssistant", "ProcessExplorer",
                "handle", "handle64", "autoruns", "autoruns64",
                "procmon", "procmon64"
            };
            foreach (var n in names)
                foreach (var p in Process.GetProcessesByName(n))
                { try { p.Kill(); } catch { } finally { try { p.Dispose(); } catch { } } }
        }

        public static void HideTaskbar()
        {
            IntPtr hwnd = FindWindow("Shell_TrayWnd", null);
            if (hwnd != IntPtr.Zero) ShowWindow(hwnd, SW_HIDE);
        }
        public static void ShowTaskbar()
        {
            IntPtr hwnd = FindWindow("Shell_TrayWnd", null);
            if (hwnd != IntPtr.Zero) ShowWindow(hwnd, SW_SHOW);
        }

        /// <summary>
        /// ADD-CLIENT-25 — Task 13: hides desktop icons by setting the
        /// HideIcons registry value to 1, then sending a toggle command to
        /// the Progman shell window so the change takes effect immediately
        /// (without this the user would have to press F5 manually).
        ///
        /// Restore on exit via RestoreDesktopIcons().
        /// </summary>
        public static void HideDesktopIcons()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",
                    "HideIcons", 1, RegistryValueKind.DWord);
                RefreshDesktop();
            }
            catch { /* best-effort — non-admin can still set HKCU */ }
        }

        /// <summary>ADD-CLIENT-25 — Task 13: restores desktop icons on exit.</summary>
        public static void RestoreDesktopIcons()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",
                    "HideIcons", 0, RegistryValueKind.DWord);
                RefreshDesktop();
            }
            catch { }
        }

        /// <summary>
        /// ADD-CLIENT-25 — Task 13: refreshes the desktop so HideIcons takes
        /// effect immediately. Sends the toggle-desktop-icons command to the
        /// Progman shell window (the same command Windows sends when the user
        /// right-clicks the desktop → View → Show desktop icons).
        /// </summary>
        private static void RefreshDesktop()
        {
            try
            {
                IntPtr progman = FindWindow("Progman", null);
                if (progman == IntPtr.Zero) return;
                IntPtr defView = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", null);
                if (defView == IntPtr.Zero)
                {
                    // Try WorkerW (when wallpaper engine / slideshow is active
                    // the DefView is reparented to a WorkerW).
                    IntPtr workerW = IntPtr.Zero;
                    do
                    {
                        workerW = FindWindowEx(progman, workerW, "WorkerW", null);
                        if (workerW != IntPtr.Zero)
                        {
                            defView = FindWindowEx(workerW, IntPtr.Zero, "SHELLDLL_DefView", null);
                            if (defView != IntPtr.Zero) break;
                        }
                    } while (workerW != IntPtr.Zero);
                }
                if (defView != IntPtr.Zero)
                {
                    IntPtr result;
                    SendMessageTimeout(defView, WM_COMMAND, (IntPtr)TOGGLE_DESKTOP_ICONS,
                        IntPtr.Zero, SMTO_NORMAL, 1000, out result);
                }
            }
            catch { /* best-effort */ }
        }

        public static void RestoreAll()
        {
            lock (_hookLock)
            {
                if (_hookId != IntPtr.Zero)
                { try { UnhookWindowsHookEx(_hookId); } catch { } _hookId = IntPtr.Zero; }
            }
            EnableTaskManager();
            ShowTaskbar();
            // ADD-CLIENT-25 — Task 13: restore desktop icons on exit.
            try { RestoreDesktopIcons(); } catch { }
            try
            {
                var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System", true);
                if (k != null)
                {
                    k.DeleteValue("DisableChangePassword", false);
                    k.DeleteValue("DisableLockWorkstation", false);
                    k.DeleteValue("DisableRegistryTools", false);
                    k.Close();
                }
            }
            catch { }
            // FIX M9: also delete the HKCU\...\Run\GameNetClient entry that
            // Watchdog.Start writes. On a NORMAL shutdown, Watchdog.Stop
            // deletes this key — but RestoreAll is the crash-recovery path
            // (called from Program.RestoreSystemOnce via the global exception
            // handlers and the anti-debug LogAndExit). On an ABNORMAL exit
            // (Environment.Exit, Process.Kill, unhandled threadpool exception
            // that bypasses the AppDomain handler), Watchdog.Stop is never
            // called and the Run key survives — pointing at the (potentially
            // uninstalled) kiosk exe. On next login Windows tries to launch
            // the missing exe, generating errors. Deleting it here ensures
            // the Run key is cleaned on EVERY exit path.
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    k?.DeleteValue("GameNetClient", false);
                }
            }
            catch { }
        }
    }
}
