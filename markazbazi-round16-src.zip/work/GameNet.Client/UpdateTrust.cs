using System;
using System.Security.Cryptography;

namespace GameNet.Client
{
    /// <summary>
    /// Fix 2 - trust anchor for self-updates.
    ///
    /// A kiosk installs an update only when the detached signature sent with
    /// the offer verifies against <see cref="PublicKeyXml"/>, the public key
    /// compiled into this build. The matching PRIVATE key stays on the
    /// developer's machine: tools\New-UpdateKey.ps1 creates it and
    /// tools\Sign-Update.ps1 uses it. A compromised or impersonated server
    /// cannot produce a valid signature, so it cannot push code to the kiosks.
    ///
    /// Until the placeholder below is replaced with a real key, this build
    /// refuses every update (fail closed).
    /// </summary>
    internal static class UpdateTrust
    {
        // REPLACE the whole PublicKeyXml line below with the line printed by
        // tools\New-UpdateKey.ps1 (a complete `private const string PublicKeyXml = ...` line), then rebuild.
        private const string PublicKeyXml = @"PLACEHOLDER-RUN-tools-New-UpdateKey.ps1";

        /// <summary>True when a real RSA public key has been compiled in.</summary>
        public static bool IsKeyConfigured
        {
            get { return PublicKeyXml.StartsWith("<RSAKeyValue>", StringComparison.Ordinal); }
        }

        /// <summary>
        /// Verifies a base64 RSA-SHA256 (PKCS#1 v1.5) signature over the whole
        /// file. Returns false for every problem, including a missing key.
        /// </summary>
        public static bool Verify(byte[] file, string signatureBase64)
        {
            if (!IsKeyConfigured || file == null || string.IsNullOrEmpty(signatureBase64)) return false;
            try
            {
                byte[] signature = Convert.FromBase64String(signatureBase64);
                using (var rsa = new RSACryptoServiceProvider())
                {
                    rsa.FromXmlString(PublicKeyXml);
                    return rsa.VerifyData(file, "SHA256", signature);
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
