using System;
using System.Security.Cryptography;
using System.Text;

namespace GameNet.Client
{
    /// <summary>
    /// Client-side mirror of GameNet.Server.Core.MessageSecurity.
    ///
    /// *** NOT YET ACTIVE — DEAD CODE ***
    /// This class is NOT called from NetworkClient.SendMessage or anywhere
    /// in the message send/receive path. It was intended as a defense-in-
    /// depth HMAC layer on top of TLS, but was never wired in because the
    /// master-secret derivation (SHA256 of MachineName + "GameNet")) differs
    /// between server and client (different machine names) — so even if
    /// wired in, HMACs would NEVER verify. TLS (when UseTls=true) already
    /// provides message integrity + authentication. This class is retained
    /// as a placeholder for a future proper implementation that uses a
    /// server-generated shared secret exchanged during the handshake.
    ///
    /// NOTE: This is a simplified copy because the Client project does not
    /// reference the Server project. The algorithm MUST stay identical.
    /// </summary>
    public static class ClientMessageSecurity
    {
        private static byte[] _masterSecret;
        private static readonly object _initLock = new object();

        private static void EnsureMaster()
        {
            if (_masterSecret != null) return;
            lock (_initLock)
            {
                if (_masterSecret != null) return;
                _masterSecret = new byte[32];
                using (var sha = SHA256.Create())
                {
                    byte[] label = Encoding.UTF8.GetBytes("GameNet-MessageSecurity-v1");
                    byte[] seed = new byte[label.Length + 16];
                    Buffer.BlockCopy(label, 0, seed, 0, label.Length);
                    byte[] mid = sha.ComputeHash(Encoding.UTF8.GetBytes(Environment.MachineName + "GameNet"));
                    Buffer.BlockCopy(mid, 0, seed, label.Length, 16);
                    byte[] full = sha.ComputeHash(seed);
                    Buffer.BlockCopy(full, 0, _masterSecret, 0, 32);
                }
            }
        }

        public static byte[] DeriveSessionKey(string sessionId)
        {
            EnsureMaster();
            using (var sha = SHA256.Create())
            {
                byte[] sid = Encoding.UTF8.GetBytes(sessionId ?? "");
                byte[] buf = new byte[_masterSecret.Length + sid.Length];
                Buffer.BlockCopy(_masterSecret, 0, buf, 0, _masterSecret.Length);
                Buffer.BlockCopy(sid, 0, buf, _masterSecret.Length, sid.Length);
                return sha.ComputeHash(buf);
            }
        }

        public static string Sign(string json, byte[] sessionKey)
        {
            if (string.IsNullOrEmpty(json)) json = "";
            if (sessionKey == null || sessionKey.Length == 0) return json;

            byte[] nonceBytes = new byte[8];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(nonceBytes);
            string nonceHex = BitConverter.ToString(nonceBytes).Replace("-", "").ToLowerInvariant();
            long timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            string payload = nonceHex + "|" + timestamp + "|" + json;
            byte[] mac;
            using (var hmac = new HMACSHA256(sessionKey))
                mac = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            string macHex = BitConverter.ToString(mac).Replace("-", "").ToLowerInvariant();

            return nonceHex + "|" + timestamp + "|" + macHex + "|" + json;
        }

        /// <summary>
        /// Verifies a signed wire-format string. Returns the original JSON
        /// if the signature is valid and the message is fresh. Returns NULL
        /// (not the raw wire string) on any tamper / stale / replay / bad-
        /// signature condition, so the caller can detect the failure and
        /// skip the message instead of silently processing tampered data.
        ///
        /// FIX M2: previously this method returned `wire` (the raw signed
        /// string) on every failure path — which meant a tampered message
        /// was passed through to the caller as-is, and the caller would
        /// try to JSON-parse the signed wire format (nonce|ts|sig|json)
        /// and fail, falling to a catch-all with no alert. Now it returns
        /// null so the caller can explicitly check and skip.
        /// </summary>
        public static string Verify(string wire, byte[] sessionKey, ClientNonceReplayCache replayCache)
        {
            if (string.IsNullOrEmpty(wire)) return null;
            if (sessionKey == null || sessionKey.Length == 0) return null;

            int p1 = wire.IndexOf('|');
            if (p1 <= 0) return null; // unsigned — reject
            int p2 = wire.IndexOf('|', p1 + 1);
            if (p2 <= 0) return null;
            int p3 = wire.IndexOf('|', p2 + 1);
            if (p3 <= 0) return null;

            string nonceHex = wire.Substring(0, p1);
            string tsStr = wire.Substring(p1 + 1, p2 - p1 - 1);
            string macHex = wire.Substring(p2 + 1, p3 - p2 - 1);
            string json = wire.Substring(p3 + 1);

            if (nonceHex.Length != 16) return null; // bad nonce format
            if (!long.TryParse(tsStr, out long timestamp)) return null; // bad timestamp

            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            if (timestamp < now - 60000) return null; // stale — possible replay
            if (timestamp > now + 5000) return null; // future-dated — clock skew or attack

            if (replayCache != null && !replayCache.TryAdd(nonceHex, timestamp))
                return null; // duplicate nonce — replay attack

            string payload = nonceHex + "|" + timestamp + "|" + json;
            byte[] expectedMac;
            using (var hmac = new HMACSHA256(sessionKey))
                expectedMac = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            string expectedHex = BitConverter.ToString(expectedMac).Replace("-", "").ToLowerInvariant();

            if (!ConstantTimeEquals(macHex, expectedHex)) return null; // HMAC mismatch — tampered
            return json; // valid — return the original JSON payload
        }

        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= (int)a[i] ^ (int)b[i];
            return diff == 0;
        }
    }

    public class ClientNonceReplayCache
    {
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, long> _seen
            = new System.Collections.Concurrent.ConcurrentDictionary<string, long>();
        private DateTime _lastCleanup = DateTime.UtcNow;
        private const long WindowMs = 120000;

        public bool TryAdd(string nonce, long timestamp)
        {
            if ((DateTime.UtcNow - _lastCleanup).TotalSeconds > 30)
            {
                _lastCleanup = DateTime.UtcNow;
                long cutoff = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - WindowMs;
                foreach (var kvp in _seen)
                    if (kvp.Value < cutoff) _seen.TryRemove(kvp.Key, out _);
            }
            return _seen.TryAdd(nonce, timestamp);
        }

        public void Clear() => _seen.Clear();
    }
}
