using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace GameNet.Client
{
    /// <summary>
    /// Collects live system metrics (CPU usage, memory usage, disk free)
    /// for reporting to the server in heartbeats. Uses PerformanceCounter
    /// on Windows for CPU (with a fallback to a simple sampling method),
    /// and Process/DriveInfo for memory and disk.
    /// </summary>
    public static class SystemMonitor
    {
        private static PerformanceCounter _cpuCounter;
        private static DateTime _lastCpuSample;
        private static TimeSpan _lastCpuTime;
        private static double _fallbackCpu;

        /// <summary>
        /// Returns the current CPU usage (0-100). Uses PerformanceCounter
        /// if available; falls back to a Process.TotalProcessorTime sampling
        /// method that approximates CPU load over the last interval.
        /// </summary>
        public static double GetCpuUsage()
        {
            try
            {
                if (_cpuCounter == null)
                {
                    try
                    {
                        _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total", true);
                        _cpuCounter.NextValue(); // first call always returns 0; prime it
                        System.Threading.Thread.Sleep(100);
                    }
                    catch
                    {
                        _cpuCounter = null; // fall back to sampling
                    }
                }

                if (_cpuCounter != null)
                {
                    double v = _cpuCounter.NextValue();
                    if (v < 0) v = 0; if (v > 100) v = 100;
                    return Math.Round(v, 1);
                }

                // Fallback: sample process CPU time over a short interval.
                var proc = Process.GetCurrentProcess();
                var now = DateTime.UtcNow;
                var cpuTime = proc.TotalProcessorTime;
                if (_lastCpuSample != default)
                {
                    double elapsed = (now - _lastCpuSample).TotalSeconds;
                    double cpuUsed = (cpuTime - _lastCpuTime).TotalSeconds;
                    if (elapsed > 0)
                    {
                        int cores = Math.Max(1, Environment.ProcessorCount);
                        _fallbackCpu = Math.Min(100, (cpuUsed / elapsed / cores) * 100);
                    }
                }
                _lastCpuSample = now;
                _lastCpuTime = cpuTime;
                return Math.Round(_fallbackCpu, 1);
            }
            catch { return 0; }
        }

        /// <summary>
        /// Returns the system memory usage percentage (0-100) — how much
        /// of the total physical RAM is in use.
        /// </summary>
        public static double GetMemoryUsage()
        {
            try
            {
                var memStatus = new MEMORYSTATUSEX();
                memStatus.dwLength = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(MEMORYSTATUSEX));
                if (GlobalMemoryStatusEx(ref memStatus))
                {
                    // dwMemoryLoad is the approximate percentage of physical
                    // memory in use (0-100).
                    return memStatus.dwMemoryLoad;
                }
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// Returns the free disk space (MB) on the drive containing the
        /// client executable.
        /// </summary>
        public static long GetDiskFreeMb()
        {
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory;
                var drive = new System.IO.DriveInfo(System.IO.Path.GetPathRoot(path) ?? "C:\\");
                if (drive.IsReady)
                    return drive.AvailableFreeSpace / (1024 * 1024);
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// FIX DEAD-CONFIG-2: seconds since the last keyboard/mouse input
        /// system-wide (not just in this process), via GetLastInputInfo.
        /// Reported in every heartbeat so the server can enforce
        /// OptionsForm's idle-shutdown setting. Returns 0 on any failure
        /// (fail-open: never idle) so a P/Invoke problem can't accidentally
        /// shut down an active kiosk.
        /// </summary>
        public static int GetIdleSeconds()
        {
            try
            {
                var info = new LASTINPUTINFO();
                info.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
                if (!GetLastInputInfo(ref info)) return 0;
                uint idleTicks = unchecked((uint)Environment.TickCount - info.dwTime);
                return (int)(idleTicks / 1000);
            }
            catch { return 0; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);
    }
}
