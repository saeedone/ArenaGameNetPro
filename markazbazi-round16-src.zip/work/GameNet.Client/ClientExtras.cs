using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using GameNet.Shared;

namespace GameNet.Client
{
    // === 1. UPS / Power Monitor ===
    public static class UpsMonitor
    {
        private static System.Threading.Timer _timer;
        private static bool _onBattery;

        public static event Action OnPowerLost;
        public static event Action OnPowerRestored;

        public static void Start()
        {
            _timer = new System.Threading.Timer(_ =>
            {
                try
                {
                    bool battery = IsOnBattery();
                    if (battery && !_onBattery) { _onBattery = true; OnPowerLost?.Invoke(); }
                    else if (!battery && _onBattery) { _onBattery = false; OnPowerRestored?.Invoke(); }
                }
                catch { }
            }, null, 5000, 5000);
        }

        public static void Stop() { _timer?.Dispose(); }

        private static bool IsOnBattery()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT BatteryStatus FROM Win32_Battery"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        int status = Convert.ToInt32(obj["BatteryStatus"]);
                        return status != 2; // 2 = AC power
                    }
                }
            }
            catch { }
            return false;
        }

        public static int GetBatteryPercent()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT EstimatedChargeRemaining FROM Win32_Battery"))
                {
                    foreach (var obj in searcher.Get())
                        return Convert.ToInt32(obj["EstimatedChargeRemaining"]);
                }
            }
            catch { }
            return -1;
        }
    }

    // === 2. Screensaver ===
    public class KioskScreensaver : Form
    {
        private System.Windows.Forms.Timer _animTimer;
        private float _x, _y;
        private float _dx = 2, _dy = 1.5f;
        private string _cafeName = "گیم‌نت";

        public KioskScreensaver(string cafeName)
        {
            _cafeName = cafeName ?? "گیم‌نت";
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.TopMost = true;
            this.BackColor = Color.FromArgb(10, 10, 20);
            this.DoubleBuffered = true;
            _x = Screen.PrimaryScreen.Bounds.Width / 2f;
            _y = Screen.PrimaryScreen.Bounds.Height / 2f;

            _animTimer = new System.Windows.Forms.Timer { Interval = 30 };
            _animTimer.Tick += (s, e) => Animate();
            _animTimer.Start();

            this.Click += (s, e) => Close();
            this.KeyDown += (s, e) => Close();
        }

        // FIX-MINOR-UPDATE FIX 1: dispose the animation timer when the
        // screensaver form closes — previously it was leaked on every
        // close (every kiosk idle cycle), accumulating GDI + timer
        // handles over a long kiosk uptime.
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { _animTimer?.Stop(); _animTimer?.Dispose(); _animTimer = null; } catch { }
            base.OnFormClosing(e);
        }

        private void Animate()
        {
            _x += _dx; _y += _dy;
            var bounds = Screen.PrimaryScreen.Bounds;
            if (_x < 100 || _x > bounds.Width - 100) _dx = -_dx;
            if (_y < 50 || _y > bounds.Height - 50) _dy = -_dy;
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using (var font = new Font("Segoe UI", 48F, FontStyle.Bold))
            using (var brush = new LinearGradientBrush(new RectangleF(_x - 200, _y - 50, 400, 100), Color.FromArgb(137, 180, 250), Color.FromArgb(203, 166, 247), 45f))
            {
                var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                g.DrawString($"🎮 {_cafeName}", font, brush, _x, _y, sf);
            }

            using (var font2 = new Font("Segoe UI", 14F))
                g.DrawString("برای ادامه کلیک کنید", font2, Brushes.Gray, Screen.PrimaryScreen.Bounds.Width / 2f, Screen.PrimaryScreen.Bounds.Height - 80,
                    new StringFormat { Alignment = StringAlignment.Center });
        }
    }

    // === 3. Splash Screen === removed in round 11 (user request).

    // === 4. RFID / Card Reader Login ===
    public class CardReaderForm : Form
    {
        public string CardId { get; private set; }

        public CardReaderForm()
        {
            this.Text = "💳 ورود با کارت";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lbl = new Label { Text = "💳 کارت خود را بکشید یا کد را وارد کنید:", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(166, 227, 161), Location = new Point(20, 20), AutoSize = true };
            var txt = new TextBox { Location = new Point(20, 60), Size = new Size(340, 35), Font = new Font("Consolas", 14F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnOk = new Button { Text = "✓ ورود", Location = new Point(20, 110), Size = new Size(160, 38), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.OK };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(200, 110), Size = new Size(160, 38), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.Cancel };

            txt.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { CardId = txt.Text.Trim(); this.DialogResult = DialogResult.OK; this.Close(); } };
            btnOk.Click += (s, e) => { CardId = txt.Text.Trim(); };

            this.Controls.AddRange(new Control[] { lbl, txt, btnOk, btnCancel });
        }
    }

    // === 6. Multi-monitor Support ===
    public static class MultiMonitor
    {
        public static int MonitorCount => Screen.AllScreens.Length;

        public static Screen GetSecondaryScreen()
        {
            var screens = Screen.AllScreens;
            return screens.Length > 1 ? screens[1] : null;
        }
    }

    // === 8. Network Speed Test ===
    public class SpeedTestPanel : UserControl
    {
        private Label _lblResult;
        private Button _btnTest;

        public SpeedTestPanel()
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "📊 تست سرعت شبکه", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(137, 180, 250), Location = new Point(20, 15), AutoSize = true };

            _btnTest = new Button { Text = "🚀 شروع تست", Location = new Point(20, 55), Size = new Size(200, 40), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnTest.Click += (s, e) => RunTest();

            _lblResult = new Label { Text = "نتیجه: ---", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 110), AutoSize = true };

            this.Controls.AddRange(new Control[] { lblTitle, _btnTest, _lblResult });
        }

        private void RunTest()
        {
            _btnTest.Enabled = false;
            _lblResult.Text = "در حال تست...";

            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    // Ping test to server
                    var ping = new Ping();
                    var reply = ping.Send(ConnectionSettings.ServerHost, 5000);

                    if (reply.Status == IPStatus.Success)
                    {
                        BeginInvoke((Action)(() =>
                        {
                            _lblResult.Text = $"✅ پینگ: {reply.RoundtripTime}ms\n📊 وضعیت: متصل و سالم";
                            _lblResult.ForeColor = Color.FromArgb(166, 227, 161);
                        }));
                    }
                    else
                    {
                        BeginInvoke((Action)(() =>
                        {
                            _lblResult.Text = "❌ اتصال برقرار نشد";
                            _lblResult.ForeColor = Color.FromArgb(243, 139, 168);
                        }));
                    }
                }
                catch (Exception ex)
                {
                    BeginInvoke((Action)(() =>
                    {
                        _lblResult.Text = "❌ خطا: " + ex.Message;
                        _lblResult.ForeColor = Color.FromArgb(243, 139, 168);
                    }));
                }
                finally
                {
                    BeginInvoke((Action)(() => _btnTest.Enabled = true));
                }
            });
        }
    }

    // === 9. QR Code Login (display QR for mobile) ===
    public class QrLoginPanel : UserControl
    {
        public QrLoginPanel(string stationName, string serverIp)
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "📱 ورود با QR کد", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(203, 166, 247), Location = new Point(20, 15), AutoSize = true };

            var lblInfo = new Label { Text = $"QR کد زیر را با گوشی اسکن کنید\nتا مستقیماً وارد شوید.\n\nایستگاه: {stationName}\nسرور: {serverIp}", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 55), Size = new Size(350, 80) };

            // Simple QR placeholder (in production, generate real QR)
            var qrBox = new PictureBox { Location = new Point(100, 150), Size = new Size(200, 200), BackColor = Color.White, SizeMode = PictureBoxSizeMode.CenterImage };
            try
            {
                // Draw a simple placeholder QR-like pattern
                var bmp = new Bitmap(200, 200);
                using (var g = Graphics.FromImage(bmp)) { g.Clear(Color.White); g.FillRectangle(Brushes.Black, 20, 20, 40, 40); g.FillRectangle(Brushes.Black, 140, 20, 40, 40); g.FillRectangle(Brushes.Black, 20, 140, 40, 40); }
                qrBox.Image = bmp;
            }
            catch { }

            this.Controls.AddRange(new Control[] { lblTitle, lblInfo, qrBox });
        }
    }

    // === 10. Wallpaper Setter ===
    public static class WallpaperSetter
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

        private const int SPI_SETDESKWALLPAPER = 20;
        private const int SPIF_UPDATEINIFILE = 1;
        private const int SPIF_SENDCHANGE = 2;

        public static void SetWallpaper(string imagePath)
        {
            try { SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, imagePath, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE); }
            catch { }
        }

        public static void SetWallpaperFromBase64(string base64)
        {
            try
            {
                string tempPath = Path.Combine(Path.GetTempPath(), "gamenet_wallpaper.jpg");
                File.WriteAllBytes(tempPath, Convert.FromBase64String(base64));
                SetWallpaper(tempPath);
            }
            catch { }
        }
    }

    // === 11. Ambient Music Player ===
    public static class AmbientMusic
    {
        private static System.Media.SoundPlayer _player;
        private static bool _enabled;

        public static void Start(string musicPath = null)
        {
            try
            {
                if (string.IsNullOrEmpty(musicPath)) return;
                if (!File.Exists(musicPath)) return;
                _player = new System.Media.SoundPlayer(musicPath);
                _player.PlayLooping();
                _enabled = true;
            }
            catch { }
        }

        public static void Stop()
        {
            try { _player?.Stop(); _enabled = false; } catch { }
        }

        public static bool IsPlaying => _enabled;
    }

    // === 12. Temperature Display ===
    public static class TempMonitor
    {
        public static double GetCpuTemp()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        double temp = Convert.ToDouble(obj["CurrentTemperature"]);
                        return Math.Round((temp - 2732) / 10.0, 1); // Kelvin to Celsius
                    }
                }
            }
            catch { }
            return -1;
        }

        public static double GetGpuTemp()
        {
            // GPU temp requires NVAPI or AMD SDK — return -1 if unavailable
            return -1;
        }
    }
}
