﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;
using Microsoft.Win32;

namespace GameNet.Client
{
    public partial class KioskForm : Form
    {
        private ClientEngine _engine;
        private bool _isLocked = true;
        // 1-second UI timer that drives the billing display by calling
        // _engine.CheckSession() while a session is active.
        private System.Windows.Forms.Timer _sessionTimer;
        // Round 10: not readonly; ApplyServerAddress points them at a new server.
        private string _serverHost;
        private int _serverPort;

        // Config-driven feature visibility (set from server ConfigSync).
        // REAPPLY-KIOSK-CHANGES-1 (Part A): _showTicket removed — the handyCafe
        // sidebar no longer exposes a ticket button at all.
        // Round 6: _showGames/_showSettings removed. The server's feature switches
        // that apply to a right-column item are kept here by feature key (missing
        // key = on, the server's default), filled by OnConfigSync and applied by
        // LayoutSessionControls to the item with the same meaning.
        private readonly System.Collections.Generic.Dictionary<string, bool> _serverFeatureOn =
            new System.Collections.Generic.Dictionary<string, bool>();
        private static readonly string[] ColumnFeatureKeys =
            { "chat", "announcements", "loyalty", "profile", "stats", "topup", "food", "ambient_music", "settings" };

        // Round 6: right-column buttons for features that had no button since the
        // original v5 source (chat, announcements, loyalty, profile, stats, food
        // order, music). Created once by EnsureColumnFeatureButtons.
        private Button _btnColChat, _btnColAnnouncements, _btnColLoyalty, _btnColProfile,
                       _btnColStats, _btnColFood, _btnColMusic;
        private static readonly Font ColumnButtonFont = new Font("Segoe UI", 9F, FontStyle.Bold);
        // Round 6: the food-order and music handlers, kept so the column buttons can
        // run them too (btnFood and btnMusic are not on screen).
        private EventHandler _foodOrderHandler, _musicToggleHandler;
        // Round 6: latest loyalty points from OnTierInfo for the points row (-1 = not known yet).
        private int _lastLoyaltyPoints = -1;

        // Round 7: admin mode. The offline admin login (admin and its password on the
        // login screen, ClientOptions.VerifySuperAdmin) used to open a two-option
        // maintenance dialog. It now opens the right column in admin mode: an orange
        // header, the IP row, the server status, and four buttons (client settings,
        // desktop, lock, full exit). The customer items are hidden meanwhile.
        private bool _adminMode;
        // Round 7: the header label, so admin mode can change its text.
        private Label _sidebarBrand;
        private Label _adminStatus, _adminHint;
        private Button _btnAdminSettings, _btnAdminDesktop, _btnAdminLock, _btnAdminExit, _btnAdminDoctor;
        private static readonly Font AdminButtonFont = new Font("Segoe UI", 10F, FontStyle.Bold);
        private static readonly Color SidebarBarColor = Color.FromArgb(51, 95, 189);
        private static readonly Color AdminBarColor = Color.FromArgb(196, 82, 18);
        // Round 7: ends admin mode after ClientOptions.AdminIdleLockMinutes without
        // keyboard or mouse input (checked every 15 s).
        private System.Windows.Forms.Timer _adminIdleTimer;
        // Round 7: the settings dialog while it is open, so leaving admin mode can close it.
        private Form _openSettingsDialog;
        // Round 10: remaining minutes at the previous session update, for the
        // OnTimeEndMinutes warning (int.MaxValue = none yet in this session).
        private int _prevRemForTimeEnd = int.MaxValue;
        // Round 10: set while the kiosk waits a few seconds after a logout so the
        // logout message and sound can be seen and heard.
        private bool _closePending;

        // REAPPLY-KIOSK-CHANGES-1 (Part B): handyCafe-style sidebar controls.
        // The session panel renders a 280px-wide column docked to the right of
        // the screen, composed of: a blue header bar with the brand label, a
        // white timer panel that exposes four rows (Start / Remaining / Used /
        // Cost), a 2-column button grid, and a blue footer bar with the
        // version label.
        private System.Windows.Forms.Panel _sidebarHeader;
        private System.Windows.Forms.Panel _sidebarFooter;
        private System.Windows.Forms.Panel _sidebarTimer;
        // One Label per timer row (Start / Remaining / Used / Cost).
        private System.Windows.Forms.Label[] _sidebarTimerLabels;
        // One Panel per timer row (so ApplyHideSettings can hide a whole row).
        private System.Windows.Forms.Panel[] _sidebarTimerRows;
        private TimeWarningOverlay _timeOverlay;
        // Sound alert tracking — play once per threshold
        private int _lastSoundMinute = -1;
        private bool _dndMode = false;
        // Phase 14: feature flag-controlled extras
        private bool _upsEnabled = true;
        private bool _screensaverEnabled = true;
        private System.Windows.Forms.Timer _screensaverTimer;

        // FIX H6/L13: stored delegate for UpsMonitor.OnPowerLost so we can
        // unsubscribe in OnFormClosed (was a fresh lambda each time, so the
        // event kept a strong ref to the form even after Dispose).
        private Action _upsPowerLostHandler;

        // ADD-CLIENT-25 — Task 24: LowPerformanceMode (read from
        // ConnectionSettings). When true: disable splash/screensaver/music,
        // reduce timer refresh from 1s to 5s, disable game cover images,
        // reduce animation effects.
        private bool _lowPerfMode;
        // BUG FIX: shows the DisableLoginRequest warning MessageBox once
        // per app run rather than every time this check re-executes, so it
        // doesn't nag the operator repeatedly if it's genuinely intentional.
        private bool _disableLoginWarningShown;

        // ADD-CLIENT-25 — Task 25: secondary timer form shown on the second
        // monitor when the kiosk detects 2+ displays. Lets the customer see
        // the timer while the game runs full-screen on the primary monitor.
        private SecondaryTimerForm _secondaryTimer;

        // ADD-CLIENT-25 — Task 3: banner overlay shown at 5min/1min/0min. We
        // track the last banner threshold so each one only shows once per
        // session (so a session that drops to 5min and gets topped up to 8min
        // and then drops to 5min again triggers the 5-min banner again only
        // if it crosses the threshold fresh — see OnSessionUpdate).
        // FIX (FIX-CLIENT-BUGS B8): changed initial value from -1 to int.MaxValue.
        // See the long comment above the OnSessionUpdate banner logic for why.
        private int _lastBannerMinute = int.MaxValue;
        // Track the last banner instance so we can close it before showing a
        // new one (avoids stacking banners when multiple thresholds trigger
        // in rapid succession).
        private ToastBanner _activeBanner;

        // ADD-CLIENT-25 — Task 19: news ticker scrolling timer + the latest
        // ticker text. The timer slides the text horizontally so the operator
        // can post long announcements without them being clipped.
        private System.Windows.Forms.Timer _tickerTimer;
        private int _tickerOffset;
        private string _tickerText = "📢 به گیم‌نت خوش آمدید!";
        // FIX DEAD-CONFIG-4: color for the ticker text, configurable via
        // OptionsForm → بنرها → "رنگ بنر" (previously saved but never sent
        // to the client or applied anywhere).
        private Color _tickerColor = Color.FromArgb(249, 226, 175);

        public KioskForm() : this(ConnectionSettings.ServerHost, ConnectionSettings.ServerPort) { }

        public KioskForm(string serverHost, int serverPort)
        {
            _serverHost = serverHost;
            _serverPort = serverPort;

            InitializeComponent();
            GameNet.Shared.AppIcon.Apply(this); // round 11: 3D program icon

            // REAPPLY-KIOSK-CHANGES-1 (Part F.1): load the handyCafe client
            // options BEFORE any other initialization step so every Apply*
            // call below sees the operator-configured values. The persisted
            // store lives at %APPDATA%\GameNet\client_options.json.
            try { ClientOptions.Load(); } catch { }

            // Round 10: the server address is no longer copied from ClientOptions. Its
            // "127.0.0.1" default overwrote ConnectionSettings.ServerHost, and the engine
            // never used it. The address lives in server_settings.txt (ConnectionSettings);
            // the Options dialog's General tab edits that (ApplyServerAddress).

            // REAPPLY-KIOSK-CHANGES-1 (Parts F.2-F.5): apply the environment-side options
            // now so the kiosk boots with the operator's chosen wallpaper / USB policy /
            // language. Round 10: the UDP auto-discovery call is gone (no server answered
            // it; it only delayed the start by 2 s). Program.cs looks for the server on
            // the LAN when the saved one does not answer (ClientOptions.AutoDiscovery).
            try { ApplyDefaultWallpaper(); } catch { }
            try { ApplyUsbProtection(); } catch { }
            try { ApplyLanguage(); } catch { }

            // ADD-CLIENT-25 — Task 24: load the LowPerformanceMode flag from
            // ConnectionSettings (loaded from server_settings.txt) BEFORE we
            // configure any feature that depends on it.
            _lowPerfMode = ConnectionSettings.LowPerformanceMode;
            if (_lowPerfMode)
            {
                _upsEnabled = false;
                _screensaverEnabled = false;
            }

            // Kiosk mode: borderless, top-most, FULLSCREEN.
            // The kiosk fills the entire screen so the customer can't see
            // or interact with the desktop.
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.ShowInTaskbar = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            // Full screen — fill the entire primary monitor.
            // BUG FIX: this used to also set `this.Bounds = screen;`
            // immediately before setting WindowState — two separate sizing
            // operations back to back, each independently capable of firing
            // the Resize handler below (which repositions the login fields
            // via CenterLoginControls). Depending on exact timing, that
            // could race and leave the fields positioned using a stale or
            // partial ClientSize — a plausible cause of intermittent
            // "field doesn't appear correctly" symptoms, since race
            // conditions don't behave the same way on every run.
            // WindowState = Maximized alone is sufficient to fill the
            // screen; the redundant Bounds assignment is removed.
            this.WindowState = FormWindowState.Maximized;

            // Center the login controls whenever the form resizes.
            // FIX M4: also re-layout the session controls so the game menu
            // and buttons adapt to the new form size. Previously only the
            // login panel was re-centered on resize — the session panel's
            // controls stayed at their initial (1280×800-design) positions,
            // causing the game menu to overflow on smaller screens or leave
            // empty space on larger ones.
            this.Resize += (s, e) =>
            {
                CenterLoginControls();
                LayoutSessionControls();
                // FIX DESKTOP-ACCESS: when the kiosk is restored from
                // minimized (user clicked it in the taskbar to return),
                // re-enable TopMost so it's on top again.
                if (this.WindowState != FormWindowState.Minimized)
                {
                    this.TopMost = true;
                }
            };

            // BUG FIX: final, authoritative re-layout once the window has
            // fully finished showing and sizing — Shown fires exactly once,
            // after InitializeComponent, the maximize, and any
            // Resize-triggered layout passes above have settled. This is a
            // safety net against the login fields ending up positioned
            // using a stale/partial size from an earlier race during
            // startup (see the BUG FIX note above on the Bounds removal).
            this.Shown += (s, e) =>
            {
                CenterLoginControls();
                LayoutSessionControls();
                // Round 11: start-up sound — the station has been switched on (the
                // kiosk starts with Windows) and is ready.
                try { SoundAlert.PlayStartup(); } catch { }
            };

            // FIX L4: do NOT call SecurityLock here. Previously the kiosk
            // disabled Task Manager + blocked special keys at the very START
            // of the ctor — if anything later in the ctor threw (engine
            // init, timer setup, ConfigSync subscribe), the system was left
            // locked (TaskMgr disabled, Win keys blocked) but the form was
            // never shown, so the operator had no UI to recover with. The
            // SecurityLock calls are now made at the END of the ctor (after
            // SetupEngine / SetupSessionTimer / ShowLoginPanel succeed), and
            // any ctor exception is caught + RestoreAll'd in the outer
            // try/catch below so the system is always left unlocked on
            // failure.

            this.FormClosing += KioskForm_FormClosing;
            this.KeyPreview = true;
            this.KeyDown += (s, e) =>
            {
                if (e.Alt && e.KeyCode == Keys.F4) e.SuppressKeyPress = true;
                if (e.KeyCode == Keys.LWin || e.KeyCode == Keys.RWin) e.SuppressKeyPress = true;
            };

            // REAPPLY-KIOSK-CHANGES-1 (Part C): btnNavSettings used to open
            // the ConnectionSettingsForm (server IP/port dialog). That dialog
            // is now superseded by the handyCafe-style ClientOptionsForm's
            // General tab (admin username/password + server IP + auto). The
            // nav button itself is repurposed as the ⏻ خروج (logout) button
            // — see KioskForm.Designer.cs — so it now wires directly to
            // btnLogout_Click below. The btnNavOptions button below opens
            // the new ClientOptionsForm.
            // Round 7: outside admin mode the settings button asks for the admin
            // username and password first (OpenClientOptionsChecked).
            btnNavOptions.Click += (s, e) => OpenClientOptionsChecked();
            btnNavSettings.Click += (s, e) =>
            {
                try { btnLogout_Click(s, e); }
                catch { }
            };

            // REAPPLY-KIOSK-CHANGES-1 (Part A): the btnNavTicket.Click handler
            // (InputBox for ticket code) is removed entirely. The handyCafe
            // sidebar's "➕ اعتبار" button covers the same quick-credit UX.

            // ADD-CLIENT-25 — Task 4: quick top-up button on the session panel.
            // Clicking it opens an InputBox asking for the amount, then sends
            // ClientTopupRequest to the server. Much faster than navigating
            // through the sidebar to the TopupPanel.
            btnQuickTopup.Click += (s, e) =>
            {
                try
                {
                    string amt = Microsoft.VisualBasic.Interaction.InputBox("مبلغ شارژ (تومان):", "💰 شارژ سریع", "10000");
                    if (!string.IsNullOrWhiteSpace(amt))
                    {
                        amt = amt.Replace(",", "").Trim();
                        if (decimal.TryParse(amt, out decimal amount) && amount > 0)
                        {
                            _engine.RequestTopup(amount, "cash");
                            try { ActivityLogger.TopupRequested(amount, "cash"); } catch { }
                            MessageBox.Show(DialogOwner(), $"✅ درخواست شارژ {amount:N0} تومان ارسال شد.\nمنتظر تأیید اپراتور بمانید.", "شارژ سریع", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show(DialogOwner(), "مبلغ معتبر وارد کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            // ADD-CLIENT-25 — Task 16: food/drink ordering button. Opens a
            // simple InputBox asking for the item + quantity, then sends a
            // ClientFoodOrder message to the server.
            // Round 6: kept in _foodOrderHandler so the right column's
            // "food order" button runs the same dialog.
            _foodOrderHandler = (s, e) =>
            {
                try
                {
                    // Build a simple food-order dialog inline (avoids a separate
                    // FoodPanel swap that would hide the games grid).
                    using (var dlg = new Form())
                    {
                        dlg.Text = "🥤 سفارش غذا";
                        dlg.Size = new Size(380, 240);
                        dlg.StartPosition = FormStartPosition.CenterParent;
                        dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                        dlg.BackColor = Color.FromArgb(240, 240, 240);
                        dlg.ForeColor = Color.FromArgb(40, 40, 40);
                        dlg.RightToLeft = RightToLeft.Yes;

                        var lblItem = new Label { Text = "آیتم:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
                        var cboItem = new ComboBox { Location = new Point(120, 17), Size = new Size(220, 30), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };
                        cboItem.Items.AddRange(new object[] { "نوشابه", "چای", "قهوه", "ساندویچ", "پیتزا", "آب معدنی" });
                        cboItem.SelectedIndex = 0;

                        var lblQty = new Label { Text = "تعداد:", Location = new Point(20, 60), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
                        var numQty = new NumericUpDown { Location = new Point(120, 57), Size = new Size(80, 30), Minimum = 1, Maximum = 20, Value = 1, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };

                        var btnSend = new Button { Text = "📤 سفارش", Location = new Point(20, 110), Size = new Size(150, 40), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.OK };
                        var btnCancel = new Button { Text = "انصراف", Location = new Point(190, 110), Size = new Size(150, 40), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(240, 240, 240), DialogResult = DialogResult.Cancel };

                        dlg.Controls.AddRange(new Control[] { lblItem, cboItem, lblQty, numQty, btnSend, btnCancel });
                        dlg.AcceptButton = btnSend;
                        dlg.CancelButton = btnCancel;

                        if (ShowKioskDialog(dlg) == DialogResult.OK)
                        {
                            string item = cboItem.SelectedItem?.ToString() ?? "";
                            int qty = (int)numQty.Value;
                            var items = new System.Collections.Generic.List<FoodOrderItem>
                            {
                                new FoodOrderItem { Name = item, Quantity = qty, Price = 15000 }
                            };
                            decimal total = items[0].Price * qty;
                            _engine.SendSafe(new NetMessage(MessageType.ClientFoodOrder,
                                new FoodOrderPayload
                                {
                                    Username = _engine.Username ?? "",
                                    StationName = Environment.MachineName,
                                    Items = items,
                                    TotalAmount = total,
                                    Notes = "",
                                    OrderedAt = DateTime.UtcNow
                                }, _engine.SessionId));
                            try { ActivityLogger.FoodOrdered(item, total); } catch { }
                            // Show a non-blocking toast banner (task 16 UX).
                            ShowToast("🥤 سفارش غذا", "سفارش ارسال شد ✓", "info");
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            btnFood.Click += _foodOrderHandler;

            // ADD-CLIENT-25 — Task 18: ambient music button. Toggles the
            // AmbientMusic player (using System.Media.SoundPlayer for WAV).
            // In low-perf mode the button is hidden (Task 24).
            // Round 6: kept in _musicToggleHandler so the right column's
            // "music" button runs the same toggle.
            _musicToggleHandler = (s, e) =>
            {
                try
                {
                    if (AmbientMusic.IsPlaying)
                    {
                        AmbientMusic.Stop();
                        btnMusic.Text = "🎵 موسیقی";
                        ShowToast("🎵 موسیقی", "موسیقی متوقف شد", "info");
                    }
                    else
                    {
                        // Look for a music file in the app's music/ folder.
                        string musicDir = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "music");
                        string musicFile = null;
                        if (System.IO.Directory.Exists(musicDir))
                        {
                            foreach (var f in System.IO.Directory.GetFiles(musicDir, "*.wav"))
                            {
                                musicFile = f; break;
                            }
                        }
                        if (musicFile != null)
                        {
                            AmbientMusic.Start(musicFile);
                            btnMusic.Text = "⏸️ توقف موسیقی";
                            ShowToast("🎵 موسیقی", "موسیقی پخش شد", "info");
                        }
                        else
                        {
                            ShowToast("🎵 موسیقی", "فایل موسیقی موجود نیست\n(یک فایل .wav در پوشه music/ قرار دهید)", "warning");
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            btnMusic.Click += _musicToggleHandler;

            // ADD-CLIENT-25 — Task 24: in low-perf mode, hide non-essential UI.
            if (_lowPerfMode)
            {
                btnMusic.Visible = false;
            }

            // FIX MONITOR-TO-CLIENT: repurpose nav buttons as monitoring action
            // buttons. These send requests to the server (via the engine) to
            // control the current session — same actions that were in the
            // server's ClientMonitorForm right panel.
            // FIX DESKTOP-ACCESS: btnNavHome now shows the desktop (minimizes
            // the kiosk so the user can see the desktop and launch games
            // directly from shortcuts/icons). btnNavSettings is now logout.
            btnNavHome.Click += (s, e) =>
            {
                try
                {
                    // Minimize the kiosk so the desktop is visible.
                    this.TopMost = false;
                    this.WindowState = FormWindowState.Minimized;
                    // Show a small toast so the user knows how to return.
                    try { System.Windows.Forms.ToolTip tip = new System.Windows.Forms.ToolTip(); tip.Show("برای بازگشت به markazbazi، روی آیکون آن در تسک‌بار کلیک کنید", this, 5000); } catch { }
                }
                catch { }
            };
            btnNavGames.Click += (s, e) => { try { _engine?.SetSessionTimeRequest(1, 10, "+10"); } catch { } };
            btnNavChat.Click += (s, e) => { try { _engine?.SetSessionTimeRequest(1, 30, "+30"); } catch { } };
            btnNavAnnounce.Click += (s, e) => { try { _engine?.SetSessionTimeRequest(1, 60, "+60"); } catch { } };
            btnNavLoyalty.Click += (s, e) => { try { _engine?.SetSessionTimeRequest(3, 0, "پایان"); } catch { } };
            btnNavProfile.Click += (s, e) => { try { _engine?.RequestScreenshot(); } catch { } };
            btnNavStats.Click += (s, e) =>
            {
                try
                {
                    string m = Microsoft.VisualBasic.Interaction.InputBox("پیام:", "ارسال پیام به اپراتور");
                    if (!string.IsNullOrEmpty(m)) _engine?.SendChatMessage(m);
                }
                catch { }
            };
            btnNavTopup.Click += (s, e) =>
            {
                try
                {
                    string amt = Microsoft.VisualBasic.Interaction.InputBox("مبلغ شارژ (تومان):", "💰 شارژ سریع", "10000");
                    if (!string.IsNullOrWhiteSpace(amt))
                    {
                        amt = amt.Replace(",", "").Trim();
                        if (decimal.TryParse(amt, out decimal amount) && amount > 0)
                            _engine?.RequestTopup(amount, "cash");
                    }
                }
                catch { }
            };
            // REAPPLY-KIOSK-CHANGES-1 (Part A): the btnNavTicket handler
            // (unlimited-time request) is removed. btnNavSettings's logout
            // behavior is now wired above (right after the btnNavOptions.Click
            // wiring) — it is no longer wired here as a duplicate.

            // Wire DND toggle
            btnToggleSidebar.Click += (s, e) =>
            {
                _dndMode = !_dndMode;
                btnToggleSidebar.Text = _dndMode ? "🔇 سکوت" : "☰ منو";
                MessageBox.Show(_dndMode ? "حالت سکوت فعال شد. هشدارهای صوتی غیرفعال." : "حالت سکوت غیرفعال شد.");
            };

            // Keyboard shortcuts
            this.KeyDown += (s, e) =>
            {
                // REAPPLY-KIOSK-CHANGES-1 (Part C): F3 opens the handyCafe-
                // style ClientOptionsForm (was: SwapToPanel(new ChatPanel)).
                // Round 7: outside admin mode F3 asks for the admin username and
                // password first (OpenClientOptionsChecked).
                if (e.KeyCode == Keys.F3) { OpenClientOptionsChecked(); return; }
                if (e.KeyCode == Keys.F1) ShowLoginPanel();
                // Round 7: F2 only during a session or in admin mode. On the locked
                // login screen it opened the column, with the desktop beside it,
                // without any login.
                else if (e.KeyCode == Keys.F2)
                {
                    if (!_isLocked || _adminMode) { timerDisplayControl.Visible = true; ShowSessionPanel(); }
                }
                // Round 6: F4-F9 open their screen in its own window (ShowFeatureWindow).
                // SwapToPanel put it in the 280 px column, about 50 px wide. A key
                // whose right-column item is switched off does nothing.
                else if (e.KeyCode == Keys.F4)
                {
                    if (!ClientOptions.HideBtnAnnouncements && ServerAllows("announcements"))
                        ShowFeatureWindow("اطلاعیه‌ها", new AnnouncementsPanel(_engine));
                }
                else if (e.KeyCode == Keys.F5)
                {
                    if (!ClientOptions.DisableCafeteria && ServerAllows("topup"))
                        ShowFeatureWindow("شارژ سریع", new TopupPanel(_engine));
                }
                else if (e.KeyCode == Keys.F6)
                {
                    if (!ClientOptions.HideBtnProfile && ServerAllows("profile"))
                        ShowFeatureWindow("پروفایل کاربر", new ProfilePanel(_engine, _engine.Username ?? "کاربر", _engine.Balance));
                }
                else if (e.KeyCode == Keys.F7) ShowFeatureWindow("تاریخچه نشست‌ها", new HistoryPanel(_engine));
                else if (e.KeyCode == Keys.F8) ShowFeatureWindow("تنظیم صدا", new VolumePanel());
                else if (e.KeyCode == Keys.F9) ShowFeatureWindow("توقف موقت نشست", new PausePanel(_engine));
                // Round 7: F10 (log out and close the kiosk) only during a customer
                // session. On the locked login screen it closed the kiosk without any
                // login; admin mode has its own exit button.
                else if (e.KeyCode == Keys.F10)
                {
                    // Round 10: also not when the exit button is hidden on the customer page.
                    if (!_isLocked && !_adminMode && !ClientOptions.HideBtnExit) btnLogout_Click(s, e);
                }
                else if (e.Control && e.KeyCode == Keys.M) NightMode.Toggle(this);
            };

            // REAPPLY-KIOSK-CHANGES-1 (Part F.6): separate KeyDown handler
            // for the DisableAltEnter toggle (operator can suppress Alt+Enter
            // fullscreen toggling on games that misbehave when windowed).
            this.KeyDown += (s, e) =>
            {
                if (ClientOptions.DisableAltEnter && e.Alt && e.KeyCode == Keys.Enter)
                    e.SuppressKeyPress = true;
            };

            ApplyFeatureVisibility();
            // Create the time-warning overlay (hidden until time runs low)
            _timeOverlay = new TimeWarningOverlay();

            // Phase 14: Start background services (controlled by feature flags).
            // ADD-CLIENT-25 — Task 21: DEFER non-critical init to AFTER the
            // form is shown so the kiosk's UI appears immediately instead
            // of waiting 200ms for the screensaver timer + UPS monitor +
            // ticker timer to spin up. The screensaver timer doesn't need
            // to run before the form is visible (nothing to cover), and the
            // UPS monitor's first tick is 5s out anyway. The Shown handler
            // also sets up the multi-monitor secondary form (Task 25).
            if (!_lowPerfMode)
            {
                _upsEnabled = true;
                _screensaverEnabled = true;
            }
            _screensaverTimer = new System.Windows.Forms.Timer { Interval = 180000 }; // 3 min idle
            _screensaverTimer.Tick += (s, e) => { if (_screensaverEnabled && _isLocked) ShowScreensaver(); };
            // Don't Start() here — deferred to OnShown.

            // UPS monitor
            // FIX H6/L13: extract the lambda to a named method and store the
            // delegate so OnFormClosed can unsubscribe — otherwise the
            // UpsMonitor keeps a reference to this form via the closure and
            // the form cannot be GC'd, plus the handler keeps firing after
            // Dispose (the next power-lost event would NRE on BeginInvoke
            // against a disposed form).
            _upsPowerLostHandler = () => BeginInvoke((Action)(() =>
            {
                MessageBox.Show(DialogOwner(), "⚠️ برق قطع شد!\nنشست شما ذخیره می‌شود.\nلطفاً هرچه سریع‌تر ذخیره کنید.", "هشدار برق", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }));
            UpsMonitor.OnPowerLost += _upsPowerLostHandler;

            // ADD-CLIENT-25 — Task 19: news ticker scroll timer. Slides the
            // ticker text 2px left every 50ms; when the text scrolls fully off
            // the screen, resets to the right edge.
            _tickerTimer = new System.Windows.Forms.Timer { Interval = 50 };
            _tickerTimer.Tick += (s, e) =>
            {
                try
                {
                    _tickerOffset -= 2;
                    lblTicker.Invalidate();
                }
                catch { }
            };
            lblTicker.Paint += (s, e) =>
            {
                try
                {
                    var g = e.Graphics;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    using (var brush = new SolidBrush(_tickerColor))
                    using (var font = new Font("Segoe UI", 10F, FontStyle.Bold))
                    {
                        var size = g.MeasureString(_tickerText, font);
                        if (_tickerOffset < -size.Width) _tickerOffset = lblTicker.ClientSize.Width;
                        g.DrawString(_tickerText, font, brush, _tickerOffset, (lblTicker.ClientSize.Height - size.Height) / 2f);
                    }
                }
                catch { }
            };
            // Ticker starts on ShowSessionPanel.

            // ADD-CLIENT-25 — Task 21: deferred init via Shown. Non-critical
            // setup (splash, UPS, screensaver, multi-monitor) runs AFTER the
            // form is visible so the user sees the kiosk immediately.
            this.Shown += (s, e) =>
            {
                // FIX TEXTBOX-VISIBLE: force re-center after form is displayed.
                // This ensures the textboxes are visible even if ClientSize
                // wasn't correct during the constructor.
                try { CenterLoginControls(); } catch { }
                try
                {
                    if (_screensaverEnabled) _screensaverTimer.Start();
                    if (_upsEnabled) UpsMonitor.Start();
                }
                catch { }

                // ADD-CLIENT-25 — Task 25: multi-monitor support. If 2+ screens
                // are attached, show the secondary timer form on the second
                // monitor. The customer can see the timer while gaming on the
                // primary screen.
                try
                {
                    if (Screen.AllScreens.Length > 1)
                    {
                        _secondaryTimer = new SecondaryTimerForm();
                        _secondaryTimer.FormClosed += (s2, e2) => _secondaryTimer = null;
                        _secondaryTimer.Show();
                    }
                }
                catch { /* best-effort — multi-monitor is a UX enhancement */ }
            };

            SetupEngine();
            SetupSessionTimer();
            ShowLoginPanel();

            // FIX L4: NOW that every ctor step has succeeded, lock the system.
            // Wrap in try/catch so a partial failure (e.g. BlockSpecialKeys
            // throws because the keyboard hook DLL is missing) doesn't leave
            // TaskMgr disabled while the hook isn't installed — RestoreAll
            // unwinds whatever was already applied.
            try
            {
                SecurityLock.DisableTaskManager();
                SecurityLock.BlockSpecialKeys();
            }
            catch (Exception ex)
            {
                // Restore whatever was applied so the kiosk isn't half-locked.
                try { SecurityLock.RestoreAll(); } catch { }
                // Log to the client audit file (best-effort) so the operator
                // can see why the kiosk failed to lock down.
                try
                {
                    string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_log.txt");
                    System.IO.File.AppendAllText(logPath,
                        $"{DateTime.UtcNow:o}  KioskForm SecurityLock init failed: {ex.Message}{Environment.NewLine}");
                }
                catch { }
                // Re-throw so the outer Program.cs handler can show the error
                // and RestoreSystemOnce runs in the finally block.
                throw;
            }
        }

        /// <summary>
        /// Shows/hides sidebar nav buttons based on the _show* config flags.
        /// Called after ConfigSync updates the flags.
        /// REAPPLY-KIOSK-CHANGES-1 (Part A): removed btnNavTicket/btnTicket
        /// visibility lines and the btnNavTicket reposition line. The
        /// handyCafe sidebar layout is driven entirely by
        /// LayoutSessionControls now.
        /// </summary>
        private void ApplyFeatureVisibility()
        {
            // Round 6: LayoutSessionControls applies the server switches to the
            // item with the same meaning (ServerAllows) together with the
            // Options dialog's switches.
            try { LayoutSessionControls(); } catch { }
        }

        /// <summary>
        /// Swaps the session panel's content to the given UserControl (chat,
        /// announcements, profile, etc.). The timer is hidden
        /// while the alternate panel is shown.
        /// </summary>
        private void SwapToPanel(UserControl panel)
        {
            // Hide the timer while another panel is shown
            timerDisplayControl.Visible = false;

            // Remove any previously-swapped panel.
            // FIX (FIX-CLIENT-BUGS B12): iterating over pnlSession.Controls
            // while calling Remove(c) inside the foreach is unsafe —
            // ControlCollection's enumerator does NOT snapshot the list, so
            // removing at index i shifts subsequent elements down and the
            // enumerator's internal index SKIPS the next element. In practice
            // this meant that if two swap-panels were open (e.g. ChatPanel +
            // a previously-opened AnnouncementsPanel that wasn't disposed),
            // only the first was removed + disposed; the second lingered
            // (invisible, capturing engine events, leaking handles). Collect
            // them first, then remove+dispose.
            var toRemove = new System.Collections.Generic.List<Control>();
            foreach (Control c in pnlSession.Controls)
            {
                if (c is ChatPanel || c is AnnouncementsPanel || c is ProfilePanel || c is StatsPanel || c is LoyaltyPanel || c is TopupPanel)
                    toRemove.Add(c);
            }
            foreach (Control c in toRemove)
            {
                pnlSession.Controls.Remove(c);
                c.Dispose();
            }

            // Add the new panel
            panel.Location = new Point(20, 15);
            panel.Size = new Size(pnlSession.Width - 230, pnlSession.Height - 30);
            pnlSession.Controls.Add(panel);
            panel.BringToFront();
            pnlSession.Visible = true;
            pnlLogin.Visible = false;
        }

        private void KioskForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // FIX (FIX-B1-B4 B2, HIGH): if the user/operator explicitly chose
            // to exit (btnLogout_Click set IsExplicitExit=true), ALWAYS allow
            // the close — even if a session is still active on the client side
            // (e.g. ClientLogout send failed because the network is down).
            // Previously, when SendSafe(ClientLogout) returned false, State
            // stayed InSession, and this handler would re-cancel the close
            // that btnLogout_Click had just initiated — trapping the user on
            // a kiosk they could not exit. The explicit-exit path now bypasses
            // both the InSession block and the _isLocked block below.
            if (IsExplicitExit) return;

            // FIX 6: never block Windows shutdown / logoff / Task Manager /
            // Application.Exit — otherwise the kiosk prevents the OS from
            // shutting down and the user has to hard-power-cycle the machine.
            if (e.CloseReason == CloseReason.WindowsShutDown ||
                e.CloseReason == CloseReason.TaskManagerClosing ||
                e.CloseReason == CloseReason.ApplicationExitCall)
            {
                // Allow Windows shutdown / Task Manager / Application.Exit — don't block.
                return;
            }
            // Round 7: admin mode is not locked (_isLocked false), but the window still
            // closes only through the column's exit button (Application.Exit, allowed
            // above), not through a close message.
            if (_adminMode)
            {
                e.Cancel = true;
                return;
            }
            // Always block close during an active session (operator must end it
            // first via the server operator UI). Allow close when no session.
            if (_engine != null && _engine.State == ClientState.InSession)
            {
                e.Cancel = true;
                // C3: use BeginInvoke so we don't block the thread that triggered
                // the close (could be a WM_CLOSE from another process).
                BeginInvoke((Action)(() =>
                    MessageBox.Show(DialogOwner(), "برای خروج ابتدا نشست را پایان دهید.", "خروج ممکن نیست",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning)));
                return;
            }
            if (_isLocked && !IsExplicitExit)
            {
                e.Cancel = true;
            }
        }

        // FIX C4: settable IsExplicitExit — wired to an authenticated
        // operator exit shortcut (Ctrl+Shift+Alt+Q + password prompt).
        // Previously hardcoded `=> false`, so the operator had no normal
        // way to close the kiosk (Task Manager disabled, close button blocked).
        private bool _isExplicitExit = false;
        private bool IsExplicitExit { get => _isExplicitExit; set => _isExplicitExit = value; }

        private void SetupEngine()
        {
            _engine = new ClientEngine(_serverHost, _serverPort);

            // C3: every event handler uses BeginInvoke (async) so the network
            // reader thread is NEVER blocked waiting on the UI thread. This is
            // what keeps ServerTimeExpired / ServerForceLogout / heartbeats
            // flowing even while a modal dialog (MessageBox / WarningNotification)
            // is on screen.
            _engine.OnConnected += () => BeginInvoke((Action)(() =>
            {
                string myIp = LocalNetworkInfo.GetLocalIp();
                string host = LocalNetworkInfo.GetHostname();
                lblStatus.Text = $"🟢 متصل به سرور | IP: {myIp} | {host}";
                lblStatus.ForeColor = Color.FromArgb(20, 130, 50);
                // FIX C1: on a reconnect-resume (ServerWelcome with the same
                // SessionId), OnConnected fires again but the billing timer
                // was stopped in OnDisconnected. Restart it so the session
                // display keeps ticking instead of freezing.
                if (_engine.State == ClientState.InSession) _sessionTimer?.Start();
            }));

            _engine.OnDisconnected += (r) => BeginInvoke((Action)(() =>
            {
                lblStatus.Text = $"قطع: {r}";
                lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
                // Stop the billing timer while disconnected.
                _sessionTimer?.Stop();
                // ADD-CLIENT-25 — Task 23: show a non-blocking "در حال اتصال
                // مجدد..." toast on the initial disconnect so the user knows
                // the kiosk is recovering (not just frozen). Subsequent
                // attempts get their own toast via OnReconnectAttempt below.
                ShowToast("🔌 قطع ارتباط", "در حال اتصال مجدد...", "warning", 3000);
            }));

            // ADD-CLIENT-25 — Task 23: show a "در حال اتصال مجدد..." toast on
            // each reconnect attempt so the user knows the kiosk is actively
            // retrying (and roughly how long the next attempt will take).
            _engine.OnReconnectAttempt += (attempt, delayMs) => BeginInvoke((Action)(() =>
            {
                try
                {
                    double delaySec = delayMs / 1000.0;
                    lblStatus.Text = $"🔄 تلاش {attempt} برای اتصال مجدد... ({delaySec:F0}s)";
                    lblStatus.ForeColor = Color.FromArgb(180, 140, 20);
                    ShowToast("🔄 اتصال مجدد", $"تلاش {attempt} برای اتصال مجدد...", "info", 2000);
                }
                catch { }
            }));

            // FIX 24 + self-repair (NET-006): after the fast attempts the kiosk keeps
            // retrying every 60 s. The operator is told once, with a non-modal notice,
            // because a MessageBox would block the kiosk screen.
            _engine.OnReconnectGaveUp += () => BeginInvoke((Action)(() =>
            {
                ShowToast("🔌 سرور پاسخ نمی‌دهد",
                    "ارتباط با سرور قطع است. کیوسک هر ۶۰ ثانیه دوباره تلاش می‌کند. علت در «عیب‌یابی» ثبت شده است.",
                    "warning", 10000);
            }));

            // Self-repair: every fault the engine records (FMEA catalogue, see FaultCatalog)
            // reaches the status line. Faults marked ShowOnClient also get a toast.
            _engine.OnFault += (rec) => BeginInvoke((Action)(() =>
            {
                try
                {
                    FaultDefinition def = FaultCatalog.Get(rec.Code);
                    if (def.Severity == FaultSeverity.Info) return;
                    lblStatus.Text = "⚠ " + def.Code + ": " + def.Title;
                    lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
                    if (def.ShowOnClient)
                        ShowToast("⚠ " + def.Title, def.Cause + "\n" + def.Action,
                            def.Severity == FaultSeverity.Critical ? "critical" : "warning", 10000);
                }
                catch { }
            }));

            // Self-repair: when the previous run crashed, explain why once. The explanation
            // is shown after the window is on screen, because a modal box at start-up would
            // block the kiosk. The full record stays in diagnostics.log.
            this.Shown += (s, e) =>
            {
                try
                {
                    string pending = FaultJournal.TakePendingReport();
                    if (string.IsNullOrEmpty(pending)) return;
                    if (pending.Length > 360) pending = pending.Substring(0, 360) + "...";
                    ShowToast("⚠ برنامه در اجرای قبلی بسته شد", pending, "critical", 20000);
                }
                catch { }
            };

            _engine.OnLoginResult += (ok, msg, name, bal, pph) => BeginInvoke((Action)(() =>
            {
                if (ok)
                {
                    lblWelcome.Text = $"خوش آمدید، {name}";
                    // ADD-CLIENT-25 — Task 5: large balance display with the
                    // 💰 emoji and thousands separators.
                    lblBalance.Text = $"💰 اعتبار: {bal:N0} تومان";
                    // Round 7: a customer session ends admin mode.
                    ClearAdminMode("customer login");
                    _isLocked = false;
                    _lastSoundMinute = -1; // reset sound tracker
                    _prevRemForTimeEnd = int.MaxValue; // round 10: OnTimeEndMinutes tracker
                    _lastBannerMinute = int.MaxValue; // reset banner tracker (task 3)
                    ShowSessionPanel();
                    // C1: start the billing/timer tick.
                    _sessionTimer?.Start();
                    // ADD-CLIENT-25 — Task 3: log login + start the ticker.
                    try { ActivityLogger.Login(name); } catch { }
                    try { _tickerTimer?.Start(); } catch { }
                    // Request loyalty/tier info from the server so the
                    // lblLoyalty display updates (task 20).
                    try { _engine.RequestTierInfo(); } catch { }

                    // REAPPLY-KIOSK-CHANGES-1 (Part F.9): after a successful
                    // login, show the OnLoginMessage toast + play the
                    // OnLoginSound (only if the operator has configured them).
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(ClientOptions.OnLoginMessage))
                            ShowToast("ورود", ClientOptions.OnLoginMessage, "info", 4000);
                    }
                    catch { }
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(ClientOptions.OnLoginSound))
                            SoundAlert.PlayFile(ClientOptions.OnLoginSound);
                    }
                    catch { }
                }
                else
                {
                    // C3: MessageBox is shown on the UI thread (via BeginInvoke)
                    // so the reader thread is not blocked.
                    MessageBox.Show(DialogOwner(), msg, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                }
            }));

            // ADD-CLIENT-25 — Task 20: loyalty/tier info → update the
            // lblLoyalty display with the current points + tier badge +
            // discount percentage. Tier badge is Bronze/Silver/Gold/Platinum
            // based on the CurrentTier.Name (best-effort).
            _engine.OnTierInfo += (tier) => BeginInvoke((Action)(() =>
            {
                try
                {
                    if (tier != null && tier.CurrentTier != null)
                    {
                        _lastLoyaltyPoints = tier.CurrentPoints; // round 6: points row
                        string badge = GetTierBadge(tier.CurrentTier.Name);
                        string disc = tier.CurrentTier.DiscountPercent > 0
                            ? $" | تخفیف: {tier.CurrentTier.DiscountPercent}%"
                            : "";
                        lblLoyalty.Text = $"🏆 امتیاز شما: {tier.CurrentPoints:N0} | {badge}{disc}";
                    }
                    else
                    {
                        lblLoyalty.Text = "🏆 امتیاز شما: ---";
                    }
                }
                catch { }
            }));

            _engine.OnTimeWarning += (min, msg, crit) => BeginInvoke((Action)(() =>
            {
                // REAPPLY-KIOSK-CHANGES-1 (Part F.10): use the operator-
                // configured OnTimeEndMessage / OnTimeEndSound instead of the
                // server-provided message (the server's text is still the
                // fallback when the operator hasn't configured one).
                string displayMsg = !string.IsNullOrWhiteSpace(ClientOptions.OnTimeEndMessage)
                    ? ClientOptions.OnTimeEndMessage
                    : msg;
                try
                {
                    if (!string.IsNullOrWhiteSpace(ClientOptions.OnTimeEndSound))
                        SoundAlert.PlayFile(ClientOptions.OnTimeEndSound);
                }
                catch { }
                // Medium: wrap in using so the WarningNotification's window
                // handles are deterministically freed.
                using (var w = new WarningNotification(min, displayMsg, crit))
                    ShowKioskDialog(w);
            }));

            _engine.OnTimeExpired += () => BeginInvoke((Action)(() =>
            {
                _sessionTimer?.Stop();
                // ADD-CLIENT-25 — Task 19/3: stop the ticker too.
                try { _tickerTimer?.Stop(); } catch { }
                // CRITICAL: Kill all running games before locking
                try { GameKiller.KillAllGames(); } catch { }
                if (_timeOverlay != null) _timeOverlay.UpdateTime(0);
                // ADD-CLIENT-25 — Task 3: play the expiration sound + show
                // the expiration banner (non-modal, so the MessageBox below
                // doesn't double up).
                try { SoundAlert.PlayExpired(); } catch { } // round 11: time-over sound
                ShowToast("⏰ زمان تمام شد", "نشست شما به پایان رسید", "critical", 8000);
                MessageBox.Show(DialogOwner(), "⏰ اعتبار تمام شده!\nهمه بازی‌ها بسته شدند.", "پایان زمان", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_timeOverlay != null) _timeOverlay.HideOverlay();
                _isLocked = true;
                ShowLoginPanel();
            }));

            _engine.OnForceLogout += (r) => BeginInvoke((Action)(() =>
            {
                _sessionTimer?.Stop();
                MessageBox.Show(DialogOwner(), r, "خروج اجباری", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _isLocked = true;
                ShowLoginPanel();
            }));

            _engine.OnSessionUpdate += (el, cost, rem) => BeginInvoke((Action)(() =>
            {
                timerDisplayControl.UpdateDisplay(el, cost, rem);

                // REAPPLY-KIOSK-CHANGES-1 (Part F.11): update the handyCafe
                // sidebar's four timer rows with live values:
                //   row 0 (Start)     = engine.SessionStart (local HH:MM:SS)
                //   row 1 (Remaining) = FormatMinutes(rem)
                //   row 2 (Used)       = FormatMinutes(elapsed minutes)
                //   row 3 (Cost)       = "{cost:N0} ت"
                try
                {
                    if (_sidebarTimerLabels != null)
                    {
                        // NEW (per request): IP address and price/hour rows.
                        // IP doesn't change during a session, but setting it
                        // on every tick is harmless and simplest — avoids
                        // needing a separate one-time-set code path.
                        if (_sidebarTimerLabels[0] != null)
                        {
                            try { _sidebarTimerLabels[0].Text = LocalNetworkInfo.GetLocalIp(); }
                            catch { _sidebarTimerLabels[0].Text = "--"; }
                        }
                        if (_sidebarTimerLabels[1] != null)
                        {
                            _sidebarTimerLabels[1].Text = $"{_engine.PricePerHour:N0} ت";
                        }
                        if (_sidebarTimerLabels[2] != null)
                        {
                            DateTime? ss = _engine?.SessionStart;
                            _sidebarTimerLabels[2].Text = ss.HasValue
                                ? ss.Value.ToLocalTime().ToString("HH:mm:ss")
                                : "--:--:--";
                        }
                        if (_sidebarTimerLabels[3] != null)
                        {
                            _sidebarTimerLabels[3].Text = rem.HasValue
                                ? FormatMinutes(rem.Value)
                                : "--:--:--";
                        }
                        if (_sidebarTimerLabels[4] != null)
                        {
                            int elapsedMin = (int)el.TotalMinutes;
                            _sidebarTimerLabels[4].Text = FormatMinutes(elapsedMin);
                        }
                        // Round 6: balance (as the engine knows it: at login and
                        // after each credit) and the last loyalty points.
                        if (_sidebarTimerLabels.Length > 7)
                        {
                            if (_sidebarTimerLabels[6] != null)
                                _sidebarTimerLabels[6].Text = $"{_engine.Balance:N0} ت";
                            if (_sidebarTimerLabels[7] != null)
                                _sidebarTimerLabels[7].Text = _lastLoyaltyPoints >= 0 ? _lastLoyaltyPoints.ToString("N0") : "---";
                        }
                        if (_sidebarTimerLabels[5] != null)
                        {
                            _sidebarTimerLabels[5].Text = $"{cost:N0} ت";
                        }
                    }
                }
                catch { }

                // REAPPLY-KIOSK-CHANGES-1 (Part F.11): fire the
                // OnTimeEndMinutes warning when the remaining minutes cross
                // the operator-configured threshold. We use the same
                // threshold-crossing pattern as the 5/1/0 banners above so
                // the warning only fires once per threshold crossing (not on
                // every tick inside the band).
                bool customWarnFired = false; // round 11: the operator's own warning fired this tick
                try
                {
                    // Round 10: own crossing check. It used _lastSoundMinute, which only
                    // moves at 10, 5 and 2 minutes, so values other than 2 and 5 showed the
                    // warning every second for minutes, or never.
                    int prevRem = _prevRemForTimeEnd;
                    if (rem.HasValue) _prevRemForTimeEnd = rem.Value;
                    if (rem.HasValue && ClientOptions.OnTimeEndMinutes > 0)
                    {
                        int threshold = ClientOptions.OnTimeEndMinutes;
                        int curMin = rem.Value;
                        if (curMin <= threshold && prevRem > threshold)
                        {
                            // Operator-configured message + sound (fall back to
                            // a generic warning if the operator didn't set one).
                            string msg = !string.IsNullOrWhiteSpace(ClientOptions.OnTimeEndMessage)
                                ? ClientOptions.OnTimeEndMessage
                                : $"⏱️ {threshold} دقیقه دیگر زمان دارید";
                            ShowToast("⏱️ پایان زمان نزدیک است", msg, "warning", 5000);
                            customWarnFired = true;
                            try
                            {
                                if (!string.IsNullOrWhiteSpace(ClientOptions.OnTimeEndSound))
                                    SoundAlert.PlayFile(ClientOptions.OnTimeEndSound);
                                else if (!SoundAlert.PlayBuiltIn(threshold <= 1 ? SoundAlert.Warn1Sound : threshold <= 5 ? SoundAlert.Warn5Sound : SoundAlert.Warn10Sound))
                                    System.Media.SystemSounds.Asterisk.Play();
                            }
                            catch { }
                        }
                    }
                }
                catch { }

                // ADD-CLIENT-25 — Task 25: also update the secondary timer form
                // (multi-monitor) so the customer sees the timer on the
                // second screen.
                try { _secondaryTimer?.UpdateDisplay(el, cost, rem, _engine.Balance); } catch { }

                // Time-warning overlay + sound alerts
                if (_timeOverlay != null && rem.HasValue)
                {
                    int min = rem.Value;
                    _timeOverlay.UpdateTime(min);
                    if (min <= 10) _timeOverlay.ShowOverlay();

                    // Round 11: the sounds moved into the threshold-crossing checks below.
                    // The old exact-minute check (min == 10/5/2) missed a threshold when
                    // the minute jumped over it, and played over the banner sound (two
                    // PlaySound calls at once cut each other off). DND mode still
                    // suppresses the 10/5/1-minute sounds but NOT the visual overlay.
                    bool soundOk = !_dndMode && !customWarnFired;
                    if (min <= 10 && min > 5 && _lastSoundMinute != 10)
                    {
                        if (soundOk) SoundAlert.PlayInfo();
                        _lastSoundMinute = 10;
                    }

                    // ADD-CLIENT-25 — Task 3: banner overlay shown at 5min,
                    // 1min, and 0min. Uses ToastBanner (non-modal, doesn't
                    // block the running game). Each threshold only fires once
                    // per session crossing (tracked by _lastBannerMinute).
                    // Sound: SystemSounds (no external files).
                    //
                    // FIX (FIX-CLIENT-BUGS B8): the previous logic was
                    //   if (min != _lastBannerMinute) { ... _lastBannerMinute = 5; }
                    // which fired the 5-min banner EVERY minute from min=5
                    // down to min=2 (4 banners, all mislabeled "5 minutes")
                    // because each new `min` value (4, 3, 2) != the stored 5.
                    // Replaced with threshold-crossing checks: a banner only
                    // fires when min CROSSES DOWN INTO the band, not on every
                    // tick inside it.
                    if (min <= 0 && _lastBannerMinute > 0)
                    {
                        try { SoundAlert.PlayExpired(); } catch { } // time over: plays even in DND
                        ShowToast("⏰ زمان تمام شد", "نشست شما به پایان رسید", "critical", 8000);
                        _lastBannerMinute = 0;
                    }
                    else if (min <= 1 && _lastBannerMinute > 1)
                    {
                        if (soundOk) { try { SoundAlert.PlayUrgent(); } catch { } }
                        if (!customWarnFired) ShowToast("⚠️ ۱ دقیقه!", "زمان شما رو به اتمام است — شارژ کنید", "critical", 6000);
                        _lastBannerMinute = 1;
                    }
                    else if (min <= 5 && _lastBannerMinute > 5)
                    {
                        // Round 11: with the default "On Last Minutes" = 5 the operator's
                        // own warning already fired this tick, so this one stays quiet
                        // (it used to show a second toast at the same moment).
                        if (soundOk) { try { SoundAlert.PlayWarning(); } catch { } }
                        if (!customWarnFired) ShowToast("⏱️ ۵ دقیقه زمان دارید", "لطفاً برای شارژ اقدام کنید", "warning", 5000);
                        _lastBannerMinute = 5;
                    }
                }
            }));

            // Round 11: a short notice when the operator takes over mouse and keyboard.
            _engine.OnRemoteControlActive += () =>
            {
                try
                {
                    if (IsDisposed || !IsHandleCreated) return;
                    BeginInvoke((Action)(() => ShowToast("🖱️ کمک از راه دور", "اپراتور در حال استفاده از موس و کیبورد این سیستم است", "info", 4000)));
                }
                catch { }
            };

            _engine.OnServerMessage += (t, b, l) => BeginInvoke((Action)(() =>
            {
                // Self-repair: a message that the server repeats on every reconnect attempt
                // (for example a refused station) is shown once as a modal box and then as a
                // toast, instead of a queue of modal boxes. The text itself is not changed.
                if (IsRepeatedServerMessage(t, b))
                {
                    ShowToast(t, b, l == "error" ? "critical" : "warning", 8000);
                    return;
                }
                MessageBox.Show(DialogOwner(), b, t, MessageBoxButtons.OK,
                    l == "error" ? MessageBoxIcon.Error :
                    l == "warning" ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
            }));

            // Top-up response — show a toast even if the user isn't on the topup panel
            _engine.OnTopupResponse += (resp) => BeginInvoke((Action)(() =>
            {
                try { ActivityLogger.TopupResponse(resp.Approved, resp.Amount, resp.Message); } catch { }
                if (resp.Approved)
                {
                    ShowToast("💳 شارژ سریع", $"✅ تأیید شد! {resp.Amount:N0} تومان اضافه شد", "info", 5000);
                    MessageBox.Show(DialogOwner(), $"✅ شارژ تأیید شد!\n{resp.Amount:N0} تومان به اعتبار شما اضافه شد.", "شارژ سریع", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show(DialogOwner(), $"❌ درخواست شارژ رد شد:\n{resp.Message}", "شارژ سریع", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }));

            // Credit added by operator — update balance display + show notification
            _engine.OnCreditAdded += (ac) => BeginInvoke((Action)(() =>
            {
                // FIX C3: silently skip the MessageBox for 0-amount reconnect
                // syncs (server sends AddCredit with Amount=0, Reason="reconnect-sync"
                // immediately after a reconnect to refresh the cached balance).
                // Without this filter, every reconnect pops a misleading
                // "اعتبار شما افزایش یافت! مبلغ: ۰ تومان" dialog.
                if (ac.Amount == 0 || (ac.Reason ?? "").Contains("reconnect"))
                {
                    // Silent — just update the balance label.
                    lblBalance.Text = $"💰 اعتبار: {ac.NewBalance:N0} تومان";
                    if (_timeOverlay != null && ac.NewBalance > 0) _timeOverlay.HideOverlay();
                    return;
                }
                lblBalance.Text = $"💰 اعتبار: {ac.NewBalance:N0} تومان";
                // ADD-CLIENT-25 — Task 3: reset the banner tracker so a fresh
                // top-up re-triggers the 5-min / 1-min banners next time the
                // time drops below those thresholds (otherwise the user
                // would get no warning on a topped-up session).
                _lastBannerMinute = int.MaxValue;
                // Hide the time-expired overlay if it was showing (credit was added in time!)
                if (_timeOverlay != null && ac.NewBalance > 0) _timeOverlay.HideOverlay();
                // Reset the sound tracker so alerts re-trigger at the new thresholds
                _lastSoundMinute = -1;
                // Show a non-blocking notification
                MessageBox.Show(DialogOwner(), $"✅ اعتبار شما افزایش یافت!\nمبلغ: {ac.Amount:N0} تومان\nموجودی جدید: {ac.NewBalance:N0} تومان\n\nدلیل: {ac.Reason}", "افزایش اعتبار", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }));

            // ConfigSync — receive feature flags from server and show/hide panels
            _engine.OnConfigSync += (cfg) => BeginInvoke((Action)(() =>
            {
                if (cfg.Settings != null)
                {
                    // REAPPLY-KIOSK-CHANGES-1 (Part A): _showTicket is gone —
                    // do not toggle any ticket-related visibility from
                    // ConfigSync anymore.
                    // Round 6: the switches are stored by feature name and applied by
                    // LayoutSessionControls to the right-column item with the same
                    // meaning. Before, they were wired to buttons by their old names:
                    // "chat" hid "+30 min", "loyalty" hid "end session", "settings" hid
                    // the exit button, and so on. "games" has no item any more (the
                    // games menu was removed). Missing key = on, as before.
                    foreach (string featureKey in ColumnFeatureKeys)
                    {
                        string featureFlag;
                        _serverFeatureOn[featureKey] = !cfg.Settings.TryGetValue("feat_" + featureKey, out featureFlag) || featureFlag == "1";
                    }

                    // Phase 14: new feature flags (overridden by low-perf mode — task 24).
                    if (!_lowPerfMode)
                    {
                        _upsEnabled = cfg.Settings.ContainsKey("feat_ups_monitor") ? cfg.Settings["feat_ups_monitor"] == "1" : true;
                        _screensaverEnabled = cfg.Settings.ContainsKey("feat_screensaver") ? cfg.Settings["feat_screensaver"] == "1" : true;
                    }

                    // Start/stop UPS based on flag
                    if (_upsEnabled) UpsMonitor.Start(); else UpsMonitor.Stop();

                    // FIX DEAD-CONFIG-4: apply the operator-configured top
                    // banner text/color to the ticker (used as its default
                    // content; OnAnnouncements below still overrides it
                    // temporarily whenever a new announcement arrives).
                    if (cfg.Settings.TryGetValue("banner_top_text", out var bannerText) && !string.IsNullOrWhiteSpace(bannerText))
                        _tickerText = bannerText;
                    if (cfg.Settings.TryGetValue("banner_color", out var bannerColorHex) && !string.IsNullOrWhiteSpace(bannerColorHex))
                    {
                        try { _tickerColor = Color.FromArgb(int.Parse(bannerColorHex)); } catch { /* keep previous color on bad value */ }
                    }

                    ApplyFeatureVisibility();
                }
            }));

            // ADD-CLIENT-25 — Task 19: announcements update the news ticker
            // AND show a toast when a new one arrives. The ticker text is the
            // latest announcement's title so the customer sees it scrolling
            // at the bottom of the session panel.
            _engine.OnAnnouncements += (ann) => BeginInvoke((Action)(() =>
            {
                try
                {
                    if (ann != null && ann.Announcements != null && ann.Announcements.Count > 0)
                    {
                        var latest = ann.Announcements[0];
                        _tickerText = $"📢 {latest.Title}: {latest.Body}";
                        _tickerOffset = lblTicker.ClientSize.Width;
                        if (latest.Level == "critical")
                            ShowToast($"📢 {latest.Title}", latest.Body, "critical", 8000);
                    }
                }
                catch { }
            }));

            // Food order response
            _engine.OnFoodOrderResponse += (fr) => BeginInvoke((Action)(() =>
            {
                MessageBox.Show(DialogOwner(), fr.Success ? $"✅ سفارش ثبت شد!\nمبلغ: {fr.TotalAmount:N0} تومان" : $"❌ خطا: {fr.Message}", "سفارش غذا", MessageBoxButtons.OK, fr.Success ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }));

            // Pause response
            _engine.OnPauseResponse += (pr) => BeginInvoke((Action)(() =>
            {
                MessageBox.Show(DialogOwner(), pr.Approved ? $"✅ توقف موقت تأیید شد ({pr.Minutes} دقیقه)" : $"❌ رد شد: {pr.Message}", "توقف موقت", MessageBoxButtons.OK, pr.Approved ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            }));

            _engine.OnLocked += () => BeginInvoke((Action)(() =>
            {
                _sessionTimer?.Stop();
                _isLocked = true;
                ShowLoginPanel();
            }));

            // Medium: aligns with the ClientEngine fix — ServerUnlockClient now
            // restores the pre-lock state (InSession), so this handler works.
            _engine.OnUnlocked += () => BeginInvoke((Action)(() =>
            {
                if (_engine.State == ClientState.InSession)
                {
                    _isLocked = false;
                    ShowSessionPanel();
                    _sessionTimer?.Start();
                }
            }));

            // FIX 7: Connect() must NOT run synchronously on the UI thread —
            // it does up to 10s of TCP work and the keyboard hook is dead
            // while the UI thread is blocked (kiosk-escape window). Move it
            // to a background thread; the engine raises events back to the
            // UI thread via BeginInvoke so wiring works regardless.
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try { _engine.Connect(); } catch { }
            });
        }

        private void SetupSessionTimer()
        {
            // ADD-CLIENT-25 — Task 24: in low-perf mode, refresh every 5s
            // instead of every 1s. Cuts idle CPU on weak kiosks / VMs.
            int intervalMs = _lowPerfMode ? 5000 : 1000;
            _sessionTimer = new System.Windows.Forms.Timer { Interval = intervalMs };
            _sessionTimer.Tick += (s, e) =>
            {
                if (_engine != null && _engine.State == ClientState.InSession)
                    _engine.CheckSession(); // raises OnSessionUpdate → BeginInvoke → UI
                // FIX H3: re-install the keyboard hook on the UI thread if the
                // Watchdog's CheckHookHealth flagged it as stale. This MUST run
                // on the UI thread (this timer's Tick handler) because
                // SetWindowsHookEx for WH_KEYBOARD_LL installs the hook on the
                // calling thread and the callback is dispatched through that
                // thread's message pump — the Watchdog's threadpool thread has
                // no message pump, so it can't safely re-install the hook.
                try { SecurityLock.EnsureHookInstalledIfStale(); } catch { }
            };
            // Started on login, stopped on session end.
        }

        /// <summary>
        /// Shows a modal dialog of the kiosk. The dialogs were owned by the kiosk window,
        /// and the desktop button minimizes that window. Windows keeps a dialog hidden
        /// while its owner is minimized, so after that the settings (F3, the offline
        /// maintenance menu) and the food order never appeared, and the desktop was what
        /// the user saw. A modal dialog that cannot be seen also blocks the kiosk's UI
        /// thread. When the kiosk is minimized, the dialog is shown as its own topmost
        /// window in the middle of the screen; otherwise it is shown as before.
        /// </summary>
        private DialogResult ShowKioskDialog(Form dlg)
        {
            bool kioskVisible = this.Visible && this.WindowState != FormWindowState.Minimized;
            if (kioskVisible)
                return dlg.ShowDialog(this);

            dlg.TopMost = true;
            dlg.ShowInTaskbar = true;
            dlg.StartPosition = FormStartPosition.CenterScreen;
            return dlg.ShowDialog();
        }

        /// <summary>
        /// The owner for a message box the kiosk shows: the kiosk while it is visible.
        /// While it is minimized there is no owner, because a message box owned by a
        /// minimized window is hidden and blocks the kiosk's UI thread (see ShowKioskDialog).
        /// </summary>
        private IWin32Window DialogOwner()
        {
            return (this.Visible && this.WindowState != FormWindowState.Minimized) ? (IWin32Window)this : null;
        }

        private void ShowLoginPanel()
        {
            // Round 7: the login screen ends admin mode. Without a customer session
            // the kiosk is locked again.
            if (_adminMode)
            {
                ClearAdminMode("login screen");
                if (_engine == null || _engine.State != ClientState.InSession) _isLocked = true;
            }

            // REAPPLY-KIOSK-CHANGES-1 (Part B.2): restore the kiosk to
            // fullscreen so the login panel fills the screen again (the
            // session panel had shrunk the form to a 280px right column).
            try
            {
                this.WindowState = FormWindowState.Normal;
                this.Bounds = Screen.PrimaryScreen.Bounds;
                this.WindowState = FormWindowState.Maximized;
            }
            catch { }

            pnlLogin.Visible = true;
            pnlLogin.BringToFront();  // ensure login is on top
            pnlSession.Visible = false;
            // FIX SIDEBAR-REMOVE: pnlSidebar is no longer used. Navigation
            // buttons are now integrated into pnlSession as a compact bar.
            pnlSidebar.Visible = false;
            pnlSidebar.Enabled = false;
            // Center the login controls for the current form size.
            CenterLoginControls();

            // BUG FIX ("login only worked once"): clear the previous user's
            // credentials and restore a clean placeholder state, so the
            // second and subsequent logins behave exactly like the first.
            // See ResetLoginFields in KioskForm.Designer.cs for the details.
            ResetLoginFields();
            // Put the caret in the username box, ready for the next customer.
            try { txtUsername.Focus(); } catch { }
        }

        private void ShowSessionPanel()
        {
            // REAPPLY-KIOSK-CHANGES-1 (Part B.1): shrink the form to a
            // 280px-wide column docked to the right side of the primary
            // screen. The dark background + the handyCafe-style sidebar
            // (white panel + blue header + timer + button grid + blue
            // footer) is built by LayoutSessionControls. The rest of the
            // screen shows the desktop / running game.
            try
            {
                this.WindowState = FormWindowState.Normal;
                var wa = Screen.PrimaryScreen.WorkingArea;
                int colW = 280;
                this.Bounds = new Rectangle(wa.Right - colW, wa.Y, colW, wa.Height);
                this.TopMost = true;
            }
            catch { }

            pnlLogin.Visible = false;
            pnlSession.Visible = true;
            // FIX SIDEBAR-REMOVE: pnlSidebar is no longer shown. Navigation
            // buttons are now inside pnlSession (added by LayoutSessionControls).
            pnlSidebar.Visible = false;
            pnlSidebar.Enabled = false;
            // Lay out the right-column session buttons.
            LayoutSessionControls();
        }

        /// <summary>
        /// Centers the login controls (title, username, password, buttons,
        /// status) horizontally on the form. Called on form Resize and on
        /// ShowLoginPanel. This fixes the issue where the controls were at a
        /// fixed x=500 that looked wrong on non-1920px screens.
        /// REAPPLY-KIOSK-CHANGES-1 (Part F.7): honors DisableLoginRequest (a
        /// customer login is refused; the admin login still works). Round 10:
        /// the boxes are no longer pre-filled with admin credentials.
        /// REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket.Location removed.
        /// </summary>
        private void CenterLoginControls()
        {
            if (pnlLogin == null || !pnlLogin.Visible) return;
            try
            {
                int formW = this.ClientSize.Width;
                int formH = this.ClientSize.Height;
                if (formW <= 0) formW = 1280;
                if (formH <= 0) formH = 800;
                int centerX = (formW - 400) / 2;
                if (centerX < 20) centerX = 20;

                int startY = (formH - 480) / 2;
                if (startY < 30) startY = 30;

                lblTitle.Location = new System.Drawing.Point((formW - 500) / 2, startY);
                lblSubtitle.Location = new System.Drawing.Point(centerX, startY + 80);

                // FIX TEXTBOX-VISIBLE: ensure textboxes are visible and properly sized
                txtUsername.Location = new System.Drawing.Point(centerX, startY + 130);
                txtUsername.Size = new System.Drawing.Size(400, 45);
                txtUsername.Visible = true;
                txtUsername.BringToFront();

                txtPassword.Location = new System.Drawing.Point(centerX, startY + 190);
                txtPassword.Size = new System.Drawing.Size(400, 45);
                txtPassword.Visible = true;
                txtPassword.BringToFront();

                btnLogin.Location = new System.Drawing.Point(centerX, startY + 260);
                btnLogin.Visible = true;
                btnLogin.BringToFront();

                // REAPPLY-KIOSK-CHANGES-1 (Part A): btnTicket.Location line
                // removed — the login panel no longer has a ticket button.
                lblStatus.Location = new System.Drawing.Point(centerX, startY + 390);

                // REAPPLY-KIOSK-CHANGES-1 (Part F.7): honor DisableLoginRequest.
                // Round 10: the login boxes are no longer pre-filled from the Options
                // dialog's admin fields. Those fields now set the offline admin login
                // (ClientOptions.SetSuperAdmin); the pre-fill showed a typed password in
                // plain text on the login screen.
                try
                {
                    if (ClientOptions.DisableLoginRequest)
                    {
                        // BUG FIX (root cause, fixed properly this time):
                        // this used to set btnLogin.Enabled = false — but a
                        // disabled Button in WinForms never raises Click AT
                        // ALL, for ANY reason. That meant the offline
                        // super-admin login (which is supposed to ALWAYS
                        // work, specifically so an operator can recover a
                        // misconfigured kiosk) was ALSO silently blocked
                        // whenever this setting was on — defeating the
                        // entire purpose of having an "always works"
                        // emergency path. This is very likely what actually
                        // happened in the reported case: the flag came back
                        // on (from wherever), and it also silently disabled
                        // the exact button meant to fix that.
                        //
                        // Fixed properly: the button now ALWAYS stays
                        // Enabled = true, so it can always be clicked. The
                        // actual "is a normal customer login allowed right
                        // now" check moved into btnLogin_Click itself, AFTER
                        // the super-admin check — so the super-admin path
                        // can never be blocked by this setting again,
                        // automatically, with no file to edit and nothing
                        // to remember.
                        btnLogin.BackColor = Color.FromArgb(120, 120, 130);
                        btnLogin.Text = "▶️ ورود";
                        if (!_disableLoginWarningShown)
                        {
                            _disableLoginWarningShown = true;
                            MessageBox.Show(DialogOwner(),
                                "ورود عادی مشتری در این کلاینت غیرفعال است (تنظیم محلی DisableLoginRequest) — اما ورود مدیر محلی (admin/password) همچنان همیشه کار می‌کند.",
                                "ورود عادی غیرفعال است", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        btnLogin.Enabled = true;
                        // Restore the normal text/color in case a previous
                        // check had set the disabled state.
                        btnLogin.Text = "▶️ ورود";
                        btnLogin.BackColor = Color.FromArgb(38, 166, 154);
                    }
                }
                catch { }
            }
            catch { }
        }

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part B.3): handyCafe-style sidebar
        /// layout. Builds a 280px-wide column on the right side of the
        /// session panel, composed of:
        ///   - a blue header bar (51, 95, 189) at top, 32px tall, with the
        ///     brand label "markazbazi" centered in white,
        ///   - a white timer panel (Dock=Top, 126px tall) with four rows
        ///     (Start / Remaining / Used / Cost). Each row's visibility is
        ///     driven by the matching Hide* setting from ClientOptions.
        ///   - a 2-column button grid (5 rows of 2 = 10 buttons). Light gray
        ///     buttons (225,225,230) with black text. If the button count is
        ///     odd, the last button spans the full column width.
        ///   - a blue footer bar at the bottom (26px tall) with "Version 1.0.0"
        ///     centered in white.
        /// Also applies Disable* settings (DisableCafeteria hides btnNavTopup,
        /// DisableHide hides btnNavHome) and the Hide* timer-row settings.
        /// </summary>
        private void LayoutSessionControls()
        {
            if (pnlSession == null) return;
            // The session panel may not be visible yet (early Resize event),
            // but we still need to lay the controls out so they're ready
            // when it becomes visible. Skip the early-return when the panel
            // is null only.
            try
            {
                int w = pnlSession.ClientSize.Width;
                int h = pnlSession.ClientSize.Height;
                if (w <= 0) w = 280;
                if (h <= 0) h = 600;

                // === Apply Disable* + Hide* settings =========================
                // DisableCafeteria → hide the "➕ اعتبار" (btnNavTopup) button.
                // DisableHide → hide the "🖥️ دسکتاپ" (btnNavHome) button (the
                // operator doesn't want the customer minimizing the kiosk).
                try { btnNavTopup.Visible = !ClientOptions.DisableCafeteria; } catch { }
                try { btnNavHome.Visible = !ClientOptions.DisableHide; } catch { }

                // === Header bar (blue, 32px, Dock=Top) =======================
                if (_sidebarHeader == null)
                {
                    _sidebarHeader = new Panel
                    {
                        Height = 32,
                        Dock = DockStyle.Top,
                        BackColor = Color.FromArgb(51, 95, 189),
                    };
                    var lblBrand = new Label
                    {
                        Text = "markazbazi",
                        Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                        ForeColor = Color.White,
                        Dock = DockStyle.Fill,
                        TextAlign = ContentAlignment.MiddleCenter,
                        BackColor = Color.Transparent,
                    };
                    _sidebarHeader.Controls.Add(lblBrand);
                    _sidebarBrand = lblBrand;
                    pnlSession.Controls.Add(_sidebarHeader);
                }
                _sidebarHeader.BringToFront();
                // Round 7: admin mode has its own header text and colour.
                _sidebarHeader.BackColor = _adminMode ? AdminBarColor : SidebarBarColor;
                if (_sidebarBrand != null) _sidebarBrand.Text = _adminMode ? "🛠️ حالت مدیر" : "markazbazi";

                // === Timer panel (white, Dock=Top, 186px tall) ===============
                // BUG FIX (per request: restore the right-column info that
                // used to be requested — IP address and price/hour were
                // never part of this panel at all, only Start/Remaining/
                // Used/Cost were). Extended from 4 rows to 6: IP address and
                // price/hour added, in the same style/pattern as the
                // existing four rows.
                // Six rows: IP / Price-per-hour / Start / Remaining / Used / Cost.
                if (_sidebarTimer == null)
                {
                    _sidebarTimer = new Panel
                    {
                        Height = 186,
                        Dock = DockStyle.Top,
                        BackColor = Color.White,
                    };
                    _sidebarTimerLabels = new Label[8];
                    _sidebarTimerRows = new Panel[8];
                    string[] rowLabels = { "آدرس IP", "قیمت هر ساعت", "شروع", "باقی‌مانده", "استفاده شده", "هزینه" };
                    // Round 6: two more rows, balance and loyalty points.
                    System.Array.Resize(ref rowLabels, 8);
                    rowLabels[6] = "اعتبار";
                    rowLabels[7] = "امتیاز";
                    for (int i = 0; i < 8; i++)
                    {
                        int rowY = i * 30 + 4;
                        var row = new Panel
                        {
                            Location = new Point(4, rowY),
                            Size = new Size(w - 8, 28),
                            BackColor = Color.White,
                        };
                        var lblCap = new Label
                        {
                            Text = rowLabels[i],
                            Font = new Font("Segoe UI", 9F),
                            ForeColor = Color.FromArgb(40, 40, 40),
                            Dock = DockStyle.Left,
                            AutoSize = false,
                            Width = 110,
                            TextAlign = ContentAlignment.MiddleLeft,
                        };
                        var lblVal = new Label
                        {
                            Text = "---",
                            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                            ForeColor = Color.FromArgb(51, 95, 189),
                            Dock = DockStyle.Fill,
                            AutoSize = false,
                            TextAlign = ContentAlignment.MiddleRight,
                        };
                        row.Controls.Add(lblVal);
                        row.Controls.Add(lblCap);
                        _sidebarTimerRows[i] = row;
                        _sidebarTimerLabels[i] = lblVal;
                        _sidebarTimer.Controls.Add(row);
                    }
                    pnlSession.Controls.Add(_sidebarTimer);
                }
                // Apply Hide* settings — each row's visibility is the inverse
                // of the matching Hide* flag. Indices shifted by 2 now that
                // IP (0) and price/hour (1) are new rows before the
                // original four (Start/Remaining/Used/Cost are now 2-5).
                // Round 6: the IP and price rows can be switched off too, and rows
                // 6 (balance) and 7 (loyalty points) were added. The rows that are
                // on are stacked from the top and the panel height follows them.
                bool[] rowShown =
                {
                    !ClientOptions.HideIpAddress,
                    !ClientOptions.HidePricePerHour,
                    !ClientOptions.HideStartTime,
                    !ClientOptions.HideRemainingTime,
                    !ClientOptions.HideUsedTime,
                    !ClientOptions.HideCost,
                    !ClientOptions.HideBalance,
                    !ClientOptions.HideLoyaltyPoints && ServerAllows("loyalty"),
                };
                // Round 7: admin mode shows only the IP row (the others are session
                // data). The IP is set here because no session updates it.
                if (_adminMode)
                {
                    rowShown = new bool[] { true, false, false, false, false, false, false, false };
                    try { _sidebarTimerLabels[0].Text = LocalNetworkInfo.GetLocalIp(); } catch { }
                }
                int rowsShown = 0;
                for (int i = 0; i < _sidebarTimerRows.Length; i++)
                {
                    bool showRow = i < rowShown.Length && rowShown[i];
                    _sidebarTimerRows[i].Visible = showRow;
                    if (showRow)
                    {
                        _sidebarTimerRows[i].Top = rowsShown * 30 + 4;
                        rowsShown++;
                    }
                }
                _sidebarTimer.Height = rowsShown * 30 + 8;
                _sidebarTimer.Visible = rowsShown > 0;
                _sidebarTimer.BringToFront();

                // === Button grid (2 columns) =================================
                // Round 6: up to 17 buttons. Each one can be switched off in the
                // Options dialog (tab "ستون راست"); a button whose feature is
                // switched off in the server's feature list is hidden as well
                // (ServerAllows). Only visible buttons are placed, so the grid
                // closes up; with an odd count the last button spans both
                // columns. The grid starts below the info panel, and the cell
                // height shrinks (40 down to 28 px) when the column is too short.
                EnsureColumnFeatureButtons();
                var defs = new (Button btn, string text, bool show)[]
                {
                    (btnNavHome,           "🖥️ دسکتاپ",     !ClientOptions.DisableHide),
                    (btnNavGames,          "⏱️ +۱۰ دقیقه",    !ClientOptions.HideBtnAdd10),
                    (btnNavChat,           "⏱️ +۳۰ دقیقه",     !ClientOptions.HideBtnAdd30),
                    (btnNavAnnounce,       "⏱️ +۶۰ دقیقه", !ClientOptions.HideBtnAdd60),
                    (btnNavLoyalty,        "⏹️ پایان نشست",  !ClientOptions.HideBtnEndSession),
                    (btnNavProfile,        "📷 اسکرین‌شات",  !ClientOptions.HideBtnScreenshot),
                    (btnNavStats,          "💬 پیام",    !ClientOptions.HideBtnMessage),
                    (btnNavTopup,          "➕ اعتبار",    !ClientOptions.DisableCafeteria && ServerAllows("topup")),
                    (_btnColChat,          null,     !ClientOptions.HideBtnChat && ServerAllows("chat")),
                    (_btnColAnnouncements, null,     !ClientOptions.HideBtnAnnouncements && ServerAllows("announcements")),
                    (_btnColLoyalty,       null,     !ClientOptions.HideBtnLoyalty && ServerAllows("loyalty")),
                    (_btnColProfile,       null,     !ClientOptions.HideBtnProfile && ServerAllows("profile")),
                    (_btnColStats,         null,     !ClientOptions.HideBtnStats && ServerAllows("stats")),
                    (_btnColFood,          null,     !ClientOptions.HideBtnFood && ServerAllows("food")),
                    (_btnColMusic,         null,     !ClientOptions.HideBtnMusic && ServerAllows("ambient_music") && !_lowPerfMode),
                    (btnNavOptions,        "⚙️ تنظیمات",  !ClientOptions.HideBtnOptions && ServerAllows("settings")),
                    (btnNavSettings,       "⏻ خروج",     !ClientOptions.HideBtnExit),
                };
                var shownButtons = new System.Collections.Generic.List<Button>();
                foreach (var d in defs)
                {
                    if (d.btn == null) continue;
                    if (d.text != null) d.btn.Text = d.text;
                    // Round 7: admin mode hides every customer button.
                    bool showBtn = d.show && !_adminMode;
                    d.btn.Visible = showBtn;
                    if (showBtn) shownButtons.Add(d.btn);
                }

                // rowsShown, not _sidebarTimer.Visible: Visible reads false while
                // pnlSession itself is hidden (layout before login).
                int gridStartY = 32 + (rowsShown > 0 ? _sidebarTimer.Height : 0) + 8;
                int gridCols = 2;
                int cellGap = 6;
                int cellW = (w - 8 - cellGap) / gridCols; // 8px outer padding + 6px gap
                int gridRows = (shownButtons.Count + gridCols - 1) / gridCols;
                int cellH = 40;
                if (gridRows > 0)
                {
                    int avail = h - gridStartY - 26 - 6; // 26 = footer bar
                    int fit = (avail - (gridRows - 1) * cellGap) / gridRows;
                    if (fit < cellH) cellH = Math.Max(28, fit);
                }

                for (int k = 0; k < shownButtons.Count; k++)
                {
                    Button btn = shownButtons[k];
                    int r = k / gridCols;
                    int c = k % gridCols;
                    bool spanRow = k == shownButtons.Count - 1 && shownButtons.Count % gridCols == 1;
                    btn.Font = ColumnButtonFont;
                    btn.ForeColor = Color.Black;
                    btn.BackColor = Color.FromArgb(225, 225, 230);
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(210, 210, 215);
                    btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(195, 195, 200);
                    btn.TextAlign = ContentAlignment.MiddleCenter;
                    int x = 4 + c * (cellW + cellGap);
                    int y = gridStartY + r * (cellH + cellGap);
                    btn.Location = new Point(x, y);
                    btn.Size = new Size(spanRow ? w - 8 : cellW, cellH);
                    btn.BringToFront();
                }

                // Round 7: the admin controls (hidden outside admin mode).
                LayoutAdminControls(w, gridStartY);

                // === Footer bar (blue, 26px, Dock=Bottom) ===================
                if (_sidebarFooter == null)
                {
                    _sidebarFooter = new Panel
                    {
                        Height = 26,
                        Dock = DockStyle.Bottom,
                        BackColor = Color.FromArgb(51, 95, 189),
                    };
                    var lblVer = new Label
                    {
                        Text = "Version 1.0.0",
                        Font = new Font("Segoe UI", 8F),
                        ForeColor = Color.White,
                        Dock = DockStyle.Fill,
                        TextAlign = ContentAlignment.MiddleCenter,
                        BackColor = Color.Transparent,
                    };
                    _sidebarFooter.Controls.Add(lblVer);
                    pnlSession.Controls.Add(_sidebarFooter);
                }
                _sidebarFooter.BringToFront();
                _sidebarFooter.BackColor = _adminMode ? AdminBarColor : SidebarBarColor;

                // === Hide the old btnLogout (Part B.3) ======================
                // btnLogout is now superseded by btnNavSettings ("⏻ خروج"),
                // wired to btnLogout_Click in KioskForm.Designer.cs. Hide the
                // duplicate button so it doesn't overlap the grid.
                try { btnLogout.Visible = false; btnLogout.Enabled = false; } catch { }
            }
            catch { }
        }

        /// <summary>
        /// Round 6: true unless the server's feature list switched this feature off
        /// (ConfigSync, feat_&lt;key&gt; other than "1"). A null key means the item has
        /// no server switch.
        /// </summary>
        private bool ServerAllows(string featureKey)
        {
            if (featureKey == null) return true;
            bool on;
            return !_serverFeatureOn.TryGetValue(featureKey, out on) || on;
        }

        /// <summary>
        /// Round 6: creates the right-column buttons for chat, announcements,
        /// loyalty, profile, stats, food order and music once, inside pnlSession.
        /// LayoutSessionControls places and shows them.
        /// </summary>
        private void EnsureColumnFeatureButtons()
        {
            if (_btnColChat != null) return;
            _btnColChat = MkColumnButton("🗨️ چت", (s, e) =>
                ShowFeatureWindow("چت با اپراتور", new ChatPanel(_engine)));
            _btnColAnnouncements = MkColumnButton("📢 اطلاعیه‌ها", (s, e) =>
                ShowFeatureWindow("اطلاعیه‌ها", new AnnouncementsPanel(_engine)));
            _btnColLoyalty = MkColumnButton("🏆 امتیازات", (s, e) =>
                ShowFeatureWindow("امتیازات وفاداری", new LoyaltyPanel(_engine, _engine?.Username ?? "کاربر")));
            _btnColProfile = MkColumnButton("👤 پروفایل", (s, e) =>
                ShowFeatureWindow("پروفایل کاربر", new ProfilePanel(_engine, _engine?.Username ?? "کاربر", _engine?.Balance ?? 0m)));
            _btnColStats = MkColumnButton("📊 آمار", (s, e) =>
                ShowFeatureWindow("آمار شخصی", new StatsPanel(_engine?.Username ?? "کاربر", _engine?.Balance ?? 0m)));
            _btnColFood = MkColumnButton("🍔 سفارش غذا", (s, e) =>
            {
                EventHandler h = _foodOrderHandler;
                if (h != null) h(s, e);
            });
            _btnColMusic = MkColumnButton("🎵 موسیقی", (s, e) =>
            {
                EventHandler h = _musicToggleHandler;
                if (h != null) h(s, e);
                // The toggle writes play/stop into btnMusic's text; the column
                // button shows the same state.
                try { _btnColMusic.Text = btnMusic.Text; } catch { }
            });
        }

        private Button MkColumnButton(string text, EventHandler onClick)
        {
            var b = new Button { Text = text, Visible = false };
            b.Click += onClick;
            pnlSession.Controls.Add(b);
            return b;
        }

        /// <summary>
        /// Round 6: opens a right-column feature (chat, announcements, ...) in its
        /// own window. The panels were laid out for the old wide session screen
        /// (about 860 x 620 px); SwapToPanel gave them about 50 px of the 280 px
        /// column. The window takes the panel's size, or the screen minus a margin
        /// with scroll bars on a small screen. Closing it disposes the panel, which
        /// unsubscribes the panel's engine events.
        /// </summary>
        private void ShowFeatureWindow(string title, UserControl panel)
        {
            try
            {
                Rectangle wa = Screen.PrimaryScreen.WorkingArea;
                using (var host = new Form
                {
                    Text = title,
                    StartPosition = FormStartPosition.CenterScreen,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    MaximizeBox = false,
                    MinimizeBox = false,
                    ShowInTaskbar = false,
                    RightToLeft = RightToLeft.Yes,
                    BackColor = Color.FromArgb(240, 240, 240),
                    ClientSize = new Size(Math.Min(880, wa.Width - 40), Math.Min(630, wa.Height - 40)),
                })
                {
                    panel.Dock = DockStyle.Fill;
                    panel.AutoScroll = true;
                    host.Controls.Add(panel);
                    ShowKioskDialog(host);
                }
            }
            catch (Exception ex)
            {
                try { panel.Dispose(); } catch { }
                try { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); } catch { }
            }
        }

        /// <summary>
        /// Round 7: called after a successful offline admin login on the login screen,
        /// instead of the two-option maintenance dialog. The kiosk shows the right
        /// column in admin mode, with the desktop beside it. The typed credentials are
        /// cleared from the login boxes.
        /// </summary>
        /// <summary>Round 14: a local event for the server's activity journal.</summary>
        private void ReportKioskEvent(string kind, string text)
        {
            try { CrashReporter.ReportEvent(kind, text); } catch { }
            try { _engine?.FlushReportsNow(); } catch { }
        }

        private void EnterAdminMode()
        {
            ReportKioskEvent("station", "ورود به حالت مدیر روی خود کیوسک"); // round 14
            _adminMode = true;
            _isLocked = false;
            // The watchdog stops pulling focus back from cmd, regedit and the like.
            Watchdog.SuspendFocusSteal = true;
            try { ResetLoginFields(); } catch { }
            try { ActivityLogger.Log("SuperAdmin", "Admin mode started (offline admin login)."); } catch { }
            ShowSessionPanel();
            if (_adminIdleTimer == null)
            {
                _adminIdleTimer = new System.Windows.Forms.Timer { Interval = 15000 };
                _adminIdleTimer.Tick += (s, e) => OnAdminIdleTick();
            }
            _adminIdleTimer.Stop();
            _adminIdleTimer.Start();
        }

        /// <summary>
        /// Round 7: the lock button and the idle lock. Back to the customer column when
        /// a customer session is running (admin mode reached through F1 during a
        /// session), otherwise to the locked login screen.
        /// </summary>
        private void LeaveAdminMode(string reason)
        {
            if (!_adminMode) return;
            ReportKioskEvent("station", "خروج از حالت مدیر روی کیوسک" + (string.IsNullOrEmpty(reason) ? "" : " (" + reason + ")")); // round 14
            bool inSession = _engine != null && _engine.State == ClientState.InSession;
            ClearAdminMode(reason);
            if (inSession)
            {
                _isLocked = false;
                ShowSessionPanel();
            }
            else
            {
                _isLocked = true;
                ShowLoginPanel();
            }
        }

        /// <summary>
        /// Round 7: turns admin mode off: stops the idle check, closes the settings
        /// dialog if it is open (unsaved changes are dropped) and writes the activity
        /// log. Does not change the screen or _isLocked; the callers do.
        /// </summary>
        private void ClearAdminMode(string reason)
        {
            if (!_adminMode) return;
            _adminMode = false;
            Watchdog.SuspendFocusSteal = false;
            try { _adminIdleTimer?.Stop(); } catch { }
            try { _openSettingsDialog?.Close(); } catch { }
            try { ActivityLogger.Log("SuperAdmin", "Admin mode ended: " + reason + "."); } catch { }
        }

        /// <summary>
        /// Round 7: idle check for admin mode, every 15 s. After
        /// ClientOptions.AdminIdleLockMinutes without keyboard or mouse input anywhere
        /// on the PC (SystemMonitor.GetIdleSeconds), admin mode ends. An open settings
        /// dialog is closed first and the lock follows on the next check, once the
        /// dialog has gone.
        /// </summary>
        private void OnAdminIdleTick()
        {
            if (!_adminMode)
            {
                try { _adminIdleTimer?.Stop(); } catch { }
                return;
            }
            int minutes = ClientOptions.AdminIdleLockMinutes;
            if (minutes <= 0) return;
            if (SystemMonitor.GetIdleSeconds() < minutes * 60) return;
            Form open = _openSettingsDialog;
            if (open != null)
            {
                try { open.Close(); } catch { }
                return;
            }
            LeaveAdminMode("no input for " + minutes + " min");
        }

        /// <summary>
        /// Round 7: creates the admin column's controls once, inside pnlSession.
        /// LayoutAdminControls places and shows them in admin mode only.
        /// </summary>
        private void EnsureAdminControls()
        {
            if (_btnAdminSettings != null) return;
            _adminStatus = new Label
            {
                AutoSize = false,
                Visible = false,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 8.5F),
                TextAlign = ContentAlignment.MiddleCenter,
            };
            pnlSession.Controls.Add(_adminStatus);
            _adminHint = new Label
            {
                AutoSize = false,
                Visible = false,
                BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(90, 90, 90),
                Font = new Font("Segoe UI", 8F),
                TextAlign = ContentAlignment.TopCenter,
            };
            pnlSession.Controls.Add(_adminHint);
            _btnAdminSettings = MkAdminButton("⚙️ تنظیمات کلاینت",
                Color.FromArgb(38, 166, 154), Color.FromArgb(8, 30, 34), (s, e) => OpenClientOptions(true));
            _btnAdminDesktop = MkAdminButton("🖥️ دسکتاپ (کوچک کردن ستون)",
                Color.FromArgb(225, 225, 230), Color.Black, (s, e) => MinimizeAdminColumn());
            _btnAdminLock = MkAdminButton("🔒 قفل و بازگشت به صفحه ورود",
                SidebarBarColor, Color.White, (s, e) => LeaveAdminMode("lock button"));
            _btnAdminExit = MkAdminButton("🚪 خروج کامل از کیوسک",
                Color.FromArgb(243, 139, 168), Color.FromArgb(30, 30, 46), (s, e) => ExitKioskFromAdmin());
            // Round 15: step-by-step test of the connection to the server.
            _btnAdminDoctor = MkAdminButton("🩺 تست اتصال به سرور",
                Color.FromArgb(137, 180, 250), Color.FromArgb(10, 20, 50), (s, e) => RunConnectionDoctor());
            // The status line repeats the login screen's connection status.
            lblStatus.TextChanged += (s, e) => UpdateAdminStatus();
        }

        /// <summary>Round 15: runs ConnectionDoctor in the background and shows the result.</summary>
        private void RunConnectionDoctor()
        {
            if (_btnAdminDoctor != null) { _btnAdminDoctor.Enabled = false; _btnAdminDoctor.Text = "⏳ در حال تست..."; }
            string host = _serverHost, status = "";
            int port = _serverPort;
            bool tls = ConnectionSettings.UseTls;
            try { status = lblStatus.Text; } catch { }
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                string result;
                try { result = ConnectionDoctor.Run(host, port, tls, status); }
                catch (Exception ex) { result = "تست انجام نشد: " + ex.Message; }
                try
                {
                    BeginInvoke((Action)(() =>
                    {
                        if (_btnAdminDoctor != null) { _btnAdminDoctor.Enabled = true; _btnAdminDoctor.Text = "🩺 تست اتصال به سرور"; }
                        try { using (var dlg = ConnectionDoctor.MakeDialog(result)) ShowKioskDialog(dlg); } catch { }
                    }));
                }
                catch { }
            });
        }

        private Button MkAdminButton(string text, Color back, Color fore, EventHandler onClick)
        {
            var b = new Button
            {
                Text = text,
                Visible = false,
                BackColor = back,
                ForeColor = fore,
                Font = AdminButtonFont,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleCenter,
            };
            b.FlatAppearance.BorderSize = 0;
            b.Click += onClick;
            pnlSession.Controls.Add(b);
            return b;
        }

        /// <summary>
        /// Round 7: places the admin controls from <paramref name="top"/> down (status
        /// line, then one full-width button per row, then the idle-lock note), or hides
        /// them outside admin mode.
        /// </summary>
        private void LayoutAdminControls(int w, int top)
        {
            EnsureAdminControls();
            Control[] items = { _adminStatus, _btnAdminSettings, _btnAdminDoctor, _btnAdminDesktop, _btnAdminLock, _btnAdminExit, _adminHint };
            if (!_adminMode)
            {
                foreach (Control c in items) c.Visible = false;
                return;
            }
            UpdateAdminStatus();
            int y = top;
            _adminStatus.SetBounds(4, y, w - 8, 44);
            y += 44 + 8;
            foreach (Button b in new[] { _btnAdminSettings, _btnAdminDoctor, _btnAdminDesktop, _btnAdminLock, _btnAdminExit })
            {
                b.SetBounds(4, y, w - 8, 42);
                y += 42 + 6;
            }
            int minutes = ClientOptions.AdminIdleLockMinutes;
            _adminHint.Text = minutes > 0
                ? "بعد از " + ToPersianDigits(minutes) + " دقیقه بدون کار با موس یا کیبورد، کیوسک خودش قفل خواهد شد."
                : "";
            _adminHint.SetBounds(4, y + 2, w - 8, 40);
            foreach (Control c in items)
            {
                c.Visible = true;
                c.BringToFront();
            }
            _adminHint.Visible = minutes > 0;
        }

        private void UpdateAdminStatus()
        {
            if (_adminStatus == null) return;
            try { _adminStatus.Text = lblStatus.Text; } catch { }
        }

        /// <summary>
        /// Round 7: the admin column's desktop button. Minimizes the kiosk; its taskbar
        /// icon brings the column back (the Resize handler restores TopMost).
        /// </summary>
        private void MinimizeAdminColumn()
        {
            try
            {
                this.TopMost = false;
                this.WindowState = FormWindowState.Minimized;
            }
            catch { }
        }

        private static string ToPersianDigits(int n)
        {
            var sb = new System.Text.StringBuilder();
            foreach (char ch in n.ToString(CultureInfo.InvariantCulture))
                sb.Append(ch >= '0' && ch <= '9' ? (char)('\u06F0' + (ch - '0')) : ch);
            return sb.ToString();
        }

        /// <summary>
        /// Round 7: the column's settings button and F3. In admin mode the settings open
        /// directly; otherwise the admin username and password are asked first, with the
        /// same offline check as the login screen (ClientOptions.VerifySuperAdmin).
        /// Before, both opened the settings without any password, also for a customer.
        /// </summary>
        private void OpenClientOptionsChecked()
        {
            if (!_adminMode && !AskAdminCredentials()) return;
            OpenClientOptions();
        }

        /// <summary>
        /// Round 7: small dialog for the admin username and password. True only when
        /// they pass ClientOptions.VerifySuperAdmin.
        /// </summary>
        private bool AskAdminCredentials()
        {
            try
            {
                using (var dlg = new Form
                {
                    Text = "ورود مدیر",
                    StartPosition = FormStartPosition.CenterScreen,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    MaximizeBox = false,
                    MinimizeBox = false,
                    ShowInTaskbar = false,
                    RightToLeft = RightToLeft.Yes,
                    BackColor = Color.FromArgb(240, 240, 240),
                    ClientSize = new Size(360, 180),
                })
                using (var font = new Font("Segoe UI", 10F))
                {
                    var lblInfo = new Label
                    {
                        Text = "برای باز کردن تنظیمات کلاینت، نام کاربری و رمز مدیر را وارد کنید.",
                        AutoSize = false,
                        Location = new Point(12, 10),
                        Size = new Size(336, 40),
                        TextAlign = ContentAlignment.MiddleCenter,
                        Font = font,
                    };
                    var lblUser = new Label { Text = "نام کاربری:", AutoSize = true, Font = font };
                    var lblPass = new Label { Text = "رمز عبور:", AutoSize = true, Font = font };
                    var txtUser = new TextBox { Location = new Point(12, 60), Size = new Size(230, 26), Font = font, RightToLeft = RightToLeft.No };
                    var txtPass = new TextBox { Location = new Point(12, 96), Size = new Size(230, 26), Font = font, RightToLeft = RightToLeft.No, UseSystemPasswordChar = true };
                    var btnOk = new Button { Text = "ورود", DialogResult = DialogResult.OK, Location = new Point(248, 136), Size = new Size(100, 32), Font = font };
                    var btnCancel = new Button { Text = "انصراف", DialogResult = DialogResult.Cancel, Location = new Point(140, 136), Size = new Size(100, 32), Font = font };
                    dlg.Controls.AddRange(new Control[] { lblInfo, lblUser, lblPass, txtUser, txtPass, btnOk, btnCancel });
                    // The dialog is not mirrored, so the labels are placed at the right
                    // edge by hand, beside their boxes.
                    lblUser.Location = new Point(348 - lblUser.PreferredWidth, 63);
                    lblPass.Location = new Point(348 - lblPass.PreferredWidth, 99);
                    dlg.AcceptButton = btnOk;
                    dlg.CancelButton = btnCancel;
                    dlg.Shown += (s, e) => txtUser.Focus();
                    if (ShowKioskDialog(dlg) != DialogResult.OK) return false;
                    if (ClientOptions.VerifySuperAdmin(txtUser.Text, txtPass.Text)) return true;
                    MessageBox.Show(DialogOwner(), "نام کاربری یا رمز مدیر درست نیست.", "ورود مدیر", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            catch (Exception ex)
            {
                try { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); } catch { }
                return false;
            }
        }

        private void btnLogin_Click(object s, EventArgs e)
        {
            // Check if the user actually typed something, or if the textbox
            // still shows the placeholder ("نام کاربری" / "رمز عبور").
            // Without this check, clicking Login without focusing the textboxes
            // first sends the placeholder text as credentials → "wrong password".
            if (KioskForm.IsPlaceholder(txtUsername) || string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show(DialogOwner(), "لطفاً نام کاربری را وارد کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUsername.Focus();
                return;
            }
            if (KioskForm.IsPlaceholder(txtPassword) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show(DialogOwner(), "لطفاً رمز عبور را وارد کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPassword.Focus();
                return;
            }
            // FIX C5: capture the text on the UI thread BEFORE moving to a
            // background thread.
            string user = txtUsername.Text.Trim();
            string pw = txtPassword.Text;

            // NEW FEATURE (offline emergency access, per request): checked
            // entirely locally, before any network attempt, so this works
            // even with zero server connectivity. See ClientOptions.cs for
            // the default credentials and the documented security tradeoff.
            //
            // BUG FIX: this whole block used to have no error handling at
            // all. This app has a global exception handler (Program.cs)
            // that catches any unhandled exception and silently sends it to
            // CrashReporter — which logs it to a file/server, but shows
            // NOTHING to the user. If anything here threw, the visible
            // symptom would be exactly "I click Login and nothing happens
            // at all" — indistinguishable from the check simply not
            // matching. Wrapping this in its own try/catch with a visible
            // MessageBox turns a silent failure into a diagnosable one.
            try
            {
                if (ClientOptions.VerifySuperAdmin(user, pw))
                {
                    // Round 7: admin mode in the right column instead of the
                    // two-option maintenance dialog (EnterAdminMode).
                    EnterAdminMode();
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(DialogOwner(), "خطا در بررسی ورود محلی:\n\n" + ex.ToString(), "خطا — لطفاً این پیام را برای پشتیبانی ارسال کنید", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // BUG FIX (root cause, fixed properly): this check now runs
            // HERE — after the super-admin check above has already had its
            // chance to succeed and return — instead of disabling the whole
            // button, which used to also block the super-admin path. A
            // normal (non-admin) login attempt is blocked here when the
            // operator has intentionally disabled customer self-login; the
            // admin override above is never affected by this setting.
            if (ClientOptions.DisableLoginRequest)
            {
                MessageBox.Show(DialogOwner(), "ورود عادی مشتری در این کلاینت غیرفعال است — با اپراتور تماس بگیرید.", "ورود غیرفعال است", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnLogin.Enabled = false;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    _engine.Login(user, pw);
                }
                finally
                {
                    try { BeginInvoke((Action)(() => btnLogin.Enabled = true)); }
                    catch (InvalidOperationException) { /* form closing/closed */ }
                }
            });
        }

        /// <summary>
        /// Round 7: the admin column's full-exit button. Same steps as the exit of the
        /// former maintenance dialog (OpenMaintenanceMenu, removed; EnterAdminMode
        /// replaces it): confirm, release the keyboard and Task Manager locks, log,
        /// and close the program, which leaves the normal Windows desktop for deeper
        /// repair.
        /// </summary>
        private void ExitKioskFromAdmin()
        {
            var confirm = MessageBox.Show(DialogOwner(),
                "این کار قفل کیوسک را کاملاً باز می‌کند و به دسکتاپ ویندوز دسترسی می‌دهید. ادامه می‌دهید؟",
                "تأیید خروج کامل", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;
            // Admin mode may have ended while the question was open (idle lock, server
            // lock); then the answer no longer counts.
            if (!_adminMode) return;
            try { _adminIdleTimer?.Stop(); } catch { }
            try { SecurityLock.RestoreAll(); } catch { }
            try { ActivityLogger.Log("SuperAdmin", "Kiosk unlocked via offline maintenance login."); } catch { }
            // Round 12: the only exit the guard and the scheduled task accept as on
            // purpose. Maintenance lasts until the kiosk is started again (by hand or at
            // the next Windows start).
            ReportKioskEvent("station", "خروج کامل از کیوسک توسط مدیر (حالت نگهداری؛ سیستم بی‌قفل)"); // round 14
            try { GameNet.Shared.SelfHeal.Guardian.SetMaintenance("Client", true); } catch { }
            try { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Client"); } catch { }
            Application.Exit();
        }

        private void btnLogout_Click(object s, EventArgs e)
        {
            // Round 10: a logout is already under way (waiting for the logout message).
            if (_closePending) return;

            // REAPPLY-KIOSK-CHANGES-1 (Part F.8): honor DisableLogout — the
            // operator can make the kiosk non-exitable from the customer UI
            // (e.g. for unattended / pre-paid stations). Show a warning toast
            // and return without closing.
            if (ClientOptions.DisableLogout)
            {
                try
                {
                    ShowToast("🚫 خروج غیرفعال است",
                              "خروج از کیوسک توسط اپراتور غیرفعال شده است.",
                              "warning", 4000);
                }
                catch { }
                return;
            }

            // Just one button — closes the kiosk completely (no password needed).
            // The user (customer or operator) clicks "⏻ خروج" and the kiosk exits.
            try
            {
                _sessionTimer?.Stop();
                try { _tickerTimer?.Stop(); } catch { }

                // REAPPLY-KIOSK-CHANGES-1 (Part F.8): TerminateOnLogout —
                // kill all non-critical processes before closing so the
                // customer can't leave a game running. We use the same
                // GameKiller utility that the OnTimeExpired handler uses.
                if (ClientOptions.TerminateOnLogout)
                {
                    try { GameKiller.KillAllGames(); } catch { }
                }

                // FIX (FIX-CLIENT-BUGS B4): the previous code computed minutes
                // played as `(DateTime.UtcNow - DateTime.UtcNow).TotalMinutes`
                // which is ALWAYS 0 (zero elapsed). Worse, this redundant
                // ActivityLogger.Logout call ALSO happened inside
                // ClientEngine.Logout (which correctly uses _sessionStart), so
                // the activity log got TWO entries per logout — one with min=0
                // (broken) and one with the correct value. Remove the broken
                // duplicate call here and let ClientEngine.Logout handle the
                // single, correct log entry.
                _engine?.Logout();

                // REAPPLY-KIOSK-CHANGES-1 (Part F.8): show the OnLogoutMessage
                // toast + play the OnLogoutSound before closing (only if the
                // operator has configured one). The toast is non-modal so it
                // doesn't block Close().
                try
                {
                    if (!string.IsNullOrWhiteSpace(ClientOptions.OnLogoutMessage))
                        ShowToast("خروج", ClientOptions.OnLogoutMessage, "info", 3000);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrWhiteSpace(ClientOptions.OnLogoutSound))
                        SoundAlert.PlayFile(ClientOptions.OnLogoutSound);
                }
                catch { }
            }
            catch { }
            // FIX (FIX-B1-B4 B2, HIGH): ALWAYS clear state and close,
            // regardless of whether the ClientLogout send succeeded.
            // Previously, ClientEngine.Logout() only cleared State (to
            // Connected) when `SendSafe(ClientLogout)` returned true. If the
            // network was down, SendSafe returned false, State stayed
            // InSession, and then `this.Close()` triggered
            // KioskForm_FormClosing which saw State==InSession and CANCELLED
            // the close with the contradictory "برای خروج ابتدا نشست را
            // پایان دهید" popup — trapping the user on a kiosk they could
            // not exit. Force State back to Connected here (best-effort:
            // server will time the session out via heartbeat loss) so
            // FormClosing doesn't block, then mark explicit-exit and close.
            if (_engine != null) _engine.State = ClientState.Connected;
            IsExplicitExit = true;
            // Round 10: with a logout message or sound set, wait 3 s before closing so it
            // can be seen and heard; the program used to close at once and cut both off.
            bool farewell = !string.IsNullOrWhiteSpace(ClientOptions.OnLogoutMessage)
                || !string.IsNullOrWhiteSpace(ClientOptions.OnLogoutSound);
            if (!farewell)
            {
                this.Close();
                return;
            }
            _closePending = true;
            var closeTimer = new System.Windows.Forms.Timer { Interval = 3000 };
            closeTimer.Tick += (s2, e2) =>
            {
                closeTimer.Stop();
                closeTimer.Dispose();
                this.Close();
            };
            closeTimer.Start();
        }

        // REAPPLY-KIOSK-CHANGES-1 (Part A): the entire btnTicket_Click
        // method is removed. The handyCafe sidebar's "➕ اعتبار" button
        // covers the same quick-credit UX without the InputBox modal that
        // was kiosk-insecure (see worklog L1.25).

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part F.13): formats a minute count as
        /// <c>HH:MM:00</c> for the handyCafe sidebar's timer rows. Used by
        /// the OnSessionUpdate handler for the Used + Remaining rows. The
        /// seconds component is always 00 because the server only deals in
        // whole minutes (matching the handyCafe display).
        /// </summary>
        private static string FormatMinutes(int min)
        {
            if (min < 0) min = 0;
            int h = min / 60;
            int m = min % 60;
            return $"{h:00}:{m:00}:00";
        }

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part C + Part G): opens the handyCafe-
        /// style ClientOptionsForm as a modal dialog. If the operator clicks
        /// OK (DialogResult.OK), re-applies the four environment-side
        /// options (wallpaper / USB / language / sidebar layout) so the
        /// changes take effect immediately without requiring a kiosk restart.
        /// Round 8: <paramref name="customerPageTab"/> opens the dialog on the
        /// customer-page tab (the admin column's settings button passes true).
        /// </summary>
        private void OpenClientOptions(bool customerPageTab = false)
        {
            try
            {
                using (var dlg = new ClientOptionsForm())
                {
                    // Round 10: read after the dialog has reloaded client_options.json.
                    bool usbBefore = ClientOptions.UsbProtection;
                    var journalBefore = ClientOptions.SnapshotForJournal(); // round 14
                    // Round 7: centred on the screen (from the 280 px column the dialog
                    // was pushed against the right edge), and kept in
                    // _openSettingsDialog so leaving admin mode can close it.
                    dlg.StartPosition = FormStartPosition.CenterScreen;
                    if (customerPageTab) dlg.ShowCustomerPageTab();
                    _openSettingsDialog = dlg;
                    DialogResult result;
                    try { result = ShowKioskDialog(dlg); }
                    finally { _openSettingsDialog = null; }
                    if (result == DialogResult.OK)
                    {
                        // Round 14: the server's activity journal gets what changed here.
                        try
                        {
                            string changes = ClientOptions.DescribeChanges(journalBefore, ClientOptions.SnapshotForJournal());
                            ReportKioskEvent("settings", string.IsNullOrEmpty(changes) ? "تنظیمات کیوسک باز و بدون تغییر بسته شد" : "تنظیمات کیوسک تغییر کرد: " + changes);
                        }
                        catch { }
                        try { ApplyDefaultWallpaper(); } catch { }
                        // Round 10: USB protection reports the result when it was changed;
                        // without administrator rights it used to fail silently.
                        bool usbApplied = false;
                        try { usbApplied = ApplyUsbProtection(); } catch { }
                        if (ClientOptions.UsbProtection != usbBefore)
                        {
                            if (usbApplied)
                                ShowToast("USB Protection", "تنظیم شد. برای اعمال کامل، ویندوز را یک بار ری‌استارت کنید.", "info", 6000);
                            else
                                MessageBox.Show(DialogOwner(),
                                    "USB Protection اعمال نشد: برنامهٔ کیوسک دسترسی مدیر ویندوز ندارد.\nاین تنظیم فقط وقتی کار می‌کند که کیوسک با دسترسی مدیر (Administrator) اجرا شود.",
                                    "USB Protection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        try { ApplyLanguage(); } catch { }
                        try { LayoutSessionControls(); } catch { }
                        // Round 10: a new server address from the General tab is used now.
                        if (dlg.ServerAddressChanged) ApplyServerAddress();
                    }
                }
            }
            catch (Exception ex)
            {
                try
                {
                    MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
            }
        }

        /// <summary>
        /// Round 10: the General tab saved a new server address (ConnectionSettings,
        /// server_settings.txt). Outside a customer session the kiosk drops its link and
        /// connects to the new server at once. During a session that session would be
        /// lost, so the address is used from the next start of the program.
        /// </summary>
        private void ApplyServerAddress()
        {
            if (_engine != null && _engine.State == ClientState.InSession)
            {
                ShowToast("آدرس سرور", "ذخیره شد؛ دفعهٔ بعد که برنامهٔ کیوسک باز شود اعمال می‌شود.", "info", 6000);
                return;
            }
            try
            {
                ClientEngine old = _engine;
                _serverHost = ConnectionSettings.ServerHost;
                _serverPort = ConnectionSettings.ServerPort;
                try { _sessionTimer?.Stop(); } catch { }
                try { old?.Dispose(); } catch { }
                lblStatus.Text = "🔄 اتصال به " + _serverHost + "...";
                SetupEngine();
            }
            catch (Exception ex)
            {
                try { MessageBox.Show(DialogOwner(), ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); } catch { }
            }
        }

        // REAPPLY-KIOSK-CHANGES-1 (Part F.2): P/Invoke for SPI_SETDESKWALLPAPER.
        // user32!SystemParametersInfo with SPI_SETDESKWALLPAPER lets us set
        // the operator-configured DefaultWallpaper as the desktop background.
        [DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        private static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
        private const int SPI_SETDESKWALLPAPER = 0x0014;
        private const int SPIF_UPDATEINIFILE = 0x01;
        private const int SPIF_SENDWININICHANGE = 0x02;

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part F.2): applies the operator-configured
        /// DefaultWallpaper to the desktop. If the path is empty / missing /
        /// not an image file, no-op (the previous wallpaper stays). Best-effort
        /// — never throws (a corrupt wallpaper path must not brick the kiosk).
        /// </summary>
        private void ApplyDefaultWallpaper()
        {
            try
            {
                string path = ClientOptions.DefaultWallpaper;
                if (string.IsNullOrWhiteSpace(path)) return;
                if (!System.IO.File.Exists(path)) return;
                SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, path,
                    SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
            }
            catch { }
        }

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part F.3): toggles USB mass-storage
        /// protection by setting the USBSTOR driver's Start value in the
        /// registry. <c>Start=4</c> disables the driver (USB storage devices
        // no longer mount); <c>Start=3</c> re-enables it. Requires admin
        // rights — wrapped in try/catch so the kiosk still boots when the
        // operator is running un-elevated (the change is just silently
        // skipped and the previous state stays).
        /// </summary>
        // Round 10: returns false when the value could not be written (no administrator
        // rights, or no USBSTOR key); OpenClientOptions reports that to the operator.
        private bool ApplyUsbProtection()
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(
                    @"SYSTEM\CurrentControlSet\Services\USBSTOR", true))
                {
                    if (key == null) return false;
                    int val = ClientOptions.UsbProtection ? 4 : 3;
                    key.SetValue("Start", val, RegistryValueKind.DWord);
                    return true;
                }
            }
            catch { return false; /* un-elevated / restricted kiosk user */ }
        }

        // Round 10: ApplyAutoDiscovery (a UDP broadcast to the server) was removed. No
        // server answered it, so it only delayed the start by 2 s. Program.cs looks for
        // the server on the LAN when the saved one does not answer (AutoDiscovery).

        /// <summary>
        /// REAPPLY-KIOSK-CHANGES-1 (Part F.5): maps the friendly language name
        // saved by the handyCafe Options dialog ("فارسی" / "English" / ...) to
        // the matching .NET culture name and applies it to the current thread's
        // CurrentUICulture so any future resource lookup uses the right
        // locale. Wrapped in try/catch so an unknown language name doesn't
        // break the ctor.
        /// </summary>
        private void ApplyLanguage()
        {
            try
            {
                string lang = ClientOptions.Language;
                if (string.IsNullOrWhiteSpace(lang)) return;
                string cultureName;
                switch (lang.Trim().ToLowerInvariant())
                {
                    case "فارسی":
                    case "persian":
                    case "farsi":
                        cultureName = "fa-IR"; break;
                    case "english":
                        cultureName = "en-US"; break;
                    case "deutsch":
                        cultureName = "de-DE"; break;
                    case "español":
                    case "espanol":
                        cultureName = "es-ES"; break;
                    case "português":
                    case "portugues":
                        cultureName = "pt-PT"; break;
                    case "türkçe":
                    case "turkce":
                        cultureName = "tr-TR"; break;
                    default:
                        // Unknown — try to map directly (e.g. "fa-IR" passed
                        // through verbatim).
                        cultureName = lang.Trim();
                        break;
                }
                try
                {
                    var ci = new CultureInfo(cultureName);
                    System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
                    System.Threading.Thread.CurrentThread.CurrentCulture = ci;
                }
                catch { /* unknown culture string — ignore */ }
            }
            catch { }
        }

        /// <summary>Shows the kiosk screensaver when idle.</summary>
        private void ShowScreensaver()
        {
            // ADD-CLIENT-25 — Task 24: no-op in low-perf mode (screensaver disabled).
            if (_lowPerfMode) return;
            try
            {
                // Not shown while the kiosk is minimized (desktop mode): a dialog owned by a
                // minimized window stays hidden and would block the UI thread.
                if (this.WindowState != FormWindowState.Minimized)
                    using (var ss = new KioskScreensaver("GameNet"))
                        ss.ShowDialog(this);
            }
            catch { }
            _screensaverTimer.Stop();
            _screensaverTimer.Start(); // reset idle timer
        }

        private string _lastServerMsgKey = "";
        private DateTime _lastServerMsgAt = DateTime.MinValue;

        /// <summary>
        /// True when the same title and body were already shown less than 5 minutes ago.
        /// Called on the UI thread only.
        /// </summary>
        private bool IsRepeatedServerMessage(string title, string body)
        {
            string key = (title ?? "") + "\u001f" + (body ?? "");
            bool repeated = key == _lastServerMsgKey && (DateTime.UtcNow - _lastServerMsgAt).TotalMinutes < 5;
            _lastServerMsgKey = key;
            _lastServerMsgAt = DateTime.UtcNow;
            return repeated;
        }

        /// <summary>
        /// ADD-CLIENT-25 — Task 3: shows a non-modal ToastBanner with the
        /// given title/body/level. Auto-dismisses after autoCloseMs. Used
        /// by the time-warning system (5-min / 1-min / 0-min) and by the
        /// food/topup confirmation toasts.
        /// </summary>
        private void ShowToast(string title, string body, string level, int autoCloseMs = 5000)
        {
            try
            {
                // Close any active banner first so they don't stack.
                try { _activeBanner?.Close(); _activeBanner?.Dispose(); } catch { }
                _activeBanner = new ToastBanner(title, body, level, autoCloseMs);
                _activeBanner.FormClosed += (s, e) => _activeBanner = null;
                _activeBanner.Show(this);
            }
            catch { /* best-effort: a toast failure must not break the calling path */ }
        }

        /// <summary>
        /// ADD-CLIENT-25 — Task 20: maps the server-side tier name (which can
        /// be customized by the operator) to one of the four canonical badge
        /// names: Bronze/Silver/Gold/Platinum. Best-effort string match.
        /// </summary>
        private static string GetTierBadge(string name)
        {
            if (string.IsNullOrEmpty(name)) return "رتبه: عادی";
            string n = name.ToLowerInvariant();
            if (n.Contains("plat") || n.Contains("پلاتین")) return "🏅 پلاتین";
            if (n.Contains("gold") || n.Contains("طلا")) return "🥇 طلایی";
            if (n.Contains("silver") || n.Contains("نقره")) return "🥈 نقره‌ای";
            if (n.Contains("bronze") || n.Contains("برنز")) return "🥉 برنزی";
            return "🏅 " + name;
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // FIX H6: stop+dispose the screensaver timer (was leaking a 3-min
            // WinForms timer whose Tick handler captured `this`, keeping the
            // form alive after Dispose).
            try { _screensaverTimer?.Stop(); _screensaverTimer?.Dispose(); } catch { }
            // FIX H6/L13: unsubscribe the UpsMonitor handler so the static event
            // doesn't keep a strong ref to the disposed form (would NRE on the
            // next power-lost event when BeginInvoke is called against a closed
            // window handle, and would also prevent the form from being GC'd).
            try { if (_upsPowerLostHandler != null) UpsMonitor.OnPowerLost -= _upsPowerLostHandler; } catch { }
            try { _sessionTimer?.Stop(); _sessionTimer?.Dispose(); } catch { }
            try { _tickerTimer?.Stop(); _tickerTimer?.Dispose(); } catch { }
            try { _adminIdleTimer?.Stop(); _adminIdleTimer?.Dispose(); } catch { }
            try { _timeOverlay?.HideOverlay(); _timeOverlay?.Dispose(); } catch { }
            // ADD-CLIENT-25 — Task 25: close the secondary timer form.
            try { _secondaryTimer?.Close(); _secondaryTimer?.Dispose(); } catch { }
            // ADD-CLIENT-25 — Task 3: close any active banner.
            try { _activeBanner?.Close(); _activeBanner?.Dispose(); } catch { }
            // ADD-CLIENT-25 — Task 18: stop ambient music on exit.
            try { AmbientMusic.Stop(); } catch { }
            // FIX H10: Dispose the engine (not just Disconnect) so the
            // underlying NetworkClient + TcpClient + socket handles are
            // formally released. Previously only Disconnect() was called,
            // which closed the stream but left the NetworkClient undisposed
            // — leaking a TcpClient per form close.
            try { _engine?.Dispose(); } catch { }
            base.OnFormClosed(e);
        }
    }
}
