using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace GameNet.Client
{
    /// <summary>
    /// Phase — Client-side license fingerprint + cached license token.
    ///
    /// Generate() returns a stable per-machine fingerprint combining:
    ///   - Machine name
    ///   - First NIC MAC address
    ///   - Windows serial number (from WMI, fallback: empty)
    /// hashed with SHA-256. The server uses this to identify the kiosk.
    ///
    /// LoadCachedToken() / SaveCachedToken() persist the license token the
    /// server issues after approval, so the kiosk doesn't have to be
    /// re-approved after every restart.
    /// </summary>
    public static class ClientLicenseFingerprint
    {
        private static string _cachedFingerprint;
        private static readonly string TokenFile = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "license.token");

        /// <summary>
        /// Generates (and caches) the machine fingerprint. Returns the same
        /// value on every call within a process lifetime.
        /// </summary>
        public static string Generate()
        {
            if (_cachedFingerprint != null) return _cachedFingerprint;

            string machineName = Environment.MachineName ?? "";
            string mac = NetworkClient.GetMacAddress() ?? "";
            string serial = GetWindowsSerial();

            string combined = machineName + "|" + mac + "|" + serial;
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(combined));
                var sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                _cachedFingerprint = sb.ToString();
            }
            return _cachedFingerprint;
        }

        /// <summary>Returns the cached license token, or empty if none.</summary>
        public static string LoadCachedToken()
        {
            try
            {
                if (File.Exists(TokenFile))
                    return File.ReadAllText(TokenFile).Trim();
            }
            catch { }
            return "";
        }

        /// <summary>Saves the license token issued by the server.</summary>
        public static void SaveCachedToken(string token)
        {
            try { File.WriteAllText(TokenFile, token ?? ""); }
            catch { }
        }

        private static string GetWindowsSerial()
        {
            try
            {
                // Read the Windows ProductId from the registry — no extra
                // assembly reference needed (unlike WMI). Stable across reboots.
                using (var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                {
                    var productId = key?.GetValue("ProductId")?.ToString();
                    if (!string.IsNullOrEmpty(productId)) return productId;
                    // FIX (FIX-B1-B4 B3, HIGH): `DigitalProductId` is stored
                    // in the registry as a REG_BINARY (byte[]). The previous
                    // code did `key.GetValue("DigitalProductId")?.ToString()`
                    // which — for a byte[] — returns the literal string
                    // "System.Byte[]" (Object.ToString() on an array returns
                    // its type name). Every kiosk on the planet therefore
                    // produced the same fingerprint component
                    // "...|<mac>|System.Byte[]", causing fingerprint
                    // collisions on machines where `ProductId` was empty
                    // (e.g. post-2018 Windows 10 builds that stopped
                    // populating ProductId) AND causing the fingerprint to
                    // be byte-identical across all such machines (the MAC
                    // was the only differentiator, and on machines where
                    // GetMacAddress returned "UNKNOWN" — see B4 — the
                    // entire fingerprint collided).
                    // Convert the byte[] to a stable Base64 string so it
                    // actually contributes a unique value to the hash.
                    object val = key?.GetValue("DigitalProductId");
                    if (val is byte[] bytes)
                        return Convert.ToBase64String(bytes);
                    else if (val != null)
                        return val.ToString();
                }
            }
            catch { }
            return "";
        }
    }
}
