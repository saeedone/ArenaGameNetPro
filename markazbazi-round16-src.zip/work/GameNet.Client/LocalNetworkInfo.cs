using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;

namespace GameNet.Client
{
    /// <summary>
    /// Utility class for retrieving the kiosk's local network IP address
    /// and hostname. Used to display in the client UI and send to the
    /// server as part of the connection info.
    /// </summary>
    public static class LocalNetworkInfo
    {
        private static string _cachedIp;
        private static string _cachedHostname;

        /// <summary>
        /// Returns the kiosk's primary local IPv4 address (e.g.
        /// 192.168.1.50). Falls back to "?" if no network is available.
        /// Cached after the first call.
        /// </summary>
        public static string GetLocalIp()
        {
            if (_cachedIp != null) return _cachedIp;
            try
            {
                // The most reliable way: connect a UDP socket to a public
                // address and read the local endpoint. This doesn't actually
                // send any packets, but the OS picks the correct NIC.
                using (var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
                {
                    socket.Connect("8.8.8.8", 80);
                    var endPoint = socket.LocalEndPoint as IPEndPoint;
                    if (endPoint != null)
                    {
                        _cachedIp = endPoint.Address.ToString();
                        return _cachedIp;
                    }
                }
            }
            catch { }

            // Fallback: enumerate network interfaces
            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                var ip = host.AddressList.FirstOrDefault(a => a.AddressFamily == AddressFamily.InterNetwork && !a.ToString().StartsWith("127."));
                _cachedIp = ip?.ToString() ?? "?";
                return _cachedIp;
            }
            catch { }

            _cachedIp = "?";
            return _cachedIp;
        }

        /// <summary>Returns the machine name.</summary>
        public static string GetHostname()
        {
            if (_cachedHostname != null) return _cachedHostname;
            try { _cachedHostname = Environment.MachineName; }
            catch { _cachedHostname = "?"; }
            return _cachedHostname;
        }
    }
}
