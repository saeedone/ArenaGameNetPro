using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// A Panel subclass that paints a smooth diagonal gradient background.
    /// Used for the login screen so the dark "kiosk" backdrop gets a subtle
    /// accent-blue glow instead of being a flat fill.
    /// </summary>
    public class GradientPanel : Panel
    {
        public Color ColorTop { get; set; } = Color.FromArgb(240, 240, 240);
        public Color ColorBottom { get; set; } = Color.FromArgb(240, 240, 240);
        public float GradientAngle { get; set; } = 90F;

        public GradientPanel()
        {
            this.DoubleBuffered = true;
            this.ResizeRedraw = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            // Fill the gradient FIRST so child labels with transparent
            // backcolors inherit the gradient instead of the panel's flat
            // BackColor (which WinForms would otherwise paint for us).
            try
            {
                var g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var brush = new LinearGradientBrush(this.ClientRectangle, ColorTop, ColorBottom, GradientAngle))
                {
                    g.FillRectangle(brush, this.ClientRectangle);
                }
            }
            catch { }
            // Call base.OnPaint to ensure child controls paint correctly.
            base.OnPaint(e);
        }
    }

    /// <summary>
    /// A Label subclass that draws a soft "glow" shadow behind the text so the
    /// title stands out against a busy gradient background. The glow color is
    /// a darker variant of the ForeColor.
    /// </summary>
    public class GlowLabel : Label
    {
        public Color GlowColor { get; set; } = Color.FromArgb(0, 80, 160);
        public int GlowOffset { get; set; } = 3;

        public GlowLabel()
        {
            this.DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            // Make the label transparent over the parent so the gradient shows
            // through (we draw text manually).
            this.BackColor = Color.Transparent;
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                var g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                // FIX (FIX-CLIENT-BUGS B1): do NOT wrap `this.Font` in a
                // `using` — `this.Font` returns a SHARED Font instance (the
                // label's own Font, which is typically inherited from the
                // parent form). Disposing it would destroy the Font for every
                // control sharing it, causing "Object reference not set" /
                // "Font is already disposed" exceptions elsewhere in the app.
                // We reference it directly without disposing.
                var font = this.Font;
                using (var glowBrush = new SolidBrush(GlowColor))
                using (var textBrush = new SolidBrush(this.ForeColor))
                using (var sf = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                })
                {
                    if (this.RightToLeft == RightToLeft.Yes) sf.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
                    var rect = new RectangleF(0, 0, this.Width, this.Height);
                    // Draw the glow text 8 times, offset to create a halo.
                    for (int dx = -GlowOffset; dx <= GlowOffset; dx += GlowOffset)
                        for (int dy = -GlowOffset; dy <= GlowOffset; dy += GlowOffset)
                            g.DrawString(this.Text, font, glowBrush, new RectangleF(rect.X + dx, rect.Y + dy, rect.Width, rect.Height), sf);
                    // Draw the actual text on top.
                    g.DrawString(this.Text, font, textBrush, rect, sf);
                }
            }
            catch
            {
                // Fallback to default label painting if anything fails.
                base.OnPaint(e);
            }
        }
    }

    /// <summary>
    /// A Button subclass with rounded corners. Used for the login "ورود"
    /// button.
    /// BUG FIX (per report: "clicking Login does nothing at all"): this
    /// used to restrict the CLICKABLE area to a Region matching the rounded
    /// shape, recomputed only in OnResize. That's fragile — if the Region
    /// were ever computed against a stale size (e.g. before the control's
    /// final Size/DPI scaling settled), the clickable area could end up
    /// smaller than what's visually shown, or not matching it at all,
    /// silently swallowing every click with no visible symptom. Rather than
    /// keep chasing the exact trigger, the safest fix is to stop
    /// restricting the hit-area at all: the corners are still painted
    /// rounded (via OnPaint below), but the ENTIRE rectangular bounds stay
    /// clickable regardless of any sizing/DPI edge case. Trades a small
    /// cosmetic nicety (a few fully-square pixels in the corners, covered
    /// by the rounded paint anyway) for guaranteed clickability everywhere.
    /// </summary>
    public class RoundedButton : Button
    {
        public int CornerRadius { get; set; } = 18;

        public RoundedButton()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.DoubleBuffered = true;
            this.ResizeRedraw = true;
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            // Paints the rounded-rectangle background itself now that the
            // Region no longer does it — same visual shape as before, just
            // no longer restricting where clicks land.
            try
            {
                int r = Math.Max(0, Math.Min(CornerRadius, Math.Min(Width, Height) / 2));
                var rect = new Rectangle(0, 0, Math.Max(1, Width - 1), Math.Max(1, Height - 1));
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    if (r <= 0)
                    {
                        path.AddRectangle(rect);
                    }
                    else
                    {
                        path.AddArc(rect.X, rect.Y, r * 2, r * 2, 180, 90);
                        path.AddArc(rect.Right - r * 2, rect.Y, r * 2, r * 2, 270, 90);
                        path.AddArc(rect.Right - r * 2, rect.Bottom - r * 2, r * 2, r * 2, 0, 90);
                        path.AddArc(rect.X, rect.Bottom - r * 2, r * 2, r * 2, 90, 90);
                        path.CloseFigure();
                    }
                    using (var brush = new SolidBrush(this.BackColor))
                        pevent.Graphics.FillPath(brush, path);
                }
            }
            catch { }

            // Draw the text/icon content on top, same as a normal flat button.
            TextRenderer.DrawText(pevent.Graphics, this.Text, this.Font, this.ClientRectangle, this.ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
}
