using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Shared;

namespace GameNet.Client
{
    /// <summary>
    /// All functional panels for the kiosk sidebar navigation. Each panel
    /// is a self-contained UserControl that the KioskForm swaps in when
    /// the user clicks the corresponding nav button.
    /// </summary>

    // === CHAT PANEL ===
    public class ChatPanel : UserControl
    {
        private RichTextBox _messages;
        private TextBox _input;
        private Button _send;
        private ClientEngine _engine;
        private FlowLayoutPanel _emojiBar;
        // FIX (FIX-CLIENT-BUGS B6): store handlers so we can unsubscribe in
        // Dispose. Without this, after the user navigates away from the chat
        // panel (which disposes it), every incoming chat message would call
        // BeginInvoke on the disposed panel → InvalidOperationException →
        // surfaced as an "خطای پردازش پیام" MessageBox per chat message.
        private Action<ChatReceivePayload> _chatHandler;
        private Action<ChatHistoryPayload> _historyHandler;

        public ChatPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "💬 چت با اپراتور", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(203, 166, 247), Location = new Point(20, 15), AutoSize = true };

            // ADD-CLIENT-25 — Task 17: full-height chat history (was 400px,
            // now fills the panel minus the input row + emoji bar).
            _messages = new RichTextBox
            {
                Location = new Point(20, 55), Size = new Size(820, 460),
                BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 12F), ReadOnly = true, BorderStyle = BorderStyle.None,
            };
            _messages.AppendText("💬 چت با اپراتور آماده است.\n\n");

            // ADD-CLIENT-25 — Task 17: emoji bar — a row of clickable emoji
            // buttons that insert their emoji into the input box.
            _emojiBar = new FlowLayoutPanel
            {
                Location = new Point(20, 525),
                Size = new Size(820, 36),
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(4),
                AutoScroll = false,
                WrapContents = false,
            };
            var emojis = new[] { "👍", "❤️", "😂", "🎮", "🔥", "👏", "🙏", "💯", "⭐", "✅", "❌", "☕" };
            foreach (var em in emojis)
            {
                var btn = new Button
                {
                    Text = em,
                    Size = new Size(36, 28),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(49, 50, 68),
                    ForeColor = Color.FromArgb(40, 40, 40),
                    Font = new Font("Segoe UI", 11F),
                    Margin = new Padding(2),
                    Tag = em,
                };
                btn.Click += (s, e) =>
                {
                    try
                    {
                        var b = s as Button;
                        if (b != null && _input.Text != "پیام خود را بنویسید...")
                            _input.Text += b.Tag as string;
                        _input.Focus();
                        _input.SelectionStart = _input.TextLength;
                    }
                    catch { }
                };
                _emojiBar.Controls.Add(btn);
            }

            _input = new TextBox
            {
                Location = new Point(20, 570), Size = new Size(700, 35),
                BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 12F), BorderStyle = BorderStyle.FixedSingle,
            };
            SetPlaceholder(_input, "پیام خود را بنویسید...");

            _send = new Button
            {
                Text = "📤 ارسال", Location = new Point(730, 568), Size = new Size(110, 38),
                BackColor = Color.FromArgb(203, 166, 247), FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240),
            };
            _send.Click += (s, e) => SendMessage();

            this.Controls.AddRange(new Control[] { lblTitle, _messages, _emojiBar, _input, _send });

            // Wire engine events
            if (_engine != null)
            {
                _chatHandler = (msg) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        _messages.SelectionColor = msg.IsBroadcast ? Color.FromArgb(249, 226, 175) : Color.FromArgb(166, 227, 161);
                        _messages.AppendText($"[{msg.Timestamp.ToLocalTime():HH:mm}] {msg.SenderDisplayName}: {msg.Message}\n");
                        _messages.SelectionColor = Color.FromArgb(40, 40, 40);
                        _messages.ScrollToCaret();
                        // ADD-CLIENT-25 — Task 17: play a notification sound when a
                        // new chat message arrives (best-effort — SystemSounds).
                        try { System.Media.SystemSounds.Asterisk.Play(); } catch { }
                    }
                    catch { /* disposed */ }
                }));
                _historyHandler = (hist) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        _messages.Clear();
                        foreach (var m in hist.Messages)
                        {
                            _messages.SelectionColor = m.IsBroadcast ? Color.FromArgb(249, 226, 175) : Color.FromArgb(40, 40, 40);
                            _messages.AppendText($"[{m.Timestamp.ToLocalTime():HH:mm}] {m.SenderDisplayName}: {m.Message}\n");
                        }
                        _messages.ScrollToCaret();
                    }
                    catch { /* disposed */ }
                }));
                _engine.OnChatMessage += _chatHandler;
                _engine.OnChatHistory += _historyHandler;
                // Request chat history on load.
                try { _engine.RequestChatHistory(); } catch { }
            }
        }

        protected override void Dispose(bool disposing)
        {
            // FIX (FIX-CLIENT-BUGS B6): unsubscribe engine events so the
            // disposed panel doesn't get BeginInvoke'd on every new chat
            // message (which would throw InvalidOperationException and surface
            // as an "خطای پردازش پیام" MessageBox per message).
            if (disposing && _engine != null)
            {
                if (_chatHandler != null) try { _engine.OnChatMessage -= _chatHandler; } catch { }
                if (_historyHandler != null) try { _engine.OnChatHistory -= _historyHandler; } catch { }
            }
            base.Dispose(disposing);
        }

        private void SendMessage()
        {
            if (string.IsNullOrWhiteSpace(_input.Text) || _input.Text == "پیام خود را بنویسید...") return;
            try { _engine?.SendChatMessage(_input.Text, "", true); _input.Clear(); }
            catch { }
        }

        private void SetPlaceholder(TextBox tb, string ph)
        {
            tb.Text = ph; tb.ForeColor = Color.FromArgb(128, 128, 128);
            tb.GotFocus += (s, e) => { if (tb.Text == ph) { tb.Text = ""; tb.ForeColor = Color.FromArgb(40, 40, 40); } };
            tb.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(tb.Text)) { tb.Text = ph; tb.ForeColor = Color.FromArgb(128, 128, 128); } };
        }
    }

    // === ANNOUNCEMENTS PANEL ===
    public class AnnouncementsPanel : UserControl
    {
        private FlowLayoutPanel _flow;
        private ClientEngine _engine;
        // FIX (FIX-CLIENT-BUGS B6): store the handler for unsubscription in Dispose.
        private Action<AnnouncementListPayload> _annHandler;

        public AnnouncementsPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "📢 اطلاعیه‌ها", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(249, 226, 175), Location = new Point(20, 15), AutoSize = true };

            _flow = new FlowLayoutPanel
            {
                Location = new Point(20, 55), Size = new Size(800, 500),
                BackColor = Color.FromArgb(240, 240, 240), AutoScroll = true, WrapContents = true, Padding = new Padding(10),
            };

            this.Controls.AddRange(new Control[] { lblTitle, _flow });

            if (_engine != null)
            {
                _annHandler = (ann) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        _flow.Controls.Clear();
                        foreach (var a in ann.Announcements)
                        {
                            var card = new Panel { Size = new Size(750, 100), BackColor = Color.FromArgb(49, 50, 68), Margin = new Padding(5) };
                            var color = a.Level == "critical" ? Color.FromArgb(243, 139, 168) : a.Level == "warning" ? Color.FromArgb(249, 226, 175) : Color.FromArgb(137, 180, 250);
                            card.Controls.Add(new Label { Text = a.Title, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = color, Location = new Point(10, 5), AutoSize = true });
                            card.Controls.Add(new Label { Text = a.Body, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(10, 35), Size = new Size(730, 50) });
                            card.Controls.Add(new Label { Text = a.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"), Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(10, 80), AutoSize = true });
                            _flow.Controls.Add(card);
                        }
                        if (ann.Announcements.Count == 0)
                            _flow.Controls.Add(new Label { Text = "📢 هیچ اطلاعیه‌ای موجود نیست.", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(148, 226, 213), AutoSize = true });
                    }
                    catch { /* disposed */ }
                }));
                _engine.OnAnnouncements += _annHandler;
                // Request announcements on load
                try { _engine.RequestAnnouncements(); } catch { }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _engine != null && _annHandler != null)
            {
                try { _engine.OnAnnouncements -= _annHandler; } catch { }
            }
            base.Dispose(disposing);
        }
    }

    // === PROFILE PANEL ===
    public class ProfilePanel : UserControl
    {
        private ClientEngine _engine;
        private Label _lblUser, _lblBalance, _lblMember;
        private TextBox _txtOldPw, _txtNewPw, _txtNewPw2;
        private Button _btnChangePw;

        public ProfilePanel(ClientEngine engine, string username, decimal balance)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "👤 پروفایل کاربر", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 15), AutoSize = true };

            _lblUser = new Label { Text = $"👤 نام کاربری: {username}", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 55), AutoSize = true };
            _lblBalance = new Label { Text = $"💰 اعتبار: {balance:N0} تومان", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(166, 227, 161), Location = new Point(20, 85), AutoSize = true };
            _lblMember = new Label { Text = "🏅 سطح عضویت: عادی", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(249, 226, 175), Location = new Point(20, 115), AutoSize = true };

            // Network info
            var lblIp = new Label { Text = $"🌐 IP محلی: {LocalNetworkInfo.GetLocalIp()}", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 145), AutoSize = true };
            var lblHost = new Label { Text = $"💻 نام دستگاه: {LocalNetworkInfo.GetHostname()}", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 175), AutoSize = true };

            var lblChangePw = new Label { Text = "🔐 تغییر رمز عبور:", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(137, 180, 250), Location = new Point(20, 220), AutoSize = true };

            _txtOldPw = MkPwBox(20, 255, "رمز فعلی");
            _txtNewPw = MkPwBox(20, 295, "رمز جدید");
            _txtNewPw2 = MkPwBox(20, 335, "تکرار رمز جدید");

            _btnChangePw = new Button { Text = "✅ تغییر رمز", Location = new Point(20, 380), Size = new Size(200, 38), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnChangePw.Click += (s, e) =>
            {
                if (_txtNewPw.Text != _txtNewPw2.Text) { MessageBox.Show("رمز جدید و تکرار آن یکسان نیستند."); return; }
                if (_txtNewPw.Text.Length < 4) { MessageBox.Show("رمز جدید باید حداقل ۴ کاراکتر باشد."); return; }
                MessageBox.Show("برای تغییر رمز، لطفاً به اپراتور مراجعه کنید.", "تغییر رمز", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            this.Controls.AddRange(new Control[] { lblTitle, _lblUser, _lblBalance, _lblMember, lblIp, lblHost, lblChangePw, _txtOldPw, _txtNewPw, _txtNewPw2, _btnChangePw });
        }

        private TextBox MkPwBox(int x, int y, string ph)
        {
            var tb = new TextBox { Location = new Point(x, y), Size = new Size(300, 30), PasswordChar = '*', Font = new Font("Segoe UI", 11F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };
            tb.Text = ph; tb.ForeColor = Color.FromArgb(128, 128, 128);
            tb.GotFocus += (s, e) => { if (tb.Text == ph) { tb.Text = ""; tb.ForeColor = Color.FromArgb(40, 40, 40); } };
            tb.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(tb.Text)) { tb.Text = ph; tb.ForeColor = Color.FromArgb(128, 128, 128); } };
            return tb;
        }
    }

    // === STATS PANEL ===
    public class StatsPanel : UserControl
    {
        public StatsPanel(string username, decimal balance)
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "📊 آمار شخصی", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(137, 180, 250), Location = new Point(20, 15), AutoSize = true };

            var lblInfo = new Label
            {
                Text = $"👤 کاربر: {username}\n\n💰 اعتبار فعلی: {balance:N0} تومان\n\n📊 آمار دقیق در سرور ذخیره می‌شود.\nاپراتور می‌تواند گزارش کامل شما را ارائه دهد.",
                Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(40, 40, 40),
                Location = new Point(20, 55), Size = new Size(700, 200),
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblInfo });
        }
    }

    // === LOYALTY PANEL ===
    public class LoyaltyPanel : UserControl
    {
        private ClientEngine _engine;
        private Label _lblPoints;
        private TextBox _txtRedeem;
        private Button _btnRedeem;
        // FIX (FIX-CLIENT-BUGS B5): store the OnTierInfo handler so we can
        // unsubscribe in Dispose. Without this, the engine keeps a strong
        // reference to the panel via the closure, and any TierInfo message
        // arriving after the panel is closed would invoke BeginInvoke against
        // a disposed handle (ObjectDisposedException swallowed by the
        // BeginInvoke marshaller — silent leak of a closure per panel open).
        private Action<TierInfoPayload> _tierInfoHandler;

        public LoyaltyPanel(ClientEngine engine, string username)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "🏆 امتیازات وفاداری", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(250, 179, 135), Location = new Point(20, 15), AutoSize = true };

            _lblPoints = new Label { Text = "🏆 امتیاز شما: ---\n\n💰 هر امتیاز = ۱,۰۰۰ تومان اعتبار\n\nبرای تبدیل امتیاز به اعتبار، تعداد را وارد کنید:", Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 55), Size = new Size(700, 100) };

            _txtRedeem = new TextBox { Location = new Point(20, 170), Size = new Size(200, 30), Font = new Font("Segoe UI", 12F), BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            _btnRedeem = new Button { Text = "💰 تبدیل به اعتبار", Location = new Point(230, 168), Size = new Size(200, 35), BackColor = Color.FromArgb(249, 226, 175), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnRedeem.Click += (s, e) =>
            {
                if (int.TryParse(_txtRedeem.Text, out int pts) && pts > 0)
                {
                    MessageBox.Show($"درخواست تبدیل {pts} امتیاز ارسال شد.\nاپراتور تأیید خواهد کرد.", "درخواست", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else MessageBox.Show("تعداد امتیاز معتبر وارد کنید.");
            };

            // FIX (FIX-CLIENT-BUGS B5): subscribe to OnTierInfo BEFORE calling
            // RequestTierInfo. The previous order (RequestTierInfo → +=) had a
            // race where the server's reply could arrive (on the read thread)
            // and raise OnTierInfo BEFORE the += line executed — the panel
            // would silently miss the tier update and stay on "---".
            if (_engine != null)
            {
                _tierInfoHandler = (tier) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        if (tier != null && tier.CurrentTier != null)
                            _lblPoints.Text = $"🏆 امتیاز شما: {tier.CurrentPoints}\n🏅 سطح: {tier.CurrentTier.Name}\n\n💰 هر امتیاز = ۱,۰۰۰ تومان اعتبار\n\nبرای تبدیل امتیاز به اعتبار، تعداد را وارد کنید:";
                    }
                    catch { /* disposed */ }
                }));
                _engine.OnTierInfo += _tierInfoHandler;
                try { _engine.RequestTierInfo(); } catch { }
            }

            this.Controls.AddRange(new Control[] { lblTitle, _lblPoints, _txtRedeem, _btnRedeem });
        }

        protected override void Dispose(bool disposing)
        {
            // FIX (FIX-CLIENT-BUGS B5): unsubscribe the engine event so the
            // closure doesn't keep a strong reference to this panel after
            // the user navigates away.
            if (disposing && _engine != null && _tierInfoHandler != null)
            {
                try { _engine.OnTierInfo -= _tierInfoHandler; } catch { }
            }
            base.Dispose(disposing);
        }
    }

    // === QUICK TOP-UP PANEL ===
    public class TopupPanel : UserControl
    {
        private ClientEngine _engine;
        private NumericUpDown _numAmount;
        private ComboBox _cboMethod;
        private Button _btnRequest;
        private Label _lblStatus;
        // FIX (FIX-CLIENT-BUGS B6): store the handler for unsubscription in Dispose.
        private Action<TopupResponsePayload> _topupHandler;

        public TopupPanel(ClientEngine engine)
        {
            _engine = engine;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            var lblTitle = new Label { Text = "💳 شارژ سریع", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(166, 227, 161), Location = new Point(20, 15), AutoSize = true };

            var lblInfo = new Label { Text = "مبلغ مورد نظر را وارد کنید.\nدرخواست به اپراتور ارسال می‌شود.\nپس از تأیید، اعتبار شما افزایش می‌یابد.", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(148, 226, 213), Location = new Point(20, 55), Size = new Size(700, 60) };

            var lblAmount = new Label { Text = "مبلغ (تومان):", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 130), AutoSize = true };
            _numAmount = new NumericUpDown { Location = new Point(150, 127), Size = new Size(200, 30), Font = new Font("Segoe UI", 12F), Minimum = 1000, Maximum = 1000000, Increment = 5000, Value = 10000, BackColor = Color.FromArgb(49, 50, 68), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblMethod = new Label { Text = "روش پرداخت:", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, 170), AutoSize = true };
            _cboMethod = new ComboBox { Location = new Point(150, 167), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F) };
            _cboMethod.Items.AddRange(new object[] { "نقدی (حضوری)", "کارت‌خوان", "انتقال بانکی" });
            _cboMethod.SelectedIndex = 0;

            _btnRequest = new Button { Text = "📤 ارسال درخواست", Location = new Point(20, 220), Size = new Size(200, 40), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            _btnRequest.Click += (s, e) =>
            {
                try
                {
                    _engine?.RequestTopup(_numAmount.Value, _cboMethod.SelectedIndex == 0 ? "cash" : _cboMethod.SelectedIndex == 1 ? "card" : "transfer");
                    _lblStatus.Text = "✅ درخواست ارسال شد! منتظر تأیید اپراتور بمانید.";
                    _lblStatus.ForeColor = Color.FromArgb(166, 227, 161);
                }
                catch (Exception ex) { _lblStatus.Text = "❌ خطا: " + ex.Message; _lblStatus.ForeColor = Color.FromArgb(243, 139, 168); }
            };

            _lblStatus = new Label { Text = "", Font = new Font("Segoe UI", 11F), ForeColor = Color.FromArgb(166, 227, 161), Location = new Point(20, 270), AutoSize = true };

            // Wire response
            if (_engine != null)
            {
                _topupHandler = (resp) => BeginInvoke((Action)(() =>
                {
                    try
                    {
                        if (resp.Approved)
                        {
                            _lblStatus.Text = $"✅ تأیید شد! {resp.Amount:N0} تومان به اعتبار شما اضافه شد.";
                            _lblStatus.ForeColor = Color.FromArgb(166, 227, 161);
                        }
                        else
                        {
                            _lblStatus.Text = $"❌ رد شد: {resp.Message}";
                            _lblStatus.ForeColor = Color.FromArgb(243, 139, 168);
                        }
                    }
                    catch { /* disposed */ }
                }));
                _engine.OnTopupResponse += _topupHandler;
            }

            this.Controls.AddRange(new Control[] { lblTitle, lblInfo, lblAmount, _numAmount, lblMethod, _cboMethod, _btnRequest, _lblStatus });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _engine != null && _topupHandler != null)
            {
                try { _engine.OnTopupResponse -= _topupHandler; } catch { }
            }
            base.Dispose(disposing);
        }
    }
}
