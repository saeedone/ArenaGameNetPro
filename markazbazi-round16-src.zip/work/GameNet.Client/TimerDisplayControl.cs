using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GameNet.Client
{
    /// <summary>
    /// Large, color-coded timer display with a progress bar.
    ///
    ///   - Timer text: 48pt bold Consolas (MUCH larger than the previous 28pt)
    ///   - Cost: 20pt bold (larger than the previous 10pt)
    ///   - Color-code: green >10min, yellow 5-10min, red <5min
    ///   - Pulsing/blinking red when <1 minute (toggles between red and dark-red every 500ms)
    ///   - Progress bar: shows time-elapsed vs total available
    /// </summary>
    public class TimerDisplayControl : UserControl
    {
        private Label _timer, _elapsed, _cost, _remaining;
        private Panel _progressOuter;
        private Panel _progressInner;
        private Timer _pulseTimer;
        private int _pulsePhase;
        private bool _pulse;
        private int? _lastRemaining;

        public TimerDisplayControl()
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Padding = new Padding(10);
            this.DoubleBuffered = true;
            // Make the control tall enough for the bigger timer + progress bar.
            this.Size = new Size(440, 180);

            _timer = new Label
            {
                Dock = DockStyle.Top,
                Font = new Font("Consolas", 48F, FontStyle.Bold),
                ForeColor = Color.FromArgb(137, 180, 250),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "00:00:00",
                Height = 75,
            };
            _elapsed = new Label
            {
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(40, 40, 40),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "زمان: --:--:--",
                Height = 22,
            };
            _cost = new Label
            {
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                ForeColor = Color.FromArgb(249, 226, 175),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "هزینه: ---",
                Height = 34,
            };
            _remaining = new Label
            {
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(166, 227, 161),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "باقی‌مانده: ---",
                Height = 22,
            };
            _progressOuter = new Panel
            {
                Dock = DockStyle.Top,
                Height = 10,
                BackColor = Color.FromArgb(45, 45, 65),
                Margin = new Padding(0, 4, 0, 0),
            };
            _progressInner = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(0, 10),
                BackColor = Color.FromArgb(166, 227, 161),
            };
            _progressOuter.Controls.Add(_progressInner);

            // FIX (FIX-CLIENT-BUGS B3): WinForms docks controls in REVERSE
            // z-order — the LAST control added to the Controls collection is
            // at the FRONT (z-order index 0) and docks FIRST (i.e., ends up
            // at the TOP for DockStyle.Top). The previous order
            //   { _timer, _elapsed, _cost, _remaining, _progressOuter }
            // produced the REVERSE visual layout: the progress bar at the top
            // and the big timer at the bottom. Reverse the array so the
            // intended top→bottom order is restored:
            //   _timer (top) → _elapsed → _cost → _remaining → _progressOuter (bottom).
            Controls.AddRange(new Control[] { _progressOuter, _remaining, _cost, _elapsed, _timer });

            _pulseTimer = new Timer { Interval = 500 };
            _pulseTimer.Tick += (s, e) =>
            {
                _pulsePhase++;
                if (_pulse)
                {
                    _timer.ForeColor = (_pulsePhase % 2 == 0)
                        ? Color.FromArgb(243, 139, 168)
                        : Color.FromArgb(120, 30, 50);
                }
            };
            _pulseTimer.Start();
        }

        // FIX (FIX-CLIENT-BUGS B10): the pulse timer is a System.Windows.Forms.Timer
        // stored in a private field — it is NOT added to the UserControl's
        // `components` container, so the base Dispose(bool) does NOT dispose it.
        // Without this override, the timer kept ticking after the control was
        // disposed (every 500ms, capturing `this` via the Tick lambda), leaking
        // a timer handle + a strong ref to the disposed control per kiosk
        // session. On a long-running kiosk that logged in/out many users, this
        // accumulated hundreds of zombie timers all firing every 500ms.
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try { _pulseTimer?.Stop(); _pulseTimer?.Dispose(); } catch { }
            }
            base.Dispose(disposing);
        }

        public void UpdateDisplay(TimeSpan el, decimal cost, int? rem)
        {
            if (InvokeRequired) { Invoke((Action)(() => UpdateDisplay(el, cost, rem))); return; }
            string t = $"{(int)el.TotalHours:D2}:{el.Minutes:D2}:{el.Seconds:D2}";
            _timer.Text = t;
            _elapsed.Text = $"زمان: {t}";
            _cost.Text = $"💰 هزینه: {cost:N0} تومان";
            _remaining.Text = rem.HasValue ? $"باقی‌مانده: {rem} دقیقه" : "باقی‌مانده: نامحدود";

            // Color-code the timer: green >10min, yellow 5-10min, red <5min,
            // pulsing red when <1 minute.
            _lastRemaining = rem;
            if (!rem.HasValue)
            {
                _timer.ForeColor = Color.FromArgb(137, 180, 250); // blue (unlimited)
                _pulse = false;
            }
            else if (rem.Value <= 1)
            {
                _pulse = true;
                _timer.ForeColor = (_pulsePhase % 2 == 0)
                    ? Color.FromArgb(243, 139, 168)
                    : Color.FromArgb(120, 30, 50);
            }
            else if (rem.Value <= 5)
            {
                _timer.ForeColor = Color.FromArgb(243, 139, 168); // red
                _pulse = false;
            }
            else if (rem.Value <= 10)
            {
                _timer.ForeColor = Color.FromArgb(249, 226, 175); // yellow
                _pulse = false;
            }
            else
            {
                _timer.ForeColor = Color.FromArgb(166, 227, 161); // green
                _pulse = false;
            }

            // Update the progress bar: shows the elapsed fraction of the
            // total available time (based on balance / price-per-hour). When
            // remaining time is unlimited, show a "full" bar (no progress).
            try
            {
                if (rem.HasValue)
                {
                    int remMin = rem.Value;
                    // total = elapsed minutes + remaining minutes
                    int elapsedMin = (int)el.TotalMinutes;
                    int totalMin = elapsedMin + remMin;
                    if (totalMin <= 0) totalMin = 1;
                    int pct = (int)(100L * elapsedMin / totalMin);
                    if (pct < 0) pct = 0;
                    if (pct > 100) pct = 100;
                    int innerW = (int)(_progressOuter.ClientSize.Width * (pct / 100.0));
                    _progressInner.Size = new Size(Math.Max(0, innerW), 10);
                    _progressInner.BackColor = _timer.ForeColor;
                }
                else
                {
                    _progressInner.Size = new Size(0, 10);
                }
            }
            catch { }
        }
    }
}
