using System;
using System.Media;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX-MONITOR-ADD5 TASK B3: simple sound-notifications helper. Wraps
    /// <see cref="SystemSounds"/> so the rest of the server code can fire
    /// a sound by intent (topup / timer-expired / order / success / error)
    /// without each caller hard-coding the Windows sound alias.
    ///
    /// All methods are best-effort: any failure (no audio device, sound
    /// service stopped, etc.) is swallowed so a missing audio driver can
    /// never crash the server. The PlayXxx methods are non-blocking —
    /// SystemSounds.Play uses the OS's async sound-play mechanism.
    /// </summary>
    public static class SoundNotification
    {
        /// <summary>
        /// Played when a kiosk sends a ClientTopupRequest — draws the
        /// operator's attention to the new topup toast so they can confirm
        /// or reverse the auto-approved topup.
        /// </summary>
        public static void PlayTopup() { try { SystemSounds.Exclamation.Play(); } catch { } }

        /// <summary>
        /// Played when a client's session timer hits zero (the kiosk is
        /// about to be force-locked). Different from PlayTopup so the
        /// operator can distinguish "needs attention" from "session over".
        /// </summary>
        public static void PlayTimerExpired() { try { SystemSounds.Hand.Play(); } catch { } }

        /// <summary>
        /// Played when a kiosk submits a food/drink order via the OrdersForm
        /// integration (not yet wired — placeholder for the future orders
        /// pipeline).
        /// </summary>
        public static void PlayOrder() { try { SystemSounds.Asterisk.Play(); } catch { } }

        /// <summary>
        /// Generic "operation succeeded" cue — e.g. after a successful
        /// manual topup from the Users tab.
        /// </summary>
        public static void PlaySuccess() { try { SystemSounds.Asterisk.Play(); } catch { } }

        /// <summary>
        /// Generic "operation failed" cue — e.g. when a database write
        /// fails or a station command can't be delivered.
        /// </summary>
        public static void PlayError() { try { SystemSounds.Hand.Play(); } catch { } }

        // ---- Round 11: the operator's sound cues ------------------------------
        // WAV files in the "Sounds" folder next to the server exe (the build copies
        // them). Replace any file with your own .wav of the same name to change it.
        // A missing file falls back to a Windows system sound.

        /// <summary>Turns all round-11 cues off (for example a quiet shift).</summary>
        public static volatile bool Enabled = true;

        private static readonly object _gate = new object();
        private static readonly System.Collections.Generic.Dictionary<string, DateTime> _last =
            new System.Collections.Generic.Dictionary<string, DateTime>();

        /// <summary>
        /// Plays Sounds\fileName. <paramref name="key"/> + <paramref name="minGapSeconds"/>
        /// stop a burst of events (ten stations coming online after a power cut, a
        /// customer pressing a button repeatedly) from playing the cue ten times.
        /// </summary>
        public static void PlayCue(string fileName, SystemSound fallback, string key = null, double minGapSeconds = 2)
        {
            if (!Enabled) return;
            string k = (key ?? "") + "|" + fileName;
            lock (_gate)
            {
                DateTime prev;
                if (_last.TryGetValue(k, out prev) && (DateTime.UtcNow - prev).TotalSeconds < minGapSeconds) return;
                _last[k] = DateTime.UtcNow;
            }
            try
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sounds", fileName);
                if (System.IO.File.Exists(path))
                {
                    using (var sp = new SoundPlayer(path)) sp.Play(); // asynchronous
                    return;
                }
            }
            catch { }
            try { fallback?.Play(); } catch { }
        }

        /// <summary>A station's kiosk program connected (the PC was switched on).</summary>
        public static void PlayClientOnline(string station) { PlayCue("client_online.wav", SystemSounds.Asterisk, station, 30); }

        /// <summary>A customer sent the operator a message.</summary>
        public static void PlayCustomerMessage(string station) { PlayCue("customer_message.wav", SystemSounds.Exclamation, station, 1.5); }

        /// <summary>A customer asked for extra time (or to end the session).</summary>
        public static void PlayTimeRequest(string station) { PlayCue("time_request.wav", SystemSounds.Exclamation, station, 1.5); }

        /// <summary>A station has 5 minutes left.</summary>
        public static void PlayFiveMinutes(string station) { PlayCue("warn5.wav", SystemSounds.Asterisk, station, 50); }

        /// <summary>A station's time is over.</summary>
        public static void PlayTimeEnd(string station) { PlayCue("time_end.wav", SystemSounds.Hand, station, 10); }
    }
}
