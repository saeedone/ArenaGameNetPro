using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX DEAD-CONFIG-6: SyncForm used to keep its task list in a plain
    /// <c>List&lt;SyncTask&gt;</c> field on the form instance — every task the
    /// operator defined was silently lost the moment the Sync window was
    /// closed, and OptionsForm's "همگام‌سازی زمان‌بندی‌شده" (ScheduledSync)
    /// setting had nothing to run against even if it were wired up, because
    /// there was nowhere durable to read task definitions from.
    ///
    /// This persists the task list (host / info / local path — the fields
    /// the operator actually fills in) to sync_tasks.json next to the exe,
    /// mirroring the pattern used by <see cref="StationNumbering"/>.
    /// </summary>
    public static class SyncTaskStore
    {
        private static readonly string StoreFile = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "sync_tasks.json");

        private static readonly object _lock = new object();

        public class SyncTaskRecord
        {
            public int Id { get; set; }
            public string Host { get; set; } = "";
            public string Info { get; set; } = "";
            public string LocalPath { get; set; } = "";
        }

        public static List<SyncTaskRecord> Load()
        {
            lock (_lock)
            {
                try
                {
                    if (!File.Exists(StoreFile)) return new List<SyncTaskRecord>();
                    string json = File.ReadAllText(StoreFile);
                    return JsonConvert.DeserializeObject<List<SyncTaskRecord>>(json) ?? new List<SyncTaskRecord>();
                }
                catch (Exception ex)
                {
                    AuditLog.Log("SyncTaskStore", "Load failed, starting empty: " + ex.Message);
                    return new List<SyncTaskRecord>();
                }
            }
        }

        public static void Save(List<SyncTaskRecord> tasks)
        {
            lock (_lock)
            {
                try
                {
                    string json = JsonConvert.SerializeObject(tasks, Formatting.Indented);
                    // FIX (consistent with other JSON stores in this codebase):
                    // write to a temp file and swap in, so a crash mid-write
                    // can't leave sync_tasks.json truncated/corrupt.
                    string tmp = StoreFile + ".tmp";
                    File.WriteAllText(tmp, json);
                    File.Copy(tmp, StoreFile, overwrite: true);
                    File.Delete(tmp);
                }
                catch (Exception ex)
                {
                    AuditLog.Log("SyncTaskStore", "Save failed: " + ex.Message);
                }
            }
        }
    }
}
