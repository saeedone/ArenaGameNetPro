using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Wait-queue system for when all stations (PC or console) are occupied.
    ///
    /// A user is added to the queue with a desired resource type (PC, PS4,
    /// PS5, Xbox, or Any). When a matching station becomes free, the
    /// operator is notified and can call the next user. The queue is FIFO
    /// within each resource type, with optional VIP priority (members of a
    /// higher tier jump ahead).
    ///
    /// Tables:
    ///   wait_queue (id, username, resource_type, position, status, notes,
    ///               vip, estimated_wait_min, created_at, called_at, served_at)
    ///   wait_history (id, username, resource_type, queue_id, waited_min,
    ///                 status, created_at)
    ///
    /// Status values: 'waiting' → 'called' → 'served' | 'cancelled' | 'expired'
    /// </summary>
    public class QueueManager
    {
        public const string ResourceAny = "Any";
        public const string ResourcePC = "PC";
        public const string ResourcePS4 = "PS4";
        public const string ResourcePS5 = "PS5";
        public const string ResourceXbox = "Xbox";

        /// <summary>
        /// Adds a user to the wait queue. Position is calculated as
        /// max(position) + 1 within the same resource type. VIP users are
        /// inserted before non-VIP users at the same position.
        /// </summary>
        public int Enqueue(string username, string resourceType, bool vip = false, string notes = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (string.IsNullOrEmpty(resourceType)) resourceType = ResourceAny;

            // Verify user exists
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            // Check the user isn't already in the queue
            int existing = Database.Instance.QueryOne(
                "SELECT COUNT(*) FROM wait_queue WHERE username = @u AND status = 'waiting'",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => r.GetInt32(0));
            if (existing > 0) throw new InvalidOperationException("این کاربر از قبل در صف است");

            int id = 0;
            Database.Instance.ExecuteInTransaction(tx =>
            {
                // Compute next position
                int maxPos = Database.Instance.QueryOne(
                    "SELECT COALESCE(MAX(position), 0) FROM wait_queue WHERE resource_type = @r AND status = 'waiting'",
                    cmd => cmd.Parameters.AddWithValue("@r", resourceType),
                    r => r.GetInt32(0), tx);

                int position = maxPos + 1;

                // If VIP, shift existing non-VIP users back
                if (vip)
                {
                    Database.Instance.Execute(
                        "UPDATE wait_queue SET position = position + 1 WHERE resource_type = @r AND status = 'waiting' AND vip = 0",
                        cmd => cmd.Parameters.AddWithValue("@r", resourceType), tx);
                    // VIP goes to position 1 (or after other VIPs)
                    int vipCount = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM wait_queue WHERE resource_type = @r AND status = 'waiting' AND vip = 1",
                        cmd => cmd.Parameters.AddWithValue("@r", resourceType),
                        r => r.GetInt32(0), tx);
                    position = vipCount + 1;
                }

                int estWait = EstimateWait(resourceType, position);

                Database.Instance.Execute(
                    "INSERT INTO wait_queue (username, resource_type, position, status, notes, vip, estimated_wait_min, created_at) " +
                    "VALUES (@u, @r, @p, 'waiting', @n, @v, @e, @c)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@r", resourceType);
                        cmd.Parameters.AddWithValue("@p", position);
                        cmd.Parameters.AddWithValue("@n", notes ?? "");
                        cmd.Parameters.AddWithValue("@v", vip ? 1 : 0);
                        cmd.Parameters.AddWithValue("@e", estWait);
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                    }, tx);

                id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });

            AuditLog.Log("Queue", $"User {username} enqueued for {resourceType} (pos ?, VIP={vip})");
            return id;
        }

        /// <summary>
        /// Removes a user from the queue (cancelled by user or operator).
        /// Repositions subsequent waiting entries.
        /// </summary>
        public void Cancel(int queueId, string reason = "Cancelled by operator")
        {
            var entry = GetEntry(queueId);
            if (entry.Equals(default)) throw new KeyNotFoundException("ورودی صف یافت نشد");
            if (entry.Status != "waiting" && entry.Status != "called")
                throw new InvalidOperationException("این ورودی قابل لغو نیست");

            Database.Instance.ExecuteInTransaction(tx =>
            {
                Database.Instance.Execute(
                    "UPDATE wait_queue SET status = 'cancelled', notes = COALESCE(notes,'') || ' | ' || @r WHERE id = @id",
                    cmd => { cmd.Parameters.AddWithValue("@r", reason); cmd.Parameters.AddWithValue("@id", queueId); }, tx);

                // Reposition subsequent entries
                Database.Instance.Execute(
                    "UPDATE wait_queue SET position = position - 1 WHERE resource_type = @r AND status = 'waiting' AND position > @p",
                    cmd => { cmd.Parameters.AddWithValue("@r", entry.ResourceType); cmd.Parameters.AddWithValue("@p", entry.Position); }, tx);
            });

            AuditLog.Log("Queue", $"Entry #{queueId} cancelled: {reason}");
        }

        /// <summary>
        /// Marks a queue entry as "called" — the operator is summoning the
        /// user to an available station. The entry is held in "called" state
        /// for a grace period (default 10 minutes) before it auto-expires.
        /// </summary>
        public void CallNext(string resourceType)
        {
            if (string.IsNullOrEmpty(resourceType)) resourceType = ResourceAny;

            // Find the next waiting entry (lowest position, VIP first)
            var entry = Database.Instance.QueryOne(
                "SELECT id, username, position FROM wait_queue WHERE resource_type = @r AND status = 'waiting' ORDER BY vip DESC, position ASC LIMIT 1",
                cmd => cmd.Parameters.AddWithValue("@r", resourceType),
                r => (Id: r.GetInt32(0), Username: r.GetString(1), Position: r.GetInt32(2)));

            if (entry.Equals(default)) throw new InvalidOperationException("صف خالی است");

            Database.Instance.ExecuteInTransaction(tx =>
            {
                Database.Instance.Execute(
                    "UPDATE wait_queue SET status = 'called', called_at = @c WHERE id = @id",
                    cmd => { cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", entry.Id); }, tx);

                // Reposition remaining waiting entries
                Database.Instance.Execute(
                    "UPDATE wait_queue SET position = position - 1 WHERE resource_type = @r AND status = 'waiting' AND position > @p",
                    cmd => { cmd.Parameters.AddWithValue("@r", resourceType); cmd.Parameters.AddWithValue("@p", entry.Position); }, tx);
            });

            AuditLog.Log("Queue", $"Called next: {entry.Username} (#{entry.Id}) for {resourceType}");
        }

        /// <summary>
        /// Marks a called entry as served (the user has started a session).
        /// Moves it to history.
        /// </summary>
        public void MarkServed(int queueId)
        {
            var entry = GetEntry(queueId);
            if (entry.Equals(default)) throw new KeyNotFoundException("ورودی یافت نشد");

            int waitedMin = entry.CreatedAt == DateTime.MinValue ? 0 : (int)Math.Round((DateTime.UtcNow - entry.CreatedAt).TotalMinutes);

            Database.Instance.ExecuteInTransaction(tx =>
            {
                Database.Instance.Execute(
                    "UPDATE wait_queue SET status = 'served', served_at = @c WHERE id = @id",
                    cmd => { cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", queueId); }, tx);

                Database.Instance.Execute(
                    "INSERT INTO wait_history (username, resource_type, queue_id, waited_min, status, created_at) VALUES (@u, @r, @q, @w, 'served', @c)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", entry.Username);
                        cmd.Parameters.AddWithValue("@r", entry.ResourceType);
                        cmd.Parameters.AddWithValue("@q", queueId);
                        cmd.Parameters.AddWithValue("@w", waitedMin);
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                    }, tx);
            });

            AuditLog.Log("Queue", $"Entry #{queueId} served (waited {waitedMin} min)");
        }

        /// <summary>
        /// Expires "called" entries that haven't been served within the grace
        /// period. Called by a periodic timer.
        /// </summary>
        public int ExpireStaleCalls(int graceMinutes = 10)
        {
            var stale = Database.Instance.Query(
                "SELECT id, username, resource_type, called_at FROM wait_queue WHERE status = 'called' AND called_at < @c",
                cmd => cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.AddMinutes(-graceMinutes).ToString("o")),
                r => (Id: r.GetInt32(0), Username: r.GetString(1), ResourceType: r.GetString(2), CalledAt: r.GetDateTime(3)));

            foreach (var s in stale)
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    Database.Instance.Execute("UPDATE wait_queue SET status = 'expired' WHERE id = @id",
                        cmd => cmd.Parameters.AddWithValue("@id", s.Id), tx);
                    Database.Instance.Execute(
                        "INSERT INTO wait_history (username, resource_type, queue_id, waited_min, status, created_at) VALUES (@u, @r, @q, 0, 'expired', @c)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", s.Username);
                            cmd.Parameters.AddWithValue("@r", s.ResourceType);
                            cmd.Parameters.AddWithValue("@q", s.Id);
                            cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                        }, tx);
                });
                AuditLog.Log("Queue", $"Entry #{s.Id} expired (no response within {graceMinutes} min)");
            }
            return stale.Count;
        }

        /// <summary>
        /// Returns all waiting entries, ordered by VIP then position.
        /// </summary>
        public List<(int Id, string Username, string ResourceType, int Position, bool Vip, int EstWaitMin, DateTime CreatedAt, string Notes)> GetWaiting()
        {
            return Database.Instance.Query(
                "SELECT id, username, resource_type, position, vip, estimated_wait_min, created_at, notes FROM wait_queue WHERE status = 'waiting' ORDER BY resource_type, vip DESC, position ASC",
                null,
                r => (
                    r.GetInt32(0),
                    r.GetString(1),
                    r.GetString(2),
                    r.GetInt32(3),
                    r.GetBoolean(4),
                    r.GetInt32(5),
                    r.GetDateTime(6),
                    r.IsDBNull(7) ? "" : r.GetString(7)
                ));
        }

        /// <summary>
        /// Returns all called (summoned) entries.
        /// </summary>
        public List<(int Id, string Username, string ResourceType, DateTime CalledAt)> GetCalled()
        {
            return Database.Instance.Query(
                "SELECT id, username, resource_type, called_at FROM wait_queue WHERE status = 'called' ORDER BY called_at ASC",
                null,
                r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetDateTime(3)));
        }

        /// <summary>Returns a single queue entry by id.</summary>
        public (int Id, string Username, string ResourceType, int Position, string Status, bool Vip, DateTime CreatedAt, DateTime CalledAt, string Notes) GetEntry(int id)
        {
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT id, username, resource_type, position, status, vip, created_at, COALESCE(called_at, created_at), COALESCE(notes, '') FROM wait_queue WHERE id = @id",
                    cmd => cmd.Parameters.AddWithValue("@id", id),
                    r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetInt32(3), r.GetString(4), r.GetBoolean(5), r.GetDateTime(6), r.GetDateTime(7), r.GetString(8)));
            }
            catch { return default; }
        }

        /// <summary>
        /// Returns count of waiting entries per resource type.
        /// </summary>
        public List<(string ResourceType, int Count)> GetCounts()
        {
            return Database.Instance.Query(
                "SELECT resource_type, COUNT(*) FROM wait_queue WHERE status = 'waiting' GROUP BY resource_type ORDER BY resource_type",
                null,
                r => (r.GetString(0), r.GetInt32(1)));
        }

        /// <summary>
        /// Estimates wait time (minutes) for a new entry at the given position.
        /// Uses average session duration (default 60 min) × position ahead.
        /// </summary>
        public int EstimateWait(string resourceType, int position)
        {
            // Try to get average session duration
            double avgMin = 60;
            try
            {
                var avg = Database.Instance.QueryOne<double>(
                    "SELECT AVG(duration_minutes) FROM client_sessions WHERE end_time IS NOT NULL AND duration_minutes > 0",
                    null, r => r.IsDBNull(0) ? 60 : r.GetDouble(0));
                if (avg > 0) avgMin = avg;
            }
            catch { }
            return (int)Math.Round(avgMin * Math.Max(0, position - 1));
        }

        /// <summary>
        /// Clears the entire queue (all waiting + called entries marked
        /// cancelled). Used at end of day.
        /// </summary>
        public void ClearAll(string reason = "End of day clear")
        {
            Database.Instance.Execute(
                "UPDATE wait_queue SET status = 'cancelled', notes = COALESCE(notes,'') || ' | ' || @r WHERE status IN ('waiting','called')",
                cmd => cmd.Parameters.AddWithValue("@r", reason));
            AuditLog.Log("Queue", "Queue cleared: " + reason);
        }
    }
}
