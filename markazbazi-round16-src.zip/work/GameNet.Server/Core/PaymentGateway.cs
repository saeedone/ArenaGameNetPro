using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class PaymentGateway
    {
        private readonly string _merchantId;
        private readonly string _callbackUrl;
        private readonly bool _sandbox;
        // Optional shared secret used to verify the callback signature. When
        // configured, VerifyPayment will require a `signature` query-string
        // parameter equal to HMAC-SHA256(secret, authority) in lowercase hex.
        private readonly string _callbackSecret;

        public PaymentGateway(string merchantId = "", string callbackUrl = "http://localhost:9090/payment/callback", bool sandbox = true, string callbackSecret = "")
        {
            _merchantId = merchantId;
            _callbackUrl = callbackUrl;
            _sandbox = sandbox;
            _callbackSecret = callbackSecret ?? "";
        }

        public PaymentRequestResult RequestPayment(string username, decimal amount, string description = "")
        {
            if (string.IsNullOrEmpty(_merchantId)) throw new InvalidOperationException("Merchant ID not configured");
            if (amount < 1000) throw new ArgumentException("حداقل مبلغ پرداخت ۱,۰۰۰ تومان است");

            try
            {
                string apiUrl = _sandbox ? "https://sandbox.zarinpal.com/pg/v4/payment/request.json" : "https://api.zarinpal.com/pg/v4/payment/request.json";
                var payload = new
                {
                    merchant_id = _merchantId,
                    amount = (long)amount,
                    description = description ?? $"شارژ حساب {username} - GameNet",
                    callback_url = _callbackUrl,
                    metadata = new { mobile = "", email = "" }
                };

                string response = PostJson(apiUrl, payload);
                var result = JsonConvert.DeserializeObject<ZarinPalResponse>(response);

                if (result?.data?.code == 100)
                {
                    string paymentUrl = _sandbox ? $"https://sandbox.zarinpal.com/pg/StartPay/{result.data.authority}" : $"https://www.zarinpal.com/pg/StartPay/{result.data.authority}";

                    Database.Instance.Execute("INSERT INTO payment_transactions (username, amount, authority, status, gateway, created_at) VALUES (@u, @a, @auth, 'pending', 'zarinpal', @t)",
                        cmd => { cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@a", amount); cmd.Parameters.AddWithValue("@auth", result.data.authority); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });

                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentRequested", $"User: {username}, Amount: {amount:N0}");

                    return new PaymentRequestResult { Success = true, Authority = result.data.authority, PaymentUrl = paymentUrl };
                }

                return new PaymentRequestResult { Success = false, Message = $"Error code: {result?.data?.code}" };
            }
            catch (Exception ex)
            {
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentRequestFailed", ex.Message, EnhancedAuditLog.AuditLevel.Error);
                return new PaymentRequestResult { Success = false, Message = ex.Message };
            }
        }

        /// <summary>
        /// Verify a ZarinPal payment and credit the user. This method is
        /// IDEMPOTENT: if the authority has already been verified, the method
        /// returns the existing result without re-crediting. The status update
        /// (pending -> verified) and the user's balance increment run in a
        /// single transaction so a failure between them cannot leave the
        /// payment marked verified-but-not-credited (or vice versa). If a
        /// callback secret is configured, the caller-supplied signature is
        /// verified against HMAC-SHA256(secret, authority) before any DB write.
        /// </summary>
        public PaymentVerifyResult VerifyPayment(string authority, decimal amount, string callbackSignature = null)
        {
            try
            {
                // --- Callback signature verification (optional) ---
                if (!string.IsNullOrEmpty(_callbackSecret))
                {
                    if (string.IsNullOrEmpty(callbackSignature))
                        return new PaymentVerifyResult { Success = false, Message = "امضای کالبک ارسال نشده است" };

                    string expected;
                    using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_callbackSecret)))
                    {
                        byte[] hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(authority ?? ""));
                        expected = BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                    }
                    // Constant-time comparison to avoid a timing oracle.
                    if (!ConstantTimeStringEquals(expected, callbackSignature ?? ""))
                    {
                        EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentSignatureMismatch",
                            $"Authority: {authority}", EnhancedAuditLog.AuditLevel.Warning);
                        return new PaymentVerifyResult { Success = false, Message = "امضای کالبک نامعتبر است" };
                    }
                }

                // --- Idempotency check ---
                // If the authority has already been verified, return the
                // existing ref_id without contacting ZarinPal or crediting
                // the user again. This makes the callback safe to retry.
                var existing = Database.Instance.QueryOne(
                    "SELECT username, amount, status, ref_id FROM payment_transactions WHERE authority = @a",
                    cmd => cmd.Parameters.AddWithValue("@a", authority),
                    r => new { Username = r.GetString(0), Amount = r.GetDecimal(1), Status = r.GetString(2), RefId = r.IsDBNull(3) ? "" : r.GetString(3) });

                if (existing != null && existing.Status == "verified")
                {
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentVerifyIdempotent",
                        $"Authority {authority} already verified; returning cached result. RefID: {existing.RefId}");
                    return new PaymentVerifyResult { Success = true, RefId = ParseRefId(existing.RefId) };
                }

                if (existing == null)
                    return new PaymentVerifyResult { Success = false, Message = "تراکنش یافت نشد" };

                // --- Verify with ZarinPal gateway ---
                string apiUrl = _sandbox ? "https://sandbox.zarinpal.com/pg/v4/payment/verify.json" : "https://api.zarinpal.com/pg/v4/payment/verify.json";
                var payload = new { merchant_id = _merchantId, amount = (long)amount, authority = authority };
                string response = PostJson(apiUrl, payload);
                var result = JsonConvert.DeserializeObject<ZarinPalVerifyResponse>(response);

                if (result?.data?.code != 100 && result?.data?.code != 101)
                    return new PaymentVerifyResult { Success = false, Message = $"Verify error: {result?.data?.code}" };

                string refIdStr = result.data.ref_id.ToString();
                string username = existing.Username;

                // --- Atomic status update + credit in one transaction ---
                // Update the transaction row to 'verified' AND increment the
                // user's balance inside a single transaction. The unique index
                // idx_pay_authority_unique on payment_transactions(authority)
                // plus the status check above makes this idempotent even under
                // concurrent callbacks: the second callback will see the
                // already-verified status on retry and short-circuit.
                try
                {
                    Database.Instance.ExecuteInTransaction(tx =>
                    {
                        // Conditional update: only flip pending -> verified.
                        // If another callback already verified it, rows = 0
                        // and we skip the credit (idempotent).
                        int rows = Database.Instance.ExecuteNonQuery(
                            "UPDATE payment_transactions SET status = 'verified', ref_id = @ref, verified_at = @t WHERE authority = @a AND status = 'pending'",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@ref", refIdStr);
                                cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                                cmd.Parameters.AddWithValue("@a", authority);
                            }, tx);

                        if (rows == 0)
                            return; // already verified by a concurrent callback — nothing to do

                        Database.Instance.ExecuteNonQuery(
                            "UPDATE users SET balance = balance + @amt WHERE username = @u",
                            cmd => { cmd.Parameters.AddWithValue("@amt", amount); cmd.Parameters.AddWithValue("@u", username); }, tx);
                    });
                }
                catch (Exception txEx)
                {
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentVerifyTxnFailed",
                        $"Authority {authority}, user {username}: {txEx.Message}", EnhancedAuditLog.AuditLevel.Error);
                    throw;
                }

                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentVerified",
                    $"User: {username}, Amount: {amount:N0}, RefID: {refIdStr}");
                return new PaymentVerifyResult { Success = true, RefId = result.data.ref_id };
            }
            catch (Exception ex)
            {
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Payment, "PaymentVerifyFailed",
                    ex.Message, EnhancedAuditLog.AuditLevel.Error);
                return new PaymentVerifyResult { Success = false, Message = ex.Message };
            }
        }

        private static long ParseRefId(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            return long.TryParse(s, out long v) ? v : 0;
        }

        private static bool ConstantTimeStringEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        public List<PaymentTransaction> GetTransactions(string username = "", int limit = 50)
        {
            string sql = string.IsNullOrEmpty(username)
                ? "SELECT id, username, amount, authority, status, ref_id, gateway, created_at, verified_at FROM payment_transactions ORDER BY created_at DESC LIMIT @lim"
                : "SELECT id, username, amount, authority, status, ref_id, gateway, created_at, verified_at FROM payment_transactions WHERE username = @u ORDER BY created_at DESC LIMIT @lim";

            return Database.Instance.Query<PaymentTransaction>(sql,
                cmd => { if (!string.IsNullOrEmpty(username)) cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@lim", limit); },
                r => new PaymentTransaction
                {
                    Id = r.GetInt32(0), Username = r.GetString(1), Amount = r.GetDecimal(2),
                    Authority = r.IsDBNull(3) ? "" : r.GetString(3), Status = r.GetString(4),
                    RefId = r.IsDBNull(5) ? "" : r.GetString(5), Gateway = r.IsDBNull(6) ? "" : r.GetString(6),
                    CreatedAt = r.GetDateTime(7), VerifiedAt = r.IsDBNull(8) ? (DateTime?)null : r.GetDateTime(8)
                });
        }

        private string PostJson(string url, object payload)
        {
            var json = JsonConvert.SerializeObject(payload);
            byte[] data = Encoding.UTF8.GetBytes(json);
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.ContentLength = data.Length;
            using (var stream = request.GetRequestStream()) { stream.Write(data, 0, data.Length); }
            using (var response = request.GetResponse())
            using (var reader = new System.IO.StreamReader(response.GetResponseStream())) { return reader.ReadToEnd(); }
        }
    }

    public class PaymentRequestResult { public bool Success; public string Authority; public string PaymentUrl; public string Message; }
    public class PaymentVerifyResult { public bool Success; public long RefId; public string Message; }
    public class PaymentTransaction { public int Id; public string Username; public decimal Amount; public string Authority; public string Status; public string RefId; public string Gateway; public DateTime CreatedAt; public DateTime? VerifiedAt; }
    public class ZarinPalResponse { public ZarinPalData data; }
    public class ZarinPalData { public int code; public string authority; public string message; }
    public class ZarinPalVerifyResponse { public ZarinPalVerifyData data; }
    public class ZarinPalVerifyData { public int code; public long ref_id; public string message; }
}
