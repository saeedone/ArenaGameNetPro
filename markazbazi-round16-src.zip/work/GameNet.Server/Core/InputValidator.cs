using GameNet.Shared;
﻿using System;
using System.Text.RegularExpressions;

namespace GameNet.Server.Core
{
    public static class InputValidator
    {
        // Default password policy. Member passwords must be at least 6 chars and
        // contain at least one letter and one digit. Caller can override the
        // minimum length via the ValidatePassword overload.
        public const int DefaultMinPasswordLength = 6;

        public static (bool IsValid, string Error) ValidateRequired(string value, string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value)) return (false, $"{fieldName} نمی‌تواند خالی باشد");
            return (true, "");
        }

        public static (bool IsValid, string Error) ValidateLength(string value, int min, int max, string fieldName)
        {
            // Null-safety: treat null as length 0 so the min-length branch fires
            // instead of throwing NullReferenceException on `value.Length`.
            int len = value == null ? 0 : value.Length;
            if (len < min) return (false, $"{fieldName} باید حداقل {min} کاراکتر باشد");
            if (len > max) return (false, $"{fieldName} نمی‌تواند بیشتر از {max} کاراکتر باشد");
            return (true, "");
        }

        public static (bool IsValid, string Error) ValidateNumeric(string value, string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value)) return (false, $"{fieldName} نمی‌تواند خالی باشد");
            if (!decimal.TryParse(value, out _)) return (false, $"{fieldName} باید عدد باشد");
            return (true, "");
        }

        public static (bool IsValid, string Error) ValidateUsername(string username)
        {
            var r = ValidateRequired(username, "نام کاربری");
            if (!r.IsValid) return r;
            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9_]{3,30}$")) return (false, "نام کاربری فقط حروف انگلیسی، عدد و _ مجاز است");
            return (true, "");
        }

        /// <summary>
        /// Validates a password against the default policy (min length 6, must
        /// contain at least one letter and one digit). Use this for all new
        /// member/operator password assignments.
        /// </summary>
        public static (bool IsValid, string Error) ValidatePassword(string password)
            => ValidatePassword(password, DefaultMinPasswordLength);

        /// <summary>
        /// Validates a password against a configurable minimum length. Requires
        /// at least one letter and one digit regardless of min length.
        /// </summary>
        public static (bool IsValid, string Error) ValidatePassword(string password, int minLength)
        {
            if (minLength < 1) minLength = 1;
            if (string.IsNullOrEmpty(password)) return (false, "رمز عبور نمی‌تواند خالی باشد");
            if (password.Length < minLength) return (false, $"رمز عبور باید حداقل {minLength} کاراکتر باشد");
            bool hasLetter = false, hasDigit = false;
            foreach (char c in password)
            {
                if (char.IsLetter(c)) hasLetter = true;
                else if (char.IsDigit(c)) hasDigit = true;
            }
            if (!hasLetter || !hasDigit) return (false, "رمز عبور باید شامل حرف و عدد باشد");
            return (true, "");
        }
    }
}
