﻿using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public static class AuditLog
    {
        public static void Log(string category, string action, string details = "")
        {
            // FIX B6: wrap the entire Log body in try/catch with a file
            // fallback. AuditLog.Log is called from many error-handling paths
            // (including inside other try/catch blocks) — if it ever throws
            // (e.g. DB connection disposed, table locked, schema corrupted),
            // the caller's catch swallows the original exception AND the audit
            // log exception escapes, crashing the server. The file fallback
            // guarantees we always have *some* record of the message even when
            // the DB is unavailable.
            try
            {
                Database.Instance.Execute(
                    "INSERT INTO audit_log (category, action, details, timestamp) VALUES (@c, @a, @d, @t)",
                    cmd => { cmd.Parameters.AddWithValue("@c", category); cmd.Parameters.AddWithValue("@a", action); cmd.Parameters.AddWithValue("@d", details ?? ""); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });
            }
            catch
            {
                // Fallback: write to a file next to the exe so the message is
                // not lost even when the DB is unreachable. Best-effort — if
                // even this throws (e.g. disk full), swallow silently.
                try
                {
                    System.IO.File.AppendAllText(
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "audit_fallback.log"),
                        DateTime.Now.ToString("o") + " | " + category + " | " + action + (string.IsNullOrEmpty(details) ? "" : " | " + details) + Environment.NewLine);
                }
                catch { }
            }
        }

        public static PagedResult<(int Id, string Category, string Action, string Details, DateTime Timestamp)> ReadPaged(int page, int pageSize)
        {
            return Database.Instance.QueryPaged(
                "SELECT id, category, action, details, timestamp FROM audit_log ORDER BY id DESC",
                "SELECT COUNT(*) FROM audit_log", page, pageSize, null,
                r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.IsDBNull(3) ? "" : r.GetString(3), r.GetDateTime(4)));
        }

        /// <summary>
        /// FIX LONGTERM-1: audit_log had NO cleanup mechanism at all — unlike
        /// EnhancedAuditLog.CleanupOldEntries and ChatManager.CleanupOldMessages
        /// (which at least existed, even if nothing scheduled them either — see
        /// DatabaseMaintenanceScheduler, which now calls all three on a timer).
        /// Every single AuditLog.Log() call across the entire app — logins,
        /// payments, every sync tick, every idle check, every error path —
        /// inserts a row here with no limit. Over a year of continuous
        /// 24/7 cybercafe operation this table would grow into the millions
        /// of rows, eventually filling the disk and slowing every query that
        /// touches it. Deletes rows older than <paramref name="daysToKeep"/>
        /// and returns how many were removed.
        /// </summary>
        public static int CleanupOldEntries(int daysToKeep = 180)
        {
            try
            {
                string cutoff = DateTime.UtcNow.AddDays(-daysToKeep).ToString("o");
                return Database.Instance.ExecuteNonQuery(
                    "DELETE FROM audit_log WHERE timestamp < @cutoff",
                    cmd => cmd.Parameters.AddWithValue("@cutoff", cutoff));
            }
            catch (Exception ex)
            {
                // Deliberately not calling AuditLog.Log here — if this cleanup
                // itself is failing, logging the failure through the same
                // path is more likely to compound the problem than help.
                try { System.IO.File.AppendAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "audit_fallback.log"), DateTime.Now.ToString("o") + " | AuditLog | CleanupOldEntries failed: " + ex.Message + Environment.NewLine); } catch { }
                return 0;
            }
        }
    }
}
