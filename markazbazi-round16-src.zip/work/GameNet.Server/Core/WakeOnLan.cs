﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public static class WakeOnLan
    {
        public static bool SendMagicPacket(string mac, int port = 9, string broadcast = "255.255.255.255")
        {
            try
            {
                byte[] macBytes = ParseMac(mac); if (macBytes == null) return false;
                byte[] packet = new byte[102];
                for (int i = 0; i < 6; i++) packet[i] = 0xFF;
                for (int i = 1; i <= 16; i++) for (int j = 0; j < 6; j++) packet[i * 6 + j] = macBytes[j];
                using (var client = new UdpClient()) { client.EnableBroadcast = true; client.Send(packet, packet.Length, new IPEndPoint(IPAddress.Parse(broadcast), port)); client.Send(packet, packet.Length, new IPEndPoint(IPAddress.Broadcast, port)); }
                return true;
            }
            catch { return false; }
        }

        public static bool IsValidMacAddress(string mac) => !string.IsNullOrWhiteSpace(mac) && (Regex.IsMatch(mac, @"^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$") || Regex.IsMatch(mac, @"^[0-9A-Fa-f]{12}$"));

        private static byte[] ParseMac(string mac) { if (string.IsNullOrWhiteSpace(mac)) return null; string clean = mac.Replace(":", "").Replace("-", "").Replace(".", "").ToUpper(); if (clean.Length != 12) return null; byte[] b = new byte[6]; for (int i = 0; i < 6; i++) if (!byte.TryParse(clean.Substring(i * 2, 2), System.Globalization.NumberStyles.HexNumber, null, out b[i])) return null; return b; }
    }
}
