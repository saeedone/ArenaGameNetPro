using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Toast notification severity / accent color. Drives the 4px left
    /// border color and the icon shown next to the message.
    /// </summary>
    public enum ToastType
    {
        /// <summary>Blue accent — neutral informational message.</summary>
        Info,
        /// <summary>Green accent — operation completed successfully.</summary>
        Success,
        /// <summary>Yellow accent — non-blocking warning the operator should be aware of.</summary>
        Warning,
        /// <summary>Red accent — recoverable error that does not require a modal dialog.</summary>
        Error,
    }

    /// <summary>
    /// Non-modal, auto-dismissing notification that slides in from the
    /// bottom-right corner of the owner form (or the primary screen if no
    /// owner is supplied). Replaces <see cref="MessageBox.Show(string)"/>
    /// for non-critical success / info / warning / error messages so the
    /// 1Hz status timer (and every other Tick on the UI thread) keeps
    /// running while the operator is notified.
    ///
    /// Features:
    ///  • Borderless 300px-wide form, auto-height based on the wrapped text.
    ///  • 0.95 opacity dark surface with a 4px colored left border per type.
    ///  • Stacks vertically — multiple active toasts never overlap.
    ///  • Auto-dismisses after <paramref name="durationMs"/> (default 3s).
    ///  • Fades out smoothly in the final 500ms.
    ///  • Click anywhere on the toast to dismiss immediately.
    ///  • Thread-safe: <see cref="Show"/> marshals to the UI thread via
    ///    <see cref="Control.BeginInvoke"/> when called from a non-UI thread.
    /// </summary>
    public static class ToastNotification
    {
        // ── layout constants ──────────────────────────────────────────────
        private const int ToastWidth = 300;
        private const int ToastPaddingX = 14;
        private const int ToastPaddingY = 12;
        private const int BorderThickness = 4;       // left accent stripe
        private const int ScreenMarginX = 18;        // gap from the right edge of the owner
        private const int ScreenMarginY = 18;        // gap from the bottom edge of the owner
        private const int StackGap = 10;             // gap between stacked toasts
        private const int FadeOutMs = 500;           // final fade-out window

        // ── active toast registry (one list per owner form) ───────────────
        // Keyed by the owner form so that toasts spawned from the MainForm
        // don't share the same vertical stack as toasts spawned from the
        // ClientMonitorForm. Each entry is the live ToastForm reference so
        // we can walk the stack and reposition survivors when one closes.
        private static readonly Dictionary<Form, List<ToastForm>> _activeToasts
            = new Dictionary<Form, List<ToastForm>>();

        private static readonly object _lock = new object();

        // FIX B9: use Lazy<Font> instead of static readonly Font. The
        // previous static-readonly Font fields were created during type
        // initialization — if ToastNotification was touched before the
        // message pump was ready (e.g. via a unit test, or very early in
        // Program.Main before Application.EnableVisualStyles), the Font
        // constructor could fail and crash the app with a TypeInitialization
        // Exception whose InnerException was opaque. Lazy<Font> defers
        // creation to first use (always inside SpawnToast on the UI thread).
        private static readonly System.Lazy<Font> _toastMsgFont = new System.Lazy<Font>(() => new Font("Segoe UI", 10F));
        private static readonly System.Lazy<Font> _toastGlyphFont = new System.Lazy<Font>(() => new Font("Segoe UI", 14F));

        /// <summary>
        /// Shows a toast notification anchored to the bottom-right of
        /// <paramref name="owner"/>. Safe to call from any thread.
        /// </summary>
        /// <param name="owner">Form the toast is anchored to. If null, the
        /// toast is anchored to the primary screen's working area.</param>
        /// <param name="message">Message text. May contain newlines; the
        /// toast auto-sizes its height to fit the wrapped text.</param>
        /// <param name="type">Severity / accent color.</param>
        /// <param name="durationMs">How long the toast stays visible before
        /// auto-dismissing. Default 3000ms. Must be &gt; FadeOutMs.</param>
        public static void Show(Form owner, string message, ToastType type = ToastType.Info, int durationMs = 3000)
        {
            if (string.IsNullOrEmpty(message)) return;
            if (durationMs < FadeOutMs + 100) durationMs = FadeOutMs + 100;

            // Marshal to the owner's UI thread. BeginInvoke requires a live
            // handle; if the owner is closing/closed or null, fall back to
            // creating the toast on the primary screen directly (still on
            // the calling thread — must be the UI thread in that case).
            try
            {
                if (owner != null && !owner.IsDisposed && owner.IsHandleCreated)
                {
                    if (owner.InvokeRequired)
                    {
                        owner.BeginInvoke((Action)(() => SpawnToast(owner, message, type, durationMs)));
                        return;
                    }
                }
                else if (owner != null && (owner.IsDisposed || !owner.IsHandleCreated))
                {
                    // Owner is gone — anchor to the primary screen instead.
                    owner = null;
                }
            }
            catch (InvalidOperationException)
            {
                // Owner closed between the IsDisposed check and BeginInvoke.
                owner = null;
            }
            catch { return; }

            // We're either on the UI thread already or have no owner — spawn
            // directly. SpawnToast must run on an STA/UI thread because it
            // creates a Form.
            if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            {
                // Last-resort: marshal onto a brand-new STA thread. This is
                // rare (we only get here if owner==null and the caller is a
                // non-UI thread), but it keeps the API contract that Show
                // can be called from anywhere.
                var t = new Thread(() => SpawnToast(null, message, type, durationMs));
                t.SetApartmentState(ApartmentState.STA);
                t.IsBackground = true;
                t.Start();
                return;
            }

            SpawnToast(owner, message, type, durationMs);
        }

        // ── private implementation ────────────────────────────────────────

        private static void SpawnToast(Form owner, string message, ToastType type, int durationMs)
        {
            Color accent = GetAccentColor(type);
            string glyph = GetGlyph(type);

            // Create the borderless toast form.
            var toast = new ToastForm
            {
                Width = ToastWidth,
                // Height is computed below after measuring the message text.
                FormBorderStyle = FormBorderStyle.None,
                ShowInTaskbar = false,
                TopMost = true,
                StartPosition = FormStartPosition.Manual,
                Opacity = 0.0,                 // start invisible; fade in
                BackColor = Color.FromArgb(30, 30, 42),
                ForeColor = Color.White,
                Text = "ToastNotification",
            };
            // ToastForm overrides ShowWithoutActivation to return true so
            // the toast doesn't steal focus from the owner. The
            // WS_EX_NOACTIVATE flag in CreateParams reinforces this at the
            // Win32 level.

            // FIX B1/B9: use the Lazy<Font>.Value for both measuring and the
            // label — no `using` block, so the font is NOT disposed when the
            // label still references it. The label will use the static font
            // for its entire lifetime; we never dispose it. Lazy creation
            // also avoids TypeInitializationException if the type is touched
            // before the message pump is ready.
            int textWidth = ToastWidth - BorderThickness - ToastPaddingX * 2 - 24 /* glyph box */;
            // Use TextRenderer (matches what Label actually renders).
            var sz = TextRenderer.MeasureText(message, _toastMsgFont.Value, new Size(textWidth, int.MaxValue),
                TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
            int textHeight = sz.Height;

            // ── glyph label (icon on the left, after the accent stripe) ──
            var lblGlyph = new Label
            {
                Text = glyph,
                Font = _toastGlyphFont.Value,
                ForeColor = accent,
                BackColor = Color.Transparent,
                Location = new Point(BorderThickness + ToastPaddingX - 2, ToastPaddingY - 2),
                AutoSize = false,
                Size = new Size(28, textHeight),
                TextAlign = ContentAlignment.TopLeft,
            };
            toast.Controls.Add(lblGlyph);

            // ── message label ──
            var lblMsg = new Label
            {
                Text = message,
                Font = _toastMsgFont.Value,
                ForeColor = Color.White,
                BackColor = Color.Transparent,
                Location = new Point(BorderThickness + ToastPaddingX + 28, ToastPaddingY),
                AutoSize = false,
                Size = new Size(textWidth, textHeight),
                TextAlign = ContentAlignment.TopLeft,
            };
            toast.Controls.Add(lblMsg);

            // Final toast height = top pad + text height + bottom pad.
            toast.Height = ToastPaddingY * 2 + textHeight;

            // Custom paint to draw the colored left accent stripe.
            toast.AccentColor = accent;
            toast.PaintToast = (g) =>
            {
                // Subtle drop shadow effect: draw a slightly darker border
                // around the whole form, then the accent stripe on the left.
                using (var pen = new Pen(Color.FromArgb(60, 0, 0, 0), 1))
                    g.DrawRectangle(pen, 0, 0, toast.Width - 1, toast.Height - 1);
                using (var brush = new SolidBrush(accent))
                    g.FillRectangle(brush, 0, 0, BorderThickness, toast.Height);
            };

            // Click anywhere on the toast (or any of its child labels) to
            // dismiss immediately.
            toast.Click += (s, e) => BeginFadeOut(toast);
            foreach (Control c in toast.Controls)
            {
                c.Click += (s, e) => BeginFadeOut(toast);
            }

            // Position the toast at the bottom-right of the owner (or the
            // primary screen). Then walk the active-toast stack so this new
            // toast sits ABOVE any existing toasts for the same owner.
            Rectangle anchorArea = GetAnchorArea(owner);
            Point pos = ComputePosition(toast.Size, anchorArea, owner);
            toast.Location = pos;

            // Register the toast in the per-owner stack BEFORE showing it so
            // any subsequent toast spawned while this one is fading in will
            // stack on top correctly.
            lock (_lock)
            {
                Form key = owner ?? GetSentinelForm();
                if (!_activeToasts.TryGetValue(key, out var stack))
                {
                    stack = new List<ToastForm>();
                    _activeToasts[key] = stack;
                }
                stack.Add(toast);
                toast.Tag = key; // remember the key so OnToastClosed can find it
            }

            // Auto-dismiss after durationMs (starts the fade-out 500ms before
            // the deadline).
            var dismissTimer = new System.Windows.Forms.Timer { Interval = Math.Max(50, durationMs - FadeOutMs) };
            dismissTimer.Tick += (s, e) =>
            {
                dismissTimer.Stop();
                dismissTimer.Dispose();
                BeginFadeOut(toast);
            };
            dismissTimer.Start();

            // Fade-in: 0 → 0.95 in ~120ms.
            toast.FadeIn();

            // Show without activating. We use Show() (not ShowDialog) so it
            // stays non-modal; ShowWithoutActivation + TopMost keeps it on
            // top without stealing focus.
            try { toast.Show(owner); }
            catch (InvalidOperationException)
            {
                // Owner became invalid between the check above and Show.
                try { toast.Show(); } catch { /* give up silently */ }
            }
        }

        /// <summary>
        /// Returns the screen-coordinate rectangle the toast should be
        /// anchored to — the owner form's bounds if supplied, otherwise the
        /// primary screen's working area (excluding the taskbar).
        /// </summary>
        private static Rectangle GetAnchorArea(Form owner)
        {
            try
            {
                if (owner != null && !owner.IsDisposed && owner.Visible)
                    return owner.Bounds;
            }
            catch { }
            return Screen.PrimaryScreen != null
                ? Screen.PrimaryScreen.WorkingArea
                : new Rectangle(0, 0, 1280, 720);
        }

        /// <summary>
        /// Computes the bottom-right position for a toast of the given size,
        /// then walks the active-toast stack for <paramref name="owner"/> so
        /// the new toast sits ABOVE (smaller Y) any toasts already shown.
        /// </summary>
        private static Point ComputePosition(Size toastSize, Rectangle anchorArea, Form owner)
        {
            int x = anchorArea.Right - toastSize.Width - ScreenMarginX;
            int y = anchorArea.Bottom - toastSize.Height - ScreenMarginY;

            lock (_lock)
            {
                Form key = owner ?? GetSentinelForm();
                if (_activeToasts.TryGetValue(key, out var stack))
                {
                    foreach (var t in stack)
                    {
                        try
                        {
                            if (!t.IsDisposed && t.Visible)
                            {
                                // If this toast overlaps our target Y, shift up.
                                int topY = t.Location.Y;
                                int bottomY = topY + t.Height;
                                if (bottomY > y - StackGap - toastSize.Height)
                                {
                                    y = topY - StackGap - toastSize.Height;
                                }
                            }
                        }
                        catch { /* stale entry, skip */ }
                    }
                }
            }

            // Clamp within the anchor area's top edge so the stack never
            // runs off the top of the screen.
            if (y < anchorArea.Top + ScreenMarginY)
                y = anchorArea.Top + ScreenMarginY;

            return new Point(x, y);
        }

        /// <summary>
        /// Begins the fade-out animation. When the toast reaches 0 opacity
        /// it is closed + disposed + removed from the active stack.
        /// </summary>
        private static void BeginFadeOut(ToastForm toast)
        {
            if (toast == null || toast.IsDisposed) return;
            if (toast.IsFadingOut) return; // already fading
            toast.IsFadingOut = true;

            try
            {
                if (toast.InvokeRequired)
                {
                    toast.BeginInvoke((Action)(() => AnimateFadeOut(toast)));
                }
                else
                {
                    AnimateFadeOut(toast);
                }
            }
            catch (InvalidOperationException) { /* toast closed mid-call */ }
            catch { }
        }

        /// <summary>
        /// Runs the fade-out animation on the UI thread. Steps the opacity
        /// from its current value down to 0 in ~500ms using a 30Hz timer.
        /// </summary>
        private static void AnimateFadeOut(ToastForm toast)
        {
            if (toast == null || toast.IsDisposed) return;
            const int stepMs = 30;
            int steps = Math.Max(1, FadeOutMs / stepMs);
            double startOpacity = toast.Opacity;
            var fadeTimer = new System.Windows.Forms.Timer { Interval = stepMs };
            int step = 0;
            fadeTimer.Tick += (s, e) =>
            {
                try
                {
                    step++;
                    double opacity = startOpacity * (1.0 - (double)step / steps);
                    if (opacity <= 0 || step >= steps)
                    {
                        fadeTimer.Stop();
                        fadeTimer.Dispose();
                        OnToastClosed(toast);
                        try { toast.Close(); } catch { }
                        try { toast.Dispose(); } catch { }
                        return;
                    }
                    toast.Opacity = opacity;
                }
                catch
                {
                    try { fadeTimer.Stop(); fadeTimer.Dispose(); } catch { }
                    try { toast.Close(); toast.Dispose(); } catch { }
                }
            };
            fadeTimer.Start();
        }

        /// <summary>
        /// Removes a toast from the active stack and repositions any
        /// toasts that were stacked above it so they slide down to fill
        /// the gap.
        /// </summary>
        private static void OnToastClosed(ToastForm toast)
        {
            try
            {
                lock (_lock)
                {
                    Form key = toast.Tag as Form ?? GetSentinelForm();
                    if (_activeToasts.TryGetValue(key, out var stack))
                    {
                        stack.Remove(toast);
                        if (stack.Count == 0) _activeToasts.Remove(key);
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// Sentinel "form" used as the dictionary key when no owner is
        /// supplied. We can't use null as a dictionary key directly
        /// (Dictionary`2 doesn't allow null keys), so we use a singleton
        /// placeholder.
        ///
        /// FIX B16: previously this was a static field initializer
        /// (`private static readonly Form _sentinelForm = new Form { ... };`)
        /// which created a Form inside the type initializer. Form creation
        /// requires the message pump / handles to be available, and field
        /// initializers run before any UI code — on some hosts (e.g. unit
        /// tests, service contexts, or when the type is touched very early
        /// during startup) this throws or creates a phantom handle that
        /// keeps the app alive after exit. Lazy initialization on first use
        /// defers Form creation to the first Show() call (which always runs
        /// on the UI thread).
        /// </summary>
        private static Form _sentinelForm;
        private static Form GetSentinelForm()
        {
            if (_sentinelForm == null)
            {
                _sentinelForm = new Form
                {
                    Visible = false,
                    ShowInTaskbar = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Size = Size.Empty,
                };
            }
            return _sentinelForm;
        }

        private static Color GetAccentColor(ToastType type)
        {
            switch (type)
            {
                case ToastType.Success: return Color.FromArgb(166, 227, 161); // green
                case ToastType.Warning: return Color.FromArgb(249, 226, 175); // yellow
                case ToastType.Error:   return Color.FromArgb(243, 139, 168); // red
                case ToastType.Info:
                default:                return Color.FromArgb(137, 180, 250); // blue
            }
        }

        private static string GetGlyph(ToastType type)
        {
            switch (type)
            {
                case ToastType.Success: return "✓";
                case ToastType.Warning: return "!";
                case ToastType.Error:   return "✕";
                case ToastType.Info:
                default:                return "ℹ";
            }
        }

        // ────────────────────────────────────────────────────────────────────
        //  ToastForm — the borderless form that hosts a single toast.
        // ────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Borderless top-most form that hosts a single toast notification.
        /// Exposes a paint callback so the static ToastNotification class
        /// can draw the accent stripe without exposing internal state.
        /// </summary>
        private sealed class ToastForm : Form
        {
            /// <summary>Color of the 4px left accent stripe.</summary>
            public Color AccentColor;
            /// <summary>Custom paint callback for the accent stripe.</summary>
            public Action<Graphics> PaintToast;
            /// <summary>True once the fade-out animation has started
            /// (prevents a second click-triggered fade from racing the
            /// auto-dismiss one).</summary>
            public bool IsFadingOut;

            public ToastForm()
            {
                // Enable manual painting so we can draw the accent stripe +
                // the drop-shadow border ourselves.
                SetStyle(ControlStyles.AllPaintingInWmPaint
                       | ControlStyles.UserPaint
                       | ControlStyles.OptimizedDoubleBuffer, true);
            }

            /// <summary>
            /// Override to return true so the toast form is shown without
            /// stealing focus from the owner. Combined with the
            /// WS_EX_NOACTIVATE flag in CreateParams, this keeps keyboard
            /// focus on the owner form when the toast appears.
            /// </summary>
            protected override bool ShowWithoutActivation => true;

            /// <summary>Fades the toast in from 0 to 0.95 opacity.</summary>
            public void FadeIn()
            {
                try
                {
                    const int stepMs = 20;
                    const int totalMs = 120;
                    int steps = Math.Max(1, totalMs / stepMs);
                    double target = 0.95;
                    var t = new System.Windows.Forms.Timer { Interval = stepMs };
                    int step = 0;
                    t.Tick += (s, e) =>
                    {
                        try
                        {
                            step++;
                            double opacity = target * ((double)step / steps);
                            if (opacity >= target || step >= steps)
                            {
                                this.Opacity = target;
                                t.Stop();
                                t.Dispose();
                                return;
                            }
                            this.Opacity = opacity;
                        }
                        catch
                        {
                            try { t.Stop(); t.Dispose(); } catch { }
                        }
                    };
                    t.Start();
                }
                catch { this.Opacity = 0.95; }
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                try
                {
                    var g = e.Graphics;
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    if (PaintToast != null) PaintToast(g);
                }
                catch { }
                // Let the base class draw any child controls (labels).
                // (We can't call base.OnPaint because we use UserPaint, but
                // child controls paint themselves independently.)
            }

            protected override CreateParams CreateParams
            {
                get
                {
                    // WS_EX_NOACTIVATE: prevents the toast from stealing
                    // focus when shown. Combined with ShowWithoutActivation
                    // this keeps keyboard focus on the owner form.
                    var cp = base.CreateParams;
                    cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
                    cp.ExStyle |= 0x00000008; // WS_EX_TOPMOST (redundant with TopMost=true, but explicit)
                    return cp;
                }
            }
        }
    }
}
