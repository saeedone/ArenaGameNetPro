using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages member tier system with points and discounts.
    /// Tiers: Bronze (0%), Silver (5%), Gold (10%), Diamond (15%).
    /// Users earn points from spending and move up tiers automatically.
    /// </summary>
    public class MemberTierManager
    {
        public MemberTier CreateTier(string name, string description, decimal discountPercent, int requiredPoints, decimal minTopUp, string color, string icon)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام سطح عضویت الزامی است");
            if (discountPercent < 0 || discountPercent > 100) throw new ArgumentException("درصد تخفیف باید بین ۰ تا ۱۰۰ باشد");

            Database.Instance.Execute(
                "INSERT INTO member_tiers (name, description, discount_percent, required_points, min_top_up, color, icon, is_active, sort_order) VALUES (@name, @desc, @disc, @pts, @topup, @color, @icon, 1, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM member_tiers))",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue("@disc", discountPercent);
                    cmd.Parameters.AddWithValue("@pts", requiredPoints);
                    cmd.Parameters.AddWithValue("@topup", minTopUp);
                    cmd.Parameters.AddWithValue("@color", color ?? "#89B4FA");
                    cmd.Parameters.AddWithValue("@icon", icon ?? "");
                });

            int id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));
            AuditLog.Log("MemberTier", $"Tier created: {name} ({discountPercent}% discount)");

            return GetTier(id);
        }

        public MemberTier GetTier(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active FROM member_tiers WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new MemberTier
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? "" : r.GetString(2),
                    DiscountPercent = r.GetDecimal(3),
                    RequiredPoints = r.GetInt32(4),
                    MinTopUp = r.GetDecimal(5),
                    Color = r.IsDBNull(6) ? "#89B4FA" : r.GetString(6),
                    Icon = r.IsDBNull(7) ? "" : r.GetString(7),
                    IsActive = r.GetBoolean(8)
                });
        }

        public List<MemberTier> GetAllTiers()
        {
            return Database.Instance.Query(
                "SELECT id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active FROM member_tiers WHERE is_active = 1 ORDER BY sort_order, required_points",
                null,
                r => new MemberTier
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? "" : r.GetString(2),
                    DiscountPercent = r.GetDecimal(3),
                    RequiredPoints = r.GetInt32(4),
                    MinTopUp = r.GetDecimal(5),
                    Color = r.IsDBNull(6) ? "#89B4FA" : r.GetString(6),
                    Icon = r.IsDBNull(7) ? "" : r.GetString(7),
                    IsActive = r.GetBoolean(8)
                });
        }

        /// <summary>
        /// Gets the current tier info for a user, including their points and next tier.
        /// </summary>
        public TierInfoPayload GetUserTierInfo(string username)
        {
            // Ensure user has a tier progress record
            EnsureUserTierProgress(username);

            var progress = Database.Instance.QueryOne(
                "SELECT tier_id, points, total_spent FROM user_tier_progress WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => new { TierId = r.GetInt32(0), Points = r.GetInt32(1), TotalSpent = r.GetDecimal(2) });

            if (progress == null) return null;

            var currentTier = GetTier(progress.TierId);
            var allTiers = GetAllTiers();
            // Sort by RequiredPoints (not by Id) so the "next tier" lookup is
            // robust against admin reordering and out-of-order inserts.
            var orderedTiers = allTiers?.OrderBy(t => t.RequiredPoints).ToList() ?? new List<MemberTier>();
            MemberTier nextTier = null;
            int pointsToNext = 0;

            // Find the next tier above current
            foreach (var tier in orderedTiers)
            {
                if (tier.RequiredPoints > progress.Points)
                {
                    nextTier = tier;
                    pointsToNext = tier.RequiredPoints - progress.Points;
                    break;
                }
            }

            return new TierInfoPayload
            {
                CurrentTier = MapToPayload(currentTier),
                NextTier = nextTier != null ? MapToPayload(nextTier) : null,
                CurrentPoints = progress.Points,
                PointsToNextTier = pointsToNext,
                TotalSpent = progress.TotalSpent
            };
        }

        /// <summary>
        /// Adds points to a user and automatically upgrades their tier if eligible.
        /// Called when a user spends money.
        /// </summary>
        public void AddPointsForSpending(string username, decimal amountSpent)
        {
            EnsureUserTierProgress(username);

            // 1 point per 10,000 Toman spent
            int pointsEarned = (int)(amountSpent / 10000);
            if (pointsEarned <= 0) return;

            Database.Instance.Execute(
                "UPDATE user_tier_progress SET points = points + @pts, total_spent = total_spent + @spent, updated_at = @ua WHERE username = @u",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@pts", pointsEarned);
                    cmd.Parameters.AddWithValue("@spent", amountSpent);
                    cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@u", username);
                });

            // Check for tier upgrade
            CheckTierUpgrade(username);
        }

        /// <summary>
        /// Gets the discount percentage for a user based on their tier.
        /// </summary>
        public decimal GetUserDiscount(string username)
        {
            try
            {
                var info = GetUserTierInfo(username);
                return info?.CurrentTier?.DiscountPercent ?? 0;
            }
            catch { return 0; }
        }

        private void EnsureUserTierProgress(string username)
        {
            var existing = Database.Instance.QueryOne(
                "SELECT id FROM user_tier_progress WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => r.GetInt32(0));

            if (existing == 0)
            {
                // Default to Bronze tier (id=1)
                Database.Instance.Execute(
                    "INSERT INTO user_tier_progress (username, tier_id, points, total_spent, updated_at) VALUES (@u, 1, 0, 0, @ua)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("o"));
                    });
            }
        }

        /// <summary>
        /// Recompute the user's tier from their current point total. Tiers are
        /// ordered by RequiredPoints (NOT by Id) so admin reordering or
        /// out-of-order inserts do not break the upgrade path. The user is
        /// placed in the highest tier whose RequiredPoints is &lt;= their
        /// current points. Persists the new tier_id if it changed.
        /// </summary>
        private void CheckTierUpgrade(string username)
        {
            var progress = Database.Instance.QueryOne(
                "SELECT points, tier_id FROM user_tier_progress WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => new { Points = r.GetInt32(0), TierId = r.GetInt32(1) });

            if (progress == null) return;

            var allTiers = GetAllTiers();
            if (allTiers == null || allTiers.Count == 0) return;

            // Order by RequiredPoints ascending so we can find the highest tier
            // the user qualifies for. (Previous code iterated GetAllTiers() and
            // compared Id — broken if tiers were inserted out of order or
            // reordered by the admin.)
            var ordered = allTiers.OrderBy(t => t.RequiredPoints).ToList();
            int newTierId = ordered[0].Id; // default: lowest tier
            foreach (var tier in ordered)
            {
                if (progress.Points >= tier.RequiredPoints)
                    newTierId = tier.Id;
                else
                    break; // sorted ascending — no later tier will qualify
            }

            if (newTierId != progress.TierId)
            {
                Database.Instance.Execute(
                    "UPDATE user_tier_progress SET tier_id = @tid, updated_at = @ua WHERE username = @u",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@tid", newTierId);
                        cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@u", username);
                    });

                var newTier = GetTier(newTierId);
                AuditLog.Log("MemberTier", $"User {username} upgraded to tier: {newTier.Name}");
            }
        }

        public void UpdateTier(int id, string name, string description, decimal discountPercent, int requiredPoints, decimal minTopUp, string color, string icon, bool isActive)
        {
            Database.Instance.Execute(
                "UPDATE member_tiers SET name = @name, description = @desc, discount_percent = @disc, required_points = @pts, min_top_up = @topup, color = @color, icon = @icon, is_active = @active WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue("@disc", discountPercent);
                    cmd.Parameters.AddWithValue("@pts", requiredPoints);
                    cmd.Parameters.AddWithValue("@topup", minTopUp);
                    cmd.Parameters.AddWithValue("@color", color ?? "#89B4FA");
                    cmd.Parameters.AddWithValue("@icon", icon ?? "");
                    cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                    cmd.Parameters.AddWithValue("@id", id);
                });
            AuditLog.Log("MemberTier", $"Tier updated: {name}");
        }

        private MemberTierPayload MapToPayload(MemberTier tier)
        {
            if (tier == null) return null;
            return new MemberTierPayload
            {
                Id = tier.Id,
                Name = tier.Name,
                Description = tier.Description,
                DiscountPercent = tier.DiscountPercent,
                RequiredPoints = tier.RequiredPoints,
                MinTopUp = tier.MinTopUp,
                Color = tier.Color,
                Icon = tier.Icon,
                IsActive = tier.IsActive
            };
        }
    }

    // Internal model (not shared with client)
    public class MemberTier
    {
        public int Id;
        public string Name;
        public string Description;
        public decimal DiscountPercent;
        public int RequiredPoints;
        public decimal MinTopUp;
        public string Color;
        public string Icon;
        public bool IsActive;
    }
}
