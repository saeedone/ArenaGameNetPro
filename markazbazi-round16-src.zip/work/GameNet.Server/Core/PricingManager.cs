﻿using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Flexible pricing management - hourly rates, minimum charges, rounding rules.
    /// Supports multiple pricing plans and per-station pricing.
    /// </summary>
    public class PricingManager
    {
        public int CreatePlan(string name, decimal pricePerHour, decimal minimumCharge = 0, int roundingMinutes = 10)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام تعرفه نمی‌تواند خالی باشد");
            if (pricePerHour <= 0) throw new ArgumentException("قیمت ساعتی باید بیشتر از صفر باشد");

            if (minimumCharge <= 0) minimumCharge = Math.Round(pricePerHour / 6, 0);

            Database.Instance.Execute(
                "INSERT INTO pricing (name, price_per_hour, minimum_charge, rounding_minutes, is_default, created_at) VALUES (@n, @p, @m, @r, 0, @c)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@p", pricePerHour);
                    cmd.Parameters.AddWithValue("@m", minimumCharge);
                    cmd.Parameters.AddWithValue("@r", roundingMinutes);
                    cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                });

            AuditLog.Log("PricingManager", $"Pricing plan '{name}' created: {pricePerHour:N0} تومان/ساعت");
            return (int)Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt64(0));
        }

        public PricingPlan GetDefaultPlan()
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, price_per_hour, minimum_charge, rounding_minutes, is_default FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1",
                null, MapPlan) ?? GetPlan(1);
        }

        public PricingPlan GetPlan(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, price_per_hour, minimum_charge, rounding_minutes, is_default FROM pricing WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id), MapPlan);
        }

        public List<PricingPlan> GetAllPlans()
        {
            return Database.Instance.Query(
                "SELECT id, name, price_per_hour, minimum_charge, rounding_minutes, is_default FROM pricing ORDER BY id",
                null, MapPlan);
        }

        public void UpdatePlan(int id, string name = null, decimal? pricePerHour = null,
            decimal? minimumCharge = null, int? roundingMinutes = null)
        {
            var sets = new List<string>();
            if (name != null) sets.Add("name = @n");
            if (pricePerHour.HasValue) sets.Add("price_per_hour = @p");
            if (minimumCharge.HasValue) sets.Add("minimum_charge = @m");
            if (roundingMinutes.HasValue) sets.Add("rounding_minutes = @r");
            if (sets.Count == 0) return;

            Database.Instance.Execute(
                $"UPDATE pricing SET {string.Join(", ", sets)} WHERE id = @id",
                cmd =>
                {
                    if (name != null) cmd.Parameters.AddWithValue("@n", name);
                    if (pricePerHour.HasValue) cmd.Parameters.AddWithValue("@p", pricePerHour.Value);
                    if (minimumCharge.HasValue) cmd.Parameters.AddWithValue("@m", minimumCharge.Value);
                    if (roundingMinutes.HasValue) cmd.Parameters.AddWithValue("@r", roundingMinutes.Value);
                    cmd.Parameters.AddWithValue("@id", id);
                });

            AuditLog.Log("PricingManager", $"Pricing plan {id} updated");
        }

        public void SetDefaultPlan(int id)
        {
            Database.Instance.Execute("UPDATE pricing SET is_default = 0");
            Database.Instance.Execute("UPDATE pricing SET is_default = 1 WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("PricingManager", $"Default pricing plan set to {id}");
        }

        public void DeletePlan(int id)
        {
            var plan = GetPlan(id);
            if (plan != null && plan.IsDefault)
                throw new InvalidOperationException("نمی‌توان تعرفه پیش‌فرض را حذف کرد");

            Database.Instance.Execute("DELETE FROM pricing WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("PricingManager", $"Pricing plan {id} deleted");
        }

        /// <summary>
        /// Calculate session cost based on pricing plan.
        /// </summary>
        public decimal CalculateCost(int planId, int minutes)
        {
            var plan = GetPlan(planId);
            if (plan == null) plan = GetDefaultPlan();
            if (plan == null) return 0;

            // Round up to nearest rounding interval
            int roundedMinutes = minutes;
            if (plan.RoundingMinutes > 1)
            {
                roundedMinutes = ((minutes + plan.RoundingMinutes - 1) / plan.RoundingMinutes) * plan.RoundingMinutes;
            }

            decimal cost = Math.Round(plan.PricePerHour / 60 * roundedMinutes, 0);

            // Apply minimum charge
            if (cost < plan.MinimumCharge && minutes > 0)
                cost = plan.MinimumCharge;

            return cost;
        }

        /// <summary>
        /// Calculate remaining time from balance.
        /// </summary>
        public int CalculateRemainingMinutes(decimal balance, int planId = 0)
        {
            var plan = planId > 0 ? GetPlan(planId) : GetDefaultPlan();
            if (plan == null || plan.PricePerHour <= 0) return int.MaxValue;
            return (int)(balance / plan.PricePerHour * 60);
        }

        private PricingPlan MapPlan(System.Data.Common.DbDataReader r)
        {
            return new PricingPlan
            {
                Id = r.GetInt32(0), Name = r.GetString(1),
                PricePerHour = r.GetDecimal(2), MinimumCharge = r.GetDecimal(3),
                RoundingMinutes = r.GetInt32(4), IsDefault = r.GetBoolean(5)
            };
        }
    }

    public class PricingPlan
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal PricePerHour { get; set; }
        public decimal MinimumCharge { get; set; }
        public int RoundingMinutes { get; set; }
        public bool IsDefault { get; set; }
    }
}
