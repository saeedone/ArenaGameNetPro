using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 3: VIP membership system.
    ///
    /// Loyalty tiers awarded by play-spend:
    ///   Bronze    0-99    pts → 0%  discount
    ///   Silver    100-499 pts → 5%  discount
    ///   Gold      500-1999 pts → 10% discount
    ///   Platinum  2000+   pts → 15% discount
    ///
    /// Points: 1 point per 1000 Toman spent. Stored in the `vip_points`
    /// column on the users table (added by the v17 schema migration).
    ///
    /// Distinct from <see cref="MemberTierManager"/> — the latter is the
    /// configurable, multi-tier member-pricing subsystem that already
    /// existed in this codebase. VipManager is the simpler, spec-defined
    /// loyalty programme that the task asked for. Both can coexist:
    /// MemberTierManager owns the member_tiers/user_tier_progress tables,
    /// VipManager owns the vip_points column on users.
    /// </summary>
    public static class VipManager
    {
        private const int PointsPer1000Toman = 1;
        private const int SilverThreshold = 100;
        private const int GoldThreshold = 500;
        private const int PlatinumThreshold = 2000;

        /// <summary>
        /// Awards VIP points for a session spend. Called from
        /// ClientCommunicator.EndSession after the user's balance is
        /// deducted. 1 point per 1000 Toman (rounded down). No-op on
        /// empty usernames or non-positive amounts.
        /// </summary>
        public static int AddPoints(string username, decimal amountSpent)
        {
            if (string.IsNullOrEmpty(username) || amountSpent <= 0) return 0;
            int points = (int)Math.Floor(amountSpent / 1000m) * PointsPer1000Toman;
            if (points <= 0) return 0;
            try
            {
                Database.Instance.Execute(
                    "UPDATE users SET vip_points = vip_points + @p WHERE username = @u",
                    cmd => { cmd.Parameters.AddWithValue("@p", points); cmd.Parameters.AddWithValue("@u", username); });
                AuditLog.Log("VIP", $"Awarded {points} points to {username} (spent {amountSpent:N0})");
                return points;
            }
            catch (Exception ex)
            {
                AuditLog.Log("VIP", $"AddPoints error for {username}: {ex.Message}");
                return 0;
            }
        }

        /// <summary>Current VIP point balance for the user (0 if not found).</summary>
        public static int GetPoints(string username)
        {
            if (string.IsNullOrEmpty(username)) return 0;
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT vip_points FROM users WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", username),
                    r => r.IsDBNull(0) ? 0 : r.GetInt32(0));
            }
            catch { return 0; }
        }

        /// <summary>Tier name (Bronze / Silver / Gold / Platinum) for the user.</summary>
        public static string GetTier(string username)
        {
            return TierName(GetPoints(username));
        }

        /// <summary>Discount percentage (0/5/10/15) for the user.</summary>
        public static decimal GetDiscountPercent(string username)
        {
            return TierDiscount(GetPoints(username));
        }

        /// <summary>
        /// Top N VIP members by points. Returns username, display name,
        /// points, tier, discount. N defaults to 10 (used by the VIP panel).
        /// </summary>
        public static List<VipMemberInfo> GetAllVipMembers(int top = 10)
        {
            try
            {
                var rows = Database.Instance.Query(
                    "SELECT username, display_name, vip_points FROM users WHERE vip_points > 0 ORDER BY vip_points DESC LIMIT @lim",
                    cmd => cmd.Parameters.AddWithValue("@lim", top),
                    r => new VipMemberInfo
                    {
                        Username = r.GetString(0),
                        DisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                        Points = r.IsDBNull(2) ? 0 : r.GetInt32(2)
                    });
                foreach (var m in rows) { m.Tier = TierName(m.Points); m.DiscountPercent = TierDiscount(m.Points); }
                return rows;
            }
            catch (Exception ex)
            {
                AuditLog.Log("VIP", "GetAllVipMembers error: " + ex.Message);
                return new List<VipMemberInfo>();
            }
        }

        /// <summary>
        /// Manually adjusts a user's VIP points by delta (can be negative
        /// to subtract). Used by the operator from the VIP panel.
        /// </summary>
        public static void AdjustPoints(string username, int delta)
        {
            if (string.IsNullOrEmpty(username) || delta == 0) return;
            try
            {
                // Use MAX(0, ...) so points can never go negative.
                Database.Instance.Execute(
                    "UPDATE users SET vip_points = MAX(0, vip_points + @d) WHERE username = @u",
                    cmd => { cmd.Parameters.AddWithValue("@d", delta); cmd.Parameters.AddWithValue("@u", username); });
                AuditLog.Log("VIP", $"Operator adjusted {username} points by {delta}");
            }
            catch (Exception ex)
            {
                AuditLog.Log("VIP", $"AdjustPoints error for {username}: {ex.Message}");
            }
        }

        // ---- tier helpers ----

        public static string TierName(int points)
        {
            if (points >= PlatinumThreshold) return "Platinum";
            if (points >= GoldThreshold) return "Gold";
            if (points >= SilverThreshold) return "Silver";
            return "Bronze";
        }

        public static decimal TierDiscount(int points)
        {
            if (points >= PlatinumThreshold) return 15m;
            if (points >= GoldThreshold) return 10m;
            if (points >= SilverThreshold) return 5m;
            return 0m;
        }

        public static string TierIcon(string tier)
        {
            switch (tier)
            {
                case "Platinum": return "💎";
                case "Gold": return "🥇";
                case "Silver": return "🥈";
                default: return "🥉";
            }
        }
    }

    /// <summary>
    /// Lightweight DTO for the VIP panel grid. Populated by
    /// <see cref="VipManager.GetAllVipMembers"/>.
    /// </summary>
    public class VipMemberInfo
    {
        public string Username;
        public string DisplayName;
        public int Points;
        public string Tier;
        public decimal DiscountPercent;
    }
}
