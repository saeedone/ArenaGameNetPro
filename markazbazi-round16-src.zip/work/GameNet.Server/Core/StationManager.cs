using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages workstation/station records - unlimited terminals support.
    /// Each station has a name, IP, MAC, pricing plan, and status.
    /// </summary>
    public class StationManager
    {
        public int CreateStation(string name, string ipAddress = "", string macAddress = "",
            int? pricingPlanId = null, string category = "", string notes = "")
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام ایستگاه نمی‌تواند خالی باشد");

            Database.Instance.Execute(
                "INSERT INTO stations (name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at) VALUES (@n, @ip, @mac, @pid, @cat, 'available', @notes, @c)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@ip", ipAddress ?? "");
                    cmd.Parameters.AddWithValue("@mac", macAddress ?? "");
                    cmd.Parameters.AddWithValue("@pid", (object)pricingPlanId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@cat", category ?? "");
                    cmd.Parameters.AddWithValue("@notes", notes ?? "");
                    cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                });

            AuditLog.Log("StationManager", $"Station '{name}' created");
            return (int)Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt64(0));
        }

        public StationInfo FindById(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at FROM stations WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id), MapStation);
        }

        public StationInfo FindByName(string name)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at FROM stations WHERE name = @n",
                cmd => cmd.Parameters.AddWithValue("@n", name), MapStation);
        }

        public List<StationInfo> GetAllStations()
        {
            return Database.Instance.Query(
                "SELECT id, name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at FROM stations ORDER BY name",
                null, MapStation);
        }

        public PagedResult<StationInfo> GetStationsPaged(int page, int pageSize, string search = "")
        {
            string where = "";
            Action<SQLiteCommand> param = null;
            if (!string.IsNullOrWhiteSpace(search))
            {
                where = " WHERE name LIKE @q OR ip_address LIKE @q OR category LIKE @q";
                param = cmd => cmd.Parameters.AddWithValue("@q", $"%{search}%");
            }

            return Database.Instance.QueryPaged(
                $"SELECT id, name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at FROM stations{where} ORDER BY name",
                $"SELECT COUNT(*) FROM stations{where}",
                page, pageSize, param, MapStation);
        }

        public void UpdateStation(int id, string name = null, string ipAddress = null,
            string macAddress = null, int? pricingPlanId = null, string category = null,
            string status = null, string notes = null)
        {
            var sets = new List<string>();
            if (name != null) sets.Add("name = @n");
            if (ipAddress != null) sets.Add("ip_address = @ip");
            if (macAddress != null) sets.Add("mac_address = @mac");
            if (pricingPlanId.HasValue) sets.Add("pricing_plan_id = @pid");
            if (category != null) sets.Add("category = @cat");
            if (status != null) sets.Add("status = @s");
            if (notes != null) sets.Add("notes = @notes");
            if (sets.Count == 0) return;

            Database.Instance.Execute(
                $"UPDATE stations SET {string.Join(", ", sets)} WHERE id = @id",
                cmd =>
                {
                    if (name != null) cmd.Parameters.AddWithValue("@n", name);
                    if (ipAddress != null) cmd.Parameters.AddWithValue("@ip", ipAddress);
                    if (macAddress != null) cmd.Parameters.AddWithValue("@mac", macAddress);
                    if (pricingPlanId.HasValue) cmd.Parameters.AddWithValue("@pid", pricingPlanId.Value);
                    if (category != null) cmd.Parameters.AddWithValue("@cat", category);
                    if (status != null) cmd.Parameters.AddWithValue("@s", status);
                    if (notes != null) cmd.Parameters.AddWithValue("@notes", notes);
                    cmd.Parameters.AddWithValue("@id", id);
                });
        }

        public void DeleteStation(int id)
        {
            Database.Instance.Execute("DELETE FROM stations WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("StationManager", $"Station {id} deleted");
        }

        /// <summary>
        /// Auto-create stations from network scan results.
        /// </summary>
        public int AutoCreateFromScan(List<ScannedDevice> devices)
        {
            int created = 0;
            foreach (var device in devices)
            {
                if (!device.IsGameNetClient) continue;

                // Check if station already exists
                var existing = Database.Instance.QueryOne(
                    "SELECT id FROM stations WHERE ip_address = @ip OR mac_address = @mac",
                    cmd => { cmd.Parameters.AddWithValue("@ip", device.IpAddress); cmd.Parameters.AddWithValue("@mac", device.MacAddress); },
                    r => r.GetInt32(0));

                if (existing == 0)
                {
                    string name = !string.IsNullOrWhiteSpace(device.Hostname)
                        ? device.Hostname.Split('.')[0]
                        : $"PC-{device.IpAddress.Split('.').Last()}";

                    CreateStation(name, device.IpAddress, device.MacAddress);
                    created++;
                }
            }

            AuditLog.Log("StationManager", $"Auto-created {created} stations from network scan");
            return created;
        }

        /// <summary>
        /// Get income per station for a given period.
        /// </summary>
        public List<StationIncome> GetStationIncome(DateTime from, DateTime to)
        {
            return Database.Instance.Query(
                @"SELECT s.name, COUNT(cs.id), COALESCE(SUM(cs.total_cost), 0), COALESCE(SUM(cs.duration_minutes), 0)
                  FROM stations s
                  LEFT JOIN client_sessions cs ON cs.station_name = s.name
                    AND cs.start_time >= @from AND cs.start_time <= @to
                  GROUP BY s.name ORDER BY s.name",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@from", from.ToString("o"));
                    cmd.Parameters.AddWithValue("@to", to.ToString("o"));
                },
                r => new StationIncome
                {
                    StationName = r.GetString(0),
                    TotalSessions = r.GetInt32(1),
                    TotalIncome = r.GetDecimal(2),
                    TotalMinutes = r.GetInt32(3)
                });
        }

        private StationInfo MapStation(System.Data.Common.DbDataReader r)
        {
            return new StationInfo
            {
                Id = r.GetInt32(0), Name = r.GetString(1),
                IpAddress = r.IsDBNull(2) ? "" : r.GetString(2),
                MacAddress = r.IsDBNull(3) ? "" : r.GetString(3),
                PricingPlanId = r.IsDBNull(4) ? (int?)null : r.GetInt32(4),
                Category = r.IsDBNull(5) ? "" : r.GetString(5),
                Status = r.IsDBNull(6) ? "available" : r.GetString(6),
                Notes = r.IsDBNull(7) ? "" : r.GetString(7),
                CreatedAt = r.GetDateTime(8)
            };
        }
    }

    public class StationInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string IpAddress { get; set; }
        public string MacAddress { get; set; }
        public int? PricingPlanId { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class StationIncome
    {
        public string StationName { get; set; }
        public int TotalSessions { get; set; }
        public decimal TotalIncome { get; set; }
        public int TotalMinutes { get; set; }
    }
}
