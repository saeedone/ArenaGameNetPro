using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase — Client license / station registration system.
    ///
    /// The operator pre-registers each kiosk station (name + optional MAC).
    /// On first connect, the kiosk presents its machine fingerprint
    /// (machine name + MAC + CPU ID hash); the server checks it against
    /// the registered stations. If registered, the server issues a signed
    /// license token (HMAC) the client caches for subsequent connections.
    /// Unregistered kiosks are rejected (or placed in a "pending approval"
    /// queue the operator can approve).
    ///
    /// Tables:
    ///   client_licenses (id, station_name, machine_fingerprint, mac_address,
    ///                    license_token, is_approved, is_revoked, approved_by,
    ///                    approved_at, created_at, last_seen_at, notes)
    /// </summary>
    public class ClientLicenseManager
    {
        /// <summary>
        /// Returns the HMAC key used to sign license tokens. Derived from
        /// the deployment's master.key so only this server can issue valid
        /// tokens.
        /// </summary>
        private static byte[] GetLicenseKey()
        {
            try { DataEncryption.Initialize(); } catch { }
            // Read master.key directly (DataEncryption caches its key privately)
            string keyPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "master.key");
            byte[] secret = System.IO.File.ReadAllBytes(keyPath);
            using (var sha = SHA256.Create())
            {
                byte[] label = Encoding.UTF8.GetBytes("client-license-key");
                byte[] buf = new byte[label.Length + secret.Length];
                Buffer.BlockCopy(label, 0, buf, 0, label.Length);
                Buffer.BlockCopy(secret, 0, buf, label.Length, secret.Length);
                return sha.ComputeHash(buf);
            }
        }

        /// <summary>
        /// Registers a new station. Returns the license token the client
        /// should use. Throws if the station name or fingerprint is already
        /// registered.
        /// </summary>
        public (int Id, string LicenseToken) RegisterStation(string stationName, string machineFingerprint, string macAddress, string approvedBy, string notes = "")
        {
            if (string.IsNullOrWhiteSpace(stationName)) throw new ArgumentException("نام ایستگاه الزامی است");
            if (string.IsNullOrWhiteSpace(machineFingerprint)) throw new ArgumentException("اثر انگشت ماشین الزامی است");

            // Check for duplicates
            int dupName = Database.Instance.QueryOne(
                "SELECT COUNT(*) FROM client_licenses WHERE station_name = @n AND is_revoked = 0",
                cmd => cmd.Parameters.AddWithValue("@n", stationName),
                r => r.GetInt32(0));
            if (dupName > 0) throw new InvalidOperationException("این نام ایستگاه قبلاً ثبت شده است");

            string token = GenerateLicenseToken(stationName, machineFingerprint);
            int id = 0;

            Database.Instance.ExecuteInTransaction(tx =>
            {
                Database.Instance.Execute(
                    "INSERT INTO client_licenses (station_name, machine_fingerprint, mac_address, license_token, is_approved, is_revoked, approved_by, approved_at, created_at, notes) " +
                    "VALUES (@n, @f, @m, @t, 1, 0, @ab, @aa, @c, @no)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@n", stationName);
                        cmd.Parameters.AddWithValue("@f", machineFingerprint);
                        cmd.Parameters.AddWithValue("@m", macAddress ?? "");
                        cmd.Parameters.AddWithValue("@t", token);
                        cmd.Parameters.AddWithValue("@ab", approvedBy ?? "operator");
                        cmd.Parameters.AddWithValue("@aa", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@no", notes ?? "");
                    }, tx);
                id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });

            AuditLog.Log("License", $"Station '{stationName}' registered (id #{id}) by {approvedBy}");
            return (id, token);
        }

        /// <summary>
        /// Validates a client's connection. Called by ClientCommunicator at
        /// ClientHello time. Returns (approved, reason).
        ///   - If the client presents a license token, verify it.
        ///   - Else, look up by machine fingerprint. If registered &
        ///     approved, OK. If registered but not approved, pending. If not
        ///     registered at all, reject (or auto-add as pending, configurable).
        /// </summary>
        public (bool Approved, string Reason, string StationName) ValidateConnection(string machineFingerprint, string macAddress, string licenseToken, string clientHelloStationName)
        {
            // 1. Try license token first (fast path for returning kiosks)
            if (!string.IsNullOrEmpty(licenseToken))
            {
                var row = Database.Instance.QueryOne(
                    "SELECT id, station_name, machine_fingerprint, is_approved, is_revoked FROM client_licenses WHERE license_token = @t",
                    cmd => cmd.Parameters.AddWithValue("@t", licenseToken),
                    r => (Id: r.GetInt32(0), StationName: r.GetString(1), Fp: r.GetString(2), Approved: r.GetBoolean(3), Revoked: r.GetBoolean(4)));

                if (!row.Equals(default))
                {
                    if (row.Revoked) return (false, "لایسنس این کلاینت باطل شده است.", row.StationName);
                    if (!row.Approved) return (false, "این کلاینت هنوز تأیید نشده است.", row.StationName);
                    // Verify fingerprint matches (detects token theft)
                    if (!string.IsNullOrEmpty(row.Fp) && row.Fp != machineFingerprint)
                        return (false, "اثر انگشت ماشین با لایسنس مطابقت ندارد — احتمال سرقت توکن.", row.StationName);

                    // Update last seen
                    Database.Instance.Execute(
                        "UPDATE client_licenses SET last_seen_at = @t WHERE id = @id",
                        cmd => { cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", row.Id); });
                    return (true, "OK", row.StationName);
                }
            }

            // 2. Look up by fingerprint
            if (!string.IsNullOrEmpty(machineFingerprint))
            {
                var row = Database.Instance.QueryOne(
                    "SELECT id, station_name, is_approved, is_revoked FROM client_licenses WHERE machine_fingerprint = @f",
                    cmd => cmd.Parameters.AddWithValue("@f", machineFingerprint),
                    r => (Id: r.GetInt32(0), StationName: r.GetString(1), Approved: r.GetBoolean(2), Revoked: r.GetBoolean(3)));

                if (!row.Equals(default))
                {
                    if (row.Revoked) return (false, "لایسنس این کلاینت باطل شده است.", row.StationName);
                    if (!row.Approved) return (false, "این کلاینت هنوز تأیید نشده است.", row.StationName);
                    Database.Instance.Execute(
                        "UPDATE client_licenses SET last_seen_at = @t WHERE id = @id",
                        cmd => { cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", row.Id); });
                    return (true, "OK", row.StationName);
                }
            }

            // 3. Not registered — auto-approve is ON by default so first-run
            // deployments work out of the box. The operator can turn it off
            // from the license management tab once all kiosks are registered.
            bool autoApprove = true;
            try
            {
                var v = Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = 'license_auto_approve'",
                    null, r => r.GetString(0));
                // Only honor the setting if it was explicitly set (non-empty)
                if (!string.IsNullOrEmpty(v)) bool.TryParse(v, out autoApprove);
            }
            catch { }

            if (autoApprove)
            {
                // Auto-register as a new pending station
                string safeFp = string.IsNullOrEmpty(machineFingerprint) ? "UNKNOWN" : machineFingerprint;
                string fpPrefix = safeFp.Length >= 6 ? safeFp.Substring(0, 6).ToUpperInvariant() : safeFp.ToUpperInvariant().PadRight(6, '0');
                string autoName = string.IsNullOrEmpty(clientHelloStationName) ? ("KIOSK-" + fpPrefix) : clientHelloStationName;
                try
                {
                    var (id, token) = RegisterStation(autoName, safeFp, macAddress, "auto-approve", "Auto-registered on first connect");
                    return (true, "OK (auto-registered)", autoName);
                }
                catch
                {
                    // AutoName collision — try with a suffix
                    try
                    {
                        autoName = autoName + "-" + fpPrefix;
                        var (id, token) = RegisterStation(autoName, safeFp, macAddress, "auto-approve", "Auto-registered (collision retry)");
                        return (true, "OK (auto-registered)", autoName);
                    }
                    catch { /* fall through to reject */ }
                }
            }

            // 4. Otherwise, add as pending and reject for now
            try
            {
                string safeFp2 = string.IsNullOrEmpty(machineFingerprint) ? "UNKNOWN" : machineFingerprint;
                string fpPrefix2 = safeFp2.Length >= 6 ? safeFp2.Substring(0, 6).ToUpperInvariant() : safeFp2.ToUpperInvariant().PadRight(6, '0');
                string pendingName = string.IsNullOrEmpty(clientHelloStationName) ? ("PENDING-" + fpPrefix2) : clientHelloStationName;
                Database.Instance.Execute(
                    "INSERT INTO client_licenses (station_name, machine_fingerprint, mac_address, license_token, is_approved, is_revoked, approved_by, approved_at, created_at, notes) " +
                    "VALUES (@n, @f, @m, '', 0, 0, '', NULL, @c, 'Pending approval')",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@n", pendingName);
                        cmd.Parameters.AddWithValue("@f", machineFingerprint);
                        cmd.Parameters.AddWithValue("@m", macAddress ?? "");
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                    });
            }
            catch { }

            return (false, "کلاینت ثبت نشده — منتظر تأیید اپراتور.", clientHelloStationName ?? "");
        }

        /// <summary>Approves a pending client.</summary>
        public string ApproveClient(int id, string approvedBy)
        {
            var row = Database.Instance.QueryOne(
                "SELECT station_name, machine_fingerprint FROM client_licenses WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => (StationName: r.GetString(0), Fp: r.GetString(1)));

            if (row.Equals(default)) throw new KeyNotFoundException("کلاینت یافت نشد");

            string token = GenerateLicenseToken(row.StationName, row.Fp);
            Database.Instance.Execute(
                "UPDATE client_licenses SET is_approved = 1, approved_by = @ab, approved_at = @aa, license_token = @t WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@ab", approvedBy ?? "operator");
                    cmd.Parameters.AddWithValue("@aa", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@t", token);
                    cmd.Parameters.AddWithValue("@id", id);
                });
            AuditLog.Log("License", $"Client #{id} ('{row.StationName}') approved by {approvedBy}");
            return token;
        }

        /// <summary>Revokes a client license.</summary>
        public void RevokeClient(int id, string reason = "")
        {
            Database.Instance.Execute(
                "UPDATE client_licenses SET is_revoked = 1, notes = COALESCE(notes,'') || ' | revoked: ' || @r WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@r", reason); cmd.Parameters.AddWithValue("@id", id); });
            AuditLog.Log("License", $"Client #{id} revoked: {reason}");
        }

        /// <summary>Returns all registered clients (for the management UI).</summary>
        public List<(int Id, string StationName, string Fingerprint, string Mac, bool Approved, bool Revoked, string ApprovedBy, DateTime? ApprovedAt, DateTime? LastSeenAt, string Notes)> GetAllClients()
        {
            return Database.Instance.Query(
                "SELECT id, station_name, machine_fingerprint, mac_address, is_approved, is_revoked, COALESCE(approved_by,''), approved_at, last_seen_at, COALESCE(notes,'') FROM client_licenses ORDER BY id DESC",
                null,
                r => (
                    r.GetInt32(0),
                    r.GetString(1),
                    r.GetString(2),
                    r.IsDBNull(3) ? "" : r.GetString(3),
                    r.GetBoolean(4),
                    r.GetBoolean(5),
                    r.IsDBNull(6) ? "" : r.GetString(6),
                    r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                    r.IsDBNull(8) ? (DateTime?)null : r.GetDateTime(8),
                    r.IsDBNull(9) ? "" : r.GetString(9)
                ));
        }

        /// <summary>Returns only pending (not approved) clients.</summary>
        public List<(int Id, string StationName, string Fingerprint, string Mac, DateTime CreatedAt)> GetPendingClients()
        {
            return Database.Instance.Query(
                "SELECT id, station_name, machine_fingerprint, mac_address, created_at FROM client_licenses WHERE is_approved = 0 AND is_revoked = 0 ORDER BY created_at DESC",
                null,
                r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.IsDBNull(3) ? "" : r.GetString(3), r.GetDateTime(4)));
        }

        // ---- Token generation ----

        private string GenerateLicenseToken(string stationName, string fingerprint)
        {
            // token = base64(stationName || fingerprint || expiry || HMAC(stationName || fingerprint || expiry))
            string expiry = DateTime.UtcNow.AddYears(5).ToString("o");
            string payload = stationName + "|" + fingerprint + "|" + expiry;
            byte[] payloadBytes = Encoding.UTF8.GetBytes(payload);
            byte[] mac;
            using (var hmac = new HMACSHA256(GetLicenseKey()))
                mac = hmac.ComputeHash(payloadBytes);
            byte[] tokenBytes = new byte[payloadBytes.Length + mac.Length];
            Buffer.BlockCopy(payloadBytes, 0, tokenBytes, 0, payloadBytes.Length);
            Buffer.BlockCopy(mac, 0, tokenBytes, payloadBytes.Length, mac.Length);
            return "LIC1:" + Convert.ToBase64String(tokenBytes);
        }

        /// <summary>
        /// *** DO NOT USE FOR PRE-REGISTRATION ***
        /// FIX H2: This server-side fingerprint generator is retained for
        /// internal/test use only. It CANNOT produce a fingerprint that
        /// matches what the client sends in ClientHello, because the client
        /// computes its fingerprint with the REAL Windows ProductId (read from
        /// the registry), which the server doesn't know. Calling this with
        /// windowsSerial="" (as the operator UI previously did) produces a
        /// fingerprint SHA256(name|mac|) that will NEVER match the client's
        /// SHA256(name|mac|<ProductId>).
        ///
        /// The correct registration flow is:
        ///   1. Let the client connect (auto-approve is ON by default).
        ///   2. The server stores the client-sent fingerprint verbatim.
        ///   3. If the operator wants to pre-register, they must paste the
        ///      fingerprint the client printed/sent on its first connect.
        /// </summary>
        public static string GenerateFingerprint(string machineName, string macAddress, string windowsSerial = "")
        {
            string combined = (machineName ?? "") + "|" + (macAddress ?? "") + "|" + (windowsSerial ?? "");
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(combined));
                var sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
    }
}
