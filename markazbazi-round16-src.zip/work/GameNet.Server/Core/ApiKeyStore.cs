using System;
using System.IO;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX SEC-3: persisted read-only + admin API keys, shared by
    /// MobileApiController (which owned this logic exclusively before) and
    /// WebSocketServer (which had NO authentication at all — see the fix in
    /// MainForm.StartWebSocket / WebSocketServer's constructor call site).
    ///
    /// The WebSocket live-events feed (client connect/disconnect, session
    /// start/end with username + cost) is read-only data, so it reuses the
    /// same "readonly_key" the mobile API already generates and persists to
    /// api_key.txt — no new secret, no new file, and turning on the mobile
    /// API and the WebSocket feed both authenticate against the one key an
    /// operator already has to hand out.
    /// </summary>
    public static class ApiKeyStore
    {
        private const string ApiKeyFile = "api_key.txt";

        public static string GenerateApiKey()
        {
            using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create())
            {
                var bytes = new byte[32]; rng.GetBytes(bytes);
                return Convert.ToBase64String(bytes).Replace("/", "_").Replace("+", "-").TrimEnd('=');
            }
        }

        /// <summary>Loads read-only + admin API keys from api_key.txt, or generates + persists new ones.</summary>
        public static (string ReadonlyKey, string AdminKey) LoadOrGenerateKeys()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ApiKeyFile);
            try
            {
                if (File.Exists(path))
                {
                    var lines = File.ReadAllLines(path);
                    string ro = null, adm = null;
                    foreach (var line in lines)
                    {
                        var p = line.Split(new[] { '=' }, 2);
                        if (p.Length == 2)
                        {
                            if (p[0].Trim() == "readonly_key") ro = p[1].Trim();
                            else if (p[0].Trim() == "admin_key") adm = p[1].Trim();
                        }
                    }
                    if (!string.IsNullOrEmpty(ro) && !string.IsNullOrEmpty(adm))
                        return (ro, adm);
                }
            }
            catch (Exception ex) { AuditLog.Log("API", "Error reading api_key.txt: " + ex.Message); }

            // Generate new keys
            string nro = GenerateApiKey();
            string nadm = GenerateApiKey();
            try
            {
                File.WriteAllText(path, $"readonly_key={nro}{Environment.NewLine}admin_key={nadm}{Environment.NewLine}");
                AuditLog.Log("API", "New API keys generated and saved to " + path);
            }
            catch (Exception ex) { AuditLog.Log("API", "Could not persist api_key.txt: " + ex.Message); }
            return (nro, nadm);
        }
    }
}
