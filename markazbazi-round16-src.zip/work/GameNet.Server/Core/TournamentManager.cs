using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 4: Tournament system.
    ///
    /// A simple competition manager: the operator creates a tournament
    /// (name, game, entry fee, prize, max participants, start time),
    /// users register for it, and the operator later records the winner
    /// + runner-up. Tables `tournaments` and `tournament_participants`
    /// are created by Database.Initialize (see Database.CreateTables).
    ///
    /// Minimal-but-working implementation: no bracket/match tracking,
    /// just create/register/result. Designed to be extensible — adding
    /// a bracket stage would mean adding a `matches` table with
    /// tournament_id, round, p1_username, p2_username, winner_username
    /// columns and the matching methods here.
    /// </summary>
    public class TournamentManager
    {
        /// <summary>
        /// Creates a new tournament. Returns the new tournament's id
        /// (0 on failure — caller should check).
        /// </summary>
        /// <remarks>
        /// FIX B6: the INSERT and the SELECT last_insert_rowid() are now
        /// wrapped in a single `lock (Database.Instance)` so a concurrent
        /// CreateTournament call on another thread can't slip its INSERT
        /// in between ours and our last_insert_rowid() read. Without this
        /// lock, Thread A's INSERT could be followed by Thread B's INSERT,
        /// and then Thread A's last_insert_rowid() would return Thread B's
        /// id (last_insert_rowid() is per-connection, but the Database
        /// singleton shares ONE connection across all threads — so the
        /// last insert wins).
        /// FIX B12: uses <see cref="GetLastInsertIdQuery"/> so the same
        /// code path works on both SQLite (last_insert_rowid) and MySQL
        /// (LAST_INSERT_ID).
        /// </remarks>
        public int CreateTournament(string name, string game, decimal entryFee, decimal prize, int maxParticipants, DateTime startTime)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام مسابقه الزامی است");
            if (string.IsNullOrWhiteSpace(game)) throw new ArgumentException("نام بازی الزامی است");
            if (maxParticipants < 2) throw new ArgumentException("حداقل تعداد شرکت‌کننده ۲ است");

            try
            {
                // FIX B6: hold the lock across INSERT + last_insert_rowid so
                // a concurrent CreateTournament can't interleave and steal
                // our id. The Database methods also lock on _lock internally,
                // but that's a DIFFERENT lock object — locking on
                // Database.Instance here serializes TournamentManager callers.
                lock (Database.Instance)
                {
                    Database.Instance.Execute(
                        "INSERT INTO tournaments (name, game, entry_fee, prize, max_participants, start_time, status, created_at) VALUES (@n, @g, @ef, @pz, @mp, @st, 'open', @ca)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@n", name);
                            cmd.Parameters.AddWithValue("@g", game);
                            cmd.Parameters.AddWithValue("@ef", entryFee);
                            cmd.Parameters.AddWithValue("@pz", prize);
                            cmd.Parameters.AddWithValue("@mp", maxParticipants);
                            cmd.Parameters.AddWithValue("@st", startTime.ToString("o"));
                            cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                        });
                    // FIX B12: pick the correct LAST_INSERT_ID syntax for
                    // the active backend (SQLite vs MySQL).
                    int id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => Convert.ToInt32(r.GetValue(0)));
                    AuditLog.Log("Tournament", $"Created: {name} ({game}), entry={entryFee:N0}, prize={prize:N0}, max={maxParticipants}, id={id}");
                    return id;
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "CreateTournament error: " + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Registers a user for an open tournament. Refuses when:
        ///   - tournament is not in 'open' status
        ///   - max_participants has been reached
        ///   - user is already registered (UNIQUE check is enforced by app logic)
        /// Returns true on success.
        /// </summary>
        /// <remarks>
        /// FIX B5: the count-check + INSERT are now wrapped in a single
        /// `lock (Database.Instance)` so a concurrent RegisterUser call
        /// for the same tournament can't slip its INSERT in between our
        /// CountParticipants read and our INSERT write. Without this lock,
        /// two threads could both read count=N (under the cap), both pass
        /// the check, and both INSERT — exceeding max_participants.
        /// </remarks>
        public bool RegisterUser(int tournamentId, string username)
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            try
            {
                // FIX B5: serialize the count + check + insert atomically.
                // Locking on Database.Instance (the singleton) ensures that
                // two concurrent RegisterUser calls for the same tournament
                // can't both pass the cap check and both INSERT.
                lock (Database.Instance)
                {
                    // Look up the tournament — must be open and not full.
                    var t = GetTournament(tournamentId);
                    if (t == null) throw new InvalidOperationException("مسابقه یافت نشد.");
                    if (t.Status != "open") throw new InvalidOperationException("ثبت‌نام در این مسابقه بسته شده است.");
                    int current = CountParticipants(tournamentId);
                    if (current >= t.MaxParticipants) throw new InvalidOperationException("ظرفیت مسابقه تکمیل شده است.");

                    // Check duplicate registration (defensive — there's no UNIQUE
                    // index on (tournament_id, username) by design so we check here).
                    bool already = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM tournament_participants WHERE tournament_id = @t AND username = @u",
                        cmd => { cmd.Parameters.AddWithValue("@t", tournamentId); cmd.Parameters.AddWithValue("@u", username); },
                        r => r.GetInt32(0)) > 0;
                    if (already) throw new InvalidOperationException("این کاربر قبلاً ثبت‌نام کرده است.");

                    Database.Instance.Execute(
                        "INSERT INTO tournament_participants (tournament_id, username, registered_at) VALUES (@t, @u, @r)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@t", tournamentId);
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@r", DateTime.UtcNow.ToString("o"));
                        });

                    // Auto-close registration once the cap is hit.
                    if (current + 1 >= t.MaxParticipants)
                    {
                        Database.Instance.Execute("UPDATE tournaments SET status = 'full' WHERE id = @id",
                            cmd => cmd.Parameters.AddWithValue("@id", tournamentId));
                    }

                    AuditLog.Log("Tournament", $"User {username} registered for tournament #{tournamentId}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", $"RegisterUser error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Records the winner + runner-up of a tournament and marks it
        /// 'completed'. Idempotent — calling again overwrites the previous
        /// result (operator correction).
        /// </summary>
        public void SetResult(int tournamentId, string winnerUsername, string runnerUpUsername)
        {
            if (string.IsNullOrWhiteSpace(winnerUsername)) throw new ArgumentException("برنده الزامی است");
            try
            {
                Database.Instance.Execute(
                    "UPDATE tournaments SET status = 'completed', winner_username = @w, runner_up_username = @ru WHERE id = @id",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@w", winnerUsername);
                        cmd.Parameters.AddWithValue("@ru", string.IsNullOrEmpty(runnerUpUsername) ? "" : runnerUpUsername);
                        cmd.Parameters.AddWithValue("@id", tournamentId);
                    });
                AuditLog.Log("Tournament", $"Tournament #{tournamentId} result set: winner={winnerUsername}, runner-up={runnerUpUsername}");
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "SetResult error: " + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// All tournaments whose status is 'open' or 'full' (i.e. not
        /// completed). Used by the TournamentForm list view.
        /// </summary>
        public List<TournamentInfo> GetActiveTournaments()
        {
            try
            {
                return Database.Instance.Query(
                    "SELECT id, name, game, entry_fee, prize, max_participants, start_time, status FROM tournaments WHERE status IN ('open', 'full') ORDER BY start_time ASC",
                    null,
                    r => new TournamentInfo
                    {
                        Id = r.GetInt32(0),
                        Name = r.GetString(1),
                        Game = r.GetString(2),
                        EntryFee = r.IsDBNull(3) ? 0 : r.GetDecimal(3),
                        Prize = r.IsDBNull(4) ? 0 : r.GetDecimal(4),
                        MaxParticipants = r.GetInt32(5),
                        StartTime = r.GetDateTime(6),
                        Status = r.GetString(7)
                    });
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "GetActiveTournaments error: " + ex.Message);
                return new List<TournamentInfo>();
            }
        }

        /// <summary>Single tournament by id (or null if not found).</summary>
        public TournamentInfo GetTournament(int id)
        {
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT id, name, game, entry_fee, prize, max_participants, start_time, status, winner_username, runner_up_username FROM tournaments WHERE id = @id",
                    cmd => cmd.Parameters.AddWithValue("@id", id),
                    r => new TournamentInfo
                    {
                        Id = r.GetInt32(0),
                        Name = r.GetString(1),
                        Game = r.GetString(2),
                        EntryFee = r.IsDBNull(3) ? 0 : r.GetDecimal(3),
                        Prize = r.IsDBNull(4) ? 0 : r.GetDecimal(4),
                        MaxParticipants = r.GetInt32(5),
                        StartTime = r.GetDateTime(6),
                        Status = r.GetString(7),
                        Winner = r.IsDBNull(8) ? "" : r.GetString(8),
                        RunnerUp = r.IsDBNull(9) ? "" : r.GetString(9)
                    });
            }
            catch { return null; }
        }

        /// <summary>All tournaments, including completed (for the history view).</summary>
        public List<TournamentInfo> GetAllTournaments()
        {
            try
            {
                return Database.Instance.Query(
                    "SELECT id, name, game, entry_fee, prize, max_participants, start_time, status, winner_username, runner_up_username FROM tournaments ORDER BY id DESC",
                    null,
                    r => new TournamentInfo
                    {
                        Id = r.GetInt32(0),
                        Name = r.GetString(1),
                        Game = r.GetString(2),
                        EntryFee = r.IsDBNull(3) ? 0 : r.GetDecimal(3),
                        Prize = r.IsDBNull(4) ? 0 : r.GetDecimal(4),
                        MaxParticipants = r.GetInt32(5),
                        StartTime = r.GetDateTime(6),
                        Status = r.GetString(7),
                        Winner = r.IsDBNull(8) ? "" : r.GetString(8),
                        RunnerUp = r.IsDBNull(9) ? "" : r.GetString(9)
                    });
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "GetAllTournaments error: " + ex.Message);
                return new List<TournamentInfo>();
            }
        }

        public int CountParticipants(int tournamentId)
        {
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT COUNT(*) FROM tournament_participants WHERE tournament_id = @t",
                    cmd => cmd.Parameters.AddWithValue("@t", tournamentId),
                    r => r.GetInt32(0));
            }
            catch { return 0; }
        }

        /// <summary>List of usernames registered for a tournament.</summary>
        public List<TournamentParticipant> GetTournamentParticipants(int tournamentId)
        {
            try
            {
                return Database.Instance.Query(
                    "SELECT username, registered_at FROM tournament_participants WHERE tournament_id = @t ORDER BY registered_at ASC",
                    cmd => cmd.Parameters.AddWithValue("@t", tournamentId),
                    r => new TournamentParticipant { Username = r.GetString(0), RegisteredAt = r.GetDateTime(1) });
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "GetTournamentParticipants error: " + ex.Message);
                return new List<TournamentParticipant>();
            }
        }

        /// <summary>Removes a tournament and all its participant rows.</summary>
        public void DeleteTournament(int id)
        {
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    Database.Instance.Execute("DELETE FROM tournament_participants WHERE tournament_id = @t",
                        cmd => cmd.Parameters.AddWithValue("@t", id), tx);
                    Database.Instance.Execute("DELETE FROM tournaments WHERE id = @id",
                        cmd => cmd.Parameters.AddWithValue("@id", id), tx);
                });
                AuditLog.Log("Tournament", $"Deleted tournament #{id}");
            }
            catch (Exception ex)
            {
                AuditLog.Log("Tournament", "DeleteTournament error: " + ex.Message);
                throw;
            }
        }
    }

    /// <summary>Tournament DTO for UI/API consumption.</summary>
    public class TournamentInfo
    {
        public int Id;
        public string Name;
        public string Game;
        public decimal EntryFee;
        public decimal Prize;
        public int MaxParticipants;
        public DateTime StartTime;
        public string Status; // open / full / completed
        public string Winner;
        public string RunnerUp;

        public int CurrentParticipantCount; // filled by UI layer via CountParticipants
    }

    public class TournamentParticipant
    {
        public string Username;
        public DateTime RegisteredAt;
    }
}
