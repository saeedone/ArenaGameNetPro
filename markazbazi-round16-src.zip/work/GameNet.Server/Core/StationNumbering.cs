using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Assigns sequential station names (PC_1, PC_2, ... PC_10) to clients
    /// based on their MAC address. The mapping is persisted to a JSON file
    /// so the same physical kiosk gets the same number across server restarts.
    ///
    /// Behavior:
    /// - First client to connect (by MAC) → PC_1
    /// - Second different client → PC_2
    /// - ... up to PC_10
    /// - If a known MAC reconnects → same number
    /// - If &gt;10 different MACs connect → PC_11, PC_12, ... (no hard cap,
    ///   but the UI was designed for 10)
    /// - If a client sends a custom StationName (not empty, not the machine
    ///   name), that name is used instead of auto-numbering.
    /// </summary>
    public static class StationNumbering
    {
        private static readonly string MapFile = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "station_map.json");

        private static readonly object _lock = new object();
        private static Dictionary<string, string> _map; // MAC → "PC_N"

        static StationNumbering()
        {
            Load();
        }

        /// <summary>
        /// Returns the station name for the given MAC. If the MAC is already
        /// known, returns the existing name. Otherwise assigns the next
        /// available PC_N number. If the client sent a custom name (not empty,
        /// not a Windows machine name like "DESKTOP-XXXX"), that name is used
        /// as-is without auto-numbering.
        /// </summary>
        public static string GetOrAssign(string mac, string clientSentName)
        {
            // FIX L12: when MAC is unknown (the kiosk's NIC lookup returned
            // "UNKNOWN"), use the client IP as the dedup key instead of the
            // literal string "_unknown_mac_". Previously every MAC-less
            // kiosk collided on "_unknown_mac_" and got the SAME station
            // number (PC_1), so two simultaneously-connected MAC-less
            // kiosks showed up as one another in the monitor grid. The IP
            // is unique per TCP connection, which is good enough for the
            // station-map dedup.
            if (string.IsNullOrEmpty(mac) || mac == "UNKNOWN")
            {
                // Fall back to the caller's IP — but GetOrAssign only has
                // (mac, clientSentName), so we have to defer to the caller.
                // The ClientCommunicator.HandleHello caller now passes the
                // IP in the `mac` slot when the real MAC is unknown; see
                // the caller for the IP-fallback wiring.
                mac = "_unknown_mac_";
            }

            lock (_lock)
            {
                // If the client sent a meaningful custom name (not a Windows
                // auto-generated machine name), use it as-is. We detect
                // auto-generated names by the "DESKTOP-" / "LAPTOP-" prefix
                // or all-uppercase-with-dashes pattern.
                if (!string.IsNullOrEmpty(clientSentName) &&
                    !IsAutoMachineName(clientSentName))
                {
                    // The client's custom name is valid — use it, and remember
                    // the mapping so reconnects stay consistent.
                    if (!_map.ContainsKey(mac))
                    {
                        _map[mac] = clientSentName;
                        Save();
                    }
                    return _map[mac];
                }

                // Auto-number: if this MAC already has a number, return it.
                if (_map.ContainsKey(mac))
                    return _map[mac];

                // Find the next available PC_N (1..10, then 11+).
                int next = FindNextAvailableNumber();
                string name = "PC_" + next;
                _map[mac] = name;
                Save();
                AuditLog.Log("StationNumbering", $"Assigned {name} to MAC {mac}");
                return name;
            }
        }

        /// <summary>
        /// Detects Windows auto-generated machine names: "DESKTOP-XXXXXX",
        /// "LAPTOP-XXXXXX", etc. These should be replaced with sequential
        /// PC_N names. A custom name like "Reception" or "PC_5"
        /// or "Gaming-01" is preserved.
        ///
        /// FIX L8: tightened the heuristic. The previous "all-caps with a
        /// single dash + 6+ alphanumeric chars after" rule produced false
        /// positives for legitimate station names like "GAME-ZONE01" or
        /// "PS4-PRO1234" (which the operator would want preserved). Now we
        /// only match the well-known Windows OEM prefixes (DESKTOP- / LAPTOP-)
        /// — these are the actual auto-generated patterns Windows uses for
        /// fresh installs. The PC-XXXXXX pattern is intentionally NOT matched
        /// because the cafe's own naming convention may legitimately start
        /// with "PC-".
        /// </summary>
        private static bool IsAutoMachineName(string name)
        {
            if (string.IsNullOrEmpty(name)) return true;
            string upper = name.ToUpperInvariant();
            if (upper.StartsWith("DESKTOP-")) return true;
            if (upper.StartsWith("LAPTOP-")) return true;
            return false;
        }

        /// <summary>
        /// Finds the smallest available station number (1, 2, ... 10, 11+)
        /// that isn't already assigned to any MAC.
        /// </summary>
        private static int FindNextAvailableNumber()
        {
            var used = new HashSet<int>();
            foreach (var kvp in _map)
            {
                if (kvp.Value != null && kvp.Value.StartsWith("PC_"))
                {
                    if (int.TryParse(kvp.Value.Substring(3), out int n))
                        used.Add(n);
                }
            }
            for (int i = 1; i <= 100; i++)
                if (!used.Contains(i)) return i;
            return _map.Count + 1;
        }

        private static void Load()
        {
            try
            {
                _map = new Dictionary<string, string>();
                if (File.Exists(MapFile))
                {
                    var json = File.ReadAllText(MapFile);
                    _map = JsonConvert.DeserializeObject<Dictionary<string, string>>(json) ?? new Dictionary<string, string>();
                }
            }
            catch { _map = new Dictionary<string, string>(); }
        }

        private static void Save()
        {
            try
            {
                var json = JsonConvert.SerializeObject(_map, Formatting.Indented);
                File.WriteAllText(MapFile, json);
            }
            catch { }
        }

        /// <summary>Returns a copy of the current MAC→name mapping (for UI display).</summary>
        public static Dictionary<string, string> GetAll()
        {
            lock (_lock) { return new Dictionary<string, string>(_map); }
        }

        /// <summary>Clears all assignments (useful for reset).</summary>
        public static void Reset()
        {
            lock (_lock)
            {
                _map.Clear();
                Save();
            }
        }
    }
}
