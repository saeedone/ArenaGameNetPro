using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages console (PS4 / PS5 / Xbox) time reservations and walk-in
    /// console sessions. Consoles are stored in the existing `stations`
    /// table with category = 'PS4' / 'PS5' / 'Xbox'. This manager handles:
    ///   - Creating time-slot reservations (booking ahead)
    ///   - Starting a walk-in session on a console (pay-as-you-go)
    ///   - Ending a console session and calculating the cost
    ///   - Listing today's reservations per console
    ///   - Blocking double-booking with overlap detection (transactional)
    /// Console sessions are tracked in `console_sessions` table; reservations
    /// use the existing `reservations` table.
    /// </summary>
    public class ConsoleReservationManager
    {
        public const string ConsoleCategoryPS4 = "PS4";
        public const string ConsoleCategoryPS5 = "PS5";
        public const string ConsoleCategoryXbox = "Xbox";

        /// <summary>Creates a time-slot reservation for a console.</summary>
        public int CreateReservation(string username, string consoleName, string consoleType,
            DateTime startTime, DateTime endTime, string notes = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (string.IsNullOrWhiteSpace(consoleName)) throw new ArgumentException("نام کنسول الزامی است");
            if (endTime <= startTime) throw new ArgumentException("زمان پایان باید بعد از شروع باشد");
            if (startTime < DateTime.Now.AddMinutes(-5)) throw new ArgumentException("زمان شروع نمی‌تواند در گذشته باشد");

            // Verify user
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            // Verify console station exists and is a console type
            var station = new StationManager().FindByName(consoleName);
            if (station == null) throw new InvalidOperationException($"کنسول «{consoleName}» یافت نشد");
            if (!IsConsoleCategory(station.Category))
                throw new InvalidOperationException($"ایستگاه «{consoleName}» یک کنسول نیست (نوع: {station.Category})");

            int reservationId = 0;
            Database.Instance.ExecuteInTransaction(tx =>
            {
                int overlaps = Database.Instance.QueryOne(
                    "SELECT COUNT(*) FROM reservations WHERE station_name = @s AND status = 'active' " +
                    "AND (start_time < @end AND end_time > @start)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@s", consoleName);
                        cmd.Parameters.AddWithValue("@start", startTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@end", endTime.ToString("o"));
                    }, r => r.GetInt32(0), tx);

                if (overlaps > 0)
                    throw new InvalidOperationException("در این بازه زمانی رزرو دیگری برای این کنسول وجود دارد");

                Database.Instance.Execute(
                    "INSERT INTO reservations (username, station_name, start_time, end_time, status, created_at, notes) " +
                    "VALUES (@u, @s, @st, @et, 'active', @ct, @n)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@s", consoleName);
                        cmd.Parameters.AddWithValue("@st", startTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@et", endTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@n", (notes ?? "") + $" [کنسول: {consoleType}]");
                    }, tx);

                reservationId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });

            AuditLog.Log("ConsoleReservation", $"Reservation #{reservationId}: {username} → {consoleName} ({consoleType}) {startTime:t} - {endTime:t}");
            return reservationId;
        }

        /// <summary>Starts a walk-in (pay-as-you-go) session on a console.</summary>
        public int StartSession(string username, string consoleName, string consoleType)
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (string.IsNullOrWhiteSpace(consoleName)) throw new ArgumentException("نام کنسول الزامی است");

            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            var station = new StationManager().FindByName(consoleName);
            if (station == null) throw new InvalidOperationException($"کنسول «{consoleName}» یافت نشد");
            if (!IsConsoleCategory(station.Category))
                throw new InvalidOperationException($"ایستگاه «{consoleName}» یک کنسول نیست");

            int sessionId = 0;
            Database.Instance.ExecuteInTransaction(tx =>
            {
                // Check no active session on this console
                int active = Database.Instance.QueryOne(
                    "SELECT COUNT(*) FROM console_sessions WHERE console_name = @c AND status = 'active'",
                    cmd => cmd.Parameters.AddWithValue("@c", consoleName),
                    r => r.GetInt32(0), tx);

                if (active > 0)
                    throw new InvalidOperationException("این کنسول در حال حاضر در استفاده است — ابتدا نشست قبلی را پایان دهید");

                Database.Instance.Execute(
                    "INSERT INTO console_sessions (username, console_name, console_type, start_time, status, created_at) " +
                    "VALUES (@u, @c, @t, @st, 'active', @ct)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@c", consoleName);
                        cmd.Parameters.AddWithValue("@t", consoleType);
                        cmd.Parameters.AddWithValue("@st", DateTime.Now.ToString("o"));
                        cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                    }, tx);

                sessionId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });

            AuditLog.Log("ConsoleReservation", $"Walk-in session #{sessionId} started: {username} on {consoleName} ({consoleType})");
            return sessionId;
        }

        /// <summary>Ends an active console session and returns the cost.</summary>
        public decimal EndSession(int sessionId, decimal pricePerHour)
        {
            var session = Database.Instance.QueryOne(
                "SELECT id, username, console_name, console_type, start_time, status FROM console_sessions WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", sessionId),
                r => new
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    ConsoleName = r.GetString(2),
                    ConsoleType = r.GetString(3),
                    StartTime = r.GetDateTime(4),
                    Status = r.GetString(5)
                });

            if (session == null) throw new KeyNotFoundException("نشست یافت نشد");
            if (session.Status != "active") throw new InvalidOperationException("این نشست قبلاً پایان یافته است");

            DateTime endTime = DateTime.Now;
            TimeSpan duration = endTime - session.StartTime;
            // Minimum charge: 15 minutes
            double billableMinutes = Math.Max(15, Math.Ceiling(duration.TotalMinutes));
            decimal cost = Math.Round((decimal)(billableMinutes / 60.0) * pricePerHour, 0);

            // Deduct from user balance (atomic, conditional)
            var mgr = new UserManager();
            try { mgr.DeductCredit(session.Username, cost); }
            catch (InvalidOperationException) { /* insufficient balance — still end session, record debt */ }

            Database.Instance.Execute(
                "UPDATE console_sessions SET end_time = @et, duration_minutes = @dur, cost = @cost, status = 'ended' WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@et", endTime.ToString("o"));
                    cmd.Parameters.AddWithValue("@dur", (int)billableMinutes);
                    cmd.Parameters.AddWithValue("@cost", cost);
                    cmd.Parameters.AddWithValue("@id", sessionId);
                });

            AuditLog.Log("ConsoleReservation", $"Session #{sessionId} ended: {session.Username} on {session.ConsoleName}, duration {billableMinutes} min, cost {cost:N0} Toman");
            return cost;
        }

        /// <summary>Returns all active console sessions (walk-in, in-progress).</summary>
        public List<(int Id, string Username, string ConsoleName, string ConsoleType, DateTime StartTime, int ElapsedMinutes)> GetActiveSessions()
        {
            var now = DateTime.Now;
            return Database.Instance.Query(
                "SELECT id, username, console_name, console_type, start_time FROM console_sessions WHERE status = 'active' ORDER BY start_time",
                null,
                r => (
                    r.GetInt32(0),
                    r.GetString(1),
                    r.GetString(2),
                    r.IsDBNull(3) ? "PS4" : r.GetString(3),
                    r.GetDateTime(4),
                    (int)Math.Round((now - r.GetDateTime(4)).TotalMinutes)
                ));
        }

        /// <summary>Returns today's reservations for all consoles.</summary>
        public List<(int Id, string Username, string ConsoleName, DateTime Start, DateTime End, string Status, string Notes)> GetTodayReservations()
        {
            var today = DateTime.Today;
            var tomorrow = today.AddDays(1);
            return Database.Instance.Query(
                "SELECT id, username, station_name, start_time, end_time, status, notes FROM reservations " +
                "WHERE station_name IN (SELECT name FROM stations WHERE category IN ('PS4','PS5','Xbox')) " +
                "AND start_time >= @ts AND start_time < @te ORDER BY start_time",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@ts", today.ToString("o"));
                    cmd.Parameters.AddWithValue("@te", tomorrow.ToString("o"));
                },
                r => (
                    r.GetInt32(0),
                    r.GetString(1),
                    r.GetString(2),
                    r.GetDateTime(3),
                    r.GetDateTime(4),
                    r.GetString(5),
                    r.IsDBNull(6) ? "" : r.GetString(6)
                ));
        }

        /// <summary>Returns all consoles (stations with console categories).</summary>
        public List<(int Id, string Name, string Category, string Status)> GetConsoles()
        {
            return Database.Instance.Query(
                "SELECT id, name, category, status FROM stations WHERE category IN ('PS4','PS5','Xbox') ORDER BY category, name",
                null,
                r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetString(3)));
        }

        /// <summary>Adds a new console station.</summary>
        public int AddConsole(string name, string consoleType, string notes = "")
        {
            if (!IsConsoleCategory(consoleType)) throw new ArgumentException("نوع کنسول باید PS4، PS5 یا Xbox باشد");
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام کنسول الزامی است");

            int id = 0;
            Database.Instance.ExecuteInTransaction(tx =>
            {
                Database.Instance.Execute(
                    "INSERT INTO stations (name, ip_address, mac_address, pricing_plan_id, category, status, notes, created_at) " +
                    "VALUES (@n, '', '', NULL, @cat, 'available', @notes, @ct)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@n", name);
                        cmd.Parameters.AddWithValue("@cat", consoleType);
                        cmd.Parameters.AddWithValue("@notes", notes ?? "");
                        cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                    }, tx);
                id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });
            AuditLog.Log("ConsoleReservation", $"Console added: {name} ({consoleType})");
            return id;
        }

        /// <summary>Cancels a reservation.</summary>
        public void CancelReservation(int id, string reason)
        {
            int rows = Database.Instance.ExecuteNonQuery(
                "UPDATE reservations SET status = 'cancelled', notes = COALESCE(notes,'') || ' | لغو: ' || @r WHERE id = @id AND status = 'active'",
                cmd => { cmd.Parameters.AddWithValue("@r", reason); cmd.Parameters.AddWithValue("@id", id); });
            if (rows > 0) AuditLog.Log("ConsoleReservation", $"Reservation #{id} cancelled: {reason}");
        }

        public static bool IsConsoleCategory(string category)
        {
            if (string.IsNullOrEmpty(category)) return false;
            return category == ConsoleCategoryPS4 || category == ConsoleCategoryPS5 || category == ConsoleCategoryXbox;
        }

        /// <summary>Gets the price per hour for a console type from the pricing table.</summary>
        public decimal GetConsolePrice(string consoleType)
        {
            // Look for a pricing plan whose name matches the console type; if
            // none found, fall back to the default plan.
            var price = Database.Instance.QueryOne(
                "SELECT price_per_hour FROM pricing WHERE name = @n AND is_default = 0 ORDER BY id DESC LIMIT 1",
                cmd => cmd.Parameters.AddWithValue("@n", consoleType),
                r => r.GetDecimal(0));
            if (price > 0) return price;

            // Fallback: default pricing plan
            return Database.Instance.QueryOne(
                "SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1",
                null, r => r.GetDecimal(0));
        }
    }
}
