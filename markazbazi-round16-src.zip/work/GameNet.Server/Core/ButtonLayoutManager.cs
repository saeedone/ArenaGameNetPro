using System;
using System.Collections.Generic;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages which buttons are visible to regular operators vs admin-only.
    /// Each button has a key, label, and an "IsAdminOnly" flag stored in DB.
    /// The admin can toggle this flag from the Button Layout Manager panel.
    /// </summary>
    public class ButtonLayoutEntry
    {
        public string Key = "";
        public string Label = "";
        public bool IsAdminOnly;
    }

    public static class ButtonLayoutManager
    {
        private const string TableName = "button_layout";

        // All button definitions: key, default label, default admin-only status.
        private static readonly (string Key, string Label, bool DefaultAdminOnly)[] _definitions = new[]
        {
            // Safe operations (default: visible to all)
            ("time_add10", "⏱️ +۱۰ دقیقه", false),
            ("time_add30", "⏱️ +۳۰ دقیقه", false),
            ("time_add60", "⏱️ +۶۰ دقیقه", false),
            ("time_unlimited", "♾️ نامحدود", false),
            ("time_end", "⏹️ پایان نشست", false),
            ("add_credit", "➕ افزایش اعتبار", false),
            ("screenshot", "📷 اسکرین‌شات", false),
            ("send_message", "💬 پیام", false),
            // Dangerous operations (default: admin-only)
            ("unlock_station", "🔓 باز کردن قفل", true),
            ("force_logout", "🚪 خروج اجباری", true),
            ("shutdown", "⏻ خاموش کلاینت", true),
            ("restart", "🔄 ری‌استارت", true),
            // Advanced features (default: admin-only)
            ("internet_off", "🌐 قطع اینترنت", true),
            ("internet_on", "🌐 وصل اینترنت", true),
            ("mute_off", "🔇 قطع صدا", true),
            ("mute_on", "🔊 وصل صدا", true),
            ("remote_desktop", "🖥️ مدیریت ریموت", true),
        };

        public static void EnsureTable()
        {
            try
            {
                Database.Instance.Execute($"CREATE TABLE IF NOT EXISTS {TableName} (key TEXT PRIMARY KEY, label TEXT, is_admin_only INTEGER DEFAULT 0)", null);
                // Seed defaults for any missing keys.
                foreach (var def in _definitions)
                {
                    Database.Instance.Execute(
                        $"INSERT OR IGNORE INTO {TableName} (key, label, is_admin_only) VALUES (@k, @l, @a)",
                        c =>
                        {
                            c.Parameters.AddWithValue("@k", def.Key);
                            c.Parameters.AddWithValue("@l", def.Label);
                            c.Parameters.AddWithValue("@a", def.DefaultAdminOnly ? 1 : 0);
                        });
                }
            }
            catch { }
        }

        public static List<ButtonLayoutEntry> GetAll()
        {
            var list = new List<ButtonLayoutEntry>();
            try
            {
                EnsureTable();
                Database.Instance.Query(
                    $"SELECT key, label, is_admin_only FROM {TableName} ORDER BY key",
                    null,
                    r =>
                    {
                        list.Add(new ButtonLayoutEntry
                        {
                            Key = r.GetString(0),
                            Label = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                            IsAdminOnly = r.GetInt32(2) == 1
                        });
                        return true;
                    });
            }
            catch { }
            return list;
        }

        public static bool IsAdminOnly(string key)
        {
            try
            {
                EnsureTable();
                var result = Database.Instance.QueryOne(
                    $"SELECT is_admin_only FROM {TableName} WHERE key = @k",
                    c => c.Parameters.AddWithValue("@k", key),
                    r => r.GetInt32(0) == 1);
                return result;
            }
            catch { return false; }
        }

        public static void SetAdminOnly(string key, bool adminOnly)
        {
            try
            {
                EnsureTable();
                Database.Instance.Execute(
                    $"UPDATE {TableName} SET is_admin_only = @a WHERE key = @k",
                    c =>
                    {
                        c.Parameters.AddWithValue("@a", adminOnly ? 1 : 0);
                        c.Parameters.AddWithValue("@k", key);
                    });
                AuditLog.Log("ButtonLayout", $"Button '{key}' set to {(adminOnly ? "admin-only" : "visible to all")}");
            }
            catch { }
        }
    }
}
