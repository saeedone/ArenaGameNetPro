using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 10 — Auto-update distributor + file transfer.
    ///
    /// The operator drops a new client build (e.g. GameNet.Client.exe)
    /// into the "updates" folder next to the server exe. The server then
    /// offers it to connected kiosks; on acceptance, the file is streamed
    /// in chunks (~512KB each) via ServerUpdateChunk messages. The client
    /// verifies the SHA-256 hash, writes the file to a temp location, and
    /// runs it (which replaces the old exe via a batch rename on next launch).
    ///
    /// The same chunked-transfer mechanism powers ad-hoc file transfer
    /// (SendFileToStation) — the operator picks any file and a target path
    /// on the kiosk, and the server streams it.
    /// </summary>
    public class UpdateDistributor
    {
        private const int ChunkSize = 512 * 1024; // 512KB chunks

        // FIX DEAD-CONFIG-5: OptionsForm's "محدودیت پهنای باند" checkbox +
        // "حداکثر سرعت (KB/s)" field were saved to options.json and never
        // read anywhere — file transfer always ran at full speed regardless
        // of what was configured. StreamFile/StreamFileTransfer now sleep
        // between chunks to cap the effective send rate when enabled.
        private static void ThrottleIfConfigured(long totalBytesSentSoFar, System.Diagnostics.Stopwatch sw)
        {
            try
            {
                var opts = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                if (opts == null || !opts.BandwidthLimit) return;
                int kbps = opts.BandwidthMaxKbps > 0 ? opts.BandwidthMaxKbps : 100;
                double expectedMs = totalBytesSentSoFar / 1024.0 / kbps * 1000.0;
                double elapsedMs = sw.Elapsed.TotalMilliseconds;
                if (expectedMs > elapsedMs)
                    System.Threading.Thread.Sleep((int)(expectedMs - elapsedMs));
            }
            catch { /* never let a bad setting break the transfer */ }
        }

        private readonly string _updatesDir;

        public UpdateDistributor()
        {
            _updatesDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "updates");
            try { Directory.CreateDirectory(_updatesDir); } catch { }
        }

        /// <summary>Returns info about the latest available client update, or null if none.</summary>
        public UpdateOfferPayload GetLatestUpdate()
        {
            try
            {
                var di = new DirectoryInfo(_updatesDir);
                var files = di.GetFiles("GameNet.Client*.exe", SearchOption.TopDirectoryOnly);
                if (files.Length == 0) return null;
                // Pick the most recently modified
                var latest = files[0];
                foreach (var f in files) if (f.LastWriteTimeUtc > latest.LastWriteTimeUtc) latest = f;

                // FIX-MINOR-UPDATE IMPROVE A: prefer version.txt (operator-
                // maintained or auto-staged by MainForm on startup) → fall
                // back to extracting the version from the filename pattern
                // (markazbazi.Client.exe) → finally fall back to the
                // embedded FileVersionInfo of the exe itself. Previously
                // a plain "GameNet.Client.exe" with no version in its name
                // got "0.0", and the operator's confirmation dialog said
                // "📦 نسخه: 0.0" — confusing.
                string version = ReadVersionFile();
                if (string.IsNullOrEmpty(version) || version == "0.0")
                {
                    version = ExtractVersionFromName(latest.Name);
                }
                if (string.IsNullOrEmpty(version) || version == "0.0")
                {
                    version = ReadVersionFromExe(latest.FullName);
                }
                // Fix 2: an update without a detached signature is never offered.
                // tools\Sign-Update.ps1 writes <file>.sig with the developer's PRIVATE
                // key; kiosks verify it against the PUBLIC key compiled into the client.
                // This server cannot forge a signature.
                string signature = ReadSignatureFile(latest.FullName);
                if (string.IsNullOrEmpty(signature))
                {
                    AuditLog.Log("Update", "Not offered: " + latest.Name + " has no signature file (" + latest.Name + ".sig)");
                    return null;
                }
                return new UpdateOfferPayload
                {
                    Version = version,
                    Filename = latest.Name,
                    FileSize = latest.Length,
                    Sha256 = ComputeSha256(latest.FullName),
                    Signature = signature,
                    ReleaseNotes = ReadReleaseNotes(),
                    IsMandatory = false
                };
            }
            catch { return null; }
        }

        /// <summary>
        /// Streams the given file to a client in chunks via the provided
        /// send callback. Each chunk is base64-encoded (so it fits in the
        /// JSON framing). Returns when the whole file has been sent.
        /// </summary>
        public void StreamFile(string filePath, Action<NetMessage> sendChunk)
        {
            if (!File.Exists(filePath)) throw new FileNotFoundException(filePath);
            byte[] allBytes = File.ReadAllBytes(filePath);
            int totalChunks = (int)Math.Ceiling(allBytes.Length / (double)ChunkSize);
            var sw = System.Diagnostics.Stopwatch.StartNew();

            for (int i = 0; i < totalChunks; i++)
            {
                int offset = i * ChunkSize;
                int length = Math.Min(ChunkSize, allBytes.Length - offset);
                byte[] chunk = new byte[length];
                Buffer.BlockCopy(allBytes, offset, chunk, 0, length);

                var payload = new FileChunkPayload
                {
                    Sequence = i + 1,
                    TotalSequences = totalChunks,
                    Base64Data = Convert.ToBase64String(chunk),
                    IsLast = (i + 1 == totalChunks)
                };
                sendChunk(new NetMessage(MessageType.ServerUpdateChunk, payload));
                ThrottleIfConfigured(offset + length, sw);
            }
        }

        /// <summary>
        /// Streams an arbitrary file (not necessarily an update) to a
        /// client. Used by the operator's "send file" action.
        /// </summary>
        public void StreamFileTransfer(string filePath, Action<NetMessage> sendChunk)
        {
            if (!File.Exists(filePath)) throw new FileNotFoundException(filePath);
            byte[] allBytes = File.ReadAllBytes(filePath);
            int totalChunks = (int)Math.Ceiling(allBytes.Length / (double)ChunkSize);
            var sw = System.Diagnostics.Stopwatch.StartNew();

            for (int i = 0; i < totalChunks; i++)
            {
                int offset = i * ChunkSize;
                int length = Math.Min(ChunkSize, allBytes.Length - offset);
                byte[] chunk = new byte[length];
                Buffer.BlockCopy(allBytes, offset, chunk, 0, length);

                var payload = new FileChunkPayload
                {
                    Sequence = i + 1,
                    TotalSequences = totalChunks,
                    Base64Data = Convert.ToBase64String(chunk),
                    IsLast = (i + 1 == totalChunks)
                };
                sendChunk(new NetMessage(MessageType.ServerFileTransferChunk, payload));
                ThrottleIfConfigured(offset + length, sw);
            }
        }

        /// <summary>Returns the full path of the latest update file, or null.</summary>
        public string GetLatestUpdatePath()
        {
            try
            {
                var di = new DirectoryInfo(_updatesDir);
                var files = di.GetFiles("GameNet.Client*.exe", SearchOption.TopDirectoryOnly);
                if (files.Length == 0) return null;
                var latest = files[0];
                foreach (var f in files) if (f.LastWriteTimeUtc > latest.LastWriteTimeUtc) latest = f;
                return latest.FullName;
            }
            catch { return null; }
        }

        public string GetUpdatesDir() => _updatesDir;

        private static string ExtractVersionFromName(string name)
        {
            // Try patterns like: markazbazi.Client.exe, markazbazi.Client.exe
            try
            {
                string baseName = Path.GetFileNameWithoutExtension(name);
                int dot = baseName.LastIndexOf('.');
                if (dot < 0) return "0.0";
                // Find the last version-like segment
                var parts = baseName.Split('.');
                if (parts.Length >= 2)
                {
                    string last = parts[parts.Length - 1];
                    string prev = parts[parts.Length - 2];
                    if (double.TryParse(last, out _) || double.TryParse(prev, out _))
                        return prev + "." + last;
                }
            }
            catch { }
            return "0.0";
        }

        private static string ComputeSha256(string path)
        {
            try
            {
                using (var sha = SHA256.Create())
                using (var fs = File.OpenRead(path))
                {
                    byte[] hash = sha.ComputeHash(fs);
                    var sb = new System.Text.StringBuilder(hash.Length * 2);
                    foreach (byte b in hash) sb.Append(b.ToString("x2"));
                    return sb.ToString();
                }
            }
            catch { return ""; }
        }

        /// <summary>Fix 2: returns the base64 signature stored next to an update file, or null.</summary>
        private static string ReadSignatureFile(string exePath)
        {
            try
            {
                string sigPath = exePath + ".sig";
                if (!File.Exists(sigPath)) return null;
                string sig = File.ReadAllText(sigPath).Trim();
                return sig.Length == 0 ? null : sig;
            }
            catch { return null; }
        }

        private string ReadReleaseNotes()
        {
            try
            {
                string path = Path.Combine(_updatesDir, "release_notes.txt");
                if (File.Exists(path)) return File.ReadAllText(path);
            }
            catch { }
            return "";
        }

        /// <summary>
        /// FIX-MINOR-UPDATE IMPROVE A: reads updates/version.txt if present.
        /// The operator (or the MainForm auto-stage routine) writes the
        /// version string here so GetLatestUpdate doesn't have to rely on
        /// the filename containing a parseable version.
        /// </summary>
        private string ReadVersionFile()
        {
            try
            {
                string path = Path.Combine(_updatesDir, "version.txt");
                if (File.Exists(path))
                {
                    string v = File.ReadAllText(path).Trim();
                    if (!string.IsNullOrEmpty(v)) return v;
                }
            }
            catch { }
            return null;
        }

        /// <summary>
        /// FIX-MINOR-UPDATE IMPROVE A: reads the FileVersionInfo of the
        /// staged exe and returns its FileVersion (or ProductVersion as a
        /// fallback). Used when neither version.txt nor the filename
        /// pattern yields a parseable version.
        /// </summary>
        private static string ReadVersionFromExe(string exePath)
        {
            try
            {
                var ver = System.Diagnostics.FileVersionInfo.GetVersionInfo(exePath);
                if (!string.IsNullOrEmpty(ver.FileVersion)) return ver.FileVersion;
                if (!string.IsNullOrEmpty(ver.ProductVersion)) return ver.ProductVersion;
            }
            catch { }
            return "0.0";
        }
    }
}
