using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages user debts (مچال/بدهی). Tracks amounts owed by users,
    /// supports partial payments, and integrates with the billing system.
    /// </summary>
    public class DebtManager
    {
        public DebtPayload CreateDebt(string username, decimal amount, string description, DateTime? dueDate = null, string notes = "", string createdBy = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (amount <= 0) throw new ArgumentException("مبلغ بدهی باید بیشتر از صفر باشد");

            // Verify user exists
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            Database.Instance.Execute(
                "INSERT INTO debts (username, amount, description, is_paid, created_at, due_date, notes, created_by) VALUES (@u, @amt, @desc, 0, @ca, @due, @notes, @by)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@amt", amount);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@due", dueDate.HasValue ? dueDate.Value.ToString("o") : (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@notes", notes ?? "");
                    cmd.Parameters.AddWithValue("@by", createdBy ?? "");
                });

            int id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));
            AuditLog.Log("DebtManager", $"Debt created for {username}: {amount:N0} Toman - {description}");

            return GetDebt(id);
        }

        public DebtPayload GetDebt(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, username, amount, description, is_paid, created_at, due_date, paid_at, notes FROM debts WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new DebtPayload
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    Amount = r.GetDecimal(2),
                    Description = r.IsDBNull(3) ? "" : r.GetString(3),
                    IsPaid = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    DueDate = r.IsDBNull(6) ? (DateTime?)null : r.GetDateTime(6),
                    PaidAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8)
                });
        }

        /// <summary>
        /// Gets all debts for a specific user.
        /// </summary>
        public DebtListPayload GetUserDebts(string username)
        {
            var debts = Database.Instance.Query(
                "SELECT id, username, amount, description, is_paid, created_at, due_date, paid_at, notes FROM debts WHERE username = @u ORDER BY is_paid ASC, created_at DESC",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => new DebtPayload
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    Amount = r.GetDecimal(2),
                    Description = r.IsDBNull(3) ? "" : r.GetString(3),
                    IsPaid = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    DueDate = r.IsDBNull(6) ? (DateTime?)null : r.GetDateTime(6),
                    PaidAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8)
                });

            decimal totalDebt = 0;
            foreach (var d in debts) { if (!d.IsPaid) totalDebt += d.Amount; }

            return new DebtListPayload { Debts = debts, TotalDebt = totalDebt };
        }

        /// <summary>
        /// Gets all unpaid debts across all users.
        /// </summary>
        public DebtListPayload GetAllUnpaidDebts()
        {
            var debts = Database.Instance.Query(
                "SELECT id, username, amount, description, is_paid, created_at, due_date, paid_at, notes FROM debts WHERE is_paid = 0 ORDER BY created_at",
                null,
                r => new DebtPayload
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    Amount = r.GetDecimal(2),
                    Description = r.IsDBNull(3) ? "" : r.GetString(3),
                    IsPaid = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    DueDate = r.IsDBNull(6) ? (DateTime?)null : r.GetDateTime(6),
                    PaidAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8)
                });

            decimal totalDebt = 0;
            foreach (var d in debts) totalDebt += d.Amount;

            return new DebtListPayload { Debts = debts, TotalDebt = totalDebt };
        }

        /// <summary>
        /// Marks a debt as paid by deducting from user balance. Both the
        /// deduction and the debt status update run in a single transaction so
        /// a failure between them cannot leave the user debited while the debt
        /// is still unpaid (or vice versa).
        /// </summary>
        public bool PayDebt(int debtId, bool deductFromBalance = true)
        {
            var debt = GetDebt(debtId);
            if (debt == null) return false;
            if (debt.IsPaid) return false;

            if (deductFromBalance)
            {
                var user = new UserManager().FindByUsername(debt.Username);
                if (user == null) return false;

                int balRows = 0;
                try
                {
                    Database.Instance.ExecuteInTransaction(tx =>
                    {
                        // Atomic conditional deduction — guards against the race
                        // where the user's balance was drained between our
                        // pre-check and the deduction.
                        balRows = Database.Instance.ExecuteNonQuery(
                            "UPDATE users SET balance = balance - @amt WHERE username = @u AND balance >= @amt",
                            cmd => { cmd.Parameters.AddWithValue("@amt", debt.Amount); cmd.Parameters.AddWithValue("@u", debt.Username); }, tx);

                        if (balRows == 0)
                            throw new InsufficientBalanceException(debt.Username, user.Balance, debt.Amount);

                        Database.Instance.Execute(
                            "UPDATE debts SET is_paid = 1, paid_at = @pa WHERE id = @id",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@pa", DateTime.UtcNow.ToString("o"));
                                cmd.Parameters.AddWithValue("@id", debtId);
                            }, tx);
                    });
                }
                catch (InsufficientBalanceException)
                {
                    throw new InvalidOperationException($"موجودی کاربر ({user.Balance:N0} تومان) کمتر از مبلغ بدهی ({debt.Amount:N0} تومان) است");
                }
                catch (Exception ex)
                {
                    AuditLog.Log("DebtManager", $"PayDebt failed for debt {debtId}: {ex.Message}");
                    throw;
                }
            }
            else
            {
                Database.Instance.Execute(
                    "UPDATE debts SET is_paid = 1, paid_at = @pa WHERE id = @id",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@pa", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@id", debtId);
                    });
            }

            AuditLog.Log("DebtManager", $"Debt paid: {debt.Username} - {debt.Amount:N0} Toman (ID: {debtId})");
            return true;
        }

        /// <summary>
        /// Partially pays a debt by reducing the amount owed. Validates that
        /// the payment does not exceed the remaining debt. The deduction and
        /// debt reduction run in a single transaction; if the deduction fails
        /// (balance too low), the debt is left untouched.
        /// </summary>
        public bool PartialPayDebt(int debtId, decimal amount)
        {
            if (amount <= 0) throw new ArgumentException("مبلغ پرداخت باید بیشتر از صفر باشد");

            var debt = GetDebt(debtId);
            if (debt == null || debt.IsPaid) return false;

            // Reject overpayment — caller must pay the exact remaining amount
            // or less. Without this check, the previous code would silently
            // mark a 30,000 Toman debt as "paid" if you sent 50,000, leaving
            // 20,000 Toman of the user's money unaccounted for.
            if (amount > debt.Amount)
                throw new ArgumentException($"مبلغ پرداخت ({amount:N0} تومان) بیشتر از بدهی باقی‌مانده ({debt.Amount:N0} تومان) است");

            var user = new UserManager().FindByUsername(debt.Username);
            if (user == null) return false;

            decimal remaining = debt.Amount - amount;
            bool fullyPaid = remaining <= 0;

            int balRows = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Atomic conditional deduction of the user's balance.
                    balRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance - @amt WHERE username = @u AND balance >= @amt",
                        cmd => { cmd.Parameters.AddWithValue("@amt", amount); cmd.Parameters.AddWithValue("@u", debt.Username); }, tx);

                    if (balRows == 0)
                        throw new InsufficientBalanceException(debt.Username, user.Balance, amount);

                    if (fullyPaid)
                    {
                        Database.Instance.Execute(
                            "UPDATE debts SET is_paid = 1, paid_at = @pa WHERE id = @id",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@pa", DateTime.UtcNow.ToString("o"));
                                cmd.Parameters.AddWithValue("@id", debtId);
                            }, tx);
                    }
                    else
                    {
                        Database.Instance.Execute(
                            "UPDATE debts SET amount = @amt WHERE id = @id",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@amt", remaining);
                                cmd.Parameters.AddWithValue("@id", debtId);
                            }, tx);
                    }
                });
            }
            catch (InsufficientBalanceException)
            {
                throw new InvalidOperationException("موجودی کاربر کافی نیست");
            }
            catch (Exception ex)
            {
                AuditLog.Log("DebtManager", $"PartialPayDebt failed for debt {debtId}: {ex.Message}");
                throw;
            }

            AuditLog.Log("DebtManager", $"Partial debt payment: {debt.Username} - {amount:N0} Toman (Remaining: {remaining:N0})");
            return true;
        }

        public void DeleteDebt(int id)
        {
            Database.Instance.Execute("DELETE FROM debts WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("DebtManager", $"Debt deleted: ID {id}");
        }

        /// <summary>
        /// Gets total debt statistics.
        /// </summary>
        public (int TotalDebts, decimal TotalAmount, int UnpaidCount, decimal UnpaidAmount) GetDebtStats()
        {
            var stats = Database.Instance.QueryOne(
                "SELECT COUNT(*), COALESCE(SUM(amount), 0), SUM(CASE WHEN is_paid = 0 THEN 1 ELSE 0 END), COALESCE(SUM(CASE WHEN is_paid = 0 THEN amount ELSE 0 END), 0) FROM debts",
                null,
                r => new
                {
                    Total = r.GetInt32(0),
                    TotalAmt = r.GetDecimal(1),
                    Unpaid = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                    UnpaidAmt = r.GetDecimal(3)
                });

            return (stats.Total, stats.TotalAmt, stats.Unpaid, stats.UnpaidAmt);
        }
    }
}
