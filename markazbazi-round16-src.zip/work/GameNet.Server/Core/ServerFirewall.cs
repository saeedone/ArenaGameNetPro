using System;
using System.IO;
using System.Windows.Forms;
using GameNet.Shared.Diagnostics;
using GameNet.Shared.SelfHeal;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Round 15: Windows Firewall on the server. Without an "allow" rule (or with the
    /// "block" rule Windows creates when its "allow access" prompt is cancelled, or when
    /// only "Private" was ticked while the network is "Public") no kiosk can connect,
    /// and the server shows no station at all, with no error anywhere.
    /// </summary>
    public static class ServerFirewall
    {
        public static int TcpPort = GameNet.Shared.Protocol.DefaultPort;
        public static volatile string LastStatus = "بررسی نشده";
        public static volatile bool LastOk;

        private static string ExePath { get { return Application.ExecutablePath; } }
        private static string SkipFile { get { return Path.Combine(Guardian.StateDir("Server"), "firewall_skip.flag"); } }

        /// <summary>Checks the rules (slow: netsh); safe on any thread.</summary>
        public static bool Check(out string why)
        {
            bool ok = FirewallHelper.ServerRulesOk(ExePath, out why);
            LastOk = ok;
            LastStatus = ok ? "✅ فایروال ویندوز اجازهٔ اتصال کیوسک‌ها را می‌دهد" : "❌ " + why;
            return ok;
        }

        /// <summary>Adds the rules; asks Windows for administrator approval when needed.</summary>
        public static bool Fix(IWin32Window owner)
        {
            var cmds = FirewallHelper.ServerAllowCommands(ExePath, TcpPort);
            bool ran;
            if (FirewallHelper.IsElevated())
            {
                string o; ran = true;
                foreach (var c in cmds) FirewallHelper.Netsh(c, out o);
            }
            else ran = FirewallHelper.RunElevated(cmds);
            string why;
            bool ok = ran && Check(out why);
            try { ActivityJournal.Record(ActivityJournal.Server, ok ? "فایروال ویندوز برای کیوسک‌ها باز شد" : "باز کردن فایروال ویندوز انجام نشد"); } catch { }
            try { if (ok && File.Exists(SkipFile)) File.Delete(SkipFile); } catch { }
            return ok;
        }

        /// <summary>
        /// At start: checks in the background; if the rules are missing, fixes them silently
        /// when the server runs as administrator, otherwise asks the operator once (with
        /// "do not ask again").
        /// </summary>
        public static void CheckAtStartup(Form owner)
        {
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                string why;
                if (Check(out why)) return;
                FaultJournal.Raise("NET-013", why);
                try
                {
                    owner.BeginInvoke((Action)(() =>
                    {
                        try
                        {
                            if (FirewallHelper.IsElevated()) { Fix(owner); return; }
                            if (File.Exists(SkipFile)) return;
                            var r = MessageBox.Show(owner,
                                "فایروال ویندوز ممکن است جلوی اتصال کیوسک‌ها به این سرور را بگیرد — یکی از علت‌های رایج «کلاینت در سرور نشان داده نمی‌شود».\n\n" + why +
                                "\n\nبرای باز کردن آن، ویندوز یک بار تأیید مدیر (Administrator) می‌خواهد. انجام شود؟\n\n(بله = باز کن، خیر = این بار نه، لغو = دیگر نپرس)",
                                "فایروال ویندوز", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                            if (r == DialogResult.Cancel) { try { File.WriteAllText(SkipFile, DateTime.Now.ToString("o")); } catch { } return; }
                            if (r != DialogResult.Yes) return;
                            bool ok = Fix(owner);
                            MessageBox.Show(owner, ok ? "✅ فایروال برای کیوسک‌ها باز شد." : "انجام نشد. از تب «🩺 عیب‌یابی اتصال» دوباره امتحان کنید یا سرور را با «Run as administrator» باز کنید.",
                                "فایروال ویندوز", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                        }
                        catch { }
                    }));
                }
                catch { }
            });
        }
    }
}
