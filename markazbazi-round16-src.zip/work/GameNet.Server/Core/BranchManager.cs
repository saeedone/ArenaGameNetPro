using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using GameNet.Shared;
using Newtonsoft.Json;

namespace GameNet.Server.Core
{
    public class BranchManager
    {
        public Branch CreateBranch(string name, string address, string phone, string managerName, int stationCount = 0,
            string serverIp = "", int serverPort = 0)
        {
            if (string.IsNullOrEmpty(name)) throw new ArgumentException("نام شعبه الزامی است");
            Database.Instance.Execute("INSERT INTO branches (name, address, phone, manager_name, station_count, is_active, created_at, server_ip, server_port) VALUES (@n, @a, @p, @m, @s, 1, @t, @ip, @port)",
                cmd => {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@a", address ?? "");
                    cmd.Parameters.AddWithValue("@p", phone ?? "");
                    cmd.Parameters.AddWithValue("@m", managerName ?? "");
                    cmd.Parameters.AddWithValue("@s", stationCount);
                    cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@ip", serverIp ?? "");
                    cmd.Parameters.AddWithValue("@port", serverPort);
                });
            var id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Branch, "BranchCreated", name);
            return new Branch { Id = id, Name = name, Address = address, Phone = phone, ManagerName = managerName, StationCount = stationCount, IsActive = true, ServerIp = serverIp ?? "", ServerPort = serverPort };
        }

        public List<Branch> GetAllBranches()
        {
            return Database.Instance.Query<Branch>("SELECT id, name, address, phone, manager_name, station_count, is_active, created_at, server_ip, server_port FROM branches ORDER BY name",
                null, r => new Branch {
                    Id = r.GetInt32(0), Name = r.GetString(1),
                    Address = r.IsDBNull(2) ? "" : r.GetString(2),
                    Phone = r.IsDBNull(3) ? "" : r.GetString(3),
                    ManagerName = r.IsDBNull(4) ? "" : r.GetString(4),
                    StationCount = r.IsDBNull(5) ? 0 : r.GetInt32(5),
                    IsActive = r.GetBoolean(6),
                    CreatedAt = r.GetDateTime(7),
                    ServerIp = r.IsDBNull(8) ? "" : r.GetString(8),
                    ServerPort = r.IsDBNull(9) ? 0 : r.GetInt32(9)
                });
        }

        public Branch GetBranch(int id)
        {
            return Database.Instance.QueryOne("SELECT id, name, address, phone, manager_name, station_count, is_active, created_at, server_ip, server_port FROM branches WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new Branch {
                    Id = r.GetInt32(0), Name = r.GetString(1),
                    Address = r.IsDBNull(2) ? "" : r.GetString(2),
                    Phone = r.IsDBNull(3) ? "" : r.GetString(3),
                    ManagerName = r.IsDBNull(4) ? "" : r.GetString(4),
                    StationCount = r.IsDBNull(5) ? 0 : r.GetInt32(5),
                    IsActive = r.GetBoolean(6),
                    CreatedAt = r.GetDateTime(7),
                    ServerIp = r.IsDBNull(8) ? "" : r.GetString(8),
                    ServerPort = r.IsDBNull(9) ? 0 : r.GetInt32(9)
                });
        }

        public void UpdateBranch(int id, string name, string address, string phone, string managerName, int stationCount, bool isActive,
            string serverIp = null, int? serverPort = null)
        {
            // Read existing server_ip/server_port if not provided so we don't
            // clobber them when only updating basic fields.
            string ip = serverIp;
            int? port = serverPort;
            if (ip == null || port == null)
            {
                var existing = GetBranch(id);
                if (existing != null)
                {
                    if (ip == null) ip = existing.ServerIp;
                    if (port == null) port = existing.ServerPort;
                }
            }
            Database.Instance.Execute("UPDATE branches SET name = @n, address = @a, phone = @p, manager_name = @m, station_count = @s, is_active = @act, server_ip = @ip, server_port = @port WHERE id = @id",
                cmd => {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@a", address ?? "");
                    cmd.Parameters.AddWithValue("@p", phone ?? "");
                    cmd.Parameters.AddWithValue("@m", managerName ?? "");
                    cmd.Parameters.AddWithValue("@s", stationCount);
                    cmd.Parameters.AddWithValue("@act", isActive ? 1 : 0);
                    cmd.Parameters.AddWithValue("@ip", ip ?? "");
                    cmd.Parameters.AddWithValue("@port", port ?? 0);
                    cmd.Parameters.AddWithValue("@id", id);
                });
        }

        public void DeleteBranch(int id)
        {
            Database.Instance.Execute("DELETE FROM branches WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", id));
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Branch, "BranchDeleted", id.ToString());
        }

        public BranchSummary GetBranchSummary(int branchId)
        {
            var branch = GetBranch(branchId);
            if (branch == null) return null;
            try
            {
                var revenue = new ReportEngine().GetRevenueReport(DateTime.UtcNow.AddDays(-30), DateTime.UtcNow);
                return new BranchSummary { Branch = branch, MonthlyRevenue = revenue.TotalRevenue, MonthlySessions = revenue.TotalSessions, ActiveStations = branch.StationCount };
            }
            catch { return new BranchSummary { Branch = branch }; }
        }

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 9: queries the remote branch's REST API
        /// (/api/status) and returns the parsed JSON. Returns null on any
        /// network or HTTP error. Uses a 3-second timeout so a slow/unreachable
        /// branch doesn't block the UI thread.
        ///
        /// The remote branch must have RestApiServer enabled (ApiPort > 0 in
        /// its options.json) for this to succeed.
        /// </summary>
        public string QueryBranchStatus(int branchId)
        {
            var branch = GetBranch(branchId);
            if (branch == null || string.IsNullOrEmpty(branch.ServerIp) || branch.ServerPort <= 0)
                return null;
            try
            {
                var url = $"http://{branch.ServerIp}:{branch.ServerPort}/api/status";
                var req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "GET";
                req.Timeout = 3000;
                req.ReadWriteTimeout = 3000;
                using (var resp = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Branch", $"QueryBranchStatus failed for {branch.Name} ({branch.ServerIp}:{branch.ServerPort}): " + ex.Message);
                return null;
            }
        }

        /// <summary>
        /// Parses the JSON returned by QueryBranchStatus into a typed object
        /// for the UI to consume. Returns null if the JSON is null or invalid.
        /// </summary>
        public BranchRemoteStatus ParseBranchStatus(string json)
        {
            if (string.IsNullOrEmpty(json)) return null;
            try { return JsonConvert.DeserializeObject<BranchRemoteStatus>(json); }
            catch { return null; }
        }
    }

    public class Branch { public int Id; public string Name; public string Address; public string Phone; public string ManagerName; public int StationCount; public bool IsActive; public DateTime CreatedAt;
        // ADD-MULTI-FEATURES Feature 9: remote REST API endpoint for live status queries.
        public string ServerIp; public int ServerPort;
    }
    public class BranchSummary { public Branch Branch; public decimal MonthlyRevenue; public int MonthlySessions; public int ActiveStations; }

    /// <summary>
    /// Parsed shape of the /api/status JSON returned by a remote branch's
    /// RestApiServer. Populated by <see cref="BranchManager.ParseBranchStatus"/>.
    /// </summary>
    public class BranchRemoteStatus
    {
        public string server_version;
        public string started_at;
        public long uptime_seconds;
        public int connected_clients;
        public decimal today_income;
        public string database_provider;
        public int api_active_tokens;
    }
}
