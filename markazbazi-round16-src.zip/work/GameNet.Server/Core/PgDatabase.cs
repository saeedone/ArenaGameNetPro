// ============================================================================
// DEAD CODE - PostgreSQL migration not implemented in this build.
// The HAS_NPGSQL symbol is never defined in any csproj in this solution, so
// every member below throws NotSupportedException / returns a placeholder
// string at runtime. This file is kept only as a placeholder for a possible
// future PostgreSQL migration; do NOT rely on it. All production code paths
// use Database.cs (SQLite) exclusively.
// ============================================================================
using System;
using System.Collections.Generic;

// Npgsql is optional - this class is only used for PostgreSQL migration
// To enable, install Npgsql NuGet package and recompile with HAS_NPGSQL symbol
#if HAS_NPGSQL
using Npgsql;
using GameNet.Shared;
#endif

namespace GameNet.Server.Core
{
    public class PgDatabase
    {
        private readonly string _connectionString;

        public PgDatabase(string connectionString)
        {
            _connectionString = connectionString;
        }

        public bool TestConnection()
        {
#if HAS_NPGSQL
            try
            {
                using (var conn = new NpgsqlConnection(_connectionString))
                { conn.Open(); return conn.State == System.Data.ConnectionState.Open; }
            }
            catch { return false; }
#else
            throw new NotSupportedException("PostgreSQL support requires Npgsql package. Install it and recompile with HAS_NPGSQL symbol.");
#endif
        }

        public string MigrateFromSQLite(string sqliteDbPath)
        {
#if HAS_NPGSQL
            var report = new System.Text.StringBuilder();
            try
            {
                var sqliteConn = new System.Data.SQLite.SQLiteConnection($"Data Source={sqliteDbPath}");
                sqliteConn.Open();
                using (var pgConn = new NpgsqlConnection(_connectionString))
                {
                    pgConn.Open();
                    var tables = new[] { "users", "operators", "stations", "games", "pricing", "client_sessions", "food_items", "food_orders", "tickets", "announcements", "chat_messages", "debts", "print_jobs", "session_packages", "member_tiers", "user_tier_progress", "branches", "payment_transactions", "smart_pricing_rules", "enhanced_audit_log", "user_auto_recharge" };

                    foreach (var table in tables)
                    {
                        try
                        {
                            using (var cmd = sqliteConn.CreateCommand())
                            {
                                cmd.CommandText = $"SELECT * FROM {table}";
                                using (var reader = cmd.ExecuteReader())
                                {
                                    int rows = 0;
                                    while (reader.Read()) rows++;
                                    report.AppendLine($"{table}: {rows} rows ready for migration");
                                }
                            }
                        }
                        catch (Exception ex) { report.AppendLine($"{table}: SKIP - {ex.Message}"); }
                    }
                }
                sqliteConn.Close();
            }
            catch (Exception ex) { report.AppendLine($"Migration error: {ex.Message}"); }
            return report.ToString();
#else
            return "PostgreSQL migration requires Npgsql package. Install it and recompile with HAS_NPGSQL symbol.";
#endif
        }

        public string GeneratePgSchema()
        {
            return @"-- GameNet PostgreSQL Schema
CREATE EXTENSION IF NOT EXISTS ""uuid-ossp"";

CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password_hash VARCHAR(128) NOT NULL, display_name VARCHAR(100), balance DECIMAL(18,2) NOT NULL DEFAULT 0, is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), phone VARCHAR(20));
CREATE TABLE IF NOT EXISTS operators (id SERIAL PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password_hash VARCHAR(128) NOT NULL, salt VARCHAR(64) NOT NULL, display_name VARCHAR(100), permissions INTEGER NOT NULL DEFAULT 0, role_name VARCHAR(50) NOT NULL DEFAULT 'Operator', is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), last_login_at TIMESTAMPTZ, failed_login_attempts INTEGER NOT NULL DEFAULT 0, locked_until TIMESTAMPTZ, two_factor_secret VARCHAR(64), two_factor_enabled BOOLEAN NOT NULL DEFAULT FALSE);
CREATE TABLE IF NOT EXISTS stations (id SERIAL PRIMARY KEY, name VARCHAR(50) NOT NULL UNIQUE, ip_address VARCHAR(45), mac_address VARCHAR(17), pricing_plan_id INTEGER, category VARCHAR(50), status VARCHAR(20) NOT NULL DEFAULT 'available', notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS client_sessions (id SERIAL PRIMARY KEY, session_id VARCHAR(64) NOT NULL UNIQUE, username VARCHAR(50), station_name VARCHAR(50), machine_name VARCHAR(100), mac_address VARCHAR(17), state INTEGER NOT NULL DEFAULT 0, start_time TIMESTAMPTZ NOT NULL, end_time TIMESTAMPTZ, duration_minutes INTEGER NOT NULL DEFAULT 0, total_cost DECIMAL(18,2) NOT NULL DEFAULT 0, current_game VARCHAR(100), client_ip VARCHAR(45), last_heartbeat TIMESTAMPTZ, is_connected BOOLEAN NOT NULL DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS branches (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL, address TEXT, phone VARCHAR(20), manager_name VARCHAR(100), station_count INTEGER NOT NULL DEFAULT 0, is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS payment_transactions (id SERIAL PRIMARY KEY, username VARCHAR(50) NOT NULL, amount DECIMAL(18,2) NOT NULL, authority VARCHAR(100), status VARCHAR(20) NOT NULL DEFAULT 'pending', ref_id VARCHAR(50), gateway VARCHAR(30) NOT NULL DEFAULT 'zarinpal', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), verified_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS smart_pricing_rules (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL, rule_type VARCHAR(30) NOT NULL, condition_json TEXT, discount_percent DECIMAL(5,2) NOT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE, priority INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS enhanced_audit_log (id SERIAL PRIMARY KEY, category VARCHAR(30) NOT NULL, action VARCHAR(100) NOT NULL, details TEXT, level VARCHAR(10) NOT NULL DEFAULT 'Info', operator_name VARCHAR(50), client_ip VARCHAR(45), station_name VARCHAR(50), timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS user_auto_recharge (username VARCHAR(50) NOT NULL PRIMARY KEY, config_json TEXT NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS update_history (id SERIAL PRIMARY KEY, version_from VARCHAR(10), version_to VARCHAR(10), download_path TEXT, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());

-- Indexes
CREATE INDEX IF NOT EXISTS idx_sessions_username ON client_sessions(username);
CREATE INDEX IF NOT EXISTS idx_sessions_time ON client_sessions(start_time);
CREATE INDEX IF NOT EXISTS idx_audit_time ON enhanced_audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_category ON enhanced_audit_log(category);
CREATE INDEX IF NOT EXISTS idx_payments_username ON payment_transactions(username);
";
        }
    }
}
