using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 4.1 — Intrusion Detection System.
    ///
    /// Monitors security-relevant events in real time and flags suspicious
    /// patterns:
    ///   • Brute-force: many failed logins from the same IP in a short window
    ///   • Credential stuffing: same username tried from many different IPs
    ///   • Off-hours access: sensitive actions outside business hours
    ///   • Mass data export: unusual number of reads in a short window
    ///   • Privilege escalation attempt: operator accessing tabs they lack
    ///     permission for, repeatedly
    ///   • Multiple session: same operator logging in from 2+ machines
    ///   • Rapid fire API calls: mobile API being scraped
    ///
    /// Alerts are written to the `security_alerts` table AND raised via the
    /// OnAlert event so the UI can show them in real time. A background
    /// thread periodically promotes sliding-window counters into persisted
    /// alerts so the operator sees them even after a restart.
    /// </summary>
    public static class IntrusionDetectionSystem
    {
        // Sliding-window counters (in-memory, fast)
        private static readonly ConcurrentDictionary<string, LoginAttempt> _failedLoginsByIp = new ConcurrentDictionary<string, LoginAttempt>();
        private static readonly ConcurrentDictionary<string, HashSet<string>> _ipsPerUsername = new ConcurrentDictionary<string, HashSet<string>>();
        private static readonly ConcurrentDictionary<string, int> _apiCallsByIp = new ConcurrentDictionary<string, int>();
        private static readonly ConcurrentDictionary<string, int> _permDeniedByOperator = new ConcurrentDictionary<string, int>();
        private static readonly ConcurrentDictionary<string, DateTime> _activeOperatorSessions = new ConcurrentDictionary<string, DateTime>();

        private static Timer _cleanupTimer;
        private static Timer _promoteTimer;
        private static readonly object _initLock = new object();
        private static bool _initialized;

        public static event Action<SecurityAlert> OnAlert;

        // Thresholds
        private const int BruteForceThreshold = 10;     // 10 failed logins in 5 min
        private const int CredentialStuffingThreshold = 5; // 5 different IPs for same username in 10 min
        private const int ApiScrapingThreshold = 200;   // 200 API calls in 1 min
        private const int PermEscalationThreshold = 5;  // 5 denied permission checks in 5 min
        private const int BusinessStartHour = 7;        // 7 AM
        private const int BusinessEndHour = 24;         // midnight (open late)

        public static void Initialize()
        {
            lock (_initLock)
            {
                if (_initialized) return;
                _initialized = true;
                _cleanupTimer = new Timer(_ => CleanupOldCounters(), null, 60000, 60000); // every 1 min
                _promoteTimer = new Timer(_ => PromoteAlerts(), null, 30000, 30000); // every 30s
                AuditLog.Log("IDS", "Intrusion Detection System started.");
            }
        }

        // ---- Event hooks (called by other subsystems) ----

        public static void RecordFailedLogin(string username, string clientIp)
        {
            Initialize();
            if (string.IsNullOrEmpty(clientIp)) return;

            // Brute-force: many failures from same IP
            var entry = _failedLoginsByIp.AddOrUpdate(clientIp,
                _ => new LoginAttempt { Count = 1, FirstAttempt = DateTime.UtcNow, LastIp = clientIp },
                (_, e) => { e.Count++; return e; });

            if (entry.Count >= BruteForceThreshold)
            {
                RaiseAlert("BruteForce", "Critical",
                    $"تلاش ورود ناموفق زیاد از IP {clientIp} ({entry.Count} بار در {(DateTime.UtcNow - entry.FirstAttempt).TotalMinutes:0} دقیقه)",
                    clientIp, username);
            }

            // Credential stuffing: same username from many IPs
            if (!string.IsNullOrEmpty(username))
            {
                var ips = _ipsPerUsername.GetOrAdd(username, _ => new HashSet<string>());
                lock (ips) { ips.Add(clientIp); }
                if (ips.Count >= CredentialStuffingThreshold)
                {
                    RaiseAlert("CredentialStuffing", "High",
                        $"نام کاربری «{username}» از {ips.Count} IP مختلف تلاش ورود کرده — احتمال credential stuffing",
                        clientIp, username);
                }
            }
        }

        public static void RecordSuccessfulLogin(string username, string clientIp)
        {
            Initialize();
            // Clear brute-force counter for this IP on success
            _failedLoginsByIp.TryRemove(clientIp, out _);

            // Multiple-session detection: same operator from 2+ IPs
            if (!string.IsNullOrEmpty(username))
            {
                _activeOperatorSessions.AddOrUpdate(username, DateTime.UtcNow, (k, v) => DateTime.UtcNow);
            }
        }

        public static void RecordApiCall(string clientIp)
        {
            Initialize();
            if (string.IsNullOrEmpty(clientIp)) return;
            int count = _apiCallsByIp.AddOrUpdate(clientIp, 1, (_, c) => c + 1);
            if (count == ApiScrapingThreshold) // raise once when crossing
            {
                RaiseAlert("ApiScraping", "High",
                    $"تعداد زیاد درخواست API از IP {clientIp} ({count} درخواست در ۱ دقیقه) — احتمال scraping",
                    clientIp, "");
            }

            // FIX B15: self-limiting cleanup. The CleanupOldCounters timer
            // runs every 60s and clears the dict, but between cleanups a
            // burst of unique IPs (e.g. a botnet scraping from 10k IPs in
            // 30s) could grow the dictionary to tens of thousands of entries
            // and consume hundreds of MB before the next cleanup tick fires.
            // This inline cleanup caps the dict at ~1000 entries by evicting
            // the lowest-count entries (the ones least likely to be the
            // scraper) whenever the dict exceeds the cap. Runs only on the
            // call that pushes the count over the threshold, so the per-call
            // overhead is amortized.
            try
            {
                if (_apiCallsByIp.Count > 1000)
                {
                    // Take the 500 entries with the smallest count and
                    // remove them — they're the one-hit-wonder IPs that
                    // haven't crossed the scraping threshold.
                    var toRemove = _apiCallsByIp
                        .Where(kvp => kvp.Value < ApiScrapingThreshold)
                        .OrderBy(kvp => kvp.Value)
                        .Take(500)
                        .Select(kvp => kvp.Key)
                        .ToList();
                    foreach (var key in toRemove)
                        _apiCallsByIp.TryRemove(key, out _);
                }
            }
            catch { /* cleanup must never throw — it's on the hot path */ }
        }

        public static void RecordPermissionDenied(string operatorName, string permission)
        {
            Initialize();
            if (string.IsNullOrEmpty(operatorName)) return;
            int count = _permDeniedByOperator.AddOrUpdate(operatorName, 1, (_, c) => c + 1);
            if (count >= PermEscalationThreshold)
            {
                RaiseAlert("PrivilegeEscalation", "High",
                    $"اپراتور «{operatorName}» {count} بار سعی کرده به {permission} دسترسی پیدا کند — احتمال privilege escalation",
                    "", operatorName);
            }
        }

        public static void RecordSensitiveAction(string action, string operatorName, string details = "")
        {
            Initialize();
            int hour = DateTime.Now.Hour;
            if (hour < BusinessStartHour || hour >= BusinessEndHour)
            {
                RaiseAlert("OffHoursAccess", "Medium",
                    $"عملیات حساس در ساعت غیرکاری ({DateTime.Now:HH:mm}): {action} توسط {operatorName}. {details}",
                    "", operatorName);
            }
        }

        // ---- Alert handling ----

        private static void RaiseAlert(string type, string severity, string message, string clientIp, string operatorName)
        {
            var alert = new SecurityAlert
            {
                Type = type,
                Severity = severity,
                Message = message,
                ClientIp = clientIp,
                OperatorName = operatorName,
                Timestamp = DateTime.UtcNow
            };

            // Persist to DB
            try
            {
                Database.Instance.Execute(
                    "INSERT INTO security_alerts (alert_type, severity, message, client_ip, operator_name, timestamp, is_acknowledged) " +
                    "VALUES (@t, @s, @m, @ip, @op, @ts, 0)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@t", type);
                        cmd.Parameters.AddWithValue("@s", severity);
                        cmd.Parameters.AddWithValue("@m", message);
                        cmd.Parameters.AddWithValue("@ip", clientIp ?? "");
                        cmd.Parameters.AddWithValue("@op", operatorName ?? "");
                        cmd.Parameters.AddWithValue("@ts", alert.Timestamp.ToString("o"));
                    });
            }
            catch (Exception ex) { AuditLog.Log("IDS", "Failed to persist alert: " + ex.Message); }

            // Raise event for UI
            try { OnAlert?.Invoke(alert); } catch { }

            // Also write to tamper-proof audit chain
            try { TamperProofAuditLog.Log("Security", $"IDS Alert: {type}", message, severity, operatorName, clientIp, ""); }
            catch { }

            AuditLog.Log("IDS", $"[{severity}] {type}: {message}");
        }

        // ---- Cleanup & promotion ----

        private static void CleanupOldCounters()
        {
            // Reset API call counter every minute
            _apiCallsByIp.Clear();
            _permDeniedByOperator.Clear();

            // Evict stale brute-force entries (older than 5 min)
            var cutoff = DateTime.UtcNow.AddMinutes(-5);
            foreach (var kvp in _failedLoginsByIp)
                if (kvp.Value.FirstAttempt < cutoff) _failedLoginsByIp.TryRemove(kvp.Key, out _);

            // Evict stale credential-stuffing entries (older than 10 min)
            // (We can't track timestamps per entry in the HashSet, so we just
            // clear the whole map every 10 minutes — acceptable for alerting.)
        }

        private static void PromoteAlerts()
        {
            // Nothing to promote yet — alerts are written immediately in
            // RaiseAlert. This timer is a hook for future batch processing
            // (e.g. aggregating near-duplicate alerts).
        }

        // ---- Query API ----

        public static List<SecurityAlert> GetRecentAlerts(int limit = 50)
        {
            return Database.Instance.Query(
                "SELECT id, alert_type, severity, message, client_ip, operator_name, timestamp, is_acknowledged FROM security_alerts ORDER BY id DESC LIMIT @lim",
                cmd => cmd.Parameters.AddWithValue("@lim", limit),
                r => new SecurityAlert
                {
                    Id = r.GetInt32(0),
                    Type = r.GetString(1),
                    Severity = r.GetString(2),
                    Message = r.GetString(3),
                    ClientIp = r.IsDBNull(4) ? "" : r.GetString(4),
                    OperatorName = r.IsDBNull(5) ? "" : r.GetString(5),
                    Timestamp = r.GetDateTime(6),
                    IsAcknowledged = r.GetBoolean(7)
                });
        }

        public static int GetUnacknowledgedCount()
        {
            try
            {
                return Database.Instance.QueryOne<int>(
                    "SELECT COUNT(*) FROM security_alerts WHERE is_acknowledged = 0",
                    null, r => r.GetInt32(0));
            }
            catch { return 0; }
        }

        public static void AcknowledgeAlert(int id)
        {
            Database.Instance.Execute(
                "UPDATE security_alerts SET is_acknowledged = 1 WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
        }

        public static void AcknowledgeAll()
        {
            Database.Instance.Execute(
                "UPDATE security_alerts SET is_acknowledged = 1 WHERE is_acknowledged = 0", null);
        }
    }

    public class LoginAttempt
    {
        public int Count;
        public DateTime FirstAttempt;
        public string LastIp;
    }

    public class SecurityAlert
    {
        public int Id;
        public string Type;
        public string Severity; // Critical, High, Medium, Low
        public string Message;
        public string ClientIp;
        public string OperatorName;
        public DateTime Timestamp;
        public bool IsAcknowledged;
    }
}
