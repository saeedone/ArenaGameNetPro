using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 3.1 — Central key management with rotation.
    ///
    /// Manages three classes of keys:
    ///
    ///   • MasterDataKey    — used by DataEncryption for AES field encryption.
    ///                        Rotated every 90 days. Old keys are retained so
    ///                        legacy ciphertext can still be decrypted; new
    ///                        writes always use the current key.
    ///
    ///   • MessageSecurityKey — used by MessageSecurity for HMAC signing.
    ///                          Rotated every 30 days. Both sides derive
    ///                          per-session keys from this, so rotation is
    ///                          seamless (a new connection uses the new key).
    ///
    ///   • BackupKey        — used by BackupManager to encrypt backup files.
    ///                        Rotated every 180 days. Old backups remain
    ///                        decryptable with their archived key.
    ///
    /// Key storage: a single encrypted key vault file (key_vault.dat) holds
    /// all keys + metadata. The vault itself is sealed with AES-256 using a
    /// key derived from the operator-entered vault password (via PBKDF2,
    /// 100k iterations). The password is NOT stored anywhere; it must be
    /// re-entered on each server start (or cached in memory for the session).
    ///
    /// Rotation policy:
    ///   - On startup, check each key's CreatedAt; if older than its rotation
    ///     period, generate a new key, mark the old as "retired" (still used
    ///     for decryption), and log the rotation.
    ///   - The operator can force-rotate from the security tab.
    /// </summary>
    public static class KeyManager
    {
        public const int DataKeyRotationDays = 90;
        public const int MessageKeyRotationDays = 30;
        public const int BackupKeyRotationDays = 180;

        private const string VaultFile = "key_vault.dat";
        private const string VaultSaltFile = "key_vault.salt";

        private static KeyVault _vault;
        private static byte[] _vaultPasswordKey;
        private static readonly object _lock = new object();

        public static bool IsInitialized => _vault != null;
        public static bool IsUnlocked => _vault != null && _vaultPasswordKey != null;

        /// <summary>
        /// Initializes the key vault. If the vault file doesn't exist, a new
        /// one is created with fresh keys and sealed with the given password.
        /// If it exists, the password is verified and the vault is loaded.
        /// Throws if the password is wrong.
        /// </summary>
        public static void Initialize(string vaultPassword)
        {
            if (string.IsNullOrEmpty(vaultPassword))
                throw new ArgumentException("رمز vault الزامی است");

            lock (_lock)
            {
                string vaultPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, VaultFile);
                string saltPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, VaultSaltFile);

                // Load or generate the salt
                byte[] salt;
                if (File.Exists(saltPath))
                {
                    salt = File.ReadAllBytes(saltPath);
                }
                else
                {
                    salt = new byte[16];
                    using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
                    File.WriteAllBytes(saltPath, salt);
                }

                // Derive the vault-sealing key from the password
                _vaultPasswordKey = new byte[32];
                using (var pbkdf2 = new Rfc2898DeriveBytes(vaultPassword, salt, 100000, HashAlgorithmName.SHA256))
                    _vaultPasswordKey = pbkdf2.GetBytes(32);

                if (File.Exists(vaultPath))
                {
                    // Load and decrypt existing vault
                    _vault = LoadVault(vaultPath);
                    AuditLog.Log("KeyManager", "Key vault loaded and unlocked.");
                }
                else
                {
                    // Create a new vault with fresh keys
                    _vault = new KeyVault
                    {
                        CreatedAt = DateTime.UtcNow,
                        DataKeys = new List<KeyEntry> { GenerateKeyEntry("data") },
                        MessageKeys = new List<KeyEntry> { GenerateKeyEntry("msg") },
                        BackupKeys = new List<KeyEntry> { GenerateKeyEntry("backup") },
                    };
                    SaveVault(vaultPath);
                    AuditLog.Log("KeyManager", "New key vault created with fresh keys.");
                }

                // Check for needed rotations
                CheckRotations();
            }
        }

        /// <summary>Gets the current (newest) data-encryption key.</summary>
        public static byte[] GetCurrentDataKey()
        {
            EnsureUnlocked();
            return _vault.DataKeys[0].KeyBytes;
        }

        /// <summary>Gets the current (newest) message-signing key.</summary>
        public static byte[] GetCurrentMessageKey()
        {
            EnsureUnlocked();
            return _vault.MessageKeys[0].KeyBytes;
        }

        /// <summary>Gets the current (newest) backup-encryption key.</summary>
        public static byte[] GetCurrentBackupKey()
        {
            EnsureUnlocked();
            return _vault.BackupKeys[0].KeyBytes;
        }

        /// <summary>
        /// Finds a data key by its ID (for decrypting old ciphertext). The
        /// ciphertext prefix is "ENC1:" but the key id is embedded in a
        /// future format. For now, we try all retained keys.
        /// </summary>
        public static IEnumerable<byte[]> GetAllDataKeys()
        {
            EnsureUnlocked();
            return _vault.DataKeys.ConvertAll(k => k.KeyBytes);
        }

        /// <summary>Force-rotates the data key (operator action).</summary>
        public static void RotateDataKey()
        {
            lock (_lock)
            {
                EnsureUnlocked();
                var newKey = GenerateKeyEntry("data");
                _vault.DataKeys.Insert(0, newKey);
                // Keep at most 5 old keys
                if (_vault.DataKeys.Count > 5) _vault.DataKeys.RemoveRange(5, _vault.DataKeys.Count - 5);
                SaveVault();
                AuditLog.Log("KeyManager", $"Data key rotated. New key id: {newKey.Id}");
            }
        }

        /// <summary>Force-rotates the message-signing key.</summary>
        public static void RotateMessageKey()
        {
            lock (_lock)
            {
                EnsureUnlocked();
                var newKey = GenerateKeyEntry("msg");
                _vault.MessageKeys.Insert(0, newKey);
                if (_vault.MessageKeys.Count > 5) _vault.MessageKeys.RemoveRange(5, _vault.MessageKeys.Count - 5);
                SaveVault();
                AuditLog.Log("KeyManager", $"Message key rotated. New key id: {newKey.Id}");
            }
        }

        /// <summary>Force-rotates the backup key.</summary>
        public static void RotateBackupKey()
        {
            lock (_lock)
            {
                EnsureUnlocked();
                var newKey = GenerateKeyEntry("backup");
                _vault.BackupKeys.Insert(0, newKey);
                if (_vault.BackupKeys.Count > 5) _vault.BackupKeys.RemoveRange(5, _vault.BackupKeys.Count - 5);
                SaveVault();
                AuditLog.Log("KeyManager", $"Backup key rotated. New key id: {newKey.Id}");
            }
        }

        /// <summary>
        /// Checks if any key is older than its rotation period and rotates
        /// it if so. Called on startup and periodically.
        /// </summary>
        public static void CheckRotations()
        {
            lock (_lock)
            {
                EnsureUnlocked();
                bool changed = false;
                if ((DateTime.UtcNow - _vault.DataKeys[0].CreatedAt).TotalDays > DataKeyRotationDays)
                { RotateDataKey(); changed = true; }
                if ((DateTime.UtcNow - _vault.MessageKeys[0].CreatedAt).TotalDays > MessageKeyRotationDays)
                { RotateMessageKey(); changed = true; }
                if ((DateTime.UtcNow - _vault.BackupKeys[0].CreatedAt).TotalDays > BackupKeyRotationDays)
                { RotateBackupKey(); changed = true; }
                if (changed) AuditLog.Log("KeyManager", "Scheduled key rotation completed.");
            }
        }

        /// <summary>Returns a summary of all keys for the UI.</summary>
        public static KeyVaultSummary GetSummary()
        {
            EnsureUnlocked();
            return new KeyVaultSummary
            {
                VaultCreatedAt = _vault.CreatedAt,
                DataKey = Summarize(_vault.DataKeys[0], DataKeyRotationDays),
                MessageKey = Summarize(_vault.MessageKeys[0], MessageKeyRotationDays),
                BackupKey = Summarize(_vault.BackupKeys[0], BackupKeyRotationDays),
            };
        }

        private static KeySummary Summarize(KeyEntry entry, int rotationDays)
        {
            return new KeySummary
            {
                Id = entry.Id,
                CreatedAt = entry.CreatedAt,
                AgeDays = (int)(DateTime.UtcNow - entry.CreatedAt).TotalDays,
                RotationDays = rotationDays,
                DaysUntilRotation = rotationDays - (int)(DateTime.UtcNow - entry.CreatedAt).TotalDays,
            };
        }

        private static KeyEntry GenerateKeyEntry(string prefix)
        {
            var key = new byte[32];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(key);
            return new KeyEntry
            {
                Id = prefix + "_" + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                CreatedAt = DateTime.UtcNow,
                KeyBytes = key,
            };
        }

        private static void EnsureUnlocked()
        {
            if (_vault == null || _vaultPasswordKey == null)
                throw new InvalidOperationException("Key vault is not initialized. Call Initialize(password) first.");
        }

        private static void SaveVault(string path = null)
        {
            path = path ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, VaultFile);
            // Serialize the vault to JSON, then AES-encrypt with the vault password key.
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(_vault);
            byte[] plain = Encoding.UTF8.GetBytes(json);

            byte[] iv;
            byte[] cipher;
            using (var aes = Aes.Create())
            {
                aes.Key = _vaultPasswordKey;
                aes.GenerateIV();
                iv = aes.IV;
                using (var enc = aes.CreateEncryptor())
                    cipher = enc.TransformFinalBlock(plain, 0, plain.Length);
            }

            byte[] result = new byte[iv.Length + cipher.Length];
            Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
            Buffer.BlockCopy(cipher, 0, result, iv.Length, cipher.Length);
            File.WriteAllBytes(path, result);
        }

        private static KeyVault LoadVault(string path)
        {
            byte[] all = File.ReadAllBytes(path);
            if (all.Length < 16) throw new InvalidOperationException("Vault file is corrupt.");

            byte[] iv = new byte[16];
            byte[] cipher = new byte[all.Length - 16];
            Buffer.BlockCopy(all, 0, iv, 0, 16);
            Buffer.BlockCopy(all, 16, cipher, 0, cipher.Length);

            byte[] plain;
            using (var aes = Aes.Create())
            {
                aes.Key = _vaultPasswordKey;
                aes.IV = iv;
                try
                {
                    using (var dec = aes.CreateDecryptor())
                        plain = dec.TransformFinalBlock(cipher, 0, cipher.Length);
                }
                catch (CryptographicException)
                {
                    throw new CryptographicException("رمز vault اشتباه است یا فایل vault خراب است.");
                }
            }

            return Newtonsoft.Json.JsonConvert.DeserializeObject<KeyVault>(Encoding.UTF8.GetString(plain));
        }
    }

    // ---- DTOs ----

    public class KeyVault
    {
        public DateTime CreatedAt;
        public List<KeyEntry> DataKeys;
        public List<KeyEntry> MessageKeys;
        public List<KeyEntry> BackupKeys;
    }

    public class KeyEntry
    {
        public string Id;
        public DateTime CreatedAt;
        public byte[] KeyBytes;
    }

    public class KeyVaultSummary
    {
        public DateTime VaultCreatedAt;
        public KeySummary DataKey;
        public KeySummary MessageKey;
        public KeySummary BackupKey;
    }

    public class KeySummary
    {
        public string Id;
        public DateTime CreatedAt;
        public int AgeDays;
        public int RotationDays;
        public int DaysUntilRotation;
    }
}
