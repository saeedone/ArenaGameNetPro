using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class LoyaltyEntry { public int UserId; public string Username = ""; public int Points; public string Tier = ""; }
    public class AdvancedLoyaltyManager {
        public void AddPoints(string username, int points) { try { EnsureTable(); Database.Instance.Execute("INSERT OR REPLACE INTO loyalty_points (username, points, tier, last_earned) VALUES (@u, @p, @t, @d)", c => { c.Parameters.AddWithValue("@u", username); c.Parameters.AddWithValue("@p", points); c.Parameters.AddWithValue("@t", points >= 1000 ? "Gold" : points >= 500 ? "Silver" : "Bronze"); c.Parameters.AddWithValue("@d", DateTime.UtcNow.ToString("o")); }); AuditLog.Log("Loyalty", $"Added {points} points to {username}"); } catch { } }
        public List<LoyaltyEntry> GetAll() { var list = new List<LoyaltyEntry>(); try { EnsureTable(); Database.Instance.Query("SELECT rowid, username, points, tier FROM loyalty_points ORDER BY points DESC", null, r => { list.Add(new LoyaltyEntry { UserId = r.GetInt32(0), Username = r.GetString(1), Points = r.GetInt32(2), Tier = r.IsDBNull(3) ? "" : r.GetString(3) }); return true; }); } catch { } return list; }
        public void Delete(int rowid) { try { Database.Instance.Execute("DELETE FROM loyalty_points WHERE rowid=@id", c => c.Parameters.AddWithValue("@id", rowid)); } catch { } }
        private void EnsureTable() { Database.Instance.Execute("CREATE TABLE IF NOT EXISTS loyalty_points (username TEXT PRIMARY KEY, points INTEGER DEFAULT 0, tier TEXT, last_earned TEXT)", null); }
    }
}
