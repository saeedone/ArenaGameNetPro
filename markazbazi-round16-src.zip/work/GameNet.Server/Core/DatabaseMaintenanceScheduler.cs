using System;
using System.Threading;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX LONGTERM-1: nothing in this codebase ever automatically pruned
    /// the log-type tables. Two of the three cleanup methods this class
    /// calls (EnhancedAuditLog.CleanupOldEntries, ChatManager.
    /// CleanupOldMessages) already existed and were fully correct — they
    /// just had no scheduler, only a manual "cleanup" button in
    /// SecurityForm that most operators would never think to click. The
    /// third (AuditLog.CleanupOldEntries, for the base audit_log table —
    /// the single highest-volume table in the app) didn't exist at all
    /// until this fix.
    ///
    /// Left alone, a 24/7 cybercafe server accumulates one audit_log row
    /// for nearly every event (login, payment, sync tick, idle check,
    /// error...) with no upper bound. Over a year that's easily millions
    /// of rows — growing disk usage forever and making every date-filtered
    /// query slower every single day. This runs once every 24h and prunes
    /// rows older than a fixed retention window from each of the three
    /// tables. It does NOT touch business/financial records (client_sessions,
    /// payment_transactions, loyalty_history, debts, etc.) or the
    /// tamper-evident audit_chain (pruning a hash-chained log would defeat
    /// its own purpose) — only genuinely disposable diagnostic/chat logs.
    /// </summary>
    public class DatabaseMaintenanceScheduler : IDisposable
    {
        private Timer _timer;
        private DateTime _lastRunUtc = DateTime.MinValue;
        private const int TickHours = 1;       // check cadence
        private const int RunEveryHours = 24;  // actual maintenance cadence

        // Retention windows — deliberately generous (not aggressive) so
        // recent history stays available for the operator to review.
        private const int AuditLogRetentionDays = 180;
        private const int EnhancedAuditLogRetentionDays = 180;
        private const int ChatRetentionDays = 90;

        public void Start()
        {
            _timer = new Timer(Tick, null, TimeSpan.FromHours(TickHours), TimeSpan.FromHours(TickHours));
        }

        public void Stop()
        {
            _timer?.Dispose();
            _timer = null;
        }

        private void Tick(object state)
        {
            try
            {
                if ((DateTime.UtcNow - _lastRunUtc).TotalHours < RunEveryHours) return;
                _lastRunUtc = DateTime.UtcNow;
                RunNow();
            }
            catch (Exception ex)
            {
                AuditLog.Log("DbMaintenance", "Scheduled maintenance tick failed: " + ex.Message);
            }
        }

        /// <summary>Runs all three cleanups immediately (also callable manually, e.g. from a UI button).</summary>
        public static void RunNow()
        {
            int a = 0, e = 0, c = 0;
            try { a = AuditLog.CleanupOldEntries(AuditLogRetentionDays); } catch (Exception ex) { AuditLog.Log("DbMaintenance", "audit_log cleanup failed: " + ex.Message); }
            try { e = EnhancedAuditLog.CleanupOldEntries(EnhancedAuditLogRetentionDays); } catch (Exception ex) { AuditLog.Log("DbMaintenance", "enhanced_audit_log cleanup failed: " + ex.Message); }
            try { c = new ChatManager().CleanupOldMessages(ChatRetentionDays); } catch (Exception ex) { AuditLog.Log("DbMaintenance", "chat_messages cleanup failed: " + ex.Message); }
            AuditLog.Log("DbMaintenance", $"Scheduled log cleanup: audit_log -{a}, enhanced_audit_log -{e}, chat_messages -{c}");
        }

        public void Dispose() => Stop();
    }
}
