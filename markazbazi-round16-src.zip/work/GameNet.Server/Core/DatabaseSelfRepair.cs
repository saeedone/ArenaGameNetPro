using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using GameNet.Shared.Diagnostics;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Round 12 self-repair for the SQLite database (gamenet.db).
    ///  - Before the server opens the database, PRAGMA quick_check checks it.
    ///  - If it is damaged (for example power was cut during a write), the newest backup
    ///    in the Backups folder that passes the same check is offered (operator backups,
    ///    automatic backups and the daily self-repair copies). On "Yes" the damaged file
    ///    (and its -wal / -shm files) is kept as gamenet.db.damaged-&lt;time&gt; and the
    ///    backup is copied in. Nothing is deleted.
    ///  - Once a day, after a healthy start, a consistent copy is made
    ///    (Backups\gamenet_selfheal_yyyyMMdd.db, the three newest are kept), so a recent
    ///    good copy exists even when nobody makes backups.
    /// </summary>
    public static class DatabaseSelfRepair
    {
        public static string BackupDir()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups");
        }

        /// <summary>"ok" when the file passes quick_check; otherwise the problem text.</summary>
        public static string Check(string dbPath)
        {
            try
            {
                using (var c = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;FailIfMissing=True;"))
                {
                    c.Open();
                    using (var cmd = new SQLiteCommand("PRAGMA quick_check;", c))
                    {
                        cmd.CommandTimeout = 120;
                        var first = Convert.ToString(cmd.ExecuteScalar());
                        return string.Equals(first, "ok", StringComparison.OrdinalIgnoreCase) ? "ok" : (first ?? "unknown");
                    }
                }
            }
            catch (Exception ex) { return ex.GetType().Name + ": " + ex.Message; }
        }

        /// <summary>
        /// Checks gamenet.db and, if it is damaged, offers the newest good backup.
        /// Returns false only when the database is damaged and was not replaced.
        /// </summary>
        public static bool CheckAndRepair(string dbPath)
        {
            if (!File.Exists(dbPath)) return true;           // first start: a new database is created
            string result = Check(dbPath);
            if (result == "ok") return true;
            AuditLog.Log("DatabaseSelfRepair", "gamenet.db failed quick_check: " + result);

            string good = null; DateTime goodTime = DateTime.MinValue;
            try
            {
                if (Directory.Exists(BackupDir()))
                {
                    foreach (var bf in Directory.GetFiles(BackupDir(), "*.db").OrderByDescending(f => File.GetLastWriteTime(f)))
                    {
                        if (Check(bf) == "ok") { good = bf; goodTime = File.GetLastWriteTime(bf); break; }
                    }
                }
            }
            catch (Exception ex) { AuditLog.Log("DatabaseSelfRepair", "backup scan failed: " + ex.Message); }

            if (good == null)
            {
                FaultJournal.Raise("HEAL-006", result);
                MessageBox.Show("پایگاه دادهٔ سرور (gamenet.db) خراب است و هیچ نسخهٔ پشتیبان سالمی در پوشهٔ Backups پیدا نشد.\n\n" +
                    "از فایل gamenet.db کپی بگیرید و پاکش نکنید، و برای پشتیبانی بفرستید.\n\nجزئیات: " + Shorten(result),
                    "خرابی پایگاه داده", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            var answer = MessageBox.Show(
                "پایگاه دادهٔ سرور (gamenet.db) خراب است؛ احتمالاً برق وسط ذخیره قطع شده.\n\n" +
                "آخرین نسخهٔ سالم: " + goodTime.ToString("yyyy/MM/dd HH:mm") + "\n(" + Path.GetFileName(good) + ")\n\n" +
                "برگردانده شود؟ تغییراتی که بعد از این زمان ثبت شده‌اند از دست می‌روند. فایل خراب پاک نمی‌شود و با نام damaged کنارش می‌ماند.",
                "تعمیر خودکار پایگاه داده", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes)
            {
                FaultJournal.Raise("HEAL-006", result + " (operator declined restore from " + Path.GetFileName(good) + ")",
                    null, "اپراتور بازگردانی را نپذیرفت.");
                return false;
            }

            try
            {
                string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
                foreach (var suffix in new[] { "", "-wal", "-shm", "-journal" })
                {
                    string f = dbPath + suffix;
                    if (File.Exists(f)) File.Move(f, dbPath + ".damaged-" + stamp + suffix);
                }
                File.Copy(good, dbPath, false);
                FaultJournal.Raise("HEAL-005", result + " -> restored " + Path.GetFileName(good) + " (" + goodTime.ToString("o") + ")");
                AuditLog.Log("DatabaseSelfRepair", "restored " + good);
                MessageBox.Show("پایگاه داده از نسخهٔ " + goodTime.ToString("yyyy/MM/dd HH:mm") + " برگردانده شد.\nفایل خراب با نام gamenet.db.damaged-" + stamp + " نگه داشته شد.",
                    "تعمیر انجام شد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            catch (Exception ex)
            {
                FaultJournal.Raise("HEAL-006", result + "; restore failed: " + ex.Message);
                MessageBox.Show("بازگردانی انجام نشد: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Once a day: a consistent copy of the healthy database (online backup API, safe
        /// while the server writes). Keeps the three newest. Runs on a background thread.
        /// </summary>
        public static void MakeDailyCopyInBackground(string dbPath)
        {
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    if (!File.Exists(dbPath)) return;
                    Directory.CreateDirectory(BackupDir());
                    string dest = Path.Combine(BackupDir(), "gamenet_selfheal_" + DateTime.Now.ToString("yyyyMMdd") + ".db");
                    if (File.Exists(dest)) return;
                    string tmp = dest + ".tmp";
                    using (var src = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;FailIfMissing=True;"))
                    using (var dst = new SQLiteConnection("Data Source=" + tmp + ";Version=3;"))
                    {
                        src.Open(); dst.Open();
                        src.BackupDatabase(dst, "main", "main", -1, null, 0);
                    }
                    SQLiteConnection.ClearAllPools();
                    if (Check(tmp) != "ok") { try { File.Delete(tmp); } catch { } return; }
                    File.Move(tmp, dest);
                    var old = Directory.GetFiles(BackupDir(), "gamenet_selfheal_*.db").OrderByDescending(f => f).Skip(3).ToList();
                    foreach (var oldFile in old) try { File.Delete(oldFile); } catch { }
                    AuditLog.Log("DatabaseSelfRepair", "daily copy " + Path.GetFileName(dest));
                }
                catch (Exception ex) { try { AuditLog.Log("DatabaseSelfRepair", "daily copy failed: " + ex.Message); } catch { } }
            });
        }

        private static string Shorten(string s) { s = s ?? ""; return s.Length > 300 ? s.Substring(0, 300) + "…" : s; }
    }
}
