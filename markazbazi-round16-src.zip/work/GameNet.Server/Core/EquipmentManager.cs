using System;
using System.Collections.Generic;
using System.Data.SQLite;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages equipment/hardware inventory for each station.
    /// </summary>
    public class EquipmentManager
    {
        public int AddEquipment(string name, string stationName = "", string category = "",
            string status = "active", string purchaseDate = "", string notes = "")
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام تجهیزات نمی‌تواند خالی باشد");

            Database.Instance.Execute(
                "INSERT INTO equipment (name, station_name, category, status, purchase_date, notes) VALUES (@n, @s, @cat, @st, @pd, @notes)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@s", stationName ?? "");
                    cmd.Parameters.AddWithValue("@cat", category ?? "");
                    cmd.Parameters.AddWithValue("@st", status ?? "active");
                    cmd.Parameters.AddWithValue("@pd", purchaseDate ?? "");
                    cmd.Parameters.AddWithValue("@notes", notes ?? "");
                });

            AuditLog.Log("EquipmentManager", $"Equipment '{name}' added");
            return (int)Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt64(0));
        }

        public EquipmentInfo FindById(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, station_name, category, status, purchase_date, notes FROM equipment WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id), MapEquipment);
        }

        public List<EquipmentInfo> GetAllEquipment(string category = "", string stationName = "")
        {
            string where = "";
            if (!string.IsNullOrWhiteSpace(category) || !string.IsNullOrWhiteSpace(stationName))
            {
                var conditions = new List<string>();
                if (!string.IsNullOrWhiteSpace(category)) conditions.Add("category = @cat");
                if (!string.IsNullOrWhiteSpace(stationName)) conditions.Add("station_name = @st");
                where = " WHERE " + string.Join(" AND ", conditions);
            }

            return Database.Instance.Query(
                $"SELECT id, name, station_name, category, status, purchase_date, notes FROM equipment{where} ORDER BY name",
                cmd =>
                {
                    if (!string.IsNullOrWhiteSpace(category)) cmd.Parameters.AddWithValue("@cat", category);
                    if (!string.IsNullOrWhiteSpace(stationName)) cmd.Parameters.AddWithValue("@st", stationName);
                },
                MapEquipment);
        }

        public PagedResult<EquipmentInfo> GetEquipmentPaged(int page, int pageSize, string search = "")
        {
            string where = "";
            Action<SQLiteCommand> param = null;
            if (!string.IsNullOrWhiteSpace(search))
            {
                where = " WHERE name LIKE @q OR category LIKE @q OR station_name LIKE @q";
                param = cmd => cmd.Parameters.AddWithValue("@q", $"%{search}%");
            }

            return Database.Instance.QueryPaged(
                $"SELECT id, name, station_name, category, status, purchase_date, notes FROM equipment{where} ORDER BY name",
                $"SELECT COUNT(*) FROM equipment{where}",
                page, pageSize, param, MapEquipment);
        }

        public void UpdateEquipment(int id, string name = null, string stationName = null,
            string category = null, string status = null, string purchaseDate = null, string notes = null)
        {
            var sets = new List<string>();
            if (name != null) sets.Add("name = @n");
            if (stationName != null) sets.Add("station_name = @s");
            if (category != null) sets.Add("category = @cat");
            if (status != null) sets.Add("status = @st");
            if (purchaseDate != null) sets.Add("purchase_date = @pd");
            if (notes != null) sets.Add("notes = @notes");
            if (sets.Count == 0) return;

            Database.Instance.Execute(
                $"UPDATE equipment SET {string.Join(", ", sets)} WHERE id = @id",
                cmd =>
                {
                    if (name != null) cmd.Parameters.AddWithValue("@n", name);
                    if (stationName != null) cmd.Parameters.AddWithValue("@s", stationName);
                    if (category != null) cmd.Parameters.AddWithValue("@cat", category);
                    if (status != null) cmd.Parameters.AddWithValue("@st", status);
                    if (purchaseDate != null) cmd.Parameters.AddWithValue("@pd", purchaseDate);
                    if (notes != null) cmd.Parameters.AddWithValue("@notes", notes);
                    cmd.Parameters.AddWithValue("@id", id);
                });
        }

        public void DeleteEquipment(int id)
        {
            Database.Instance.Execute("DELETE FROM equipment WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("EquipmentManager", $"Equipment {id} deleted");
        }

        public List<string> GetCategories()
        {
            return Database.Instance.Query(
                "SELECT DISTINCT category FROM equipment WHERE category != '' ORDER BY category",
                null, r => r.GetString(0));
        }

        private EquipmentInfo MapEquipment(System.Data.Common.DbDataReader r)
        {
            return new EquipmentInfo
            {
                Id = r.GetInt32(0), Name = r.GetString(1),
                StationName = r.IsDBNull(2) ? "" : r.GetString(2),
                Category = r.IsDBNull(3) ? "" : r.GetString(3),
                Status = r.IsDBNull(4) ? "active" : r.GetString(4),
                PurchaseDate = r.IsDBNull(5) ? "" : r.GetString(5),
                Notes = r.IsDBNull(6) ? "" : r.GetString(6)
            };
        }
    }

    public class EquipmentInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string StationName { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string PurchaseDate { get; set; }
        public string Notes { get; set; }
    }
}
