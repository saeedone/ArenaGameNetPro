using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class GameDetector
    {
        private readonly Dictionary<string, string> _knownGames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            {"csgo.exe", "Counter-Strike: Global Offensive"}, {"cs2.exe", "Counter-Strike 2"},
            {"valorant.exe", "Valorant"}, {"leagueclient.exe", "League of Legends"},
            {"fortnite.exe", "Fortnite"}, {"pubg.exe", "PUBG: Battlegrounds"},
            {"overwatch.exe", "Overwatch 2"}, {"rocketleague.exe", "Rocket League"},
            {"minecraft.exe", "Minecraft"}, {"gta5.exe", "GTA V"},
            {"dota2.exe", "Dota 2"}, {"r6s.exe", "Rainbow Six Siege"},
            {"apex_legend.exe", "Apex Legends"}, {"fifa*.exe", "EA Sports FC"},
            {"warzone.exe", "Call of Duty: Warzone"}, {"lol.launcher.exe", "League of Legends"},
            {"genshinimpact.exe", "Genshin Impact"}, {"steam.exe", "Steam"},
            {"epicgameslauncher.exe", "Epic Games Launcher"}, {"battlenet.exe", "Battle.net"},
        };

        public List<DetectedGame> DetectRunningGames()
        {
            var result = new List<DetectedGame>();
            try
            {
                var processes = Process.GetProcesses();
                foreach (var proc in processes)
                {
                    try
                    {
                        string name = proc.ProcessName + ".exe";
                        if (_knownGames.TryGetValue(name, out var gameName))
                            result.Add(new DetectedGame { ProcessName = name, GameName = gameName, ProcessId = proc.Id, MemoryUsageMb = proc.WorkingSet64 / (1024 * 1024) });
                    }
                    catch { }
                }
            }
            catch { }
            return result.GroupBy(g => g.GameName).Select(g => g.First()).ToList();
        }

        public List<GameInfo> BuildGameLibrary(string steamPath = "", string epicPath = "")
        {
            var games = new List<GameInfo>();
            int id = 1;

            if (!string.IsNullOrEmpty(steamPath) && Directory.Exists(steamPath))
            {
                var steamApps = Path.Combine(steamPath, "steamapps");
                if (Directory.Exists(steamApps))
                {
                    foreach (var acf in Directory.GetFiles(steamApps, "*.acf"))
                    {
                        try
                        {
                            var content = File.ReadAllText(acf);
                            var nameMatch = System.Text.RegularExpressions.Regex.Match(content, @"""name""\s+""(.+?)""");
                            var pathMatch = System.Text.RegularExpressions.Regex.Match(content, @"""installdir""\s+""(.+?)""");
                            if (nameMatch.Success)
                                games.Add(new GameInfo { Id = id++, Name = nameMatch.Groups[1].Value, ExecutablePath = pathMatch.Success ? Path.Combine(steamApps, "common", pathMatch.Groups[1].Value) : "", Category = "Steam" });
                        }
                        catch { }
                    }
                }
            }

            if (!string.IsNullOrEmpty(epicPath) && Directory.Exists(epicPath))
            {
                foreach (var dir in Directory.GetDirectories(epicPath))
                {
                    try
                    {
                        var manifestFiles = Directory.GetFiles(dir, "*.manifest");
                        if (manifestFiles.Length > 0)
                            games.Add(new GameInfo { Id = id++, Name = Path.GetFileName(dir), ExecutablePath = dir, Category = "Epic" });
                    }
                    catch { }
                }
            }

            return games;
        }

        public void SyncToDatabase(List<GameInfo> games)
        {
            foreach (var game in games)
            {
                try
                {
                    var existing = Database.Instance.QueryOne("SELECT id FROM games WHERE name = @n",
                        cmd => cmd.Parameters.AddWithValue("@n", game.Name), r => (int?)r.GetInt32(0));
                    if (existing == null)
                        Database.Instance.Execute("INSERT INTO games (name, executable_path, icon_path, category, is_active) VALUES (@n, @e, @i, @c, 1)",
                            cmd => { cmd.Parameters.AddWithValue("@n", game.Name); cmd.Parameters.AddWithValue("@e", game.ExecutablePath ?? ""); cmd.Parameters.AddWithValue("@i", game.IconPath ?? ""); cmd.Parameters.AddWithValue("@c", game.Category ?? ""); });
                }
                catch { }
            }
        }
    }

    public class DetectedGame { public string ProcessName; public string GameName; public int ProcessId; public long MemoryUsageMb; }
}
