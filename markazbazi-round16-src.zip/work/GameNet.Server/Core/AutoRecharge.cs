using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages auto-recharge: when a user's balance drops below a configured
    /// threshold, the system tops them up from an external wallet (stored as
    /// <c>WalletBalance</c> inside the config JSON). The threshold check and
    /// top-up are atomic per-user. The actual trigger (calling
    /// <see cref="ProcessAutoRecharges"/> on a schedule) must be wired up by
    /// the billing cycle — see the worklog note for FIX-2c.
    /// </summary>
    public class AutoRecharge
    {
        public void SetAutoRecharge(string username, decimal thresholdAmount, decimal rechargeAmount)
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (thresholdAmount <= 0) throw new ArgumentException("مبلغ آستانه باید بیشتر از صفر باشد");
            if (rechargeAmount <= 0) throw new ArgumentException("مبلغ شارژ خودکار باید بیشتر از صفر باشد");

            // Preserve any existing WalletBalance when the user re-configures.
            var existing = GetAutoRecharge(username);
            var config = new AutoRechargeConfig
            {
                ThresholdAmount = thresholdAmount,
                RechargeAmount = rechargeAmount,
                WalletBalance = existing?.WalletBalance ?? 0m,
                Enabled = true
            };
            var json = JsonConvert.SerializeObject(config);
            Database.Instance.Execute("INSERT OR REPLACE INTO user_auto_recharge (username, config_json, updated_at) VALUES (@u, @c, @t)",
                cmd => { cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@c", json); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "AutoRechargeSet", $"User: {username}, Threshold: {thresholdAmount}, Recharge: {rechargeAmount}");
        }

        public AutoRechargeConfig GetAutoRecharge(string username)
        {
            try
            {
                var json = Database.Instance.QueryOne("SELECT config_json FROM user_auto_recharge WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", username), r => r.GetString(0));
                return JsonConvert.DeserializeObject<AutoRechargeConfig>(json) ?? new AutoRechargeConfig();
            }
            catch { return new AutoRechargeConfig(); }
        }

        public void DisableAutoRecharge(string username)
        {
            // Soft-disable: keep the config but flip Enabled=false. This is
            // safer than DELETE because it preserves the WalletBalance in case
            // the user re-enables later. Falls back to DELETE if the row does
            // not exist (no-op).
            var config = GetAutoRecharge(username);
            config.Enabled = false;
            var json = JsonConvert.SerializeObject(config);
            int rows = Database.Instance.ExecuteNonQuery(
                "UPDATE user_auto_recharge SET config_json = @c, updated_at = @t WHERE username = @u",
                cmd => { cmd.Parameters.AddWithValue("@c", json); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@u", username); });
            if (rows == 0)
            {
                // No existing row — insert a disabled row so GetAutoRecharge
                // returns Enabled=false consistently.
                Database.Instance.Execute(
                    "INSERT OR REPLACE INTO user_auto_recharge (username, config_json, updated_at) VALUES (@u, @c, @t)",
                    cmd => { cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@c", json); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });
            }
        }

        /// <summary>
        /// Top up the external wallet for a user's auto-recharge. Funds added
        /// here are drawn down by <see cref="ProcessAutoRecharges"/> when the
        /// user's main balance falls below the threshold.
        /// </summary>
        public void TopUpExternalWallet(string username, decimal amount)
        {
            if (amount <= 0) throw new ArgumentException("مبلغ باید بیشتر از صفر باشد");
            var config = GetAutoRecharge(username);
            config.WalletBalance += amount;
            var json = JsonConvert.SerializeObject(config);
            Database.Instance.Execute("INSERT OR REPLACE INTO user_auto_recharge (username, config_json, updated_at) VALUES (@u, @c, @t)",
                cmd => { cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@c", json); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "AutoRechargeWalletToppedUp",
                $"User: {username}, +{amount:N0} (new wallet balance: {config.WalletBalance:N0})");
        }

        /// <summary>
        /// Scan all configured auto-recharges and apply top-ups where the
        /// user's balance is below the threshold and the external wallet has
        /// funds. Each top-up is atomic (single transaction: increment user
        /// balance, decrement wallet balance, persist config). The previous
        /// implementation used a fragile <c>LIKE '%"Enabled":true%'</c> filter
        /// that would mismatch on whitespace or key ordering; this version
        /// loads all configs and parses JSON properly.
        /// NOTE: This method must be invoked by the billing cycle (typically
        /// <c>ClientCommunicator.BillingCycle</c>) — see worklog FIX-2c.
        /// </summary>
        public void ProcessAutoRecharges()
        {
            List<(string User, string ConfigJson)> rows;
            try
            {
                // Load ALL configs — no LIKE filter. We parse JSON below.
                rows = Database.Instance.Query(
                    "SELECT username, config_json FROM user_auto_recharge",
                    null, r => (User: r.GetString(0), ConfigJson: r.GetString(1)));
            }
            catch (Exception ex)
            {
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "AutoRechargeScanFailed",
                    ex.Message, EnhancedAuditLog.AuditLevel.Error);
                return;
            }

            foreach (var row in rows)
            {
                try
                {
                    var config = JsonConvert.DeserializeObject<AutoRechargeConfig>(row.ConfigJson);
                    if (config == null || !config.Enabled) continue;

                    // Read the user's current balance.
                    var balance = Database.Instance.QueryOne("SELECT balance FROM users WHERE username = @u",
                        cmd => cmd.Parameters.AddWithValue("@u", row.User), r => r.GetDecimal(0));

                    if (balance >= config.ThresholdAmount) continue;
                    if (config.WalletBalance < config.RechargeAmount) continue;

                    // Atomic top-up: increment user balance, decrement wallet,
                    // persist updated config — all in one transaction so a
                    // concurrent ProcessAutoRecharges call cannot double-spend
                    // the wallet.
                    bool applied = false;
                    Database.Instance.ExecuteInTransaction(tx =>
                    {
                        // Re-read the config inside the txn to pick up any
                        // concurrent TopUpExternalWallet / DisableAutoRecharge.
                        var freshJson = Database.Instance.QueryOne(
                            "SELECT config_json FROM user_auto_recharge WHERE username = @u",
                            cmd => cmd.Parameters.AddWithValue("@u", row.User), r => r.GetString(0), tx);
                        var fresh = JsonConvert.DeserializeObject<AutoRechargeConfig>(freshJson);
                        if (fresh == null || !fresh.Enabled) return;
                        if (fresh.WalletBalance < fresh.RechargeAmount) return;

                        Database.Instance.ExecuteNonQuery(
                            "UPDATE users SET balance = balance + @amt WHERE username = @u",
                            cmd => { cmd.Parameters.AddWithValue("@amt", fresh.RechargeAmount); cmd.Parameters.AddWithValue("@u", row.User); }, tx);

                        fresh.WalletBalance -= fresh.RechargeAmount;
                        var updatedJson = JsonConvert.SerializeObject(fresh);
                        Database.Instance.Execute(
                            "UPDATE user_auto_recharge SET config_json = @c, updated_at = @t WHERE username = @u",
                            cmd => { cmd.Parameters.AddWithValue("@c", updatedJson); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@u", row.User); }, tx);
                        applied = true;
                    });

                    if (applied)
                        EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "AutoRechargeApplied",
                            $"User: {row.User}, Amount: {config.RechargeAmount:N0}");
                }
                catch (Exception ex)
                {
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "AutoRechargeUserFailed",
                        $"User: {row.User}, Error: {ex.Message}", EnhancedAuditLog.AuditLevel.Error);
                }
            }
        }
    }

    public class AutoRechargeConfig
    {
        public decimal ThresholdAmount = 10000m;
        public decimal RechargeAmount = 50000m;
        public decimal WalletBalance;
        public bool Enabled;
    }
}
