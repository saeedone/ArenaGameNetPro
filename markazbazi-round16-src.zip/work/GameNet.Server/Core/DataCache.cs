using System;
using System.Collections.Concurrent;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX-MONITOR-ADD5 TASK B4: tiny TTL-based in-memory cache for
    /// read-mostly DB queries. Designed for the dashboard's RefreshFast
    /// tick (every 5s) — without this cache, the income KPI query
    /// (<c>SELECT SUM(total_cost) FROM client_sessions WHERE
    /// date(start_time)=date('now')</c>) ran on every tick, locking
    /// the SQLite writer (the live ClientCommunicator that's inserting
    /// session rows) for ~10-30ms on a busy game-net.
    ///
    /// The cache is process-wide (static) and thread-safe
    /// (<see cref="ConcurrentDictionary{TKey, TValue}"/>). Entries
    /// expire after their TTL; <see cref="GetOrCompute{T}"/> recomputes
    /// the value lazily on first miss after expiry.
    ///
    /// NOT a general-purpose cache — there's no eviction policy, no size
    /// cap, no per-key invalidation. Suitable only for a handful of
    /// dashboard-style summary queries. Use Redis or a real LRU cache
    /// for anything heavier.
    /// </summary>
    public static class DataCache
    {
        private static readonly ConcurrentDictionary<string, (object Value, DateTime Expires)> _cache
            = new ConcurrentDictionary<string, (object, DateTime)>();

        /// <summary>
        /// Returns the cached value for <paramref name="key"/> if it
        /// exists and is still fresh; otherwise invokes
        /// <paramref name="compute"/> to fetch a fresh value, stores it
        /// with the given <paramref name="ttl"/>, and returns it.
        /// </summary>
        /// <typeparam name="T">Value type. Stored as <c>object</c>
        /// internally and cast back on read — caller must use the same
        /// T for the same key (no type-mixing across calls).</typeparam>
        public static T GetOrCompute<T>(string key, Func<T> compute, TimeSpan ttl)
        {
            if (_cache.TryGetValue(key, out var entry) && entry.Expires > DateTime.UtcNow)
                return (T)entry.Value;
            var value = compute();
            _cache[key] = (value, DateTime.UtcNow + ttl);
            return value;
        }

        /// <summary>Clears all cached entries. Call after a DB restore
        /// or schema migration so stale values don't survive.</summary>
        public static void Clear() { _cache.Clear(); }
    }
}
