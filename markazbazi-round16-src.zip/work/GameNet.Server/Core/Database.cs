using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.IO;
using GameNet.Shared;
// MySQL support: requires MySql.Data NuGet package (8.4.0). The package is
// installed in GameNet.Server.csproj. The MySQL plumbing below is gated by
// DatabaseProvider.MySql — when SQLite (default) is selected, no MySql.Data
// code path is exercised, so the SQLite-only existing installs are unchanged.
#if USE_MYSQL
using MySql.Data.MySqlClient;
#endif

namespace GameNet.Server.Core
{
    /// <summary>
    /// Database backend selector. SQLite is the default and is what existing
    /// installs use. MySQL is opt-in (set "DatabaseProvider":"mysql" in
    /// options.json) and runs the schema on a MySql.Data connection. Note
    /// that the SQL dialect differences (AUTOINCREMENT vs AUTO_INCREMENT,
    /// last_insert_rowid() vs LAST_INSERT_ID(), strftime vs DATE_FORMAT,
    /// ON CONFLICT upsert syntax, etc.) mean the existing Execute/Query
    /// SQL strings written for SQLite will NOT all run unchanged on MySQL;
    /// a full dialect migration is needed for production use. This minimal
    /// implementation opens the connection and exposes it for callers that
    /// want to issue MySQL-native SQL; the SQLite-typed public API
    /// (Execute/Query/QueryOne/QueryPaged) keeps working unchanged.
    /// </summary>
    public enum DatabaseProvider { SQLite, MySQL }

    /// <summary>
    /// Singleton SQLite database wrapper. Holds a single long-lived connection
    /// that is shared across all server threads. All public methods acquire an
    /// exclusive lock (_lock) so concurrent calls are serialized - this avoids
    /// "database is locked" errors and corruption. For atomic multi-statement
    /// work, use <see cref="ExecuteInTransaction"/>.
    /// </summary>
    public class Database
    {
        private static Database _instance;
        // Single static lock guards both singleton publication (Instance/Initialize/Shutdown)
        // and every connection-touching public method (Execute/Query/QueryOne/QueryPaged/Backup).
        // C# lock is reentrant on the same thread, so methods that call other locked
        // methods (e.g. QueryPaged -> Query -> lock) are safe.
        private static readonly object _lock = new object();
        private SQLiteConnection _connection;
        private const int CurrentSchemaVersion = 19;

        /// <summary>Currently-selected backend. Defaults to SQLite.</summary>
        public static DatabaseProvider Provider { get; private set; } = DatabaseProvider.SQLite;

        /// <summary>
        /// Live MySQL connection when Provider == MySQL; null otherwise. Callers
        /// that want to issue MySQL-native SQL use this directly. The SQLite-typed
        /// Execute/Query/QueryOne API still operates on the SQLite connection —
        /// both can coexist so legacy callers keep working during migration.
        /// </summary>
        public static IDbConnection MySqlConnection { get; private set; }

        /// <summary>The connection string most recently passed to Initialize.</summary>
        public static string ConnectionString { get; private set; }

        /// <summary>The on-disk path of the live database file (":memory:" for in-memory).</summary>
        public string DatabaseFilePath
        {
            get
            {
                lock (_lock)
                {
                    try { return _connection?.DataSource; }
                    catch (ObjectDisposedException) { return null; }
                }
            }
        }

        /// <summary>
        /// FIX B12: returns the SQL snippet for retrieving the last inserted
        /// row's id, picking the correct dialect for the active backend.
        /// SQLite uses <c>last_insert_rowid()</c>, MySQL uses
        /// <c>LAST_INSERT_ID()</c>. Call this right after an INSERT (within
        /// the same locked section / transaction) so the id corresponds to
        /// your INSERT and not a concurrent one.
        ///
        /// FIX AUDIT-FIX-POSTUPDATE Bug D1: when Provider == MySQL, the
        /// public Execute/Query/QueryOne API still runs on the SQLite
        /// singleton connection (see InitializeMySQL doc comment) — so the
        /// returned SQL must be SQLite-dialect even when Provider is MySQL,
        /// otherwise callers like TournamentManager.CreateTournament would
        /// issue "SELECT LAST_INSERT_ID()" against a SQLite connection and
        /// crash with "no such function: LAST_INSERT_ID". Callers that
        /// issue raw SQL against <see cref="MySqlConnection"/> directly
        /// should hard-code "SELECT LAST_INSERT_ID()" themselves. The
        /// Provider flag here is purely informational for status/UI.
        /// </summary>
        public static string GetLastInsertIdQuery()
        {
            // Always return SQLite syntax — the public Execute/Query API
            // runs against the SQLite singleton even when MySQL is selected.
            // See the Bug D1 note above.
            return "SELECT last_insert_rowid()";
        }

        public static Database Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null) throw new InvalidOperationException("Call Database.Initialize() first.");
                    return _instance;
                }
            }
        }

        /// <summary>
        /// Creates (or replaces) the singleton Database. If a previous instance exists,
        /// its connection is disposed first so the underlying file can be replaced.
        /// </summary>
        public static void Initialize(string cs)
        {
            lock (_lock)
            {
                if (_instance != null)
                {
                    try { _instance._connection?.Dispose(); }
                    catch { /* swallow - we are tearing down anyway */ }
                    _instance = null;
                }
                _instance = new Database(cs);
            }
        }

        /// <summary>
        /// Disposes the singleton connection and clears the instance. After this call,
        /// <see cref="Instance"/> will throw until <see cref="Initialize"/> is called again.
        /// Used by BackupManager.RestoreBackup before overwriting the database file.
        /// </summary>
        public static void Shutdown()
        {
            lock (_lock)
            {
                try { _instance?._connection?.Dispose(); }
                catch { /* swallow */ }
                _instance = null;
            }
        }

        /// <summary>
        /// Initializes the MySQL backend. Opens a long-lived MySql.Data connection
        /// using the supplied connection string (e.g.
        /// "Server=localhost;Database=gamenet;Uid=root;Pwd=secret;"). Also runs
        /// CreateTables-equivalent schema bootstrap on the MySQL side — see
        /// <see cref="EnsureMySqlSchema"/>. Existing callers that use the
        /// SQLite-typed Execute/Query API continue to operate on the SQLite
        /// connection (which is also opened so the singleton never throws);
        /// MySQL-aware callers can issue raw SQL via <see cref="MySqlConnection"/>.
        /// </summary>
        /// <remarks>
        /// A full MySQL migration (rewriting every Execute/Query call site's
        /// SQL to MySQL dialect: AUTO_INCREMENT, LAST_INSERT_ID(), DATE_FORMAT,
        /// INSERT ... ON DUPLICATE KEY UPDATE, etc.) is required for the
        /// MySQL backend to be production-usable. This method opens the
        /// connection and stamps the provider so callers can branch on
        /// <see cref="Provider"/>.
        /// </remarks>
        public static void InitializeMySQL(string connectionString)
        {
            // FIX B7: previously the SQLite singleton was initialized with
            // "Data Source=:memory:" — an in-memory DB that is wiped on every
            // process restart. When the operator configured DatabaseProvider=mysql
            // but the server was compiled WITHOUT USE_MYSQL, the #else branch
            // below left the singleton on the in-memory DB — every restart
            // started with an empty database (no operators, no users, no
            // pricing), which looked exactly like "the server won't open"
            // because the operator couldn't log in.
            //
            // Now the SQLite singleton is initialized with a file-backed path
            // (gamenet.db next to the exe) so data survives restarts even when
            // MySQL was requested but not compiled in.
            Initialize("Data Source=" + System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet.db"));
            lock (_lock)
            {
                // FIX B11: previously `Provider = DatabaseProvider.MySQL;`
                // was set here UNCONDITIONALLY — before the #if USE_MYSQL
                // check. When the server was compiled without USE_MYSQL, the
                // warning was logged but Provider was still set to MySQL — so
                // any code branching on `Database.Provider == MySQL` (e.g.
                // GetLastInsertIdQuery, TournamentManager, the REST API
                // status endpoint) would think MySQL was active even though
                // the connection was never opened. Now we set Provider to
                // MySQL ONLY inside the #if USE_MYSQL branch, so a build
                // without USE_MYSQL stays on SQLite (the actual active
                // backend).
                ConnectionString = connectionString;
                try
                {
#if USE_MYSQL
                    Provider = DatabaseProvider.MySQL;
                    var conn = new MySqlConnection(connectionString);
                    conn.Open();
                    MySqlConnection = conn;
                    EnsureMySqlSchema(conn);
                    AuditLog.Log("Database", "MySQL backend initialized: " + SafeConnStringForLog(connectionString));
#else
                    // USE_MYSQL compile flag not set — log a warning so the operator
                    // knows the MySQL backend is not actually wired. The SQLite
                    // singleton is still active (file-backed, see above) so the
                    // server keeps running with persistent data.
                    // FIX B7: do NOT use :memory: — see comment at the top of
                    // this method.
                    // FIX B11: do NOT set Provider = MySQL here — the actual
                    // active backend is the SQLite singleton initialized above.
                    AuditLog.Log("Database", "WARNING: MySQL requested but not compiled. Using file-backed SQLite.");
#endif
                }
                catch (Exception ex)
                {
                    AuditLog.Log("Database", "MySQL init failed: " + ex.Message + " — falling back to SQLite singleton.");
                    Provider = DatabaseProvider.SQLite;
                    MySqlConnection = null;
                }
            }
        }

#if USE_MYSQL
        /// <summary>
        /// Creates the core tables on the MySQL backend. Mirrors the SQLite
        /// CreateTables() schema but uses MySQL syntax (AUTO_INCREMENT,
        /// BIGINT, DATETIME, ENGINE=InnoDB, utf8mb4). Only creates the
        /// essential tables needed for the MySQL path to be queryable —
        /// the full 30-table schema migration is out of scope for this
        /// minimal version.
        /// </summary>
        private static void EnsureMySqlSchema(MySqlConnection conn)
        {
            var batch = new[]
            {
                "CREATE TABLE IF NOT EXISTS settings (k VARCHAR(128) PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(64) NOT NULL UNIQUE, password_hash VARCHAR(256) NOT NULL, display_name VARCHAR(128), balance DECIMAL(18,2) NOT NULL DEFAULT 0, is_active TINYINT NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, phone VARCHAR(32)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS audit_log (id INT AUTO_INCREMENT PRIMARY KEY, category VARCHAR(64) NOT NULL, action VARCHAR(128) NOT NULL, details TEXT, timestamp DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS client_sessions (id INT AUTO_INCREMENT PRIMARY KEY, session_id VARCHAR(64) NOT NULL UNIQUE, username VARCHAR(64), station_name VARCHAR(64), start_time DATETIME NOT NULL, end_time DATETIME, duration_minutes INT NOT NULL DEFAULT 0, total_cost DECIMAL(18,2) NOT NULL DEFAULT 0, current_game VARCHAR(128)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            };
            foreach (var sql in batch)
            {
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
        }
#endif

        /// <summary>
        /// Redacts the password from a MySQL connection string for logging.
        /// Returns the input string with Pwd=... replaced by Pwd=***.
        /// </summary>
        private static string SafeConnStringForLog(string cs)
        {
            if (string.IsNullOrEmpty(cs)) return "";
            try
            {
                // crude redaction — covers "Pwd=secret" and "Password=secret"
                var regex = new System.Text.RegularExpressions.Regex("(Pwd|Password)=[^;]*", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return regex.Replace(cs, "$1=***");
            }
            catch { return "(redacted)"; }
        }

        private Database(string connectionString)
        {
            // FIX B21: back up the existing DB file BEFORE running any
            // migration. A migration that fails mid-way (e.g. ALTER TABLE
            // that hits an unsupported column type) leaves the DB in a
            // half-migrated state that may not open cleanly on the next
            // launch — the operator can restore from the .premigrate.bak
            // file to recover. Best-effort: skip silently if the file is
            // missing, in-memory, or the copy fails (e.g. file locked).
            try
            {
                // Parse the SQLite connection string's Data Source to find
                // the on-disk file path. SQLiteConnectionStringBuilder is
                // in System.Data.SQLite — already imported.
                var csb = new SQLiteConnectionStringBuilder(connectionString);
                string dbPath = csb.DataSource;
                if (!string.IsNullOrEmpty(dbPath) && dbPath != ":memory:" && File.Exists(dbPath))
                {
                    string bakPath = dbPath + ".premigrate.bak";
                    try { File.Copy(dbPath, bakPath, true); }
                    catch { /* file may be locked — best-effort */ }
                }
            }
            catch { }

            try
            {
                ConnectionString = connectionString;
                _connection = new SQLiteConnection(connectionString);
                _connection.Open();
                using (var cmd = _connection.CreateCommand()) { cmd.CommandText = "PRAGMA journal_mode=WAL"; cmd.ExecuteNonQuery(); }
                using (var cmd = _connection.CreateCommand()) { cmd.CommandText = "PRAGMA foreign_keys=ON"; cmd.ExecuteNonQuery(); }
                CreateTables();
                Migrate();
            }
            catch
            {
                // Make sure we never leave a half-open connection hanging around.
                try { _connection?.Dispose(); } catch { }
                _connection = null;
                throw;
            }
        }

        /// <summary>
        /// Ensures the connection is in the Open state before use. Re-opens if it was
        /// closed externally (e.g. after a connection-level error). PRAGMAs are re-applied
        /// on reopen so WAL mode and foreign keys remain in effect.
        /// </summary>
        private void EnsureOpen()
        {
            if (_connection == null)
                throw new InvalidOperationException("Database has not been initialized. Call Database.Initialize() first.");
            if (_connection.State != System.Data.ConnectionState.Open)
            {
                _connection.Open();
                using (var cmd = _connection.CreateCommand()) { cmd.CommandText = "PRAGMA journal_mode=WAL"; cmd.ExecuteNonQuery(); }
                using (var cmd = _connection.CreateCommand()) { cmd.CommandText = "PRAGMA foreign_keys=ON"; cmd.ExecuteNonQuery(); }
            }
        }

        private void CreateTables()
        {
            ExecuteBatch(@"
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, display_name TEXT, balance NUMERIC NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, phone TEXT);
                CREATE TABLE IF NOT EXISTS food_items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price NUMERIC NOT NULL, category TEXT, is_available INTEGER NOT NULL DEFAULT 1);
                CREATE TABLE IF NOT EXISTS food_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, food_item_id INTEGER NOT NULL, quantity INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'pending', notes TEXT, created_at TEXT NOT NULL, delivered_at TEXT, FOREIGN KEY (food_item_id) REFERENCES food_items(id));
                CREATE TABLE IF NOT EXISTS reservations (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, station_name TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, notes TEXT);
                CREATE TABLE IF NOT EXISTS console_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, console_name TEXT NOT NULL, console_type TEXT, start_time TEXT NOT NULL, end_time TEXT, duration_minutes INTEGER, cost NUMERIC, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit_chain (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL, category TEXT NOT NULL, action TEXT NOT NULL, details TEXT, level TEXT NOT NULL DEFAULT 'Info', operator_name TEXT, client_ip TEXT, station_name TEXT, prev_hash TEXT NOT NULL, entry_hash TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS network_whitelist (id INTEGER PRIMARY KEY AUTOINCREMENT, allowed_mac TEXT NOT NULL, allowed_ip TEXT, is_active INTEGER NOT NULL DEFAULT 1, description TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS security_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, alert_type TEXT NOT NULL, severity TEXT NOT NULL, message TEXT NOT NULL, client_ip TEXT, operator_name TEXT, timestamp TEXT NOT NULL, is_acknowledged INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS loyalty_points (username TEXT PRIMARY KEY, points INTEGER NOT NULL DEFAULT 0, total_earned INTEGER NOT NULL DEFAULT 0, total_redeemed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS loyalty_history (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, points INTEGER NOT NULL, reason TEXT, session_cost NUMERIC, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS discount_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, discount_type TEXT NOT NULL, value NUMERIC NOT NULL, max_uses INTEGER NOT NULL DEFAULT 0, current_uses INTEGER NOT NULL DEFAULT 0, expiry TEXT, single_use_per_user INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, description TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS discount_usage (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, username TEXT NOT NULL, session_id TEXT, used_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS wait_queue (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, resource_type TEXT NOT NULL DEFAULT 'Any', position INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'waiting', notes TEXT, vip INTEGER NOT NULL DEFAULT 0, estimated_wait_min INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, called_at TEXT, served_at TEXT);
                CREATE TABLE IF NOT EXISTS wait_history (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, resource_type TEXT, queue_id INTEGER, waited_min INTEGER, status TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS client_licenses (id INTEGER PRIMARY KEY AUTOINCREMENT, station_name TEXT NOT NULL, machine_fingerprint TEXT NOT NULL, mac_address TEXT, license_token TEXT, is_approved INTEGER NOT NULL DEFAULT 0, is_revoked INTEGER NOT NULL DEFAULT 0, approved_by TEXT, approved_at TEXT, created_at TEXT NOT NULL, last_seen_at TEXT, notes TEXT);
                CREATE TABLE IF NOT EXISTS topup_requests (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, station_name TEXT, amount NUMERIC NOT NULL, payment_method TEXT DEFAULT 'cash', status TEXT NOT NULL DEFAULT 'pending', notes TEXT, requested_at TEXT NOT NULL, responded_at TEXT, response_message TEXT);
                CREATE TABLE IF NOT EXISTS client_feature_flags (key TEXT PRIMARY KEY, is_enabled INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS referral_history (id INTEGER PRIMARY KEY AUTOINCREMENT, referrer TEXT NOT NULL, referred TEXT NOT NULL, referrer_reward NUMERIC, referee_reward NUMERIC, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS client_crash_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, station_name TEXT, machine_fingerprint TEXT, client_version TEXT, exception_type TEXT, exception_message TEXT, stack_trace TEXT, last_action TEXT, crashed_at TEXT NOT NULL, received_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, action TEXT NOT NULL, details TEXT, timestamp TEXT NOT NULL);
                -- FIX LONGTERM-1: audit_log is the single highest-volume table in
                -- the whole app (AuditLog.Log is called from nearly every code
                -- path — every login, payment, sync tick, idle check, error...).
                -- It had NO index at all, so any date-filtered query (or the
                -- pruning this fix adds — see DatabaseMaintenanceScheduler)
                -- would be a full table scan; after a year of continuous
                -- operation that table scan gets slower every single day.
                CREATE INDEX IF NOT EXISTS idx_audit_log_time ON audit_log(timestamp);
                CREATE TABLE IF NOT EXISTS backup_metadata (id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, file_size INTEGER NOT NULL, backup_type TEXT NOT NULL DEFAULT 'manual', description TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS equipment (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, station_name TEXT, category TEXT, status TEXT NOT NULL DEFAULT 'active', purchase_date TEXT, notes TEXT);
                CREATE TABLE IF NOT EXISTS stations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, ip_address TEXT, mac_address TEXT, pricing_plan_id INTEGER, category TEXT, status TEXT NOT NULL DEFAULT 'available', notes TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS operators (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, salt TEXT NOT NULL, display_name TEXT, permissions INTEGER NOT NULL DEFAULT 0, role_name TEXT NOT NULL DEFAULT 'Operator', is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, last_login_at TEXT, failed_login_attempts INTEGER NOT NULL DEFAULT 0, locked_until TEXT, two_factor_secret TEXT, two_factor_enabled INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, credit_amount NUMERIC NOT NULL DEFAULT 0, duration_minutes INTEGER NOT NULL DEFAULT 0, ticket_type TEXT NOT NULL DEFAULT 'credit', is_used INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, expires_at TEXT, used_at TEXT, used_by_username TEXT, max_uses INTEGER NOT NULL DEFAULT 1, current_uses INTEGER NOT NULL DEFAULT 0, created_by_operator_id INTEGER, notes TEXT, FOREIGN KEY (created_by_operator_id) REFERENCES operators(id));
                CREATE TABLE IF NOT EXISTS client_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL UNIQUE, username TEXT, station_name TEXT, machine_name TEXT, mac_address TEXT, state INTEGER NOT NULL DEFAULT 0, start_time TEXT NOT NULL, end_time TEXT, duration_minutes INTEGER NOT NULL DEFAULT 0, total_cost NUMERIC NOT NULL DEFAULT 0, current_game TEXT, client_ip TEXT, last_heartbeat TEXT, is_connected INTEGER NOT NULL DEFAULT 1);
                CREATE TABLE IF NOT EXISTS operator_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, operator_id INTEGER NOT NULL, operator_name TEXT NOT NULL, action TEXT NOT NULL, details TEXT, station_name TEXT, timestamp TEXT NOT NULL, FOREIGN KEY (operator_id) REFERENCES operators(id));
                CREATE TABLE IF NOT EXISTS games (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, executable_path TEXT, icon_path TEXT, category TEXT, is_active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS pricing (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price_per_hour NUMERIC NOT NULL DEFAULT 15000, minimum_charge NUMERIC NOT NULL DEFAULT 2500, rounding_minutes INTEGER NOT NULL DEFAULT 10, is_default INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
                INSERT OR IGNORE INTO pricing (id, name, price_per_hour, minimum_charge, rounding_minutes, is_default, created_at) VALUES (1, 'استاندارد', 15000, 2500, 10, 1, datetime('now'));

                -- Phase 3: Chat messages
                CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_username TEXT NOT NULL, target_username TEXT, message TEXT NOT NULL, is_broadcast INTEGER NOT NULL DEFAULT 0, is_system INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_chat_sender ON chat_messages(sender_username);
                CREATE INDEX IF NOT EXISTS idx_chat_target ON chat_messages(target_username);
                CREATE INDEX IF NOT EXISTS idx_chat_created ON chat_messages(created_at);

                -- Phase 3: Announcements
                CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, level TEXT NOT NULL DEFAULT 'info', is_active INTEGER NOT NULL DEFAULT 1, created_by TEXT, created_at TEXT NOT NULL, expires_at TEXT);

                -- Phase 3: Session Packages
                CREATE TABLE IF NOT EXISTS session_packages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT, duration_minutes INTEGER NOT NULL, price NUMERIC NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, max_uses INTEGER NOT NULL DEFAULT 0, current_uses INTEGER NOT NULL DEFAULT 0, category TEXT, created_at TEXT NOT NULL);

                -- Phase 3: Member Tiers
                CREATE TABLE IF NOT EXISTS member_tiers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT, discount_percent REAL NOT NULL DEFAULT 0, required_points INTEGER NOT NULL DEFAULT 0, min_top_up NUMERIC NOT NULL DEFAULT 0, color TEXT DEFAULT '#89B4FA', icon TEXT, is_active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS user_tier_progress (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, tier_id INTEGER NOT NULL, points INTEGER NOT NULL DEFAULT 0, total_spent NUMERIC NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, FOREIGN KEY (tier_id) REFERENCES member_tiers(id));
                INSERT OR IGNORE INTO member_tiers (id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active, sort_order) VALUES (1, 'برنزی', 'عضو عادی', 0, 0, 0, '#A6E3A1', '🥉', 1, 1);
                INSERT OR IGNORE INTO member_tiers (id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active, sort_order) VALUES (2, 'نقره‌ای', 'عضو نقره‌ای با ۵٪ تخفیف', 5, 100, 500000, '#CDD6F4', '🥈', 1, 2);
                INSERT OR IGNORE INTO member_tiers (id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active, sort_order) VALUES (3, 'طلایی', 'عضو طلایی با ۱۰٪ تخفیف', 10, 500, 2000000, '#F9E2AF', '🥇', 1, 3);
                INSERT OR IGNORE INTO member_tiers (id, name, description, discount_percent, required_points, min_top_up, color, icon, is_active, sort_order) VALUES (4, 'الماسی', 'عضو الماسی با ۱۵٪ تخفیف', 15, 2000, 5000000, '#89B4FA', '💎', 1, 4);

                -- Phase 3: Debts
                CREATE TABLE IF NOT EXISTS debts (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, amount NUMERIC NOT NULL, description TEXT, is_paid INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, due_date TEXT, paid_at TEXT, notes TEXT, created_by TEXT);
                CREATE INDEX IF NOT EXISTS idx_debts_username ON debts(username);
                CREATE INDEX IF NOT EXISTS idx_debts_paid ON debts(is_paid);

                -- Phase 3: Print Jobs
                CREATE TABLE IF NOT EXISTS print_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, station_name TEXT, document_name TEXT, pages INTEGER NOT NULL DEFAULT 1, print_type TEXT NOT NULL DEFAULT 'bw', cost NUMERIC NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending', notes TEXT, created_at TEXT NOT NULL, completed_at TEXT);
                CREATE INDEX IF NOT EXISTS idx_print_username ON print_jobs(username);

                -- Phase 3: Report Snapshots
                CREATE TABLE IF NOT EXISTS report_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, report_type TEXT NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, data_json TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_report_type ON report_snapshots(report_type);

                -- Phase 4: Enhanced Audit Log
                CREATE TABLE IF NOT EXISTS enhanced_audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, action TEXT NOT NULL, details TEXT, level TEXT NOT NULL DEFAULT 'Info', operator_name TEXT, client_ip TEXT, station_name TEXT, timestamp TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_enh_audit_time ON enhanced_audit_log(timestamp);
                CREATE INDEX IF NOT EXISTS idx_enh_audit_cat ON enhanced_audit_log(category);

                -- Phase 6: Smart Pricing Rules
                CREATE TABLE IF NOT EXISTS smart_pricing_rules (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, rule_type TEXT NOT NULL, condition_json TEXT, discount_percent REAL NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, priority INTEGER NOT NULL DEFAULT 0);

                -- Phase 6: Auto Recharge
                CREATE TABLE IF NOT EXISTS user_auto_recharge (username TEXT NOT NULL PRIMARY KEY, config_json TEXT NOT NULL, updated_at TEXT NOT NULL);

                -- Phase 7: Branches
                CREATE TABLE IF NOT EXISTS branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, address TEXT, phone TEXT, manager_name TEXT, station_count INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);

                -- Phase 7: Payment Transactions
                CREATE TABLE IF NOT EXISTS payment_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, amount NUMERIC NOT NULL, authority TEXT, status TEXT NOT NULL DEFAULT 'pending', ref_id TEXT, gateway TEXT NOT NULL DEFAULT 'zarinpal', created_at TEXT NOT NULL, verified_at TEXT);
                CREATE INDEX IF NOT EXISTS idx_pay_username ON payment_transactions(username);
                CREATE INDEX IF NOT EXISTS idx_pay_status ON payment_transactions(status);
                -- M7: authority must be unique when present (prevents duplicate payment tracking)
                CREATE UNIQUE INDEX IF NOT EXISTS idx_pay_authority_unique ON payment_transactions(authority) WHERE authority IS NOT NULL;
                -- M8: composite indexes for the most common report/dashboard queries
                CREATE INDEX IF NOT EXISTS idx_pay_status_created ON payment_transactions(status, created_at);
                CREATE INDEX IF NOT EXISTS idx_sessions_user_time_state ON client_sessions(username, start_time, state);
                CREATE INDEX IF NOT EXISTS idx_food_orders_user_status ON food_orders(username, status);

                -- Phase 8: Update History
                CREATE TABLE IF NOT EXISTS update_history (id INTEGER PRIMARY KEY AUTOINCREMENT, version_from TEXT, version_to TEXT, download_path TEXT, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL);

                -- ADD-MULTI-FEATURES Feature 3: VIP membership (vip_points column on users).
                -- The ALTER TABLE for an existing users table is handled by the
                -- v17 migration step (cannot use ADD COLUMN IF NOT EXISTS in SQLite),
                -- so this is just a placeholder comment for fresh installs — the
                -- column appears via the migration below.

                -- ADD-MULTI-FEATURES Feature 4: Tournament system.
                CREATE TABLE IF NOT EXISTS tournaments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    game TEXT NOT NULL,
                    entry_fee NUMERIC NOT NULL DEFAULT 0,
                    prize NUMERIC NOT NULL DEFAULT 0,
                    max_participants INTEGER NOT NULL DEFAULT 16,
                    start_time TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'open',
                    winner_username TEXT,
                    runner_up_username TEXT,
                    created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS tournament_participants (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tournament_id INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    registered_at TEXT NOT NULL,
                    FOREIGN KEY (tournament_id) REFERENCES tournaments(id));
                CREATE INDEX IF NOT EXISTS idx_tourn_participants_tid ON tournament_participants(tournament_id);
                CREATE INDEX IF NOT EXISTS idx_tourn_participants_user ON tournament_participants(username);
            ");
        }

        /// <summary>
        /// Runs stepwise schema migrations from the current on-disk version up to
        /// <see cref="CurrentSchemaVersion"/>. On a fresh install CreateTables() has
        /// already created every object with IF NOT EXISTS, so the migration list can
        /// be empty - we just stamp the version. For upgrades from older builds, add
        /// (targetVersion, sql) tuples to the list below; each is applied only if the
        /// current version is below targetVersion.
        /// </summary>
        private void Migrate()
        {
            int current = GetSchemaVersion();
            if (current >= CurrentSchemaVersion) return;

            // Migration steps indexed by target schema version. Each step is applied
            // only when upgrading from a prior version. Add new steps here as the
            // schema evolves - they must be idempotent (use IF NOT EXISTS / OR IGNORE).
            var migrations = new List<(int Version, string Sql)>
            {
                // Example for the next schema bump:
                // (17, "ALTER TABLE users ADD COLUMN email TEXT"),
                // ADD-MULTI-FEATURES Feature 3 (v17): add vip_points column to
                // the users table. ALTER TABLE ADD COLUMN is idempotent-safe via
                // the PRAGMA-check guard below — we attempt it only if the
                // column doesn't already exist.
                (17, "-- v17 migration: add vip_points column (executed conditionally)\nSELECT 1;"),
                // ADD-MULTI-FEATURES Feature 9 (v18): add server_ip + server_port
                // columns to the branches table so the main server can query
                // the REST API of each branch's GameNet.Server instance.
                (18, "-- v18 migration: add branches.server_ip + branches.server_port\nSELECT 1;"),
                // FIX-MINOR-UPDATE FIX 4 (v19): add two_factor columns to the
                // operators table. The columns are part of the CREATE TABLE
                // for fresh installs, but legacy gamenet.db files predate
                // them. The actual ALTER TABLE runs in the v19 branch of the
                // switch below (guarded by EnsureColumnExists so re-runs are
                // safe); this list entry just bumps the schema version.
                (19, "-- v19 migration: add operators.two_factor_secret + operators.two_factor_enabled (conditional)\nSELECT 1;"),
            };

            foreach (var m in migrations)
            {
                if (m.Version <= current) continue;
                if (m.Version > CurrentSchemaVersion) break;
                // Apply migration then stamp the per-step version so partial progress
                // is visible. On failure we rethrow so the caller sees the error.
                ExecuteBatch(m.Sql);
                // ADD-MULTI-FEATURES Feature 3 (v17): conditional ALTER TABLE.
                // SQLite has no "ADD COLUMN IF NOT EXISTS" — guard with a PRAGMA
                // table_info check so a re-run after a partial migration is safe.
                if (m.Version == 17)
                {
                    try { EnsureColumnExists("users", "vip_points", "ALTER TABLE users ADD COLUMN vip_points INTEGER NOT NULL DEFAULT 0"); }
                    catch (Exception ex) { AuditLog.Log("Database", "v17 vip_points migration guard failed: " + ex.Message); }
                }
                if (m.Version == 18)
                {
                    try { EnsureColumnExists("branches", "server_ip", "ALTER TABLE branches ADD COLUMN server_ip TEXT NOT NULL DEFAULT ''"); }
                    catch (Exception ex) { AuditLog.Log("Database", "v18 branches.server_ip migration guard failed: " + ex.Message); }
                    try { EnsureColumnExists("branches", "server_port", "ALTER TABLE branches ADD COLUMN server_port INTEGER NOT NULL DEFAULT 0"); }
                    catch (Exception ex) { AuditLog.Log("Database", "v18 branches.server_port migration guard failed: " + ex.Message); }
                }
                if (m.Version == 19)
                {
                    // FIX-MINOR-UPDATE FIX 4: ensure the two_factor columns
                    // exist on the operators table for upgrades from old DBs
                    // (the columns are part of the CREATE TABLE for fresh
                    // installs, but legacy gamenet.db files predate them —
                    // operator login crashed with SqlException "no such
                    // column: two_factor_secret"). Each call is idempotent
                    // (guarded by PRAGMA table_info).
                    try { EnsureColumnExists("operators", "two_factor_secret", "ALTER TABLE operators ADD COLUMN two_factor_secret TEXT"); }
                    catch (Exception ex) { AuditLog.Log("Database", "v19 operators.two_factor_secret migration guard failed: " + ex.Message); }
                    try { EnsureColumnExists("operators", "two_factor_enabled", "ALTER TABLE operators ADD COLUMN two_factor_enabled INTEGER NOT NULL DEFAULT 0"); }
                    catch (Exception ex) { AuditLog.Log("Database", "v19 operators.two_factor_enabled migration guard failed: " + ex.Message); }
                }
                SetSchemaVersion(m.Version);
                current = m.Version;
            }

            // Stamp to current schema version. For fresh installs this is the only
            // thing Migrate does because CreateTables() already created everything.
            if (current < CurrentSchemaVersion)
            {
                SetSchemaVersion(CurrentSchemaVersion);
            }
        }

        /// <summary>
        /// Checks PRAGMA table_info(table) for a column named <paramref name="col"/>.
        /// If absent, runs <paramref name="alterSql"/> (which must be a valid
        /// ALTER TABLE ... ADD COLUMN statement for the same table). Idempotent
        /// — repeated calls find the column present and skip the ALTER.
        /// </summary>
        private void EnsureColumnExists(string table, string col, string alterSql)
        {
            lock (_lock)
            {
                EnsureOpen();
                bool exists = false;
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = $"PRAGMA table_info({table})";
                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            if (string.Equals(r.GetString(1), col, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                        }
                    }
                }
                if (!exists)
                {
                    using (var cmd = _connection.CreateCommand())
                    {
                        cmd.CommandText = alterSql;
                        cmd.ExecuteNonQuery();
                    }
                    AuditLog.Log("Database", $"Schema: added column {table}.{col}");
                }
            }
        }

        private int GetSchemaVersion()
        {
            try { return QueryOne("SELECT CAST(value AS INTEGER) FROM settings WHERE key = 'schema_version'", null, r => r.GetInt32(0)); }
            catch { return 0; }
        }

        private void SetSchemaVersion(int v)
        {
            Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', @v)",
                cmd => cmd.Parameters.AddWithValue("@v", v.ToString()));
        }

        // ==================================================================================
        // Public API: Execute
        // ==================================================================================

        /// <summary>Executes a non-query SQL statement and discards the rows-affected count.</summary>
        public void Execute(string sql, Action<SQLiteCommand> p = null) => Execute(sql, p, null);

        /// <summary>Executes a non-query SQL statement and returns the number of rows affected.</summary>
        public int ExecuteNonQuery(string sql, Action<SQLiteCommand> p = null) => ExecuteNonQuery(sql, p, null);

        /// <summary>Executes a non-query SQL statement inside an explicit transaction.</summary>
        public void Execute(string sql, Action<SQLiteCommand> p, SQLiteTransaction tx)
        {
            lock (_lock)
            {
                EnsureOpen();
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Transaction = tx;
                    p?.Invoke(cmd);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>Executes a non-query SQL statement inside an explicit transaction and returns rows affected.</summary>
        public int ExecuteNonQuery(string sql, Action<SQLiteCommand> p, SQLiteTransaction tx)
        {
            lock (_lock)
            {
                EnsureOpen();
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Transaction = tx;
                    p?.Invoke(cmd);
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        // ==================================================================================
        // Public API: QueryOne
        // ==================================================================================

        public T QueryOne<T>(string sql, Action<SQLiteCommand> p, Func<SQLiteDataReader, T> map)
            => QueryOne(sql, p, map, null);

        public T QueryOne<T>(string sql, Action<SQLiteCommand> p, Func<SQLiteDataReader, T> map, SQLiteTransaction tx)
        {
            lock (_lock)
            {
                EnsureOpen();
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Transaction = tx;
                    p?.Invoke(cmd);
                    using (var r = cmd.ExecuteReader())
                    {
                        if (r.Read()) return map(r);
                        return default(T);
                    }
                }
            }
        }

        // ==================================================================================
        // Public API: Query
        // ==================================================================================

        public List<T> Query<T>(string sql, Action<SQLiteCommand> p, Func<SQLiteDataReader, T> map)
            => Query(sql, p, map, null);

        public List<T> Query<T>(string sql, Action<SQLiteCommand> p, Func<SQLiteDataReader, T> map, SQLiteTransaction tx)
        {
            var res = new List<T>();
            lock (_lock)
            {
                EnsureOpen();
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Transaction = tx;
                    p?.Invoke(cmd);
                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read()) res.Add(map(r));
                    }
                }
            }
            return res;
        }

        // ==================================================================================
        // Public API: QueryPaged
        // ==================================================================================

        /// <summary>
        /// Executes a paged query. page is 1-based and clamped to >= 1. LIMIT/OFFSET are
        /// bound as parameters (not interpolated) to prevent SQL injection.
        /// </summary>
        public PagedResult<T> QueryPaged<T>(string dataSql, string countSql, int page, int pageSize, Action<SQLiteCommand> p, Func<SQLiteDataReader, T> map)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 1;

            lock (_lock)
            {
                EnsureOpen();
                int total = QueryOne(countSql, p, r => r.GetInt32(0));
                var items = Query($"{dataSql} LIMIT @lim OFFSET @off",
                    cmd =>
                    {
                        // Bind the caller's parameters first, then our pagination params.
                        // The caller must not use @lim / @off names.
                        p?.Invoke(cmd);
                        cmd.Parameters.AddWithValue("@lim", pageSize);
                        cmd.Parameters.AddWithValue("@off", (page - 1) * pageSize);
                    },
                    map);
                return new PagedResult<T>(items, total, page, pageSize);
            }
        }

        // ==================================================================================
        // Public API: ExecuteInTransaction
        // ==================================================================================

        /// <summary>
        /// Runs <paramref name="action"/> inside a single SQLite transaction. All Database
        /// calls made by the action must pass <paramref name="tx"/> to their overload so
        /// they participate in the transaction. Commits if the action returns normally,
        /// rolls back and rethrows if it throws. The lock is held for the whole transaction
        /// so no other thread can interleave writes.
        /// </summary>
        public T ExecuteInTransaction<T>(Func<SQLiteTransaction, T> action)
        {
            lock (_lock)
            {
                EnsureOpen();
                using (var tx = _connection.BeginTransaction())
                {
                    try
                    {
                        var result = action(tx);
                        tx.Commit();
                        return result;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { /* swallow rollback errors */ }
                        throw;
                    }
                }
            }
        }

        /// <summary>Action overload of <see cref="ExecuteInTransaction{T}(Func{SQLiteTransaction, T})"/>.</summary>
        public void ExecuteInTransaction(Action<SQLiteTransaction> action)
        {
            ExecuteInTransaction<object>(tx => { action(tx); return null; });
        }

        // ==================================================================================
        // Public API: Backup
        // ==================================================================================

        /// <summary>
        /// Creates a consistent snapshot of the live database into <paramref name="dest"/>
        /// using SQLite's BackupDatabase API. This is WAL-safe (unlike File.Copy which can
        /// produce corrupt snapshots when the WAL file has uncommitted pages). Records the
        /// backup metadata in the backup_metadata table.
        /// </summary>
        public void Backup(string dest, string desc = "")
        {
            lock (_lock)
            {
                EnsureOpen();
                var dir = Path.GetDirectoryName(dest);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                // Use the online backup API so the destination is a transactionally
                // consistent snapshot, regardless of WAL state on the source.
                using (var backupConn = new SQLiteConnection($"Data Source={dest};Version=3;"))
                {
                    backupConn.Open();
                    _connection.BackupDatabase(backupConn, "main", "main", -1, null, 0);
                }

                var fi = new FileInfo(dest);
                Execute("INSERT INTO backup_metadata (filename, file_size, backup_type, description, created_at) VALUES (@f, @s, @t, @d, @c)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@f", Path.GetFileName(dest));
                        cmd.Parameters.AddWithValue("@s", fi.Length);
                        cmd.Parameters.AddWithValue("@t", "manual");
                        cmd.Parameters.AddWithValue("@d", desc ?? "");
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                    });
            }
        }

        // ==================================================================================
        // Internal helpers
        // ==================================================================================

        /// <summary>Executes a multi-statement SQL script (CREATE TABLE batch etc.).</summary>
        private void ExecuteBatch(string sql)
        {
            lock (_lock)
            {
                EnsureOpen();
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }

    public class PagedResult<T>
    {
        public List<T> Items;
        public int TotalCount;
        public int Page;
        public int PageSize;
        public int TotalPages => PageSize > 0 ? (int)Math.Ceiling((double)TotalCount / PageSize) : 0;
        public bool HasNextPage => Page < TotalPages;
        public bool HasPreviousPage => Page > 1;
        public PagedResult(List<T> items, int totalCount, int page, int pageSize)
        {
            Items = items ?? new List<T>();
            TotalCount = totalCount;
            Page = page;
            PageSize = pageSize;
        }
    }
}
