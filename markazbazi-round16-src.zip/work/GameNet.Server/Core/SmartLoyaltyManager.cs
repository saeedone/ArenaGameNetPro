using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class SmartLoyaltySuggestion { public string Username = ""; public int Points; public string Suggestion = ""; }
    public class SmartLoyaltyManager {
        public List<SmartLoyaltySuggestion> GetSuggestions() { var list = new List<SmartLoyaltySuggestion>(); try { Database.Instance.Query("SELECT username, points, tier FROM loyalty_points ORDER BY points DESC LIMIT 20", null, r => { string u = r.GetString(0); int p = r.GetInt32(1); string sug = p >= 1000 ? "تخفیف ۲۰٪ پیشنهاد می‌شود" : p >= 500 ? "تخفیف ۱۰٪ پیشنهاد می‌شود" : "امتیاز بیشتر نیاز است"; list.Add(new SmartLoyaltySuggestion { Username = u, Points = p, Suggestion = sug }); return true; }); } catch { } return list; }
    }
}
