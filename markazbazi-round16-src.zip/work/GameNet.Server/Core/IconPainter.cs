using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Renders crisp, scalable vector toolbar icons with GDI+ so the server
    /// UI matches the reference design image (professional icon toolbar with
    /// Monitor / Members / Orders / Timers / Shortcuts / SystemLog / Market /
    /// Sync icons). All icons are drawn programmatically — no external image
    /// resources required — and rendered at 4x supersampling then downscaled
    /// for anti-aliased edges on any DPI.
    /// </summary>
    public static class IconPainter
    {
        // Catppuccin-Mocha accent palette (matches the dark glassmorphism theme
        // used by MainForm). Bright on dark toolbar background.
        public static readonly Color Blue = Color.FromArgb(137, 180, 250);
        public static readonly Color Green = Color.FromArgb(166, 227, 161);
        public static readonly Color Yellow = Color.FromArgb(249, 226, 175);
        public static readonly Color Orange = Color.FromArgb(250, 179, 135);
        public static readonly Color Purple = Color.FromArgb(203, 166, 247);
        public static readonly Color Red = Color.FromArgb(243, 139, 168);
        public static readonly Color Teal = Color.FromArgb(148, 226, 213);
        public static readonly Color Rose = Color.FromArgb(245, 194, 231);
        public static readonly Color Text = Color.FromArgb(205, 214, 244);
        public static readonly Color Surface = Color.FromArgb(49, 50, 68);
        public static readonly Color Surface2 = Color.FromArgb(69, 71, 90);

        /// <summary>
        /// Main entry: returns a Bitmap for a named icon at the requested size.
        /// Used by MainForm / ClientMonitorForm toolbars.
        /// </summary>
        public static Bitmap Get(string name, int size = 32)
        {
            // Render at 4x then downscale for smooth anti-aliased edges.
            int ss = size * 4;
            Bitmap hi = new Bitmap(ss, ss, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(hi))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.Clear(Color.Transparent);
                DrawNamed(g, name, ss);
            }
            Bitmap out_bmp = new Bitmap(size, size, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            using (Graphics g2 = Graphics.FromImage(out_bmp))
            {
                g2.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g2.SmoothingMode = SmoothingMode.AntiAlias;
                g2.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g2.DrawImage(hi, 0, 0, size, size);
            }
            hi.Dispose();
            return out_bmp;
        }

        private static void DrawNamed(Graphics g, string name, int s)
        {
            switch (name)
            {
                case "monitor": DrawMonitor(g, s, Blue, Green); break;
                case "members": DrawMembers(g, s, Blue, Teal); break;
                case "orders": DrawOrders(g, s, Yellow); break;
                case "money": DrawMoney(g, s, Yellow, Orange); break;
                case "customer": DrawCustomer(g, s, Purple, Yellow); break;
                case "chat": DrawChat(g, s, Purple); break;
                case "report": DrawReport(g, s, Blue, Green); break;
                case "security": DrawShield(g, s, Red); break;
                case "system": DrawGear(g, s, Teal); break;
                case "timers": DrawStopwatch(g, s, Red); break;
                case "shortcuts": DrawStar(g, s, Yellow); break;
                case "market": DrawGlobe(g, s, Blue); break;
                case "sync": DrawSync(g, s, Blue, Green); break;
                case "log": DrawDocument(g, s, Text); break;
                // Secondary action icons (smaller, used in ClientMonitorForm)
                case "play": DrawPlay(g, s, Green); break;
                case "stop": DrawStop(g, s, Red); break;
                case "check": DrawCheck(g, s, Green); break;
                case "forward": DrawForward(g, s, Blue); break;
                case "refresh": DrawRefresh(g, s, Blue); break;
                case "lock": DrawLock(g, s, Yellow); break;
                case "camera": DrawCamera(g, s, Orange); break;
                case "msg": DrawMessage(g, s, Purple); break;
                case "volume": DrawVolume(g, s, Teal); break;
                case "shutdown": DrawShutdown(g, s, Red); break;
                case "restart": DrawRestart(g, s, Orange); break;
                case "user": DrawUser(g, s, Blue); break;
                case "globe": DrawGlobe(g, s, Blue); break;
                case "screen": DrawScreen(g, s, Teal); break;
                case "terminal": DrawTerminal(g, s, Text); break;
                case "close": DrawClose(g, s, Red); break;
                case "target": DrawTarget(g, s, Red); break;
                case "power": DrawPower(g, s, Yellow); break;
                case "database": DrawDatabase(g, s, Green); break;
                case "key": DrawKey(g, s, Yellow); break;
                case "food": DrawFood(g, s, Orange); break;
                case "pause": DrawPause(g, s, Yellow); break;
                case "history": DrawHistory(g, s, Blue); break;
                case "leaderboard": DrawTrophy(g, s, Yellow); break;
                case "night": DrawMoon(g, s, Purple); break;
                case "settings": DrawGear(g, s, Teal); break;
                case "exit": DrawExit(g, s, Red); break;
                // Secondary toolbar icons (matching reference image row 2)
                case "undo": DrawUndo(g, s, Blue); break;
                case "redo": DrawRedo(g, s, Blue); break;
                case "smiley": DrawSmiley(g, s, Yellow); break;
                case "profile": DrawProfile(g, s, Purple); break;
                case "printer": DrawPrinter(g, s, Text); break;
                case "save": DrawSave(g, s, Blue); break;
                case "folder": DrawFolder(g, s, Yellow); break;
                case "newpage": DrawNewPage(g, s, Green); break;
                case "search": DrawSearch(g, s, Blue); break;
                case "record": DrawRecord(g, s, Red); break;
                case "help": DrawHelp(g, s, Blue); break;
                case "refresh_user": DrawRefreshUser(g, s, Blue, Green); break;
                default: DrawDocument(g, s, Text); break;
            }
        }

        // ===== Primary category icons =====

        /// <summary>Monitor with a rising graph inside (نظارت / Monitoring).</summary>
        public static void DrawMonitor(Graphics g, int s, Color frame, Color graph)
        {
            float p = s / 48f;
            using (var pen = new Pen(frame, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(40, frame)))
            using (var fillScreen = new SolidBrush(Color.FromArgb(60, 30, 40, 60)))
            {
                // Screen body
                var rect = new RectangleF(7 * p, 7 * p, 34 * p, 25 * p);
                g.FillPath(fillScreen, RoundRect(rect, 4 * p));
                g.DrawPath(pen, RoundRect(rect, 4 * p));
                // Stand
                g.FillPath(fill, new GraphicsPath());
                g.DrawLine(pen, 18 * p, 32 * p, 18 * p, 39 * p);
                g.DrawLine(pen, 30 * p, 32 * p, 30 * p, 39 * p);
                g.DrawLine(pen, 14 * p, 40 * p, 34 * p, 40 * p);
                // Graph line going up
                using (var gp = new GraphicsPath())
                {
                    gp.AddLines(new PointF[] {
                        new PointF(11*p, 27*p), new PointF(17*p, 22*p),
                        new PointF(23*p, 25*p), new PointF(29*p, 17*p),
                        new PointF(36*p, 13*p)
                    });
                    g.DrawPath(pen, gp);
                }
                // Graph dots
                using (var b = new SolidBrush(graph))
                {
                    g.FillEllipse(b, 9 * p, 25 * p, 4 * p, 4 * p);
                    g.FillEllipse(b, 35 * p, 11 * p, 4 * p, 4 * p);
                }
            }
        }

        /// <summary>Two people silhouettes (مدیریت / Members).</summary>
        public static void DrawMembers(Graphics g, int s, Color c1, Color c2)
        {
            float p = s / 48f;
            using (var b1 = new SolidBrush(c1))
            using (var b2 = new SolidBrush(c2))
            {
                // Back (smaller) person
                g.FillEllipse(b2, 24 * p, 8 * p, 11 * p, 11 * p);
                g.FillEllipse(b2, 19 * p, 19 * p, 21 * p, 16 * p);
                // Front (larger) person
                g.FillEllipse(b1, 11 * p, 11 * p, 14 * p, 14 * p);
                g.FillEllipse(b1, 5 * p, 25 * p, 26 * p, 18 * p);
            }
        }

        /// <summary>Clipboard with lines (مالی / Orders).</summary>
        public static void DrawOrders(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.5f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            using (var line = new SolidBrush(c))
            {
                var body = new RectangleF(11 * p, 8 * p, 26 * p, 32 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                // Clip at top
                var clip = new RectangleF(19 * p, 5 * p, 10 * p, 6 * p);
                g.FillPath(fill, RoundRect(clip, 2 * p));
                g.DrawPath(pen, RoundRect(clip, 2 * p));
                // Lines
                for (int i = 0; i < 4; i++)
                    g.FillRectangle(line, 15 * p, (16 + i * 5) * p, 18 * p, 2.2f * p);
            }
        }

        /// <summary>Stack of coins (مالی alternative).</summary>
        public static void DrawMoney(Graphics g, int s, Color c1, Color c2)
        {
            float p = s / 48f;
            using (var b1 = new SolidBrush(c1))
            using (var b2 = new SolidBrush(c2))
            using (var rim = new Pen(Color.FromArgb(180, c2), 1.6f * p))
            {
                // Bottom coin (ellipse) - largest
                g.FillEllipse(b2, 8 * p, 30 * p, 32 * p, 11 * p);
                g.DrawEllipse(rim, 8 * p, 30 * p, 32 * p, 11 * p);
                // Middle
                g.FillEllipse(b1, 10 * p, 21 * p, 28 * p, 10 * p);
                g.DrawEllipse(rim, 10 * p, 21 * p, 28 * p, 10 * p);
                // Top
                g.FillEllipse(b1, 12 * p, 12 * p, 24 * p, 10 * p);
                g.DrawEllipse(rim, 12 * p, 12 * p, 24 * p, 10 * p);
                // "﷼"-ish mark — use a simple currency slash
                using (var pen = new Pen(c2, 2.2f * p))
                {
                    g.DrawLine(pen, 22 * p, 16 * p, 26 * p, 16 * p);
                    g.DrawLine(pen, 24 * p, 14 * p, 24 * p, 20 * p);
                }
            }
        }

        /// <summary>Customer with star badge (مشتری / Customer loyalty).</summary>
        public static void DrawCustomer(Graphics g, int s, Color person, Color star)
        {
            float p = s / 48f;
            using (var bp = new SolidBrush(person))
            using (var bs = new SolidBrush(star))
            {
                // Person
                g.FillEllipse(bp, 13 * p, 8 * p, 14 * p, 14 * p);
                g.FillEllipse(bp, 6 * p, 21 * p, 28 * p, 19 * p);
                // Star badge bottom-right
                DrawStarShape(g, bs, 28 * p, 26 * p, 12 * p);
            }
        }

        /// <summary>Speech bubble with dots (ارتباط / Chat).</summary>
        public static void DrawChat(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            using (var dot = new SolidBrush(c))
            {
                var body = new RectangleF(7 * p, 8 * p, 34 * p, 25 * p);
                g.FillPath(fill, RoundRect(body, 6 * p));
                g.DrawPath(pen, RoundRect(body, 6 * p));
                // Tail
                var tail = new GraphicsPath();
                tail.AddLines(new PointF[] {
                    new PointF(15*p, 32*p), new PointF(13*p, 41*p),
                    new PointF(23*p, 32*p)
                });
                g.FillPath(fill, tail);
                g.DrawPath(pen, tail);
                // Dots
                g.FillEllipse(dot, 16 * p, 18 * p, 5 * p, 5 * p);
                g.FillEllipse(dot, 23 * p, 18 * p, 5 * p, 5 * p);
                g.FillEllipse(dot, 30 * p, 18 * p, 5 * p, 5 * p);
            }
        }

        /// <summary>Document with folded corner + bar chart (گزارش / Report).</summary>
        public static void DrawReport(Graphics g, int s, Color c1, Color c2)
        {
            float p = s / 48f;
            using (var pen = new Pen(c1, 2.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(45, c1)))
            using (var bar = new SolidBrush(c2))
            {
                // Page
                var path = new GraphicsPath();
                path.AddLines(new PointF[] {
                    new PointF(12*p, 6*p), new PointF(30*p, 6*p),
                    new PointF(38*p, 14*p), new PointF(38*p, 42*p),
                    new PointF(12*p, 42*p)
                });
                path.CloseFigure();
                // Folded corner
                var fold = new GraphicsPath();
                fold.AddLines(new PointF[] {
                    new PointF(30*p, 6*p), new PointF(30*p, 14*p),
                    new PointF(38*p, 14*p)
                });
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
                g.DrawPath(pen, fold);
                // Bars
                g.FillRectangle(bar, 16 * p, 28 * p, 5 * p, 10 * p);
                g.FillRectangle(bar, 23 * p, 24 * p, 5 * p, 14 * p);
                g.FillRectangle(bar, 30 * p, 20 * p, 5 * p, 18 * p);
            }
        }

        /// <summary>Shield with check (امنیت / Security).</summary>
        public static void DrawShield(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(60, c)))
            using (var check = new Pen(Color.White, 3.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                var path = new GraphicsPath();
                path.AddLines(new PointF[] {
                    new PointF(24*p, 5*p), new PointF(40*p, 11*p),
                    new PointF(40*p, 25*p), new PointF(24*p, 43*p),
                    new PointF(8*p, 25*p), new PointF(8*p, 11*p)
                });
                path.CloseFigure();
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
                // Check mark
                g.DrawLines(check, new PointF[] {
                    new PointF(16*p, 23*p), new PointF(22*p, 30*p),
                    new PointF(33*p, 16*p)
                });
            }
        }

        /// <summary>Gear / cog (سیستم / System).</summary>
        public static void DrawGear(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.2f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            {
                var path = new GraphicsPath();
                float cx = 24 * p, cy = 24 * p;
                float rOut = 18 * p, rIn = 13 * p, rHub = 6 * p;
                int teeth = 8;
                for (int i = 0; i < teeth; i++)
                {
                    double a0 = i * (2 * Math.PI / teeth);
                    double a1 = a0 + (Math.PI / teeth) * 0.45;
                    double a2 = a0 + (Math.PI / teeth) * 0.55;
                    double a3 = a0 + (Math.PI / teeth);
                    AddTooth(path, cx, cy, rOut, rIn, a0, a1, a2, a3);
                }
                path.CloseFigure();
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
                // Hub
                g.FillEllipse(Brushes.Transparent, cx - rHub, cy - rHub, rHub * 2, rHub * 2);
                g.DrawEllipse(pen, cx - rHub, cy - rHub, rHub * 2, rHub * 2);
            }
        }

        private static void AddTooth(GraphicsPath path, float cx, float cy, float rOut, float rIn, double a0, double a1, double a2, double a3)
        {
            PointF p1 = Polar(cx, cy, rIn, a0);
            PointF p2 = Polar(cx, cy, rOut, a1);
            PointF p3 = Polar(cx, cy, rOut, a2);
            PointF p4 = Polar(cx, cy, rIn, a3);
            if (path.PointCount == 0)
                path.StartFigure();
            path.AddLines(new PointF[] { p1, p2, p3, p4 });
        }

        private static PointF Polar(float cx, float cy, float r, double a)
        {
            return new PointF(cx + r * (float)Math.Cos(a), cy + r * (float)Math.Sin(a));
        }

        // ===== Reference-image specific icons =====

        /// <summary>Red stopwatch (Timers).</summary>
        public static void DrawStopwatch(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.8f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            using (var hand = new Pen(c, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                // Top button
                g.FillRectangle(fill, 21 * p, 5 * p, 6 * p, 5 * p);
                g.DrawRectangle(pen, 21 * p, 5 * p, 6 * p, 5 * p);
                // Side buttons
                g.DrawLine(pen, 12 * p, 14 * p, 16 * p, 17 * p);
                g.DrawLine(pen, 36 * p, 14 * p, 32 * p, 17 * p);
                // Body
                var body = new RectangleF(9 * p, 12 * p, 30 * p, 30 * p);
                g.FillEllipse(fill, body);
                g.DrawEllipse(pen, body);
                // Hands
                g.DrawLine(hand, 24 * p, 27 * p, 24 * p, 18 * p);
                g.DrawLine(hand, 24 * p, 27 * p, 31 * p, 30 * p);
                g.FillEllipse(new SolidBrush(c), 22.5f * p, 25.5f * p, 3 * p, 3 * p);
            }
        }

        /// <summary>5-point star (Shortcuts).</summary>
        public static void DrawStar(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var fill = new SolidBrush(c))
            using (var pen = new Pen(Color.FromArgb(180, c), 1.5f * p))
            {
                DrawStarShape(g, fill, 24 * p, 24 * p, 18 * p);
            }
        }

        private static void DrawStarShape(Graphics g, Brush fill, float cx, float cy, float r)
        {
            var path = new GraphicsPath();
            for (int i = 0; i < 10; i++)
            {
                double a = -Math.PI / 2 + i * Math.PI / 5;
                float rr = (i % 2 == 0) ? r : r * 0.42f;
                PointF pt = new PointF(cx + rr * (float)Math.Cos(a), cy + rr * (float)Math.Sin(a));
                if (i == 0) path.AddLine(pt, pt); else path.AddLine(path.GetLastPoint(), pt);
            }
            path.CloseFigure();
            g.FillPath(fill, path);
        }

        /// <summary>Blue globe with meridians (Market / Network).</summary>
        public static void DrawGlobe(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            {
                var body = new RectangleF(7 * p, 7 * p, 34 * p, 34 * p);
                g.FillEllipse(fill, body);
                g.DrawEllipse(pen, body);
                // Meridians (vertical ellipses)
                g.DrawEllipse(pen, 18 * p, 7 * p, 12 * p, 34 * p);
                g.DrawEllipse(pen, 12 * p, 7 * p, 24 * p, 34 * p);
                // Equator + parallels
                g.DrawLine(pen, 7 * p, 24 * p, 41 * p, 24 * p);
                g.DrawArc(pen, 7 * p, 14 * p, 34 * p, 20 * p, 0, 180);
                g.DrawArc(pen, 7 * p, 14 * p, 34 * p, 20 * p, 180, 180);
            }
        }

        /// <summary>Monitor with circular refresh arrows (Sync).</summary>
        public static void DrawSync(Graphics g, int s, Color frame, Color arrow)
        {
            float p = s / 48f;
            using (var pen = new Pen(frame, 2.6f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(45, frame)))
            using (var aPen = new Pen(arrow, 3.2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var aFill = new SolidBrush(arrow))
            {
                var rect = new RectangleF(7 * p, 7 * p, 34 * p, 25 * p);
                g.FillPath(fill, RoundRect(rect, 3 * p));
                g.DrawPath(pen, RoundRect(rect, 3 * p));
                g.DrawLine(pen, 18 * p, 32 * p, 30 * p, 32 * p);
                g.DrawLine(pen, 14 * p, 40 * p, 34 * p, 40 * p);
                // Circular arrow inside screen
                var arc = new RectangleF(14 * p, 11 * p, 20 * p, 16 * p);
                g.DrawArc(aPen, arc, 30, 270);
                // Arrow head
                PointF tip = new PointF(33 * p, 16 * p);
                g.FillPolygon(aFill, new PointF[] {
                    tip, new PointF(29*p, 12*p), new PointF(29*p, 20*p)
                });
            }
        }

        /// <summary>Plain document with lines (System Log).</summary>
        public static void DrawDocument(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(40, c)))
            using (var line = new Pen(c, 2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                var path = new GraphicsPath();
                path.AddLines(new PointF[] {
                    new PointF(13*p, 6*p), new PointF(31*p, 6*p),
                    new PointF(37*p, 12*p), new PointF(37*p, 42*p),
                    new PointF(13*p, 42*p)
                });
                path.CloseFigure();
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
                g.DrawLine(pen, 31 * p, 6 * p, 31 * p, 12 * p);
                g.DrawLine(pen, 31 * p, 12 * p, 37 * p, 12 * p);
                for (int i = 0; i < 4; i++)
                    g.DrawLine(line, 17 * p, (18 + i * 5) * p, 33 * p, (18 + i * 5) * p);
            }
        }

        // ===== Secondary action icons =====

        public static void DrawPlay(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
                g.FillPolygon(b, new PointF[] {
                    new PointF(17*p, 10*p), new PointF(17*p, 38*p),
                    new PointF(39*p, 24*p)
                });
        }

        public static void DrawStop(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
                g.FillRectangle(b, 12 * p, 12 * p, 24 * p, 24 * p);
        }

        public static void DrawCheck(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            using (var pen = new Pen(Color.White, 4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                g.FillEllipse(b, 6 * p, 6 * p, 36 * p, 36 * p);
                g.DrawLines(pen, new PointF[] {
                    new PointF(15*p, 24*p), new PointF(21*p, 31*p),
                    new PointF(34*p, 16*p)
                });
            }
        }

        public static void DrawForward(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            {
                g.FillPolygon(b, new PointF[] {
                    new PointF(8*p, 12*p), new PointF(8*p, 36*p),
                    new PointF(24*p, 24*p)
                });
                g.FillPolygon(b, new PointF[] {
                    new PointF(24*p, 12*p), new PointF(24*p, 36*p),
                    new PointF(40*p, 24*p)
                });
            }
        }

        public static void DrawRefresh(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                var arc = new RectangleF(8 * p, 8 * p, 32 * p, 32 * p);
                g.DrawArc(pen, arc, 45, 270);
                // Arrow heads
                g.FillPolygon(b, new PointF[] {
                    new PointF(38*p, 12*p), new PointF(33*p, 7*p), new PointF(42*p, 7*p)
                });
                g.FillPolygon(b, new PointF[] {
                    new PointF(10*p, 36*p), new PointF(15*p, 41*p), new PointF(6*p, 41*p)
                });
            }
        }

        public static void DrawLock(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p))
            using (var fill = new SolidBrush(Color.FromArgb(60, c)))
            using (var body = new SolidBrush(c))
            {
                var shackle = new RectangleF(14 * p, 6 * p, 20 * p, 18 * p);
                g.DrawArc(pen, shackle, 180, 180);
                g.DrawLine(pen, 14 * p, 15 * p, 14 * p, 22 * p);
                g.DrawLine(pen, 34 * p, 15 * p, 34 * p, 22 * p);
                var bod = new RectangleF(9 * p, 22 * p, 30 * p, 20 * p);
                g.FillPath(fill, RoundRect(bod, 3 * p));
                g.DrawPath(pen, RoundRect(bod, 3 * p));
                g.FillEllipse(body, 22 * p, 28 * p, 4 * p, 5 * p);
                g.FillRectangle(body, 23 * p, 32 * p, 2 * p, 5 * p);
            }
        }

        public static void DrawCamera(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            {
                var body = new RectangleF(6 * p, 14 * p, 36 * p, 24 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                // Viewfinder bump
                g.FillPath(fill, RoundRect(new RectangleF(18 * p, 9 * p, 12 * p, 6 * p), 2 * p));
                g.DrawPath(pen, RoundRect(new RectangleF(18 * p, 9 * p, 12 * p, 6 * p), 2 * p));
                // Lens
                g.FillEllipse(fill, 17 * p, 19 * p, 14 * p, 14 * p);
                g.DrawEllipse(pen, 17 * p, 19 * p, 14 * p, 14 * p);
                g.DrawEllipse(pen, 21 * p, 23 * p, 6 * p, 6 * p);
                // Flash dot
                g.FillEllipse(new SolidBrush(c), 36 * p, 18 * p, 3 * p, 3 * p);
            }
        }

        public static void DrawMessage(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            {
                var body = new RectangleF(6 * p, 10 * p, 36 * p, 24 * p);
                g.FillPath(fill, RoundRect(body, 5 * p));
                g.DrawPath(pen, RoundRect(body, 5 * p));
                // Tail
                g.FillPolygon(fill, new PointF[] {
                    new PointF(14*p, 33*p), new PointF(11*p, 42*p),
                    new PointF(22*p, 33*p)
                });
                g.DrawLines(pen, new PointF[] {
                    new PointF(14*p, 33*p), new PointF(11*p, 42*p),
                    new PointF(22*p, 33*p)
                });
                // 3 dots
                using (var b = new SolidBrush(c))
                {
                    g.FillEllipse(b, 14 * p, 20 * p, 5 * p, 5 * p);
                    g.FillEllipse(b, 22 * p, 20 * p, 5 * p, 5 * p);
                    g.FillEllipse(b, 30 * p, 20 * p, 5 * p, 5 * p);
                }
            }
        }

        public static void DrawVolume(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            using (var pen = new Pen(c, 2.6f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                // Speaker body
                g.FillPolygon(b, new PointF[] {
                    new PointF(8*p, 19*p), new PointF(17*p, 19*p),
                    new PointF(27*p, 9*p), new PointF(27*p, 39*p),
                    new PointF(17*p, 29*p), new PointF(8*p, 29*p)
                });
                // Waves
                g.DrawArc(pen, 28 * p, 12 * p, 12 * p, 24 * p, 300, 120);
                g.DrawArc(pen, 31 * p, 9 * p, 18 * p, 30 * p, 300, 120);
            }
        }

        public static void DrawShutdown(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3.2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                // Vertical line
                g.DrawLine(pen, 24 * p, 8 * p, 24 * p, 22 * p);
                // Arc
                g.DrawArc(pen, 12 * p, 12 * p, 24 * p, 24 * p, 40, 280);
            }
        }

        public static void DrawRestart(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3.2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                g.DrawArc(pen, 10 * p, 10 * p, 28 * p, 28 * p, 60, 280);
                g.FillPolygon(b, new PointF[] {
                    new PointF(33*p, 12*p), new PointF(28*p, 8*p), new PointF(38*p, 7*p)
                });
                g.FillPolygon(b, new PointF[] {
                    new PointF(15*p, 36*p), new PointF(20*p, 40*p), new PointF(10*p, 41*p)
                });
            }
        }

        public static void DrawUser(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            {
                g.FillEllipse(b, 16 * p, 7 * p, 16 * p, 16 * p);
                g.FillEllipse(b, 8 * p, 23 * p, 32 * p, 22 * p);
            }
        }

        public static void DrawScreen(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p))
            using (var fill = new SolidBrush(Color.FromArgb(45, c)))
            {
                var body = new RectangleF(6 * p, 8 * p, 36 * p, 26 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                g.DrawLine(pen, 18 * p, 34 * p, 30 * p, 34 * p);
                g.DrawLine(pen, 24 * p, 34 * p, 24 * p, 40 * p);
            }
        }

        public static void DrawTerminal(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            using (var arrow = new Pen(c, 2.8f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                var body = new RectangleF(6 * p, 9 * p, 36 * p, 30 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                // >_ prompt
                g.DrawLines(arrow, new PointF[] {
                    new PointF(11*p, 18*p), new PointF(16*p, 23*p), new PointF(11*p, 28*p)
                });
                g.DrawLine(arrow, 19 * p, 28 * p, 27 * p, 28 * p);
            }
        }

        public static void DrawClose(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(Color.FromArgb(50, c)))
            {
                g.FillEllipse(b, 6 * p, 6 * p, 36 * p, 36 * p);
                g.DrawLine(pen, 16 * p, 16 * p, 32 * p, 32 * p);
                g.DrawLine(pen, 32 * p, 16 * p, 16 * p, 32 * p);
            }
        }

        public static void DrawTarget(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p))
            using (var b = new SolidBrush(c))
            {
                g.DrawEllipse(pen, 6 * p, 6 * p, 36 * p, 36 * p);
                g.DrawEllipse(pen, 13 * p, 13 * p, 22 * p, 22 * p);
                g.FillEllipse(b, 20 * p, 20 * p, 8 * p, 8 * p);
            }
        }

        public static void DrawPower(Graphics g, int s, Color c) { DrawShutdown(g, s, c); }

        public static void DrawDatabase(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            {
                // Top ellipse
                g.FillEllipse(fill, 9 * p, 6 * p, 30 * p, 10 * p);
                g.DrawEllipse(pen, 9 * p, 6 * p, 30 * p, 10 * p);
                // Sides
                g.FillPath(fill, DbBody(s));
                g.DrawPath(pen, DbBody(s));
                // Mid + bottom ellipse lines
                g.DrawEllipse(pen, 9 * p, 19 * p, 30 * p, 10 * p);
                g.DrawEllipse(pen, 9 * p, 32 * p, 30 * p, 10 * p);
            }
        }

        private static GraphicsPath DbBody(int s)
        {
            float p = s / 48f;
            var path = new GraphicsPath();
            path.AddLine(9 * p, 11 * p, 9 * p, 37 * p);
            path.AddArc(new RectangleF(9 * p, 32 * p, 30 * p, 10 * p), 180, 180);
            path.AddLine(39 * p, 37 * p, 39 * p, 11 * p);
            return path;
        }

        public static void DrawKey(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                // Bow (circle)
                g.DrawEllipse(pen, 8 * p, 8 * p, 16 * p, 16 * p);
                g.FillEllipse(new SolidBrush(Color.FromArgb(80, c)), 12 * p, 12 * p, 8 * p, 8 * p);
                // Shaft
                g.DrawLine(pen, 22 * p, 22 * p, 40 * p, 40 * p);
                // Teeth
                g.DrawLine(pen, 34 * p, 34 * p, 34 * p, 40 * p);
                g.DrawLine(pen, 38 * p, 30 * p, 38 * p, 36 * p);
            }
        }

        public static void DrawFood(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            {
                // Dome (burger bun top)
                g.FillPie(fill, 6 * p, 10 * p, 36 * p, 30 * p, 180, 180);
                g.DrawArc(pen, 6 * p, 10 * p, 36 * p, 30 * p, 180, 180);
                g.DrawLine(pen, 6 * p, 25 * p, 42 * p, 25 * p);
                // Fries on top
                using (var b = new SolidBrush(c))
                {
                    g.FillRectangle(b, 16 * p, 4 * p, 2.5f * p, 10 * p);
                    g.FillRectangle(b, 22 * p, 3 * p, 2.5f * p, 11 * p);
                    g.FillRectangle(b, 28 * p, 5 * p, 2.5f * p, 9 * p);
                }
                // Bottom bun
                g.FillPie(fill, 6 * p, 22 * p, 36 * p, 22 * p, 0, 180);
                g.DrawArc(pen, 6 * p, 22 * p, 36 * p, 22 * p, 0, 180);
            }
        }

        public static void DrawPause(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            {
                g.FillRectangle(b, 14 * p, 10 * p, 7 * p, 28 * p);
                g.FillRectangle(b, 27 * p, 10 * p, 7 * p, 28 * p);
            }
        }

        public static void DrawHistory(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.8f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                // Clock face
                g.DrawEllipse(pen, 8 * p, 8 * p, 32 * p, 32 * p);
                g.DrawLine(pen, 24 * p, 24 * p, 24 * p, 14 * p);
                g.DrawLine(pen, 24 * p, 24 * p, 31 * p, 28 * p);
                // Counter-clockwise arrow
                g.DrawArc(pen, 4 * p, 4 * p, 40 * p, 40 * p, 200, 90);
                g.FillPolygon(b, new PointF[] {
                    new PointF(6*p, 32*p), new PointF(2*p, 28*p), new PointF(9*p, 27*p)
                });
            }
        }

        public static void DrawTrophy(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(60, c)))
            using (var b = new SolidBrush(c))
            {
                // Cup
                var cup = new RectangleF(15 * p, 7 * p, 18 * p, 16 * p);
                g.FillPath(fill, RoundRect(cup, 3 * p));
                g.DrawPath(pen, RoundRect(cup, 3 * p));
                // Handles
                g.DrawArc(pen, 6 * p, 9 * p, 12 * p, 12 * p, 270, 180);
                g.DrawArc(pen, 30 * p, 9 * p, 12 * p, 12 * p, 90, 180);
                // Stem
                g.FillRectangle(fill, 22 * p, 23 * p, 4 * p, 8 * p);
                g.DrawRectangle(pen, 22 * p, 23 * p, 4 * p, 8 * p);
                // Base
                g.FillPath(fill, RoundRect(new RectangleF(14 * p, 31 * p, 20 * p, 7 * p), 2 * p));
                g.DrawPath(pen, RoundRect(new RectangleF(14 * p, 31 * p, 20 * p, 7 * p), 2 * p));
                // Star
                DrawStarShape(g, b, 24 * p, 14 * p, 5 * p);
            }
        }

        public static void DrawMoon(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(c))
            {
                var path = new GraphicsPath();
                path.AddArc(new RectangleF(8 * p, 8 * p, 32 * p, 32 * p), 45, 270);
                path.AddArc(new RectangleF(16 * p, 12 * p, 24 * p, 24 * p), 225, -270);
                path.CloseFigure();
                g.FillPath(b, path);
            }
        }

        public static void DrawExit(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                // Door rectangle
                g.DrawRectangle(pen, 8 * p, 10 * p, 20 * p, 28 * p);
                // Arrow out
                g.DrawLine(pen, 20 * p, 24 * p, 40 * p, 24 * p);
                g.FillPolygon(b, new PointF[] {
                    new PointF(40*p, 24*p), new PointF(33*p, 18*p), new PointF(33*p, 30*p)
                });
            }
        }

        // ===== Secondary toolbar icons (matching reference image row 2) =====

        /// <summary>Undo: counter-clockwise curved arrow.</summary>
        public static void DrawUndo(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3.2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                g.DrawArc(pen, 12 * p, 12 * p, 28 * p, 28 * p, 90, 270);
                // Arrow head at start (top-left)
                g.FillPolygon(b, new PointF[] {
                    new PointF(12*p, 14*p), new PointF(7*p, 10*p), new PointF(17*p, 8*p)
                });
            }
        }

        /// <summary>Redo: clockwise curved arrow.</summary>
        public static void DrawRedo(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3.2f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var b = new SolidBrush(c))
            {
                g.DrawArc(pen, 8 * p, 12 * p, 28 * p, 28 * p, 270, 270);
                g.FillPolygon(b, new PointF[] {
                    new PointF(36*p, 14*p), new PointF(41*p, 10*p), new PointF(31*p, 8*p)
                });
            }
        }

        /// <summary>Smiley face.</summary>
        public static void DrawSmiley(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            using (var b = new SolidBrush(c))
            {
                g.FillEllipse(fill, 6 * p, 6 * p, 36 * p, 36 * p);
                g.DrawEllipse(pen, 6 * p, 6 * p, 36 * p, 36 * p);
                g.FillEllipse(b, 16 * p, 17 * p, 5 * p, 5 * p);
                g.FillEllipse(b, 27 * p, 17 * p, 5 * p, 5 * p);
                g.DrawArc(pen, 15 * p, 22 * p, 18 * p, 14 * p, 20, 140);
            }
        }

        /// <summary>Profile: head silhouette inside a card frame.</summary>
        public static void DrawProfile(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(45, c)))
            using (var b = new SolidBrush(c))
            {
                var card = new RectangleF(7 * p, 6 * p, 34 * p, 36 * p);
                g.FillPath(fill, RoundRect(card, 3 * p));
                g.DrawPath(pen, RoundRect(card, 3 * p));
                // Head + shoulders
                g.FillEllipse(b, 18 * p, 12 * p, 12 * p, 12 * p);
                g.FillEllipse(b, 12 * p, 22 * p, 24 * p, 16 * p);
            }
        }

        /// <summary>Printer.</summary>
        public static void DrawPrinter(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(45, c)))
            {
                // Paper input (top)
                var top = new RectangleF(13 * p, 6 * p, 22 * p, 10 * p);
                g.FillPath(fill, RoundRect(top, 2 * p));
                g.DrawPath(pen, RoundRect(top, 2 * p));
                // Printer body
                var body = new RectangleF(7 * p, 16 * p, 34 * p, 14 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                // Paper output (bottom)
                var outp = new RectangleF(13 * p, 28 * p, 22 * p, 14 * p);
                g.FillPath(fill, RoundRect(outp, 2 * p));
                g.DrawPath(pen, RoundRect(outp, 2 * p));
                // Buttons
                g.FillEllipse(new SolidBrush(c), 34 * p, 21 * p, 3 * p, 3 * p);
                g.FillEllipse(new SolidBrush(Color.FromArgb(120, Green)), 29 * p, 21 * p, 3 * p, 3 * p);
                // Lines on output paper
                using (var lp = new Pen(c, 1.6f * p))
                {
                    g.DrawLine(lp, 16 * p, 33 * p, 32 * p, 33 * p);
                    g.DrawLine(lp, 16 * p, 37 * p, 32 * p, 37 * p);
                }
            }
        }

        /// <summary>Floppy disk (save).</summary>
        public static void DrawSave(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(50, c)))
            using (var dark = new SolidBrush(Color.FromArgb(80, c)))
            {
                // Body
                var body = new RectangleF(7 * p, 7 * p, 34 * p, 34 * p);
                g.FillPath(fill, RoundRect(body, 3 * p));
                g.DrawPath(pen, RoundRect(body, 3 * p));
                // Top label area
                var label = new RectangleF(13 * p, 7 * p, 22 * p, 12 * p);
                g.FillPath(dark, RoundRect(label, 2 * p));
                g.DrawPath(pen, RoundRect(label, 2 * p));
                // Sliding metal cover (small rect)
                g.FillRectangle(dark, 20 * p, 9 * p, 8 * p, 8 * p);
                // Bottom label
                var lbl2 = new RectangleF(13 * p, 24 * p, 22 * p, 14 * p);
                g.FillPath(fill, RoundRect(lbl2, 2 * p));
                g.DrawPath(pen, RoundRect(lbl2, 2 * p));
                // Lines on bottom label
                using (var lp = new Pen(c, 1.6f * p))
                {
                    g.DrawLine(lp, 16 * p, 28 * p, 32 * p, 28 * p);
                    g.DrawLine(lp, 16 * p, 32 * p, 32 * p, 32 * p);
                    g.DrawLine(lp, 16 * p, 36 * p, 28 * p, 36 * p);
                }
            }
        }

        /// <summary>Open folder.</summary>
        public static void DrawFolder(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p))
            using (var fill = new SolidBrush(Color.FromArgb(55, c)))
            {
                // Back tab
                var tab = new RectangleF(6 * p, 9 * p, 16 * p, 7 * p);
                g.FillPath(fill, RoundRect(tab, 2 * p));
                g.DrawPath(pen, RoundRect(tab, 2 * p));
                // Folder body (open)
                var path = new GraphicsPath();
                path.AddLines(new PointF[] {
                    new PointF(6*p, 14*p), new PointF(20*p, 14*p),
                    new PointF(24*p, 18*p), new PointF(42*p, 18*p),
                    new PointF(42*p, 40*p), new PointF(6*p, 40*p)
                });
                path.CloseFigure();
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
            }
        }

        /// <summary>New page (page with folded corner + plus).</summary>
        public static void DrawNewPage(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(45, c)))
            using (var plus = new Pen(c, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                var path = new GraphicsPath();
                path.AddLines(new PointF[] {
                    new PointF(13*p, 6*p), new PointF(30*p, 6*p),
                    new PointF(38*p, 14*p), new PointF(38*p, 42*p),
                    new PointF(13*p, 42*p)
                });
                path.CloseFigure();
                g.FillPath(fill, path);
                g.DrawPath(pen, path);
                var fold = new GraphicsPath();
                fold.AddLines(new PointF[] {
                    new PointF(30*p, 6*p), new PointF(30*p, 14*p),
                    new PointF(38*p, 14*p)
                });
                g.DrawPath(pen, fold);
                // Plus sign
                g.DrawLine(plus, 20 * p, 24 * p, 32 * p, 24 * p);
                g.DrawLine(plus, 26 * p, 18 * p, 26 * p, 30 * p);
            }
        }

        /// <summary>Magnifying glass (search).</summary>
        public static void DrawSearch(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var fill = new SolidBrush(Color.FromArgb(40, c)))
            {
                g.FillEllipse(fill, 7 * p, 6 * p, 24 * p, 24 * p);
                g.DrawEllipse(pen, 7 * p, 6 * p, 24 * p, 24 * p);
                g.DrawLine(pen, 26 * p, 26 * p, 41 * p, 41 * p);
            }
        }

        /// <summary>Circle with solid dot in center (record).</summary>
        public static void DrawRecord(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 3f * p))
            using (var b = new SolidBrush(c))
            {
                g.DrawEllipse(pen, 7 * p, 7 * p, 34 * p, 34 * p);
                g.FillEllipse(b, 18 * p, 18 * p, 12 * p, 12 * p);
            }
        }

        /// <summary>Question mark in circle (help).</summary>
        public static void DrawHelp(Graphics g, int s, Color c)
        {
            float p = s / 48f;
            using (var pen = new Pen(c, 2.6f * p))
            using (var fill = new SolidBrush(Color.FromArgb(45, c)))
            using (var b = new SolidBrush(c))
            {
                g.FillEllipse(fill, 6 * p, 6 * p, 36 * p, 36 * p);
                g.DrawEllipse(pen, 6 * p, 6 * p, 36 * p, 36 * p);
                // Question mark curve
                using (var q = new Pen(c, 3.4f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                {
                    g.DrawArc(q, 17 * p, 13 * p, 14 * p, 12 * p, 0, 270);
                    g.DrawLine(q, 24 * p, 25 * p, 24 * p, 30 * p);
                }
                g.FillEllipse(b, 22.5f * p, 33 * p, 3 * p, 3 * p);
            }
        }

        /// <summary>User with circular refresh arrow.</summary>
        public static void DrawRefreshUser(Graphics g, int s, Color frame, Color arrow)
        {
            float p = s / 48f;
            using (var b = new SolidBrush(frame))
            using (var pen = new Pen(arrow, 3f * p) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var af = new SolidBrush(arrow))
            {
                // Person (smaller, offset)
                g.FillEllipse(b, 18 * p, 14 * p, 12 * p, 12 * p);
                g.FillEllipse(b, 12 * p, 24 * p, 24 * p, 16 * p);
                // Refresh arc around
                g.DrawArc(pen, 6 * p, 6 * p, 36 * p, 36 * p, 30, 280);
                // Arrow head
                g.FillPolygon(af, new PointF[] {
                    new PointF(38*p, 14*p), new PointF(33*p, 9*p), new PointF(42*p, 8*p)
                });
            }
        }

        // ===== Helpers =====

        private static GraphicsPath RoundRect(RectangleF r, float radius)
        {
            var path = new GraphicsPath();
            float d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
