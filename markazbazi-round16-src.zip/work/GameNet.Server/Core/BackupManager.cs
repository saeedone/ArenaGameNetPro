using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages database and settings backup with auto-backup scheduling support.
    /// Supports manual, scheduled, and pre-update backups.
    /// </summary>
    public class BackupManager
    {
        private readonly string _backupDirectory;
        private Timer _autoBackupTimer;

        public BackupManager(string backupDirectory = null)
        {
            _backupDirectory = backupDirectory ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups");
            if (!Directory.Exists(_backupDirectory))
                Directory.CreateDirectory(_backupDirectory);
        }

        /// <summary>Returns the backup directory path (used by SecureBackupManager).</summary>
        public string GetBackupDirectory() => _backupDirectory;

        public class BackupInfo
        {
            public int Id;
            public string Filename;
            public long FileSize;
            public string BackupType;
            public string Description;
            public DateTime CreatedAt;
        }

        /// <summary>
        /// Creates a manual backup of the database.
        /// </summary>
        public BackupInfo CreateBackup(string description = "")
        {
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string filename = $"gamenet_backup_{timestamp}.db";
            string destPath = Path.Combine(_backupDirectory, filename);

            Database.Instance.Backup(destPath, description);

            var info = Database.Instance.QueryOne(
                "SELECT id, filename, file_size, backup_type, description, created_at FROM backup_metadata WHERE filename = @f ORDER BY id DESC LIMIT 1",
                cmd => cmd.Parameters.AddWithValue("@f", filename),
                r => new BackupInfo
                {
                    Id = r.GetInt32(0),
                    Filename = r.GetString(1),
                    FileSize = r.GetInt64(2),
                    BackupType = r.GetString(3),
                    Description = r.IsDBNull(4) ? "" : r.GetString(4),
                    CreatedAt = r.GetDateTime(5)
                });

            AuditLog.Log("BackupManager", $"Backup created: {filename}");
            return info;
        }

        /// <summary>
        /// Creates a scheduled backup (called automatically).
        /// </summary>
        public BackupInfo CreateScheduledBackup()
        {
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string filename = $"gamenet_auto_{timestamp}.db";
            string destPath = Path.Combine(_backupDirectory, filename);

            Database.Instance.Backup(destPath, "پشتیبان‌گیری خودکار");

            Database.Instance.Execute(
                "UPDATE backup_metadata SET backup_type = 'scheduled' WHERE filename = @f",
                cmd => cmd.Parameters.AddWithValue("@f", filename));

            var info = Database.Instance.QueryOne(
                "SELECT id, filename, file_size, backup_type, description, created_at FROM backup_metadata WHERE filename = @f ORDER BY id DESC LIMIT 1",
                cmd => cmd.Parameters.AddWithValue("@f", filename),
                r => new BackupInfo
                {
                    Id = r.GetInt32(0),
                    Filename = r.GetString(1),
                    FileSize = r.GetInt64(2),
                    BackupType = r.GetString(3),
                    Description = r.IsDBNull(4) ? "" : r.GetString(4),
                    CreatedAt = r.GetDateTime(5)
                });

            AuditLog.Log("BackupManager", $"Scheduled backup created: {filename}");
            return info;
        }

        /// <summary>
        /// Starts automatic backup scheduling at the given interval in hours.
        /// </summary>
        public void StartAutoBackup(int intervalHours)
        {
            StopAutoBackup();
            if (intervalHours <= 0) return;

            _autoBackupTimer = new Timer(_ =>
            {
                try { CreateScheduledBackup(); }
                catch { }
            }, null, TimeSpan.FromHours(intervalHours), TimeSpan.FromHours(intervalHours));

            AuditLog.Log("BackupManager", $"Auto-backup scheduled every {intervalHours} hours");
        }

        public void StopAutoBackup()
        {
            _autoBackupTimer?.Dispose();
            _autoBackupTimer = null;
        }

        /// <summary>
        /// Restores the database from a backup file. Safely shuts down the live
        /// singleton connection, copies the backup file (and any -wal / -shm sidecars
        /// that belong to it) over the live database file, then re-initializes the
        /// singleton so subsequent queries see the restored data. Returns false (and
        /// attempts to recover) on any error instead of silently swallowing it.
        /// </summary>
        public bool RestoreBackup(string backupFilename)
        {
            string srcPath = Path.Combine(_backupDirectory, backupFilename);
            if (!File.Exists(srcPath))
            {
                AuditLog.Log("BackupManager", $"RestoreBackup failed: backup file not found: {backupFilename}");
                return false;
            }

            string connectionString;
            string dbFilePath;
            try
            {
                connectionString = Database.ConnectionString;
                dbFilePath = Database.Instance.DatabaseFilePath;
            }
            catch (Exception ex)
            {
                AuditLog.Log("BackupManager", $"RestoreBackup failed to read live DB info: {ex.Message}");
                return false;
            }

            // In-memory databases cannot be restored from a file.
            if (string.IsNullOrEmpty(dbFilePath) || dbFilePath == ":memory:")
            {
                AuditLog.Log("BackupManager", "RestoreBackup not supported for in-memory databases");
                return false;
            }

            try
            {
                // 1) Close the singleton connection so the underlying file is unlocked.
                Database.Shutdown();

                // 2) Copy the backup file and any WAL/SHM sidecars that may have been
                //    captured with it. If the backup has no sidecar files but the live
                //    DB does, remove the stale sidecars so SQLite doesn't replay them.
                File.Copy(srcPath, dbFilePath, true);

                string walSrc = srcPath + "-wal";
                string walDest = dbFilePath + "-wal";
                if (File.Exists(walSrc)) File.Copy(walSrc, walDest, true);
                else if (File.Exists(walDest)) { try { File.Delete(walDest); } catch { } }

                string shmSrc = srcPath + "-shm";
                string shmDest = dbFilePath + "-shm";
                if (File.Exists(shmSrc)) File.Copy(shmSrc, shmDest, true);
                else if (File.Exists(shmDest)) { try { File.Delete(shmDest); } catch { } }

                // 3) Re-initialize the singleton so the new file is opened and schema
                //    migrations (if any) are re-applied.
                Database.Initialize(connectionString);

                AuditLog.Log("BackupManager", $"Database restored from: {backupFilename}");
                return true;
            }
            catch (Exception ex)
            {
                AuditLog.Log("BackupManager", $"RestoreBackup failed: {ex.Message}");
                // Best-effort recovery: re-initialize the singleton so the server is
                // still usable even if the restore didn't complete.
                try { Database.Initialize(connectionString); }
                catch (Exception inner) { AuditLog.Log("BackupManager", $"Recovery re-init failed: {inner.Message}"); }
                return false;
            }
        }

        /// <summary>
        /// Gets a list of all backups, most recent first.
        /// </summary>
        public List<BackupInfo> GetBackups(int limit = 50)
        {
            return Database.Instance.Query(
                "SELECT id, filename, file_size, backup_type, description, created_at FROM backup_metadata ORDER BY created_at DESC LIMIT @lim",
                cmd => cmd.Parameters.AddWithValue("@lim", limit),
                r => new BackupInfo
                {
                    Id = r.GetInt32(0),
                    Filename = r.GetString(1),
                    FileSize = r.GetInt64(2),
                    BackupType = r.GetString(3),
                    Description = r.IsDBNull(4) ? "" : r.GetString(4),
                    CreatedAt = r.GetDateTime(5)
                });
        }

        /// <summary>
        /// Deletes an old backup file and its metadata.
        /// </summary>
        public bool DeleteBackup(int backupId)
        {
            var info = Database.Instance.QueryOne(
                "SELECT filename FROM backup_metadata WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", backupId),
                r => r.GetString(0));

            if (info == null) return false;

            string filePath = Path.Combine(_backupDirectory, info);
            if (File.Exists(filePath))
            {
                try { File.Delete(filePath); } catch { }
            }

            Database.Instance.Execute("DELETE FROM backup_metadata WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", backupId));

            AuditLog.Log("BackupManager", $"Backup deleted: {info}");
            return true;
        }

        /// <summary>
        /// Cleans up old backups, keeping only the most recent N backups.
        /// </summary>
        public int CleanupOldBackups(int keepCount = 10)
        {
            var allBackups = GetBackups(1000);
            if (allBackups.Count <= keepCount) return 0;

            int deleted = 0;
            for (int i = keepCount; i < allBackups.Count; i++)
            {
                if (DeleteBackup(allBackups[i].Id)) deleted++;
            }

            AuditLog.Log("BackupManager", $"Cleanup: {deleted} old backups removed, {keepCount} kept");
            return deleted;
        }
    }
}
