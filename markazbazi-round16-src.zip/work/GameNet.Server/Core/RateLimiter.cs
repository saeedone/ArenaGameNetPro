using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class RateLimiter
    {
        private readonly ConcurrentDictionary<string, RateLimitEntry> _entries = new ConcurrentDictionary<string, RateLimitEntry>();
        private readonly int _maxRequestsPerMinute;
        private readonly int _maxRequestsPerHour;
        private readonly int _blockDurationMinutes;
        private Timer _cleanupTimer;

        public RateLimiter(int maxPerMinute = 30, int maxPerHour = 500, int blockDuration = 15)
        {
            _maxRequestsPerMinute = maxPerMinute;
            _maxRequestsPerHour = maxPerHour;
            _blockDurationMinutes = blockDuration;
            _cleanupTimer = new Timer(Cleanup, null, TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(5));
        }

        public RateLimitResult CheckLimit(string key)
        {
            // Never bypass rate limiting - if the caller passed an empty key
            // (unauthenticated request, missing IP, etc.) bucket it under a
            // shared "anonymous" key so all such requests are throttled as a
            // group rather than allowed through unbounded.
            if (string.IsNullOrEmpty(key)) key = "anonymous";

            var entry = _entries.GetOrAdd(key, _ => new RateLimitEntry());
            lock (entry)
            {
                var now = DateTime.UtcNow;

                if (entry.BlockedUntil.HasValue && now < entry.BlockedUntil.Value)
                    return new RateLimitResult { Allowed = false, RetryAfterSeconds = (int)(entry.BlockedUntil.Value - now).TotalSeconds, Reason = "Rate limit exceeded. IP temporarily blocked." };

                if (entry.BlockedUntil.HasValue && now >= entry.BlockedUntil.Value)
                    entry.BlockedUntil = null;

                entry.Timestamps = entry.Timestamps.Where(t => now - t < TimeSpan.FromHours(1)).ToList();

                var minuteCount = entry.Timestamps.Count(t => now - t < TimeSpan.FromMinutes(1));
                if (minuteCount >= _maxRequestsPerMinute)
                {
                    entry.BlockedUntil = now.AddMinutes(_blockDurationMinutes);
                    AuditLog.Log("RateLimiter", $"Rate limit exceeded (minute) for {key}. Blocked for {_blockDurationMinutes} min.");
                    return new RateLimitResult { Allowed = false, RetryAfterSeconds = _blockDurationMinutes * 60, Reason = $"More than {_maxRequestsPerMinute} requests per minute." };
                }

                if (entry.Timestamps.Count >= _maxRequestsPerHour)
                {
                    entry.BlockedUntil = now.AddMinutes(_blockDurationMinutes);
                    AuditLog.Log("RateLimiter", $"Rate limit exceeded (hour) for {key}. Blocked for {_blockDurationMinutes} min.");
                    return new RateLimitResult { Allowed = false, RetryAfterSeconds = _blockDurationMinutes * 60, Reason = $"More than {_maxRequestsPerHour} requests per hour." };
                }

                entry.Timestamps.Add(now);
                return new RateLimitResult { Allowed = true, RemainingMinute = _maxRequestsPerMinute - minuteCount, RemainingHour = _maxRequestsPerHour - entry.Timestamps.Count };
            }
        }

        public void Block(string key, int minutes = 60)
        {
            var entry = _entries.GetOrAdd(key, _ => new RateLimitEntry());
            lock (entry) { entry.BlockedUntil = DateTime.UtcNow.AddMinutes(minutes); }
        }

        public void Unblock(string key) { _entries.TryRemove(key, out _); }

        public List<BlockedEntry> GetBlockedEntries()
        {
            var now = DateTime.UtcNow;
            var result = new List<BlockedEntry>();
            foreach (var kvp in _entries)
            {
                lock (kvp.Value)
                {
                    if (kvp.Value.BlockedUntil.HasValue && now < kvp.Value.BlockedUntil.Value)
                        result.Add(new BlockedEntry { Key = kvp.Key, BlockedUntil = kvp.Value.BlockedUntil.Value });
                }
            }
            return result;
        }

        private void Cleanup(object state)
        {
            var now = DateTime.UtcNow;
            foreach (var kvp in _entries.ToList())
            {
                lock (kvp.Value)
                {
                    kvp.Value.Timestamps = kvp.Value.Timestamps.Where(t => now - t < TimeSpan.FromHours(1)).ToList();
                    if (kvp.Value.Timestamps.Count == 0 && (!kvp.Value.BlockedUntil.HasValue || now >= kvp.Value.BlockedUntil.Value))
                        _entries.TryRemove(kvp.Key, out _);
                }
            }
        }

        private class RateLimitEntry { public List<DateTime> Timestamps = new List<DateTime>(); public DateTime? BlockedUntil; }
    }

    public class RateLimitResult { public bool Allowed; public int RetryAfterSeconds; public string Reason; public int RemainingMinute; public int RemainingHour; }
    public class BlockedEntry { public string Key; public DateTime BlockedUntil; }
}
