using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;

namespace GameNet.Server.Core
{
    public class ClientCommunicator : IDisposable
    {
        private TcpListener _listener;
        private Thread _listenerThread;
        private volatile bool _running;
        private readonly int _port;
        private readonly ConcurrentDictionary<string, ClientConnection> _connections = new ConcurrentDictionary<string, ClientConnection>();
        private Timer _heartbeatCheckTimer;
        private Timer _billingTimer;
        private RateLimiter _rateLimiter;
        // Settings push: the settings a station receives at ServerWelcome are sent again
        // to every welcomed station when they change (checked every 30 seconds).
        private Timer _configPushTimer;
        private string _lastConfigSignature;
        private readonly object _configPushLock = new object();
        private readonly TlsWrapper _tlsWrapper;
        private readonly string _certPath;
        private readonly string _certPassword;

        // Per-account 2FA failure lockout: username -> failure info
        private readonly ConcurrentDictionary<string, TwoFactorLockoutInfo> _2faLockouts = new ConcurrentDictionary<string, TwoFactorLockoutInfo>();

        /// <summary>
        /// Fix 1 - TLS is ON by default. Every client connection must complete a
        /// TLS handshake. A plaintext connection is refused, and a failed handshake
        /// is dropped (never downgraded to plaintext). If the certificate cannot be
        /// loaded while this is on, all connections are refused (fail closed).
        /// Set to false only for plaintext debugging, or on an installation whose
        /// kiosks have not yet been switched to TLS.
        /// </summary>
        public bool UseTls { get; set; } = true;

        // NOTE: These events are raised from ThreadPool worker threads, Timer
        // threads (BillingCycle / CheckHeartbeats) and the listener thread —
        // NEVER the WinForms UI thread. WinForms subscribers MUST marshal back
        // to the UI thread via Control.Invoke/BeginInvoke before touching any
        // UI element. Handler exceptions are caught and logged so one bad
        // subscriber cannot crash the network thread (see SafeInvoke).
        public event Action<ConnectedClient> OnClientConnected;
        public event Action<string> OnClientDisconnected;
        public event Action<string, NetMessage> OnMessageReceived;
        public event Action<string, ClientSession> OnSessionStarted;
        public event Action<string, ClientSession> OnSessionEnded;
        /// <summary>Raised when a screenshot response arrives. Args: stationName, payload.</summary>
        public event Action<string, ScreenshotResponsePayload> OnScreenshotReceived;
#pragma warning disable CS0067
        public event Action<string, ServerTimeWarningPayload> OnTimeWarning;
        // Round 11: a customer wrote to the operator (station, username, text).
        public event Action<string, string, string> OnCustomerMessage;
        // Round 11: a customer pressed a request button on the kiosk
        // (station, username, kind = "time" | "end" | "lock" | "shutdown", minutes).
        public event Action<string, string, string, int> OnCustomerRequest;
#pragma warning restore CS0067

        public int ConnectedClientCount => _connections.Count;

        // ---- Round 15: read-only facts for the "🩺 عیب‌یابی اتصال" tab ----
        public int Port => _port;
        public bool CertificateLoaded => _tlsWrapper != null && _tlsWrapper.IsEnabled;
        /// <summary>Where the certificate file is looked for (relative paths follow the working folder).</summary>
        public string CertificateFullPath
        {
            get { try { return string.IsNullOrEmpty(_certPath) ? "" : Path.GetFullPath(_certPath); } catch { return _certPath ?? ""; } }
        }
        public int WelcomedCount { get { int n = 0; foreach (var kv in _connections) if (kv.Value.ClientInfo != null) n++; return n; } }
        public List<BlockedEntry> RateLimitedNow()
        {
            try { return _rateLimiter?.GetBlockedEntries() ?? new List<BlockedEntry>(); }
            catch { return new List<BlockedEntry>(); }
        }
        public IEnumerable<ConnectedClient> ConnectedClients
        {
            get
            {
                foreach (var kvp in _connections)
                    if (kvp.Value.ClientInfo != null) yield return kvp.Value.ClientInfo;
            }
        }

        /// <summary>
        /// Returns a snapshot of ALL raw connections, including those that
        /// have not yet sent ClientHello (ClientInfo == null). Used by the
        /// client-monitor UI so the operator can see every TCP socket — even
        /// clients that connected but haven't completed the handshake yet.
        /// </summary>
        public List<(string SessionId, string ClientIp, string StationName, ClientState State, string User, string Game, int Minutes, decimal Cost, double Cpu, double Ram, long Disk, DateTime LastHeartbeat, string ActiveWindow, string OsVersion, bool PlayAndPay, DateTime ConnectedAt, DateTime SessionStart, string MacAddress, string ClientVersion, int TimeCapMinutes)> GetAllRawConnections()
        {
            // FIX H2/M2/L14: tuple extended with SessionStart (H2), MacAddress
            // (M2), ClientVersion (M2), and TimeCapMinutes (L14). New fields
            // appended at the END so existing named-tuple callers keep
            // compiling (positional deconstruction would break, but every
            // caller in this codebase uses member access like c.StationName).
            var list = new List<(string, string, string, ClientState, string, string, int, decimal, double, double, long, DateTime, string, string, bool, DateTime, DateTime, string, string, int)>();
            foreach (var kvp in _connections)
            {
                var c = kvp.Value;
                var info = c.ClientInfo;
                list.Add((
                    kvp.Key,
                    info?.ClientIp ?? ((c.TcpClient?.Client?.RemoteEndPoint is System.Net.IPEndPoint ep) ? ep.Address.ToString() : "?"),
                    info?.StationName ?? "(در حال اتصال...)",
                    info?.State ?? ClientState.Disconnected,
                    info?.CurrentUser ?? "",
                    info?.CurrentGame ?? "",
                    info?.SessionMinutesElapsed ?? 0,
                    info?.SessionCost ?? 0,
                    info?.CpuUsage ?? 0,
                    info?.MemoryUsage ?? 0,
                    0,
                    c.LastHeartbeat,
                    info?.ActiveWindowTitle ?? "",
                    info?.OsVersion ?? "",
                    info?.PlayAndPay ?? false,
                    info?.ConnectedAt ?? c.LastHeartbeat,
                    // FIX H2: prefer the actual login time, fall back to the
                    // connect time, then to LastHeartbeat (so a freshly-
                    // connected client shows ~now instead of DateTime.MinValue).
                    // Round 5 (FIX MONITOR-NRE, ported from the other source line):
                    // info is null for a connection that has not completed the hello
                    // (including a station whose ClientReconnect was rejected).
                    // `info?.SessionStart != default(DateTime)` is then null != MinValue,
                    // which is true, so `info.SessionStart` threw NullReferenceException
                    // and every caller (client monitor, live dashboard, REST API) got
                    // no list at all while such a connection was open. Both branches
                    // check info first now.
                    info != null && info.SessionStart != default(DateTime) ? info.SessionStart
                        : (info != null && info.ConnectedAt != default(DateTime) ? info.ConnectedAt : c.LastHeartbeat),
                    // FIX M2: surface the real MAC and version (was hardcoded
                    // "8.1" + the IP-as-MAC fallback before).
                    info?.MacAddress ?? "",
                    info?.ClientVersion ?? "",
                    // FIX L14: per-station time cap from SetSessionTime.
                    info?.TimeCapMinutes ?? 0
                ));
            }
            return list;
        }

        public ClientCommunicator(int port = Protocol.DefaultPort)
            : this(port, "server.pfx", "")
        {
        }

        public ClientCommunicator(int port, string certPath, string certPassword = "")
        {
            _port = port;
            _rateLimiter = new RateLimiter();

            // Phase 1.1: TLS certificate. TlsWrapper auto-generates a
            // self-signed server.pfx on first run if the file is missing,
            // so TLS is always active without manual setup.
            try
            {
                _certPath = certPath ?? "server.pfx";
                _certPassword = certPassword ?? "";
                _tlsWrapper = new TlsWrapper(_certPath, _certPassword);
                if (!_tlsWrapper.IsEnabled)
                {
                    AuditLog.Log("Network", "WARNING: TLS cert not loaded. With UseTls on, every client connection will be refused.");
                    FaultJournal.Raise("TLS-001", "certificate not loaded: " + _certPath);
                }
                else
                    AuditLog.Log("Network", "TLS enabled with certificate: " + _certPath);
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "Failed to initialise TLS wrapper: " + ex.Message + " — using plaintext");
                _certPath = certPath ?? "server.pfx";
                _certPassword = certPassword ?? "";
                // Self-repair (TLS-001): the TLS wrapper could not be created at all.
                FaultJournal.Raise("TLS-001", "TLS wrapper could not be created: " + ex.Message);
            }
        }

        public void Start()
        {
            if (_running) return;
            _running = true;
            // Self-repair (FMEA SRV-001 / SRV-003 / SRV-900): the listener is supervised.
            // Start() does not throw when the port is busy: SupervisorLoop retries with
            // backoff until the port is free, and records the cause.
            _listenerThread = new Thread(SupervisorLoop) { IsBackground = true, Name = "GameNet-Listener" };
            _listenerThread.Start();
            _heartbeatCheckTimer = new Timer(CheckHeartbeats, null, TimeSpan.FromSeconds(15), TimeSpan.FromSeconds(15));
            // FIX M14: shorten the billing cycle from 60s to 30s so a user
            // whose balance dips below the per-cycle cost is disconnected
            // within ~30s instead of ~60s. The previous 60s cadence let a
            // user play up to a full extra minute after their balance was
            // technically depleted (the `bal <= cost` check only ran once
            // per cycle). The BillingCycle handler already gates on
            // `bal <= cost` (cost = effectivePph/60 * elapsed), so halving
            // the interval halves the worst-case over-play window.
            _billingTimer = new Timer(BillingCycle, null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));
            StartConfigPushTimer();
        }

        public void Stop()
        {
            if (!_running) return;
            _running = false;
            // Full fence: pairs with the fence in SupervisorLoop after _listener is stored, so that
            // either this method sees the new listener and closes it, or the supervisor sees _running == false.
            Thread.MemoryBarrier();
            _heartbeatCheckTimer?.Dispose();
            _billingTimer?.Dispose();
            _configPushTimer?.Dispose();
            // FIX C1: Finalize all active sessions BEFORE disposing connections.
            // Otherwise the server-close path orphans every in-flight session
            // (state=InSession, end_time=NULL, balance never deducted).
            foreach (var kvp in _connections)
            {
                try
                {
                    if (!string.IsNullOrEmpty(kvp.Value.CurrentSessionId))
                        EndSession(kvp.Value, "Server shutdown");
                }
                catch (Exception ex) { AuditLog.Log("Network", "Error finalizing session in Stop: " + ex.Message); }
            }
            foreach (var kvp in _connections)
            {
                try { lock (kvp.Value.SendLock) kvp.Value.Dispose(); }
                catch (Exception ex) { AuditLog.Log("Network", "Error disposing conn in Stop: " + ex.Message); }
            }
            _connections.Clear();
            _listener?.Stop();
            _listenerThread?.Join(3000);
        }

        /// <summary>
        /// Self-repair supervisor for the listening socket (FMEA SRV-001, SRV-003, SRV-900;
        /// rules R1 and R2). It binds the port and accepts connections, and recovers by itself:
        ///   - a busy port (SRV-003) is retried with backoff until the port is free;
        ///   - an accept error (SRV-001) is retried with backoff; after 3 errors in a row the
        ///     socket is rebuilt from scratch;
        ///   - when the listener works again after a failure, SRV-900 is recorded.
        /// Nothing here changes which clients are accepted or refused.
        /// </summary>
        private void SupervisorLoop()
        {
            int bindFailures = 0;
            int acceptFailures = 0;
            bool recovering = false;
            bool announced = false;
            while (_running)
            {
                TcpListener listener = _listener;
                if (listener == null)
                {
                    try
                    {
                        listener = new TcpListener(IPAddress.Any, _port);
                        listener.Start();
                        _listener = listener;
                        // Full fence (see Stop): if Stop() has already cleared _running, leave the loop;
                        // the cleanup after the loop closes this listener.
                        Thread.MemoryBarrier();
                        if (!_running) break;
                    }
                    catch (Exception ex)
                    {
                        if (!_running) break;
                        bindFailures++;
                        recovering = true;
                        bool busy = ex is SocketException se && se.SocketErrorCode == SocketError.AddressAlreadyInUse;
                        FaultJournal.Raise(busy ? "SRV-003" : "SRV-001",
                            "bind port " + _port + " failed (attempt " + bindFailures + "): " + ex.Message, "bind");
                        Pause(bindFailures);
                        continue;
                    }
                    bindFailures = 0;
                    acceptFailures = 0;
                    if (recovering)
                    {
                        FaultJournal.Raise("SRV-900", "port " + _port + " is listening again after a failure");
                        recovering = false;
                    }
                    if (!announced)
                    {
                        announced = true;
                        bool tlsOn = UseTls && _tlsWrapper != null && _tlsWrapper.IsEnabled;
                        AuditLog.Log("ClientCommunicator", $"TCP listener started on port {_port} (TLS={(tlsOn ? "on" : "off")})");
                    }
                }

                try
                {
                    var tcp = listener.AcceptTcpClient();
                    acceptFailures = 0;
                    if (recovering)
                    {
                        FaultJournal.Raise("SRV-900", "port " + _port + " is accepting connections again");
                        recovering = false;
                    }
                    var conn = new ClientConnection(tcp);
                    // NOTE: do NOT add to _connections here — wait until
                    // HandleClient has set up conn.Stream (incl. TLS wrap) so
                    // SendToClient never sees a connection with a null stream.
                    // Round 16: one dedicated thread per station. HandleClient blocks on
                    // reads for the station's whole life; on the shared thread pool 20-30
                    // stations held most pool threads, and the timers (heartbeat check,
                    // billing, settings push) and new connections waited for the pool to
                    // grow (about 2 threads a second) — after a server restart the kiosks'
                    // hellos were answered late or after their 30-second welcome watchdog.
                    var t = new Thread(() => HandleClient(conn)) { IsBackground = true, Name = "GameNet-Client" };
                    t.Start();
                }
                catch (Exception ex)
                {
                    if (!_running) break;
                    acceptFailures++;
                    recovering = true;
                    AuditLog.Log("Network", "Error in AcceptLoop: " + ex.Message);
                    FaultJournal.Raise("SRV-001", "accept failed (" + acceptFailures + " in a row): " + ex.Message, "accept");
                    int step = acceptFailures;
                    if (acceptFailures >= 3)
                    {
                        // Rebuild the socket: close this listener and bind the port again.
                        try { listener.Stop(); } catch { }
                        _listener = null;
                        acceptFailures = 0;
                    }
                    Pause(step);
                }
            }

            // The loop has ended (Stop, or a stop seen after a bind). Close the socket that is still
            // open, so a bind that finished after Stop() had read _listener cannot keep the port.
            try { _listener?.Stop(); } catch { }
            _listener = null;
        }

        /// <summary>Waits before a retry: exponential backoff with jitter (rule R1). Returns early when stopping.</summary>
        private void Pause(int step)
        {
            TimeSpan wait = RecoveryPolicy.WithJitter(
                RecoveryPolicy.Backoff(step, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30)), 0.2);
            DateTime until = DateTime.UtcNow + wait;
            while (_running && DateTime.UtcNow < until) Thread.Sleep(200);
        }

        /// <summary>Remote IP of a connection, or "" when it is not known.</summary>
        private static string ClientIpOf(ClientConnection conn)
        {
            try { return ((IPEndPoint)conn.TcpClient.Client.RemoteEndPoint)?.Address?.ToString() ?? ""; }
            catch { return ""; }
        }

        /// <summary>
        /// FMEA NET-010: a plaintext server reads the first four bytes of a TLS ClientHello
        /// as a message length, which shows up as 0x16xxxxxx ("Invalid message length: 369...").
        /// </summary>
        private static bool LooksLikeTlsHello(Exception ex)
        {
            const string prefix = "Invalid message length: ";
            string m = ex?.Message ?? "";
            if (!m.StartsWith(prefix, StringComparison.Ordinal)) return false;
            long len;
            if (!long.TryParse(m.Substring(prefix.Length), out len)) return false;
            return len >= 0x16000000L && len <= 0x16FFFFFFL;
        }

        private void HandleClient(ClientConnection conn)
        {
            try
            {
                Stream baseStream = conn.TcpClient.GetStream();
                Stream stream = baseStream;
                // Fix 1: when UseTls is on there is NO plaintext fallback. A client that
                // cannot complete the handshake is dropped, so an attacker cannot force
                // a downgrade by breaking the handshake.
                if (UseTls)
                {
                    if (_tlsWrapper == null || !_tlsWrapper.IsEnabled)
                    {
                        AuditLog.Log("Network", "Connection refused: TLS is required but no certificate is loaded.");
                        try { conn.TcpClient.Close(); } catch { }
                        return;
                    }
                    // Round 16: a station that connects and then stalls (crashed, cable pulled
                    // mid-handshake) no longer holds its thread forever: 15 s for the handshake.
                    try { conn.TcpClient.ReceiveTimeout = 15000; conn.TcpClient.SendTimeout = 15000; } catch { }
                    try { stream = _tlsWrapper.WrapServerStream((NetworkStream)baseStream); }
                    catch (Exception ex)
                    {
                        AuditLog.Log("Network", "Connection refused: TLS handshake failed: " + ex.Message);
                        FaultJournal.Raise("NET-011", "TLS handshake from " + ClientIpOf(conn) + " failed: " + ex.Message, ClientIpOf(conn));
                        try { conn.TcpClient.Close(); } catch { }
                        return;
                    }
                }
                try { conn.TcpClient.ReceiveTimeout = 0; conn.TcpClient.SendTimeout = 30000; } catch { } // round 16: reads wait; heartbeat check cleans up
                conn.Stream = stream;
                // Now that the stream is ready, publish the connection so
                // SendToClient / ConnectedClients can see it.
                _connections[conn.SessionId] = conn;

                while (_running && conn.TcpClient.Connected)
                {
                    try
                    {
                        var msg = Protocol.ReadMessage(stream);
                        ProcessMessage(conn, msg);
                    }
                    catch (IOException ex)
                    {
                        AuditLog.Log("Network", "IO error reading from client: " + ex.Message);
                        // Self-repair (NET-010): a TLS hello that reached a server with TLS off.
                        if (!UseTls && LooksLikeTlsHello(ex))
                            FaultJournal.Raise("NET-010", "a TLS ClientHello from " + ClientIpOf(conn) + " reached a server with UseTls off", ClientIpOf(conn));
                        break;
                    }
                    catch (Exception ex) { AuditLog.Log("Network", "Error in HandleClient loop: " + ex.Message); break; }
                }
            }
            finally { RemoveClient(conn); }
        }

        private void ProcessMessage(ClientConnection conn, NetMessage msg)
        {
            conn.LastHeartbeat = DateTime.UtcNow;
            if (conn.ClientInfo != null) conn.ClientInfo.LastHeartbeat = DateTime.UtcNow;
            // Security: server ALWAYS controls the SessionId. Client-supplied
            // SessionId is ignored except as a reconnect hint (ClientReconnect).

            // Rate limiting (defensive: use connection IP, not ClientInfo which
            // is null until Hello).
            // Before ClientHello the key is the remote IP address, the same value that
            // ClientInfo.ClientIp holds after Hello, so each station has its own budget.
            // The key used to be one shared "anonymous" budget: when many kiosks started
            // or reconnected together, that budget ran out and dropped every unwelcomed
            // station's hello for 15 minutes, so those kiosks were never welcomed and
            // never listed on the server. An empty IP still falls back to "anonymous".
            var clientIp = conn.ClientInfo?.ClientIp ?? ClientIpOf(conn);
            var limitResult = _rateLimiter.CheckLimit(clientIp);
            if (!limitResult.Allowed)
            {
                // Self-repair (SRV-004): the message is dropped exactly as before; the reason is recorded.
                string who = clientIp.Length > 0 ? clientIp : ClientIpOf(conn);
                FaultJournal.Raise("SRV-004", "message rate limit reached by " + who, who);
                return;
            }

            SafeInvoke(OnMessageReceived, conn.SessionId, msg, "OnMessageReceived");
            switch (msg.Type)
            {
                case MessageType.ClientHello: HandleHello(conn, msg); break;
                case MessageType.ClientLogin: HandleLogin(conn, msg); break;
                case MessageType.ClientReconnect: HandleReconnect(conn, msg); break;
                case MessageType.ClientLogout: EndSession(conn, "User logout"); break;
                case MessageType.ClientHeartbeat: HandleHeartbeat(conn, msg); break;
                case MessageType.ClientSessionInfo: HandleSessionInfoRequest(conn); break;
                case MessageType.ClientTicketRedeem: HandleTicket(conn, msg); break;
                case MessageType.ClientGameLaunched: HandleGameLaunched(conn, msg); break;
                case MessageType.ClientGameClosed: HandleGameClosed(conn); break;

                // Phase 3: Chat
                case MessageType.ClientChatSend: HandleChatSend(conn, msg); break;
                case MessageType.ClientChatHistory: HandleChatHistory(conn, msg); break;
                case MessageType.ClientAnnouncementList: HandleAnnouncementList(conn); break;
                case MessageType.ClientPrintRequest: HandlePrintRequest(conn, msg); break;
                case MessageType.ClientDebtList: HandleDebtList(conn, msg); break;
                case MessageType.ClientPackageList: HandlePackageList(conn); break;
                case MessageType.ClientPackagePurchase: HandlePackagePurchase(conn, msg); break;
                case MessageType.ClientTierInfo: HandleTierInfo(conn, msg); break;

                // Phase 4: Security
                case MessageType.Client2FAVerify: Handle2FAVerify(conn, msg); break;

                // Phase 9: Remote monitoring
                case MessageType.ClientScreenshotResponse: HandleScreenshotResponse(conn, msg); break;
                // NEW FEATURE (real video+audio codec, per request).
                case MessageType.ClientVideoStreamStatus:
                    {
                        var vs = msg.GetPayload<VideoStreamStatusPayload>();
                        if (vs != null) RaiseVideoStreamStatus(vs.StationName, vs);
                        break;
                    }

                // Phase 10: Auto-update + file transfer + crash report
                case MessageType.ClientUpdateAccept: HandleUpdateAccept(conn, msg); break;
                case MessageType.ClientUpdateProgress: HandleUpdateProgress(conn, msg); break;
                case MessageType.ClientUpdateComplete: HandleUpdateComplete(conn, msg); break;
                case MessageType.ClientCrashReport: HandleCrashReport(conn, msg); break;

                // Phase 11: Quick top-up
                case MessageType.ClientTopupRequest: HandleTopupRequest(conn, msg); break;
                case MessageType.ClientFileTransferAccept: HandleFileTransferAccept(conn, msg); break;
                case MessageType.ClientFileTransferComplete: HandleFileTransferComplete(conn, msg); break;

                // Phase 5: UX
                case MessageType.ClientThemeRequest: HandleThemeRequest(conn); break;
                case MessageType.ClientLangChange: HandleLangChange(conn, msg); break;

                // Phase 6: Intelligence
                case MessageType.ClientSmartPriceRequest: HandleSmartPriceRequest(conn); break;
                case MessageType.ClientAutoRechargeConfig: HandleAutoRechargeConfig(conn, msg); break;
                case MessageType.ClientGameDetection: HandleGameDetection(conn, msg); break;

                // Phase 7: Payment
                case MessageType.ClientPaymentRequest: HandlePaymentRequest(conn, msg); break;
            }
        }

        private void HandleHello(ClientConnection conn, NetMessage msg)
        {
            var h = msg.GetPayload<ClientHelloPayload>();
            if (h == null) return;

            // Phase — Network Access Control (MAC whitelist + CIDR filter).
            // Enforce BEFORE license check so a banned IP is rejected fast.
            string clientIp = "";
            try { clientIp = ((IPEndPoint)conn.TcpClient.Client.RemoteEndPoint)?.Address?.ToString() ?? ""; } catch { }
            try
            {
                var (allowed, aclReason) = NetworkAccessControl.IsAllowed(clientIp, h.MacAddress ?? "");
                if (!allowed)
                {
                    AuditLog.Log("Network", $"Client rejected (ACL): {aclReason} (ip={clientIp}, mac={h.MacAddress})");
                    FaultJournal.Raise("AUTH-001", "ip=" + clientIp + " mac=" + (h.MacAddress ?? "") + " | " + aclReason, clientIp);
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "دسترسی غیرمجاز: " + aclReason }));
                    try { System.Threading.Tasks.Task.Delay(2000).ContinueWith(_ => { try { conn.TcpClient?.Close(); } catch { } }); } catch { }
                    return;
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "ACL check error: " + ex.Message); }

            // FIX CLIENT-NOT-SHOWING: DISABLED license validation. The license
            // check was rejecting clients when RegisterStation failed (e.g.
            // DB table issues, duplicate names, empty fingerprint). This was
            // the #1 cause of "client connects but doesn't show in server".
            // All clients are now accepted immediately — license validation
            // can be re-enabled later from the security tab if needed.
            //
            // try
            // {
            //     var licMgr = new ClientLicenseManager();
            //     var (approved, reason, stationName) = licMgr.ValidateConnection(
            //         h.MachineFingerprint ?? "", h.MacAddress ?? "", h.LicenseToken ?? "", h.StationName ?? h.MachineName);
            //     if (!approved) { ... reject ... return; }
            // }
            // catch (Exception ex) { AuditLog.Log("Network", "License check error: " + ex.Message); }

            // FIX H1: client integrity self-hash check. If the operator has
            // configured a known-good client hash (settings table key
            // 'client_known_hash'), compare the client's SelfHash against it.
            // A mismatch means the client exe has been tampered with / patched
            // (e.g. to bypass the keyboard hook or the license check). Reject
            // the connection so a modified client cannot join the network.
            // If no known-good hash is configured (default), skip the check
            // so first-run deployments work without extra setup.
            try
            {
                string knownHash = Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = 'client_known_hash'",
                    null, r => r.GetString(0));
                if (!string.IsNullOrWhiteSpace(knownHash))
                {
                    string clientHash = h.SelfHash ?? "";
                    if (!string.Equals(clientHash, knownHash.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        FaultJournal.Raise("AUTH-002", "station=" + (h.StationName ?? h.MachineName), clientIp);
                        AuditLog.Log("Network", $"Client rejected (integrity): self-hash mismatch (client={clientHash?.Substring(0,Math.Min(12,clientHash.Length)) ?? "—"}, expected={knownHash.Trim().Substring(0,Math.Min(12,knownHash.Trim().Length))}, station={h.StationName})");
                        SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "نسخه کلاینت شما معتبر نیست (تغییر یافته). لطفاً نسخه رسمی را نصب کنید." }));
                        try { System.Threading.Tasks.Task.Delay(2000).ContinueWith(_ => { try { conn.TcpClient?.Close(); } catch { } }); } catch { }
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "Integrity check error: " + ex.Message);
                // Self-repair (DB-002): recorded; the check stays fail-open exactly as before.
                FaultJournal.Raise("DB-002", "integrity check could not run, connection continues (fail-open): " + ex.Message, clientIp);
                /* fail-open on DB error */
            }

            // SECURITY FIX: the client already sends ServerClientPassword in
            // every handshake, and the server-side setting to configure one
            // already exists in OptionsForm — but nothing here ever read or
            // checked it, so the feature was completely inert. Anyone could
            // connect regardless of what password (if any) the operator
            // configured. Follows the exact same opt-in pattern as the
            // integrity check above: only enforced if the operator has
            // actually set a non-empty password, so deployments that never
            // touched this setting see no change in behavior.
            try
            {
                string optionsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
                if (File.Exists(optionsPath))
                {
                    var opts = Newtonsoft.Json.Linq.JObject.Parse(File.ReadAllText(optionsPath));
                    string configuredPassword = (string)opts["ServerClientPassword"];
                    if (!string.IsNullOrEmpty(configuredPassword))
                    {
                        string clientPassword = h.ServerClientPassword ?? "";
                        if (!string.Equals(clientPassword, configuredPassword, StringComparison.Ordinal))
                        {
                            FaultJournal.Raise("AUTH-003", "station=" + (h.StationName ?? h.MachineName), clientIp);
                            AuditLog.Log("Network", $"Client rejected (password): station={h.StationName ?? h.MachineName}");
                            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "رمز اتصال کلاینت نادرست است." }));
                            try { System.Threading.Tasks.Task.Delay(2000).ContinueWith(_ => { try { conn.TcpClient?.Close(); } catch { } }); } catch { }
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "ServerClientPassword check error: " + ex.Message);
                // Self-repair (CFG-002): recorded; the check stays fail-open exactly as before.
                FaultJournal.Raise("CFG-002", "options.json could not be read for the station password check (fail-open): " + ex.Message, clientIp);
                /* fail-open on read error, consistent with the integrity check above */
            }

            conn.ClientInfo = new ConnectedClient
            {
                SessionId = conn.SessionId,
                StationName = h.StationName ?? h.MachineName,
                MachineName = h.MachineName,
                MacAddress = h.MacAddress,
                ClientIp = ((IPEndPoint)conn.TcpClient.Client.RemoteEndPoint)?.Address?.ToString() ?? "",
                State = ClientState.Connected,
                ConnectedAt = DateTime.UtcNow,
                LastHeartbeat = DateTime.UtcNow,
                OsVersion = h.OsVersion ?? "",
                PlayAndPay = h.PlayAndPay,
                // FIX M2: store the kiosk's reported build so the monitor grid
                // can display the real client version instead of a hardcoded
                // "8.1" placeholder.
                ClientVersion = h.ClientVersion ?? "",
                // FIX H2: SessionStart is set later in CompleteLogin — until
                // then default to ConnectedAt so the tuple's non-nullable
                // SessionStart field has a sensible value (the kiosk has not
                // logged in yet, so "used time" reads as ~0).
                SessionStart = DateTime.UtcNow
            };

            // === Auto-number stations PC_1 .. PC_10 ===
            // If the client sent a generic MachineName (or empty StationName),
            // assign a sequential PC_N name based on connection order. This
            // persists in a small JSON file so the same physical kiosk gets the
            // same number across restarts (identified by MAC address).
            try
            {
                string mac = h.MacAddress ?? "";
                // FIX L12: if the kiosk couldn't determine its MAC (NetworkClient
                // returns "UNKNOWN" when no NIC is up), use the client IP as the
                // dedup key so two simultaneously-connected MAC-less kiosks don't
                // collide on the same PC_N assignment. Without this, every
                // MAC-less kiosk mapped to the literal "_unknown_mac_" entry
                // and they all shared PC_1.
                if (string.IsNullOrEmpty(mac) || mac == "UNKNOWN")
                {
                    try
                    {
                        mac = ((IPEndPoint)conn.TcpClient.Client.RemoteEndPoint)?.Address?.ToString() ?? "";
                    }
                    catch { }
                    if (string.IsNullOrEmpty(mac)) mac = "_unknown_mac_";
                }
                string assignedName = StationNumbering.GetOrAssign(mac, conn.ClientInfo.StationName);
                if (!string.IsNullOrEmpty(assignedName))
                    conn.ClientInfo.StationName = assignedName;
            }
            catch (Exception ex) { AuditLog.Log("Network", "StationNumbering error: " + ex.Message); }

            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerWelcome, new ServerWelcomePayload { ServerVersion = Protocol.ServerVersion, ServerName = "مرکز بازی", SessionId = conn.SessionId }));
            SendGameList(conn.SessionId);
            SendPriceInfo(conn.SessionId);
            SafeInvoke(OnClientConnected, conn.ClientInfo, "OnClientConnected");

            // Config sync (Phase 8). The same settings are sent again by
            // PushConfigIfChanged whenever the operator changes them.
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerConfigSync, BuildConfigSyncPayload()));
        }

        /// <summary>
        /// The settings a station receives: the saved server options and the feature
        /// flags. Sent at ServerWelcome, and sent again by PushConfigIfChanged when the
        /// operator changes them.
        /// </summary>
        private ConfigSyncPayload BuildConfigSyncPayload()
        {
            try
            {
                var cfgOpts = Forms.OptionsForm.LoadStaticOptions();
                var settings = FeatureFlagManager.BuildSettingsDictionary();
                string lang = "fa";
                if (cfgOpts != null)
                {
                    if (!string.IsNullOrEmpty(cfgOpts.Language)) lang = cfgOpts.Language;
                    // FIX DEAD-CONFIG-4: the kiosk top banner text/color —
                    // previously configurable in OptionsForm but never sent
                    // to any client. Piggybacks on the existing feature-flag
                    // Settings dictionary so no protocol change is needed.
                    settings["banner_top_text"] = cfgOpts.BannerTopText ?? "";
                    settings["banner_color"] = cfgOpts.BannerColor ?? "";
                    // FIX DEAD-CONFIG-5: bandwidth cap for server→client file
                    // transfer (update distribution / SendFileToStation).
                    // See UpdateDistributor.StreamFile/StreamFileTransfer,
                    // which now throttle to this rate when enabled.
                    settings["bandwidth_limit_enabled"] = cfgOpts.BandwidthLimit ? "1" : "0";
                    settings["bandwidth_max_kbps"] = (cfgOpts.BandwidthMaxKbps > 0 ? cfgOpts.BandwidthMaxKbps : 100).ToString();
                }
                return new ConfigSyncPayload { ServerVersion = Protocol.ServerVersion, HeartbeatInterval = Protocol.HeartbeatIntervalSeconds, SessionWarningMinutes = 15, ThemeName = "Catppuccin Mocha", Language = lang, Settings = settings };
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "ConfigSync build failed, sending defaults: " + ex.Message);
                return new ConfigSyncPayload { ServerVersion = Protocol.ServerVersion, HeartbeatInterval = Protocol.HeartbeatIntervalSeconds, SessionWarningMinutes = 15, ThemeName = "Catppuccin Mocha", Language = "fa", Settings = FeatureFlagManager.BuildSettingsDictionary() };
            }
        }

        /// <summary>Starts the timer that checks, every 30 seconds, whether the settings changed.</summary>
        private void StartConfigPushTimer()
        {
            try
            {
                string baseline = ConfigSignature(BuildConfigSyncPayload());
                lock (_configPushLock) _lastConfigSignature = baseline;
            }
            catch (Exception ex) { AuditLog.Log("Network", "Settings push baseline failed: " + ex.Message); }
            _configPushTimer = new Timer(PushConfigIfChanged, null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));
        }

        /// <summary>
        /// Sends the settings again to every station that has completed ServerWelcome,
        /// but only when they differ from what was sent last. A station that has not
        /// welcomed yet receives them in its welcome, so it is skipped here.
        /// </summary>
        private void PushConfigIfChanged(object state)
        {
            if (!_running) return;
            try
            {
                var payload = BuildConfigSyncPayload();
                string signature = ConfigSignature(payload);
                lock (_configPushLock)
                {
                    if (signature == _lastConfigSignature) return;
                    _lastConfigSignature = signature;
                }

                int sent = 0;
                foreach (var kvp in _connections)
                {
                    var conn = kvp.Value;
                    if (conn.ClientInfo == null) continue;
                    try
                    {
                        SendToClient(conn.SessionId, new NetMessage(MessageType.ServerConfigSync, payload));
                        sent++;
                    }
                    catch { }
                }
                AuditLog.Log("Network", "Settings changed: sent to " + sent + " station(s).");
            }
            catch (Exception ex) { AuditLog.Log("Network", "Settings push failed: " + ex.Message); }
        }

        /// <summary>A text form of the settings, used only to detect a change.</summary>
        private static string ConfigSignature(ConfigSyncPayload p)
        {
            string sig = p.Language + "|" + p.ThemeName + "|" + p.HeartbeatInterval + "|" + p.SessionWarningMinutes + "|";
            if (p.Settings == null) return sig;
            var keys = new List<string>(p.Settings.Keys);
            keys.Sort(StringComparer.Ordinal);
            foreach (var k in keys)
                sig += k + "=" + p.Settings[k] + ";";
            return sig;
        }

        private void HandleLogin(ClientConnection conn, NetMessage msg)
        {
            var login = msg.GetPayload<ClientLoginPayload>();
            if (login == null) return;
            try
            {
                // Use the secure UserManager.Authenticate (PBKDF2 + lockout)
                // instead of the old unsalted-SHA256 path that would never
                // match PBKDF2-stored hashes.
                var userMgr = new UserManager();
                var userInfo = userMgr.FindByUsername(login.Username);
                if (userInfo == null || !userInfo.IsActive)
                {
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "نام کاربری یا رمز عبور اشتباه است" }));
                    try { IntrusionDetectionSystem.RecordFailedLogin(login.Username, conn.ClientInfo?.ClientIp ?? ""); } catch { }
                    return;
                }
                bool authOk;
                try { authOk = userMgr.Authenticate(login.Username, login.Password); }
                catch (UnauthorizedAccessException) { authOk = false; }
                catch { authOk = false; }
                if (!authOk)
                {
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "نام کاربری یا رمز عبور اشتباه است" }));
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Auth, "LoginFail", $"User: {login.Username}", EnhancedAuditLog.AuditLevel.Warning, clientIp: conn.ClientInfo?.ClientIp ?? "");
                    try { IntrusionDetectionSystem.RecordFailedLogin(login.Username, conn.ClientInfo?.ClientIp ?? ""); } catch { }
                    return;
                }
                // Re-fetch the (possibly balance-updated) record
                var user = userInfo;

                // FIX ADMIN-LOGIN: DISABLED 2FA check for CLIENT login.
                // 2FA is for OPERATORS logging into the SERVER admin panel,
                // NOT for kiosk users logging into the client. The old code
                // checked the operators table for 2FA when a kiosk user
                // logged in — if the username "admin" also existed in the
                // operators table with 2FA enabled, the kiosk login would
                // get stuck waiting for a 2FA code that the kiosk UI
                // doesn't even support. This was the #1 cause of
                // "client becomes inaccessible when logging in as admin."
                //
                // bool requires2FA = false;
                // try {
                //     var flag = Database.Instance.QueryOne("SELECT CASE WHEN two_factor_enabled = 1 THEN 1 ELSE 0 END FROM operators WHERE username = @u", ...);
                //     requires2FA = flag == 1;
                // } catch { }
                // if (requires2FA) { ... return; }

                CompleteLogin(conn, user.Username);
            }
            catch (Exception ex)
            {
                SendToClient(conn.SessionId, new NetMessage(MessageType.Error, new { Error = ex.Message }));
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Auth, "LoginError", ex.Message, EnhancedAuditLog.AuditLevel.Error);
            }
        }

        /// <summary>
        /// Performs the session-creation + notification steps that complete a
        /// login. Called either directly from HandleLogin (no 2FA) or from
        /// Handle2FAVerify after a successful TOTP challenge.
        /// </summary>
        private void CompleteLogin(ClientConnection conn, string username)
        {
            var user = Database.Instance.QueryOne("SELECT id, username, display_name, balance FROM users WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => new { Id = r.GetInt32(0), User = r.GetString(1), Disp = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2), Bal = r.GetDecimal(3) });
            if (user == null)
            {
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail, new ServerLoginResultPayload { Success = false, Message = "کاربر یافت نشد" }));
                return;
            }

            // Apply member tier discount
            decimal discount = 0;
            try { discount = new MemberTierManager().GetUserDiscount(user.User); } catch (Exception ex) { AuditLog.Log("Network", "Error fetching tier discount: " + ex.Message); }
            decimal basePph = 15000m;
            try { var priceRow = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1", null, r => r.GetDecimal(0)); if (priceRow > 0) basePph = priceRow; } catch (Exception ex) { AuditLog.Log("Network", "Error fetching price: " + ex.Message); }

            // Smart pricing (Phase 6)
            decimal effectivePph = basePph;
            try { effectivePph = new SmartPricing().CalculateEffectivePrice(user.User, conn.ClientInfo?.StationName ?? "", basePph); }
            catch (Exception ex) { AuditLog.Log("Network", "SmartPricing error: " + ex.Message); effectivePph = Math.Round(basePph * (1 - discount / 100), 0); }

            string sid = Guid.NewGuid().ToString("N");
            Database.Instance.Execute("INSERT INTO client_sessions (session_id, username, station_name, machine_name, mac_address, state, start_time, last_heartbeat, is_connected, client_ip) VALUES (@sid, @u, @st, @m, @mac, @state, @start, @hb, 1, @ip)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@sid", sid);
                    cmd.Parameters.AddWithValue("@u", user.User);
                    cmd.Parameters.AddWithValue("@st", conn.ClientInfo?.StationName ?? "");
                    cmd.Parameters.AddWithValue("@m", conn.ClientInfo?.MachineName ?? "");
                    cmd.Parameters.AddWithValue("@mac", conn.ClientInfo?.MacAddress ?? "");
                    cmd.Parameters.AddWithValue("@state", (int)ClientState.InSession);
                    cmd.Parameters.AddWithValue("@start", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@hb", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@ip", conn.ClientInfo?.ClientIp ?? "");
                });
            if (conn.ClientInfo != null) { conn.ClientInfo.State = ClientState.InSession; conn.ClientInfo.CurrentUser = user.User; conn.ClientInfo.SessionStart = DateTime.UtcNow; }
            conn.CurrentSessionId = sid;
            conn.CurrentUser = user.User;
            int? minRem = effectivePph > 0 && user.Bal > 0 ? (int)(user.Bal / effectivePph * 60) : (int?)null;

            // Send announcements on login
            try { var announcements = new AnnouncementManager().GetActiveAnnouncements(); if (announcements.Announcements.Count > 0) SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAnnouncementList, announcements)); } catch (Exception ex) { AuditLog.Log("Network", "Error sending announcements: " + ex.Message); }

            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginOk, new ServerLoginResultPayload { Success = true, DisplayName = user.Disp, Balance = user.Bal, PricePerHour = effectivePph, SessionMinutesRemaining = minRem }));

            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Auth, "UserLogin", $"User: {user.User}", EnhancedAuditLog.AuditLevel.Info, clientIp: conn.ClientInfo?.ClientIp ?? "", stationName: conn.ClientInfo?.StationName ?? "");
            try { IntrusionDetectionSystem.RecordSuccessfulLogin(user.User, conn.ClientInfo?.ClientIp ?? ""); } catch { }

            SafeInvoke(OnSessionStarted, conn.ClientInfo?.StationName ?? conn.SessionId, new ClientSession { SessionId = sid, Username = user.User, StationName = conn.ClientInfo?.StationName ?? "", StartTime = DateTime.UtcNow, State = ClientState.InSession }, "OnSessionStarted");
        }

        /// <summary>
        /// Handles ClientReconnect (MessageType 1011). The server ALWAYS controls
        /// the SessionId — the client's claimed id is only a lookup hint. If the
        /// <summary>
        /// Handles a client heartbeat. Updates the connection's CPU/RAM/disk
        /// stats from the ClientStatusPayload (if present) so the live
        /// monitor shows real-time system metrics. Also sends a heartbeat
        /// ack so the client knows the connection is alive.
        /// </summary>
        private void HandleHeartbeat(ClientConnection conn, NetMessage msg)
        {
            conn.LastHeartbeat = DateTime.UtcNow;
            if (conn.ClientInfo != null) conn.ClientInfo.LastHeartbeat = DateTime.UtcNow;

            try
            {
                var status = msg.GetPayload<ClientStatusPayload>();
                if (status != null && conn.ClientInfo != null)
                {
                    conn.ClientInfo.CpuUsage = status.CpuUsage;
                    conn.ClientInfo.MemoryUsage = status.MemoryUsage;
                    if (!string.IsNullOrEmpty(status.CurrentGame))
                        conn.ClientInfo.CurrentGame = status.CurrentGame;
                    conn.ClientInfo.ActiveWindowTitle = status.ActiveWindowTitle ?? "";
                    conn.ClientInfo.OsVersion = status.OsVersion ?? "";
                    // FIX DEAD-CONFIG-2: drives the idle-shutdown check in BillingCycle.
                    conn.ClientInfo.IdleSeconds = status.IdleSeconds;
                }
            }
            catch { }

            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerHeartbeatAck));
        }

        /// <summary>
        /// Handles a ClientReconnect message. The client sends its previous
        /// SessionId; if that id maps to a live connection, the new connection takes over
        /// the session state and the old connection is closed. If the claimed id
        /// is unknown or stale, the server sends a fresh login challenge.
        /// </summary>
        private void HandleReconnect(ClientConnection conn, NetMessage msg)
        {
            string claimedSessionId = msg.SessionId;
            if (string.IsNullOrEmpty(claimedSessionId))
            {
                SendLoginChallenge(conn, "نشست معتبر نیست. لطفاً دوباره وارد شوید");
                return;
            }

            if (!_connections.TryGetValue(claimedSessionId, out var oldConn) || ReferenceEquals(oldConn, conn))
            {
                SendLoginChallenge(conn, "نشست معتبر نیست. لطفاً دوباره وارد شوید");
                return;
            }

            // Validate freshness: if the old connection hasn't sent a heartbeat
            // recently, the session is effectively dead — clean up and ask the
            // client to log in afresh.
            if (DateTime.UtcNow - oldConn.LastHeartbeat > TimeSpan.FromSeconds(180))
            {
                _connections.TryRemove(claimedSessionId, out _);
                SendLoginChallenge(conn, "نشست منقضی شده. لطفاً دوباره وارد شوید");
                try { lock (oldConn.SendLock) oldConn.Dispose(); } catch (Exception ex) { AuditLog.Log("Network", "Error disposing stale old conn: " + ex.Message); }
                return;
            }

            // Rebind: transfer session state to the new connection. The new
            // connection takes over the OLD (claimed) SessionId — this is
            // critical: the client treats a ServerWelcome whose SessionId
            // matches its _lastSessionId as a successful resume, not a forced
            // re-login (FIX 3).
            conn.CurrentUser = oldConn.CurrentUser;
            conn.CurrentSessionId = oldConn.CurrentSessionId;
            // FIX 14: clone ClientInfo instead of sharing the instance —
            // concurrent readers (Refresh / BillingCycle / heartbeat thread)
            // could otherwise see half-mutated data when the new connection
            // updates fields.
            var oldInfo = oldConn.ClientInfo;
            if (oldInfo != null)
            {
                conn.ClientInfo = new ConnectedClient
                {
                    SessionId = claimedSessionId,
                    StationName = oldInfo.StationName,
                    MachineName = oldInfo.MachineName,
                    MacAddress = oldInfo.MacAddress,
                    ClientIp = oldInfo.ClientIp,
                    State = oldInfo.State,
                    ConnectedAt = oldInfo.ConnectedAt,
                    LastHeartbeat = DateTime.UtcNow,
                    CurrentUser = oldInfo.CurrentUser,
                    CurrentGame = oldInfo.CurrentGame,
                    SessionMinutesElapsed = oldInfo.SessionMinutesElapsed,
                    SessionCost = oldInfo.SessionCost,
                    CpuUsage = oldInfo.CpuUsage,
                    MemoryUsage = oldInfo.MemoryUsage,
                    ActiveWindowTitle = oldInfo.ActiveWindowTitle,
                    OsVersion = oldInfo.OsVersion,
                    PlayAndPay = oldInfo.PlayAndPay,
                    // FIX H2/M2/L14: preserve the per-session fields across
                    // reconnect so the monitor grid keeps showing the right
                    // session-start time, client build, and time cap.
                    SessionStart = oldInfo.SessionStart != default(DateTime) ? oldInfo.SessionStart : oldInfo.ConnectedAt,
                    ClientVersion = oldInfo.ClientVersion ?? "",
                    TimeCapMinutes = oldInfo.TimeCapMinutes,
                };
                oldConn.ClientInfo = null; // prevent further use of the old instance
            }
            conn.LastHeartbeat = DateTime.UtcNow;
            oldConn.CurrentSessionId = null;
            oldConn.CurrentUser = null;

            // FIX M15: re-key _connections ATOMICALLY. The previous code did:
            //   1. _connections.TryRemove(claimedSessionId, out _)  // remove old
            //   2. lock(oldConn.SendLock) oldConn.Dispose()
            //   3. _connections.TryRemove(conn.SessionId, out _)     // remove new's server-assigned id
            //   4. _connections[claimedSessionId] = conn             // add new under claimed id
            // Between steps 1 and 4, a concurrent SendToClient(claimedSessionId, ...)
            // (e.g. a chat send, billing-timer tick, or operator action) would
            // silently drop the message because the key was temporarily absent.
            // Add-first guarantees there is always exactly one live entry for
            // claimedSessionId at every point in time.
            string newConnOldServerSessionId = conn.SessionId;
            conn.SessionId = claimedSessionId;
            _connections[claimedSessionId] = conn;               // add new conn under claimed id (overwrites oldConn)
            _connections.TryRemove(newConnOldServerSessionId, out _); // remove new conn's server-assigned id (now stale)

            // FIX (FIX-FINAL-10 B1+B2): BEFORE disposing the old connection,
            // reassign its SessionId to a sentinel value so its eventual
            // RemoveClient (called from the ReadLoop finally block when the
            // old socket is disposed) does NOT remove the NEW connection.
            //
            // Previously oldConn.SessionId was still == claimedSessionId
            // (the dict key under which the NEW conn is now published), so
            // RemoveClient(oldConn) did _connections.TryRemove(claimedSessionId)
            // — which silently DELETED the new conn. The new conn's eventual
            // disconnect then found no dict entry, never raised OnClientDisconnected,
            // and the server kept billing a ghost session whose socket was gone.
            //
            // The sentinel "::stale::" makes TryRemove return false → RemoveClient
            // returns early at the `if (!removed) return;` guard, so neither the
            // dict entry nor OnClientDisconnected is touched for the old conn
            // (which is correct — the new conn has taken over the session, so no
            // disconnect event should fire for the old one).
            //
            // B2: this also fixes the "OnClientDisconnected raised with GUID"
            // bug — with ClientInfo already nulled (line 645), the old
            // RemoveClient path would have fallen back to conn.SessionId (the
            // GUID-like claimedSessionId) when raising OnClientDisconnected.
            // With the sentinel, OnClientDisconnected is no longer raised at
            // all for the old conn, and for the NEW conn (which eventually
            // disconnects normally) ClientInfo is intact so StationName is used.
            oldConn.SessionId = "::stale::";

            // Dispose the old connection AFTER the new one is published so
            // concurrent readers that grabbed oldConn before the overwrite
            // can still finish their locked send. The oldConn's finally-block
            // RemoveClient will be a no-op (TryRemove returns false because
            // the dict key under "::stale::" doesn't exist).
            try { lock (oldConn.SendLock) oldConn.Dispose(); } catch (Exception ex) { AuditLog.Log("Network", "Error disposing old conn on reconnect: " + ex.Message); }

            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Session, "ClientReconnect",
                $"Rebound session {claimedSessionId} (preserved), user={conn.CurrentUser}",
                EnhancedAuditLog.AuditLevel.Info,
                clientIp: conn.ClientInfo?.ClientIp ?? "",
                stationName: conn.ClientInfo?.StationName ?? "");

            // FIX 3: reply with the OLD (claimed) SessionId so the client
            // treats it as a successful resume and doesn't force a re-login.
            SendToClient(claimedSessionId, new NetMessage(MessageType.ServerWelcome,
                new ServerWelcomePayload { ServerVersion = Protocol.ServerVersion, ServerName = "مرکز بازی", SessionId = claimedSessionId }));
        }

        private void SendLoginChallenge(ClientConnection conn, string message)
        {
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerLoginFail,
                new ServerLoginResultPayload { Success = false, Message = message }));
        }

        private void HandleTicket(ClientConnection conn, NetMessage msg)
        {
            var t = msg.GetPayload<TicketRedeemPayload>();
            if (t == null) return;
            try
            {
                var result = new TicketManager().RedeemTicket(t.TicketCode, conn.CurrentUser ?? "");
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTicketResult, result));
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "Error in HandleTicket: " + ex.Message);
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTicketResult, new TicketResultPayload { Success = false, Message = ex.Message }));
            }
        }

        private void HandleGameLaunched(ClientConnection conn, NetMessage msg)
        {
            var g = msg.GetPayload<ClientGameLaunchedPayload>();
            if (g != null && conn.ClientInfo != null) conn.ClientInfo.CurrentGame = g.GameName;
            try
            {
                Database.Instance.Execute("UPDATE client_sessions SET current_game = @g WHERE session_id = @s",
                    cmd => { cmd.Parameters.AddWithValue("@g", g?.GameName ?? ""); cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId ?? ""); });
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleGameLaunched: " + ex.Message); }
        }

        private void HandleGameClosed(ClientConnection conn)
        {
            if (conn.ClientInfo != null) conn.ClientInfo.CurrentGame = null;
            try
            {
                Database.Instance.Execute("UPDATE client_sessions SET current_game = NULL WHERE session_id = @s",
                    cmd => cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId ?? ""));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleGameClosed: " + ex.Message); }
        }

        // === Phase 3 Message Handlers ===
        private void HandleChatSend(ClientConnection conn, NetMessage msg)
        {
            var chatMsg = msg.GetPayload<ChatSendPayload>();
            if (chatMsg == null) return;
            chatMsg.SenderUsername = conn.CurrentUser ?? "unknown";
            string station = conn.ClientInfo?.StationName ?? "";

            // Round 11: the kiosk's +10/+30/+60, "end", "lock" and "shutdown" buttons send
            // "[REQ] ..." through this chat channel (ClientEngine.SetSessionTimeRequest).
            // They were stored as chat lines that nobody was sent, so the operator never
            // saw them. Now they are raised to the server UI and not stored as chat.
            string text = chatMsg.Message ?? "";
            if (text.StartsWith("[REQ]", StringComparison.Ordinal))
            {
                string kind = null; int minutes = 0;
                var m = System.Text.RegularExpressions.Regex.Match(text, @"^\[REQ\] action=(\d+),min=(-?\d+)");
                if (m.Success)
                {
                    int action;
                    int.TryParse(m.Groups[1].Value, out action);
                    int.TryParse(m.Groups[2].Value, out minutes);
                    if (action == 1 && minutes > 0 && minutes <= 600) kind = "time";
                    else if (action == 3) kind = "end";
                }
                else if (text == "[REQ] lock") kind = "lock";
                else if (text == "[REQ] shutdown") kind = "shutdown";
                if (kind != null)
                {
                    AuditLog.Log("Request", $"Customer request from {chatMsg.SenderUsername} on {station}: {kind} {minutes}");
                    try { ActivityJournal.Record(ActivityJournal.Request, (kind == "time" ? "درخواست " + minutes + " دقیقه زمان اضافه" : kind == "end" ? "درخواست پایان نشست" : kind == "shutdown" ? "درخواست خاموش کردن" : "درخواست قفل") + " — «" + chatMsg.SenderUsername + "»", station); } catch { } // round 14
                    try { SafeInvoke(OnCustomerRequest, station, chatMsg.SenderUsername, kind, minutes, "OnCustomerRequest"); } catch { }
                }
                return;
            }
            // A message for the operator (no target) or for everyone: tell the operator.
            if (string.IsNullOrEmpty(chatMsg.TargetUsername) && !string.IsNullOrWhiteSpace(text))
            {
                try { ActivityJournal.Record(ActivityJournal.Request, "پیام «" + chatMsg.SenderUsername + "»: " + (text.Length > 200 ? text.Substring(0, 200) + "…" : text), station); } catch { } // round 14
                try { SafeInvoke(OnCustomerMessage, station, chatMsg.SenderUsername, text, "OnCustomerMessage"); } catch { }
            }
            try
            {
                var result = new ChatManager().SendMessage(chatMsg.SenderUsername, chatMsg.Message, chatMsg.TargetUsername, chatMsg.IsBroadcast);
                if (chatMsg.IsBroadcast) BroadcastMessage(new NetMessage(MessageType.ServerChatReceive, result));
                else if (!string.IsNullOrEmpty(chatMsg.TargetUsername))
                {
                    foreach (var kvp in _connections)
                    {
                        if (kvp.Value.CurrentUser == chatMsg.TargetUsername)
                        {
                            SendToClient(kvp.Key, new NetMessage(MessageType.ServerChatReceive, result));
                            break;
                        }
                    }
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleChatSend: " + ex.Message); }
        }

        private void HandleChatHistory(ClientConnection conn, NetMessage msg)
        {
            try { var history = new ChatManager().GetHistory(conn.CurrentUser ?? "", 50); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerChatHistory, history)); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleChatHistory: " + ex.Message); }
        }

        private void HandleAnnouncementList(ClientConnection conn)
        {
            try { var announcements = new AnnouncementManager().GetActiveAnnouncements(); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAnnouncementList, announcements)); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleAnnouncementList: " + ex.Message); }
        }

        private void HandlePrintRequest(ClientConnection conn, NetMessage msg)
        {
            var printReq = msg.GetPayload<PrintRequestPayload>();
            if (printReq == null) return;
            try { var result = new PrintManager().CreatePrintJob(printReq.Username, printReq.StationName, printReq.DocumentName, printReq.Pages, printReq.PrintType, printReq.Notes); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPrintResult, result)); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandlePrintRequest: " + ex.Message); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPrintResult, new PrintResultPayload { Success = false, Message = ex.Message })); }
        }

        private void HandleDebtList(ClientConnection conn, NetMessage msg)
        {
            try { string username = conn.CurrentUser ?? ""; var debts = new DebtManager().GetUserDebts(username); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerDebtList, debts)); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleDebtList: " + ex.Message); }
        }

        private void HandlePackageList(ClientConnection conn)
        {
            try
            {
                var packages = new SessionPackageManager().GetActivePackages();
                var payload = new PackageListPayload { Packages = packages.ConvertAll(p => new SessionPackagePayload { Id = p.Id, Name = p.Name, Description = p.Description, DurationMinutes = p.DurationMinutes, Price = p.Price, IsActive = p.IsActive, MaxUses = p.MaxUses, CurrentUses = p.CurrentUses, Category = p.Category }) };
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPackageList, payload));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandlePackageList: " + ex.Message); }
        }

        private void HandlePackagePurchase(ClientConnection conn, NetMessage msg)
        {
            var purchase = msg.GetPayload<PackagePurchasePayload>();
            if (purchase == null) return;
            try { var result = new SessionPackageManager().PurchasePackage(purchase.PackageId, purchase.Username); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPackageResult, result)); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandlePackagePurchase: " + ex.Message); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPackageResult, new PackageResultPayload { Success = false, Message = ex.Message })); }
        }

        private void HandleTierInfo(ClientConnection conn, NetMessage msg)
        {
            try { string username = conn.CurrentUser ?? ""; var tierInfo = new MemberTierManager().GetUserTierInfo(username); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTierInfo, tierInfo ?? new TierInfoPayload())); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleTierInfo: " + ex.Message); }
        }

        // === Phase 9: Remote Monitoring ===

        /// <summary>
        /// Sends a screenshot request to the named station. The response will
        /// arrive asynchronously and raise OnScreenshotReceived.
        /// </summary>
        public void RequestScreenshot(string stationName, int quality = 50)
        {
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Network", "RequestScreenshot: station not found: " + stationName); return; }
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerScreenshotRequest,
                new ScreenshotRequestPayload { StationName = stationName, Quality = quality }));
        }

        private void HandleScreenshotResponse(ClientConnection conn, NetMessage msg)
        {
            var payload = msg.GetPayload<ScreenshotResponsePayload>();
            if (payload == null) return;
            string station = conn.ClientInfo?.StationName ?? payload.StationName ?? "";
            try { SafeInvoke(OnScreenshotReceived, station, payload, "OnScreenshotReceived"); }
            catch (Exception ex) { AuditLog.Log("Network", "Screenshot response handler error: " + ex.Message); }
        }

        /// <summary>
        /// Phase 11 — Adds credit to a user AND notifies the connected client
        /// so its session timer updates immediately (doesn't expire). Called
        /// from the ClientMonitorForm right-click menu.
        /// </summary>
        public void AddCreditToClient(string stationName, string username, decimal amount, string reason = "افزایش دستی اپراتور")
        {
            try { ActivityJournal.Record(ActivityJournal.TimeCredit, "افزودن اعتبار " + amount.ToString("N0") + " تومان به «" + username + "» — " + reason, stationName); } catch { } // round 14
            // 1. Add credit in DB
            try { new UserManager().AddCredit(username, amount, reason); }
            catch (Exception ex) { AuditLog.Log("Network", "AddCreditToClient DB error: " + ex.Message); return; }

            // 2. Fetch new balance
            decimal newBalance = 0;
            try
            {
                var user = new UserManager().FindByUsername(username);
                if (user != null) newBalance = user.Balance;
            }
            catch { }

            // 3. Notify the client so it updates its display + session timer
            var conn = FindConnectionByStation(stationName);
            if (conn != null)
            {
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAddCredit,
                    new AddCreditPayload
                    {
                        Username = username,
                        Amount = amount,
                        NewBalance = newBalance,
                        Reason = reason,
                        AddedAt = DateTime.UtcNow
                    }));
                AuditLog.Log("Network", $"AddCredit: {username} +{amount:N0} (new balance: {newBalance:N0}), client {stationName} notified");
            }
            else
            {
                AuditLog.Log("Network", $"AddCredit: {username} +{amount:N0} (new balance: {newBalance:N0}), but station {stationName} not connected — client will see updated balance on next login");
            }
        }

        /// <summary>Finds a connection by station name (case-insensitive).</summary>
        private ClientConnection FindConnectionByStation(string stationName)
        {
            if (string.IsNullOrEmpty(stationName)) return null;
            foreach (var kvp in _connections)
            {
                if (string.Equals(kvp.Value.ClientInfo?.StationName, stationName, StringComparison.OrdinalIgnoreCase))
                    return kvp.Value;
            }
            return null;
        }

        /// <summary>
        /// FIX H8 — Updates the in-memory ClientInfo.StationName for every
        /// connection whose station name matches <paramref name="oldName"/>.
        /// Called by ClientMonitorForm.ChangePcForSelected after the DB row is
        /// updated so the live grid (and the left sidebar live view) reflect
        /// the new station name immediately — previously the in-memory
        /// ClientInfo kept the old name until the kiosk disconnected, so the
        /// monitor grid showed the stale name for the rest of the session.
        /// </summary>
        public void RenameStation(string oldName, string newName)
        {
            if (string.IsNullOrEmpty(oldName) || string.IsNullOrEmpty(newName)) return;
            try
            {
                foreach (var kvp in _connections)
                {
                    var info = kvp.Value.ClientInfo;
                    if (info != null &&
                        string.Equals(info.StationName, oldName, StringComparison.OrdinalIgnoreCase))
                    {
                        info.StationName = newName;
                    }
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "RenameStation error: " + ex.Message); }
        }

        // === Phase 12: Quick Time + Sound + Bulk Operations ===

        public void SetSessionTime(string stationName, int action, int minutes, string reason = "")
        {
            try { ActivityJournal.Record(ActivityJournal.TimeCredit, (action == 0 ? "تنظیم زمان روی " + minutes + " دقیقه" : action == 1 ? "افزودن " + minutes + " دقیقه" : action == 2 ? "زمان نامحدود" : action == 3 ? "پایان نشست" : "تغییر زمان") + (string.IsNullOrEmpty(reason) ? "" : " — " + reason), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Network", "SetSessionTime: station not found: " + stationName); return; }
            // FIX L14: track the per-station time cap so the live sidebar can
            // show a real remaining time. Action codes per SetSessionTimePayload:
            //   0=SetTime    → replace the cap with the new value
            //   1=AddTime    → add to the existing cap (capped to >= 0)
            //   2=Unlimited  → clear the cap (TimeCapMinutes = 0)
            //   3=EndNow     → cap is irrelevant (session ending), set to 0
            if (conn.ClientInfo != null)
            {
                try
                {
                    switch (action)
                    {
                        case 0: conn.ClientInfo.TimeCapMinutes = Math.Max(0, minutes); break;
                        case 1: conn.ClientInfo.TimeCapMinutes = Math.Max(0, conn.ClientInfo.TimeCapMinutes + minutes); break;
                        case 2: conn.ClientInfo.TimeCapMinutes = 0; break;
                        case 3: conn.ClientInfo.TimeCapMinutes = 0; break;
                    }
                }
                catch (Exception ex) { AuditLog.Log("Network", "SetSessionTime cap update error: " + ex.Message); }
            }
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerSetSessionTime,
                new SetSessionTimePayload { StationName = stationName, Username = conn.CurrentUser ?? "", Action = action, Minutes = minutes, Amount = 0, Reason = reason ?? "" }));
            AuditLog.Log("Network", $"SetSessionTime: {stationName} action={action} min={minutes} reason={reason}");
        }

        public void MuteClient(string stationName, bool mute)
        {
            try { ActivityJournal.Record(ActivityJournal.Command, (mute ? "قطع صدا" : "وصل صدا"), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) return;
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerMuteClient,
                new MuteClientPayload { StationName = stationName, Mute = mute }));
            AuditLog.Log("Network", $"MuteClient: {stationName} mute={mute}");
        }

        public void ShutdownAll() { foreach (var c in GetAllRawConnections()) try { ShutdownStation(c.StationName); } catch { } AuditLog.Log("Network", "Bulk: ShutdownAll"); }
        public void RestartAll() { foreach (var c in GetAllRawConnections()) try { RestartStation(c.StationName); } catch { } AuditLog.Log("Network", "Bulk: RestartAll"); }
        // FIX LOCK-REMOVE: LockAll removed per user request.
        public void UnlockAll() { foreach (var c in GetAllRawConnections()) try { UnlockStation(c.StationName); } catch { } AuditLog.Log("Network", "Bulk: UnlockAll"); }

        // USB control
        public void ControlUsb(string stationName, bool enable)
        {
            try { ActivityJournal.Record(ActivityJournal.Command, (enable ? "USB روشن" : "USB خاموش"), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) return;
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerUsbControl,
                new UsbControlPayload { StationName = stationName, Enable = enable }));
            AuditLog.Log("Network", $"USB control: {stationName} enable={enable}");
        }

        // Internet control
        public void ControlInternet(string stationName, bool enable)
        {
            try { ActivityJournal.Record(ActivityJournal.Command, (enable ? "اینترنت وصل" : "اینترنت قطع"), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) return;
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerInternetControl,
                new InternetControlPayload { StationName = stationName, Enable = enable }));
            AuditLog.Log("Network", $"Internet control: {stationName} enable={enable}");
        }

        // Remote Desktop — launch mstsc.exe to the client's IP
        public void RemoteDesktop(string stationName)
        {
            try { ActivityJournal.Record(ActivityJournal.Remote, "ریموت دسکتاپ ویندوز", stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Network", "RDP: station not found: " + stationName); return; }
            string ip = conn.ClientInfo?.ClientIp ?? "";
            if (string.IsNullOrEmpty(ip)) { AuditLog.Log("Network", "RDP: no IP for " + stationName); return; }
            try
            {
                System.Diagnostics.Process.Start("mstsc.exe", $"/v:{ip}");
                AuditLog.Log("Network", $"RDP launched to {stationName} ({ip})");
            }
            catch (Exception ex) { AuditLog.Log("Network", "RDP error: " + ex.Message); }
        }

        // NEW FEATURE (remote input, per request): forwards one mouse or
        // keyboard event to the named station for injection. This is the
        // real, built-in alternative to RemoteDesktop() above — that method
        // only launches Windows' own mstsc.exe (which requires the client
        // to be running Windows Pro/Enterprise to even accept an incoming
        // RDP session; Home editions silently can't). This path works over
        // the same TCP connection already used for everything else, with
        // no OS-edition dependency.
        public void SendRemoteInput(string stationName, string inputType, double normX, double normY, string button = null, int wheelDelta = 0, int keyCode = 0)
        {
            var conn = FindConnectionByStation(stationName);
            if (conn == null) return; // silent — this fires on every mouse move, too frequent to log
            var payload = new RemoteInputPayload
            {
                StationName = stationName,
                InputType = inputType,
                NormX = normX,
                NormY = normY,
                Button = button,
                WheelDelta = wheelDelta,
                KeyCode = keyCode,
            };
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerRemoteInput, payload));
        }

        // NEW FEATURE (real video+audio codec, per request). Tracks the
        // ffplay process per station so StopVideoStream can kill the right
        // one, and so a form closing early cleans up rather than leaving an
        // orphaned ffplay window.
        private static readonly ConcurrentDictionary<string, System.Diagnostics.Process> _ffplayProcesses = new ConcurrentDictionary<string, System.Diagnostics.Process>();

        public event Action<string, VideoStreamStatusPayload> OnVideoStreamStatus;

        /// <summary>
        /// Starts real H.264 video + AAC audio streaming from the named
        /// station: launches ffplay locally (listening on a free port),
        /// then tells the client to launch ffmpeg pointed at that port.
        /// Requires ffplay.exe (bundled with any FFmpeg install) to be on
        /// PATH or next to this server's .exe — see the chat message
        /// alongside this feature for why it can't be bundled automatically.
        /// </summary>
        public void StartVideoStream(string stationName, int frameRate, int scalePercent, int videoBitrateKbps, int audioBitrateKbps, bool includeAudio)
        {
            var conn = FindConnectionByStation(stationName);
            if (conn == null)
            {
                OnVideoStreamStatus?.Invoke(stationName, new VideoStreamStatusPayload { StationName = stationName, Started = false, Error = "ایستگاه یافت نشد." });
                return;
            }

            int port;
            try { port = FindFreeTcpPort(); }
            catch (Exception ex)
            {
                OnVideoStreamStatus?.Invoke(stationName, new VideoStreamStatusPayload { StationName = stationName, Started = false, Error = "یافتن پورت آزاد ناموفق: " + ex.Message });
                return;
            }

            try
            {
                // ffplay listens for ONE incoming connection and plays
                // whatever it receives, then exits when that connection
                // closes (-autoexit). "-loglevel error" keeps its own
                // console quiet; ffplay always opens its own window for
                // video+audio playback — there is no need (and no reliable
                // way without a bundled decoder) to embed this inside our
                // own WinForms window.
                string ffplayArgs = $"-loglevel error -infbuf -fflags nobuffer -flags low_delay -f mpegts -i tcp://0.0.0.0:{port}?listen -autoexit -window_title \"مانیتورینگ زنده: {stationName}\"";
                var psi = new System.Diagnostics.ProcessStartInfo("ffplay.exe", ffplayArgs)
                {
                    UseShellExecute = false,
                    CreateNoWindow = false,
                };
                var proc = System.Diagnostics.Process.Start(psi);
                if (proc == null) throw new Exception("پردازش ffplay اجرا نشد.");
                _ffplayProcesses[stationName] = proc;
                proc.EnableRaisingEvents = true;
                proc.Exited += (s, e) => { _ffplayProcesses.TryRemove(stationName, out _); };
            }
            catch (Exception ex)
            {
                // Most common cause: ffplay.exe not installed / not on PATH.
                OnVideoStreamStatus?.Invoke(stationName, new VideoStreamStatusPayload
                {
                    StationName = stationName,
                    Started = false,
                    Error = "اجرای ffplay ناموفق بود — مطمئن شوید FFmpeg نصب و به PATH اضافه شده: " + ex.Message
                });
                return;
            }

            // Round 11: the address of the network card this station already reaches the
            // server on (GetLocalIPv4 picks the first card, wrong on a multi-card server).
            string serverIp = LocalIpFor(conn) ?? GetLocalIPv4();
            var payload = new StartVideoStreamPayload
            {
                StationName = stationName,
                ServerIp = serverIp,
                Port = port,
                FrameRate = frameRate,
                ScalePercent = scalePercent,
                VideoBitrateKbps = videoBitrateKbps,
                AudioBitrateKbps = audioBitrateKbps,
                IncludeAudio = includeAudio,
            };
            AuditLog.Log("Network", $"Video stream requested for {stationName} -> {serverIp}:{port}");
            try { ActivityJournal.Record(ActivityJournal.Remote, "پخش زنده ویدیو + صدا", stationName); } catch { } // round 14
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerStartVideoStream, payload));
        }

        public void StopVideoStream(string stationName)
        {
            var conn = FindConnectionByStation(stationName);
            if (conn != null)
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerStopVideoStream, new StopVideoStreamPayload { StationName = stationName }));

            if (_ffplayProcesses.TryRemove(stationName, out var proc))
            {
                try { if (!proc.HasExited) proc.Kill(); } catch { }
                try { proc.Dispose(); } catch { }
            }
        }

        /// <summary>
        /// Round 11: live view with mouse and keyboard control. Same kiosk-side stream as
        /// StartVideoStream (H.264 from the kiosk's ffmpeg over its own TCP connection),
        /// but received by ffmpeg on the server and turned into JPEG frames on its
        /// standard output, so the picture is shown inside our own window, where the
        /// operator's mouse and keyboard are forwarded (ServerRemoteInput). The frames do
        /// not travel on the control connection, so they do not count against the
        /// 30-messages-per-minute rate limit (screenshot polling did, and blocked the
        /// station for 15 minutes). Returns the decoder process, or null with
        /// <paramref name="error"/> set. Requires ffmpeg.exe on the server's PATH.
        /// </summary>
        public System.Diagnostics.Process StartLiveView(string stationName, int frameRate, int scalePercent, int videoBitrateKbps, out string error)
        {
            error = null;
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { error = "ایستگاه یافت نشد."; return null; }

            int port;
            try { port = FindFreeTcpPort(); }
            catch (Exception ex) { error = "یافتن پورت آزاد ناموفق: " + ex.Message; return null; }

            System.Diagnostics.Process proc;
            try
            {
                // Round 13: at 50-60 fps the JPEG quality step is a little lower (5) so the
                // server keeps up; two decoder threads.
                int q = frameRate >= 50 ? 5 : 3;
                string args = $"-loglevel error -fflags nobuffer -flags low_delay -probesize 100000 -analyzeduration 200000 -threads 2 " +
                              $"-f mpegts -i tcp://0.0.0.0:{port}?listen -an -f image2pipe -c:v mjpeg -q:v {q} -";
                var psi = new System.Diagnostics.ProcessStartInfo("ffmpeg.exe", args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };
                proc = System.Diagnostics.Process.Start(psi);
                if (proc == null) throw new Exception("پردازش ffmpeg اجرا نشد.");
            }
            catch (Exception ex)
            {
                error = "اجرای ffmpeg روی سرور ناموفق بود — FFmpeg را نصب و به PATH ویندوز اضافه کنید: " + ex.Message;
                return null;
            }

            string serverIp = LocalIpFor(conn) ?? GetLocalIPv4();
            var payload = new StartVideoStreamPayload
            {
                StationName = stationName,
                ServerIp = serverIp,
                Port = port,
                FrameRate = frameRate,
                ScalePercent = scalePercent,
                VideoBitrateKbps = videoBitrateKbps,
                AudioBitrateKbps = 0,
                IncludeAudio = false,
            };
            AuditLog.Log("Network", $"Live control view requested for {stationName} -> {serverIp}:{port}");
            try { ActivityJournal.Record(ActivityJournal.Remote, "مانیتورینگ زنده (" + frameRate + " فریم)", stationName); } catch { } // round 14
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerStartVideoStream, payload));
            return proc;
        }

        /// <summary>Round 11: stops the kiosk's stream and the server-side decoder.</summary>
        public void StopLiveView(string stationName, System.Diagnostics.Process decoder)
        {
            try
            {
                var conn = FindConnectionByStation(stationName);
                if (conn != null)
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerStopVideoStream, new StopVideoStreamPayload { StationName = stationName }));
            }
            catch { }
            if (decoder != null)
            {
                try { if (!decoder.HasExited) decoder.Kill(); } catch { }
                try { decoder.Dispose(); } catch { }
            }
        }

        private static string LocalIpFor(ClientConnection conn)
        {
            try
            {
                var ep = conn?.TcpClient?.Client?.LocalEndPoint as IPEndPoint;
                if (ep == null) return null;
                var a = ep.Address;
                if (a.IsIPv4MappedToIPv6) a = a.MapToIPv4();
                if (a.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return null;
                if (IPAddress.IsLoopback(a) || a.Equals(IPAddress.Any)) return null;
                return a.ToString();
            }
            catch { return null; }
        }

        /// <summary>Called by the message dispatcher when a ClientVideoStreamStatus arrives.</summary>
        internal void RaiseVideoStreamStatus(string stationName, VideoStreamStatusPayload payload)
        {
            OnVideoStreamStatus?.Invoke(stationName, payload);
        }

        private static int FindFreeTcpPort()
        {
            var l = new TcpListener(IPAddress.Loopback, 0);
            l.Start();
            int port = ((IPEndPoint)l.LocalEndpoint).Port;
            l.Stop();
            return port;
        }

        private static string GetLocalIPv4()
        {
            try
            {
                foreach (var ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        return ip.ToString();
            }
            catch { }
            return "127.0.0.1";
        }

        // Sends the legacy close-game command. The kiosk client no longer acts on it.
        public void CloseGame(string stationName, bool force = true)
        {
            try { ActivityJournal.Record(ActivityJournal.Command, (force ? "بستن اجباری بازی" : "بستن بازی"), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Network", "CloseGame: station not found: " + stationName); return; }
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerCloseGame, new GameClosePayload { StationName = stationName, Force = force }));
            AuditLog.Log("Network", $"CloseGame sent to {stationName} (force={force})");
        }

        // Wake All (WOL) — send magic packet to all registered station MACs
        public void WakeAll()
        {
            try { ActivityJournal.Record(ActivityJournal.Command, "روشن کردن همهٔ سیستم‌ها (Wake on LAN)", null); } catch { } // round 14
            try
            {
                var stations = Database.Instance.Query("SELECT name, mac_address FROM stations WHERE mac_address IS NOT NULL AND mac_address != ''", null,
                    r => (Name: r.GetString(0), Mac: r.GetString(1)));
                foreach (var s in stations)
                {
                    try { WakeOnLan.SendMagicPacket(s.Mac); } catch { }
                }
                AuditLog.Log("Network", $"WakeAll: sent to {stations.Count} stations");
            }
            catch (Exception ex) { AuditLog.Log("Network", "WakeAll error: " + ex.Message); }
        }

        // === Phase 10: Auto-update + File Transfer + Crash Report ===

        private readonly UpdateDistributor _updateDistributor = new UpdateDistributor();

        /// <summary>Event raised when a client reports its update progress.</summary>
        public event Action<string, int, string> OnClientUpdateProgress;
        /// <summary>Event raised when a client finishes (or fails) an update.</summary>
        public event Action<string, bool, string> OnClientUpdateComplete;
        /// <summary>Event raised when a crash report arrives.</summary>
        public event Action<string, CrashReportPayload> OnCrashReport;
        /// <summary>Event raised when a file transfer completes.</summary>
        public event Action<string, bool, string> OnFileTransferComplete;

        /// <summary>Event raised when a client requests a quick top-up. Args: stationName, payload.</summary>
        public event Action<string, TopupRequestPayload> OnTopupRequest;

        /// <summary>
        /// Offers an update to the named station. The client will respond
        /// with ClientUpdateAccept (accept/reject). If accepted, the server
        /// then streams the file in chunks.
        /// </summary>
        public void OfferUpdate(string stationName)
        {
            var offer = _updateDistributor.GetLatestUpdate();
            if (offer == null) { AuditLog.Log("Update", $"No update available for {stationName}"); return; }
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Update", $"Station {stationName} not connected"); return; }
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerUpdateOffer, offer));
            AuditLog.Log("Update", $"Offered v{offer.Version} to {stationName} ({offer.FileSize} bytes)");
        }

        /// <summary>Offers an update to ALL connected stations.</summary>
        public void OfferUpdateToAll()
        {
            foreach (var kvp in _connections)
            {
                try { OfferUpdate(kvp.Value.ClientInfo?.StationName ?? ""); } catch { }
            }
        }

        /// <summary>
        /// Sends an arbitrary file to a station. The client writes it to
        /// TargetPath (must be under an allowed root). Returns true if the
        /// offer was sent.
        /// </summary>
        public bool SendFileToStation(string stationName, string localFilePath, string targetPath, string description = "")
        {
            var conn = FindConnectionByStation(stationName);
            if (conn == null) return false;
            if (!System.IO.File.Exists(localFilePath)) return false;

            var offer = new FileTransferOfferPayload
            {
                StationName = stationName,
                Filename = System.IO.Path.GetFileName(localFilePath),
                FileSize = new System.IO.FileInfo(localFilePath).Length,
                Sha256 = ComputeSha256(localFilePath),
                TargetPath = targetPath,
                Description = description
            };
            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerFileTransferOffer, offer));
            // Cache the local path so HandleFileTransferAccept can stream it
            _pendingFileTransfers[conn.SessionId] = localFilePath;
            AuditLog.Log("FileTransfer", $"Offered '{offer.Filename}' ({offer.FileSize} bytes) to {stationName}");
            return true;
        }

        private void HandleUpdateAccept(ClientConnection conn, NetMessage msg)
        {
            var accept = msg.GetPayload<UpdateAcceptPayload>();
            if (accept == null) return;
            if (!accept.Accept)
            {
                AuditLog.Log("Update", $"{conn.ClientInfo?.StationName} rejected the update");
                return;
            }
            // Stream the file
            string path = _updateDistributor.GetLatestUpdatePath();
            if (path == null) { AuditLog.Log("Update", "No update file to stream"); return; }
            AuditLog.Log("Update", $"Streaming update to {conn.ClientInfo?.StationName}...");
            try
            {
                _updateDistributor.StreamFile(path, m => SendToClient(conn.SessionId, m));
                AuditLog.Log("Update", $"Update streamed to {conn.ClientInfo?.StationName}");
            }
            catch (Exception ex) { AuditLog.Log("Update", "Stream error: " + ex.Message); }
        }

        private void HandleUpdateProgress(ClientConnection conn, NetMessage msg)
        {
            var p = msg.GetPayload<UpdateProgressPayload>();
            if (p == null) return;
            try { SafeInvoke(OnClientUpdateProgress, p.StationName, p.Percent, p.Status, "OnClientUpdateProgress"); } catch { }
        }

        private void HandleUpdateComplete(ClientConnection conn, NetMessage msg)
        {
            var c = msg.GetPayload<UpdateCompletePayload>();
            if (c == null) return;
            AuditLog.Log("Update", $"{c.StationName} update complete: success={c.Success}, version={c.InstalledVersion}, err={c.Error}");
            try { SafeInvoke(OnClientUpdateComplete, c.StationName, c.Success, c.Error, "OnClientUpdateComplete"); } catch { }
        }

        private void HandleCrashReport(ClientConnection conn, NetMessage msg)
        {
            var report = msg.GetPayload<CrashReportPayload>();
            if (report == null) return;
            // Round 14: the kiosk reports its own local events (admin mode, settings changed
            // on the kiosk) through this existing message with ExceptionType "Event:<kind>".
            // They go to the activity journal only, not to the crash table.
            string rtype = report.ExceptionType ?? "";
            string rstation = conn.ClientInfo?.StationName ?? report.StationName ?? "";
            if (rtype.StartsWith("Event:", StringComparison.Ordinal))
            {
                string k = rtype.Substring(6) == "settings" ? ActivityJournal.KioskSettings : ActivityJournal.Station;
                string when = report.CrashedAt == default(DateTime) ? "" : " (روی کیوسک: " + report.CrashedAt.ToLocalTime().ToString("MM/dd HH:mm") + ")";
                try { ActivityJournal.Record(k, (report.ExceptionMessage ?? "") + when, rstation); } catch { }
                return;
            }
            try
            {
                ActivityJournal.Record(ActivityJournal.Repair,
                    rtype == "GuardRestart:HEAL-002" ? "هنگ کرد و خودکار دوباره باز شد" :
                    rtype == "GuardRestart:HEAL-003" ? "پشت سر هم بسته شد؛ تنظیمات سالم برگردانده شد" :
                    rtype.StartsWith("GuardRestart:", StringComparison.Ordinal) ? "بسته شده بود و خودکار دوباره باز شد" :
                    "خطای برنامهٔ کیوسک: " + rtype + " — " + (report.ExceptionMessage ?? ""), rstation);
            }
            catch { } // round 14
            try
            {
                // Persist to DB
                Database.Instance.Execute(
                    "INSERT INTO client_crash_reports (station_name, machine_fingerprint, client_version, exception_type, exception_message, stack_trace, last_action, crashed_at, received_at) " +
                    "VALUES (@s, @f, @v, @t, @m, @st, @la, @c, @r)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@s", report.StationName ?? "");
                        cmd.Parameters.AddWithValue("@f", report.MachineFingerprint ?? "");
                        cmd.Parameters.AddWithValue("@v", report.ClientVersion ?? "");
                        cmd.Parameters.AddWithValue("@t", report.ExceptionType ?? "");
                        cmd.Parameters.AddWithValue("@m", report.ExceptionMessage ?? "");
                        cmd.Parameters.AddWithValue("@st", report.StackTrace ?? "");
                        cmd.Parameters.AddWithValue("@la", report.LastAction ?? "");
                        cmd.Parameters.AddWithValue("@c", report.CrashedAt.ToString("o"));
                        cmd.Parameters.AddWithValue("@r", DateTime.UtcNow.ToString("o"));
                    });
                AuditLog.Log("CrashReport", $"From {report.StationName}: {report.ExceptionType} - {report.ExceptionMessage}");
                try { SafeInvoke(OnCrashReport, report.StationName, report, "OnCrashReport"); } catch { }
                try { IntrusionDetectionSystem.RecordSensitiveAction("CrashReport", report.StationName, report.ExceptionType + ": " + report.ExceptionMessage); } catch { }
            }
            catch (Exception ex) { AuditLog.Log("CrashReport", "Persist error: " + ex.Message); }
        }

        /// <summary>
        /// Phase 11 — Handles a quick top-up request from a client. Stores
        /// it in the topup_requests table and raises OnTopupRequest so the
        /// UI can show a notification.
        /// </summary>
        private void HandleTopupRequest(ClientConnection conn, NetMessage msg)
        {
            var req = msg.GetPayload<TopupRequestPayload>();
            if (req == null) return;
            try
            {
                string station = conn.ClientInfo?.StationName ?? req.StationName ?? "";
                AuditLog.Log("Topup", $"Top-up request from {req.Username} on {station}: {req.Amount:N0} Toman ({req.PaymentMethod})");

                Database.Instance.Execute(
                    "INSERT INTO topup_requests (username, station_name, amount, payment_method, status, notes, requested_at) " +
                    "VALUES (@u, @s, @a, @pm, 'pending', @n, @r)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", req.Username ?? "");
                        cmd.Parameters.AddWithValue("@s", station);
                        cmd.Parameters.AddWithValue("@a", req.Amount);
                        cmd.Parameters.AddWithValue("@pm", req.PaymentMethod ?? "cash");
                        cmd.Parameters.AddWithValue("@n", req.Notes ?? "");
                        cmd.Parameters.AddWithValue("@r", DateTime.UtcNow.ToString("o"));
                    });

                try { SafeInvoke(OnTopupRequest, station, req, "OnTopupRequest"); } catch { }
            }
            catch (Exception ex) { AuditLog.Log("Topup", "HandleTopupRequest error: " + ex.Message); }
        }

        /// <summary>
        /// Sends a top-up response to a client (approved/denied). If
        /// approved, also adds credit to the user's balance.
        /// </summary>
        public void RespondToTopup(string stationName, string username, bool approved, decimal amount, string message = "")
        {
            try { ActivityJournal.Record(ActivityJournal.TimeCredit, (approved ? "شارژ " : "رد شارژ ") + amount.ToString("N0") + " تومان برای «" + username + "»" + (string.IsNullOrEmpty(message) ? "" : " — " + message), stationName); } catch { } // round 14
            var conn = FindConnectionByStation(stationName);
            if (conn == null) { AuditLog.Log("Topup", "RespondToTopup: station not connected: " + stationName); return; }

            if (approved && !string.IsNullOrEmpty(username) && amount > 0)
            {
                try { new UserManager().AddCredit(username, amount); }
                catch (Exception ex) { AuditLog.Log("Topup", "AddCredit error: " + ex.Message); }
            }

            try
            {
                Database.Instance.Execute(
                    "UPDATE topup_requests SET status = @st, responded_at = @r, response_message = @m WHERE username = @u AND status = 'pending' ORDER BY id DESC LIMIT 1",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@st", approved ? "approved" : "denied");
                        cmd.Parameters.AddWithValue("@r", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@m", message ?? "");
                        cmd.Parameters.AddWithValue("@u", username ?? "");
                    });
            }
            catch { }

            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTopupResponse,
                new TopupResponsePayload
                {
                    Username = username,
                    Approved = approved,
                    Amount = amount,
                    Message = message ?? (approved ? "درخواست شارژ تأیید شد" : "درخواست شارژ رد شد"),
                    ApprovedBy = "operator",
                    RespondedAt = DateTime.UtcNow
                }));
            AuditLog.Log("Topup", $"Top-up response to {username} on {stationName}: {(approved ? "approved" : "denied")} ({amount:N0})");
        }

        private void HandleFileTransferAccept(ClientConnection conn, NetMessage msg)
        {
            var accept = msg.GetPayload<FileTransferAcceptPayload>();
            if (accept == null) return;
            if (!accept.Accept)
            {
                AuditLog.Log("FileTransfer", $"{conn.ClientInfo?.StationName} rejected the file transfer");
                _pendingFileTransfers.TryRemove(conn.SessionId, out _);
                return;
            }
            if (_pendingFileTransfers.TryGetValue(conn.SessionId, out string path))
            {
                try
                {
                    _updateDistributor.StreamFileTransfer(path, m => SendToClient(conn.SessionId, m));
                    AuditLog.Log("FileTransfer", $"File streamed to {conn.ClientInfo?.StationName}");
                }
                catch (Exception ex) { AuditLog.Log("FileTransfer", "Stream error: " + ex.Message); }
            }
        }

        private void HandleFileTransferComplete(ClientConnection conn, NetMessage msg)
        {
            var c = msg.GetPayload<FileTransferCompletePayload>();
            if (c == null) return;
            AuditLog.Log("FileTransfer", $"{c.StationName} transfer complete: success={c.Success}, file={c.Filename}, err={c.Error}");
            _pendingFileTransfers.TryRemove(conn.SessionId, out _);
            try { SafeInvoke(OnFileTransferComplete, c.StationName, c.Success, c.Filename, "OnFileTransferComplete"); } catch { }
        }

        private readonly ConcurrentDictionary<string, string> _pendingFileTransfers = new ConcurrentDictionary<string, string>();

        private static string ComputeSha256(string path)
        {
            try
            {
                using (var sha = System.Security.Cryptography.SHA256.Create())
                using (var fs = System.IO.File.OpenRead(path))
                {
                    byte[] hash = sha.ComputeHash(fs);
                    var sb = new System.Text.StringBuilder(hash.Length * 2);
                    foreach (byte b in hash) sb.Append(b.ToString("x2"));
                    return sb.ToString();
                }
            }
            catch { return ""; }
        }

        // === Phase 4: Security Handlers ===
        // 2FA verification is ONLY accepted from a connection that is in a
        // "pending 2FA" state — i.e. password was already verified by
        // HandleLogin but login was held pending TOTP. This prevents an
        // attacker from submitting a TOTP guess on a connection that never
        // proved it knew the password.
        private void Handle2FAVerify(ClientConnection conn, NetMessage msg)
        {
            var payload = msg.GetPayload<TwoFactorVerifyPayload>();
            if (payload == null) return;

            if (string.IsNullOrEmpty(conn.PendingTwoFactorUsername))
            {
                SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = false, Message = "احراز هویت دو مرحله‌ای درخواست نشده است — ابتدا وارد شوید" }));
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Security, "2FAVerifyRejected", "No pending 2FA for connection", EnhancedAuditLog.AuditLevel.Warning, clientIp: conn.ClientInfo?.ClientIp ?? "");
                return;
            }

            string username = conn.PendingTwoFactorUsername;

            // Per-account lockout (5 failures / 5 min)
            if (_2faLockouts.TryGetValue(username, out var info))
            {
                lock (info)
                {
                    if (info.LockedUntil.HasValue && info.LockedUntil.Value > DateTime.UtcNow)
                    {
                        SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = false, Message = "تعداد تلاش‌های ناموفق زیاد است. بعداً دوباره تلاش کنید" }));
                        EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Security, "2FALockedOut", $"User: {username}", EnhancedAuditLog.AuditLevel.Warning, clientIp: conn.ClientInfo?.ClientIp ?? "");
                        return;
                    }
                }
            }

            try
            {
                var _2fa = new TwoFactorAuth();
                var secret = Database.Instance.QueryOne("SELECT two_factor_secret FROM operators WHERE username = @u AND two_factor_enabled = 1",
                    cmd => cmd.Parameters.AddWithValue("@u", username), r => r.GetString(0));
                if (string.IsNullOrEmpty(secret))
                {
                    SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = false, Message = "احراز هویت دو مرحله‌ای فعال نیست" }));
                    return;
                }
                bool valid = _2fa.ValidateCode(secret, payload.Code);
                if (valid)
                {
                    // Clear lockout + pending state, then complete the held login.
                    _2faLockouts.TryRemove(username, out _);
                    conn.PendingTwoFactorUsername = null;
                    SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = true, Message = "تأیید شد" }));
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Security, "2FAVerifyOk", $"User: {username}", EnhancedAuditLog.AuditLevel.Info, clientIp: conn.ClientInfo?.ClientIp ?? "");
                    CompleteLogin(conn, username);
                }
                else
                {
                    var lockout = _2faLockouts.GetOrAdd(username, _ => new TwoFactorLockoutInfo());
                    lock (lockout)
                    {
                        if (DateTime.UtcNow - lockout.FirstFailureAt > TimeSpan.FromMinutes(5))
                        {
                            lockout.Failures = 0;
                            lockout.FirstFailureAt = DateTime.UtcNow;
                        }
                        lockout.Failures++;
                        if (lockout.Failures >= 5) lockout.LockedUntil = DateTime.UtcNow.AddMinutes(5);
                    }
                    SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = false, Message = "کد نامعتبر" }));
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Security, "2FAVerifyFail", $"User: {username}, Failures: {lockout.Failures}", EnhancedAuditLog.AuditLevel.Warning, clientIp: conn.ClientInfo?.ClientIp ?? "");
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "Error in Handle2FAVerify: " + ex.Message);
                SendToClient(conn.SessionId, new NetMessage(MessageType.Server2FAResult, new TwoFactorResultPayload { Success = false, Message = "خطای داخلی" }));
            }
        }

        // === Phase 5: UX Handlers ===
        private void HandleThemeRequest(ClientConnection conn)
        {
            try
            {
                var theme = new ThemeBuilder().GetCurrentTheme();
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerThemeData, new ThemeDataPayload { ThemeName = theme.Name, BackgroundColor = $"#{theme.Background.R:X2}{theme.Background.G:X2}{theme.Background.B:X2}", PrimaryColor = $"#{theme.Primary.R:X2}{theme.Primary.G:X2}{theme.Primary.B:X2}", TextColor = $"#{theme.Text.R:X2}{theme.Text.G:X2}{theme.Text.B:X2}", AccentColor = $"#{theme.Accent.R:X2}{theme.Accent.G:X2}{theme.Accent.B:X2}", FontFamily = theme.FontFamily, BaseFontSize = theme.BaseFontSize }));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleThemeRequest: " + ex.Message); }
        }

        private void HandleLangChange(ClientConnection conn, NetMessage msg) { /* Language changes are client-side only */ }

        // === Phase 6: Intelligence Handlers ===
        private void HandleSmartPriceRequest(ClientConnection conn)
        {
            try
            {
                var basePrice = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1", null, r => r.GetDecimal(0));
                var effective = new SmartPricing().CalculateEffectivePrice(conn.CurrentUser ?? "", conn.ClientInfo?.StationName ?? "", basePrice);
                var traffic = new SmartPricing().GetCurrentTrafficLevel();
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerSmartPriceInfo, new SmartPricePayload { BasePrice = basePrice, EffectivePrice = effective, TrafficLevel = traffic, AppliedDiscounts = new List<AppliedDiscount>() }));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleSmartPriceRequest: " + ex.Message); }
        }

        private void HandleAutoRechargeConfig(ClientConnection conn, NetMessage msg)
        {
            var config = msg.GetPayload<AutoRechargeConfigPayload>();
            if (config == null) return;
            try
            {
                if (config.Enabled)
                    new AutoRecharge().SetAutoRecharge(conn.CurrentUser ?? "", config.ThresholdAmount, config.RechargeAmount);
                else
                    new AutoRecharge().DisableAutoRecharge(conn.CurrentUser ?? "");
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAutoRechargeResult, new AutoRechargeResultPayload { Success = true, Message = config.Enabled ? "شارژ خودکار فعال شد" : "شارژ خودکار غیرفعال شد" }));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleAutoRechargeConfig: " + ex.Message); SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAutoRechargeResult, new AutoRechargeResultPayload { Success = false, Message = ex.Message })); }
        }

        private void HandleGameDetection(ClientConnection conn, NetMessage msg)
        {
            var detection = msg.GetPayload<GameDetectionPayload>();
            if (detection == null) return;
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Session, "GameDetection", $"Station: {detection.StationName}, Games: {detection.RunningGames?.Count ?? 0}");
        }

        // === Phase 7: Payment Handler ===
        private void HandlePaymentRequest(ClientConnection conn, NetMessage msg)
        {
            var req = msg.GetPayload<PaymentRequestPayload>();
            if (req == null) return;
            try
            {
                var merchantId = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_merchant'", null, r => r.GetString(0));
                var sandbox = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_sandbox'", null, r => r.GetString(0));
                // FIX SEC-2/FUNC-1: same broken-callback problem as
                // PaymentForm — see PaymentCallbackHelper. Without this, a
                // kiosk-initiated payment could never be verified/credited
                // even though ZarinPal successfully charged the customer.
                string callbackUrl = PaymentCallbackHelper.GetCallbackUrlOrNull();
                if (callbackUrl == null)
                {
                    AuditLog.Log("Network", $"HandlePaymentRequest: REST API port is disabled — payment for {req.Username} cannot be auto-verified. Enable ApiPort in Options.");
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPaymentUrl, new PaymentUrlPayload { Success = false, Message = "درگاه پرداخت پیکربندی نشده است (پورت API غیرفعال است). با اپراتور تماس بگیرید." }));
                    return;
                }
                var gateway = new PaymentGateway(merchantId, callbackUrl: callbackUrl, sandbox: sandbox == "1");
                var result = gateway.RequestPayment(req.Username, req.Amount, req.Description);
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPaymentUrl, new PaymentUrlPayload { Success = result.Success, PaymentUrl = result.PaymentUrl ?? "", Authority = result.Authority ?? "", Message = result.Message ?? "" }));
            }
            catch (Exception ex)
            {
                AuditLog.Log("Network", "Error in HandlePaymentRequest: " + ex.Message);
                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerPaymentUrl, new PaymentUrlPayload { Success = false, Message = ex.Message }));
            }
        }

        // === Session & Billing ===
        private void EndSession(ClientConnection conn, string reason)
        {
            // FIX 13: EndSession can be called concurrently from BillingCycle
            // (timer thread) and ProcessMessage (reader thread) — without a
            // lock, both threads can pass the empty-session guard and double-
            // charge the user. Serialize on the connection's send lock and
            // re-check CurrentSessionId inside the lock.
            lock (conn.SendLock)
            {
            if (string.IsNullOrEmpty(conn.CurrentSessionId)) return; // already ended
            try
            {
                var start = Database.Instance.QueryOne("SELECT start_time FROM client_sessions WHERE session_id = @s", cmd => cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId), r => r.GetDateTime(0));
                if (start != default(DateTime))
                {
                    int mins = Math.Max(1, (int)(DateTime.UtcNow - start).TotalMinutes);
                    var pRow = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1", null, r => r.GetDecimal(0));
                    decimal pph = pRow > 0 ? pRow : 15000m;
                    decimal effectivePph = pph;
                    try { effectivePph = new SmartPricing().CalculateEffectivePrice(conn.CurrentUser ?? "", conn.ClientInfo?.StationName ?? "", pph); }
                    catch (Exception ex) { AuditLog.Log("Network", "SmartPricing error in EndSession: " + ex.Message); decimal discount = 0; try { discount = new MemberTierManager().GetUserDiscount(conn.CurrentUser ?? ""); } catch (Exception ex2) { AuditLog.Log("Network", "Tier discount error in EndSession: " + ex2.Message); } effectivePph = Math.Round(pph * (1 - discount / 100), 0); }
                    decimal cost = Math.Round(effectivePph / 60 * mins, 0);

                    // FIX 12: state = Disconnected (session ended), not Connected.
                    Database.Instance.Execute("UPDATE client_sessions SET state = @st, end_time = @et, duration_minutes = @d, total_cost = @c WHERE session_id = @s", cmd => { cmd.Parameters.AddWithValue("@st", (int)ClientState.Disconnected); cmd.Parameters.AddWithValue("@et", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@d", mins); cmd.Parameters.AddWithValue("@c", cost); cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId); });
                    if (!string.IsNullOrEmpty(conn.CurrentUser))
                    {
                        Database.Instance.Execute("UPDATE users SET balance = MAX(0, balance - @c) WHERE username = @u", cmd => { cmd.Parameters.AddWithValue("@c", cost); cmd.Parameters.AddWithValue("@u", conn.CurrentUser); });
                        try { new MemberTierManager().AddPointsForSpending(conn.CurrentUser, cost); } catch (Exception ex) { AuditLog.Log("Network", "Tier points error in EndSession: " + ex.Message); }
                        try { new LoyaltyManager().AwardPoints(conn.CurrentUser, cost); } catch (Exception ex) { AuditLog.Log("Network", "Loyalty award error: " + ex.Message); }
                        // ADD-MULTI-FEATURES Feature 3: VIP points (1 pt per 1000 Toman spent).
                        try { VipManager.AddPoints(conn.CurrentUser, cost); } catch (Exception ex) { AuditLog.Log("Network", "VIP award error: " + ex.Message); }
                    }
                    SafeInvoke(OnSessionEnded, conn.ClientInfo?.StationName ?? conn.SessionId, new ClientSession { SessionId = conn.CurrentSessionId, Username = conn.CurrentUser, DurationMinutes = mins, TotalCost = cost }, "OnSessionEnded");
                    EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Session, "SessionEnd", $"User: {conn.CurrentUser}, Duration: {mins}min, Cost: {cost:N0}", EnhancedAuditLog.AuditLevel.Info);

                    // Print session receipt
                    try
                    {
                        var balUser = new UserManager().FindByUsername(conn.CurrentUser);
                        decimal balRem = balUser != null ? balUser.Balance : 0;
                        ReceiptPrinter.PrintSessionReceipt(conn.CurrentUser, conn.ClientInfo?.StationName ?? "", DateTime.UtcNow.AddMinutes(-mins), DateTime.UtcNow, mins, cost, balRem);
                    }
                    catch { }

                    // Telegram notification
                    try { TelegramNotifier.Send($"🏁 نشست پایان یافت\n👤 {conn.CurrentUser}\n💻 {conn.ClientInfo?.StationName}\n⏱️ {mins} دقیقه\n💰 {cost:N0} ت"); } catch { }
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in EndSession: " + ex.Message); }
            if (conn.ClientInfo != null) { conn.ClientInfo.State = ClientState.Connected; conn.ClientInfo.CurrentUser = null; conn.ClientInfo.CurrentGame = null; }
            conn.CurrentSessionId = null;
            conn.CurrentUser = null;
            } // end lock(conn.SendLock)
        }

        private void BillingCycle(object state)
        {
            if (!_running) return;
            // FIX DEAD-CONFIG-2: idle-shutdown runs independently of billing
            // (it must apply even to a kiosk sitting at the login screen,
            // not just active paid sessions), so it's a separate pass over
            // _connections rather than folded into the loop below.
            try { CheckIdleShutdown(); } catch (Exception ex) { AuditLog.Log("Network", "CheckIdleShutdown error: " + ex.Message); }
            foreach (var kvp in _connections)
            {
                var conn = kvp.Value;
                if (string.IsNullOrEmpty(conn.CurrentSessionId)) continue;
                try
                {
                    var start = Database.Instance.QueryOne("SELECT start_time FROM client_sessions WHERE session_id = @s AND is_connected = 1", cmd => cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId), r => (DateTime?)r.GetDateTime(0));
                    if (start == null) continue;
                    int elapsed = (int)(DateTime.UtcNow - start.Value).TotalMinutes;
                    if (elapsed < 1) continue;
                    var pRow = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1", null, r => r.GetDecimal(0));
                    decimal pph = pRow > 0 ? pRow : 15000m;
                    decimal effectivePph = pph;
                    try { effectivePph = new SmartPricing().CalculateEffectivePrice(conn.CurrentUser ?? "", conn.ClientInfo?.StationName ?? "", pph); } catch (Exception ex) { AuditLog.Log("Network", "SmartPricing error in BillingCycle: " + ex.Message); }
                    decimal cost = Math.Round(effectivePph / 60 * elapsed, 0);
                    if (!string.IsNullOrEmpty(conn.CurrentUser))
                    {
                        var bal = Database.Instance.QueryOne("SELECT balance FROM users WHERE username = @u", cmd => cmd.Parameters.AddWithValue("@u", conn.CurrentUser), r => r.GetDecimal(0));
                        // FIX 8: end the session when balance can't cover
                        // another cycle (bal <= cost), not only when bal <= 0.
                        // The previous code let users play indefinitely once
                        // their balance was > 0 but < cost.
                        if (bal <= cost)
                        {
                            SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTimeExpired, new ServerTimeWarningPayload { MinutesRemaining = 0, Message = "اعتبار تمام شده", IsCritical = true }));
                            EndSession(conn, "Balance depleted");
                        }
                        else
                        {
                            // Plenty of credit — warn when getting close to running out.
                            int rem = Math.Max(0, (int)((bal / effectivePph) * 60) - elapsed);
                            if (rem <= 10)
                                SendToClient(conn.SessionId, new NetMessage(MessageType.ServerTimeWarning, new ServerTimeWarningPayload { MinutesRemaining = rem, Message = $"باقی‌مانده اعتبار: {rem} دقیقه", IsCritical = rem <= 5 }));
                        }
                    }
                    Database.Instance.Execute("UPDATE client_sessions SET duration_minutes = @d, total_cost = @c WHERE session_id = @s", cmd => { cmd.Parameters.AddWithValue("@d", elapsed); cmd.Parameters.AddWithValue("@c", cost); cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId); });
                    if (conn.ClientInfo != null) { conn.ClientInfo.SessionMinutesElapsed = elapsed; conn.ClientInfo.SessionCost = cost; }
                    conn.BillingErrorCount = 0; // reset on success
                }
                catch (Exception ex)
                {
                    // Issue #14: log billing errors instead of swallowing them.
                    AuditLog.Log("Network", "BillingCycle error for session " + conn.CurrentSessionId + ": " + ex.Message);
                    conn.BillingErrorCount++;
                    if (conn.BillingErrorCount >= 3)
                    {
                        EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "BillingFailureDisconnect",
                            $"Session: {conn.CurrentSessionId}, User: {conn.CurrentUser}, ConsecutiveErrors: {conn.BillingErrorCount}",
                            EnhancedAuditLog.AuditLevel.Error);
                        try { SendToClient(conn.SessionId, new NetMessage(MessageType.ServerForceLogout, new ServerMessagePayload { Title = "خطای صورت‌حساب", Body = "اتصال شما به دلیل خطای تکراری صورت‌حساب قطع شد. لطفاً با مدیر تماس بگیرید.", Level = "error" })); } catch (Exception ex2) { AuditLog.Log("Network", "Error sending billing disconnect notice: " + ex2.Message); }
                        RemoveClient(conn);
                    }
                }
            }
        }

        /// <summary>
        /// FIX DEAD-CONFIG-2: implements OptionsForm's "خاموش کردن کامپیوترها
        /// در بیکاری زمان‌بندی شده" (IdleShutdownEnabled/Minutes) and
        /// "هشدار به کاربر قبل از خاموشی" (WarnUserEnabled) checkboxes,
        /// which previously were saved to options.json and never read by
        /// anything. Runs every 30s (BillingCycle's cadence) over every
        /// connected station, using the IdleSeconds each kiosk reports in
        /// its heartbeat (see SystemMonitor.GetIdleSeconds).
        /// </summary>
        private void CheckIdleShutdown()
        {
            Forms.OptionsForm.OptionsData opts;
            try { opts = Forms.OptionsForm.LoadStaticOptions(); } catch { return; }
            if (opts == null || !opts.IdleShutdownEnabled) return;
            int minutes = opts.IdleShutdownMinutes > 0 ? opts.IdleShutdownMinutes : 15;
            int thresholdSec = minutes * 60;
            const int WarnBeforeSec = 60; // warn 60s before the actual shutdown

            foreach (var kvp in _connections)
            {
                var conn = kvp.Value;
                var ci = conn.ClientInfo;
                if (ci == null || string.IsNullOrEmpty(ci.StationName)) continue;
                int idle = ci.IdleSeconds;

                if (idle < Math.Max(0, thresholdSec - WarnBeforeSec))
                {
                    // Activity resumed — reset so the next idle stretch
                    // gets its own warning + shutdown.
                    conn.IdleWarningSent = false;
                    conn.IdleShutdownSent = false;
                    continue;
                }

                if (idle >= thresholdSec)
                {
                    if (!conn.IdleShutdownSent)
                    {
                        try
                        {
                            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.System, "IdleShutdown",
                                $"Station: {ci.StationName}, IdleSeconds: {idle}", EnhancedAuditLog.AuditLevel.Warning);
                            ShutdownStation(ci.StationName);
                        }
                        catch (Exception ex) { AuditLog.Log("Network", "IdleShutdown ShutdownStation failed for " + ci.StationName + ": " + ex.Message); }
                        conn.IdleShutdownSent = true;
                    }
                }
                else if (opts.WarnUserEnabled && !conn.IdleWarningSent)
                {
                    try
                    {
                        SendToClient(conn.SessionId, new NetMessage(MessageType.ServerMessage, new ServerMessagePayload
                        {
                            Title = "هشدار خاموشی به دلیل بیکاری",
                            Body = $"به دلیل عدم فعالیت، این سیستم تا {WarnBeforeSec} ثانیه دیگر خاموش می‌شود. برای لغو، کلیدی را فشار دهید یا ماوس را حرکت دهید.",
                            Level = "warning"
                        }));
                    }
                    catch (Exception ex) { AuditLog.Log("Network", "IdleShutdown warning send failed for " + ci.StationName + ": " + ex.Message); }
                    conn.IdleWarningSent = true;
                }
            }
        }

        private void CheckHeartbeats(object state)
        {
            if (!_running) return;
            var now = DateTime.UtcNow;
            foreach (var kvp in _connections)
            {
                if (now - kvp.Value.LastHeartbeat > TimeSpan.FromSeconds(90)) RemoveClient(kvp.Value);
            }
        }

        public void SendToClient(string sid, NetMessage msg)
        {
            if (!_connections.TryGetValue(sid, out var c)) return;
            try
            {
                var s = c.Stream;
                if (s == null) return;
                if (!s.CanWrite) return;
                // Per-connection send lock: Protocol.WriteMessage does two
                // separate stream.Write calls (length prefix + body) followed
                // by Flush. Without serialization, concurrent writers
                // interleave their bytes and corrupt the length-prefixed
                // framing — the #1 cause of load-induced disconnects.
                lock (c.SendLock)
                {
                    if (s.CanWrite) Protocol.WriteMessage(s, msg);
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error sending to client " + sid + ": " + ex.Message); }
        }

        public void SendToStation(string station, NetMessage msg) { foreach (var kvp in _connections) if (kvp.Value.ClientInfo?.StationName == station) { SendToClient(kvp.Key, msg); break; } }
        public void BroadcastMessage(NetMessage msg) { foreach (var kvp in _connections) SendToClient(kvp.Key, msg); }
        public void ForceLogoutStation(string station, string reason = "")
        {
            try { ActivityJournal.Record(ActivityJournal.Command, "خروج اجباری مشتری" + (string.IsNullOrEmpty(reason) ? "" : " — " + reason), station); } catch { } // round 14
            SendToStation(station, new NetMessage(MessageType.ServerForceLogout, new ServerMessagePayload { Title = "خروج اجباری", Body = reason, Level = "warning" }));
        }
        // FIX LOCK-REMOVE: LockStation removed per user request.
        // Round 14: each command is journalled with the station.
        public void UnlockStation(string station) { try { ActivityJournal.Record(ActivityJournal.Command, "باز کردن قفل / ورود ادمین", station); } catch { } SendToStation(station, new NetMessage(MessageType.ServerUnlockClient)); }
        public void ShutdownStation(string station) { try { ActivityJournal.Record(ActivityJournal.Command, "خاموش کردن سیستم", station); } catch { } SendToStation(station, new NetMessage(MessageType.ServerShutdown)); }
        public void RestartStation(string station) { try { ActivityJournal.Record(ActivityJournal.Command, "ری‌استارت سیستم", station); } catch { } SendToStation(station, new NetMessage(MessageType.ServerRestart)); }

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 2: convenience wrapper used by the REST
        /// API server to add minutes to a station's session. Action=1 means
        /// "add" in the SetSessionTimePayload contract.
        /// </summary>
        public void AddTimeToStation(string station, int minutes)
        {
            SetSessionTime(station, action: 1, minutes: minutes, reason: "REST API");
        }

        private void SendGameList(string sid)
        {
            var games = new List<GameInfo>();
            try
            {
                games.AddRange(Database.Instance.Query("SELECT id, name, executable_path, icon_path, category FROM games WHERE is_active = 1 ORDER BY name", null, r => new GameInfo { Id = r.GetInt32(0), Name = r.GetString(1), ExecutablePath = r.IsDBNull(2) ? "" : r.GetString(2), IconPath = r.IsDBNull(3) ? "" : r.GetString(3), Category = r.IsDBNull(4) ? "" : r.GetString(4) }));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in SendGameList: " + ex.Message); }
            SendToClient(sid, new NetMessage(MessageType.ServerGameList, new ServerGameListPayload { Games = games }));
        }

        private void SendPriceInfo(string sid)
        {
            var p = 15000m;
            try { var r = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1", null, r2 => r2.GetDecimal(0)); if (r > 0) p = r; }
            catch (Exception ex) { AuditLog.Log("Network", "Error in SendPriceInfo: " + ex.Message); }
            SendToClient(sid, new NetMessage(MessageType.ServerPriceInfo, new PriceInfoPayload { PricePerHour = p, Currency = "تومان", MinimumCharge = Math.Round(p / 6, 0), RoundingMinutes = 10 }));
        }

        /// <summary>
        /// FIX C2: Re-reply to a ClientSessionInfo request — re-sends the
        /// user's current balance (if logged in) and the current default price.
        /// Used by clients immediately after a successful reconnect so they
        /// can refresh their cached balance/price state.
        /// </summary>
        private void HandleSessionInfoRequest(ClientConnection conn)
        {
            try
            {
                if (conn != null && !string.IsNullOrEmpty(conn.CurrentUser))
                {
                    var user = new UserManager().FindByUsername(conn.CurrentUser);
                    decimal balance = user != null ? user.Balance : 0m;
                    SendToClient(conn.SessionId, new NetMessage(MessageType.ServerAddCredit,
                        new AddCreditPayload { Username = conn.CurrentUser, NewBalance = balance, Amount = 0, Reason = "reconnect-sync" }));
                }
                if (conn != null) SendPriceInfo(conn.SessionId);
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error in HandleSessionInfoRequest: " + ex.Message); }
        }

        // Issue #13: idempotent. TryRemove returns false if the key was
        // already removed (e.g. by HandleReconnect, Stop, or a prior
        // CheckHeartbeats), in which case we MUST NOT fire OnClientDisconnected
        // again or call Dispose a second time.
        private void RemoveClient(ClientConnection conn)
        {
            // FIX C1: Finalize any active session BEFORE removing the connection.
            // Without this, a TCP drop (heartbeat timeout, power-off, network
            // failure) leaves the session orphaned (state=InSession, end_time=NULL,
            // balance never deducted) — direct revenue loss.
            try
            {
                if (conn != null && !string.IsNullOrEmpty(conn.CurrentSessionId))
                {
                    EndSession(conn, "Disconnected");
                }
            }
            catch (Exception ex) { AuditLog.Log("Network", "RemoveClient EndSession error: " + ex.Message); }

            bool removed = _connections.TryRemove(conn.SessionId, out _);
            if (!removed) return;

            try
            {
                // Defensive: EndSession above should have already nulled CurrentSessionId,
                // but if EndSession threw before reaching the null assignment, mark
                // the session disconnected here as a fallback.
                if (!string.IsNullOrEmpty(conn.CurrentSessionId))
                    Database.Instance.Execute("UPDATE client_sessions SET is_connected = 0 WHERE session_id = @s",
                        cmd => cmd.Parameters.AddWithValue("@s", conn.CurrentSessionId));
            }
            catch (Exception ex) { AuditLog.Log("Network", "Error marking session disconnected: " + ex.Message); }

            try { lock (conn.SendLock) conn.Dispose(); }
            catch (Exception ex) { AuditLog.Log("Network", "Error disposing conn in RemoveClient: " + ex.Message); }

            // FIX AUDIT-FIX-POSTUPDATE Bug C1: OnClientDisconnected was raised
            // with conn.SessionId (a GUID like "abc123...") as the argument,
            // but every subscriber (MainForm's LiveUpdates forwarder, the
            // sidebar refresh, etc.) treats that argument as the STATION
            // NAME. The web dashboard therefore received station="<GUID>"
            // for every disconnect event. Pass the actual station name
            // (looked up from ClientInfo before it's cleared by Dispose)
            // so subscribers see "PC_1" instead of a GUID. Falls back to
            // the SessionId if ClientInfo was already nulled (defensive).
            //
            // FIX (FIX-FINAL-10 B2): the previous fallback `?? conn.SessionId`
            // returned the GUID-like session id when ClientInfo was null —
            // which happens for an OLD conn after HandleReconnect (its
            // ClientInfo was nulled at line 645). On the reconnect path
            // this is now unreachable because the B1 sentinel makes
            // RemoveClient return at the `!removed` guard above, but for
            // any OTHER path where ClientInfo is null at RemoveClient time,
            // prefer "unknown" over broadcasting a 32-char hex GUID that
            // every subscriber mistakes for a station name.
            string disconnectStationName =
                conn.ClientInfo?.StationName
                ?? (conn.SessionId != null && conn.SessionId.StartsWith("::") ? "unknown" : conn.SessionId)
                ?? "unknown";
            // Round 16: a connection that never introduced itself (failed TLS, a port test,
            // a scanner) is not a station going offline. It used to raise the event with
            // its session GUID as "station", which showed up as a "disconnected" GUID in
            // the web dashboard, in Telegram and in the activity journal.
            if (conn.ClientInfo == null) return;
            SafeInvoke(OnClientDisconnected, disconnectStationName, "OnClientDisconnected");
        }

        private string ComputeHash(string input)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input))).Replace("-", "").ToLowerInvariant();
            }
        }

        // Safe event invokers — catch handler exceptions so one bad subscriber
        // cannot crash the network / timer thread.
        private void SafeInvoke<T>(Action<T> handler, T arg, string eventName)
        {
            if (handler == null) return;
            try { handler(arg); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in " + eventName + " handler: " + ex.Message); }
        }

        private void SafeInvoke<T1, T2>(Action<T1, T2> handler, T1 arg1, T2 arg2, string eventName)
        {
            if (handler == null) return;
            try { handler(arg1, arg2); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in " + eventName + " handler: " + ex.Message); }
        }

        private void SafeInvoke<T1, T2, T3>(Action<T1, T2, T3> handler, T1 arg1, T2 arg2, T3 arg3, string eventName)
        {
            if (handler == null) return;
            try { handler(arg1, arg2, arg3); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in " + eventName + " handler: " + ex.Message); }
        }

        private void SafeInvoke<T1, T2, T3, T4>(Action<T1, T2, T3, T4> handler, T1 arg1, T2 arg2, T3 arg3, T4 arg4, string eventName)
        {
            if (handler == null) return;
            try { handler(arg1, arg2, arg3, arg4); }
            catch (Exception ex) { AuditLog.Log("Network", "Error in " + eventName + " handler: " + ex.Message); }
        }

        public void Dispose() { Stop(); }

        private class TwoFactorLockoutInfo
        {
            public int Failures;
            public DateTime FirstFailureAt = DateTime.UtcNow;
            public DateTime? LockedUntil;
        }

        private class ClientConnection : IDisposable
        {
            public string SessionId = Guid.NewGuid().ToString("N");
            public TcpClient TcpClient;
            // Stream is set once by HandleClient (after optional TLS wrap) and
            // never reassigned. SendToClient / RemoveClient read it under SendLock.
            public Stream Stream;
            public ConnectedClient ClientInfo;
            public DateTime LastHeartbeat = DateTime.UtcNow;
            public string CurrentSessionId;
            public string CurrentUser;
            // Set by HandleLogin when password was verified but TOTP is still
            // required. Handle2FAVerify checks this to refuse out-of-band 2FA.
            public string PendingTwoFactorUsername;
            // Consecutive BillingCycle failures — after 3 the client is
            // disconnected to avoid silent revenue loss.
            public int BillingErrorCount;
            // FIX DEAD-CONFIG-2: idle-shutdown state. Tracks whether the
            // warning was already sent for the current idle stretch so
            // BillingCycle (every 30s) doesn't re-send it on every tick,
            // and whether shutdown was already issued so we don't spam
            // ServerShutdown at the connection over and over.
            public bool IdleWarningSent;
            public bool IdleShutdownSent;
            // Per-connection send lock — serializes Protocol.WriteMessage calls
            // so concurrent writers cannot corrupt the length-prefixed framing.
            internal readonly object SendLock = new object();

            public ClientConnection(TcpClient tcp) { TcpClient = tcp; TcpClient.ReceiveTimeout = 90000; TcpClient.SendTimeout = 10000; }
            public void Dispose()
            {
                try { Stream?.Dispose(); } catch (Exception ex) { AuditLog.Log("Network", "Error disposing stream: " + ex.Message); }
                try { TcpClient?.Close(); } catch (Exception ex) { AuditLog.Log("Network", "Error closing TcpClient: " + ex.Message); }
            }
        }
    }
}
