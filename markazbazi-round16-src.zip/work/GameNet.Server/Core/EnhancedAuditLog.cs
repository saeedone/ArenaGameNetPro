using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public static class EnhancedAuditLog
    {
        public enum AuditLevel { Debug, Info, Warning, Error, Critical }
        public enum AuditCategory { Auth, Session, Billing, User, Operator, System, Network, Security, Chat, Print, Debt, Package, Tier, Backup, Payment, Branch, API, Config }

        public static void Log(AuditCategory category, string action, string details = "", AuditLevel level = AuditLevel.Info, string operatorName = "", string clientIp = "", string stationName = "")
        {
            try
            {
                Database.Instance.Execute(@"INSERT INTO enhanced_audit_log 
                    (category, action, details, level, operator_name, client_ip, station_name, timestamp) 
                    VALUES (@cat, @act, @det, @lvl, @op, @ip, @st, @ts)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@cat", category.ToString());
                        cmd.Parameters.AddWithValue("@act", action);
                        cmd.Parameters.AddWithValue("@det", details ?? "");
                        cmd.Parameters.AddWithValue("@lvl", level.ToString());
                        cmd.Parameters.AddWithValue("@op", operatorName ?? "");
                        cmd.Parameters.AddWithValue("@ip", clientIp ?? "");
                        cmd.Parameters.AddWithValue("@st", stationName ?? "");
                        cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.ToString("o"));
                    });
            }
            catch { AuditLog.Log(category.ToString(), $"{action}: {details}"); }
        }

        /// <summary>
        /// Queries the enhanced audit log with optional filters. All filter values are
        /// bound as parameters - the levels IN(...) list is built from one parameter per
        /// value (@lvl0, @lvl1, ...) rather than being concatenated as string literals,
        /// to prevent SQL injection through unexpected level names.
        /// </summary>
        public static List<AuditEntry> Query(AuditCategory? category = null, AuditLevel? minLevel = null, DateTime? from = null, DateTime? to = null, string operatorName = null, int limit = 100)
        {
            // Build the SQL and a parallel list of level values to bind later.
            string sql = "SELECT id, category, action, details, level, operator_name, client_ip, station_name, timestamp FROM enhanced_audit_log WHERE 1=1";
            List<string> levelsForInClause = null;

            if (category.HasValue) sql += " AND category = @cat";
            if (minLevel.HasValue)
            {
                levelsForInClause = GetLevelsAbove(minLevel.Value);
                if (levelsForInClause.Count > 0)
                {
                    var paramNames = levelsForInClause.Select((_, i) => $"@lvl{i}").ToArray();
                    sql += $" AND level IN ({string.Join(",", paramNames)})";
                }
            }
            if (from.HasValue) sql += " AND timestamp >= @from";
            if (to.HasValue) sql += " AND timestamp <= @to";
            if (!string.IsNullOrEmpty(operatorName)) sql += " AND operator_name = @op";
            sql += " ORDER BY timestamp DESC LIMIT @lim";

            return Database.Instance.Query<AuditEntry>(sql,
                cmd =>
                {
                    if (category.HasValue) cmd.Parameters.AddWithValue("@cat", category.Value.ToString());
                    if (levelsForInClause != null)
                    {
                        for (int i = 0; i < levelsForInClause.Count; i++)
                            cmd.Parameters.AddWithValue($"@lvl{i}", levelsForInClause[i]);
                    }
                    if (from.HasValue) cmd.Parameters.AddWithValue("@from", from.Value.ToString("o"));
                    if (to.HasValue) cmd.Parameters.AddWithValue("@to", to.Value.ToString("o"));
                    if (!string.IsNullOrEmpty(operatorName)) cmd.Parameters.AddWithValue("@op", operatorName);
                    cmd.Parameters.AddWithValue("@lim", limit);
                },
                r => new AuditEntry
                {
                    Id = r.GetInt32(0), Category = r.GetString(1), Action = r.GetString(2),
                    Details = r.IsDBNull(3) ? "" : r.GetString(3), Level = r.GetString(4),
                    OperatorName = r.IsDBNull(5) ? "" : r.GetString(5), ClientIp = r.IsDBNull(6) ? "" : r.GetString(6),
                    StationName = r.IsDBNull(7) ? "" : r.GetString(7), Timestamp = r.GetDateTime(8)
                });
        }

        private static List<string> GetLevelsAbove(AuditLevel level)
        {
            var levels = new List<string>();
            for (int i = (int)level; i <= (int)AuditLevel.Critical; i++)
                levels.Add(((AuditLevel)i).ToString());
            return levels;
        }

        /// <summary>
        /// Deletes audit entries older than <paramref name="daysToKeep"/> days and returns
        /// the actual number of rows deleted (uses ExecuteNonQuery which returns rows affected).
        /// </summary>
        public static int CleanupOldEntries(int daysToKeep = 90)
        {
            return Database.Instance.ExecuteNonQuery(
                "DELETE FROM enhanced_audit_log WHERE timestamp < @cutoff",
                cmd => { cmd.Parameters.AddWithValue("@cutoff", DateTime.UtcNow.AddDays(-daysToKeep).ToString("o")); });
        }
    }

    public class AuditEntry
    {
        public int Id; public string Category; public string Action; public string Details;
        public string Level; public string OperatorName; public string ClientIp;
        public string StationName; public DateTime Timestamp;
    }
}
