using System;
using System.IO;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX FEATURE-2: "بازگرداندن به حالت اولیه" (reset to defaults) —
    /// requested explicitly scoped to SETTINGS only (pricing, appearance,
    /// configuration), not customer/financial data. This did not exist
    /// anywhere in the codebase before.
    ///
    /// Resets:
    ///  - options.json (deleted — OptionsForm.LoadStaticOptions() already
    ///    returns an all-defaults OptionsData when the file is missing, so
    ///    deleting it IS the reset)
    ///  - theme.json (deleted — ThemeManager.LoadTheme() falls back to
    ///    AppTheme.Dark when missing)
    ///  - pricing table (all rows replaced with a single default plan)
    ///  - client_feature_flags table (cleared — see the FIX SEV-1 comment
    ///    in FeatureFlagManager.IsEnabled: an empty table now correctly
    ///    means "everything enabled", which is also the sensible default)
    ///
    /// Deliberately NEVER touches: users, operators, client_sessions,
    /// payment_transactions, loyalty_points/history, debts, tickets,
    /// audit_log/audit_chain, or any API/TLS credentials — those are
    /// customer/financial/security records, not "settings", and this
    /// action must never be able to destroy them.
    ///
    /// Always creates an encrypted backup first and aborts without changing
    /// anything if the backup fails, so a reset can always be undone via
    /// Restore even though it doesn't touch financial data itself.
    /// </summary>
    public static class SettingsResetManager
    {
        public class ResetResult
        {
            public bool Success;
            public string BackupPath;
            public string ErrorMessage;
        }

        public static ResetResult ResetToDefaults()
        {
            var result = new ResetResult();

            // 1. Mandatory backup first. If this fails, abort — don't touch
            // anything the operator can't get back.
            try
            {
                result.BackupPath = SecureBackupManager.CreateEncryptedBackup("Automatic backup before reset-to-defaults");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = "پشتیبان‌گیری قبل از بازنشانی ناموفق بود — چیزی تغییر نکرد: " + ex.Message;
                AuditLog.Log("SettingsReset", "Aborted — pre-reset backup failed: " + ex.Message);
                return result;
            }

            try
            {
                // 2. Config files.
                string optionsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
                string themePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme.json");
                try { if (File.Exists(optionsPath)) File.Delete(optionsPath); } catch (Exception ex) { AuditLog.Log("SettingsReset", "Could not delete options.json: " + ex.Message); }
                try { if (File.Exists(themePath)) File.Delete(themePath); } catch (Exception ex) { AuditLog.Log("SettingsReset", "Could not delete theme.json: " + ex.Message); }

                // 3. Pricing → single default plan.
                Database.Instance.Execute("DELETE FROM pricing", null);
                Database.Instance.Execute(
                    "INSERT INTO pricing (name, price_per_hour, minimum_charge, rounding_minutes, is_default, created_at) VALUES (@n, 15000, 2500, 10, 1, @c)",
                    cmd => { cmd.Parameters.AddWithValue("@n", "پیش‌فرض"); cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o")); });

                // 4. Feature flags → clear (empty table = everything enabled, see FeatureFlagManager.IsEnabled).
                Database.Instance.Execute("DELETE FROM client_feature_flags", null);

                AuditLog.Log("SettingsReset", "Settings reset to defaults. Backup: " + result.BackupPath);
                result.Success = true;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = "بازنشانی با خطا مواجه شد (بکاپ قبل از آن با موفقیت ساخته شده): " + ex.Message;
                AuditLog.Log("SettingsReset", "Partial failure during reset: " + ex.Message);
                return result;
            }
        }
    }
}
