using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class AnalyticsEntry { public string Date = ""; public int SessionCount; public decimal Revenue; public double AvgMinutes; }
    public class AnalyticsEngine {
        public List<AnalyticsEntry> GetDailyStats(int days = 30) { var list = new List<AnalyticsEntry>(); try { Database.Instance.Query("SELECT date(start_time) as d, COUNT(*) as cnt, COALESCE(SUM(total_cost),0) as rev, COALESCE(AVG(duration_minutes),0) as avg FROM client_sessions WHERE start_time >= date('now',@d) GROUP BY d ORDER BY d DESC", c => c.Parameters.AddWithValue("@d", "-" + days + " days"), r => { list.Add(new AnalyticsEntry { Date = r.GetString(0), SessionCount = r.GetInt32(1), Revenue = r.GetDecimal(2), AvgMinutes = r.IsDBNull(3) ? 0 : r.GetDouble(3) }); return true; }); } catch { } return list; }
    }
}
