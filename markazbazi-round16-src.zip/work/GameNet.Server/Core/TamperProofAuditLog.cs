using System;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 2.3 — Tamper-evident audit log using a cryptographic hash chain.
    ///
    /// Each log entry stores a `prev_hash` (the hash of the previous entry)
    /// and a `entry_hash` (SHA-256 of prev_hash + all entry fields). Deleting
    /// or modifying any entry breaks the chain — the next entry's prev_hash
    /// no longer matches the modified entry's entry_hash, and verification
    /// flags the tamper.
    ///
    /// The chain is anchored to a genesis hash stored in the settings table
    /// so an attacker cannot simply truncate the table and start a fresh
    /// chain (the genesis would mismatch).
    ///
    /// Stored in the `audit_chain` table:
    ///   id, timestamp, category, action, details, level, operator_name,
    ///   client_ip, station_name, prev_hash, entry_hash
    /// </summary>
    public static class TamperProofAuditLog
    {
        private const string GenesisSettingKey = "audit_chain_genesis";
        private static readonly object _lock = new object();

        /// <summary>
        /// Appends a tamper-evident entry to the audit chain. The entry's
        /// prev_hash is the entry_hash of the last row (or the genesis hash
        /// if the table is empty). The entry_hash is SHA-256 of
        /// (prev_hash || timestamp || category || action || details || level
        ///  || operator_name || client_ip || station_name).
        /// </summary>
        public static void Log(string category, string action, string details = "",
            string level = "Info", string operatorName = "", string clientIp = "", string stationName = "")
        {
            lock (_lock)
            {
                try
                {
                    DataEncryption.Initialize();

                    string genesis = GetOrCreateGenesis();
                    string prevHash = GetLastEntryHash() ?? genesis;
                    string timestamp = DateTime.UtcNow.ToString("o");
                    string entryHash = ComputeEntryHash(prevHash, timestamp, category, action, details, level, operatorName, clientIp, stationName);

                    Database.Instance.Execute(
                        "INSERT INTO audit_chain (timestamp, category, action, details, level, operator_name, client_ip, station_name, prev_hash, entry_hash) " +
                        "VALUES (@ts, @cat, @act, @det, @lvl, @op, @ip, @st, @ph, @eh)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@ts", timestamp);
                            cmd.Parameters.AddWithValue("@cat", category ?? "");
                            cmd.Parameters.AddWithValue("@act", action ?? "");
                            cmd.Parameters.AddWithValue("@det", details ?? "");
                            cmd.Parameters.AddWithValue("@lvl", level ?? "Info");
                            cmd.Parameters.AddWithValue("@op", operatorName ?? "");
                            cmd.Parameters.AddWithValue("@ip", clientIp ?? "");
                            cmd.Parameters.AddWithValue("@st", stationName ?? "");
                            cmd.Parameters.AddWithValue("@ph", prevHash);
                            cmd.Parameters.AddWithValue("@eh", entryHash);
                        });
                }
                catch (Exception ex)
                {
                    // Fall back to the plain audit log if the chain is unavailable.
                    AuditLog.Log("AuditChain", $"Failed to append: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Verifies the entire audit chain. Returns (ok, firstBrokenId, reason).
        /// If ok is true, the chain is intact. If false, firstBrokenId is the
        /// id of the first entry whose hash doesn't match (the tampered one
        /// or the one whose prev_hash is wrong).
        /// </summary>
        public static (bool Ok, int BrokenId, string Reason) VerifyChain()
        {
            try
            {
                string genesis = GetOrCreateGenesis();
                var entries = Database.Instance.Query(
                    "SELECT id, timestamp, category, action, details, level, operator_name, client_ip, station_name, prev_hash, entry_hash FROM audit_chain ORDER BY id",
                    null,
                    r => (
                        Id: r.GetInt32(0),
                        Timestamp: r.GetString(1),
                        Category: r.GetString(2),
                        Action: r.GetString(3),
                        Details: r.IsDBNull(4) ? "" : r.GetString(4),
                        Level: r.IsDBNull(5) ? "" : r.GetString(5),
                        Operator: r.IsDBNull(6) ? "" : r.GetString(6),
                        ClientIp: r.IsDBNull(7) ? "" : r.GetString(7),
                        Station: r.IsDBNull(8) ? "" : r.GetString(8),
                        PrevHash: r.GetString(9),
                        EntryHash: r.GetString(10)
                    ));

                string expectedPrev = genesis;
                foreach (var e in entries)
                {
                    // 1. prev_hash must match the previous entry's entry_hash (or genesis for the first).
                    if (e.PrevHash != expectedPrev)
                        return (false, e.Id, $"prev_hash mismatch at id {e.Id}: expected {expectedPrev?.Substring(0,12)}… got {e.PrevHash?.Substring(0,12)}…");

                    // 2. entry_hash must match the recomputed hash.
                    string recomputed = ComputeEntryHash(e.PrevHash, e.Timestamp, e.Category, e.Action, e.Details, e.Level, e.Operator, e.ClientIp, e.Station);
                    if (recomputed != e.EntryHash)
                        return (false, e.Id, $"entry_hash mismatch at id {e.Id}: stored {e.EntryHash?.Substring(0,12)}… recomputed {recomputed?.Substring(0,12)}…");

                    expectedPrev = e.EntryHash;
                }
                return (true, 0, "Chain intact.");
            }
            catch (Exception ex)
            {
                return (false, -1, "Verification error: " + ex.Message);
            }
        }

        private static string GetOrCreateGenesis()
        {
            try
            {
                var existing = Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", GenesisSettingKey),
                    r => r.GetString(0));
                if (!string.IsNullOrEmpty(existing)) return existing;

                // Create a new genesis: random 32 bytes hex.
                string genesis;
                byte[] g = new byte[32];
                using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(g);
                genesis = BitConverter.ToString(g).Replace("-", "").ToLowerInvariant();
                Database.Instance.Execute(
                    "INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                    cmd => { cmd.Parameters.AddWithValue("@k", GenesisSettingKey); cmd.Parameters.AddWithValue("@v", genesis); });
                AuditLog.Log("AuditChain", "Genesis hash created for audit chain.");
                return genesis;
            }
            catch { return "0000000000000000000000000000000000000000000000000000000000000000"; }
        }

        private static string GetLastEntryHash()
        {
            try
            {
                return Database.Instance.QueryOne<string>(
                    "SELECT entry_hash FROM audit_chain ORDER BY id DESC LIMIT 1",
                    null, r => r.GetString(0));
            }
            catch { return null; }
        }

        private static string ComputeEntryHash(string prevHash, string timestamp, string category, string action, string details, string level, string op, string ip, string station)
        {
            string concatenated = (prevHash ?? "") + "|" + (timestamp ?? "") + "|" + (category ?? "") + "|" + (action ?? "") + "|" + (details ?? "") + "|" + (level ?? "") + "|" + (op ?? "") + "|" + (ip ?? "") + "|" + (station ?? "");
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(concatenated));
                var sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
    }
}
