using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class TlsWrapper
    {
        private readonly string _certPath;
        private readonly string _certPassword;
        private X509Certificate2 _certificate;

        // Pinned certificate (public-key pin). When `server_cert.pem` exists in
        // the app base directory we load it once and reject any remote cert
        // whose public key does not match - this prevents MITM with a different
        // CA-issued cert. When no pin file exists we fall back to permissive
        // validation (not-null + not-expired + log a warning), which is the
        // correct behaviour for a LAN cafe using a self-signed cert.
        private static string _pinnedCertPath;
        private static string _pinnedPublicKeyHash;
        private static bool _pinInitialized;
        private static readonly object _pinInitLock = new object();

        public bool IsEnabled => _certificate != null;

        public TlsWrapper(string certPath = "", string certPassword = "")
        {
            _certPath = certPath;
            _certPassword = certPassword;
            LoadCertificate();
            EnsurePinnedCertInitialized();
        }

        private void LoadCertificate()
        {
            if (string.IsNullOrEmpty(_certPath)) return;

            // If the certificate file doesn't exist, auto-generate a
            // self-signed one on first run so TLS is ALWAYS active (no
            // silent plaintext fallback). The generated cert is saved to
            // disk so subsequent runs reuse it (and so the operator can
            // copy server_cert.pem to kiosks for pinning).
            if (!File.Exists(_certPath))
            {
                try
                {
                    GenerateSelfSigned(_certPath, _certPassword);
                    AuditLog.Log("TLS", $"Auto-generated self-signed certificate at {_certPath}. Copy server_cert.pem to kiosks for pinning.");
                }
                catch (Exception ex)
                {
                    AuditLog.Log("TLS", $"Failed to auto-generate certificate: {ex.Message}. TLS will be unavailable — connections will be plaintext.");
                    _certificate = null;
                    return;
                }
            }

            try
            {
                // FIX B5: use UserKeySet + Exportable instead of MachineKeySet +
                // PersistKeySet. MachineKeySet writes the private key to the
                // per-machine key container, which requires Administrator
                // privileges — a non-admin operator (or a service account
                // without elevated rights) would get CryptographicException
                // "Keyset does not exist" or "Access denied" on every startup,
                // which surfaced as the server failing to open. UserKeySet
                // writes the key to the per-user container (no admin needed);
                // Exportable lets the cert be re-exported for pinning
                // distribution to kiosks.
                _certificate = new X509Certificate2(_certPath, _certPassword, X509KeyStorageFlags.UserKeySet | X509KeyStorageFlags.Exportable);
                AuditLog.Log("TLS", $"Certificate loaded: {_certificate.Subject}, Expires: {_certificate.NotAfter:yyyy-MM-dd}");

                // Also export the public-key PEM for easy pinning distribution.
                try
                {
                    string pemPath = Path.Combine(Path.GetDirectoryName(_certPath) ?? ".", "server_cert.pem");
                    if (!File.Exists(pemPath))
                    {
                        File.WriteAllText(pemPath, "-----BEGIN CERTIFICATE-----\r\n" + Convert.ToBase64String(_certificate.Export(X509ContentType.Cert), Base64FormattingOptions.InsertLineBreaks) + "\r\n-----END CERTIFICATE-----\r\n");
                        AuditLog.Log("TLS", $"Public certificate exported to {pemPath} — distribute to kiosks for pinning.");
                    }
                }
                catch (Exception ex) { AuditLog.Log("TLS", "Could not export server_cert.pem: " + ex.Message); }
            }
            catch (Exception ex) { AuditLog.Log("TLS", $"Failed to load certificate: {ex.Message}"); _certificate = null; }
        }

        public Stream WrapServerStream(NetworkStream networkStream)
        {
            if (!IsEnabled) return networkStream;
            try
            {
                var ssl = new SslStream(networkStream, false);
                ssl.AuthenticateAsServer(_certificate, clientCertificateRequired: false, enabledSslProtocols: SslProtocols.Tls12, checkCertificateRevocation: false);
                AuditLog.Log("TLS", "TLS handshake completed");
                return ssl;
            }
            catch (Exception ex) { AuditLog.Log("TLS", $"TLS handshake failed: {ex.Message}"); throw; }
        }

        public Stream WrapClientStream(TcpClient tcpClient, string targetHost)
        {
            var ssl = new SslStream(tcpClient.GetStream(), false, ValidateRemoteCertificate);
            ssl.AuthenticateAsClient(targetHost ?? "gamenet-server");
            return ssl;
        }

        /// <summary>
        /// Real remote-certificate validation callback. Replaces the previous
        /// unconditional `=> true` that accepted ANY certificate (including a
        /// MITM attacker's). Behaviour:
        ///  - if a pinned `server_cert.pem` is loaded, only accept a remote cert
        ///    whose SHA-256 public-key hash matches the pin (CA chain ignored);
        ///  - otherwise (LAN self-signed scenario) accept the cert only if it is
        ///    present and not yet expired, and log a warning that no pin is set.
        /// Errors from the SslStream are still surfaced via the chain/sslPolicyErrors
        /// arguments but the pin check is authoritative when present.
        /// </summary>
        private bool ValidateRemoteCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (certificate == null)
            {
                AuditLog.Log("TLS", "Remote certificate validation failed: no certificate presented.");
                return false;
            }

            X509Certificate2 cert2;
            bool ownsCert2;
            if (certificate is X509Certificate2 existing)
            {
                cert2 = existing;
                ownsCert2 = false;
            }
            else
            {
                cert2 = new X509Certificate2(certificate);
                ownsCert2 = true;
            }

            try
            {
                // ---- Pinned-cert path (authoritative when configured) ----
                EnsurePinnedCertInitialized();
                if (!string.IsNullOrEmpty(_pinnedPublicKeyHash))
                {
                    string actualHash = ComputePublicKeySha256(cert2);
                    bool pinMatch = ConstantTimeEquals(actualHash, _pinnedPublicKeyHash);
                    if (!pinMatch)
                    {
                        AuditLog.Log("TLS", $"Remote certificate rejected: public key does not match pin (expected {_pinnedPublicKeyHash.Substring(0,12)}…, got {actualHash.Substring(0,12)}…).");
                        return false;
                    }
                    AuditLog.Log("TLS", "Remote certificate accepted: matches pinned public key.");
                    return true;
                }

                // ---- Permissive LAN path (self-signed acceptable, but verify basics) ----
                DateTime now = DateTime.UtcNow;
                if (cert2.NotAfter.ToUniversalTime() < now)
                {
                    AuditLog.Log("TLS", $"Remote certificate rejected: expired on {cert2.NotAfter:o}.");
                    return false;
                }
                if (cert2.NotBefore.ToUniversalTime() > now.AddMinutes(5))
                {
                    AuditLog.Log("TLS", $"Remote certificate rejected: not valid before {cert2.NotBefore:o} (clock skew?).");
                    return false;
                }

                // Self-signed / untrusted root is acceptable for the LAN scenario,
                // but record it loudly so operators know they should drop a pin file.
                if ((sslPolicyErrors & SslPolicyErrors.RemoteCertificateChainErrors) != 0 ||
                    (sslPolicyErrors & SslPolicyErrors.RemoteCertificateNameMismatch) != 0)
                {
                    AuditLog.Log("TLS", $"WARNING: accepting self-signed / name-mismatched cert (Subject={cert2.Subject}, Errors={sslPolicyErrors}). Drop a server_cert.pem next to the executable to enforce pinning.");
                }
                else
                {
                    AuditLog.Log("TLS", $"Remote certificate accepted (Subject={cert2.Subject}).");
                }
                return true;
            }
            finally
            {
                if (ownsCert2) cert2?.Dispose();
            }
        }

        private static string ComputePublicKeySha256(X509Certificate2 cert)
        {
            // Pin on the SubjectPublicKeyInfo (RFC 5280) rather than the full
            // certificate so rotation of the leaf cert with the same key still
            // pins. RSA / ECDsa / DSA all expose the public key via GetPublicKey().
            byte[] pubKey = cert.GetPublicKey();
            using (var sha = SHA256.Create())
            {
                byte[] digest = sha.ComputeHash(pubKey);
                StringBuilder sb = new StringBuilder(digest.Length * 2);
                foreach (byte b in digest) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= (int)a[i] ^ (int)b[i];
            return diff == 0;
        }

        private static void EnsurePinnedCertInitialized()
        {
            if (_pinInitialized) return;
            lock (_pinInitLock)
            {
                if (_pinInitialized) return;
                try
                {
                    string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server_cert.pem");
                    if (File.Exists(path))
                    {
                        var pinned = new X509Certificate2(path);
                        _pinnedCertPath = path;
                        _pinnedPublicKeyHash = ComputePublicKeySha256(pinned);
                        AuditLog.Log("TLS", $"Pinned certificate loaded from {path} (public-key SHA-256 = {_pinnedPublicKeyHash.Substring(0,16)}…).");
                    }
                    else
                    {
                        AuditLog.Log("TLS", "No server_cert.pem found in app directory. Self-signed LAN certs will be accepted but not pinned - drop a server_cert.pem to enable pinning.");
                    }
                }
                catch (Exception ex)
                {
                    AuditLog.Log("TLS", $"Failed to load pinned certificate: {ex.Message}. Falling back to permissive LAN validation.");
                    _pinnedPublicKeyHash = null;
                }
                _pinInitialized = true;
            }
        }

        public CertificateInfo GetCertificateInfo()
        {
            if (_certificate == null) return new CertificateInfo { IsLoaded = false };
            return new CertificateInfo
            {
                IsLoaded = true, Subject = _certificate.Subject,
                Issuer = _certificate.Issuer, NotBefore = _certificate.NotBefore,
                NotAfter = _certificate.NotAfter, Thumbprint = _certificate.Thumbprint,
                SerialNumber = _certificate.SerialNumber
            };
        }

        public void GenerateSelfSigned(string savePath, string password = "gamenet")
        {
            var ecdsa = System.Security.Cryptography.ECDsa.Create();
            var req = new CertificateRequest("CN=GameNet-Server", ecdsa, System.Security.Cryptography.HashAlgorithmName.SHA256);
            req.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, false));
            req.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature | X509KeyUsageFlags.KeyEncipherment, false));
            var cert = req.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddYears(5));
            File.WriteAllBytes(savePath, cert.Export(X509ContentType.Pfx, password));
            AuditLog.Log("TLS", $"Self-signed certificate generated: {savePath}");
        }
    }

    public class CertificateInfo { public bool IsLoaded; public string Subject; public string Issuer; public DateTime NotBefore; public DateTime NotAfter; public string Thumbprint; public string SerialNumber; }
}
