using System;
namespace GameNet.Server.Core {
    public class WebDashboardServer {
        public string GetStatus() { return "آماده"; }
    }
}
