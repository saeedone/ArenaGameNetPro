using System;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// *** NOT YET ACTIVE — DEAD CODE ***
    ///
    /// This class is intended as a Phase 2.1 message-level security layer
    /// on top of TLS (HMAC-SHA256 + nonce + timestamp on every NetMessage),
    /// but it is NOT called from Protocol.ReadMessage, ClientCommunicator,
    /// or anywhere in the message send/receive path. Grep confirms zero
    /// external call sites. It was never wired in because the master-secret
    /// derivation (SHA256 of MachineName + "GameNet") differs between the
    /// server and the client (different machine names) — so even if wired
    /// in, HMACs would NEVER verify. TLS (when UseTls=true) already
    /// provides message integrity + authentication.
    ///
    /// This class is retained as a placeholder for a future proper
    /// implementation that uses a server-generated shared secret exchanged
    /// during the handshake. Do NOT rely on it for security today.
    ///
    /// Wire format (for future reference):
    ///   signedJson = nonceHex + "|" + timestampUnixMs + "|" + hmacHex + "|" + originalJson
    /// </summary>
    public static class MessageSecurity
    {
        /// <summary>
        /// Master pre-shared secret. In production this should be loaded
        /// from the operator-configured network key (stored encrypted in the
        /// database / a key file). For now we derive it from the deployment's
        /// master.key so no extra setup is needed.
        /// </summary>
        private static byte[] _masterSecret;
        private static readonly object _initLock = new object();

        private static void EnsureMaster()
        {
            if (_masterSecret != null) return;
            lock (_initLock)
            {
                if (_masterSecret != null) return;
                try { DataEncryption.Initialize(); }
                catch { /* master.key will be created by DataEncryption */ }
                // Use a fixed, deployment-stable derivation so both server and
                // client (which both have access to DataEncryption via Shared
                // on server; the client has its own ConnectionSettings) can
                // agree on the same key. The client side mirrors this in
                // ClientMessageSecurity.
                _masterSecret = new byte[32];
                using (var sha = SHA256.Create())
                {
                    byte[] label = Encoding.UTF8.GetBytes("GameNet-MessageSecurity-v1");
                    byte[] seed = new byte[label.Length + 16];
                    Buffer.BlockCopy(label, 0, seed, 0, label.Length);
                    // Include a deployment id (machine name hash) so different
                    // cafes don't share the same key.
                    byte[] mid = sha.ComputeHash(Encoding.UTF8.GetBytes(Environment.MachineName + "GameNet"));
                    Buffer.BlockCopy(mid, 0, seed, label.Length, 16);
                    byte[] full = sha.ComputeHash(seed);
                    Buffer.BlockCopy(full, 0, _masterSecret, 0, 32);
                }
            }
        }

        /// <summary>
        /// Derives a per-session signing key from the master secret + the
        /// connection's SessionId. Both sides derive the same key for the
        /// same SessionId, so HMACs verify.
        /// </summary>
        public static byte[] DeriveSessionKey(string sessionId)
        {
            EnsureMaster();
            using (var sha = SHA256.Create())
            {
                byte[] sid = Encoding.UTF8.GetBytes(sessionId ?? "");
                byte[] buf = new byte[_masterSecret.Length + sid.Length];
                Buffer.BlockCopy(_masterSecret, 0, buf, 0, _masterSecret.Length);
                Buffer.BlockCopy(sid, 0, buf, _masterSecret.Length, sid.Length);
                return sha.ComputeHash(buf);
            }
        }

        /// <summary>
        /// Signs a message: returns the wire-format string
        ///   nonce|timestamp|sig|json
        /// </summary>
        public static string Sign(string json, byte[] sessionKey)
        {
            if (string.IsNullOrEmpty(json)) json = "";
            if (sessionKey == null || sessionKey.Length == 0) return json; // unsigned passthrough

            byte[] nonceBytes = new byte[8];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(nonceBytes);
            string nonceHex = BitConverter.ToString(nonceBytes).Replace("-", "").ToLowerInvariant();
            long timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            // HMAC over (nonce || timestamp || json)
            string payload = nonceHex + "|" + timestamp + "|" + json;
            byte[] mac;
            using (var hmac = new HMACSHA256(sessionKey))
                mac = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            string macHex = BitConverter.ToString(mac).Replace("-", "").ToLowerInvariant();

            return nonceHex + "|" + timestamp + "|" + macHex + "|" + json;
        }

        /// <summary>
        /// Verifies a signed wire-format string. Returns the original JSON
        /// if the signature is valid and the message is fresh (within the
        /// replay window). Throws SecurityException on tamper / replay /
        /// stale message. If the input is NOT in signed format (no 3
        /// leading pipe-delimited fields that parse as nonce/timestamp/sig),
        /// returns it unchanged so legacy/unsigned messages still work during
        /// migration.
        /// </summary>
        public static string Verify(string wire, byte[] sessionKey, NonceReplayCache replayCache)
        {
            if (string.IsNullOrEmpty(wire)) return wire;
            if (sessionKey == null || sessionKey.Length == 0) return wire;

            int p1 = wire.IndexOf('|');
            if (p1 <= 0) return wire; // unsigned passthrough
            int p2 = wire.IndexOf('|', p1 + 1);
            if (p2 <= 0) return wire;
            int p3 = wire.IndexOf('|', p2 + 1);
            if (p3 <= 0) return wire;

            string nonceHex = wire.Substring(0, p1);
            string tsStr = wire.Substring(p1 + 1, p2 - p1 - 1);
            string macHex = wire.Substring(p2 + 1, p3 - p2 - 1);
            string json = wire.Substring(p3 + 1);

            // Validate nonce format (16 hex chars = 8 bytes)
            if (nonceHex.Length != 16) return wire;

            // Validate timestamp
            if (!long.TryParse(tsStr, out long timestamp)) return wire;

            // Freshness check — reject messages older than 60 seconds or from
            // the future (clock skew tolerance 5 seconds).
            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            if (timestamp < now - 60000) throw new SecurityException("Stale message (older than 60s) — possible replay.");
            if (timestamp > now + 5000) throw new SecurityException("Future-dated message — clock skew or attack.");

            // Replay check — reject if we've already seen this nonce.
            if (replayCache != null && !replayCache.TryAdd(nonceHex, timestamp))
                throw new SecurityException("Duplicate nonce — replay attack detected.");

            // Recompute HMAC over (nonce || timestamp || json)
            string payload = nonceHex + "|" + timestamp + "|" + json;
            byte[] expectedMac;
            using (var hmac = new HMACSHA256(sessionKey))
                expectedMac = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            string expectedHex = BitConverter.ToString(expectedMac).Replace("-", "").ToLowerInvariant();

            if (!ConstantTimeEquals(macHex, expectedHex))
                throw new SecurityException("HMAC verification failed — message tampered.");

            return json;
        }

        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= (int)a[i] ^ (int)b[i];
            return diff == 0;
        }
    }

    /// <summary>
    /// Per-connection cache of seen nonces, used to reject replays. Entries
    /// older than the replay window are periodically evicted to bound memory.
    /// Thread-safe via ConcurrentDictionary.
    /// </summary>
    public class NonceReplayCache
    {
        private readonly ConcurrentDictionary<string, long> _seen = new ConcurrentDictionary<string, long>();
        private DateTime _lastCleanup = DateTime.UtcNow;
        private const long WindowMs = 120000; // 2 minutes

        /// <summary>
        /// Returns true if the nonce was added (first time seen), false if
        /// it was already present (replay).
        /// </summary>
        public bool TryAdd(string nonce, long timestamp)
        {
            // Periodic cleanup of expired entries
            if ((DateTime.UtcNow - _lastCleanup).TotalSeconds > 30)
            {
                _lastCleanup = DateTime.UtcNow;
                long cutoff = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - WindowMs;
                foreach (var kvp in _seen)
                    if (kvp.Value < cutoff) _seen.TryRemove(kvp.Key, out _);
            }
            return _seen.TryAdd(nonce, timestamp);
        }

        public void Clear() => _seen.Clear();
    }

    public class SecurityException : Exception
    {
        public SecurityException(string msg) : base(msg) { }
    }
}
