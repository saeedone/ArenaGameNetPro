using System;
namespace GameNet.Server.Core {
    public class PdfReportGenerator {
        public string GetStatus() { return "آماده"; }
    }
}
