using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class AutoUpdater
    {
        private readonly string _updateUrl;
        private readonly string _currentVersion;

        public AutoUpdater(string updateUrl = "", string currentVersion = "1.0")
        {
            _updateUrl = updateUrl;
            _currentVersion = currentVersion;
        }

        public VersionInfo CheckForUpdates()
        {
            if (string.IsNullOrEmpty(_updateUrl)) return new VersionInfo { CurrentVersion = _currentVersion, HasUpdate = false };

            try
            {
                using (var client = new WebClient())
                {
                    string json = client.DownloadString($"{_updateUrl}/version.json");
                    var info = Newtonsoft.Json.JsonConvert.DeserializeObject<VersionInfo>(json);
                    if (info != null) info.CurrentVersion = _currentVersion;
                    return info ?? new VersionInfo { CurrentVersion = _currentVersion, HasUpdate = false };
                }
            }
            catch { return new VersionInfo { CurrentVersion = _currentVersion, HasUpdate = false }; }
        }

        public UpdateResult DownloadUpdate(VersionInfo version, string savePath)
        {
            try
            {
                string url = $"{_updateUrl}/downloads/{version.LatestVersion}.zip";
                string tempFile = Path.Combine(savePath, $"update_{version.LatestVersion}.zip");

                using (var client = new WebClient()) { client.DownloadFile(url, tempFile); }

                if (!string.IsNullOrEmpty(version.Sha256Hash))
                {
                    string hash = ComputeFileHash(tempFile);
                    if (!hash.Equals(version.Sha256Hash, StringComparison.OrdinalIgnoreCase))
                    {
                        File.Delete(tempFile);
                        return new UpdateResult { Success = false, Message = "Checksum verification failed!" };
                    }
                }

                Database.Instance.Execute("INSERT INTO update_history (version_from, version_to, download_path, status, created_at) VALUES (@from, @to, @path, 'downloaded', @t)",
                    cmd => { cmd.Parameters.AddWithValue("@from", _currentVersion); cmd.Parameters.AddWithValue("@to", version.LatestVersion); cmd.Parameters.AddWithValue("@path", tempFile); cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); });

                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.System, "UpdateDownloaded", version.LatestVersion);
                return new UpdateResult { Success = true, FilePath = tempFile, Message = $"Update {version.LatestVersion} downloaded." };
            }
            catch (Exception ex) { return new UpdateResult { Success = false, Message = ex.Message }; }
        }

        public List<ClientVersion> GetConnectedClientVersions(ClientCommunicator communicator)
        {
            var result = new List<ClientVersion>();
            foreach (var client in communicator.ConnectedClients)
                result.Add(new ClientVersion { StationName = client.StationName, Version = "3.0", IsUpToDate = false });
            return result;
        }

        public void PushUpdateToClient(ClientCommunicator communicator, string station, string updateUrl)
        {
            communicator.SendToStation(station, new Shared.NetMessage(Shared.MessageType.ServerUpdateAvailable,
                new Shared.ServerUpdatePayload { Version = "1.0", DownloadUrl = updateUrl, IsMandatory = false }));
        }

        private string ComputeFileHash(string filePath)
        {
            using (var sha = SHA256.Create())
            using (var stream = File.OpenRead(filePath))
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }
    }

    public class VersionInfo { public string CurrentVersion; public string LatestVersion; public bool HasUpdate; public string ReleaseNotes; public string Sha256Hash; public long FileSizeBytes; public bool IsMandatory; }
    public class UpdateResult { public bool Success; public string FilePath; public string Message; }
    public class ClientVersion { public string StationName; public string Version; public bool IsUpToDate; }
}
