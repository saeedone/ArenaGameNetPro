using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace GameNet.Server.Core
{
    /// <summary>
    /// AES-256 field-level encryption for sensitive database columns (phone
    /// numbers, notes, 2FA secrets, etc). The master key is derived once from
    /// a deployment-specific master secret and cached for the process lifetime.
    ///
    /// Key management strategy:
    ///   - On first run, a random 32-byte master secret is generated and
    ///     written to master.key next to the executable.
    ///   - The file should be backed up securely; losing it means all
    ///     encrypted fields become unreadable.
    ///   - For higher security, replace ReadMasterKey with Windows DPAPI or
    ///     an HSM-backed key provider.
    ///
    /// Ciphertext format: base64( IV(16) || ciphertext || HMAC(32) )
    /// The HMAC is computed over (IV || ciphertext) with a separate key
    /// derived from the master (encrypt-then-MAC) so tampered ciphertext is
    /// rejected before decryption.
    /// </summary>
    public static class DataEncryption
    {
        private static readonly object _keyLock = new object();
        private static byte[] _masterKey;
        private static byte[] _hmacKey;
        private static bool _initialized;

        private const string MasterKeyFile = "master.key";

        /// <summary>
        /// Initializes the encryption keys from master.key (generating a new
        /// random key on first run). Safe to call multiple times.
        /// </summary>
        public static void Initialize()
        {
            lock (_keyLock)
            {
                if (_initialized) return;

                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, MasterKeyFile);
                byte[] secret;
                if (File.Exists(path))
                {
                    secret = File.ReadAllBytes(path);
                    if (secret.Length < 32)
                        throw new InvalidOperationException("master.key is too short (need 32 bytes).");
                }
                else
                {
                    // Generate a new 32-byte master secret on first run.
                    secret = new byte[32];
                    using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(secret);
                    try
                    {
                        File.WriteAllBytes(path, secret);
                        AuditLog.Log("Crypto", $"New master.key generated at {path}. BACK THIS FILE UP — losing it makes all encrypted data unreadable.");
                    }
                    catch (Exception ex)
                    {
                        AuditLog.Log("Crypto", "Failed to write master.key: " + ex.Message);
                        throw;
                    }
                }

                // Derive separate keys for encryption and HMAC from the master
                // secret using HKDF-like construction (SHA256 of label || secret).
                _masterKey = DeriveKey(secret, "AES-ENC", 32);
                _hmacKey = DeriveKey(secret, "HMAC-MAC", 32);
                _initialized = true;
            }
        }

        /// <summary>Derives a sub-key of the given length from a master secret + label.</summary>
        private static byte[] DeriveKey(byte[] secret, string label, int length)
        {
            using (var sha = SHA256.Create())
            {
                byte[] labelBytes = Encoding.UTF8.GetBytes(label);
                byte[] buf = new byte[labelBytes.Length + secret.Length];
                Buffer.BlockCopy(labelBytes, 0, buf, 0, labelBytes.Length);
                Buffer.BlockCopy(secret, 0, buf, labelBytes.Length, secret.Length);
                byte[] full = sha.ComputeHash(buf);
                if (length <= 32) { Array.Resize(ref full, length); return full; }
                // Need more than 32 bytes — extend with a second round.
                byte[] buf2 = new byte[full.Length + secret.Length];
                Buffer.BlockCopy(full, 0, buf2, 0, full.Length);
                Buffer.BlockCopy(secret, 0, buf2, full.Length, secret.Length);
                byte[] more = sha.ComputeHash(buf2);
                byte[] result = new byte[length];
                Buffer.BlockCopy(full, 0, result, 0, 32);
                Buffer.BlockCopy(more, 0, result, 32, length - 32);
                return result;
            }
        }

        /// <summary>
        /// Encrypts a plaintext string. Returns a base64 string containing
        /// IV + ciphertext + HMAC. Returns null if input is null; returns ""
        /// if input is empty (empty strings are not encrypted).
        /// </summary>
        public static string Encrypt(string plaintext)
        {
            if (plaintext == null) return null;
            if (plaintext.Length == 0) return "";
            Initialize();

            byte[] iv;
            byte[] cipher;
            using (var aes = Aes.Create())
            {
                aes.Key = _masterKey;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.GenerateIV();
                iv = aes.IV;
                using (var enc = aes.CreateEncryptor())
                {
                    byte[] plainBytes = Encoding.UTF8.GetBytes(plaintext);
                    cipher = enc.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                }
            }

            // Build IV || cipher
            byte[] payload = new byte[iv.Length + cipher.Length];
            Buffer.BlockCopy(iv, 0, payload, 0, iv.Length);
            Buffer.BlockCopy(cipher, 0, payload, iv.Length, cipher.Length);

            // HMAC over IV || cipher
            byte[] mac;
            using (var hmac = new HMACSHA256(_hmacKey))
                mac = hmac.ComputeHash(payload);

            byte[] result = new byte[payload.Length + mac.Length];
            Buffer.BlockCopy(payload, 0, result, 0, payload.Length);
            Buffer.BlockCopy(mac, 0, result, payload.Length, mac.Length);

            return "ENC1:" + Convert.ToBase64String(result);
        }

        /// <summary>
        /// Decrypts a string produced by Encrypt. Returns null if input is
        /// null, "" if input is empty, and the original plaintext otherwise.
        /// Throws CryptographicException if the HMAC does not verify (tampered).
        /// </summary>
        public static string Decrypt(string ciphertext)
        {
            if (ciphertext == null) return null;
            if (ciphertext.Length == 0) return "";
            if (!ciphertext.StartsWith("ENC1:")) return ciphertext; // plaintext fallback (legacy data)
            Initialize();

            byte[] all = Convert.FromBase64String(ciphertext.Substring(5));
            if (all.Length < 16 + 32) throw new CryptographicException("Ciphertext too short.");

            int macLen = 32;
            int payloadLen = all.Length - macLen;
            byte[] payload = new byte[payloadLen];
            byte[] mac = new byte[macLen];
            Buffer.BlockCopy(all, 0, payload, 0, payloadLen);
            Buffer.BlockCopy(all, payloadLen, mac, 0, macLen);

            // Verify HMAC first (encrypt-then-MAC)
            byte[] expectedMac;
            using (var hmac = new HMACSHA256(_hmacKey))
                expectedMac = hmac.ComputeHash(payload);
            if (!ConstantTimeEquals(mac, expectedMac))
                throw new CryptographicException("HMAC verification failed — ciphertext tampered.");

            // Decrypt
            byte[] iv = new byte[16];
            byte[] cipher = new byte[payloadLen - 16];
            Buffer.BlockCopy(payload, 0, iv, 0, 16);
            Buffer.BlockCopy(payload, 16, cipher, 0, cipher.Length);

            using (var aes = Aes.Create())
            {
                aes.Key = _masterKey;
                aes.IV = iv;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using (var dec = aes.CreateDecryptor())
                {
                    byte[] plain = dec.TransformFinalBlock(cipher, 0, cipher.Length);
                    return Encoding.UTF8.GetString(plain);
                }
            }
        }

        /// <summary>
        /// Returns true if the given string looks like an encrypted value
        /// (starts with the ENC1: prefix). Useful for migrating plaintext
        /// columns lazily.
        /// </summary>
        public static bool IsEncrypted(string value)
            => value != null && value.StartsWith("ENC1:");

        private static bool ConstantTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
