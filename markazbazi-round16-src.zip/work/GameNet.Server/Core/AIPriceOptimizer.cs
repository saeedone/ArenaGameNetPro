using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class AIPriceSuggestion { public int Hour; public decimal SuggestedPrice; public int Demand; }
    public class AIPriceOptimizer {
        public List<AIPriceSuggestion> GetSuggestions() { var list = new List<AIPriceSuggestion>(); try { decimal basePrice = 15000; for (int h = 0; h < 24; h++) { decimal multiplier = 1.0m; int demand = 0; if (h >= 16 && h <= 23) { multiplier = 1.3m; demand = 80; } else if (h >= 9 && h <= 15) { multiplier = 1.0m; demand = 50; } else { multiplier = 0.7m; demand = 20; } list.Add(new AIPriceSuggestion { Hour = h, SuggestedPrice = Math.Round(basePrice * multiplier, 0), Demand = demand }); } } catch { } return list; }
    }
}
