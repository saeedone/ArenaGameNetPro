using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class TicketManager
    {
        // Character set for ticket codes — ambiguous characters (0/O, 1/I) excluded
        // so codes can be read over the phone or typed at a kiosk without confusion.
        private const string CodeAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        private const int CodeLength = 10;
        private const int MaxCollisionRetries = 5;

        public Ticket CreateTicket(decimal credit, int duration, string type = "credit", DateTime? expires = null, int maxUses = 1, int? opId = null, string notes = "")
        {
            if (credit <= 0 && duration <= 0) throw new ArgumentException("اعتبار یا زمان باید بیشتر از صفر باشد");
            if (maxUses < 0) throw new ArgumentException("maxUses نمی‌تواند منفی باشد");

            string code = GenerateCode();
            Database.Instance.Execute(
                "INSERT INTO tickets (code, credit_amount, duration_minutes, ticket_type, is_used, created_at, expires_at, max_uses, current_uses, created_by_operator_id, notes) VALUES (@c, @cr, @d, @t, 0, @ca, @ex, @m, 0, @o, @n)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@c", code);
                    cmd.Parameters.AddWithValue("@cr", credit);
                    cmd.Parameters.AddWithValue("@d", duration);
                    cmd.Parameters.AddWithValue("@t", type);
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@ex", (object)expires?.ToString("o") ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@m", maxUses);
                    cmd.Parameters.AddWithValue("@o", (object)opId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@n", notes ?? "");
                });
            AuditLog.Log("TicketManager", $"Ticket created: code={code}, credit={credit}, duration={duration}, maxUses={maxUses}");
            return FindByCode(code);
        }

        public List<Ticket> CreateBatch(int count, decimal credit, int duration, string type = "credit", DateTime? expires = null, int? opId = null, string notes = "")
        {
            var list = new List<Ticket>();
            for (int i = 0; i < count; i++)
                list.Add(CreateTicket(credit, duration, type, expires, 1, opId, $"{notes} ({i + 1}/{count})"));
            return list;
        }

        /// <summary>
        /// Redeem a ticket atomically. The current_uses increment is done with a
        /// single conditional UPDATE so that two concurrent redeems of a
        /// limited-use ticket cannot both succeed (over-redemption race). The
        /// user's balance is credited in the same transaction so a failure
        /// between "mark ticket used" and "credit user" cannot lose money.
        /// Time tickets (DurationMinutes &gt; 0) are now granted as equivalent
        /// credit (default price_per_hour * DurationMinutes / 60) so they
        /// actually do something — previously they were silently dropped.
        /// </summary>
        public TicketResultPayload RedeemTicket(string code, string username)
        {
            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(username))
                return new TicketResultPayload { Success = false, Message = "کد تیکت و نام کاربری الزامی است" };

            // Read the ticket once (outside the txn) for validation messages.
            var t = FindByCode(code);
            if (t == null) return new TicketResultPayload { Success = false, Message = "تیکت یافت نشد" };
            if (t.ExpiresAt.HasValue && t.ExpiresAt < DateTime.UtcNow)
                return new TicketResultPayload { Success = false, Message = "تیکت منقضی شده" };

            // Verify the user exists (so we don't insert a redemption record
            // against a non-existent user).
            var user = new UserManager().FindByUsername(username);
            if (user == null) return new TicketResultPayload { Success = false, Message = "کاربر یافت نشد" };

            // Compute the equivalent time-credit value once (outside the txn —
            // this calls into other managers that take the same Database lock,
            // and the lock is reentrant but we don't want to hold the txn open
            // longer than necessary).
            decimal timeCreditValue = 0m;
            if (t.DurationMinutes > 0)
            {
                try
                {
                    var plan = new PricingManager().GetDefaultPlan();
                    if (plan != null && plan.PricePerHour > 0)
                        timeCreditValue = Math.Round(plan.PricePerHour / 60m * t.DurationMinutes, 0);
                }
                catch (Exception ex)
                {
                    AuditLog.Log("TicketManager", $"Failed to look up default pricing for time ticket {code}: {ex.Message}");
                }
            }

            decimal totalCredit = t.CreditAmount + timeCreditValue;

            try
            {
                int affected = 0;
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Atomic conditional increment: only increments if the ticket
                    // is still valid (not exhausted, not marked fully used).
                    affected = Database.Instance.ExecuteNonQuery(
                        "UPDATE tickets SET current_uses = current_uses + 1, is_used = CASE WHEN current_uses + 1 >= max_uses AND max_uses > 0 THEN 1 ELSE is_used END, used_at = @n, used_by_username = @ub WHERE code = @c AND is_used = 0 AND (max_uses = 0 OR current_uses < max_uses)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@n", DateTime.UtcNow.ToString("o"));
                            cmd.Parameters.AddWithValue("@ub", username);
                            cmd.Parameters.AddWithValue("@c", code);
                        }, tx);

                    if (affected == 0)
                        throw new InvalidOperationException("تیکت قبلاً استفاده شده یا ظرفیت آن تمام شده است");

                    if (totalCredit > 0)
                    {
                        Database.Instance.ExecuteNonQuery(
                            "UPDATE users SET balance = balance + @c WHERE username = @u",
                            cmd => { cmd.Parameters.AddWithValue("@c", totalCredit); cmd.Parameters.AddWithValue("@u", username); }, tx);
                    }
                });

                if (affected == 0)
                    return new TicketResultPayload { Success = false, Message = "تیکت قبلاً استفاده شده یا ظرفیت آن تمام شده است" };

                AuditLog.Log("TicketManager", $"Ticket {code} redeemed by {username}: credit={t.CreditAmount}, time={t.DurationMinutes}min (≈{timeCreditValue:N0} Toman)");
                return new TicketResultPayload
                {
                    Success = true,
                    Message = "تیکت با موفقیت استفاده شد",
                    CreditAmount = t.CreditAmount,
                    DurationMinutes = t.DurationMinutes
                };
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex)
            {
                AuditLog.Log("TicketManager", $"RedeemTicket failed for {code}/{username}: {ex.Message}");
                return new TicketResultPayload { Success = false, Message = "خطا در استفاده از تیکت" };
            }
        }

        public Ticket FindByCode(string code) => Database.Instance.QueryOne(
            "SELECT id, code, credit_amount, duration_minutes, ticket_type, is_used, created_at, expires_at, used_at, used_by_username, max_uses, current_uses, notes FROM tickets WHERE code = @c",
            cmd => cmd.Parameters.AddWithValue("@c", code),
            r => new Ticket
            {
                Id = r.GetInt32(0),
                Code = r.GetString(1),
                CreditAmount = r.GetDecimal(2),
                DurationMinutes = r.GetInt32(3),
                TicketType = r.GetString(4),
                IsUsed = r.GetBoolean(5),
                CreatedAt = r.GetDateTime(6),
                ExpiresAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                UsedAt = r.IsDBNull(8) ? (DateTime?)null : r.GetDateTime(8),
                UsedByUsername = r.IsDBNull(9) ? null : r.GetString(9),
                MaxUses = r.IsDBNull(10) ? 1 : r.GetInt32(10),
                CurrentUses = r.IsDBNull(11) ? 0 : r.GetInt32(11),
                Notes = r.IsDBNull(12) ? "" : r.GetString(12)
            });

        public List<Ticket> GetAllTickets(bool includeUsed = true) => Database.Instance.Query(
            includeUsed
                ? "SELECT id, code, credit_amount, duration_minutes, ticket_type, is_used, created_at, expires_at, used_at, used_by_username, max_uses, current_uses, notes FROM tickets ORDER BY created_at DESC"
                : "SELECT id, code, credit_amount, duration_minutes, ticket_type, is_used, created_at, expires_at, used_at, used_by_username, max_uses, current_uses, notes FROM tickets WHERE is_used = 0 ORDER BY created_at DESC",
            null,
            r => new Ticket
            {
                Id = r.GetInt32(0),
                Code = r.GetString(1),
                CreditAmount = r.GetDecimal(2),
                DurationMinutes = r.GetInt32(3),
                TicketType = r.GetString(4),
                IsUsed = r.GetBoolean(5),
                CreatedAt = r.GetDateTime(6),
                ExpiresAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                UsedAt = r.IsDBNull(8) ? (DateTime?)null : r.GetDateTime(8),
                UsedByUsername = r.IsDBNull(9) ? null : r.GetString(9),
                MaxUses = r.IsDBNull(10) ? 1 : r.GetInt32(10),
                CurrentUses = r.IsDBNull(11) ? 0 : r.GetInt32(11),
                Notes = r.IsDBNull(12) ? "" : r.GetString(12)
            });

        public void DeleteTicket(int id)
        {
            Database.Instance.Execute("DELETE FROM tickets WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("TicketManager", $"Ticket deleted: ID {id}");
        }

        /// <summary>
        /// Generates a cryptographically-random alphanumeric ticket code and
        /// verifies it does not collide with an existing ticket. Retries up to
        /// <see cref="MaxCollisionRetries"/> times before throwing. Replaces the
        /// previous time-seeded <see cref="Random"/> implementation whose codes
        /// were trivially predictable.
        /// </summary>
        private string GenerateCode()
        {
            var buffer = new byte[CodeLength];
            for (int attempt = 0; attempt < MaxCollisionRetries; attempt++)
            {
                using (var rng = RandomNumberGenerator.Create())
                    rng.GetBytes(buffer);

                var sb = new StringBuilder(CodeLength);
                for (int i = 0; i < CodeLength; i++)
                    sb.Append(CodeAlphabet[buffer[i] % CodeAlphabet.Length]);
                string candidate = sb.ToString();

                // Collision check — if the code already exists, retry.
                var existing = Database.Instance.QueryOne(
                    "SELECT id FROM tickets WHERE code = @c",
                    cmd => cmd.Parameters.AddWithValue("@c", candidate),
                    r => r.GetInt32(0));
                if (existing == 0)
                    return candidate;
                AuditLog.Log("TicketManager", $"GenerateCode: collision on attempt {attempt + 1}, retrying");
            }
            throw new InvalidOperationException("تولید کد تیکت با تلاش‌های متعدد ناموفق بود");
        }
    }
}
