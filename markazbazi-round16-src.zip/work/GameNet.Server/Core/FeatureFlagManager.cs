using System;
using System.Collections.Generic;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages per-feature enable/disable flags that the admin can toggle
    /// from the server UI. Flags are sent to clients via ConfigSync so
    /// the kiosk shows/hides the corresponding panel or button.
    /// </summary>
    public static class FeatureFlagManager
    {
        // All toggleable client features. Each key maps to a sidebar
        // button or panel in the kiosk.
        public static readonly string[] AllFeatures = new[]
        {
            "games",         // 🎮 بازی‌ها
            "chat",          // 💬 چت
            "announcements", // 📢 اطلاعیه‌ها
            "loyalty",       // 🏆 امتیازات
            "profile",       // 👤 پروفایل
            "stats",         // 📊 آمار
            "topup",         // 💳 شارژ سریع
            "ticket",        // 🎫 تیکت
            "settings",      // ⚙️ تنظیمات
            "food",          // 🍔 سفارش غذا
            "pause",         // ⏸️ توقف موقت
            "history",       // 📋 تاریخچه
            "leaderboard",   // 🏆 رتبه‌بندی
            "volume",        // 🔊 صدا
            "guest",         // 🔐 مهمان
            "night_mode",    // 🌑 حالت شب
            // Phase 14: new features
            "ups_monitor",   // 🔌 مانیتور برق
            "screensaver",   // 💪 اسکرین‌سیور
            "card_reader",   // 💳 ورود با کارت
            "game_tracker",  // 🎮 ردیابی بازی
            "multi_monitor", // 🖥️ چند مانیتور
            "save_backup",   // 💾 بکاپ save
            "speed_test",    // 📊 تست سرعت
            "qr_login",      // 📱 QR ورود
            "wallpaper",     // 🖼️ والپیپر
            "ambient_music", // 🎵 موسیقی محیطی
            "temp_display",  // 🌡️ نمایش دما
        };

        /// <summary>Returns true if the feature is enabled (default: all enabled).</summary>
        public static bool IsEnabled(string key)
        {
            // FIX SEV-1: QueryOne<int> returns default(int) = 0 when the row
            // doesn't exist — it does NOT throw. Since client_feature_flags
            // starts completely EMPTY on every fresh install (no seed data —
            // see Database.cs's CREATE TABLE), every single one of the 29
            // features (chat, loyalty, games, settings, profile, everything
            // — the full AllFeatures list above) evaluated v=0 → v==1 is
            // false → EVERY feature reported disabled on every fresh
            // install, hiding the corresponding button/panel on every kiosk
            // client until an operator manually visited the feature-flags
            // admin screen and explicitly re-enabled all 29 of them one by
            // one. The try/catch below was written assuming a missing row
            // would throw (it doesn't for QueryOne<int>), so the intended
            // "default: enabled" fallback in the catch block was dead code
            // for the actual failure mode that mattered.
            //
            // Fix: use SQL COALESCE to get an explicit -1 sentinel when no
            // row exists, distinguishing "never configured" (-1 → enabled)
            // from "explicitly disabled" (0 → disabled) from "explicitly
            // enabled" (1 → enabled).
            try
            {
                var v = Database.Instance.QueryOne<int>(
                    "SELECT COALESCE((SELECT is_enabled FROM client_feature_flags WHERE key = @k), -1)",
                    cmd => cmd.Parameters.AddWithValue("@k", key),
                    r => r.GetInt32(0));
                return v != 0; // -1 (never configured) or 1 (explicitly enabled) → true; 0 (explicitly disabled) → false
            }
            catch { return true; } // default: enabled (genuine DB error — fail open, not closed)
        }

        /// <summary>Enables or disables a feature.</summary>
        public static void SetEnabled(string key, bool enabled)
        {
            Database.Instance.Execute(
                "INSERT OR REPLACE INTO client_feature_flags (key, is_enabled, updated_at) VALUES (@k, @e, @t)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@k", key);
                    cmd.Parameters.AddWithValue("@e", enabled ? 1 : 0);
                    cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                });
            AuditLog.Log("FeatureFlag", $"Feature '{key}' {(enabled ? "enabled" : "disabled")} by admin");
        }

        /// <summary>Returns a dictionary of all features and their status.</summary>
        public static Dictionary<string, bool> GetAll()
        {
            var result = new Dictionary<string, bool>();
            foreach (var key in AllFeatures)
                result[key] = IsEnabled(key);
            return result;
        }

        /// <summary>
        /// Builds a Dictionary suitable for inclusion in ConfigSyncPayload.Settings
        /// so the client receives the current flag state on connect.
        /// Keys are prefixed with "feat_" to avoid collision with other settings.
        /// </summary>
        public static Dictionary<string, string> BuildSettingsDictionary()
        {
            var dict = new Dictionary<string, string>();
            foreach (var key in AllFeatures)
                dict["feat_" + key] = IsEnabled(key) ? "1" : "0";
            return dict;
        }
    }
}
