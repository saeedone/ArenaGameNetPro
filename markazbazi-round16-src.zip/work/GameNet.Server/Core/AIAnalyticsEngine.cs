using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class AIAnalyticsEntry { public string Metric = ""; public string Value = ""; public string Prediction = ""; }
    public class AIAnalyticsEngine {
        public List<AIAnalyticsEntry> GetMetrics() { var list = new List<AIAnalyticsEntry>(); try { int totalSessions = 0; decimal totalRevenue = 0; Database.Instance.Query("SELECT COUNT(*), COALESCE(SUM(total_cost),0) FROM client_sessions WHERE date(start_time)=date('now')", null, r => { totalSessions = r.GetInt32(0); totalRevenue = r.GetDecimal(1); return true; }); list.Add(new AIAnalyticsEntry { Metric = "نشست‌های امروز", Value = totalSessions.ToString(), Prediction = totalSessions > 10 ? "روند صعودی" : "روند نزولی" }); list.Add(new AIAnalyticsEntry { Metric = "درآمد امروز", Value = totalRevenue.ToString("N0") + " ت", Prediction = "پیش‌بینی: " + (totalRevenue * 1.15m).ToString("N0") + " ت" }); list.Add(new AIAnalyticsEntry { Metric = "کلاینت‌های فعال", Value = "0", Prediction = "پایدار" }); } catch { } return list; }
    }
}
