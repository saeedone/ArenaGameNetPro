using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class SecurityEvent { public int Id; public string EventType = ""; public string Severity = ""; public string Description = ""; public DateTime Timestamp; }
    public class AdvancedSecurityManager {
        public void LogEvent(string type, string severity, string desc) { try { EnsureTable(); Database.Instance.Execute("INSERT INTO security_events (event_type, severity, description, timestamp) VALUES (@t, @s, @d, @ts)", c => { c.Parameters.AddWithValue("@t", type); c.Parameters.AddWithValue("@s", severity); c.Parameters.AddWithValue("@d", desc); c.Parameters.AddWithValue("@ts", DateTime.UtcNow.ToString("o")); }); AuditLog.Log("Security", $"{type}: {desc}"); } catch { } }
        public List<SecurityEvent> GetRecentEvents(int limit = 50) { var list = new List<SecurityEvent>(); try { EnsureTable(); Database.Instance.Query("SELECT id, event_type, severity, description, timestamp FROM security_events ORDER BY id DESC LIMIT @l", c => c.Parameters.AddWithValue("@l", limit), r => { list.Add(new SecurityEvent { Id = r.GetInt32(0), EventType = r.GetString(1), Severity = r.GetString(2), Description = r.GetString(3), Timestamp = DateTime.Parse(r.GetString(4)) }); return true; }); } catch { } return list; }
        private void EnsureTable() { Database.Instance.Execute("CREATE TABLE IF NOT EXISTS security_events (id INTEGER PRIMARY KEY, event_type TEXT, severity TEXT, description TEXT, timestamp TEXT)", null); }
    }
}
