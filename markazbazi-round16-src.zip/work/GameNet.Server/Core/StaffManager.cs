using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public enum StaffRole { Operator, Technician, Manager, Cashier, Security }
    public class StaffMember { public int Id; public string Name = ""; public string Phone = ""; public StaffRole Role; public bool CheckedIn; }
    public class StaffManager {
        public void AddStaff(string name, string phone, StaffRole role) { try { EnsureTable(); Database.Instance.Execute("INSERT INTO staff_members (name, phone, role, checked_in) VALUES (@n, @p, @r, 0)", c => { c.Parameters.AddWithValue("@n", name); c.Parameters.AddWithValue("@p", phone ?? ""); c.Parameters.AddWithValue("@r", role.ToString()); }); AuditLog.Log("Staff", "Added: " + name); } catch { } }
        public List<StaffMember> GetAllStaff() { var list = new List<StaffMember>(); try { EnsureTable(); Database.Instance.Query("SELECT id, name, phone, role, checked_in FROM staff_members ORDER BY id", null, r => { list.Add(new StaffMember { Id = r.GetInt32(0), Name = r.GetString(1), Phone = r.IsDBNull(2) ? "" : r.GetString(2), Role = (StaffRole)Enum.Parse(typeof(StaffRole), r.GetString(3)), CheckedIn = r.GetInt32(4) == 1 }); return true; }); } catch { } return list; }
        public void DeleteStaff(int id) { try { Database.Instance.Execute("DELETE FROM staff_members WHERE id=@id", c => c.Parameters.AddWithValue("@id", id)); } catch { } }
        public void ToggleCheckIn(int id) { try { Database.Instance.Execute("UPDATE staff_members SET checked_in = 1 - checked_in WHERE id=@id", c => c.Parameters.AddWithValue("@id", id)); } catch { } }
        private void EnsureTable() { Database.Instance.Execute("CREATE TABLE IF NOT EXISTS staff_members (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, role TEXT, checked_in INTEGER DEFAULT 0, created_at TEXT)", null); }
    }
}
