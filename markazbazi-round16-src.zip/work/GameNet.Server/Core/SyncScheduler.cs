using System;
using System.Threading;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX DEAD-CONFIG-6: OptionsForm's "همگام‌سازی زمان‌بندی‌شده"
    /// (ScheduledSync) + "بازه (دقیقه)" (ScheduledSyncMinutes) were saved to
    /// options.json but nothing ever ran on a schedule — the only way to
    /// sync was the operator manually opening SyncForm and clicking
    /// "همگام‌سازی الان". This runs SyncForm's actual sync action
    /// (ClientCommunicator.OfferUpdateToAll — see SyncForm.SyncNow, which
    /// does the same thing per task) on the configured interval, gated by
    /// both SyncEnabled (master toggle) and ScheduledSync.
    ///
    /// Deliberately re-reads options.json on every tick rather than caching
    /// interval/enabled at startup, so a change made in OptionsForm takes
    /// effect on the very next tick without requiring a server restart.
    /// </summary>
    public class SyncScheduler : IDisposable
    {
        private readonly ClientCommunicator _communicator;
        private Timer _timer;
        private DateTime _lastRunUtc = DateTime.MinValue;
        private const int TickSeconds = 30; // check cadence; actual sync only fires per ScheduledSyncMinutes

        public SyncScheduler(ClientCommunicator communicator)
        {
            _communicator = communicator;
        }

        public void Start()
        {
            _timer = new Timer(Tick, null, TimeSpan.FromSeconds(TickSeconds), TimeSpan.FromSeconds(TickSeconds));
        }

        public void Stop()
        {
            _timer?.Dispose();
            _timer = null;
        }

        private void Tick(object state)
        {
            try
            {
                var opts = Forms.OptionsForm.LoadStaticOptions();
                if (opts == null || !opts.SyncEnabled || !opts.ScheduledSync) return;

                int intervalMin = opts.ScheduledSyncMinutes > 0 ? opts.ScheduledSyncMinutes : 5;
                if ((DateTime.UtcNow - _lastRunUtc).TotalMinutes < intervalMin) return;

                _lastRunUtc = DateTime.UtcNow;
                int count = _communicator?.ConnectedClientCount ?? 0;
                AuditLog.Log("SyncScheduler", $"Running scheduled sync (interval={intervalMin}m, connected clients={count})");
                _communicator?.OfferUpdateToAll();
            }
            catch (Exception ex)
            {
                AuditLog.Log("SyncScheduler", "Tick error: " + ex.Message);
            }
        }

        public void Dispose() => Stop();
    }
}
