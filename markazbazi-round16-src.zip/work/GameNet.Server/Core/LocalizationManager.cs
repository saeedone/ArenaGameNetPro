using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class LocalizationManager
    {
        private const string LangSettingsKey = "language";
        private readonly Dictionary<string, Dictionary<string, string>> _translations = new Dictionary<string, Dictionary<string, string>>
        {
            ["fa"] = new Dictionary<string, string>
            {
                ["app.title"] = "مدیریت گیم‌نت", ["menu.users"] = "مدیریت کاربران", ["menu.pricing"] = "مدیریت تعرفه‌ها",
                ["menu.stations"] = "مدیریت ایستگاه‌ها", ["menu.equipment"] = "مدیریت تجهیزات", ["menu.tickets"] = "مدیریت تیکت‌ها",
                ["menu.monitor"] = "مانیتور کلاینت‌ها", ["menu.chat"] = "چت", ["menu.announcements"] = "اطلاعیه‌ها",
                ["menu.reports"] = "گزارش‌ها", ["menu.backup"] = "پشتیبان‌گیری", ["menu.debts"] = "مدیریت بدهی",
                ["menu.print"] = "مدیریت پرینت", ["menu.packages"] = "بسته‌های زمانی", ["menu.tiers"] = "سطح‌های عضویت",
                ["menu.security"] = "امنیت", ["menu.theme"] = "تنظیمات ظاهری", ["menu.branches"] = "مدیریت شعب",
                ["menu.payment"] = "درگاه پرداخت", ["menu.dashboard"] = "داشبورد", ["menu.smartpricing"] = "قیمت‌گذاری هوشمند",
                ["btn.save"] = "ذخیره", ["btn.cancel"] = "انصراف", ["btn.delete"] = "حذف", ["btn.edit"] = "ویرایش",
                ["btn.add"] = "افزودن", ["btn.search"] = "جستجو", ["btn.refresh"] = "بروزرسانی", ["btn.close"] = "بستن",
                ["lbl.username"] = "نام کاربری", ["lbl.password"] = "رمز عبور", ["lbl.balance"] = "موجودی",
                ["lbl.price"] = "قیمت", ["lbl.time"] = "زمان", ["lbl.status"] = "وضعیت", ["lbl.name"] = "نام",
                ["msg.success"] = "عملیات با موفقیت انجام شد", ["msg.error"] = "خطا در انجام عملیات",
                ["msg.confirm_delete"] = "آیا از حذف مطمئن هستید؟", ["msg.insufficient_balance"] = "موجودی کافی نیست",
                ["status.active"] = "فعال", ["status.inactive"] = "غیرفعال", ["status.connected"] = "متصل",
                ["status.disconnected"] = "قطع", ["status.online"] = "آنلاین", ["status.offline"] = "آفلاین",
            },
            ["en"] = new Dictionary<string, string>
            {
                ["app.title"] = "GameNet Manager", ["menu.users"] = "User Management", ["menu.pricing"] = "Pricing",
                ["menu.stations"] = "Stations", ["menu.equipment"] = "Equipment", ["menu.tickets"] = "Tickets",
                ["menu.monitor"] = "Client Monitor", ["menu.chat"] = "Chat", ["menu.announcements"] = "Announcements",
                ["menu.reports"] = "Reports", ["menu.backup"] = "Backup", ["menu.debts"] = "Debts",
                ["menu.print"] = "Print", ["menu.packages"] = "Session Packages", ["menu.tiers"] = "Member Tiers",
                ["menu.security"] = "Security", ["menu.theme"] = "Theme Settings", ["menu.branches"] = "Branches",
                ["menu.payment"] = "Payment Gateway", ["menu.dashboard"] = "Dashboard", ["menu.smartpricing"] = "Smart Pricing",
                ["btn.save"] = "Save", ["btn.cancel"] = "Cancel", ["btn.delete"] = "Delete", ["btn.edit"] = "Edit",
                ["btn.add"] = "Add", ["btn.search"] = "Search", ["btn.refresh"] = "Refresh", ["btn.close"] = "Close",
                ["lbl.username"] = "Username", ["lbl.password"] = "Password", ["lbl.balance"] = "Balance",
                ["lbl.price"] = "Price", ["lbl.time"] = "Time", ["lbl.status"] = "Status", ["lbl.name"] = "Name",
                ["msg.success"] = "Operation completed successfully", ["msg.error"] = "Operation failed",
                ["msg.confirm_delete"] = "Are you sure you want to delete?", ["msg.insufficient_balance"] = "Insufficient balance",
                ["status.active"] = "Active", ["status.inactive"] = "Inactive", ["status.connected"] = "Connected",
                ["status.disconnected"] = "Disconnected", ["status.online"] = "Online", ["status.offline"] = "Offline",
            }
        };

        private string _currentLang = "fa";

        public string CurrentLanguage
        {
            get => _currentLang;
            set { _currentLang = _translations.ContainsKey(value) ? value : "fa"; SaveLanguagePreference(); }
        }

        public string this[string key] => Get(key);

        public string Get(string key)
        {
            if (_translations.TryGetValue(_currentLang, out var lang) && lang.TryGetValue(key, out var val))
                return val;
            if (_translations.TryGetValue("fa", out var faLang) && faLang.TryGetValue(key, out var faVal))
                return faVal;
            return key;
        }

        public string GetFormatted(string key, params object[] args)
        {
            var template = Get(key);
            try { return string.Format(template, args); } catch { return template; }
        }

        public List<string> GetAvailableLanguages() => new List<string>(_translations.Keys);

        private void SaveLanguagePreference()
        {
            try
            {
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                    cmd => { cmd.Parameters.AddWithValue("@k", LangSettingsKey); cmd.Parameters.AddWithValue("@v", _currentLang); });
            }
            catch { }
        }

        public void LoadLanguagePreference()
        {
            try
            {
                var lang = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", LangSettingsKey), r => r.GetString(0));
                if (!string.IsNullOrEmpty(lang) && _translations.ContainsKey(lang)) _currentLang = lang;
            }
            catch { }
        }

        public void AddTranslation(string language, string key, string value)
        {
            if (!_translations.ContainsKey(language)) _translations[language] = new Dictionary<string, string>();
            _translations[language][key] = value;
        }
    }
}
