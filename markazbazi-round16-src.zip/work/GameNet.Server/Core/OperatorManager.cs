﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class OperatorManager
    {
        // ---- Password hashing constants (PBKDF2-SHA256) ----
        private const int Pbkdf2Iterations = 60000;
        private const int SaltSize = 16;
        private const int HashSize = 32;
        private const string NewFormatPrefix = "pbkdf2:";
        // Salt column is NOT NULL on the legacy schema; new-format rows store
        // this placeholder because the real salt is embedded in password_hash.
        private const string NewFormatSaltPlaceholder = "pbkdf2";

        public Operator Authenticate(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                throw new ArgumentException("نام کاربری و رمز عبور نمی‌توانند خالی باشند");
            var op = FindByUsername(username);
            if (op == null) throw new UnauthorizedAccessException("نام کاربری یا رمز عبور اشتباه است");
            if (op.LockedUntil.HasValue && op.LockedUntil > DateTime.UtcNow)
                throw new UnauthorizedAccessException($"حساب قفل شده. {(op.LockedUntil.Value - DateTime.UtcNow).Minutes} دقیقه مانده");

            bool ok = VerifyPassword(password, op.PasswordHash, op.Salt);
            if (!ok)
            {
                op.FailedLoginAttempts++;
                DateTime? locked = op.FailedLoginAttempts >= 5 ? (DateTime?)DateTime.UtcNow.AddMinutes(15) : null;
                Database.Instance.Execute("UPDATE operators SET failed_login_attempts = @a, locked_until = @l WHERE id = @id",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@a", op.FailedLoginAttempts);
                        cmd.Parameters.AddWithValue("@l", (object)locked?.ToString("o") ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@id", op.Id);
                    });
                throw new UnauthorizedAccessException("نام کاربری یا رمز عبور اشتباه است");
            }
            Database.Instance.Execute("UPDATE operators SET failed_login_attempts = 0, locked_until = NULL, last_login_at = @n WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@n", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", op.Id); });

            // Transparent upgrade: legacy SHA-256 (10000 iterations) -> PBKDF2.
            // Done after a successful auth so we know the password is correct.
            if (op.PasswordHash != null && !op.PasswordHash.StartsWith(NewFormatPrefix))
            {
                try
                {
                    string newSalt = NewFormatSaltPlaceholder;
                    string newHash = HashPassword(password);
                    Database.Instance.Execute("UPDATE operators SET password_hash = @h, salt = @s WHERE id = @id",
                        cmd => { cmd.Parameters.AddWithValue("@h", newHash); cmd.Parameters.AddWithValue("@s", newSalt); cmd.Parameters.AddWithValue("@id", op.Id); });
                    AuditLog.Log("OperatorManager", $"Operator {op.Username} password hash upgraded to PBKDF2");
                }
                catch (Exception ex) { AuditLog.Log("OperatorManager", $"Failed to upgrade hash for {op.Username}: {ex.Message}"); }
            }
            return op;
        }

        public Operator CreateOperator(string username, string password, string displayName, OperatorPermission perms, string role = "Operator")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری نمی‌تواند خالی باشد");
            if (string.IsNullOrWhiteSpace(password) || password.Length < 6) throw new ArgumentException("رمز عبور باید حداقل ۶ کاراکتر باشد");
            if (FindByUsername(username) != null) throw new InvalidOperationException("این نام کاربری قبلاً ثبت شده است");
            string hash = HashPassword(password);
            Database.Instance.Execute("INSERT INTO operators (username, password_hash, salt, display_name, permissions, role_name, is_active, created_at, failed_login_attempts) VALUES (@u, @h, @s, @d, @p, @r, 1, @c, 0)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@h", hash);
                    cmd.Parameters.AddWithValue("@s", NewFormatSaltPlaceholder);
                    cmd.Parameters.AddWithValue("@d", displayName ?? username);
                    cmd.Parameters.AddWithValue("@p", (int)perms);
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                });
            return FindByUsername(username);
        }

        public void UpdateOperator(int id, string displayName = null, OperatorPermission? perms = null, string role = null, bool? isActive = null)
        {
            var op = FindById(id); if (op == null) return;
            var sets = new List<string>();
            if (displayName != null) sets.Add("display_name = @d");
            if (perms.HasValue) sets.Add("permissions = @p");
            if (role != null) sets.Add("role_name = @r");
            if (isActive.HasValue) sets.Add("is_active = @a");
            if (sets.Count == 0) return;
            Database.Instance.Execute($"UPDATE operators SET {string.Join(", ", sets)} WHERE id = @id",
                cmd =>
                {
                    if (displayName != null) cmd.Parameters.AddWithValue("@d", displayName);
                    if (perms.HasValue) cmd.Parameters.AddWithValue("@p", (int)perms.Value);
                    if (role != null) cmd.Parameters.AddWithValue("@r", role);
                    if (isActive.HasValue) cmd.Parameters.AddWithValue("@a", isActive.Value);
                    cmd.Parameters.AddWithValue("@id", id);
                });
        }

        public void ChangePassword(int id, string currentPw, string newPw)
        {
            var op = FindById(id);
            if (op == null) throw new KeyNotFoundException();
            // Need full row (with hash + salt) to verify; FindById does not return them, so look up by username.
            var full = FindByUsername(op.Username);
            if (full == null) throw new KeyNotFoundException();
            if (!VerifyPassword(currentPw, full.PasswordHash, full.Salt))
                throw new UnauthorizedAccessException("رمز عبور فعلی اشتباه است");
            Database.Instance.Execute("UPDATE operators SET password_hash = @h, salt = @s WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@h", HashPassword(newPw)); cmd.Parameters.AddWithValue("@s", NewFormatSaltPlaceholder); cmd.Parameters.AddWithValue("@id", id); });
        }

        public void ResetPassword(int id, string newPw)
        {
            Database.Instance.Execute("UPDATE operators SET password_hash = @h, salt = @s, failed_login_attempts = 0, locked_until = NULL WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@h", HashPassword(newPw)); cmd.Parameters.AddWithValue("@s", NewFormatSaltPlaceholder); cmd.Parameters.AddWithValue("@id", id); });
        }

        public bool HasPermission(int id, OperatorPermission perm)
        {
            return HasPermission(FindById(id), perm); // round 14: same rule as below
        }

        /// <summary>Convenience overload accepting an <see cref="Operator"/> instance.</summary>
        public bool HasPermission(Operator op, OperatorPermission perm)
        {
            if (op == null || !op.IsActive) return false;
            // Round 14: the system administrator (role SuperAdmin, or any account that may
            // manage operators and could give itself every right anyway) has every right.
            // An admin account created by an older version had only the rights that
            // existed then, so the newer PRO modules were closed to the owner.
            if (IsFullAdmin(op)) return true;
            return (op.Permissions & perm) == perm;
        }

        public static bool IsFullAdmin(Operator op)
        {
            return op != null && op.IsActive &&
                   (string.Equals(op.RoleName, "SuperAdmin", StringComparison.OrdinalIgnoreCase) ||
                    (op.Permissions & OperatorPermission.ManageOperators) == OperatorPermission.ManageOperators);
        }

        public List<Operator> GetAllOperators() => Database.Instance.Query("SELECT id, username, display_name, permissions, role_name, is_active, created_at, last_login_at, failed_login_attempts, locked_until FROM operators ORDER BY username", null, MapOp);

        public Operator FindById(int id) => Database.Instance.QueryOne("SELECT id, username, display_name, permissions, role_name, is_active, created_at, last_login_at, failed_login_attempts, locked_until FROM operators WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", id), MapOp);

        public Operator FindByUsername(string username) => Database.Instance.QueryOne("SELECT id, username, password_hash, salt, display_name, permissions, role_name, is_active, created_at, last_login_at, failed_login_attempts, locked_until FROM operators WHERE username = @u", cmd => cmd.Parameters.AddWithValue("@u", username), r =>
        {
            var op = new Operator();
            op.Id = r.GetInt32(0); op.Username = r.GetString(1); op.PasswordHash = r.GetString(2); op.Salt = r.GetString(3);
            op.DisplayName = r.IsDBNull(4) ? r.GetString(1) : r.GetString(4); op.Permissions = (OperatorPermission)r.GetInt32(5);
            op.RoleName = r.IsDBNull(6) ? "Operator" : r.GetString(6); op.IsActive = r.GetBoolean(7); op.CreatedAt = r.GetDateTime(8);
            op.LastLoginAt = r.IsDBNull(9) ? (DateTime?)null : r.GetDateTime(9); op.FailedLoginAttempts = r.IsDBNull(10) ? 0 : r.GetInt32(10);
            op.LockedUntil = r.IsDBNull(11) ? (DateTime?)null : r.GetDateTime(11);
            return op;
        });

        private Operator MapOp(System.Data.Common.DbDataReader r) => new Operator
        {
            Id = r.GetInt32(0), Username = r.GetString(1),
            DisplayName = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2),
            Permissions = (OperatorPermission)r.GetInt32(3),
            RoleName = r.IsDBNull(4) ? "Operator" : r.GetString(4),
            IsActive = r.GetBoolean(5), CreatedAt = r.GetDateTime(6),
            LastLoginAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
            FailedLoginAttempts = r.IsDBNull(8) ? 0 : r.GetInt32(8),
            LockedUntil = r.IsDBNull(9) ? (DateTime?)null : r.GetDateTime(9)
        };

        // =========================================================================
        // Password hashing (PBKDF2-SHA256, 60000 iterations, per-user salt).
        // New stored format: "pbkdf2:{iter}:{base64salt}:{base64hash}".
        // Legacy rows store SHA-256(pw+salt) iterated 10000 times, with the
        // 32-byte salt in the salt column and the base64 hash in password_hash.
        // =========================================================================

        private static string HashPassword(string pw)
        {
            if (pw == null) throw new ArgumentNullException(nameof(pw));
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var pbkdf2 = new Rfc2898DeriveBytes(pw, salt, Pbkdf2Iterations, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(HashSize);
                return $"{NewFormatPrefix}{Pbkdf2Iterations}:{Convert.ToBase64String(salt)}:{Convert.ToBase64String(hash)}";
            }
        }

        private static bool VerifyPassword(string pw, string storedHash, string storedSalt)
        {
            if (string.IsNullOrEmpty(pw) || string.IsNullOrEmpty(storedHash)) return false;

            // New PBKDF2 format.
            if (storedHash.StartsWith(NewFormatPrefix))
            {
                var body = storedHash.Substring(NewFormatPrefix.Length);
                var parts = body.Split(':');
                if (parts.Length != 3) return false;
                if (!int.TryParse(parts[0], out int iter) || iter <= 0) return false;
                byte[] salt; byte[] expected;
                try { salt = Convert.FromBase64String(parts[1]); expected = Convert.FromBase64String(parts[2]); }
                catch { return false; }
                if (expected.Length == 0) return false;
                using (var pbkdf2 = new Rfc2898DeriveBytes(pw, salt, iter, HashAlgorithmName.SHA256))
                {
                    byte[] actual = pbkdf2.GetBytes(expected.Length);
                    return CryptographicEquals(actual, expected);
                }
            }

            // Legacy: 10000 iterations of SHA-256(pw + salt) with the salt stored
            // in the salt column. Verify then upgrade on success.
            if (string.IsNullOrEmpty(storedSalt)) return false;
            string legacy = LegacyHashPassword(pw, storedSalt);
            return ConstantTimeStringEquals(legacy, storedHash);
        }

        private static bool ConstantTimeStringEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        private static bool CryptographicEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        /// <summary>
        /// LEGACY: 10000 iterations of SHA-256(pw + base64salt). Kept ONLY so
        /// pre-existing operator rows can be verified and transparently
        /// upgraded to PBKDF2 on the next successful login.
        /// </summary>
        private static string LegacyHashPassword(string pw, string salt)
        {
            using (var sha = SHA256.Create())
            {
                var h = sha.ComputeHash(Encoding.UTF8.GetBytes(pw + salt));
                for (int i = 0; i < 10000; i++) h = sha.ComputeHash(h);
                return Convert.ToBase64String(h);
            }
        }

        // =========================================================================
        // Default operator bootstrap - generates a random one-time password and
        // writes it to admin_initial_password.txt in the app base directory.
        // =========================================================================

        /// <summary>
        /// Creates the initial super-admin operator with a randomly generated
        /// one-time password (16 alphanumeric chars) if no operators exist.
        /// The password is written to admin_initial_password.txt next to the
        /// executable and printed to the console. The operator must change it
        /// on first login and delete the file. No hardcoded default password.
        /// </summary>
        /// <summary>
        /// FIX SEC-1: cryptographically random alphanumeric password for the
        /// one-time default admin account (replaces the old hardcoded
        /// "password" literal). Excludes visually ambiguous characters
        /// (0/O, 1/l/I) since a human has to read this off a text file and
        /// type it once. Internal (not private) so UserManager.EnsureDefaultUser
        /// can reuse the exact same generator for the separate client-login
        /// default account instead of duplicating the logic.
        /// </summary>
        internal static string GenerateRandomInitialPassword(int length = 16)
        {
            const string chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
            var sb = new StringBuilder(length);
            using (var rng = RandomNumberGenerator.Create())
            {
                var buf = new byte[4];
                for (int i = 0; i < length; i++)
                {
                    rng.GetBytes(buf);
                    uint val = BitConverter.ToUInt32(buf, 0);
                    sb.Append(chars[(int)(val % (uint)chars.Length)]);
                }
            }
            return sb.ToString();
        }

        public static void EnsureDefaultOperator()
        {
            // FIX B4: wrap the entire method body in try/catch. This runs at
            // startup BEFORE the operator login form is shown — if it throws
            // (e.g. SQLite DB locked, schema missing operators table, corrupted
            // row), the server would crash silently with no error dialog.
            // Now the exception is logged + swallowed so the login form can
            // still appear; the operator can then use the OptionsForm to
            // diagnose / repair.
            try
            {
                var mgr = new OperatorManager();
                string username = "admin";
                // Plain default password — no prefix, no suffix, no random
                // one-time value, no extra text file. The user explicitly
                // asked for the simplest default so the server opens straight
                // into the admin panel after install.
                string password = "password";

                // If no operators exist at all, create the default admin.
                // Otherwise LEAVE the password alone — if the operator changed it,
                // we must NOT silently reset it on every restart.
                if (mgr.GetAllOperators().Count == 0)
                {
                    mgr.CreateOperator(username, password, "مدیر سیستم", OperatorPermission.FullAccess, "SuperAdmin");
                    AuditLog.Log("OperatorManager", "Default admin account created (username=admin, password=password). Please change the password from the operator panel.");
                    return;
                }
                else
                {
                    // If admin exists but is locked out (too many failed attempts),
                    // unlock it so the operator can log in. Do NOT reset the password.
                    var admin = mgr.FindByUsername(username);
                    if (admin != null && admin.LockedUntil.HasValue && admin.LockedUntil.Value > DateTime.UtcNow)
                    {
                        try
                        {
                            Database.Instance.Execute(
                                "UPDATE operators SET failed_login_attempts = 0, locked_until = NULL WHERE id = @id",
                                cmd => cmd.Parameters.AddWithValue("@id", admin.Id));
                            AuditLog.Log("OperatorManager", "Admin account unlocked on startup (was locked due to failed attempts). Password NOT changed.");
                        }
                        catch { }
                    }
                }

                // Print to console so the credentials are visible on every run.
                Console.WriteLine("============================================================");
                Console.WriteLine(" GameNet admin login:");
                Console.WriteLine("   Username: admin");
                Console.WriteLine("   Password: password");
                Console.WriteLine(" CHANGE THIS PASSWORD IMMEDIATELY via the operator");
                Console.WriteLine(" management screen in a production environment.");
                Console.WriteLine("============================================================");
            }
            catch (Exception ex)
            {
                try { AuditLog.Log("OperatorManager", "EnsureDefaultOperator failed: " + ex.Message); } catch { }
            }
        }

        /// <summary>Generates a cryptographically strong alphanumeric password.</summary>
        private static string GenerateOneTimePassword(int length)
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
            var bytes = new byte[length];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(bytes);
            var sb = new StringBuilder(length);
            for (int i = 0; i < length; i++) sb.Append(alphabet[bytes[i] % alphabet.Length]);
            return sb.ToString();
        }
    }
}
