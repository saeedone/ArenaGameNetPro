using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages real-time chat between operators and clients.
    /// Supports direct messages, broadcast messages, and system notifications.
    /// </summary>
    public class ChatManager
    {
        /// <summary>
        /// Sends a chat message from one user to another or broadcasts to all.
        /// </summary>
        public ChatReceivePayload SendMessage(string senderUsername, string message, string targetUsername = null, bool isBroadcast = false)
        {
            if (string.IsNullOrWhiteSpace(message)) throw new ArgumentException("پیام نمی‌تواند خالی باشد");
            if (message.Length > 2000) throw new ArgumentException("پیام نمی‌تواند بیشتر از ۲۰۰۰ کاراکتر باشد");

            Database.Instance.Execute(
                "INSERT INTO chat_messages (sender_username, target_username, message, is_broadcast, is_system, created_at) VALUES (@sender, @target, @msg, @bcast, 0, @ca)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@sender", senderUsername);
                    cmd.Parameters.AddWithValue("@target", targetUsername ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@msg", message);
                    cmd.Parameters.AddWithValue("@bcast", isBroadcast ? 1 : 0);
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                });

            var senderDisplay = Database.Instance.QueryOne(
                "SELECT COALESCE(display_name, username) FROM users WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", senderUsername),
                r => r.GetString(0)) ?? senderUsername;

            return new ChatReceivePayload
            {
                SenderUsername = senderUsername,
                SenderDisplayName = senderDisplay,
                Message = message,
                Timestamp = DateTime.UtcNow,
                IsBroadcast = isBroadcast,
                IsSystem = false
            };
        }

        /// <summary>
        /// Sends a system notification message (not from a user).
        /// </summary>
        public ChatReceivePayload SendSystemMessage(string message, string targetUsername = null, bool isBroadcast = true)
        {
            Database.Instance.Execute(
                "INSERT INTO chat_messages (sender_username, target_username, message, is_broadcast, is_system, created_at) VALUES ('system', @target, @msg, @bcast, 1, @ca)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@target", targetUsername ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@msg", message);
                    cmd.Parameters.AddWithValue("@bcast", isBroadcast ? 1 : 0);
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                });

            return new ChatReceivePayload
            {
                SenderUsername = "system",
                SenderDisplayName = "سیستم",
                Message = message,
                Timestamp = DateTime.UtcNow,
                IsBroadcast = isBroadcast,
                IsSystem = true
            };
        }

        /// <summary>
        /// Gets chat history for a user, including broadcast and direct messages.
        /// </summary>
        public ChatHistoryPayload GetHistory(string username, int limit = 100)
        {
            var messages = Database.Instance.Query(
                "SELECT sender_username, COALESCE((SELECT COALESCE(display_name, username) FROM users WHERE username = c.sender_username), c.sender_username), message, is_broadcast, is_system, created_at FROM chat_messages c WHERE target_username IS NULL OR target_username = @u OR sender_username = @u OR is_broadcast = 1 ORDER BY created_at DESC LIMIT @lim",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@lim", limit);
                },
                r => new ChatReceivePayload
                {
                    SenderUsername = r.GetString(0),
                    SenderDisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                    Message = r.GetString(2),
                    IsBroadcast = r.GetBoolean(3),
                    IsSystem = r.GetBoolean(4),
                    Timestamp = r.GetDateTime(5)
                });

            messages.Reverse(); // Return in chronological order
            return new ChatHistoryPayload { Messages = messages };
        }

        /// <summary>
        /// Gets conversation between two specific users.
        /// </summary>
        public ChatHistoryPayload GetConversation(string user1, string user2, int limit = 50)
        {
            var messages = Database.Instance.Query(
                "SELECT sender_username, COALESCE((SELECT COALESCE(display_name, username) FROM users WHERE username = c.sender_username), c.sender_username), message, 0, is_system, created_at FROM chat_messages c WHERE (sender_username = @u1 AND target_username = @u2) OR (sender_username = @u2 AND target_username = @u1) ORDER BY created_at DESC LIMIT @lim",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u1", user1);
                    cmd.Parameters.AddWithValue("@u2", user2);
                    cmd.Parameters.AddWithValue("@lim", limit);
                },
                r => new ChatReceivePayload
                {
                    SenderUsername = r.GetString(0),
                    SenderDisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                    Message = r.GetString(2),
                    IsBroadcast = false,
                    IsSystem = r.GetBoolean(4),
                    Timestamp = r.GetDateTime(5)
                });

            messages.Reverse();
            return new ChatHistoryPayload { Messages = messages };
        }

        /// <summary>
        /// Gets recent broadcast and system messages.
        /// </summary>
        public ChatHistoryPayload GetRecentBroadcasts(int limit = 20)
        {
            var messages = Database.Instance.Query(
                "SELECT sender_username, COALESCE((SELECT COALESCE(display_name, username) FROM users WHERE username = c.sender_username), c.sender_username), message, is_broadcast, is_system, created_at FROM chat_messages c WHERE is_broadcast = 1 OR is_system = 1 ORDER BY created_at DESC LIMIT @lim",
                cmd => cmd.Parameters.AddWithValue("@lim", limit),
                r => new ChatReceivePayload
                {
                    SenderUsername = r.GetString(0),
                    SenderDisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                    Message = r.GetString(2),
                    IsBroadcast = r.GetBoolean(3),
                    IsSystem = r.GetBoolean(4),
                    Timestamp = r.GetDateTime(5)
                });

            messages.Reverse();
            return new ChatHistoryPayload { Messages = messages };
        }

        /// <summary>
        /// Deletes old chat messages beyond the retention period.
        /// </summary>
        public int CleanupOldMessages(int retentionDays = 90)
        {
            var cutoff = DateTime.UtcNow.AddDays(-retentionDays).ToString("o");
            Database.Instance.Execute(
                "DELETE FROM chat_messages WHERE created_at < @cutoff",
                cmd => cmd.Parameters.AddWithValue("@cutoff", cutoff));

            int deleted = Database.Instance.QueryOne(
                "SELECT changes()", null, r => r.GetInt32(0));

            if (deleted > 0)
                AuditLog.Log("ChatManager", $"Cleaned up {deleted} old chat messages (older than {retentionDays} days)");

            return deleted;
        }

        /// <summary>
        /// Gets count of unread messages for a user since a given timestamp.
        /// </summary>
        public int GetUnreadCount(string username, DateTime since)
        {
            return Database.Instance.QueryOne(
                "SELECT COUNT(*) FROM chat_messages WHERE (target_username = @u OR is_broadcast = 1) AND sender_username != @u AND created_at > @since",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@since", since.ToString("o"));
                },
                r => r.GetInt32(0));
        }
    }
}
