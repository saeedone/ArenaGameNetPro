using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase — Loyalty / rewards system + discount codes.
    ///
    /// Two complementary subsystems:
    ///
    /// 1. LOYALTY POINTS
    ///    Every ended session awards the user points (default: 1 point per
    ///    10,000 Toman spent). Points accumulate per-user in the
    ///    `loyalty_points` table and can be redeemed for account credit at
    ///    a configurable rate (default: 1,000 Toman per point). The
    ///    operator sets the earn-rate and redeem-rate via the settings
    ///    table; changes apply to future sessions only.
    ///
    /// 2. DISCOUNT CODES
    ///    The operator generates alphanumeric codes (e.g. SUMMER20 = 20%
    ///    off the next session). Codes are stored in `discount_codes` with
    ///    a type (Percent / Fixed), value, max-uses, current-uses, expiry,
    ///    and active flag. A user applies a code at session-start; the
    ///    discount is applied to the session cost at session-end. Codes
    ///    can be single-use-per-user or unlimited.
    ///
    /// Both subsystems use atomic conditional UPDATEs + transactions so
    /// concurrent redemptions cannot over-spend points or over-use codes.
    /// </summary>
    public class LoyaltyManager
    {
        // ---- Loyalty points ----

        /// <summary>
        /// Awards loyalty points to a user for a session. Called by the
        /// billing cycle when a session ends. Points = floor(cost / earnRate).
        /// </summary>
        public int AwardPoints(string username, decimal sessionCost)
        {
            if (string.IsNullOrEmpty(username) || sessionCost <= 0) return 0;
            decimal earnRate = GetSettingDecimal("loyalty_earn_rate", 10000m); // 1 point per 10k Toman
            if (earnRate <= 0) return 0;
            int points = (int)Math.Floor(sessionCost / earnRate);
            if (points <= 0) return 0;

            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Upsert into loyalty_points
                    Database.Instance.Execute(
                        "INSERT INTO loyalty_points (username, points, total_earned, updated_at) VALUES (@u, @p, @p, @t) " +
                        "ON CONFLICT(username) DO UPDATE SET points = points + @p, total_earned = total_earned + @p, updated_at = @t",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@p", points);
                            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        }, tx);

                    // Log the award
                    Database.Instance.Execute(
                        "INSERT INTO loyalty_history (username, points, reason, session_cost, created_at) VALUES (@u, @p, @r, @c, @t)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@p", points);
                            cmd.Parameters.AddWithValue("@r", "جلسه بازی");
                            cmd.Parameters.AddWithValue("@c", sessionCost);
                            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        }, tx);
                });
                AuditLog.Log("Loyalty", $"Awarded {points} points to {username} (cost {sessionCost:N0})");
                return points;
            }
            catch (Exception ex)
            {
                AuditLog.Log("Loyalty", $"AwardPoints error for {username}: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// Returns the user's current redeemable point balance.
        /// </summary>
        public int GetPoints(string username)
        {
            if (string.IsNullOrEmpty(username)) return 0;
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT points FROM loyalty_points WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", username),
                    r => r.GetInt32(0));
            }
            catch { return 0; }
        }

        /// <summary>
        /// Returns (points, total_earned, total_redeemed).
        /// </summary>
        public (int Points, int TotalEarned, int TotalRedeemed) GetPointSummary(string username)
        {
            if (string.IsNullOrEmpty(username)) return (0, 0, 0);
            try
            {
                return Database.Instance.QueryOne(
                    "SELECT points, total_earned, total_redeemed FROM loyalty_points WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", username),
                    r => (r.GetInt32(0), r.GetInt32(1), r.GetInt32(2)));
            }
            catch { return (0, 0, 0); }
        }

        /// <summary>
        /// Redeems points for account credit. Points are deducted atomically
        /// and credit added to the user's balance. Returns the credit amount
        /// granted, or 0 if insufficient points.
        /// </summary>
        public decimal RedeemPoints(string username, int points)
        {
            if (string.IsNullOrEmpty(username) || points <= 0) return 0;
            decimal redeemRate = GetSettingDecimal("loyalty_redeem_rate", 1000m); // 1k Toman per point

            decimal credit = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Atomically deduct points (conditional — only if balance >= points)
                    int rows = Database.Instance.ExecuteNonQuery(
                        "UPDATE loyalty_points SET points = points - @p, total_redeemed = total_redeemed + @p, updated_at = @t WHERE username = @u AND points >= @p",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@p", points);
                            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        }, tx);

                    if (rows == 0) throw new InvalidOperationException("امتیاز کافی نیست.");

                    credit = points * redeemRate;

                    // Add credit to user
                    Database.Instance.Execute(
                        "UPDATE users SET balance = balance + @c WHERE username = @u",
                        cmd => { cmd.Parameters.AddWithValue("@c", credit); cmd.Parameters.AddWithValue("@u", username); }, tx);

                    // Log redemption
                    Database.Instance.Execute(
                        "INSERT INTO loyalty_history (username, points, reason, session_cost, created_at) VALUES (@u, @p, @r, 0, @t)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@p", -points); // negative = redemption
                            cmd.Parameters.AddWithValue("@r", $"تبدیل به اعتبار ({credit:N0} تومان)");
                            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        }, tx);
                });
                AuditLog.Log("Loyalty", $"{username} redeemed {points} points for {credit:N0} Toman");
                return credit;
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex)
            {
                AuditLog.Log("Loyalty", $"RedeemPoints error for {username}: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// Returns the loyalty history (awards + redemptions) for a user.
        /// </summary>
        public List<(int Points, string Reason, decimal SessionCost, DateTime CreatedAt)> GetHistory(string username, int limit = 50)
        {
            if (string.IsNullOrEmpty(username)) return new List<(int, string, decimal, DateTime)>();
            try
            {
                return Database.Instance.Query(
                    "SELECT points, reason, session_cost, created_at FROM loyalty_history WHERE username = @u ORDER BY id DESC LIMIT @lim",
                    cmd => { cmd.Parameters.AddWithValue("@u", username); cmd.Parameters.AddWithValue("@lim", limit); },
                    r => (r.GetInt32(0), r.GetString(1), r.IsDBNull(2) ? 0m : r.GetDecimal(2), r.GetDateTime(3)));
            }
            catch { return new List<(int, string, decimal, DateTime)>(); }
        }

        // ---- Discount codes ----

        /// <summary>
        /// Generates a new discount code. Returns the generated code string.
        /// </summary>
        public string CreateDiscountCode(string code, string discountType, decimal value, int maxUses = 0, DateTime? expiry = null, bool singleUsePerUser = false, string description = "")
        {
            if (string.IsNullOrWhiteSpace(code)) code = GenerateRandomCode(8);
            if (discountType != "Percent" && discountType != "Fixed") throw new ArgumentException("نوع تخفیف باید Percent یا Fixed باشد");
            if (value <= 0) throw new ArgumentException("مقدار تخفیف باید بیشتر از صفر باشد");
            if (discountType == "Percent" && value > 100) throw new ArgumentException("درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد");

            try
            {
                Database.Instance.Execute(
                    "INSERT INTO discount_codes (code, discount_type, value, max_uses, current_uses, expiry, single_use_per_user, is_active, description, created_at) " +
                    "VALUES (@c, @t, @v, @m, 0, @e, @s, 1, @d, @ct)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@c", code.ToUpperInvariant());
                        cmd.Parameters.AddWithValue("@t", discountType);
                        cmd.Parameters.AddWithValue("@v", value);
                        cmd.Parameters.AddWithValue("@m", maxUses);
                        cmd.Parameters.AddWithValue("@e", expiry?.ToString("o") ?? "");
                        cmd.Parameters.AddWithValue("@s", singleUsePerUser ? 1 : 0);
                        cmd.Parameters.AddWithValue("@d", description ?? "");
                        cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                    });
                AuditLog.Log("Discount", $"Code created: {code} ({discountType} {value}, max {maxUses})");
                return code.ToUpperInvariant();
            }
            catch (Exception ex) { AuditLog.Log("Discount", "Create error: " + ex.Message); throw; }
        }

        /// <summary>
        /// Validates a discount code without consuming it. Returns (valid, type, value, error).
        /// </summary>
        public (bool Valid, string Type, decimal Value, string Error) ValidateCode(string code, string username)
        {
            if (string.IsNullOrEmpty(code)) return (false, "", 0, "کد خالی است.");
            try
            {
                var row = Database.Instance.QueryOne(
                    "SELECT discount_type, value, max_uses, current_uses, expiry, single_use_per_user, is_active FROM discount_codes WHERE code = @c",
                    cmd => cmd.Parameters.AddWithValue("@c", code.ToUpperInvariant()),
                    r => (Type: r.GetString(0), Value: r.GetDecimal(1), MaxUses: r.GetInt32(2), CurrentUses: r.GetInt32(3), Expiry: r.IsDBNull(4) ? "" : r.GetString(4), SingleUse: r.GetBoolean(5), IsActive: r.GetBoolean(6)));

                if (row.Equals(default)) return (false, "", 0, "کد یافت نشد.");
                if (!row.IsActive) return (false, "", 0, "کد غیرفعال است.");
                if (row.MaxUses > 0 && row.CurrentUses >= row.MaxUses) return (false, "", 0, "سقف استفاده از این کد تمام شده است.");
                if (!string.IsNullOrEmpty(row.Expiry) && DateTime.TryParse(row.Expiry, out DateTime exp) && exp < DateTime.UtcNow)
                    return (false, "", 0, "کد منقضی شده است.");

                if (row.SingleUse && !string.IsNullOrEmpty(username))
                {
                    int usedCount = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM discount_usage WHERE code = @c AND username = @u",
                        cmd => { cmd.Parameters.AddWithValue("@c", code.ToUpperInvariant()); cmd.Parameters.AddWithValue("@u", username); },
                        r => r.GetInt32(0));
                    if (usedCount > 0) return (false, "", 0, "شما قبلاً از این کد استفاده کرده‌اید.");
                }

                return (true, row.Type, row.Value, "");
            }
            catch (Exception ex) { return (false, "", 0, "خطا: " + ex.Message); }
        }

        /// <summary>
        /// Consumes a discount code for a user (marks it used). Called when a
        /// session starts with a valid code. Atomic — increments
        /// current_uses and inserts a usage row in one transaction.
        /// </summary>
        public bool ConsumeCode(string code, string username, string sessionId)
        {
            if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(username)) return false;
            try
            {
                int rows = 0;
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    rows = Database.Instance.ExecuteNonQuery(
                        "UPDATE discount_codes SET current_uses = current_uses + 1 WHERE code = @c AND is_active = 1 AND (max_uses = 0 OR current_uses < max_uses)",
                        cmd => cmd.Parameters.AddWithValue("@c", code.ToUpperInvariant()), tx);

                    if (rows > 0)
                    {
                        Database.Instance.Execute(
                            "INSERT INTO discount_usage (code, username, session_id, used_at) VALUES (@c, @u, @s, @t)",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@c", code.ToUpperInvariant());
                                cmd.Parameters.AddWithValue("@u", username);
                                cmd.Parameters.AddWithValue("@s", sessionId ?? "");
                                cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                            }, tx);
                    }
                });
                if (rows > 0) AuditLog.Log("Discount", $"Code {code} used by {username}");
                return rows > 0;
            }
            catch (Exception ex) { AuditLog.Log("Discount", "Consume error: " + ex.Message); return false; }
        }

        /// <summary>
        /// Applies a discount to a session cost. Returns the discounted cost.
        /// </summary>
        public decimal ApplyDiscount(decimal originalCost, string discountType, decimal value)
        {
            if (discountType == "Percent")
                return Math.Round(originalCost * (1 - value / 100m), 0);
            if (discountType == "Fixed")
                return Math.Max(0, originalCost - value);
            return originalCost;
        }

        /// <summary>
        /// Returns all discount codes (for the management UI).
        /// </summary>
        public List<(int Id, string Code, string Type, decimal Value, int MaxUses, int CurrentUses, string Expiry, bool SingleUse, bool IsActive, string Description)> GetAllCodes()
        {
            try
            {
                return Database.Instance.Query(
                    "SELECT id, code, discount_type, value, max_uses, current_uses, expiry, single_use_per_user, is_active, description FROM discount_codes ORDER BY id DESC",
                    null,
                    r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetDecimal(3), r.GetInt32(4), r.GetInt32(5),
                          r.IsDBNull(6) ? "" : r.GetString(6), r.GetBoolean(7), r.GetBoolean(8), r.IsDBNull(9) ? "" : r.GetString(9)));
            }
            catch { return new List<(int, string, string, decimal, int, int, string, bool, bool, string)>(); }
        }

        /// <summary>Deactivates a discount code.</summary>
        public void DeactivateCode(int id)
        {
            Database.Instance.Execute("UPDATE discount_codes SET is_active = 0 WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("Discount", $"Code #{id} deactivated");
        }

        /// <summary>Deletes a discount code.</summary>
        public void DeleteCode(int id)
        {
            Database.Instance.Execute("DELETE FROM discount_codes WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("Discount", $"Code #{id} deleted");
        }

        // ---- Helpers ----

        private string GenerateRandomCode(int length)
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            var bytes = new byte[length];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(bytes);
            var sb = new StringBuilder(length);
            for (int i = 0; i < length; i++) sb.Append(alphabet[bytes[i] % alphabet.Length]);
            return sb.ToString();
        }

        private decimal GetSettingDecimal(string key, decimal defaultValue)
        {
            try
            {
                var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key), r => r.GetString(0));
                return decimal.TryParse(v, out decimal d) ? d : defaultValue;
            }
            catch { return defaultValue; }
        }

        private void SetSetting(string key, string value)
        {
            Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                cmd => { cmd.Parameters.AddWithValue("@k", key); cmd.Parameters.AddWithValue("@v", value); });
        }

        public void SetEarnRate(decimal rate) => SetSetting("loyalty_earn_rate", rate.ToString());
        public void SetRedeemRate(decimal rate) => SetSetting("loyalty_redeem_rate", rate.ToString());
        public decimal GetEarnRate() => GetSettingDecimal("loyalty_earn_rate", 10000m);
        public decimal GetRedeemRate() => GetSettingDecimal("loyalty_redeem_rate", 1000m);
    }
}
