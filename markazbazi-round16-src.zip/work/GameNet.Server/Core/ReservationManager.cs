using System;
using System.Collections.Generic;
using System.Data.SQLite;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class ReservationManager
    {
        /// <summary>
        /// Create a reservation for a station. Validates:
        ///   - username / stationName non-empty
        ///   - endTime &gt; startTime
        ///   - the station exists in the stations table
        ///   - no overlapping 'active' reservation exists for the same station
        ///     (overlap = new start &lt; existing end AND new end &gt; existing start)
        /// The overlap check and the insert run in a single transaction so a
        /// concurrent reservation for the same slot cannot slip in between the
        /// check and the insert (the Database lock is held for the whole txn).
        /// </summary>
        public int Create(string username, string stationName, DateTime startTime, DateTime endTime, string notes = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (string.IsNullOrWhiteSpace(stationName)) throw new ArgumentException("نام ایستگاه الزامی است");
            if (endTime <= startTime) throw new ArgumentException("زمان پایان باید بعد از زمان شروع باشد");

            // Verify the user exists.
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            // Verify the station exists.
            var station = new StationManager().FindByName(stationName);
            if (station == null) throw new InvalidOperationException($"ایستگاه «{stationName}» یافت نشد");

            int reservationId = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Overlap check inside the txn — the lock held by
                    // ExecuteInTransaction guarantees no other thread can
                    // insert a conflicting reservation between this COUNT and
                    // our INSERT. SQLite does not support SELECT ... FOR UPDATE
                    // but the single-writer lock serves the same purpose.
                    int overlaps = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM reservations WHERE station_name = @s AND status = 'active' AND (start_time < @end AND end_time > @start)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@s", stationName);
                            cmd.Parameters.AddWithValue("@start", startTime.ToString("o"));
                            cmd.Parameters.AddWithValue("@end", endTime.ToString("o"));
                        }, r => r.GetInt32(0), tx);

                    if (overlaps > 0)
                        throw new InvalidOperationException("در این بازه زمانی رزرو دیگری برای این ایستگاه وجود دارد");

                    Database.Instance.Execute(
                        "INSERT INTO reservations (username, station_name, start_time, end_time, status, created_at, notes) VALUES (@u, @s, @st, @et, 'active', @ct, @n)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@s", stationName);
                            cmd.Parameters.AddWithValue("@st", startTime.ToString("o"));
                            cmd.Parameters.AddWithValue("@et", endTime.ToString("o"));
                            cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                            cmd.Parameters.AddWithValue("@n", notes ?? "");
                        }, tx);

                    reservationId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
                });
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex)
            {
                AuditLog.Log("ReservationManager", $"Create failed for {username}/{stationName}: {ex.Message}");
                throw;
            }

            AuditLog.Log("ReservationManager", $"Reservation #{reservationId} created: {username} on {stationName} ({startTime:o} .. {endTime:o})");
            try { ActivityJournal.Record(ActivityJournal.Reservation, "رزرو برای «" + username + "» " + startTime.ToString("MM/dd HH:mm") + " تا " + endTime.ToString("HH:mm"), stationName); } catch { } // round 14
            return reservationId;
        }

        /// <summary>
        /// Cancel a reservation. Validates that the reservation exists and
        /// that the caller supplied a non-empty reason. NOTE: actual operator
        /// authorization (is the caller allowed to cancel this user's
        /// reservation?) must be enforced at the MainForm / MobileApiController
        /// layer which has the current operator identity; this method only
        /// enforces the data-integrity constraints.
        /// </summary>
        public void Cancel(int id, string reason)
        {
            if (string.IsNullOrWhiteSpace(reason))
                throw new ArgumentException("دلیل لغو رزرو الزامی است");

            var reservation = Database.Instance.QueryOne(
                "SELECT id, status FROM reservations WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new { Id = r.GetInt32(0), Status = r.GetString(1) });

            if (reservation == null) throw new KeyNotFoundException("رزرو یافت نشد");
            if (reservation.Status == "cancelled") throw new InvalidOperationException("این رزرو قبلاً لغو شده است");

            int rows = Database.Instance.ExecuteNonQuery(
                "UPDATE reservations SET status = 'cancelled', notes = COALESCE(notes, '') || ' | لغو: ' || @r WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@r", reason); cmd.Parameters.AddWithValue("@id", id); });

            if (rows > 0)
            {
                AuditLog.Log("ReservationManager", $"Reservation #{id} cancelled. Reason: {reason}");
                try { ActivityJournal.Record(ActivityJournal.Reservation, "لغو رزرو #" + id + " — " + reason); } catch { } // round 14
            }
        }

        /// <summary>
        /// Round 11: quick reservation from the monitoring right-click menu. The
        /// customer is a name (walk-in customers usually have no account) and the
        /// station is the one the operator right-clicked, so neither is looked up in
        /// the users / stations tables (a connected PC is often not in the stations
        /// table, and Create() refused it). The overlap check is the same as Create().
        /// </summary>
        public int CreateQuick(string customerName, string stationName, DateTime startTime, DateTime endTime, string phone = "")
        {
            if (string.IsNullOrWhiteSpace(customerName)) throw new ArgumentException("نام مشتری را وارد کنید");
            if (string.IsNullOrWhiteSpace(stationName)) throw new ArgumentException("نام ایستگاه الزامی است");
            if (endTime <= startTime) throw new ArgumentException("زمان پایان باید بعد از زمان شروع باشد");
            if (endTime <= DateTime.Now) throw new ArgumentException("این زمان گذشته است");
            customerName = customerName.Trim();
            string notes = string.IsNullOrWhiteSpace(phone) ? "رزرو سریع" : "رزرو سریع | تلفن: " + phone.Trim();

            int reservationId = 0;
            Database.Instance.ExecuteInTransaction(tx =>
            {
                int overlaps = Database.Instance.QueryOne(
                    "SELECT COUNT(*) FROM reservations WHERE station_name = @s AND status = 'active' AND (start_time < @end AND end_time > @start)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@s", stationName);
                        cmd.Parameters.AddWithValue("@start", startTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@end", endTime.ToString("o"));
                    }, r => r.GetInt32(0), tx);
                if (overlaps > 0)
                    throw new InvalidOperationException("در این بازه زمانی رزرو دیگری برای این ایستگاه وجود دارد");

                Database.Instance.Execute(
                    "INSERT INTO reservations (username, station_name, start_time, end_time, status, created_at, notes) VALUES (@u, @s, @st, @et, 'active', @ct, @n)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", customerName);
                        cmd.Parameters.AddWithValue("@s", stationName);
                        cmd.Parameters.AddWithValue("@st", startTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@et", endTime.ToString("o"));
                        cmd.Parameters.AddWithValue("@ct", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@n", notes);
                    }, tx);
                reservationId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);
            });
            AuditLog.Log("ReservationManager", $"Quick reservation #{reservationId}: {customerName} on {stationName} ({startTime:o} .. {endTime:o})");
            try { ActivityJournal.Record(ActivityJournal.Reservation, "رزرو برای «" + customerName + "» " + startTime.ToString("MM/dd HH:mm") + " تا " + endTime.ToString("HH:mm"), stationName); } catch { } // round 14
            return reservationId;
        }

        /// <summary>
        /// Round 11: active reservations of one station that have not ended yet,
        /// soonest first (for the right-click menu).
        /// </summary>
        public List<(int Id, string Name, DateTime Start, DateTime End, string Notes)> GetUpcoming(string stationName, int max = 6)
        {
            var rows = Database.Instance.Query(
                "SELECT id, username, start_time, end_time, notes FROM reservations WHERE station_name = @s AND status = 'active'",
                cmd => cmd.Parameters.AddWithValue("@s", stationName ?? ""),
                r => (Id: r.GetInt32(0), Name: r.IsDBNull(1) ? "" : r.GetString(1),
                      Start: r.IsDBNull(2) ? "" : Convert.ToString(r.GetValue(2)),
                      End: r.IsDBNull(3) ? "" : Convert.ToString(r.GetValue(3)),
                      Notes: r.IsDBNull(4) ? "" : r.GetString(4)));
            var list = new List<(int Id, string Name, DateTime Start, DateTime End, string Notes)>();
            DateTime now = DateTime.Now;
            foreach (var row in rows)
            {
                DateTime st, en;
                if (!DateTime.TryParse(row.Start, null, System.Globalization.DateTimeStyles.RoundtripKind, out st)) continue;
                if (!DateTime.TryParse(row.End, null, System.Globalization.DateTimeStyles.RoundtripKind, out en)) continue;
                if (st.Kind == DateTimeKind.Utc) st = st.ToLocalTime();
                if (en.Kind == DateTimeKind.Utc) en = en.ToLocalTime();
                if (en <= now) continue;
                list.Add((row.Id, row.Name, st, en, row.Notes));
            }
            list.Sort((a, b) => a.Start.CompareTo(b.Start));
            if (list.Count > max) list.RemoveRange(max, list.Count - max);
            return list;
        }

        public PagedResult<(int Id, string Username, string Station, DateTime Start, DateTime End, string Status)> GetPaged(int page, int pageSize)
        {
            return Database.Instance.QueryPaged(
                "SELECT id, username, station_name, start_time, end_time, status FROM reservations ORDER BY id DESC",
                "SELECT COUNT(*) FROM reservations", page, pageSize, null,
                r => (r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetDateTime(3), r.GetDateTime(4), r.GetString(5)));
        }
    }
}
