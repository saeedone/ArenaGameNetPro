using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class Discount { public int Id; public string Code = ""; public decimal Percent; public decimal Amount; public bool Active; }
    public class DiscountManager {
        public void AddDiscount(string code, decimal percent, decimal amount) { try { EnsureTable(); Database.Instance.Execute("INSERT INTO discounts (code, percent, amount, active, created_at) VALUES (@c, @p, @a, 1, @t)", c => { c.Parameters.AddWithValue("@c", code); c.Parameters.AddWithValue("@p", percent); c.Parameters.AddWithValue("@a", amount); c.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); }); AuditLog.Log("Discount", "Added: " + code); } catch { } }
        public List<Discount> GetAllDiscounts() { var list = new List<Discount>(); try { EnsureTable(); Database.Instance.Query("SELECT id, code, percent, amount, active FROM discounts ORDER BY id", null, r => { list.Add(new Discount { Id = r.GetInt32(0), Code = r.GetString(1), Percent = r.GetDecimal(2), Amount = r.GetDecimal(3), Active = r.GetBoolean(4) }); return true; }); } catch { } return list; }
        public void DeleteDiscount(int id) { try { Database.Instance.Execute("DELETE FROM discounts WHERE id=@id", c => c.Parameters.AddWithValue("@id", id)); } catch { } }
        private void EnsureTable() { Database.Instance.Execute("CREATE TABLE IF NOT EXISTS discounts (id INTEGER PRIMARY KEY, code TEXT, percent REAL DEFAULT 0, amount REAL DEFAULT 0, active INTEGER DEFAULT 1, created_at TEXT)", null); }
    }
}
