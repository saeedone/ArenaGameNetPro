using System;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class TwoFactorAuth
    {
        private const int SecretSize = 20;
        private const int CodeSize = 6;
        private const int ValidityPeriodSeconds = 30;
        private const int AllowedTimeDrift = 1;

        // ---- Replay protection ----
        // Tracks the highest TOTP counter we have already accepted per secret. Any
        // code with a counter <= the recorded one is rejected as a replay. Kept
        // in-memory only - restarting the server clears it (acceptable for a LAN
        // cafe; the time window is at most 90 seconds wide).
        private static readonly ConcurrentDictionary<string, long> _lastUsedCounter =
            new ConcurrentDictionary<string, long>();

        public string GenerateSecret()
        {
            var bytes = new byte[SecretSize];
            using (var rng = RandomNumberGenerator.Create()) { rng.GetBytes(bytes); }
            return Base32Encode(bytes);
        }

        public string GenerateOtpAuthUri(string username, string secret, string issuer = "GameNet")
        {
            return $"otpauth://totp/{issuer}:{Uri.EscapeDataString(username)}?secret={secret}&issuer={issuer}&algorithm=SHA1&digits={CodeSize}&period={ValidityPeriodSeconds}";
        }

        public bool ValidateCode(string secret, string code)
        {
            if (string.IsNullOrEmpty(secret) || string.IsNullOrEmpty(code)) return false;
            if (code.Length != CodeSize) return false;
            long currentCounter = (long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds() / ValidityPeriodSeconds);
            byte[] secretBytes = Base32Decode(secret);
            // Check each acceptable counter window (current +/- drift). Accept
            // the first match whose counter is strictly greater than the last
            // accepted counter for this secret (replay protection). Once a code
            // is accepted we stamp the highest window we considered so future
            // calls for the same window (or older) are rejected.
            long lastAccepted = _lastUsedCounter.TryGetValue(secret, out var prev) ? prev : -1;
            for (int i = -AllowedTimeDrift; i <= AllowedTimeDrift; i++)
            {
                long counter = currentCounter + i;
                if (counter <= lastAccepted) continue;
                string expected = ComputeHOTP(secretBytes, counter);
                if (StringEqualsConstantTime(expected, code))
                {
                    // Stamp the highest counter we have now consumed. Use the
                    // current real-time counter so any still-valid older window
                    // is also invalidated (single-use semantics per RFC 6238 §5.2).
                    long stamp = Math.Max(counter, lastAccepted);
                    _lastUsedCounter[secret] = stamp;
                    return true;
                }
            }
            return false;
        }

        public string GenerateCurrentCode(string secret)
        {
            long counter = (long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds() / ValidityPeriodSeconds);
            return ComputeHOTP(Base32Decode(secret), counter);
        }

        private string ComputeHOTP(byte[] secret, long counter)
        {
            byte[] counterBytes = BitConverter.GetBytes(counter);
            if (BitConverter.IsLittleEndian) Array.Reverse(counterBytes);
            using (var hmac = new HMACSHA1(secret))
            {
                byte[] hash = hmac.ComputeHash(counterBytes);
                int offset = hash[hash.Length - 1] & 0x0F;
                int binary = ((hash[offset] & 0x7F) << 24) | ((hash[offset + 1] & 0xFF) << 16) | ((hash[offset + 2] & 0xFF) << 8) | (hash[offset + 3] & 0xFF);
                int otp = binary % (int)Math.Pow(10, CodeSize);
                return otp.ToString(new string('0', CodeSize));
            }
        }

        private static bool StringEqualsConstantTime(string a, string b)
        {
            if (a.Length != b.Length) return false;
            int result = 0;
            for (int i = 0; i < a.Length; i++) result |= a[i] ^ b[i];
            return result == 0;
        }

        private static string Base32Encode(byte[] data)
        {
            const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
            var result = new StringBuilder();
            for (int i = 0; i < data.Length; i += 5)
            {
                int b0 = data[i], b1 = i + 1 < data.Length ? data[i + 1] : 0;
                int b2 = i + 2 < data.Length ? data[i + 2] : 0, b3 = i + 3 < data.Length ? data[i + 3] : 0;
                int b4 = i + 4 < data.Length ? data[i + 4] : 0;
                result.Append(alphabet[(b0 >> 3) & 0x1F]);
                result.Append(alphabet[((b0 << 2) | (b1 >> 6)) & 0x1F]);
                result.Append(alphabet[(b1 >> 1) & 0x1F]);
                result.Append(alphabet[((b1 << 4) | (b2 >> 4)) & 0x1F]);
                result.Append(alphabet[((b2 << 1) | (b3 >> 7)) & 0x1F]);
                result.Append(alphabet[(b3 >> 2) & 0x1F]);
                result.Append(alphabet[((b3 << 3) | (b4 >> 5)) & 0x1F]);
                result.Append(alphabet[b4 & 0x1F]);
            }
            return result.ToString().TrimEnd('=');
        }

        private static byte[] Base32Decode(string input)
        {
            const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
            input = input.TrimEnd('=').ToUpperInvariant();
            var bytes = new byte[input.Length * 5 / 8];
            byte curByte = 0; int bitsRemaining = 8; int arrayIndex = 0;
            foreach (char c in input)
            {
                int val = alphabet.IndexOf(c); if (val < 0) continue;
                if (bitsRemaining > 5) { curByte = (byte)(curByte | (val << (bitsRemaining - 5))); bitsRemaining -= 5; }
                else { curByte = (byte)(curByte | (val >> (5 - bitsRemaining))); bytes[arrayIndex++] = curByte; curByte = (byte)(val << (3 + bitsRemaining)); bitsRemaining += 3; }
            }
            if (arrayIndex < bytes.Length) bytes[arrayIndex] = curByte;
            return bytes;
        }

        public void Enable2FAForOperator(int operatorId, string secret)
        {
            Database.Instance.Execute("UPDATE operators SET two_factor_secret = @s, two_factor_enabled = 1 WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@s", secret); cmd.Parameters.AddWithValue("@id", operatorId); });
            AuditLog.Log("2FA", $"2FA enabled for operator {operatorId}");
        }

        public void Disable2FAForOperator(int operatorId)
        {
            Database.Instance.Execute("UPDATE operators SET two_factor_secret = NULL, two_factor_enabled = 0 WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", operatorId));
            AuditLog.Log("2FA", $"2FA disabled for operator {operatorId}");
        }

        public bool Is2FAEnabled(int operatorId)
        {
            return Database.Instance.QueryOne("SELECT CASE WHEN two_factor_enabled = 1 THEN 1 ELSE 0 END FROM operators WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", operatorId), r => r.GetBoolean(0));
        }

        public bool ValidateOperator2FA(int operatorId, string code)
        {
            var secret = Database.Instance.QueryOne("SELECT two_factor_secret FROM operators WHERE id = @id AND two_factor_enabled = 1",
                cmd => cmd.Parameters.AddWithValue("@id", operatorId), r => r.GetString(0));
            if (string.IsNullOrEmpty(secret)) return false;
            return ValidateCode(secret, code);
        }
    }
}
