using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Two-state color theme for the server UI. The full per-pixel color
    /// preset system (see <see cref="AppThemePreset"/> / <see cref="ThemeBuilder"/>)
    /// is for visual customization; this enum is the simpler dark/light
    /// toggle exposed on the MainForm top bar.
    /// </summary>
    public enum AppTheme
    {
        /// <summary>Dark surfaces with light text (default).</summary>
        Dark,
        /// <summary>Light surfaces with dark text.</summary>
        Light,
    }

    /// <summary>
    /// Static manager for the server's dark/light UI theme. Persists the
    /// choice to <c>theme.json</c> next to the server exe and applies the
    /// selected palette to any form via <see cref="ApplyTheme(Form)"/>.
    ///
    /// Color palette (matches the spec):
    ///  • Dark   Background (28,28,42)  Surface (35,35,52)   Text (205,214,244)
    ///           Accent (137,180,250)   Border (49,50,68)    Success (166,227,161)
    ///           Warning (249,226,175)  Error (243,139,168)
    ///  • Light  Background (245,245,248) Surface (255,255,255) Text (30,30,46)
    ///           Accent (59,130,246)    Border (200,200,210)  Success (34,197,94)
    ///           Warning (234,179,8)    Error (239,68,68)
    /// </summary>
    public static class ThemeManager
    {
        // ── persisted state ────────────────────────────────────────────────
        private static AppTheme _currentTheme = AppTheme.Dark;

        /// <summary>Current active theme (Dark by default).</summary>
        public static AppTheme CurrentTheme
        {
            get { return _currentTheme; }
            set
            {
                if (_currentTheme != value)
                {
                    _currentTheme = value;
                    try { SaveTheme(); } catch { }
                }
            }
        }

        // ── palette ────────────────────────────────────────────────────────
        // The color values are computed on every read so a theme switch is
        // reflected immediately (no stale snapshots).

        public static Color BackgroundColor
        {
            get
            {
                // FIX AUDIT-FIX-POSTUPDATE Bug T1: the previous values
                // (18,18,24)/(24,24,32) were so close together that panels
                // and the form background were visually indistinguishable —
                // the operator saw a flat black screen with no depth. The
                // spec values (28,28,42)/(35,35,52) give a visible 7-unit
                // lift between background and surface, restoring the
                // "card on a darker backdrop" hierarchy the spec called for.
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(28, 28, 42)
                    : Color.FromArgb(245, 245, 248);
            }
        }

        public static Color SurfaceColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(35, 35, 52)
                    : Color.FromArgb(255, 255, 255);
            }
        }

        public static Color TextColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(205, 214, 244)
                    : Color.FromArgb(30, 30, 46);
            }
        }

        public static Color AccentColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(137, 180, 250)
                    : Color.FromArgb(59, 130, 246);
            }
        }

        public static Color BorderColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(49, 50, 68)
                    : Color.FromArgb(200, 200, 210);
            }
        }

        public static Color SuccessColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(166, 227, 161)
                    : Color.FromArgb(34, 197, 94);
            }
        }

        public static Color WarningColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(249, 226, 175)
                    : Color.FromArgb(234, 179, 8);
            }
        }

        public static Color ErrorColor
        {
            get
            {
                return _currentTheme == AppTheme.Dark
                    ? Color.FromArgb(243, 139, 168)
                    : Color.FromArgb(239, 68, 68);
            }
        }

        // ── theme file ─────────────────────────────────────────────────────
        // theme.json sits next to the server exe. Format:
        //   {"theme":"dark"}   or   {"theme":"light"}
        // On any read error (file missing / corrupt / wrong value) we fall
        // back to Dark, which matches the legacy hardcoded palette.

        private static string ThemeFilePath
        {
            get
            {
                try
                {
                    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme.json");
                }
                catch
                {
                    return "theme.json";
                }
            }
        }

        /// <summary>Reads theme.json (if present) and sets <see cref="CurrentTheme"/>.</summary>
        public static void LoadTheme()
        {
            try
            {
                string path = ThemeFilePath;
                if (!File.Exists(path)) { _currentTheme = AppTheme.Dark; return; }
                string json = File.ReadAllText(path);
                var dto = JsonConvert.DeserializeObject<ThemeFileDto>(json);
                if (dto != null && !string.IsNullOrEmpty(dto.Theme))
                {
                    if (string.Equals(dto.Theme, "light", StringComparison.OrdinalIgnoreCase))
                        _currentTheme = AppTheme.Light;
                    else if (string.Equals(dto.Theme, "dark", StringComparison.OrdinalIgnoreCase))
                        _currentTheme = AppTheme.Dark;
                    // any other value → keep current (default Dark)
                }
            }
            catch
            {
                // Swallow — load must never throw. Worst case the user gets
                // the default Dark theme.
            }
        }

        /// <summary>Persists <see cref="CurrentTheme"/> to theme.json.</summary>
        public static void SaveTheme()
        {
            try
            {
                string path = ThemeFilePath;
                var dto = new ThemeFileDto { Theme = _currentTheme == AppTheme.Light ? "light" : "dark" };
                string json = JsonConvert.SerializeObject(dto);
                File.WriteAllText(path, json);
            }
            catch
            {
                // Swallow — save must never throw. The theme still applies
                // in-memory for the current session.
            }
        }

        /// <summary>Switches Dark &lt;-&gt; Light, persists, and returns the new value.</summary>
        public static AppTheme ToggleTheme()
        {
            _currentTheme = _currentTheme == AppTheme.Dark ? AppTheme.Light : AppTheme.Dark;
            try { SaveTheme(); } catch { }
            return _currentTheme;
        }

        // ── apply to a form ────────────────────────────────────────────────

        /// <summary>
        /// Recursively walks all controls on <paramref name="form"/> and
        /// applies the current theme's colors. Also walks into embedded
        /// child forms (TopLevel=false) so tab-page content gets themed.
        /// </summary>
        public static void ApplyTheme(Form form)
        {
            if (form == null || form.IsDisposed) return;
            try
            {
                // Force the form's own background
                form.BackColor = BackgroundColor;
                form.ForeColor = TextColor;
                ApplyToControls(form.Controls);
                // Also walk into any embedded child forms (TopLevel=false forms
                // hosted in TabPages or panels). These are not reached by the
                // normal Controls walk because Form is a container.
                WalkEmbeddedForms(form);
                form.Invalidate(true);
            }
            catch
            {
            }
        }

        /// <summary>
        /// FIX AUDIT-FIX-POSTUPDATE Bug T3: helper that returns true if the
        /// given color matches one of the known accent colors used across
        /// the GameNet UI (blue/green/yellow/pink/purple/teal/orange). Used
        /// by ApplyToControl so accent-colored panels (KPI icon stripes,
        /// colored separator strips, etc.) are preserved instead of being
        /// flattened to SurfaceColor.
        /// </summary>
        private static bool IsAccentColor(Color c)
        {
            return c == Color.FromArgb(137, 180, 250)  // blue
                || c == Color.FromArgb(166, 227, 161)  // green
                || c == Color.FromArgb(249, 226, 175)  // yellow
                || c == Color.FromArgb(243, 139, 168)  // pink/red
                || c == Color.FromArgb(203, 166, 247)  // purple
                || c == Color.FromArgb(148, 226, 213)  // teal
                || c == Color.FromArgb(250, 179, 135); // orange
        }

        /// <summary>
        /// FIX REAPPLY-COLOR-FIX-1: maps a dark-theme pastel accent color to
        /// its readable light-theme equivalent. In Dark mode the pastel
        /// accents (e.g. (137,180,250) blue, (166,227,161) green) read fine
        /// on dark surfaces, but in Light mode they wash out against the
        /// white SurfaceColor. Form code that builds colored menu items /
        /// toolbar buttons / KPI tiles passes its accent color through this
        /// helper so the right shade is used for the active theme. Any color
        /// not in the known list is returned unchanged.
        /// </summary>
        public static Color ThemedAccent(Color c)
        {
            if (_currentTheme == AppTheme.Dark) return c;
            if (c == Color.FromArgb(137, 180, 250)) return Color.FromArgb(30, 80, 180);
            if (c == Color.FromArgb(166, 227, 161)) return Color.FromArgb(20, 130, 50);
            if (c == Color.FromArgb(249, 226, 175)) return Color.FromArgb(180, 140, 20);
            if (c == Color.FromArgb(243, 139, 168)) return Color.FromArgb(200, 30, 60);
            if (c == Color.FromArgb(203, 166, 247)) return Color.FromArgb(130, 50, 180);
            if (c == Color.FromArgb(148, 226, 213)) return Color.FromArgb(20, 140, 130);
            if (c == Color.FromArgb(250, 179, 135)) return Color.FromArgb(200, 100, 30);
            if (c == Color.FromArgb(61, 219, 122))  return Color.FromArgb(20, 130, 50);
            if (c == Color.FromArgb(0, 240, 255))   return Color.FromArgb(0, 140, 180);
            if (c == Color.FromArgb(177, 76, 255))  return Color.FromArgb(130, 50, 180);
            if (c == Color.FromArgb(255, 59, 92))   return Color.FromArgb(200, 30, 60);
            return c;
        }

        /// <summary>
        /// Finds all embedded forms (TopLevel=false) within the control tree
        /// and applies the theme to them too.
        /// </summary>
        private static void WalkEmbeddedForms(Control parent)
        {
            try
            {
                foreach (Control c in parent.Controls)
                {
                    if (c is Form embeddedForm && !embeddedForm.IsDisposed)
                    {
                        embeddedForm.BackColor = BackgroundColor;
                        embeddedForm.ForeColor = TextColor;
                        ApplyToControls(embeddedForm.Controls);
                        WalkEmbeddedForms(embeddedForm);
                    }
                    if (c.HasChildren)
                        WalkEmbeddedForms(c);
                }
            }
            catch { }
        }

        private static void ApplyToControls(Control.ControlCollection controls)
        {
            if (controls == null) return;
            foreach (Control c in controls)
            {
                try
                {
                    ApplyToControl(c);
                    if (c.HasChildren) ApplyToControls(c.Controls);
                }
                catch
                {
                    // Skip this control but continue with the rest.
                }
            }
        }

        private static void ApplyToControl(Control c)
        {
            // Order matters: more-specific types checked before their base
            // types (e.g. DataGridView before Control).

            if (c is DataGridView dgv)
            {
                dgv.BackgroundColor = SurfaceColor;
                dgv.GridColor = BorderColor;
                try
                {
                    dgv.DefaultCellStyle.BackColor = SurfaceColor;
                    dgv.DefaultCellStyle.ForeColor = TextColor;
                    dgv.DefaultCellStyle.SelectionBackColor = AccentColor;
                    dgv.DefaultCellStyle.SelectionForeColor = Color.White;
                    dgv.ColumnHeadersDefaultCellStyle.BackColor = SurfaceColor;
                    dgv.ColumnHeadersDefaultCellStyle.ForeColor = AccentColor;
                    dgv.RowHeadersDefaultCellStyle.BackColor = SurfaceColor;
                    dgv.RowHeadersDefaultCellStyle.ForeColor = TextColor;
                }
                catch { }
                return;
            }

            if (c is MenuStrip ms)
            {
                ms.BackColor = BackgroundColor;
                ms.ForeColor = TextColor;
                // FIX AUDIT-FIX-POSTUPDATE Bug T4: walk the menu items so the
                // dropdown items inherit the theme colors (without this, the
                // dropdown surface stays default SystemColors.Menu = light
                // gray and items use black text — unreadable in dark mode).
                foreach (ToolStripItem tsi in ms.Items)
                {
                    try
                    {
                        if (tsi.ForeColor == Color.Empty || tsi.ForeColor == Color.Black)
                            tsi.ForeColor = TextColor;
                        tsi.BackColor = BackgroundColor;
                    } catch { }
                    // Recurse into submenu dropdowns so nested items are themed too.
                    if (tsi is ToolStripMenuItem tsmi && tsmi.HasDropDownItems)
                    {
                        try { ThemeMenuDropDown(tsmi.DropDown); } catch { }
                    }
                }
                return;
            }

            if (c is ContextMenuStrip cms)
            {
                // FIX AUDIT-FIX-POSTUPDATE Bug T4: theme ContextMenuStrip
                // dropdowns so right-click menus in ClientMonitorForm /
                // DataGridView context menus match the dark palette.
                cms.BackColor = SurfaceColor;
                cms.ForeColor = TextColor;
                foreach (ToolStripItem tsi in cms.Items)
                {
                    try
                    {
                        // Preserve per-item accent ForeColor (already set by caller).
                        if (tsi.ForeColor == Color.Empty || tsi.ForeColor == Color.Black)
                            tsi.ForeColor = TextColor;
                        if (!IsAccentColor(tsi.BackColor))
                            tsi.BackColor = SurfaceColor;
                    } catch { }
                    // Recurse into submenus.
                    if (tsi is ToolStripMenuItem tsmi && tsmi.HasDropDownItems)
                    {
                        try { ThemeMenuDropDown(tsmi.DropDown); } catch { }
                    }
                }
                return;
            }

            if (c is StatusStrip ss)
            {
                ss.BackColor = BackgroundColor;
                ss.ForeColor = TextColor;
                // Walk the items collection — StatusStrip uses ToolStripItem,
                // not Control, so the recursive walk above doesn't reach them.
                foreach (ToolStripItem tsi in ss.Items)
                {
                    try
                    {
                        // FIX AUDIT-FIX-POSTUPDATE Bug T4: theme the items'
                        // BackColor (was only set on the parent). Items with
                        // an accent ForeColor keep their ForeColor (status
                        // labels use accent colors to distinguish role /
                        // online / etc.); items with the default empty/black
                        // ForeColor get TextColor so they're readable.
                        if (tsi.ForeColor == Color.Empty || tsi.ForeColor == Color.Black)
                            tsi.ForeColor = TextColor;
                        tsi.BackColor = BackgroundColor;
                    } catch { }
                }
                return;
            }

            if (c is ToolStrip ts)
            {
                ts.BackColor = BackgroundColor;
                ts.ForeColor = TextColor;
                foreach (ToolStripItem tsi in ts.Items)
                {
                    try
                    {
                        if (tsi.ForeColor == Color.Empty || tsi.ForeColor == Color.Black)
                            tsi.ForeColor = TextColor;
                        if (!IsAccentColor(tsi.BackColor))
                            tsi.BackColor = BackgroundColor;
                    } catch { }
                }
                return;
            }

            if (c is TabControl tab)
            {
                tab.BackColor = BackgroundColor;
                tab.ForeColor = TextColor;
                return;
            }

            if (c is TabPage tp)
            {
                tp.BackColor = SurfaceColor;
                tp.ForeColor = TextColor;
                return;
            }

            if (c is GroupBox grp)
            {
                grp.BackColor = SurfaceColor;
                grp.ForeColor = AccentColor;
                return;
            }

            if (c is Panel pnl)
            {
                // FIX AUDIT-FIX-POSTUPDATE Bug T1: do NOT force-flatten accent-
                // colored panels. The previous code unconditionally set every
                // panel to SurfaceColor, which destroyed the KPI icon stripes
                // in DashboardForm (colored accent strips became surface grey),
                // the colored toolbar separators, and any other intentional
                // accent-color panel. Now we preserve panels whose BackColor
                // is one of the known accent colors, and only flatten panels
                // that have a non-accent BackColor (default, dark grey, etc.)
                // to the theme surface. This restores the visual hierarchy
                // without breaking accent-colored design elements.
                if (!IsAccentColor(pnl.BackColor))
                    pnl.BackColor = SurfaceColor;
                return;
            }

            if (c is Button btn)
            {
                // FIX AUDIT-FIX-POSTUPDATE Bug T5: theme buttons more robustly.
                // The previous threshold (500) let default SystemColors.Control
                // buttons (light gray, brightness 720) pass through unchanged —
                // they stayed light gray in dark mode, breaking the dark theme
                // for any form that used default-styled buttons. Now we always
                // force the BackColor to SurfaceColor UNLESS the button has an
                // explicit accent color (blue/green/yellow/pink/purple/teal/
                // orange). Accent buttons (e.g. Save = green, Delete = red)
                // keep their BackColor so the operator can still identify them
                // by color. ForeColor is computed for contrast.
                if (!IsAccentColor(btn.BackColor))
                    btn.BackColor = SurfaceColor;
                int bgBrightness = btn.BackColor.R + btn.BackColor.G + btn.BackColor.B;
                // FIX AUDIT-FIX-POSTUPDATE Bug T5b: TextColor in dark mode is
                // (205,214,244) — light enough that the contrast check would
                // pick dark ForeColor (30,30,46) for it on the dark Surface.
                // Use a slightly brighter "on-dark" ForeColor for the dark-on-
                // dark case so the button text is readable.
                Color onLight = Color.FromArgb(30, 30, 46);
                Color onDark = Color.FromArgb(230, 230, 240);
                btn.ForeColor = bgBrightness > 384 ? onLight : onDark;
                return;
            }

            if (c is LinkLabel ll)
            {
                ll.LinkColor = AccentColor;
                ll.VisitedLinkColor = AccentColor;
                ll.ForeColor = TextColor;
                return;
            }

            if (c is Label lbl)
            {
                // Theme ALL labels — but preserve accent-colored labels (green/yellow/red/blue)
                // FIX AUDIT-FIX-POSTUPDATE Bug T5c: reuse IsAccentColor helper
                // (the inline list was identical and would drift if a new
                // accent color was added to one but not the other).
                if (!IsAccentColor(lbl.ForeColor))
                {
                    lbl.ForeColor = TextColor;
                }
                return;
            }

            if (c is TextBox txt)
            {
                txt.BackColor = SurfaceColor;
                txt.ForeColor = TextColor;
                try { txt.BorderStyle = BorderStyle.FixedSingle; } catch { }
                return;
            }

            if (c is ComboBox cmb)
            {
                cmb.BackColor = SurfaceColor;
                cmb.ForeColor = TextColor;
                try { cmb.FlatStyle = FlatStyle.Flat; } catch { }
                return;
            }

            if (c is NumericUpDown nud)
            {
                nud.BackColor = SurfaceColor;
                nud.ForeColor = TextColor;
                return;
            }

            if (c is ListBox lb)
            {
                lb.BackColor = SurfaceColor;
                lb.ForeColor = TextColor;
                return;
            }

            if (c is CheckedListBox clb)
            {
                clb.BackColor = SurfaceColor;
                clb.ForeColor = TextColor;
                return;
            }

            if (c is CheckBox chk)
            {
                chk.ForeColor = TextColor;
                return;
            }

            if (c is RadioButton rb)
            {
                rb.ForeColor = TextColor;
                return;
            }

            if (c is PictureBox)
            {
                // PictureBoxes don't need theming — their image is the content.
                return;
            }

            if (c is ProgressBar pb)
            {
                // ProgressBar colors are determined by the OS visual style;
                // leave them alone.
                return;
            }

            // Default: leave the control alone. Unknown control types
            // (third-party, custom) keep their existing colors.
        }

        /// <summary>
        /// FIX AUDIT-FIX-POSTUPDATE Bug T4: recursively themes a menu dropdown
        /// (the popup surface that appears when a ToolStripMenuItem is
        /// hovered). Without this, submenu items keep their default
        /// SystemColors.Menu (light gray) background and black text —
        /// unreadable in dark mode.
        /// </summary>
        private static void ThemeMenuDropDown(ToolStripDropDown dropDown)
        {
            if (dropDown == null) return;
            try
            {
                dropDown.BackColor = SurfaceColor;
                dropDown.ForeColor = TextColor;
                foreach (ToolStripItem tsi in dropDown.Items)
                {
                    try
                    {
                        if (tsi.ForeColor == Color.Empty || tsi.ForeColor == Color.Black)
                            tsi.ForeColor = TextColor;
                        if (!IsAccentColor(tsi.BackColor))
                            tsi.BackColor = SurfaceColor;
                    } catch { }
                    if (tsi is ToolStripMenuItem tsmi && tsmi.HasDropDownItems)
                    {
                        ThemeMenuDropDown(tsmi.DropDown);
                    }
                }
            }
            catch { }
        }

        // ── DTO for theme.json ─────────────────────────────────────────────
        private sealed class ThemeFileDto
        {
            [JsonProperty("theme")]
            public string Theme { get; set; }
        }
    }
}
