using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using GameNet.Shared;
using Newtonsoft.Json;

namespace GameNet.Server.Core
{
    // === -1. Payment callback URL (FIX SEC-2/FUNC-1) ===
    // The gateway's default callback URL pointed at port 9090 — the raw TCP
    // kiosk protocol port, which does not speak HTTP — so ZarinPal could
    // never reach it even if RestApiServer.HandlePaymentCallback (see
    // RestApiServer.cs) hadn't also been completely missing. Builds the
    // *actual* reachable URL from the configured REST API port instead.
    public static class PaymentCallbackHelper
    {
        /// <summary>
        /// Returns the callback URL to hand to PaymentGateway, or null if
        /// the REST API is disabled (ApiPort == 0) — in which case payment
        /// verification cannot work at all and the caller should warn the
        /// operator rather than silently generating a dead-end URL.
        ///
        /// Resolution order:
        ///  1. settings.zarinpal_callback_base, if the operator configured
        ///     one (required for a real production deployment — ZarinPal
        ///     redirects the CUSTOMER's browser here, so it must be an
        ///     address reachable from wherever the customer actually is:
        ///     a public domain/IP, not "localhost").
        ///  2. Best-effort fallback: this machine's LAN IP. Only reachable
        ///     for customers on the same LAN (fine for sandbox/testing or a
        ///     cafe where customers pay from a kiosk on the same network;
        ///     NOT sufficient for a real ZarinPal production merchant with
        ///     customers paying from their own phones over the internet).
        /// </summary>
        public static string GetCallbackUrlOrNull()
        {
            try
            {
                var opts = Forms.OptionsForm.LoadStaticOptions();
                int apiPort = opts?.ApiPort ?? 0;
                if (apiPort <= 0) return null;

                string configuredBase = Database.Instance.QueryOne(
                    "SELECT value FROM settings WHERE key = 'zarinpal_callback_base'", null, r => r.GetString(0));
                if (!string.IsNullOrWhiteSpace(configuredBase))
                    return configuredBase.TrimEnd('/') + "/payment/callback";

                string lanIp = null;
                try
                {
                    var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                    var addr = host.AddressList.FirstOrDefault(a =>
                        a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                        !a.ToString().StartsWith("127."));
                    lanIp = addr?.ToString();
                }
                catch { }
                string host2 = lanIp ?? "localhost";
                return $"http://{host2}:{apiPort}/payment/callback";
            }
            catch { return null; }
        }
    }

    // === 0. Server Auto-Startup (wires OptionsForm.OptionsData.RunServerAtStartup) ===
    // FIX DEAD-CONFIG-1: RunServerAtStartup was saved to options.json by
    // OptionsForm but nothing ever read it back, so the checkbox had zero
    // effect. This applies/removes a HKCU Run key to match the saved value.
    // HKCU (not HKLM) is used deliberately: it needs no admin elevation and
    // only affects the operator who is currently logged in, which matches
    // how the server is actually run (interactively, not as a service).
    public static class ServerAutoStartup
    {
        private const string RunKeyPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
        private const string ValueName = "GameNetServer";

        /// <summary>
        /// Ensures the HKCU Run key matches <paramref name="enabled"/>. Safe
        /// to call on every startup — it's a cheap no-op once in sync.
        /// </summary>
        public static void Apply(bool enabled)
        {
            try
            {
                using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: true))
                {
                    if (key == null) return;
                    if (enabled)
                    {
                        string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                        if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath)) return;
                        key.SetValue(ValueName, "\"" + exePath + "\"");
                    }
                    else
                    {
                        if (key.GetValue(ValueName) != null) key.DeleteValue(ValueName, throwOnMissingValue: false);
                    }
                }
            }
            catch (Exception ex) { try { AuditLog.Log("AutoStartup", "Apply(" + enabled + ") failed: " + ex.Message); } catch { } }
        }
    }

    // === 1. Session Receipt Printer ===
    public static class ReceiptPrinter
    {
        private static PrintDocument _doc;
        private static string _receiptText;

        public static void PrintSessionReceipt(string username, string stationName, DateTime startTime, DateTime endTime, int durationMinutes, decimal cost, decimal balanceRemaining)
        {
            _receiptText = "═══════════════════════\n"
                + "   🎮 markazbazi - رسید نشست\n"
                + "═══════════════════════\n\n"
                + $"👤 کاربر: {username}\n"
                + $"💻 ایستگاه: {stationName}\n"
                + $"🕐 شروع: {startTime:yyyy/MM/dd HH:mm}\n"
                + $"🕑 پایان: {endTime:yyyy/MM/dd HH:mm}\n"
                + $"⏱️ مدت: {durationMinutes} دقیقه\n"
                + $"💰 هزینه: {cost:N0} تومان\n"
                + $"💳 موجودی باقی‌مانده: {balanceRemaining:N0} تومان\n\n"
                + $"📅 {DateTime.Now:yyyy/MM/dd HH:mm}\n"
                + "═══════════════════════\n"
                + "   با تشکر از حضور شما 🙏\n"
                + "═══════════════════════\n";

            try
            {
                _doc = new PrintDocument { DocumentName = $"GameNet_Receipt_{username}_{DateTime.Now:yyyyMMddHHmm}" };
                _doc.PrintPage += (s, e) =>
                {
                    var font = new Font("Consolas", 9F);
                    var brush = new SolidBrush(Color.Black);
                    float y = 20;
                    foreach (var line in _receiptText.Split('\n'))
                    {
                        e.Graphics.DrawString(line.TrimEnd('\r'), font, brush, 20, y);
                        y += font.GetHeight() + 2;
                    }
                    e.HasMorePages = false;
                };
                _doc.Print();
                AuditLog.Log("Receipt", $"Receipt printed for {username} ({cost:N0} Toman)");
            }
            catch (Exception ex) { AuditLog.Log("Receipt", "Print error: " + ex.Message); }
        }
    }

    // === 2. In-Server Report Viewer (no Excel, display in DataGridView) ===
    public static class ReportExporter
    {
        /// <summary>Exports a report to HTML for in-app viewing in a browser control.</summary>
        public static string ExportToHtml(string title, List<string> headers, List<List<string>> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html dir='rtl'><head><meta charset='UTF-8'>");
            sb.AppendLine("<style>");
            sb.AppendLine("body { font-family: 'Segoe UI', Tahoma; background: #1e1e2e; color: #cdd6f4; padding: 20px; }");
            sb.AppendLine("h1 { color: #89b4fa; }");
            sb.AppendLine("table { border-collapse: collapse; width: 100%; margin-top: 15px; }");
            sb.AppendLine("th { background: #313244; color: #89b4fa; padding: 10px; text-align: right; }");
            sb.AppendLine("td { background: #181825; padding: 8px; border-bottom: 1px solid #313244; }");
            sb.AppendLine("tr:hover td { background: #313244; }");
            sb.AppendLine(".summary { background: #313244; padding: 15px; border-radius: 8px; margin: 15px 0; }");
            sb.AppendLine("</style></head><body>");
            sb.AppendLine($"<h1>📊 {title}</h1>");
            sb.AppendLine($"<div class='summary'>📅 تاریخ: {DateTime.Now:yyyy/MM/dd HH:mm} | 📄 تعداد رکورد: {rows.Count}</div>");
            sb.AppendLine("<table><tr>");
            foreach (var h in headers) sb.AppendLine($"<th>{h}</th>");
            sb.AppendLine("</tr>");
            foreach (var row in rows)
            {
                sb.AppendLine("<tr>");
                foreach (var cell in row) sb.AppendLine($"<td>{cell}</td>");
                sb.AppendLine("</tr>");
            }
            sb.AppendLine("</table></body></html>");
            return sb.ToString();
        }

        /// <summary>Saves report as HTML file and opens in default browser.</summary>
        public static void SaveAndOpenHtml(string title, List<string> headers, List<List<string>> rows)
        {
            try
            {
                string html = ExportToHtml(title, headers, rows);
                string path = Path.Combine(Path.GetTempPath(), $"gamenet_report_{DateTime.Now:yyyyMMddHHmmss}.html");
                File.WriteAllText(path, html, Encoding.UTF8);
                System.Diagnostics.Process.Start(path);
                AuditLog.Log("Report", $"HTML report saved: {path} ({rows.Count} rows)");
            }
            catch (Exception ex) { AuditLog.Log("Report", "HTML export error: " + ex.Message); }
        }
    }

    // === 3. Birthday Rewards ===
    public static class BirthdayRewardManager
    {
        public const decimal DefaultRewardAmount = 20000m; // 20,000 Toman

        public static void CheckAndRewardBirthdays()
        {
            try
            {
                var today = DateTime.Now.ToString("MM-dd");
                var users = Database.Instance.Query(
                    "SELECT username, display_name, phone FROM users WHERE is_active = 1 AND strftime('%m-%d', created_at) = @today",
                    cmd => cmd.Parameters.AddWithValue("@today", today),
                    r => (Username: r.GetString(0), DisplayName: r.IsDBNull(1) ? r.GetString(0) : r.GetString(1), Phone: r.IsDBNull(2) ? "" : r.GetString(2)));

                // Actually check a birthday field — for now use a settings-based approach
                // where the operator enters birthdays in the user notes field as "BD:MM-DD"
                var birthdayUsers = Database.Instance.Query(
                    "SELECT username, display_name FROM users WHERE is_active = 1 AND notes LIKE @pattern",
                    cmd => cmd.Parameters.AddWithValue("@pattern", $"%BD:{today}%"),
                    r => (Username: r.GetString(0), DisplayName: r.IsDBNull(1) ? r.GetString(0) : r.GetString(1)));

                decimal amount = GetSettingDecimal("birthday_reward_amount", DefaultRewardAmount);
                foreach (var u in birthdayUsers)
                {
                    try
                    {
                        new UserManager().AddCredit(u.Username, amount, $"🎁 پاداش تولد");
                        AuditLog.Log("Birthday", $"Birthday reward: {u.Username} +{amount:N0} Toman");
                        // Mark as rewarded today to avoid double
                        Database.Instance.Execute(
                            "UPDATE users SET notes = REPLACE(notes, @old, @new) WHERE username = @u",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@old", $"BD:{today}");
                                cmd.Parameters.AddWithValue("@new", $"BD:{today}:RW");
                                cmd.Parameters.AddWithValue("@u", u.Username);
                            });
                    }
                    catch (Exception ex) { AuditLog.Log("Birthday", $"Error rewarding {u.Username}: {ex.Message}"); }
                }
            }
            catch (Exception ex) { AuditLog.Log("Birthday", "CheckAndReward error: " + ex.Message); }
        }

        public static void SetBirthday(string username, string monthDay) // "MM-DD"
        {
            try
            {
                var user = Database.Instance.QueryOne("SELECT notes FROM users WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", username), r => r.IsDBNull(0) ? "" : r.GetString(0));

                string notes = user ?? "";
                // Remove old BD: tag
                if (notes.Contains("BD:"))
                {
                    int idx = notes.IndexOf("BD:");
                    int end = notes.IndexOf(' ', idx);
                    if (end < 0) end = notes.Length;
                    notes = notes.Remove(idx, end - idx).Trim();
                }
                notes = (string.IsNullOrEmpty(notes) ? "" : notes + " ") + $"BD:{monthDay}";

                Database.Instance.Execute("UPDATE users SET notes = @n WHERE username = @u",
                    cmd => { cmd.Parameters.AddWithValue("@n", notes); cmd.Parameters.AddWithValue("@u", username); });
                AuditLog.Log("Birthday", $"Birthday set for {username}: {monthDay}");
            }
            catch (Exception ex) { AuditLog.Log("Birthday", "SetBirthday error: " + ex.Message); }
        }

        private static decimal GetSettingDecimal(string key, decimal def)
        {
            try
            {
                var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key), r => r.GetString(0));
                return decimal.TryParse(v, out decimal d) ? d : def;
            }
            catch { return def; }
        }
    }

    // === 4. Referral System ===
    public static class ReferralManager
    {
        public const decimal DefaultReferrerReward = 10000m;
        public const decimal DefaultRefereeReward = 5000m;

        public static string GenerateReferralCode(string username)
        {
            string code = username.ToUpperInvariant().Substring(0, Math.Min(4, username.Length)) + "-" + new Random().Next(1000, 9999);
            try
            {
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                    cmd => { cmd.Parameters.AddWithValue("@k", "referral_" + username); cmd.Parameters.AddWithValue("@v", code); });
                AuditLog.Log("Referral", $"Code generated for {username}: {code}");
            }
            catch { }
            return code;
        }

        public static string GetReferralCode(string username)
        {
            try
            {
                return Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", "referral_" + username), r => r.GetString(0)) ?? GenerateReferralCode(username);
            }
            catch { return GenerateReferralCode(username); }
        }

        public static void ApplyReferral(string newUser, string referralCode)
        {
            try
            {
                // Find referrer by code
                var referrer = Database.Instance.QueryOne<string>(
                    "SELECT key FROM settings WHERE value = @code AND key LIKE 'referral_%'",
                    cmd => cmd.Parameters.AddWithValue("@code", referralCode), r => r.GetString(0));

                if (string.IsNullOrEmpty(referrer)) return;
                string referrerUsername = referrer.Replace("referral_", "");

                decimal referrerReward = GetSettingDecimal("referral_referrer_reward", DefaultReferrerReward);
                decimal refereeReward = GetSettingDecimal("referral_referee_reward", DefaultRefereeReward);

                Database.Instance.ExecuteInTransaction(tx =>
                {
                    new UserManager().AddCredit(referrerUsername, referrerReward, $"🎁 پاداش معرفی {newUser}");
                    new UserManager().AddCredit(newUser, refereeReward, $"🎁 پاداش معرفی توسط {referrerUsername}");
                    Database.Instance.Execute(
                        "INSERT INTO referral_history (referrer, referred, referrer_reward, referee_reward, created_at) VALUES (@r, @n, @rr, @nr, @c)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@r", referrerUsername);
                            cmd.Parameters.AddWithValue("@n", newUser);
                            cmd.Parameters.AddWithValue("@rr", referrerReward);
                            cmd.Parameters.AddWithValue("@nr", refereeReward);
                            cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                        }, tx);
                });
                AuditLog.Log("Referral", $"{referrerUsername} referred {newUser}: +{referrerReward} / +{refereeReward}");
            }
            catch (Exception ex) { AuditLog.Log("Referral", "ApplyReferral error: " + ex.Message); }
        }

        public static List<(string Referrer, string Referred, decimal ReferrerReward, decimal RefereeReward, DateTime CreatedAt)> GetHistory()
        {
            try
            {
                return Database.Instance.Query(
                    "SELECT referrer, referred, referrer_reward, referee_reward, created_at FROM referral_history ORDER BY id DESC LIMIT 100",
                    null,
                    r => (r.GetString(0), r.GetString(1), r.GetDecimal(2), r.GetDecimal(3), r.GetDateTime(4)));
            }
            catch { return new List<(string, string, decimal, decimal, DateTime)>(); }
        }

        private static decimal GetSettingDecimal(string key, decimal def)
        {
            try
            {
                var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key), r => r.GetString(0));
                return decimal.TryParse(v, out decimal d) ? d : def;
            }
            catch { return def; }
        }
    }

    // === 5. Telegram Bot Notifications ===
    // FIX-MONITOR-ADD5 TASK B5: TelegramNotifier was MOVED to its own file
    // at GameNet.Server/Core/TelegramNotifier.cs. The new class has the
    // same Configure(botToken, chatId) + Send(message) API but also adds
    // NotifyTopup(station, user, amount), NotifySessionEnd, and
    // NotifyDisconnect helpers, and IsConfigured is exposed as a public
    // property so callers can guard expensive work. The old DB-backed
    // Configure() / LoadConfig() persistence is gone — the bot token +
    // chat id now live in options.json (OptionsForm.OptionsData) and are
    // applied at server startup via TelegramNotifier.Configure().

    // === 6. Theme Manager (Dark/Light) ===
    public static class ServerThemeManager
    {
        public static bool IsDarkMode = true;

        public static Color Background => IsDarkMode ? Color.FromArgb(28, 28, 42) : Color.FromArgb(245, 245, 250);
        public static Color Foreground => IsDarkMode ? Color.FromArgb(205, 214, 244) : Color.FromArgb(30, 30, 46);
        public static Color Accent => IsDarkMode ? Color.FromArgb(137, 180, 250) : Color.FromArgb(60, 100, 200);
        public static Color Surface => IsDarkMode ? Color.FromArgb(35, 35, 52) : Color.FromArgb(230, 230, 240);
        public static Color TopBar => IsDarkMode ? Color.FromArgb(22, 22, 35) : Color.FromArgb(200, 200, 215);

        public static void Toggle()
        {
            IsDarkMode = !IsDarkMode;
            try
            {
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('server_dark_mode', @v)",
                    cmd => cmd.Parameters.AddWithValue("@v", IsDarkMode ? "1" : "0"));
                AuditLog.Log("Theme", $"Switched to {(IsDarkMode ? "dark" : "light")} mode");
            }
            catch { }
        }

        public static void Load()
        {
            try
            {
                var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = 'server_dark_mode'", null, r => r.GetString(0));
                if (!string.IsNullOrEmpty(v)) IsDarkMode = v == "1";
            }
            catch { }
        }
    }

    // === 7. Configurable Billing Interval ===
    public static class BillingConfig
    {
        public static int IntervalSeconds
        {
            get => GetSettingInt("billing_interval_seconds", 60);
            set => SetSetting("billing_interval_seconds", value.ToString());
        }

        public static decimal MinimumCharge
        {
            get => GetSettingDecimal("minimum_charge", 2500m);
            set => SetSetting("minimum_charge", value.ToString());
        }

        public static int RoundingMinutes
        {
            get => GetSettingInt("rounding_minutes", 15);
            set => SetSetting("rounding_minutes", value.ToString());
        }

        public static int WarningMinutes
        {
            get => GetSettingInt("session_warning_minutes", 15);
            set => SetSetting("session_warning_minutes", value.ToString());
        }

        private static int GetSettingInt(string key, int def)
        {
            try { var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k", cmd => cmd.Parameters.AddWithValue("@k", key), r => r.GetString(0)); return int.TryParse(v, out int i) ? i : def; }
            catch { return def; }
        }

        private static decimal GetSettingDecimal(string key, decimal def)
        {
            try { var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = @k", cmd => cmd.Parameters.AddWithValue("@k", key), r => r.GetString(0)); return decimal.TryParse(v, out decimal d) ? d : def; }
            catch { return def; }
        }

        private static void SetSetting(string key, string value)
        {
            Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                cmd => { cmd.Parameters.AddWithValue("@k", key); cmd.Parameters.AddWithValue("@v", value); });
            AuditLog.Log("BillingConfig", $"{key} = {value}");
        }
    }

    // === 8. JSON Database Backup ===
    public static class JsonBackupManager
    {
        public static string ExportToJson()
        {
            try
            {
                var data = new Dictionary<string, object>();

                // Export all tables
                var tables = new[] { "users", "operators", "stations", "pricing", "tickets", "client_sessions",
                    "reservations", "console_sessions", "client_licenses", "topup_requests", "wait_queue",
                    "discount_codes", "loyalty_points", "loyalty_history", "security_alerts", "settings" };

                foreach (var table in tables)
                {
                    try
                    {
                        var rows = new List<Dictionary<string, object>>();
                        var conn = Database.Instance;
                        var data2 = conn.Query($"SELECT * FROM {table}", null, r =>
                        {
                            var dict = new Dictionary<string, object>();
                            for (int i = 0; i < r.FieldCount; i++)
                            {
                                string col = r.GetName(i);
                                dict[col] = r.IsDBNull(i) ? null : r.GetValue(i);
                            }
                            return dict;
                        });
                        data[table] = data2;
                    }
                    catch { }
                }

                data["_metadata"] = new { export_time = DateTime.UtcNow, version = "v13.0", table_count = tables.Length };

                string json = JsonConvert.SerializeObject(data, Formatting.Indented);
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups", $"gamenet_full_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(path, json, Encoding.UTF8);
                AuditLog.Log("JsonBackup", $"Full JSON backup: {path} ({json.Length} bytes)");
                return path;
            }
            catch (Exception ex) { AuditLog.Log("JsonBackup", "Export error: " + ex.Message); return null; }
        }
    }
}
