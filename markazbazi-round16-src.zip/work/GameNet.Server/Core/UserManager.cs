using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Thrown when a money operation (deduct / transfer / partial payment) cannot
    /// be completed because the user's balance is insufficient. Inherits from
    /// <see cref="InvalidOperationException"/> so existing callers that catch the
    /// base class continue to work, while allowing new callers to discriminate.
    /// </summary>
    public class InsufficientBalanceException : InvalidOperationException
    {
        public string Username { get; }
        public decimal Balance { get; }
        public decimal Required { get; }

        public InsufficientBalanceException(string username, decimal balance, decimal required)
            : base($"اعتبار ناکافی. موجودی: {balance:N0} تومان، مبلغ موردنیاز: {required:N0} تومان")
        {
            Username = username;
            Balance = balance;
            Required = required;
        }

        public InsufficientBalanceException(string message) : base(message) { }
    }

    /// <summary>
    /// Manages user accounts with Toman balance, transfers, and credit protection.
    /// </summary>
    public class UserManager
    {
        // ---- Password hashing constants (PBKDF2-SHA256) ----
        private const int Pbkdf2Iterations = 60000;
        private const int SaltSize = 16;
        private const int HashSize = 32;

        // ---- In-memory member lockout (5 attempts -> 5 minute lock) ----
        // Falls back to memory because the legacy `users` table has no lockout
        // columns and Database.cs is owned by another agent. Restarting the
        // server resets in-progress lockouts, which is acceptable for a LAN cafe.
        //
        // FIX M6 (KNOWN RACE): the ConcurrentDictionary.AddOrUpdate lambda
        // below is not atomic with the read that decides whether to lock the
        // account. Two concurrent failed logins for the same user can both
        // pass the "locked?" check before either has incremented the counter,
        // so the worst case is one extra failed attempt before the lock kicks
        // in. The race is benign — the account still locks within one extra
        // attempt, and successful logins still clear the counter. A per-user
        // lock object would close the window but adds contention that's not
        // worth it for a 5-attempt / 5-min policy on a single-server system.
        private const int MaxFailedAttempts = 5;
        private static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(5);
        private static readonly ConcurrentDictionary<string, (int Attempts, DateTime LockedUntil)> _lockouts =
            new ConcurrentDictionary<string, (int, DateTime)>();

        public int CreateUser(string username, string password, string displayName, decimal initialBalance = 0, string phone = "")
        {
            var (valid, err) = InputValidator.ValidateUsername(username);
            if (!valid) throw new ArgumentException(err);
            var (pwValid, pwErr) = InputValidator.ValidatePassword(password);
            if (!pwValid) throw new ArgumentException(pwErr);
            if (FindByUsername(username) != null)
                throw new InvalidOperationException("این نام کاربری قبلاً ثبت شده است");

            string hash = HashPassword(password);
            Database.Instance.Execute(
                "INSERT INTO users (username, password_hash, display_name, balance, is_active, created_at, phone) VALUES (@u, @h, @d, @b, 1, @c, @p)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@h", hash);
                    cmd.Parameters.AddWithValue("@d", displayName ?? username);
                    cmd.Parameters.AddWithValue("@b", initialBalance);
                    cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@p", phone ?? "");
                });

            AuditLog.Log("UserManager", $"User {username} created with balance {initialBalance}");
            return (int)Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt64(0));
        }

        public UserInfo FindByUsername(string username)
        {
            return Database.Instance.QueryOne(
                "SELECT id, username, display_name, balance, is_active, created_at, phone FROM users WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username),
                r => new UserInfo
                {
                    Id = r.GetInt32(0), Username = r.GetString(1),
                    DisplayName = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2),
                    Balance = r.GetDecimal(3), IsActive = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    Phone = r.IsDBNull(6) ? "" : r.GetString(6)
                });
        }

        public UserInfo FindById(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, username, display_name, balance, is_active, created_at, phone FROM users WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new UserInfo
                {
                    Id = r.GetInt32(0), Username = r.GetString(1),
                    DisplayName = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2),
                    Balance = r.GetDecimal(3), IsActive = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    Phone = r.IsDBNull(6) ? "" : r.GetString(6)
                });
        }

        /// <summary>
        /// Add credit to user account (Toman). Atomic delta increment; no read-modify-write race.
        /// </summary>
        public void AddCredit(string username, decimal amount, string reason = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (amount <= 0) throw new ArgumentException("مبلغ باید بیشتر از صفر باشد");

            int rows = Database.Instance.ExecuteNonQuery(
                "UPDATE users SET balance = balance + @amount WHERE username = @u",
                cmd => { cmd.Parameters.AddWithValue("@amount", amount); cmd.Parameters.AddWithValue("@u", username); });

            if (rows == 0) throw new KeyNotFoundException("کاربر یافت نشد");

            AuditLog.Log("UserManager", $"Credit +{amount:N0} تومان added to {username}. Reason: {reason}");
        }

        /// <summary>
        /// Deduct credit atomically. Uses a single conditional UPDATE
        /// (balance >= amount) so that two concurrent deductions cannot both
        /// succeed and drive the balance negative. Returns nothing; throws
        /// <see cref="InsufficientBalanceException"/> if the balance is too low
        /// or <see cref="KeyNotFoundException"/> if the user does not exist.
        /// </summary>
        public void DeductCredit(string username, decimal amount, string reason = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (amount <= 0) throw new ArgumentException("مبلغ باید بیشتر از صفر باشد");

            int rows;
            try
            {
                rows = Database.Instance.ExecuteNonQuery(
                    "UPDATE users SET balance = balance - @amount WHERE username = @u AND balance >= @amount",
                    cmd => { cmd.Parameters.AddWithValue("@amount", amount); cmd.Parameters.AddWithValue("@u", username); });
            }
            catch (Exception ex)
            {
                AuditLog.Log("UserManager", $"DeductCredit failed for {username} ({amount:N0}): {ex.Message}");
                throw;
            }

            if (rows == 0)
            {
                // Either the user does not exist, or the balance was insufficient.
                var user = FindByUsername(username);
                if (user == null) throw new KeyNotFoundException("کاربر یافت نشد");
                throw new InsufficientBalanceException(username, user.Balance, amount);
            }

            AuditLog.Log("UserManager", $"Credit -{amount:N0} تومان deducted from {username}. Reason: {reason}");
        }

        /// <summary>
        /// Transfer credit between two users atomically in a single transaction.
        /// The sender's deduction is conditional on balance >= amount; if it
        /// affects 0 rows the transaction rolls back and an
        /// <see cref="InsufficientBalanceException"/> is thrown. The recipient
        /// increment is unconditional (we already verified the recipient exists).
        /// </summary>
        public void TransferCredit(string fromUsername, string toUsername, decimal amount)
        {
            if (amount <= 0) throw new ArgumentException("مبلغ باید بیشتر از صفر باشد");
            if (fromUsername == toUsername) throw new ArgumentException("نمی‌توان به خودتان انتقال دهید");

            // Pre-flight checks (existence + active). The actual money movement
            // is atomic via conditional UPDATE, so a race that drains the
            // sender between this check and the transaction is still safe.
            var from = FindByUsername(fromUsername);
            var to = FindByUsername(toUsername);
            if (from == null || to == null) throw new KeyNotFoundException("کاربر یافت نشد");
            if (!from.IsActive || !to.IsActive) throw new InvalidOperationException("حساب کاربری غیرفعال است");

            int deductRows = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    deductRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance - @amount WHERE username = @from AND balance >= @amount",
                        cmd => { cmd.Parameters.AddWithValue("@amount", amount); cmd.Parameters.AddWithValue("@from", fromUsername); }, tx);

                    if (deductRows == 0)
                        throw new InsufficientBalanceException(fromUsername, from.Balance, amount);

                    Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance + @amount WHERE username = @to",
                        cmd => { cmd.Parameters.AddWithValue("@amount", amount); cmd.Parameters.AddWithValue("@to", toUsername); }, tx);
                });
            }
            catch (InsufficientBalanceException) { throw; }
            catch (Exception ex)
            {
                AuditLog.Log("UserManager", $"Transfer failed {fromUsername}->{toUsername} ({amount:N0}): {ex.Message}");
                throw;
            }

            AuditLog.Log("UserManager", $"Transfer {amount:N0} تومان from {fromUsername} to {toUsername}");
        }

        /// <summary>
        /// Protect user credit during disconnect - deducts the actual used cost
        /// using an atomic delta update (MAX(0, balance - cost)) so a concurrent
        /// deduction cannot be lost. Returns the protected (remaining) balance.
        /// </summary>
        public decimal ProtectCreditOnDisconnect(string username, int usedMinutes, decimal pricePerHour)
        {
            var user = FindByUsername(username);
            if (user == null) return 0;

            decimal cost = Math.Round(pricePerHour / 60 * usedMinutes, 0);
            if (cost <= 0) return user.Balance;

            // Atomic delta update — no read-modify-write window for the lost-update race.
            Database.Instance.ExecuteNonQuery(
                "UPDATE users SET balance = MAX(0, balance - @cost) WHERE username = @u",
                cmd => { cmd.Parameters.AddWithValue("@cost", cost); cmd.Parameters.AddWithValue("@u", username); });

            decimal remaining = Math.Max(0, user.Balance - cost);
            AuditLog.Log("UserManager", $"Credit protected for {username}: used {usedMinutes}min, cost {cost:N0}, remaining {remaining:N0}");
            return remaining;
        }

        public void UpdateUser(int id, string displayName = null, string phone = null, bool? isActive = null)
        {
            var sets = new List<string>();
            if (displayName != null) sets.Add("display_name = @d");
            if (phone != null) sets.Add("phone = @p");
            if (isActive.HasValue) sets.Add("is_active = @a");
            if (sets.Count == 0) return;

            Database.Instance.Execute(
                $"UPDATE users SET {string.Join(", ", sets)} WHERE id = @id",
                cmd =>
                {
                    if (displayName != null) cmd.Parameters.AddWithValue("@d", displayName);
                    if (phone != null) cmd.Parameters.AddWithValue("@p", phone);
                    if (isActive.HasValue) cmd.Parameters.AddWithValue("@a", isActive.Value);
                    cmd.Parameters.AddWithValue("@id", id);
                });
        }

        public void ChangePassword(string username, string currentPassword, string newPassword)
        {
            var user = FindByUsername(username);
            if (user == null) throw new KeyNotFoundException("کاربر یافت نشد");

            var storedHash = Database.Instance.QueryOne(
                "SELECT password_hash FROM users WHERE username = @u",
                cmd => cmd.Parameters.AddWithValue("@u", username), r => r.GetString(0));

            // Verify current password (handles both PBKDF2 and legacy SHA-256 hashes).
            if (!VerifyPassword(currentPassword, storedHash))
                throw new UnauthorizedAccessException("رمز عبور فعلی اشتباه است");

            var (pwValid, pwErr) = InputValidator.ValidatePassword(newPassword);
            if (!pwValid) throw new ArgumentException(pwErr);

            Database.Instance.Execute(
                "UPDATE users SET password_hash = @h WHERE username = @u",
                cmd => { cmd.Parameters.AddWithValue("@h", HashPassword(newPassword)); cmd.Parameters.AddWithValue("@u", username); });
        }

        public void ResetPassword(string username, string newPassword)
        {
            var (pwValid, pwErr) = InputValidator.ValidatePassword(newPassword);
            if (!pwValid) throw new ArgumentException(pwErr);
            Database.Instance.Execute(
                "UPDATE users SET password_hash = @h WHERE username = @u",
                cmd => { cmd.Parameters.AddWithValue("@h", HashPassword(newPassword)); cmd.Parameters.AddWithValue("@u", username); });
            // Clear any active lockout for this member after a successful reset.
            _lockouts.TryRemove(username ?? "", out _);
            AuditLog.Log("UserManager", $"Password reset for {username}");
        }

        public void DeleteUser(int id)
        {
            Database.Instance.Execute("DELETE FROM users WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("UserManager", $"User {id} deleted");
        }

        public List<UserInfo> GetAllUsers()
        {
            return Database.Instance.Query(
                "SELECT id, username, display_name, balance, is_active, created_at, phone FROM users ORDER BY username",
                null,
                r => new UserInfo
                {
                    Id = r.GetInt32(0), Username = r.GetString(1),
                    DisplayName = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2),
                    Balance = r.GetDecimal(3), IsActive = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    Phone = r.IsDBNull(6) ? "" : r.GetString(6)
                });
        }

        public PagedResult<UserInfo> GetUsersPaged(int page, int pageSize, string search = "")
        {
            string where = "";
            Action<SQLiteCommand> param = null;
            if (!string.IsNullOrWhiteSpace(search))
            {
                where = " WHERE username LIKE @q OR display_name LIKE @q OR phone LIKE @q";
                param = cmd => cmd.Parameters.AddWithValue("@q", $"%{search}%");
            }

            return Database.Instance.QueryPaged(
                $"SELECT id, username, display_name, balance, is_active, created_at, phone FROM users{where} ORDER BY username",
                $"SELECT COUNT(*) FROM users{where}",
                page, pageSize, param,
                r => new UserInfo
                {
                    Id = r.GetInt32(0), Username = r.GetString(1),
                    DisplayName = r.IsDBNull(2) ? r.GetString(1) : r.GetString(2),
                    Balance = r.GetDecimal(3), IsActive = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    Phone = r.IsDBNull(6) ? "" : r.GetString(6)
                });
        }

        /// <summary>
        /// Authenticate a member by username + password. Implements in-memory
        /// lockout: after <see cref="MaxFailedAttempts"/> failed attempts the
        /// account is locked for <see cref="LockoutDuration"/>. Successful login
        /// clears the counter. Password verification supports both the new
        /// PBKDF2 format and the legacy unsalted SHA-256 format (which is then
        /// transparently upgraded to PBKDF2 on next successful login).
        /// </summary>
        public bool Authenticate(string username, string password)
        {
            if (string.IsNullOrEmpty(username)) return false;
            var key = username.ToLowerInvariant();

            // --- Lockout check (in-memory fallback) ---
            if (_lockouts.TryGetValue(key, out var lockout))
            {
                if (lockout.LockedUntil > DateTime.UtcNow)
                {
                    AuditLog.Log("UserManager", $"Member {username} login rejected: locked until {lockout.LockedUntil:o}");
                    return false;
                }
                // Lockout expired - reset counter so a fresh window starts.
                _lockouts.TryUpdate(key, (0, DateTime.MinValue), lockout);
            }

            var stored = Database.Instance.QueryOne(
                "SELECT password_hash FROM users WHERE username = @u AND is_active = 1",
                cmd => cmd.Parameters.AddWithValue("@u", username), r => r.GetString(0));

            bool ok = VerifyPassword(password, stored);
            if (!ok)
            {
                int attempts;
                DateTime lockedUntil;
                _lockouts.AddOrUpdate(
                    key,
                    _ => (1, DateTime.MinValue),
                    (_, cur) =>
                    {
                        attempts = cur.Attempts + 1;
                        lockedUntil = attempts >= MaxFailedAttempts ? DateTime.UtcNow.Add(LockoutDuration) : cur.LockedUntil;
                        return (attempts, lockedUntil);
                    });

                // Re-read to decide on the lock message
                if (_lockouts.TryGetValue(key, out var after) && after.LockedUntil > DateTime.UtcNow)
                {
                    AuditLog.Log("UserManager", $"Member {username} locked out after {after.Attempts} failed attempts for {LockoutDuration.TotalMinutes} min");
                }
                return false;
            }

            // Successful authentication: clear lockout counter.
            _lockouts.TryRemove(key, out _);

            // Transparent upgrade: if the stored hash is legacy SHA-256, re-hash
            // with PBKDF2 and persist. Failure to upgrade must NOT block login.
            if (stored != null && !stored.Contains("."))
            {
                try
                {
                    Database.Instance.Execute(
                        "UPDATE users SET password_hash = @h WHERE username = @u",
                        cmd => { cmd.Parameters.AddWithValue("@h", HashPassword(password)); cmd.Parameters.AddWithValue("@u", username); });
                    AuditLog.Log("UserManager", $"Password hash upgraded to PBKDF2 for {username}");
                }
                catch (Exception ex)
                {
                    AuditLog.Log("UserManager", $"Failed to upgrade hash for {username}: {ex.Message}");
                }
            }
            return true;
        }

        // =========================================================================
        // Password hashing helpers (PBKDF2-SHA256 with per-user random salt).
        // Stored format: "{iterations}.{base64salt}.{base64hash}"
        // =========================================================================

        private static string HashPassword(string password)
        {
            if (password == null) throw new ArgumentNullException(nameof(password));
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Pbkdf2Iterations, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(HashSize);
                return $"{Pbkdf2Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
            }
        }

        /// <summary>
        /// Verifies a password against a stored hash. Supports both the new
        /// PBKDF2 format ("iter.salt.hash") and the legacy unsalted SHA-256
        /// hex digest. Comparison is constant-time. Returns false for any
        /// malformed input instead of throwing - callers treat false as auth
        /// failure and the in-memory lockout handles repeat attempts.
        /// </summary>
        private static bool VerifyPassword(string password, string stored)
        {
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(stored)) return false;

            // PBKDF2 format?
            if (stored.Contains("."))
            {
                var parts = stored.Split('.');
                if (parts.Length != 3) return false;
                if (!int.TryParse(parts[0], out int iter) || iter <= 0) return false;
                byte[] salt;
                byte[] expected;
                try
                {
                    salt = Convert.FromBase64String(parts[1]);
                    expected = Convert.FromBase64String(parts[2]);
                }
                catch { return false; }
                if (expected.Length == 0) return false;
                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iter, HashAlgorithmName.SHA256))
                {
                    byte[] actual = pbkdf2.GetBytes(expected.Length);
                    return CryptographicEquals(actual, expected);
                }
            }

            // Legacy: unsalted single-round SHA-256 hex digest.
            string legacy = LegacySha256Hash(password);
            return ConstantTimeStringEquals(legacy, stored);
        }

        private static bool ConstantTimeStringEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        private static bool CryptographicEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        /// <summary>
        /// LEGACY: unsalted single-round SHA-256 hex digest. Kept ONLY to verify
        /// pre-existing member password_hash rows so they can be transparently
        /// upgraded to PBKDF2 on the next successful login. Do NOT use for new
        /// passwords - use <see cref="HashPassword"/> instead.
        /// </summary>
        private static string LegacySha256Hash(string input)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(input))).Replace("-", "").ToLowerInvariant();
        }

        /// <summary>
        /// Creates a default client user (random initial password) if no
        /// users exist. This is the account CLIENTS use to log in — it's
        /// separate from the operator account (which is for the server
        /// admin panel). Without this, the client login screen has no valid
        /// credentials to authenticate against. Idempotent: only creates if
        /// the "admin" user doesn't exist.
        ///
        /// NOTE: We bypass InputValidator.ValidatePassword (which requires
        /// letter+digit) and insert directly into the DB because this is a
        /// system-bootstrap record, not user input. The operator can change
        /// the password later from the server admin panel.
        ///
        /// FIX SEC-1: this used to hardcode "admin"/"password" — identical
        /// to the well-known default this codebase also used for the
        /// server-operator account (see OperatorManager.EnsureDefaultOperator,
        /// which had the same problem and is fixed the same way). Anyone
        /// who knew the (undocumented-but-guessable) default could log in
        /// as a customer for free over the network. Generates its own
        /// random password — deliberately NOT reusing the operator's
        /// password — so compromising one login doesn't hand over the

        /// </summary>
        public static void EnsureDefaultUser()
        {
            try
            {
                var mgr = new UserManager();
                // If the user "admin" already exists, leave it alone.
                if (mgr.FindByUsername("admin") != null) return;
                // Plain default password — admin/password, same as the operator
                // account. No random one-time value, no extra text file.
                string clientPassword = "password";
                string hash = HashPassword(clientPassword);
                Database.Instance.Execute(
                    "INSERT INTO users (username, password_hash, display_name, balance, is_active, created_at, phone) " +
                    "VALUES (@u, @h, @d, @b, 1, @c, @p)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@u", "admin");
                        cmd.Parameters.AddWithValue("@h", hash);
                        cmd.Parameters.AddWithValue("@d", "مدیر گیم‌نت");
                        cmd.Parameters.AddWithValue("@b", 0);
                        cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@p", "");
                    });
                AuditLog.Log("UserManager", "Default client user created (username=admin, password=password). Please change the password from the server admin panel (Users section).");
            }
            catch (Exception ex)
            {
                AuditLog.Log("UserManager", "EnsureDefaultUser error: " + ex.Message);
            }
        }
    }

    public class UserInfo
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string DisplayName { get; set; }
        public decimal Balance { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Phone { get; set; }
    }
}
