using System;
using System.Collections.Generic;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Round 14: "🕵️ وقتی نبودم" — a plain-Persian journal of what happened in the café:
    /// who logged in, which tabs were opened, which settings were saved (on the server and
    /// on the kiosks), stations switched on/off, sessions, time and credit, customer
    /// requests, remote control, reservations, crashes and self-repair. Each line has the
    /// time, the kind, the station and the operator who was logged in.
    /// Stored in the table activity_journal (created on first use), kept 180 days.
    /// The technical audit_log stays as it was.
    /// </summary>
    public static class ActivityJournal
    {
        // kinds (shown with their emoji in the viewer)
        public const string Operator = "👤 اپراتور";
        public const string Tab = "🗂️ تب";
        public const string Settings = "⚙️ تنظیمات";
        public const string KioskSettings = "💻 تنظیمات کلاینت";
        public const string Station = "🖥️ سیستم";
        public const string Session = "🎮 نشست";
        public const string TimeCredit = "⏱️ زمان و اعتبار";
        public const string Command = "📡 فرمان به سیستم";
        public const string Request = "🙋 درخواست مشتری";
        public const string Remote = "🖱️ کنترل از راه دور";
        public const string Reservation = "📅 رزرو";
        public const string Repair = "🛠️ خرابی و تعمیر";
        public const string Server = "🗄️ سرور";

        public static readonly string[] Kinds =
        {
            Operator, Tab, Settings, KioskSettings, Station, Session, TimeCredit, Command,
            Request, Remote, Reservation, Repair, Server
        };

        /// <summary>Who is logged in on the server now (set by MainForm).</summary>
        public static volatile string CurrentOperator = "";

        private static object _tableReadyFor; // the Database instance the table was made in
        private static readonly object _gate = new object();

        public sealed class Entry
        {
            public long Id;
            public DateTime Time;      // local time
            public string Operator;
            public string Kind;
            public string Station;
            public string Text;
        }

        private static void EnsureTable()
        {
            var db = Database.Instance;
            if (ReferenceEquals(_tableReadyFor, db)) return;
            lock (_gate)
            {
                if (ReferenceEquals(_tableReadyFor, db)) return;
                Database.Instance.Execute(
                    "CREATE TABLE IF NOT EXISTS activity_journal (id INTEGER PRIMARY KEY AUTOINCREMENT, time_utc TEXT NOT NULL, operator TEXT, kind TEXT NOT NULL, station TEXT, text TEXT NOT NULL)", null);
                Database.Instance.Execute("CREATE INDEX IF NOT EXISTS ix_activity_journal_time ON activity_journal(time_utc)", null);
                _tableReadyFor = db;
            }
        }

        /// <summary>Records one line. Never throws.</summary>
        public static void Record(string kind, string text, string station = null)
        {
            try
            {
                EnsureTable();
                Database.Instance.Execute(
                    "INSERT INTO activity_journal (time_utc, operator, kind, station, text) VALUES (@t, @o, @k, @s, @x)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@o", CurrentOperator ?? "");
                        cmd.Parameters.AddWithValue("@k", kind ?? "");
                        cmd.Parameters.AddWithValue("@s", station ?? "");
                        cmd.Parameters.AddWithValue("@x", text ?? "");
                    });
            }
            catch { }
        }

        /// <summary>Lines between two UTC times (newest first), optionally one kind and a search text.</summary>
        public static List<Entry> Query(DateTime fromUtc, DateTime toUtc, string kind = null, string search = null, int max = 5000)
        {
            var list = new List<Entry>();
            try
            {
                EnsureTable();
                string sql = "SELECT id, time_utc, operator, kind, station, text FROM activity_journal WHERE time_utc >= @f AND time_utc <= @to";
                if (!string.IsNullOrEmpty(kind)) sql += " AND kind = @k";
                if (!string.IsNullOrWhiteSpace(search)) sql += " AND (text LIKE @q OR station LIKE @q OR operator LIKE @q)";
                sql += " ORDER BY id DESC LIMIT " + Math.Max(1, Math.Min(50000, max));
                var rows = Database.Instance.Query(sql, cmd =>
                {
                    cmd.Parameters.AddWithValue("@f", fromUtc.ToString("o"));
                    cmd.Parameters.AddWithValue("@to", toUtc.ToString("o"));
                    if (!string.IsNullOrEmpty(kind)) cmd.Parameters.AddWithValue("@k", kind);
                    if (!string.IsNullOrWhiteSpace(search)) cmd.Parameters.AddWithValue("@q", "%" + search.Trim() + "%");
                }, r => new Entry
                {
                    Id = r.GetInt64(0),
                    Time = ParseUtc(Convert.ToString(r.GetValue(1))),
                    Operator = r.IsDBNull(2) ? "" : r.GetString(2),
                    Kind = r.IsDBNull(3) ? "" : r.GetString(3),
                    Station = r.IsDBNull(4) ? "" : r.GetString(4),
                    Text = r.IsDBNull(5) ? "" : r.GetString(5),
                });
                list.AddRange(rows);
            }
            catch { }
            return list;
        }

        /// <summary>When this operator last logged out or closed the server (UTC), or null.</summary>
        public static DateTime? LastLeaveOf(string operatorName)
        {
            try
            {
                EnsureTable();
                var s = Database.Instance.QueryOne(
                    "SELECT time_utc FROM activity_journal WHERE operator = @o AND ((kind = @k1 AND text LIKE 'خروج%') OR (kind = @k2 AND text LIKE 'سرور بسته%')) ORDER BY id DESC LIMIT 1",
                    cmd => { cmd.Parameters.AddWithValue("@o", operatorName ?? ""); cmd.Parameters.AddWithValue("@k1", Operator); cmd.Parameters.AddWithValue("@k2", Server); },
                    r => Convert.ToString(r.GetValue(0)));
                if (string.IsNullOrEmpty(s)) return null;
                return ParseUtc(s).ToUniversalTime();
            }
            catch { return null; }
        }

        public static int CountSince(DateTime fromUtc)
        {
            try
            {
                EnsureTable();
                return Database.Instance.QueryOne("SELECT COUNT(*) FROM activity_journal WHERE time_utc >= @f",
                    cmd => cmd.Parameters.AddWithValue("@f", fromUtc.ToString("o")), r => r.GetInt32(0));
            }
            catch { return 0; }
        }

        public static void Cleanup(int days = 180)
        {
            try
            {
                EnsureTable();
                Database.Instance.ExecuteNonQuery("DELETE FROM activity_journal WHERE time_utc < @c",
                    cmd => cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.AddDays(-days).ToString("o")));
            }
            catch { }
        }

        private static DateTime ParseUtc(string s)
        {
            DateTime d;
            if (DateTime.TryParse(s, null, System.Globalization.DateTimeStyles.RoundtripKind, out d))
                return d.Kind == DateTimeKind.Utc ? d.ToLocalTime() : d;
            return DateTime.MinValue;
        }
    }
}
