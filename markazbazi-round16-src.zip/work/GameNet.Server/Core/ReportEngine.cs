using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Generates financial and usage reports with date range filtering.
    /// Reports include: daily/weekly/monthly revenue, session stats, top users, station utilization.
    /// </summary>
    public class ReportEngine
    {
        public class RevenueReport
        {
            public DateTime PeriodStart;
            public DateTime PeriodEnd;
            public decimal TotalRevenue;
            public decimal SessionRevenue;
            public decimal FoodRevenue;
            public decimal PrintRevenue;
            public int TotalSessions;
            public int TotalUniqueUsers;
            public decimal AverageSessionCost;
            public int AverageSessionMinutes;
            public List<DailyRevenue> DailyBreakdown;
        }

        public class DailyRevenue
        {
            public DateTime Date;
            public decimal Revenue;
            public int Sessions;
            public int UniqueUsers;
        }

        public class StationUtilization
        {
            public string StationName;
            public int TotalSessions;
            public int TotalMinutes;
            public decimal TotalRevenue;
            public double UtilizationPercent;
        }

        public class TopUser
        {
            public string Username;
            public string DisplayName;
            public int TotalSessions;
            public decimal TotalSpent;
            public int TotalMinutes;
        }

        public RevenueReport GetRevenueReport(DateTime from, DateTime to)
        {
            var report = new RevenueReport
            {
                PeriodStart = from,
                PeriodEnd = to,
                DailyBreakdown = new List<DailyRevenue>()
            };

            var fromStr = from.ToString("o");
            var toStr = to.ToString("o");

            // Session revenue
            var sessionData = Database.Instance.QueryOne(
                "SELECT COALESCE(SUM(total_cost), 0), COUNT(*), COUNT(DISTINCT username), COALESCE(AVG(total_cost), 0), COALESCE(AVG(duration_minutes), 0) FROM client_sessions WHERE start_time >= @from AND start_time <= @to AND end_time IS NOT NULL",
                cmd => { cmd.Parameters.AddWithValue("@from", fromStr); cmd.Parameters.AddWithValue("@to", toStr); },
                r => new
                {
                    Revenue = r.GetDecimal(0),
                    Sessions = r.GetInt32(1),
                    UniqueUsers = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                    AvgCost = r.GetDecimal(3),
                    AvgMins = r.IsDBNull(4) ? 0 : r.GetInt32(4)
                });

            if (sessionData != null)
            {
                report.SessionRevenue = sessionData.Revenue;
                report.TotalSessions = sessionData.Sessions;
                report.TotalUniqueUsers = sessionData.UniqueUsers;
                report.AverageSessionCost = sessionData.AvgCost;
                report.AverageSessionMinutes = sessionData.AvgMins;
            }

            // Food revenue
            try
            {
                var foodRev = Database.Instance.QueryOne(
                    "SELECT COALESCE(SUM(fi.price * fo.quantity), 0) FROM food_orders fo JOIN food_items fi ON fo.food_item_id = fi.id WHERE fo.created_at >= @from AND fo.created_at <= @to AND fo.status = 'delivered'",
                    cmd => { cmd.Parameters.AddWithValue("@from", fromStr); cmd.Parameters.AddWithValue("@to", toStr); },
                    r => r.GetDecimal(0));
                report.FoodRevenue = foodRev;
            }
            catch { report.FoodRevenue = 0; }

            // Print revenue
            try
            {
                var printRev = Database.Instance.QueryOne(
                    "SELECT COALESCE(SUM(cost), 0) FROM print_jobs WHERE created_at >= @from AND created_at <= @to AND status = 'completed'",
                    cmd => { cmd.Parameters.AddWithValue("@from", fromStr); cmd.Parameters.AddWithValue("@to", toStr); },
                    r => r.GetDecimal(0));
                report.PrintRevenue = printRev;
            }
            catch { report.PrintRevenue = 0; }

            report.TotalRevenue = report.SessionRevenue + report.FoodRevenue + report.PrintRevenue;

            // Daily breakdown
            var dailyData = Database.Instance.Query(
                "SELECT DATE(start_time) as day, COALESCE(SUM(total_cost), 0), COUNT(*), COUNT(DISTINCT username) FROM client_sessions WHERE start_time >= @from AND start_time <= @to AND end_time IS NOT NULL GROUP BY DATE(start_time) ORDER BY day",
                cmd => { cmd.Parameters.AddWithValue("@from", fromStr); cmd.Parameters.AddWithValue("@to", toStr); },
                r => new DailyRevenue
                {
                    Date = r.GetDateTime(0),
                    Revenue = r.GetDecimal(1),
                    Sessions = r.GetInt32(2),
                    UniqueUsers = r.IsDBNull(3) ? 0 : r.GetInt32(3)
                });
            report.DailyBreakdown = dailyData;

            // Save snapshot
            try
            {
                Database.Instance.Execute(
                    "INSERT INTO report_snapshots (report_type, period_start, period_end, data_json, created_at) VALUES (@type, @ps, @pe, @json, @ca)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@type", "revenue");
                        cmd.Parameters.AddWithValue("@ps", fromStr);
                        cmd.Parameters.AddWithValue("@pe", toStr);
                        cmd.Parameters.AddWithValue("@json", Newtonsoft.Json.JsonConvert.SerializeObject(report));
                        cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                    });
            }
            catch { }

            return report;
        }

        public List<StationUtilization> GetStationUtilization(DateTime from, DateTime to)
        {
            var fromStr = from.ToString("o");
            var toStr = to.ToString("o");
            int totalMinutesInPeriod = (int)(to - from).TotalMinutes;
            if (totalMinutesInPeriod <= 0) totalMinutesInPeriod = 1;

            return Database.Instance.Query(
                "SELECT station_name, COUNT(*), COALESCE(SUM(duration_minutes), 0), COALESCE(SUM(total_cost), 0) FROM client_sessions WHERE start_time >= @from AND start_time <= @to AND station_name IS NOT NULL GROUP BY station_name ORDER BY SUM(total_cost) DESC",
                cmd => { cmd.Parameters.AddWithValue("@from", fromStr); cmd.Parameters.AddWithValue("@to", toStr); },
                r => new StationUtilization
                {
                    StationName = r.GetString(0),
                    TotalSessions = r.GetInt32(1),
                    TotalMinutes = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                    TotalRevenue = r.GetDecimal(3),
                    UtilizationPercent = Math.Round((double)(r.IsDBNull(2) ? 0 : r.GetInt32(2)) / totalMinutesInPeriod * 100, 1)
                });
        }

        public List<TopUser> GetTopUsers(DateTime from, DateTime to, int limit = 20)
        {
            var fromStr = from.ToString("o");
            var toStr = to.ToString("o");

            return Database.Instance.Query(
                "SELECT cs.username, COALESCE(u.display_name, cs.username), COUNT(*), COALESCE(SUM(cs.total_cost), 0), COALESCE(SUM(cs.duration_minutes), 0) FROM client_sessions cs LEFT JOIN users u ON cs.username = u.username WHERE cs.start_time >= @from AND cs.start_time <= @to AND cs.username IS NOT NULL GROUP BY cs.username ORDER BY SUM(cs.total_cost) DESC LIMIT @lim",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@from", fromStr);
                    cmd.Parameters.AddWithValue("@to", toStr);
                    cmd.Parameters.AddWithValue("@lim", limit);
                },
                r => new TopUser
                {
                    Username = r.GetString(0),
                    DisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                    TotalSessions = r.GetInt32(2),
                    TotalSpent = r.GetDecimal(3),
                    TotalMinutes = r.IsDBNull(4) ? 0 : r.GetInt32(4)
                });
        }

        public decimal GetCurrentBalance()
        {
            try
            {
                return Database.Instance.QueryOne("SELECT COALESCE(SUM(balance), 0) FROM users WHERE is_active = 1", null, r => r.GetDecimal(0));
            }
            catch { return 0; }
        }

        public int GetActiveSessionCount()
        {
            try
            {
                return Database.Instance.QueryOne("SELECT COUNT(*) FROM client_sessions WHERE is_connected = 1", null, r => r.GetInt32(0));
            }
            catch { return 0; }
        }
    }
}
