using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class MobileApiFeature { public string Name = ""; public string Endpoint = ""; public bool Available; }
    public class CustomerMobileApi {
        public string GetStatus() { return "آماده"; }
        public string GetBaseUrl() { return "http://localhost:8082/api"; }
        public List<MobileApiFeature> GetFeatures() { return new List<MobileApiFeature> { new MobileApiFeature { Name = "مشاهده موجودی", Endpoint = "/balance", Available = true }, new MobileApiFeature { Name = "شارژ حساب", Endpoint = "/topup", Available = true }, new MobileApiFeature { Name = "تاریخچه نشست", Endpoint = "/sessions", Available = true }, new MobileApiFeature { Name = "گزارش‌ها", Endpoint = "/reports", Available = true } }; }
    }
}
