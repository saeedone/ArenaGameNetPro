using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages announcements that are displayed to clients on login or periodically.
    /// Supports info/warning/urgent levels with optional expiration.
    /// </summary>
    public class AnnouncementManager
    {
        public AnnouncementPayload CreateAnnouncement(string title, string body, string level = "info", DateTime? expiresAt = null, string createdBy = "")
        {
            if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("عنوان اطلاعیه الزامی است");
            if (string.IsNullOrWhiteSpace(body)) throw new ArgumentException("متن اطلاعیه الزامی است");

            string validLevel = level;
            if (validLevel != "info" && validLevel != "warning" && validLevel != "urgent")
                validLevel = "info";

            Database.Instance.Execute(
                "INSERT INTO announcements (title, body, level, is_active, created_by, created_at, expires_at) VALUES (@title, @body, @level, 1, @by, @ca, @exp)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@body", body);
                    cmd.Parameters.AddWithValue("@level", validLevel);
                    cmd.Parameters.AddWithValue("@by", createdBy ?? "");
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@exp", expiresAt.HasValue ? expiresAt.Value.ToString("o") : (object)DBNull.Value);
                });

            int id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));
            AuditLog.Log("Announcement", $"Announcement created: {title}");

            return GetAnnouncement(id);
        }

        public AnnouncementPayload GetAnnouncement(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, title, body, level, is_active, created_by, created_at, expires_at FROM announcements WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new AnnouncementPayload
                {
                    Id = r.GetInt32(0),
                    Title = r.GetString(1),
                    Body = r.GetString(2),
                    Level = r.GetString(3),
                    IsActive = r.GetBoolean(4),
                    CreatedByName = r.IsDBNull(5) ? "" : r.GetString(5),
                    CreatedAt = r.GetDateTime(6),
                    ExpiresAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7)
                });
        }

        /// <summary>
        /// Gets all active (non-expired) announcements for display to clients.
        /// </summary>
        public AnnouncementListPayload GetActiveAnnouncements()
        {
            var announcements = Database.Instance.Query(
                "SELECT id, title, body, level, is_active, created_by, created_at, expires_at FROM announcements WHERE is_active = 1 AND (expires_at IS NULL OR expires_at > @now) ORDER BY CASE level WHEN 'urgent' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END, created_at DESC",
                cmd => cmd.Parameters.AddWithValue("@now", DateTime.UtcNow.ToString("o")),
                r => new AnnouncementPayload
                {
                    Id = r.GetInt32(0),
                    Title = r.GetString(1),
                    Body = r.GetString(2),
                    Level = r.GetString(3),
                    IsActive = r.GetBoolean(4),
                    CreatedByName = r.IsDBNull(5) ? "" : r.GetString(5),
                    CreatedAt = r.GetDateTime(6),
                    ExpiresAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7)
                });

            return new AnnouncementListPayload { Announcements = announcements };
        }

        /// <summary>
        /// Gets all announcements (including inactive/expired) for management.
        /// </summary>
        public List<AnnouncementPayload> GetAllAnnouncements()
        {
            return Database.Instance.Query(
                "SELECT id, title, body, level, is_active, created_by, created_at, expires_at FROM announcements ORDER BY created_at DESC",
                null,
                r => new AnnouncementPayload
                {
                    Id = r.GetInt32(0),
                    Title = r.GetString(1),
                    Body = r.GetString(2),
                    Level = r.GetString(3),
                    IsActive = r.GetBoolean(4),
                    CreatedByName = r.IsDBNull(5) ? "" : r.GetString(5),
                    CreatedAt = r.GetDateTime(6),
                    ExpiresAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7)
                });
        }

        public void UpdateAnnouncement(int id, string title, string body, string level, bool isActive, DateTime? expiresAt)
        {
            string validLevel = level;
            if (validLevel != "info" && validLevel != "warning" && validLevel != "urgent")
                validLevel = "info";

            Database.Instance.Execute(
                "UPDATE announcements SET title = @title, body = @body, level = @level, is_active = @active, expires_at = @exp WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@body", body);
                    cmd.Parameters.AddWithValue("@level", validLevel);
                    cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                    cmd.Parameters.AddWithValue("@exp", expiresAt.HasValue ? expiresAt.Value.ToString("o") : (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@id", id);
                });

            AuditLog.Log("Announcement", $"Announcement updated: {title}");
        }

        public void DeleteAnnouncement(int id)
        {
            Database.Instance.Execute("DELETE FROM announcements WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("Announcement", $"Announcement deleted: ID {id}");
        }

        /// <summary>
        /// Deactivates expired announcements.
        /// </summary>
        public int DeactivateExpired()
        {
            Database.Instance.Execute(
                "UPDATE announcements SET is_active = 0 WHERE expires_at IS NOT NULL AND expires_at <= @now AND is_active = 1",
                cmd => cmd.Parameters.AddWithValue("@now", DateTime.UtcNow.ToString("o")));

            int count = Database.Instance.QueryOne("SELECT changes()", null, r => r.GetInt32(0));
            if (count > 0) AuditLog.Log("Announcement", $"{count} expired announcements deactivated");
            return count;
        }
    }
}
