using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class SmartNotification
    {
        private Timer _checkTimer;
        private readonly ClientCommunicator _communicator;

        public SmartNotification(ClientCommunicator communicator)
        {
            _communicator = communicator;
            _checkTimer = new Timer(CheckNotifications, null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));
        }

        private void CheckNotifications(object state)
        {
            try
            {
                CheckLowBalance();
                CheckExpiringSessions();
                CheckUnpaidDebts();
                CheckInactiveStations();
            }
            catch { }
        }

        private void CheckLowBalance()
        {
            var connected = _communicator.ConnectedClients.Where(c => c.State == ClientState.InSession).ToList();
            foreach (var client in connected)
            {
                if (string.IsNullOrEmpty(client.CurrentUser)) continue;
                var bal = Database.Instance.QueryOne("SELECT balance FROM users WHERE username = @u",
                    cmd => cmd.Parameters.AddWithValue("@u", client.CurrentUser), r => (decimal?)r.GetDecimal(0));
                if (bal.HasValue && bal.Value > 0 && bal.Value < 20000)
                {
                    _communicator.SendToStation(client.StationName, new Shared.NetMessage(Shared.MessageType.ServerTimeWarning,
                        new Shared.ServerTimeWarningPayload
                        {
                            MinutesRemaining = (int)(bal.Value / 15000 * 60),
                            Message = $"موجودی شما کم است: {bal.Value:N0} تومان. لطفاً شارژ کنید.",
                            IsCritical = bal.Value < 5000
                        }));
                }
            }
        }

        private void CheckExpiringSessions()
        {
            var now = DateTime.UtcNow;
            var sessions = Database.Instance.Query("SELECT session_id, station_name, username, start_time FROM client_sessions WHERE is_connected = 1 AND state = @st",
                cmd => cmd.Parameters.AddWithValue("@st", (int)ClientState.InSession),
                r => new { Sid = r.GetString(0), Station = r.GetString(1), User = r.GetString(2), Start = r.GetDateTime(3) });

            foreach (var s in sessions)
            {
                int elapsed = (int)(now - s.Start).TotalMinutes;
                int remaining = Math.Max(0, 120 - elapsed);
                if (remaining == 15 || remaining == 5 || remaining == 1)
                {
                    _communicator.SendToStation(s.Station, new Shared.NetMessage(Shared.MessageType.ServerTimeWarning,
                        new Shared.ServerTimeWarningPayload { MinutesRemaining = remaining, Message = $"{remaining} دقیقه تا پایان نشست باقی‌مانده", IsCritical = remaining <= 5 }));
                }
            }
        }

        private void CheckUnpaidDebts()
        {
            try
            {
                var unpaid = new DebtManager().GetAllUnpaidDebts();
                if (unpaid.TotalDebt > 0)
                {
                    var operators = Database.Instance.Query("SELECT username FROM operators WHERE is_active = 1 AND (permissions & 4096) = 4096", null, r => r.GetString(0));
                    foreach (var op in operators)
                    {
                        EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Debt, "UnpaidDebtReminder", $"Total unpaid: {unpaid.TotalDebt:N0}", EnhancedAuditLog.AuditLevel.Warning);
                    }
                }
            }
            catch { }
        }

        private void CheckInactiveStations()
        {
            var stations = new StationManager().GetAllStations();
            var connected = _communicator.ConnectedClients.Select(c => c.StationName).ToList();
            var inactive = stations.Where(s => s.Status == "available" && !connected.Contains(s.Name)).ToList();
            if (inactive.Count > 0 && inactive.Count == stations.Count)
                EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Network, "AllStationsOffline", $"All {inactive.Count} stations appear offline", EnhancedAuditLog.AuditLevel.Warning);
        }

        public List<NotificationItem> GetRecentNotifications(int count = 20)
        {
            try
            {
                return EnhancedAuditLog.Query(limit: count)
                    .Where(e => e.Level == "Warning" || e.Level == "Error" || e.Level == "Critical")
                    .Select(e => new NotificationItem { Time = e.Timestamp, Category = e.Category, Message = $"{e.Action}: {e.Details}", Level = e.Level })
                    .ToList();
            }
            catch { return new List<NotificationItem>(); }
        }
    }

    public class NotificationItem { public DateTime Time; public string Category; public string Message; public string Level; }
}
