using System;
using System.Collections.Generic;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class SmartPricing
    {
        public List<PricingRule> GetActiveRules()
        {
            try
            {
                return Database.Instance.Query<PricingRule>("SELECT id, name, rule_type, condition_json, discount_percent, is_active, priority FROM smart_pricing_rules WHERE is_active = 1 ORDER BY priority",
                    null, r => new PricingRule { Id = r.GetInt32(0), Name = r.GetString(1), RuleType = r.GetString(2), ConditionJson = r.IsDBNull(3) ? "" : r.GetString(3), DiscountPercent = r.GetDecimal(4), IsActive = r.GetBoolean(5), Priority = r.GetInt32(6) });
            }
            catch { return new List<PricingRule>(); }
        }

        public decimal CalculateEffectivePrice(string username, string stationName, decimal basePricePerHour)
        {
            decimal price = basePricePerHour;
            var rules = GetActiveRules();

            foreach (var rule in rules)
            {
                switch (rule.RuleType)
                {
                    case "time_of_day":
                        var cond = Newtonsoft.Json.JsonConvert.DeserializeObject<TimeOfDayCondition>(rule.ConditionJson);
                        if (cond != null && IsInTimeRange(cond.StartHour, cond.EndHour))
                            price = Math.Round(price * (1 - rule.DiscountPercent / 100), 0);
                        break;
                    case "day_of_week":
                        var dowCond = Newtonsoft.Json.JsonConvert.DeserializeObject<DayOfWeekCondition>(rule.ConditionJson);
                        // Use UtcNow consistently — all server-side time comparisons
                        // (rule evaluation, traffic prediction, session timestamps)
                        // are UTC-based so that admin-configured rule hours line up
                        // with the UTC hours stored in client_sessions.start_time.
                        if (dowCond != null && dowCond.Days.Contains((int)DateTime.UtcNow.DayOfWeek))
                            price = Math.Round(price * (1 - rule.DiscountPercent / 100), 0);
                        break;
                    case "low_traffic":
                        var traffic = GetCurrentTrafficLevel();
                        if (traffic <= 0.3m)
                            price = Math.Round(price * (1 - rule.DiscountPercent / 100), 0);
                        break;
                    case "loyalty":
                        try
                        {
                            var discount = new MemberTierManager().GetUserDiscount(username);
                            if (discount > 0) price = Math.Round(price * (1 - discount / 100), 0);
                        }
                        catch { }
                        break;
                    case "station_category":
                        var stCond = Newtonsoft.Json.JsonConvert.DeserializeObject<StationCategoryCondition>(rule.ConditionJson);
                        if (stCond != null)
                        {
                            var station = new StationManager().FindByName(stationName);
                            if (station != null && station.Category == stCond.Category)
                                price = Math.Round(price * (1 - rule.DiscountPercent / 100), 0);
                        }
                        break;
                }
            }
            return price;
        }

        private bool IsInTimeRange(int startHour, int endHour)
        {
            // Evaluate against UTC — see CalculateEffectivePrice for rationale.
            int now = DateTime.UtcNow.Hour;
            if (startHour <= endHour) return now >= startHour && now < endHour;
            return now >= startHour || now < endHour;
        }

        public decimal GetCurrentTrafficLevel()
        {
            try
            {
                int totalStations = Database.Instance.QueryOne("SELECT COUNT(*) FROM stations WHERE status = 'available'", null, r => r.GetInt32(0));
                int activeStations = Database.Instance.QueryOne("SELECT COUNT(DISTINCT station_name) FROM client_sessions WHERE is_connected = 1", null, r => r.GetInt32(0));
                return totalStations > 0 ? (decimal)activeStations / totalStations : 0;
            }
            catch { return 0.5m; }
        }

        public PricingRule CreateRule(string name, string ruleType, string conditionJson, decimal discountPercent, int priority = 0)
        {
            if (string.IsNullOrEmpty(name)) throw new ArgumentException("نام قانون الزامی است");
            if (discountPercent <= 0 || discountPercent > 100) throw new ArgumentException("درصد تخفیف باید بین ۱ تا ۱۰۰ باشد");

            Database.Instance.Execute("INSERT INTO smart_pricing_rules (name, rule_type, condition_json, discount_percent, is_active, priority) VALUES (@n, @t, @c, @d, 1, @p)",
                cmd => { cmd.Parameters.AddWithValue("@n", name); cmd.Parameters.AddWithValue("@t", ruleType); cmd.Parameters.AddWithValue("@c", conditionJson ?? ""); cmd.Parameters.AddWithValue("@d", discountPercent); cmd.Parameters.AddWithValue("@p", priority); });

            var id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Billing, "SmartPricingRuleCreated", name);
            return new PricingRule { Id = id, Name = name, RuleType = ruleType, ConditionJson = conditionJson, DiscountPercent = discountPercent, IsActive = true, Priority = priority };
        }

        public void DeleteRule(int ruleId)
        {
            Database.Instance.Execute("DELETE FROM smart_pricing_rules WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", ruleId));
        }

        public TrafficPrediction PredictTraffic(int nextHours = 24)
        {
            var prediction = new TrafficPrediction();
            try
            {
                var hourlyData = Database.Instance.Query("SELECT CAST(strftime('%H', start_time) AS INTEGER), COUNT(*) FROM client_sessions WHERE start_time >= @from GROUP BY CAST(strftime('%H', start_time) AS INTEGER)",
                    cmd => cmd.Parameters.AddWithValue("@from", DateTime.UtcNow.AddDays(-30).ToString("o")),
                    r => new { Hour = r.GetInt32(0), Count = r.GetInt32(1) });

                int currentHour = DateTime.UtcNow.Hour;
                for (int h = 0; h < nextHours; h++)
                {
                    int targetHour = (currentHour + h) % 24;
                    var data = hourlyData.FirstOrDefault(d => d.Hour == targetHour);
                    prediction.HourlyPredictions.Add(new HourlyPrediction { Hour = targetHour, PredictedClients = data?.Count ?? 0 });
                }
            }
            catch { }
            return prediction;
        }
    }

    public class PricingRule { public int Id; public string Name; public string RuleType; public string ConditionJson; public decimal DiscountPercent; public bool IsActive; public int Priority; }
    public class TimeOfDayCondition { public int StartHour; public int EndHour; }
    public class DayOfWeekCondition { public List<int> Days; }
    public class StationCategoryCondition { public string Category; }
    public class TrafficPrediction { public List<HourlyPrediction> HourlyPredictions = new List<HourlyPrediction>(); }
    public class HourlyPrediction { public int Hour; public int PredictedClients; }
}
