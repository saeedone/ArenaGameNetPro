using System; using System.Collections.Generic;
namespace GameNet.Server.Core {
    public class ManagedGame { public int Id; public string Name = ""; public string ExecutablePath = ""; public string Category = ""; public bool IsActive; }
    public class GameManager {
        public void AddGame(string name, string path, string category) { try { EnsureTable(); Database.Instance.Execute("INSERT INTO games (name, executable_path, category, is_active, created_at) VALUES (@n, @p, @c, 1, @t)", c => { c.Parameters.AddWithValue("@n", name); c.Parameters.AddWithValue("@p", path); c.Parameters.AddWithValue("@c", category); c.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); }); AuditLog.Log("GameManager", "Added: " + name); } catch { } }
        public List<ManagedGame> GetAllGames() { var list = new List<ManagedGame>(); try { EnsureTable(); Database.Instance.Query("SELECT id, name, executable_path, category, is_active FROM games ORDER BY name", null, r => { list.Add(new ManagedGame { Id = r.GetInt32(0), Name = r.GetString(1), ExecutablePath = r.IsDBNull(2) ? "" : r.GetString(2), Category = r.IsDBNull(3) ? "" : r.GetString(3), IsActive = r.GetBoolean(4) }); return true; }); } catch { } return list; }
        public void DeleteGame(int id) { try { Database.Instance.Execute("DELETE FROM games WHERE id=@id", c => c.Parameters.AddWithValue("@id", id)); } catch { } }
        private void EnsureTable() { Database.Instance.Execute("CREATE TABLE IF NOT EXISTS games (id INTEGER PRIMARY KEY, name TEXT, executable_path TEXT, category TEXT, is_active INTEGER DEFAULT 1, created_at TEXT)", null); }
    }
}
