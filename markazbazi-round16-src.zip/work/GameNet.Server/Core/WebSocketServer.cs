using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Basic WebSocket gateway for GameNet. Implements:
    ///   • ClientHello handshake (optional API-token auth via the
    ///     ClientHelloPayload.MacAddress field — or open if no token is
    ///     configured in the constructor)
    ///   • Chat broadcast: forwards incoming ClientChatSend to all WS clients
    ///     AND to TCP clients via the shared ClientCommunicator
    ///
    /// All other message types are rejected with a "not implemented" Error
    /// message so clients get a clear error instead of a silent no-op (the
    /// old default case). All exceptions are logged via AuditLog.
    ///
    /// NOTE: This is intentionally a minimal implementation. A full WS gateway
    /// would route every MessageType through a shared MessageDispatcher used
    /// by both TCP and WS; that larger refactor is out of scope for this fix
    /// wave — see the networking-reviewer's architecture note in the worklog.
    /// </summary>
    public class WebSocketServer : IDisposable
    {
        private HttpListener _listener;
        private readonly int _port;
        private volatile bool _running;
        private readonly ConcurrentDictionary<string, WebSocketConnection> _connections = new ConcurrentDictionary<string, WebSocketConnection>();
        private readonly ClientCommunicator _communicator;
        private readonly string _apiToken;

        public int ConnectedCount => _connections.Count;
        public event Action<string, string> OnWebSocketMessage;

        public WebSocketServer(ClientCommunicator communicator, int port = 9091, string apiToken = null)
        {
            _communicator = communicator;
            _port = port;
            _apiToken = apiToken;
        }

        public void Start()
        {
            _running = true;
            _listener = new HttpListener();
            _listener.Prefixes.Add($"http://+:{_port}/ws/");
            try { _listener.Start(); }
            catch (HttpListenerException)
            {
                _listener.Prefixes.Clear();
                _listener.Prefixes.Add($"http://localhost:{_port}/ws/");
                _listener.Start();
            }
            Task.Run(AcceptLoop);
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Network, "WebSocketServerStarted",
                $"Port: {_port}, Auth={(!string.IsNullOrEmpty(_apiToken) ? "token" : "open")}",
                EnhancedAuditLog.AuditLevel.Info);
        }

        public void Stop()
        {
            _running = false;
            foreach (var kvp in _connections)
            {
                try { kvp.Value.WebSocket.Dispose(); }
                catch (Exception ex) { AuditLog.Log("Network", "Error disposing WS in Stop: " + ex.Message); }
            }
            _connections.Clear();
            _listener?.Stop();
        }

        private async Task AcceptLoop()
        {
            while (_running)
            {
                try
                {
                    var ctx = await _listener.GetContextAsync();
                    if (!ctx.Request.IsWebSocketRequest) { ctx.Response.StatusCode = 400; ctx.Response.Close(); continue; }
                    var wsCtx = await ctx.AcceptWebSocketAsync(null);
                    var connId = Guid.NewGuid().ToString("N");
                    _connections[connId] = new WebSocketConnection { WebSocket = wsCtx.WebSocket, ConnectedAt = DateTime.UtcNow };
                    _ = HandleConnection(connId, wsCtx.WebSocket);
                }
                catch (Exception ex)
                {
                    if (!_running) break;
                    AuditLog.Log("Network", "Error in WS AcceptLoop: " + ex.Message);
                    break;
                }
            }
        }

        private async Task HandleConnection(string connId, WebSocket ws)
        {
            // Read into a MemoryStream until end-of-message so messages >8KB
            // and fragmented frames survive (fixes networking-reviewer #5/#6).
            var buffer = new byte[8192];
            try
            {
                while (_running && ws.State == WebSocketState.Open)
                {
                    MemoryStream ms = null;
                    WebSocketReceiveResult result;
                    do
                    {
                        result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                        if (result.MessageType == WebSocketMessageType.Close) { return; }
                        if (ms == null) ms = new MemoryStream();
                        await ms.WriteAsync(buffer, 0, result.Count);
                    } while (!result.EndOfMessage);

                    string json;
                    try { json = Encoding.UTF8.GetString(ms.ToArray()); }
                    finally { ms.Dispose(); }

                    try { OnWebSocketMessage?.Invoke(connId, json); }
                    catch (Exception ex) { AuditLog.Log("Network", "Error in OnWebSocketMessage handler: " + ex.Message); }

                    try
                    {
                        var msg = NetMessage.FromJson(json);
                        await HandleWebSocketMessage(connId, msg);
                    }
                    catch (Exception ex) { AuditLog.Log("Network", "Error handling WS message: " + ex.Message); }
                }
            }
            finally
            {
                _connections.TryRemove(connId, out _);
                try { ws.Dispose(); } catch (Exception ex) { AuditLog.Log("Network", "Error disposing WS: " + ex.Message); }
            }
        }

        private async Task HandleWebSocketMessage(string connId, NetMessage msg)
        {
            _connections.TryGetValue(connId, out var conn);
            bool isAuthenticated = conn?.IsAuthenticated ?? false;

            switch (msg.Type)
            {
                case MessageType.ClientHello:
                    // Optional API-token auth. If a token is configured, the
                    // client must supply it in ClientHelloPayload.MacAddress
                    // (an arbitrary field reused as the bearer token slot).
                    // If no token is configured, hello is open.
                    var h = msg.GetPayload<ClientHelloPayload>();
                    if (!string.IsNullOrEmpty(_apiToken))
                    {
                        string supplied = h?.MacAddress ?? h?.ClientVersion ?? "";
                        if (!ConstantTimeEquals(supplied, _apiToken))
                        {
                            await SendToClient(connId, new NetMessage(MessageType.Error, new { Error = "Unauthorized" }));
                            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Network, "WSAuthFail", $"ConnId: {connId}", EnhancedAuditLog.AuditLevel.Warning);
                            return;
                        }
                    }
                    if (conn != null)
                    {
                        conn.IsAuthenticated = true;
                        conn.StationName = "WebClient-" + connId.Substring(0, 6);
                    }
                    await SendToClient(connId, new NetMessage(MessageType.ServerWelcome,
                        new ServerWelcomePayload { ServerVersion = Protocol.ServerVersion, ServerName = "GameNet WebSocket", SessionId = connId }));
                    break;

                case MessageType.ClientChatSend:
                    if (!isAuthenticated)
                    {
                        await SendToClient(connId, new NetMessage(MessageType.Error, new { Error = "Authenticate first (send ClientHello)" }));
                        return;
                    }
                    var chat = msg.GetPayload<ChatSendPayload>();
                    if (chat == null) return;
                    if (string.IsNullOrEmpty(chat.SenderUsername)) chat.SenderUsername = "ws-" + connId.Substring(0, 6);
                    try
                    {
                        var result = new ChatManager().SendMessage(chat.SenderUsername, chat.Message, chat.TargetUsername, chat.IsBroadcast);
                        // Broadcast to all WS clients
                        await BroadcastAsync(new NetMessage(MessageType.ServerChatReceive, result));
                        // Forward to TCP clients via the shared communicator so
                        // kiosks connected over TCP also see the chat.
                        try { _communicator?.BroadcastMessage(new NetMessage(MessageType.ServerChatReceive, result)); }
                        catch (Exception ex) { AuditLog.Log("Network", "Error forwarding WS chat to TCP: " + ex.Message); }
                    }
                    catch (Exception ex) { AuditLog.Log("Network", "Error in WS chat: " + ex.Message); }
                    break;

                default:
                    // Marked not-implemented: client gets a clear error instead
                    // of the old silent no-op.
                    await SendToClient(connId, new NetMessage(MessageType.Error,
                        new { Error = "Not implemented over WebSocket", RequestedType = msg.Type.ToString() }));
                    break;
            }
        }

        public async Task SendToClient(string connId, NetMessage msg)
        {
            if (_connections.TryGetValue(connId, out var conn) && conn.WebSocket.State == WebSocketState.Open)
            {
                try
                {
                    var json = msg.ToJson();
                    var bytes = Encoding.UTF8.GetBytes(json);
                    await conn.WebSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
                }
                catch (Exception ex) { AuditLog.Log("Network", "Error sending to WS client: " + ex.Message); }
            }
        }

        public async Task BroadcastAsync(NetMessage msg)
        {
            var json = msg.ToJson();
            var bytes = Encoding.UTF8.GetBytes(json);
            foreach (var kvp in _connections)
            {
                if (kvp.Value.WebSocket.State == WebSocketState.Open)
                {
                    try { await kvp.Value.WebSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None); }
                    catch (Exception ex) { AuditLog.Log("Network", "Error broadcasting to WS: " + ex.Message); }
                }
            }
        }

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 8: broadcasts a raw JSON text frame to
        /// all connected WS clients. Used by <see cref="LiveUpdates"/> to push
        /// live-update events (client_connected, session_ended, etc.) without
        /// wrapping them in a NetMessage envelope — web dashboard clients
        /// parse the JSON object directly.
        /// </summary>
        public async Task BroadcastTextAsync(string json)
        {
            if (string.IsNullOrEmpty(json)) return;
            var bytes = Encoding.UTF8.GetBytes(json);
            foreach (var kvp in _connections)
            {
                if (kvp.Value.WebSocket.State == WebSocketState.Open)
                {
                    try { await kvp.Value.WebSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None); }
                    catch (Exception ex) { AuditLog.Log("Network", "Error broadcasting text to WS: " + ex.Message); }
                }
            }
        }

        // Constant-time string compare to avoid timing oracles on tokens.
        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return a == b;
            byte[] ab = Encoding.UTF8.GetBytes(a);
            byte[] bb = Encoding.UTF8.GetBytes(b);
            if (ab.Length != bb.Length) return false;
            int diff = 0;
            for (int i = 0; i < ab.Length; i++) diff |= ab[i] ^ bb[i];
            return diff == 0;
        }

        public void Dispose() { Stop(); }
    }

    public class WebSocketConnection
    {
        public WebSocket WebSocket;
        public DateTime ConnectedAt;
        public string StationName;
        public bool IsAuthenticated;
    }

    /// <summary>
    /// ADD-MULTI-FEATURES Feature 8: static live-update broadcaster.
    ///
    /// A thin shim that lets any server-side code push live events to
    /// connected WebSocket clients without holding a direct reference to
    /// the active <see cref="WebSocketServer"/> instance. MainForm
    /// registers the WebSocketServer here on Start; ClientCommunicator
    /// event handlers (and any other code path) call
    /// <see cref="Broadcast"/> to fan-out a JSON event of the form:
    /// <code>{ "type": "client_connected", "data": { ... }, "ts": "..." }</code>
    /// Web dashboard clients subscribe by connecting to ws://server:9091/ws/
    /// and listening for text frames.
    ///
    /// If no WebSocketServer is registered, Broadcast is a no-op (the
    /// server can run headless without WS subscribers).
    /// </summary>
    public static class LiveUpdates
    {
        private static WebSocketServer _server;
        private static readonly object _lock = new object();

        public static void Register(WebSocketServer server)
        {
            lock (_lock) { _server = server; }
        }

        public static void Unregister(WebSocketServer server)
        {
            lock (_lock) { if (ReferenceEquals(_server, server)) _server = null; }
        }

        /// <summary>
        /// Broadcasts a live event to all connected WS clients. eventType
        /// is a short string like "client_connected", "session_ended",
        /// "income_updated", "client_status_changed". payload is any JSON-
        /// serialisable object (anonymous types are fine).
        /// </summary>
        public static void Broadcast(string eventType, object payload)
        {
            WebSocketServer svr;
            lock (_lock) { svr = _server; }
            if (svr == null) return;
            try
            {
                var dict = new System.Collections.Generic.Dictionary<string, object>
                {
                    ["type"] = eventType,
                    ["data"] = payload,
                    ["ts"] = DateTime.UtcNow.ToString("o")
                };
                string json = JsonConvert.SerializeObject(dict);
                // Send the raw JSON as a text frame to all WS clients.
                // (This bypasses the NetMessage envelope — web clients
                // receive a plain JSON object they can parse directly.)
                _ = svr.BroadcastTextAsync(json);
            }
            catch (Exception ex) { AuditLog.Log("Network", "LiveUpdates.Broadcast error: " + ex.Message); }
        }
    }
}
