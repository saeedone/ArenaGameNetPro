using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class FoodOrderSystem
    {
        /// <summary>
        /// Place a single-item food order. Validates the user exists, the food
        /// item exists and is available, and the user's balance is sufficient;
        /// then atomically deducts the total cost and inserts the order row
        /// in a single transaction so the user cannot be charged without
        /// receiving an order record (or vice versa).
        /// </summary>
        public int PlaceOrder(string username, int foodItemId, int quantity = 1, string notes = "")
        {
            return PlaceOrder(username, new List<FoodOrderLine> { new FoodOrderLine { FoodItemId = foodItemId, Quantity = quantity } }, notes);
        }

        /// <summary>
        /// Place a multi-item food order. Computes the total cost as
        /// sum(item price * quantity) and deducts it atomically.
        /// </summary>
        public int PlaceOrder(string username, IList<FoodOrderLine> items, string notes = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (items == null || items.Count == 0) throw new ArgumentException("حداقل یک مورد غذایی الزامی است");

            // Validate the user exists.
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            // Validate the items and look up prices.
            var validItems = new List<(int FoodItemId, int Quantity, decimal Price, string Name)>(items.Count);
            foreach (var item in items)
            {
                if (item.Quantity <= 0) throw new ArgumentException("تعداد هر مورد باید بیشتر از صفر باشد");
                if (item.Quantity > 1000) throw new ArgumentException("تعداد هر مورد نمی‌تواند بیش از ۱۰۰۰ باشد");

                var foodItem = Database.Instance.QueryOne(
                    "SELECT id, name, price, is_available FROM food_items WHERE id = @id",
                    cmd => cmd.Parameters.AddWithValue("@id", item.FoodItemId),
                    r => new { Id = r.GetInt32(0), Name = r.GetString(1), Price = r.GetDecimal(2), Available = r.GetBoolean(3) });

                if (foodItem == null) throw new InvalidOperationException($"مورد غذایی با شناسه {item.FoodItemId} یافت نشد");
                if (!foodItem.Available) throw new InvalidOperationException($"مورد غذایی «{foodItem.Name}» در حال حاضر موجود نیست");

                validItems.Add((foodItem.Id, item.Quantity, foodItem.Price, foodItem.Name));
            }

            decimal totalCost = validItems.Sum(i => i.Price * i.Quantity);

            // Pre-check balance for a friendly Persian error message. The
            // actual deduction inside the transaction is conditional so a race
            // that drains the balance between this check and the deduction is
            // still safe — the txn rolls back.
            if (user.Balance < totalCost)
                throw new InsufficientBalanceException(username, user.Balance, totalCost);

            int orderId = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // Atomic conditional deduction of the total cost.
                    int balRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance - @amt WHERE username = @u AND balance >= @amt",
                        cmd => { cmd.Parameters.AddWithValue("@amt", totalCost); cmd.Parameters.AddWithValue("@u", username); }, tx);

                    if (balRows == 0)
                        throw new InsufficientBalanceException(username, user.Balance, totalCost);

                    // Insert the order header (first item).
                    var first = validItems[0];
                    Database.Instance.Execute(
                        "INSERT INTO food_orders (username, food_item_id, quantity, status, notes, created_at) VALUES (@u, @f, @q, 'pending', @n, @t)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@f", first.FoodItemId);
                            cmd.Parameters.AddWithValue("@q", first.Quantity);
                            cmd.Parameters.AddWithValue("@n", notes ?? "");
                            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                        }, tx);

                    orderId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);

                    // Insert additional items as separate rows (same order id
                    // is implicit via username + created_at proximity; the
                    // schema has no parent order_id column).
                    for (int i = 1; i < validItems.Count; i++)
                    {
                        var v = validItems[i];
                        Database.Instance.Execute(
                            "INSERT INTO food_orders (username, food_item_id, quantity, status, notes, created_at) VALUES (@u, @f, @q, 'pending', @n, @t)",
                            cmd =>
                            {
                                cmd.Parameters.AddWithValue("@u", username);
                                cmd.Parameters.AddWithValue("@f", v.FoodItemId);
                                cmd.Parameters.AddWithValue("@q", v.Quantity);
                                cmd.Parameters.AddWithValue("@n", notes ?? "");
                                cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o"));
                            }, tx);
                    }
                });
            }
            catch (InsufficientBalanceException) { throw; }
            catch (Exception ex)
            {
                AuditLog.Log("FoodOrderSystem", $"PlaceOrder failed for {username}: {ex.Message}");
                throw;
            }

            AuditLog.Log("FoodOrderSystem", $"Food order placed by {username}: {validItems.Count} item(s), total {totalCost:N0} Toman, order #{orderId}");
            return orderId;
        }

        public void UpdateStatus(int orderId, string status)
        {
            Database.Instance.Execute("UPDATE food_orders SET status = @s WHERE id = @id",
                cmd => { cmd.Parameters.AddWithValue("@s", status); cmd.Parameters.AddWithValue("@id", orderId); });
            if (status == "delivered")
                Database.Instance.Execute("UPDATE food_orders SET delivered_at = @t WHERE id = @id",
                    cmd => { cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("o")); cmd.Parameters.AddWithValue("@id", orderId); });
        }

        public PagedResult<(int Id, string Username, int FoodItemId, int Quantity, string Status, DateTime CreatedAt)> GetOrdersPaged(int page, int pageSize)
        {
            return Database.Instance.QueryPaged(
                "SELECT id, username, food_item_id, quantity, status, created_at FROM food_orders ORDER BY id DESC",
                "SELECT COUNT(*) FROM food_orders", page, pageSize, null,
                r => (r.GetInt32(0), r.GetString(1), r.GetInt32(2), r.GetInt32(3), r.GetString(4), r.GetDateTime(5)));
        }
    }

    /// <summary>
    /// Input DTO for multi-item food orders.
    /// </summary>
    public class FoodOrderLine
    {
        public int FoodItemId;
        public int Quantity;
    }
}
