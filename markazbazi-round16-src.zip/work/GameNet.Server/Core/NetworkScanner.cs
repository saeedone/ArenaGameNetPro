using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Automatic network scanner for discovering client PCs on the LAN.
    /// Uses Ping sweep and TCP port scanning to detect GameNet clients.
    /// </summary>
    public class NetworkScanner
    {
        public event Action<ScannedDevice> OnDeviceFound;
        public event Action<int, int> OnScanProgress; // current, total
        public event Action<List<ScannedDevice>> OnScanComplete;

        private CancellationTokenSource _cts;

        /// <summary>
        /// Get the local network subnet (e.g., "192.168.1").
        /// </summary>
        public string GetLocalSubnet()
        {
            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                var ip = host.AddressList.FirstOrDefault(a =>
                    a.AddressFamily == AddressFamily.InterNetwork &&
                    !a.ToString().StartsWith("127."));

                if (ip != null)
                {
                    var parts = ip.ToString().Split('.');
                    return $"{parts[0]}.{parts[1]}.{parts[2]}";
                }
            }
            catch { }
            return "192.168.1";
        }

        /// <summary>
        /// Scan the network for active devices.
        /// </summary>
        public void ScanNetwork(string subnet = null, int startIp = 1, int endIp = 254)
        {
            if (subnet == null) subnet = GetLocalSubnet();

            _cts = new CancellationTokenSource();
            var devices = new List<ScannedDevice>();
            var lockObj = new object();
            int total = endIp - startIp + 1;
            int current = 0;

            var options = new ParallelOptions
            {
                CancellationToken = _cts.Token,
                MaxDegreeOfParallelism = 50
            };

            try
            {
                Parallel.For(startIp, endIp + 1, options, i =>
                {
                    if (_cts.IsCancellationRequested) return;

                    string ip = $"{subnet}.{i}";
                    var device = PingDevice(ip);
                    if (device != null)
                    {
                        // Check if GameNet client is running on port 9090
                        if (CheckPort(ip, Protocol.DefaultPort))
                            device.IsGameNetClient = true;

                        lock (lockObj) devices.Add(device);
                        OnDeviceFound?.Invoke(device);
                    }

                    Interlocked.Increment(ref current);
                    OnScanProgress?.Invoke(current, total);
                });
            }
            catch (OperationCanceledException) { }

            OnScanComplete?.Invoke(devices);
            AuditLog.Log("NetworkScanner", $"Network scan completed: {devices.Count} devices found on {subnet}.0/{startIp}-{endIp}");
        }

        public void CancelScan() { _cts?.Cancel(); }

        private ScannedDevice PingDevice(string ip)
        {
            try
            {
                var ping = new Ping();
                var reply = ping.Send(IPAddress.Parse(ip), 1000);
                if (reply.Status == IPStatus.Success)
                {
                    string hostname = "";
                    try { hostname = Dns.GetHostEntry(IPAddress.Parse(ip))?.HostName ?? ""; } catch { }

                    return new ScannedDevice
                    {
                        IpAddress = ip,
                        Hostname = hostname,
                        MacAddress = GetMacFromIp(ip),
                        ResponseTime = reply.RoundtripTime,
                        IsOnline = true
                    };
                }
            }
            catch { }
            return null;
        }

        private bool CheckPort(string ip, int port)
        {
            try
            {
                using (var client = new TcpClient())
                {
                    var result = client.BeginConnect(ip, port, null, null);
                    var success = result.AsyncWaitHandle.WaitOne(500);
                    if (success)
                    {
                        client.EndConnect(result);
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }

        private string GetMacFromIp(string ip)
        {
            try
            {
                // Use ARP table
                var p = new System.Diagnostics.Process
                {
                    StartInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "arp",
                        Arguments = "-a",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        CreateNoWindow = true
                    }
                };
                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                p.WaitForExit();

                foreach (var line in output.Split('\n'))
                {
                    if (line.Contains(ip))
                    {
                        var match = System.Text.RegularExpressions.Regex.Match(line,
                            @"([0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2}[:-][0-9A-Fa-f]{2})");
                        if (match.Success) return match.Value;
                    }
                }
            }
            catch { }
            return "";
        }

        /// <summary>
        /// Quick scan - only check known client IPs from database.
        /// </summary>
        public List<ScannedDevice> QuickScan()
        {
            var devices = new List<ScannedDevice>();
            var stations = Database.Instance.Query(
                "SELECT DISTINCT ip_address FROM stations WHERE ip_address IS NOT NULL AND ip_address != ''",
                null, r => r.GetString(0));

            foreach (var ip in stations)
            {
                var device = PingDevice(ip);
                if (device != null)
                {
                    device.IsGameNetClient = CheckPort(ip, Protocol.DefaultPort);
                    devices.Add(device);
                }
            }

            return devices;
        }
    }

    public class ScannedDevice
    {
        public string IpAddress { get; set; }
        public string Hostname { get; set; }
        public string MacAddress { get; set; }
        public long ResponseTime { get; set; }
        public bool IsOnline { get; set; }
        public bool IsGameNetClient { get; set; }
    }
}
