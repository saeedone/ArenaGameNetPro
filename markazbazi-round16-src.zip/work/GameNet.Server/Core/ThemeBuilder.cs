using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class ThemeBuilder
    {
        private const string ThemeSettingsKey = "theme_settings";

        // NOTE: The class previously named `AppTheme` was renamed to
        // `AppThemePreset` so the new `ThemeManager.AppTheme` enum (Dark / Light)
        // could share the same short name without colliding. This class still
        // represents a full color *preset* (Background / Surface / Primary /
        // Text / Accent / Warning / Error) used by the ThemeForm dialog.
        public AppThemePreset GetCurrentTheme()
        {
            try
            {
                var json = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", ThemeSettingsKey), r => r.GetString(0));
                return JsonConvert.DeserializeObject<AppThemePreset>(json) ?? AppThemePreset.CatppuccinMocha();
            }
            catch { return AppThemePreset.CatppuccinMocha(); }
        }

        public void SaveTheme(AppThemePreset theme)
        {
            var json = JsonConvert.SerializeObject(theme);
            Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                cmd => { cmd.Parameters.AddWithValue("@k", ThemeSettingsKey); cmd.Parameters.AddWithValue("@v", json); });
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.Config, "ThemeUpdated", theme.Name);
        }

        public List<AppThemePreset> GetPresetThemes()
        {
            return new List<AppThemePreset>
            {
                AppThemePreset.CatppuccinMocha(),
                new AppThemePreset { Name = "Nord", Background = Color.FromArgb(46, 52, 64), Surface = Color.FromArgb(59, 66, 82), Primary = Color.FromArgb(136, 192, 208), Text = Color.FromArgb(216, 222, 233), Accent = Color.FromArgb(163, 190, 140), Warning = Color.FromArgb(235, 203, 139), Error = Color.FromArgb(191, 97, 106) },
                new AppThemePreset { Name = "Dracula", Background = Color.FromArgb(40, 42, 54), Surface = Color.FromArgb(68, 71, 90), Primary = Color.FromArgb(189, 147, 249), Text = Color.FromArgb(248, 248, 242), Accent = Color.FromArgb(80, 250, 123), Warning = Color.FromArgb(241, 250, 140), Error = Color.FromArgb(255, 85, 85) },
                new AppThemePreset { Name = "Solarized Dark", Background = Color.FromArgb(7, 54, 66), Surface = Color.FromArgb(0, 43, 54), Primary = Color.FromArgb(38, 139, 210), Text = Color.FromArgb(131, 148, 150), Accent = Color.FromArgb(133, 153, 0), Warning = Color.FromArgb(181, 137, 0), Error = Color.FromArgb(220, 50, 47) },
                new AppThemePreset { Name = "Gruvbox", Background = Color.FromArgb(40, 40, 40), Surface = Color.FromArgb(60, 56, 54), Primary = Color.FromArgb(254, 128, 25), Text = Color.FromArgb(235, 219, 178), Accent = Color.FromArgb(152, 151, 26), Warning = Color.FromArgb(250, 189, 47), Error = Color.FromArgb(204, 36, 29) },
                new AppThemePreset { Name = "Light Mode", Background = Color.FromArgb(255, 255, 255), Surface = Color.FromArgb(236, 239, 244), Primary = Color.FromArgb(35, 111, 161), Text = Color.FromArgb(46, 52, 64), Accent = Color.FromArgb(46, 125, 50), Warning = Color.FromArgb(230, 150, 0), Error = Color.FromArgb(198, 40, 40) }
            };
        }

        public void ApplyTheme(Form form, AppThemePreset theme)
        {
            form.BackColor = theme.Background;
            form.ForeColor = theme.Text;
            ApplyToControls(form.Controls, theme);
        }

        private void ApplyToControls(Control.ControlCollection controls, AppThemePreset theme)
        {
            foreach (Control c in controls)
            {
                if (c is Button btn) { btn.BackColor = theme.Primary; btn.ForeColor = theme.Background; }
                else if (c is GroupBox grp) { grp.BackColor = theme.Surface; grp.ForeColor = theme.Accent; }
                else if (c is TextBox txt) { txt.BackColor = theme.Surface; txt.ForeColor = theme.Text; }
                else if (c is Label) c.ForeColor = theme.Text;
                else if (c is DataGridView dgv) { dgv.BackgroundColor = theme.Surface; dgv.ForeColor = theme.Text; }
                if (c.HasChildren) ApplyToControls(c.Controls, theme);
            }
        }
    }

    /// <summary>
    /// A full color preset (Background / Surface / Primary / Text / Accent /
    /// Warning / Error) used by the ThemeForm dialog. Renamed from `AppTheme`
    /// so the new `ThemeManager.AppTheme` enum (Dark / Light) could share the
    /// short name. The full-preset theme system is independent of the
    /// light/dark toggle: this class is for visual customization, the
    /// `ThemeManager` is for instant light/dark switching.
    /// </summary>
    public class AppThemePreset
    {
        public string Name;
        public Color Background, Surface, Primary, Text, Accent, Warning, Error;
        public string FontFamily = "Segoe UI";
        public float BaseFontSize = 10F;
        public int CornerRadius = 6;
        public int Spacing = 8;

        public static AppThemePreset CatppuccinMocha() => new AppThemePreset
        {
            Name = "Catppuccin Mocha", Background = Color.FromArgb(30, 30, 46), Surface = Color.FromArgb(49, 50, 68),
            Primary = Color.FromArgb(137, 180, 250), Text = Color.FromArgb(205, 214, 244),
            Accent = Color.FromArgb(166, 227, 161), Warning = Color.FromArgb(249, 226, 175), Error = Color.FromArgb(243, 139, 168)
        };
    }
}
