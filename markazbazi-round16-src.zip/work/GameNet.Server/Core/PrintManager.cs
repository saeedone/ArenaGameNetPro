using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages print/scan job requests from client stations.
    /// Tracks costs, pages, and job status (pending/completed/cancelled).
    /// </summary>
    public class PrintManager
    {
        // Default pricing (Toman per page)
        private const decimal PricePerPageBW = 2000m;
        private const decimal PricePerPageColor = 5000m;
        private const decimal PricePerScan = 3000m;

        public PrintResultPayload CreatePrintJob(string username, string stationName, string documentName, int pages, string printType = "bw", string notes = "")
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("نام کاربری الزامی است");
            if (pages <= 0) throw new ArgumentException("تعداد صفحات باید بیشتر از صفر باشد");
            if (pages > 200) throw new ArgumentException("حداکثر ۲۰۰ صفحه در هر درخواست");

            string validType = printType;
            if (validType != "bw" && validType != "color" && validType != "scan")
                validType = "bw";

            // Calculate cost (decimal, no rounding loss).
            decimal cost = CalculateCost(pages, validType);

            // Verify the user exists.
            var user = new UserManager().FindByUsername(username);
            if (user == null) throw new InvalidOperationException("کاربر یافت نشد");

            // Apply member tier discount.
            decimal discount = new MemberTierManager().GetUserDiscount(username);
            decimal finalCost = Math.Round(cost * (1 - discount / 100), 0);

            int jobId = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // 1. Insert the print job FIRST. If the deduction then
                    //    fails (insufficient balance), we throw inside the
                    //    transaction so the insert is rolled back — no orphan
                    //    job rows. (Previous code deducted first, then
                    //    inserted: a crash between them left the user debited
                    //    with no job record.)
                    Database.Instance.Execute(
                        "INSERT INTO print_jobs (username, station_name, document_name, pages, print_type, cost, status, notes, created_at) VALUES (@u, @st, @doc, @pages, @type, @cost, 'pending', @notes, @ca)",
                        cmd =>
                        {
                            cmd.Parameters.AddWithValue("@u", username);
                            cmd.Parameters.AddWithValue("@st", stationName ?? "");
                            cmd.Parameters.AddWithValue("@doc", documentName ?? "");
                            cmd.Parameters.AddWithValue("@pages", pages);
                            cmd.Parameters.AddWithValue("@type", validType);
                            cmd.Parameters.AddWithValue("@cost", finalCost);
                            cmd.Parameters.AddWithValue("@notes", notes ?? "");
                            cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                        }, tx);

                    jobId = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0), tx);

                    // 2. Atomic conditional deduction of the cost.
                    int balRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance - @amt WHERE username = @u AND balance >= @amt",
                        cmd => { cmd.Parameters.AddWithValue("@amt", finalCost); cmd.Parameters.AddWithValue("@u", username); }, tx);

                    if (balRows == 0)
                        throw new InsufficientBalanceException(username, user.Balance, finalCost);
                });
            }
            catch (InsufficientBalanceException)
            {
                // Transaction has rolled back the job insert. Return a friendly
                // payload so the client UI can display the reason. (The
                // network caller wraps this in try/catch and forwards the
                // payload to the kiosk.)
                return new PrintResultPayload { Success = false, Message = $"اعتبار کافی نیست. هزینه: {finalCost:N0} تومان، موجودی: {user.Balance:N0} تومان" };
            }
            catch (Exception ex)
            {
                AuditLog.Log("PrintManager", $"CreatePrintJob failed for {username}: {ex.Message}");
                throw;
            }

            AuditLog.Log("PrintManager", $"Print job created: {username} - {pages} pages ({validType}) - {finalCost:N0} Toman (job #{jobId})");

            return new PrintResultPayload
            {
                Success = true,
                Message = $"درخواست پرینت ثبت شد. هزینه: {finalCost:N0} تومان",
                Cost = finalCost,
                JobId = jobId
            };
        }

        public void CompletePrintJob(int jobId)
        {
            Database.Instance.Execute(
                "UPDATE print_jobs SET status = 'completed', completed_at = @ca WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                    cmd.Parameters.AddWithValue("@id", jobId);
                });
            AuditLog.Log("PrintManager", $"Print job completed: ID {jobId}");
        }

        public void CancelPrintJob(int jobId)
        {
            // Refund the cost
            var job = GetPrintJob(jobId);
            if (job != null && job.Status == "pending")
            {
                new UserManager().AddCredit(job.Username, job.Cost);
                Database.Instance.Execute(
                    "UPDATE print_jobs SET status = 'cancelled', completed_at = @ca WHERE id = @id",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                        cmd.Parameters.AddWithValue("@id", jobId);
                    });
                AuditLog.Log("PrintManager", $"Print job cancelled and refunded: ID {jobId}");
            }
        }

        public class PrintJobInfo
        {
            public int Id;
            public string Username;
            public string StationName;
            public string DocumentName;
            public int Pages;
            public string PrintType;
            public decimal Cost;
            public string Status;
            public string Notes;
            public DateTime CreatedAt;
            public DateTime? CompletedAt;
        }

        public PrintJobInfo GetPrintJob(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, username, station_name, document_name, pages, print_type, cost, status, notes, created_at, completed_at FROM print_jobs WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new PrintJobInfo
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    StationName = r.IsDBNull(2) ? "" : r.GetString(2),
                    DocumentName = r.IsDBNull(3) ? "" : r.GetString(3),
                    Pages = r.GetInt32(4),
                    PrintType = r.GetString(5),
                    Cost = r.GetDecimal(6),
                    Status = r.GetString(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8),
                    CreatedAt = r.GetDateTime(9),
                    CompletedAt = r.IsDBNull(10) ? (DateTime?)null : r.GetDateTime(10)
                });
        }

        public List<PrintJobInfo> GetPendingJobs()
        {
            return Database.Instance.Query(
                "SELECT id, username, station_name, document_name, pages, print_type, cost, status, notes, created_at, completed_at FROM print_jobs WHERE status = 'pending' ORDER BY created_at",
                null,
                r => new PrintJobInfo
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    StationName = r.IsDBNull(2) ? "" : r.GetString(2),
                    DocumentName = r.IsDBNull(3) ? "" : r.GetString(3),
                    Pages = r.GetInt32(4),
                    PrintType = r.GetString(5),
                    Cost = r.GetDecimal(6),
                    Status = r.GetString(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8),
                    CreatedAt = r.GetDateTime(9),
                    CompletedAt = r.IsDBNull(10) ? (DateTime?)null : r.GetDateTime(10)
                });
        }

        public List<PrintJobInfo> GetUserPrintHistory(string username, int limit = 50)
        {
            return Database.Instance.Query(
                "SELECT id, username, station_name, document_name, pages, print_type, cost, status, notes, created_at, completed_at FROM print_jobs WHERE username = @u ORDER BY created_at DESC LIMIT @lim",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@lim", limit);
                },
                r => new PrintJobInfo
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    StationName = r.IsDBNull(2) ? "" : r.GetString(2),
                    DocumentName = r.IsDBNull(3) ? "" : r.GetString(3),
                    Pages = r.GetInt32(4),
                    PrintType = r.GetString(5),
                    Cost = r.GetDecimal(6),
                    Status = r.GetString(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8),
                    CreatedAt = r.GetDateTime(9),
                    CompletedAt = r.IsDBNull(10) ? (DateTime?)null : r.GetDateTime(10)
                });
        }

        public decimal CalculateCost(int pages, string printType)
        {
            switch (printType)
            {
                case "color": return pages * PricePerPageColor;
                case "scan": return pages * PricePerScan;
                default: return pages * PricePerPageBW;
            }
        }

        public (int TotalJobs, int PendingJobs, decimal TotalRevenue) GetPrintStats()
        {
            var stats = Database.Instance.QueryOne(
                "SELECT COUNT(*), SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), COALESCE(SUM(CASE WHEN status = 'completed' THEN cost ELSE 0 END), 0) FROM print_jobs",
                null,
                r => (r.GetInt32(0), r.IsDBNull(1) ? 0 : r.GetInt32(1), r.GetDecimal(2)));
            return stats;
        }
    }
}
