using System;
using System.Net;
using System.IO;
using System.Text;

namespace GameNet.Server.Core
{
    /// <summary>
    /// FIX-MONITOR-ADD5 TASK B5: minimal Telegram Bot notifier. Sends a
    /// message via the Telegram Bot API to a configured chat. The operator
    /// configures the bot token + chat id in OptionsForm (TelegramBotToken
    /// + TelegramChatId fields on OptionsData); MainForm calls Configure()
    /// on startup and NotifyXxx() in event handlers (topup / session-end /
    /// disconnect).
    ///
    /// All network calls are best-effort with a 5-second timeout — if
    /// Telegram is unreachable (kiosk in an isolated LAN, firewall blocks
    /// api.telegram.org, etc.) the notification is silently dropped and
    /// the server keeps running. Never throws.
    ///
    /// Security note: the bot token is stored in plain text in
    /// options.json next to the server exe. Treat the server exe's
    /// directory as trusted (only the operator + Administrators should
    /// have filesystem access). If the token is leaked, revoke it via
    /// @BotFather and generate a new one.
    /// </summary>
    public static class TelegramNotifier
    {
        private static string _botToken = "";
        private static string _chatId = "";

        /// <summary>True when both a bot token and a chat id have been
        /// configured (non-empty). Send() is a no-op when this is false
        /// so callers can call NotifyXxx() unconditionally without
        /// checking.</summary>
        public static bool IsConfigured => !string.IsNullOrEmpty(_botToken) && !string.IsNullOrEmpty(_chatId);

        /// <summary>Sets the bot token + chat id. Called from MainForm's
        /// constructor after OptionsForm.LoadStaticOptions() has read
        /// options.json. Pass null to clear (no-op sends).</summary>
        public static void Configure(string botToken, string chatId)
        {
            _botToken = botToken ?? "";
            _chatId = chatId ?? "";
        }

        /// <summary>
        /// Sends <paramref name="message"/> to the configured chat.
        /// Synchronous (blocks up to 5s on the network call). Call from
        /// a ThreadPool thread or a fire-and-forget Task to avoid
        /// blocking the UI thread.
        /// </summary>
        public static void Send(string message)
        {
            if (!IsConfigured) return;
            try
            {
                string url = $"https://api.telegram.org/bot{_botToken}/sendMessage";
                string payload = $"chat_id={_chatId}&text={Uri.EscapeDataString(message)}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.Timeout = 5000;
                var bytes = Encoding.UTF8.GetBytes(payload);
                request.ContentLength = bytes.Length;
                using (var stream = request.GetRequestStream()) stream.Write(bytes, 0, bytes.Length);
                using (var response = (HttpWebResponse)request.GetResponse()) { }
            }
            catch { /* best-effort — never throw on notification failure */ }
        }

        // ----- convenience helpers for the common GameNet events -----

        /// <summary>"💰 Topup request" notification — sent when a kiosk
        /// asks the operator for a credit topup.</summary>
        public static void NotifyTopup(string station, string user, decimal amount)
        { Send($"💰 درخواست شارژ\nکلاینت: {station}\nکاربر: {user}\nمبلغ: {amount:N0} تومان"); }

        /// <summary>"🏁 Session end" notification — sent when a kiosk's
        /// session terminates naturally (time cap reached or operator
        /// force-ended).</summary>
        public static void NotifySessionEnd(string station, string user, int min, decimal cost)
        { Send($"🏁 پایان نشست\nکلاینت: {station}\nکاربر: {user}\nزمان: {min} دقیقه\nهزینه: {cost:N0} تومان"); }

        /// <summary>"⚠️ Disconnect" notification — sent when a kiosk
        /// unexpectedly drops its TCP connection (heartbeat timeout,
        /// network failure, crash).</summary>
        public static void NotifyDisconnect(string station)
        { Send($"⚠️ قطع اتصال: {station}"); }
    }
}
