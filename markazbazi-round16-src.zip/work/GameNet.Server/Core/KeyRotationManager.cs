using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 3.1 — Key rotation system.
    ///
    /// Manages the lifecycle of the master encryption key and the TLS
    /// certificate:
    ///   • Tracks when each key was created (via the settings table).
    ///   • Notifies the operator when a key is approaching its rotation
    ///     deadline (default 90 days).
    ///   • Performs rotation: generates a new key, re-encrypts all sensitive
    ///     database fields that were encrypted with the old key, and marks
    ///     the old key as retired (kept for a grace period for decryption
    ///     of old backups).
    ///
    /// The rotation is wrapped in a transaction so a crash mid-rotation
    /// leaves the database consistent (either fully rotated or not at all).
    /// </summary>
    public static class KeyRotationManager
    {
        public const int RotationIntervalDays = 90;
        public const int WarningDays = 14; // warn 2 weeks before deadline

        private const string MasterKeyCreatedSetting = "master_key_created";
        private const string MasterKeyRotatedSetting = "master_key_rotated";
        private const string CertCreatedSetting = "cert_created";

        /// <summary>
        /// Returns the status of all managed keys: creation date, age in
        /// days, whether rotation is due, and whether a warning should be
        /// shown.
        /// </summary>
        public static KeyStatus GetKeyStatus()
        {
            var status = new KeyStatus();
            try
            {
                status.MasterKeyCreated = GetSetting(MasterKeyCreatedSetting);
                status.MasterKeyRotated = GetSetting(MasterKeyRotatedSetting);
                status.CertCreated = GetSetting(CertCreatedSetting);

                DateTime refDate;
                if (DateTime.TryParse(status.MasterKeyRotated, out refDate) ||
                    DateTime.TryParse(status.MasterKeyCreated, out refDate))
                {
                    status.MasterKeyAgeDays = (DateTime.UtcNow - refDate).TotalDays;
                    status.MasterKeyRotationDue = status.MasterKeyAgeDays >= RotationIntervalDays;
                    status.MasterKeyRotationWarning = status.MasterKeyAgeDays >= (RotationIntervalDays - WarningDays);
                }

                string certPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server.pfx");
                if (File.Exists(certPath))
                {
                    var cert = new System.Security.Cryptography.X509Certificates.X509Certificate2(certPath, "");
                    status.CertNotAfter = cert.NotAfter;
                    status.CertAgeDays = (DateTime.UtcNow - cert.NotBefore).TotalDays;
                    status.CertRotationDue = cert.NotAfter < DateTime.UtcNow.AddDays(30);
                    status.CertRotationWarning = cert.NotAfter < DateTime.UtcNow.AddDays(60);
                }
            }
            catch (Exception ex) { AuditLog.Log("KeyRotation", "GetKeyStatus error: " + ex.Message); }
            return status;
        }

        /// <summary>
        /// Rotates the master encryption key. Steps:
        ///   1. Read all encrypted fields from every table that uses them.
        ///   2. Decrypt with the old key.
        ///   3. Initialize a NEW master.key (backup the old one first).
        ///   4. Re-encrypt all fields with the new key in a transaction.
        ///   5. Update the rotated timestamp.
        /// Returns the number of fields re-encrypted.
        /// </summary>
        public static int RotateMasterKey()
        {
            AuditLog.Log("KeyRotation", "Master key rotation STARTED.");
            int reEncrypted = 0;

            try
            {
                // 1. Back up the old master.key
                string keyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "master.key");
                string backupPath = keyPath + ".bak." + DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                if (File.Exists(keyPath)) File.Copy(keyPath, backupPath);
                AuditLog.Log("KeyRotation", "Old master key backed up to " + backupPath);

                // 2. Collect all encrypted fields to re-encrypt.
                //    We scan known columns that may hold ENC1: values.
                var fields = new List<(string Table, string Column)>();
                foreach (var tbl in new[] { "users", "operators" })
                {
                    foreach (var col in new[] { "phone", "two_factor_secret", "password_hash" })
                    {
                        // Check if column exists
                        try
                        {
                            Database.Instance.QueryOne($"SELECT {col} FROM {tbl} LIMIT 0", null, r => 0);
                            fields.Add((tbl, col));
                        }
                        catch { /* column doesn't exist */ }
                    }
                }

                // 3. Read all values with the OLD key (before re-init)
                var updates = new List<(string Table, string Column, string IdColumn, int Id, string OldValue, string NewValue)>();
                foreach (var (tbl, col) in fields)
                {
                    try
                    {
                        var rows = Database.Instance.Query($"SELECT id, {col} FROM {tbl}", null,
                            r => (Id: r.GetInt32(0), Value: r.IsDBNull(1) ? null : r.GetString(1)));
                        foreach (var row in rows)
                        {
                            if (row.Value != null && DataEncryption.IsEncrypted(row.Value))
                            {
                                string plain;
                                try { plain = DataEncryption.Decrypt(row.Value); }
                                catch { continue; } // can't decrypt — skip (maybe already rotated)
                                updates.Add((tbl, col, "id", row.Id, row.Value, plain));
                            }
                        }
                    }
                    catch { }
                }

                // 4. Generate a new master key by deleting master.key so
                //    DataEncryption.Initialize creates a fresh one.
                if (File.Exists(keyPath)) File.Delete(keyPath);
                // Force re-initialization by clearing the static cache via reflection
                // (DataEncryption caches _masterKey/_hmacKey privately).
                var t = typeof(DataEncryption);
                var fldMaster = t.GetField("_masterKey", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                var fldHmac = t.GetField("_hmacKey", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                var fldInit = t.GetField("_initialized", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                if (fldMaster != null) fldMaster.SetValue(null, null);
                if (fldHmac != null) fldHmac.SetValue(null, null);
                if (fldInit != null) fldInit.SetValue(null, false);
                DataEncryption.Initialize();

                // 5. Re-encrypt all collected values in a transaction.
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    foreach (var u in updates)
                    {
                        string newVal = DataEncryption.Encrypt(u.NewValue);
                        Database.Instance.Execute(
                            $"UPDATE {u.Table} SET {u.Column} = @v WHERE {u.IdColumn} = @id",
                            cmd => { cmd.Parameters.AddWithValue("@v", newVal); cmd.Parameters.AddWithValue("@id", u.Id); },
                            tx);
                        reEncrypted++;
                    }
                    SetSetting(MasterKeyRotatedSetting, DateTime.UtcNow.ToString("o"));
                });

                AuditLog.Log("KeyRotation", $"Master key rotation COMPLETE. {reEncrypted} fields re-encrypted. Old key at {backupPath}");
            }
            catch (Exception ex)
            {
                AuditLog.Log("KeyRotation", "Master key rotation FAILED: " + ex.Message);
                throw;
            }
            return reEncrypted;
        }

        /// <summary>
        /// Rotates the TLS certificate: generates a new self-signed cert,
        /// replaces server.pfx, and exports a new server_cert.pem. The old
        /// cert is backed up. NOTE: kiosk clients that have pinned the old
        /// cert must be updated with the new server_cert.pem.
        /// </summary>
        public static void RotateTlsCertificate()
        {
            AuditLog.Log("KeyRotation", "TLS certificate rotation STARTED.");
            string certPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server.pfx");
            string backupPath = certPath + ".bak." + DateTime.UtcNow.ToString("yyyyMMddHHmmss");

            if (File.Exists(certPath)) File.Copy(certPath, backupPath);
            if (File.Exists(certPath)) File.Delete(certPath);
            // Also delete the old PEM so a fresh one is exported
            string pemPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "server_cert.pem");
            if (File.Exists(pemPath)) File.Delete(pemPath);

            var tls = new TlsWrapper(certPath, "");
            if (tls.IsEnabled)
            {
                SetSetting(CertCreatedSetting, DateTime.UtcNow.ToString("o"));
                AuditLog.Log("KeyRotation", $"TLS certificate rotation COMPLETE. Old cert at {backupPath}. UPDATE KIOSKS with new server_cert.pem!");
            }
            else
            {
                AuditLog.Log("KeyRotation", "TLS certificate rotation FAILED: new cert not enabled.");
            }
        }

        private static string GetSetting(string key)
        {
            try
            {
                return Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key),
                    r => r.GetString(0));
            }
            catch { return null; }
        }

        private static void SetSetting(string key, string value)
        {
            Database.Instance.Execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                cmd => { cmd.Parameters.AddWithValue("@k", key); cmd.Parameters.AddWithValue("@v", value); });
        }
    }

    public class KeyStatus
    {
        public string MasterKeyCreated;
        public string MasterKeyRotated;
        public double MasterKeyAgeDays;
        public bool MasterKeyRotationDue;
        public bool MasterKeyRotationWarning;

        public string CertCreated;
        public DateTime CertNotAfter;
        public double CertAgeDays;
        public bool CertRotationDue;
        public bool CertRotationWarning;
    }
}
