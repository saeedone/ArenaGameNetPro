using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 3.3 — Network-level access control.
    ///
    ///   • MAC address whitelist: only kiosks whose MAC is in the
    ///     `network_whitelist` table may connect. Unknown MACs are rejected
    ///     at ClientHello time (before any session state is created).
    ///   • IP range filter: optionally restrict connections to a CIDR range
    ///     (e.g. 192.168.1.0/24). Out-of-range IPs are dropped at accept.
    ///   • Both lists are managed by the operator via the SecurityForm tab.
    ///
    /// When the whitelist is empty, the filter is disabled (open mode) so
    /// first-run deployments aren't locked out.
    /// </summary>
    public static class NetworkAccessControl
    {
        /// <summary>
        /// Returns true if the given IP+MAC pair is allowed to connect.
        /// If no whitelist entries exist, returns true (open mode).
        /// </summary>
        public static (bool Allowed, string Reason) IsAllowed(string clientIp, string macAddress)
        {
            try
            {
                // 1. CIDR range check (if configured)
                string cidr = GetSetting("network_cidr");
                if (!string.IsNullOrEmpty(cidr) && !string.IsNullOrEmpty(clientIp))
                {
                    if (!IsIpInCidr(clientIp, cidr))
                        return (false, $"IP {clientIp} خارج از محدوده مجاز ({cidr}) است.");
                }

                // 2. MAC whitelist check (if any entries exist)
                var entries = GetWhitelist();
                if (entries.Count == 0) return (true, "Open mode (no whitelist configured)");

                if (string.IsNullOrEmpty(macAddress))
                {
                    // MAC unknown — allow only if there's an IP-only entry
                    if (entries.Any(e => !string.IsNullOrEmpty(e.Ip) && e.Ip == clientIp))
                        return (true, "Allowed by IP whitelist");
                    return (false, "MAC آدرس ارسال نشده و در whitelist IP نیست.");
                }

                string mac = NormalizeMac(macAddress);
                (int Id, string Mac, string Ip, bool IsActive, string Description, DateTime CreatedAt) match = default;
                bool found = false;
                foreach (var e in entries)
                {
                    if (string.Equals(NormalizeMac(e.Mac), mac, StringComparison.OrdinalIgnoreCase) &&
                        (string.IsNullOrEmpty(e.Ip) || e.Ip == clientIp))
                    {
                        match = e; found = true; break;
                    }
                }

                if (!found)
                    return (false, $"MAC {mac} در whitelist نیست.");

                if (!match.IsActive)
                    return (false, $"MAC {mac} در whitelist غیرفعال است.");

                return (true, "Allowed");
            }
            catch (Exception ex)
            {
                AuditLog.Log("NetACL", "IsAllowed error: " + ex.Message);
                return (true, "Error - allowing (fail-open)"); // fail-open to avoid locking everyone out on a bug
            }
        }

        /// <summary>Adds a MAC (and optional IP) to the whitelist.</summary>
        public static void AddWhitelistEntry(string mac, string ip = "", string description = "")
        {
            if (string.IsNullOrWhiteSpace(mac)) throw new ArgumentException("MAC الزامی است");
            Database.Instance.Execute(
                "INSERT INTO network_whitelist (allowed_mac, allowed_ip, is_active, description, created_at) VALUES (@m, @i, 1, @d, @c)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@m", NormalizeMac(mac));
                    cmd.Parameters.AddWithValue("@i", ip ?? "");
                    cmd.Parameters.AddWithValue("@d", description ?? "");
                    cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.ToString("o"));
                });
            AuditLog.Log("NetACL", $"Whitelist entry added: {mac} / {ip}");
        }

        /// <summary>Removes a whitelist entry by id.</summary>
        public static void RemoveWhitelistEntry(int id)
        {
            Database.Instance.Execute("DELETE FROM network_whitelist WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("NetACL", $"Whitelist entry #{id} removed");
        }

        /// <summary>Returns all whitelist entries.</summary>
        public static List<(int Id, string Mac, string Ip, bool IsActive, string Description, DateTime CreatedAt)> GetWhitelist()
        {
            return Database.Instance.Query(
                "SELECT id, allowed_mac, allowed_ip, is_active, description, created_at FROM network_whitelist ORDER BY created_at DESC",
                null,
                r => (
                    r.GetInt32(0),
                    r.IsDBNull(1) ? "" : r.GetString(1),
                    r.IsDBNull(2) ? "" : r.GetString(2),
                    r.GetBoolean(3),
                    r.IsDBNull(4) ? "" : r.GetString(4),
                    r.GetDateTime(5)
                ));
        }

        /// <summary>Sets the CIDR range filter (empty = disabled).</summary>
        public static void SetCidrFilter(string cidr)
        {
            if (!string.IsNullOrEmpty(cidr) && !IsValidCidr(cidr))
                throw new ArgumentException("CIDR نامعتبر (مثال صحیح: 192.168.1.0/24)");
            Database.Instance.Execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES ('network_cidr', @v)",
                cmd => cmd.Parameters.AddWithValue("@v", cidr ?? ""));
            AuditLog.Log("NetACL", "CIDR filter set to: " + (cidr ?? "(disabled)"));
        }

        public static string GetCidrFilter() => GetSetting("network_cidr") ?? "";

        // ---- Helpers ----

        private static string NormalizeMac(string mac)
        {
            if (string.IsNullOrEmpty(mac)) return "";
            return Regex.Replace(mac, @"[^0-9A-Fa-f]", "").ToUpperInvariant();
        }

        private static string GetSetting(string key)
        {
            try
            {
                return Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key),
                    r => r.GetString(0));
            }
            catch { return null; }
        }

        private static bool IsValidCidr(string cidr)
        {
            try
            {
                var parts = cidr.Split('/');
                if (parts.Length != 2) return false;
                if (!IPAddress.TryParse(parts[0], out _)) return false;
                if (!int.TryParse(parts[1], out int prefix) || prefix < 0 || prefix > 32) return false;
                return true;
            }
            catch { return false; }
        }

        private static bool IsIpInCidr(string ip, string cidr)
        {
            try
            {
                var parts = cidr.Split('/');
                var baseIp = IPAddress.Parse(parts[0]);
                int prefix = int.Parse(parts[1]);
                var testIp = IPAddress.Parse(ip);

                if (baseIp.AddressFamily != testIp.AddressFamily) return false;
                byte[] baseBytes = baseIp.GetAddressBytes();
                byte[] testBytes = testIp.GetAddressBytes();
                int fullBytes = prefix / 8;
                int remainderBits = prefix % 8;
                for (int i = 0; i < fullBytes; i++)
                    if (baseBytes[i] != testBytes[i]) return false;
                if (remainderBits > 0 && fullBytes < baseBytes.Length)
                {
                    int mask = 0xFF << (8 - remainderBits);
                    if ((baseBytes[fullBytes] & mask) != (testBytes[fullBytes] & mask)) return false;
                }
                return true;
            }
            catch { return false; }
        }
    }
}
