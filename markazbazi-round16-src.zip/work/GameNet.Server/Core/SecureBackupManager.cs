using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Phase 3.2 — Encrypted backup with optional offsite upload.
    ///
    /// Wraps the existing BackupManager.Backup() output in an AES-256
    /// envelope so the backup file is useless to anyone who steals it
    /// without the master key. Also supports uploading the encrypted
    /// backup to an offsite location (HTTP POST or network share) so a
    /// local disaster (fire, theft) doesn't lose the data.
    ///
    /// Encrypted backup format:
    ///   GNBAK1|<originalFilename>|<base64(IV || AES-cbc(backupBytes) || HMAC)>
    ///
    /// The encryption key is derived from the deployment's master.key so
    /// the same key that protects the database also protects its backups.
    /// </summary>
    public static class SecureBackupManager
    {
        /// <summary>
        /// Creates an encrypted backup of the database. Returns the path to
        /// the encrypted .gnbak file. Internally calls BackupManager.Backup
        /// to get the raw SQLite file, then wraps it in an AES envelope.
        /// </summary>
        public static string CreateEncryptedBackup(string description = "")
        {
            DataEncryption.Initialize();

            // 1. Create a raw backup using the existing BackupManager.
            var bm = new BackupManager();
            BackupManager.BackupInfo rawInfo;
            try { rawInfo = bm.CreateBackup(description); }
            catch (Exception ex) { throw new InvalidOperationException("Raw backup failed: " + ex.Message); }

            string rawPath = Path.Combine(bm.GetBackupDirectory(), rawInfo.Filename);
            if (!File.Exists(rawPath)) throw new FileNotFoundException("Raw backup file not found: " + rawPath);

            // 2. Read the raw backup and encrypt it.
            byte[] rawBytes = File.ReadAllBytes(rawPath);
            byte[] iv;
            byte[] cipher;
            byte[] mac;
            using (var aes = Aes.Create())
            {
                aes.Key = GetBackupKey();
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.GenerateIV();
                iv = aes.IV;
                using (var enc = aes.CreateEncryptor())
                    cipher = enc.TransformFinalBlock(rawBytes, 0, rawBytes.Length);
            }
            byte[] payload = new byte[iv.Length + cipher.Length];
            Buffer.BlockCopy(iv, 0, payload, 0, iv.Length);
            Buffer.BlockCopy(cipher, 0, payload, iv.Length, cipher.Length);
            using (var hmac = new HMACSHA256(GetBackupHmacKey()))
                mac = hmac.ComputeHash(payload);

            byte[] result = new byte[payload.Length + mac.Length];
            Buffer.BlockCopy(payload, 0, result, 0, payload.Length);
            Buffer.BlockCopy(mac, 0, result, payload.Length, mac.Length);

            string originalName = Path.GetFileName(rawPath);
            string encPath = Path.ChangeExtension(rawPath, ".gnbak");
            string header = "GNBAK1|" + originalName + "|" + description + "\n";
            byte[] headerBytes = Encoding.UTF8.GetBytes(header);

            using (var fs = File.Create(encPath))
            {
                fs.Write(headerBytes, 0, headerBytes.Length);
                fs.Write(result, 0, result.Length);
            }

            // 3. Delete the raw (unencrypted) backup.
            try { File.Delete(rawPath); } catch { }

            AuditLog.Log("SecureBackup", $"Encrypted backup created: {encPath} ({result.Length + headerBytes.Length} bytes)");
            return encPath;
        }

        /// <summary>
        /// Restores from an encrypted .gnbak file. Decrypts it, writes the
        /// raw SQLite file, then calls BackupManager.RestoreBackup.
        /// </summary>
        public static void RestoreEncryptedBackup(string gnBakPath)
        {
            DataEncryption.Initialize();
            if (!File.Exists(gnBakPath)) throw new FileNotFoundException(gnBakPath);

            string[] lines = File.ReadAllLines(gnBakPath);
            if (lines.Length == 0 || !lines[0].StartsWith("GNBAK1|"))
                throw new InvalidDataException("Not a GNBAK1 file.");

            string[] header = lines[0].Split('|');
            if (header.Length < 2) throw new InvalidDataException("Malformed GNBAK header.");
            string originalName = header[1];

            // Read the binary payload after the first line.
            byte[] allBytes = File.ReadAllBytes(gnBakPath);
            int newlineIdx = 0;
            for (int i = 0; i < allBytes.Length; i++)
            {
                if (allBytes[i] == '\n') { newlineIdx = i; break; }
            }
            byte[] encrypted = new byte[allBytes.Length - newlineIdx - 1];
            Buffer.BlockCopy(allBytes, newlineIdx + 1, encrypted, 0, encrypted.Length);

            if (encrypted.Length < 16 + 32) throw new InvalidDataException("Encrypted payload too short.");

            int macLen = 32;
            int payloadLen = encrypted.Length - macLen;
            byte[] payload = new byte[payloadLen];
            byte[] mac = new byte[macLen];
            Buffer.BlockCopy(encrypted, 0, payload, 0, payloadLen);
            Buffer.BlockCopy(encrypted, payloadLen, mac, 0, macLen);

            // Verify HMAC
            byte[] expectedMac;
            using (var hmac = new HMACSHA256(GetBackupHmacKey()))
                expectedMac = hmac.ComputeHash(payload);
            if (!ConstantTimeEquals(mac, expectedMac))
                throw new CryptographicException("Backup HMAC verification failed — file tampered or wrong key.");

            // Decrypt
            byte[] iv = new byte[16];
            byte[] cipher = new byte[payloadLen - 16];
            Buffer.BlockCopy(payload, 0, iv, 0, 16);
            Buffer.BlockCopy(payload, 16, cipher, 0, cipher.Length);

            byte[] raw;
            using (var aes = Aes.Create())
            {
                aes.Key = GetBackupKey();
                aes.IV = iv;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using (var dec = aes.CreateDecryptor())
                    raw = dec.TransformFinalBlock(cipher, 0, cipher.Length);
            }

            // Write the raw SQLite file and restore.
            string tempPath = Path.Combine(Path.GetDirectoryName(gnBakPath), "restore_" + originalName);
            File.WriteAllBytes(tempPath, raw);

            var bm = new BackupManager();
            bm.RestoreBackup(tempPath);
            AuditLog.Log("SecureBackup", "Encrypted backup restored from " + gnBakPath);
        }

        /// <summary>
        /// Uploads an encrypted backup to an offsite location via HTTP POST.
        /// The URL and optional auth header are read from settings so the
        /// operator can configure them without recompiling.
        /// </summary>
        public static bool UploadOffsite(string localPath)
        {
            try
            {
                string url = GetSetting("offsite_url");
                if (string.IsNullOrEmpty(url))
                {
                    AuditLog.Log("SecureBackup", "Offsite upload skipped: no offsite_url configured.");
                    return false;
                }
                string authHeader = GetSetting("offsite_auth") ?? "";

                byte[] data = File.ReadAllBytes(localPath);
                var request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.ContentType = "application/octet-stream";
                request.ContentLength = data.Length;
                if (!string.IsNullOrEmpty(authHeader))
                    request.Headers["Authorization"] = authHeader;
                request.Timeout = 60000; // 60s

                using (var rs = request.GetRequestStream())
                    rs.Write(data, 0, data.Length);

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    bool ok = (int)response.StatusCode >= 200 && (int)response.StatusCode < 300;
                    AuditLog.Log("SecureBackup", $"Offsite upload to {url}: HTTP {(int)response.StatusCode} ({(ok ? "OK" : "FAILED")})");
                    return ok;
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("SecureBackup", "Offsite upload error: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Creates an encrypted backup AND uploads it offsite (if configured).
        /// </summary>
        public static string CreateAndUploadOffsite(string description = "")
        {
            string path = CreateEncryptedBackup(description);
            UploadOffsite(path);
            return path;
        }

        private static byte[] GetBackupKey()
        {
            // Derive a backup-specific key from the master via SHA256(label || masterSecret).
            // We can't access DataEncryption's private _masterKey, so we re-read master.key.
            string keyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "master.key");
            byte[] secret = File.ReadAllBytes(keyPath);
            using (var sha = SHA256.Create())
            {
                byte[] label = Encoding.UTF8.GetBytes("backup-aes-key");
                byte[] buf = new byte[label.Length + secret.Length];
                Buffer.BlockCopy(label, 0, buf, 0, label.Length);
                Buffer.BlockCopy(secret, 0, buf, label.Length, secret.Length);
                return sha.ComputeHash(buf);
            }
        }

        private static byte[] GetBackupHmacKey()
        {
            string keyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "master.key");
            byte[] secret = File.ReadAllBytes(keyPath);
            using (var sha = SHA256.Create())
            {
                byte[] label = Encoding.UTF8.GetBytes("backup-hmac-key");
                byte[] buf = new byte[label.Length + secret.Length];
                Buffer.BlockCopy(label, 0, buf, 0, label.Length);
                Buffer.BlockCopy(secret, 0, buf, label.Length, secret.Length);
                return sha.ComputeHash(buf);
            }
        }

        private static string GetSetting(string key)
        {
            try
            {
                return Database.Instance.QueryOne<string>(
                    "SELECT value FROM settings WHERE key = @k",
                    cmd => cmd.Parameters.AddWithValue("@k", key),
                    r => r.GetString(0));
            }
            catch { return null; }
        }

        private static bool ConstantTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
