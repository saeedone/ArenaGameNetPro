using System;
using System.Collections.Generic;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// Manages session packages (e.g., "3 hours for 40,000 Toman", "All-night package").
    /// Users can purchase packages for discounted rates.
    /// </summary>
    public class SessionPackageManager
    {
        public SessionPackage CreatePackage(string name, string description, int durationMinutes, decimal price, string category = "", int maxUses = 0)
        {
            InputValidator.ValidateUsername(name); // Reuse for non-empty check
            if (durationMinutes <= 0) throw new ArgumentException("مدت زمان بسته باید بیشتر از صفر باشد");
            if (price < 0) throw new ArgumentException("قیمت بسته نمی‌تواند منفی باشد");

            Database.Instance.Execute(
                "INSERT INTO session_packages (name, description, duration_minutes, price, is_active, max_uses, category, created_at) VALUES (@name, @desc, @dur, @price, 1, @max, @cat, @ca)",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue("@dur", durationMinutes);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@max", maxUses);
                    cmd.Parameters.AddWithValue("@cat", category ?? "");
                    cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("o"));
                });

            int id = Database.Instance.QueryOne(Database.GetLastInsertIdQuery(), null, r => r.GetInt32(0));

            AuditLog.Log("SessionPackage", $"Package created: {name} ({durationMinutes} min, {price:N0} Toman)");

            return GetPackage(id);
        }

        public SessionPackage GetPackage(int id)
        {
            return Database.Instance.QueryOne(
                "SELECT id, name, description, duration_minutes, price, is_active, max_uses, current_uses, category FROM session_packages WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id),
                r => new SessionPackage
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? "" : r.GetString(2),
                    DurationMinutes = r.GetInt32(3),
                    Price = r.GetDecimal(4),
                    IsActive = r.GetBoolean(5),
                    MaxUses = r.GetInt32(6),
                    CurrentUses = r.GetInt32(7),
                    Category = r.IsDBNull(8) ? "" : r.GetString(8)
                });
        }

        public List<SessionPackage> GetActivePackages()
        {
            return Database.Instance.Query(
                "SELECT id, name, description, duration_minutes, price, is_active, max_uses, current_uses, category FROM session_packages WHERE is_active = 1 ORDER BY price",
                null,
                r => new SessionPackage
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? "" : r.GetString(2),
                    DurationMinutes = r.GetInt32(3),
                    Price = r.GetDecimal(4),
                    IsActive = r.GetBoolean(5),
                    MaxUses = r.GetInt32(6),
                    CurrentUses = r.GetInt32(7),
                    Category = r.IsDBNull(8) ? "" : r.GetString(8)
                });
        }

        public List<SessionPackage> GetAllPackages()
        {
            return Database.Instance.Query(
                "SELECT id, name, description, duration_minutes, price, is_active, max_uses, current_uses, category FROM session_packages ORDER BY is_active DESC, price",
                null,
                r => new SessionPackage
                {
                    Id = r.GetInt32(0),
                    Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? "" : r.GetString(2),
                    DurationMinutes = r.GetInt32(3),
                    Price = r.GetDecimal(4),
                    IsActive = r.GetBoolean(5),
                    MaxUses = r.GetInt32(6),
                    CurrentUses = r.GetInt32(7),
                    Category = r.IsDBNull(8) ? "" : r.GetString(8)
                });
        }

        /// <summary>
        /// Purchase a session package for a user atomically in a single
        /// transaction. Steps performed inside the transaction:
        ///   1. Re-read the package (current_uses, max_uses, is_active) — the
        ///      lock held by ExecuteInTransaction guarantees no other thread
        ///      can interleave a purchase between this read and the writes.
        ///   2. Atomic conditional UPDATE on session_packages: only increments
        ///      current_uses if max_uses is not exhausted. This is the
        ///      over-sale guard — if 0 rows are affected, rollback.
        ///   3. Atomic conditional deduction of the user's balance
        ///      (balance &gt;= finalPrice). If 0 rows, rollback and report
        ///      insufficient balance.
        ///   4. Grant the equivalent time-credit (default plan price/hour *
        ///      DurationMinutes / 60) to the user's balance.
        /// All steps commit or rollback together so a package sale can never
        /// leave the user debited without the time credit, or the package
        /// count incremented without payment.
        /// </summary>
        public PackageResultPayload PurchasePackage(int packageId, string username)
        {
            if (string.IsNullOrWhiteSpace(username))
                return new PackageResultPayload { Success = false, Message = "نام کاربری الزامی است" };

            // Pre-flight read of the package (for the friendly error messages).
            var package = GetPackage(packageId);
            if (package == null) return new PackageResultPayload { Success = false, Message = "بسته یافت نشد" };
            if (!package.IsActive) return new PackageResultPayload { Success = false, Message = "این بسته غیرفعال است" };

            // Pre-flight user lookup.
            var user = new UserManager().FindByUsername(username);
            if (user == null) return new PackageResultPayload { Success = false, Message = "کاربر یافت نشد" };

            // Apply member tier discount.
            decimal discount = GetMemberDiscount(username);
            decimal finalPrice = Math.Round(package.Price * (1 - discount / 100), 0);

            if (user.Balance < finalPrice)
                return new PackageResultPayload { Success = false, Message = $"اعتبار کافی نیست. موجودی: {user.Balance:N0} تومان، قیمت با تخفیف: {finalPrice:N0} تومان" };

            // Pre-compute the equivalent time-credit value (outside the txn
            // since this hits another manager; the result is deterministic
            // for the duration of the purchase).
            decimal packageCreditValue;
            try
            {
                var defaultPlan = new PricingManager().GetDefaultPlan();
                decimal creditPerMinute = (defaultPlan?.PricePerHour ?? 0m) / 60m;
                packageCreditValue = Math.Round(creditPerMinute * package.DurationMinutes, 0);
            }
            catch (Exception ex)
            {
                AuditLog.Log("SessionPackage", $"PurchasePackage: failed to read default pricing for package {packageId}: {ex.Message}");
                return new PackageResultPayload { Success = false, Message = "خطا در محاسبه هزینه بسته" };
            }

            int pkgRows = 0;
            int balRows = 0;
            try
            {
                Database.Instance.ExecuteInTransaction(tx =>
                {
                    // 1. Atomic conditional increment of current_uses.
                    //    max_uses = 0 means unlimited; otherwise we require
                    //    current_uses < max_uses. The is_active = 1 guard
                    //    prevents purchases of a package that was deactivated
                    //    between our pre-flight read and this transaction.
                    pkgRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE session_packages SET current_uses = current_uses + 1 WHERE id = @id AND is_active = 1 AND (max_uses = 0 OR current_uses < max_uses)",
                        cmd => cmd.Parameters.AddWithValue("@id", packageId), tx);

                    if (pkgRows == 0)
                        throw new InvalidOperationException("ظرفیت این بسته تمام شده است یا بسته غیرفعال شده است");

                    // 2. Atomic conditional deduction of the user's balance.
                    balRows = Database.Instance.ExecuteNonQuery(
                        "UPDATE users SET balance = balance - @amt WHERE username = @u AND balance >= @amt",
                        cmd => { cmd.Parameters.AddWithValue("@amt", finalPrice); cmd.Parameters.AddWithValue("@u", username); }, tx);

                    if (balRows == 0)
                        throw new InsufficientBalanceException(username, user.Balance, finalPrice);

                    // 3. Grant the equivalent time-credit to the user's balance.
                    if (packageCreditValue > 0)
                    {
                        Database.Instance.ExecuteNonQuery(
                            "UPDATE users SET balance = balance + @c WHERE username = @u",
                            cmd => { cmd.Parameters.AddWithValue("@c", packageCreditValue); cmd.Parameters.AddWithValue("@u", username); }, tx);
                    }
                });
            }
            catch (InsufficientBalanceException)
            {
                return new PackageResultPayload { Success = false, Message = $"اعتبار کافی نیست. موجودی: {user.Balance:N0} تومان، قیمت با تخفیف: {finalPrice:N0} تومان" };
            }
            catch (InvalidOperationException ex)
            {
                return new PackageResultPayload { Success = false, Message = ex.Message };
            }
            catch (Exception ex)
            {
                AuditLog.Log("SessionPackage", $"PurchasePackage failed for user={username}, pkg={packageId}: {ex.Message}");
                return new PackageResultPayload { Success = false, Message = "خطا در خرید بسته" };
            }

            AuditLog.Log("SessionPackage", $"User {username} purchased package '{package.Name}' for {finalPrice:N0} Toman ({package.DurationMinutes} min, +{packageCreditValue:N0} credit)");
            // Award tier points for the spending.
            try { new MemberTierManager().AddPointsForSpending(username, finalPrice); }
            catch (Exception ex) { AuditLog.Log("SessionPackage", $"Tier points update failed for {username}: {ex.Message}"); }

            return new PackageResultPayload
            {
                Success = true,
                Message = $"بسته «{package.Name}» با موفقیت خریداری شد. {package.DurationMinutes} دقیقه زمان اضافه شد.",
                DurationMinutes = package.DurationMinutes,
                PricePaid = finalPrice
            };
        }

        public void UpdatePackage(int id, string name, string description, int durationMinutes, decimal price, bool isActive, string category)
        {
            Database.Instance.Execute(
                "UPDATE session_packages SET name = @name, description = @desc, duration_minutes = @dur, price = @price, is_active = @active, category = @cat WHERE id = @id",
                cmd =>
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue("@dur", durationMinutes);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                    cmd.Parameters.AddWithValue("@cat", category ?? "");
                    cmd.Parameters.AddWithValue("@id", id);
                });
            AuditLog.Log("SessionPackage", $"Package updated: {name}");
        }

        public void DeletePackage(int id)
        {
            Database.Instance.Execute("DELETE FROM session_packages WHERE id = @id",
                cmd => cmd.Parameters.AddWithValue("@id", id));
            AuditLog.Log("SessionPackage", $"Package deleted: ID {id}");
        }

        private decimal GetMemberDiscount(string username)
        {
            try
            {
                var tierMgr = new MemberTierManager();
                var tierInfo = tierMgr.GetUserTierInfo(username);
                return tierInfo?.CurrentTier?.DiscountPercent ?? 0;
            }
            catch { return 0; }
        }
    }
}
