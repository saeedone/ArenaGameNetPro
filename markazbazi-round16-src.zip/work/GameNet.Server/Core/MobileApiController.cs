using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    public class MobileApiController : IDisposable
    {
        private HttpListener _listener;
        private Thread _listenerThread;
        private volatile bool _running;
        private readonly int _port;
        private string _apiKey;
        private string _adminApiKey; // elevated-permission key for credit/station mutations
        private readonly ClientCommunicator _communicator;
        private readonly RateLimiter _rateLimiter;

        public event Action<string, string> OnApiRequest;

        [ThreadStatic] private static bool _currentIsAdmin;

        /// <summary>When true, the controller also listens on https://+. Requires a valid SSL cert.</summary>
        public bool UseHttps { get; set; } = false;
        public string SslCertPath { get; set; } = "";

        public MobileApiController(ClientCommunicator communicator, int port = 8080, string apiKey = "")
        {
            _communicator = communicator;
            _port = port;
            // Persist API keys to file so they survive restarts
            // FIX SEC-3: moved to shared ApiKeyStore so WebSocketServer can
            // reuse the same readonly_key for its own auth.
            var keys = ApiKeyStore.LoadOrGenerateKeys();
            _apiKey = !string.IsNullOrEmpty(apiKey) ? apiKey : keys.ReadonlyKey;
            _adminApiKey = keys.AdminKey;
            _rateLimiter = new RateLimiter(60, 1000, 5);
        }

        public string GetApiKey() => _apiKey;
        public string GetAdminApiKey() => _adminApiKey;

        /// <summary>Constant-time string comparison to prevent timing oracles on API keys.</summary>
        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        public void Start()
        {
            if (_running) return;
            _running = true;
            _listener = new HttpListener();
            bool httpsOk = false;
            if (UseHttps && !string.IsNullOrEmpty(SslCertPath))
            {
                try { _listener.Prefixes.Add($"https://+:{_port}/api/"); _listener.Start(); httpsOk = true; }
                catch (Exception ex)
                {
                    AuditLog.Log("API", "HTTPS listener failed (" + ex.Message + "); falling back to HTTP. API keys will travel in cleartext!");
                    _listener.Prefixes.Clear();
                }
            }
            if (!httpsOk)
            {
                _listener.Prefixes.Add($"http://+:{_port}/api/");
                try { _listener.Start(); }
                catch (HttpListenerException) { _listener.Prefixes.Clear(); _listener.Prefixes.Add($"http://localhost:{_port}/api/"); _listener.Start(); AuditLog.Log("API", "Fell back to localhost — mobile remote access will NOT work. Configure urlacl or run as admin."); }
            }
            _listenerThread = new Thread(HandleRequests) { IsBackground = true };
            _listenerThread.Start();
            EnhancedAuditLog.Log(EnhancedAuditLog.AuditCategory.API, "ApiStarted", $"Port: {_port}, HTTPS={(httpsOk ? "on" : "off")}");
        }

        public void Stop()
        {
            _running = false;
            _listener?.Stop();
            _listenerThread?.Join(3000);
        }

        private void HandleRequests()
        {
            while (_running)
            {
                try
                {
                    var ctx = _listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => ProcessRequest(ctx));
                }
                catch { break; }
            }
        }

        private void ProcessRequest(HttpListenerContext ctx)
        {
            try
            {
                string clientIp = ctx.Request.RemoteEndPoint?.Address?.ToString() ?? "";
                var limitResult = _rateLimiter.CheckLimit(clientIp);
                try { IntrusionDetectionSystem.RecordApiCall(clientIp); } catch { }
                if (!limitResult.Allowed)
                {
                    SendJson(ctx, 429, new { error = "Too Many Requests", retry_after = limitResult.RetryAfterSeconds });
                    return;
                }

                string authHeader = ctx.Request.Headers["Authorization"] ?? "";
                string providedKey = authHeader.StartsWith("Bearer ") ? authHeader.Substring(7) : "";
                bool isReadonly = ConstantTimeEquals(providedKey, _apiKey);
                bool isAdmin = !isReadonly && ConstantTimeEquals(providedKey, _adminApiKey);
                if (!isReadonly && !isAdmin)
                {
                    SendJson(ctx, 401, new { error = "Unauthorized. Valid API key required." });
                    return;
                }
                _currentIsAdmin = isAdmin; // thread-static style; safe because ProcessRequest is one-per-request on ThreadPool

                string path = ctx.Request.Url.AbsolutePath.ToLowerInvariant();
                string method = ctx.Request.HttpMethod;

                OnApiRequest?.Invoke(method, path);

                if (path.StartsWith("/api/dashboard") && method == "GET")
                    HandleDashboard(ctx);
                else if (path.StartsWith("/api/stations") && method == "GET")
                    HandleStations(ctx);
                else if (path.StartsWith("/api/users") && method == "GET")
                    HandleUsers(ctx);
                else if (path.StartsWith("/api/sessions/") && method == "POST")
                    HandleSessionAction(ctx, path);
                else if (path.StartsWith("/api/credit") && method == "POST")
                    HandleAddCredit(ctx);
                else if (path.StartsWith("/api/reports") && method == "GET")
                    HandleReports(ctx);
                else
                    SendJson(ctx, 404, new { error = "Not found" });
            }
            catch (Exception ex)
            {
                // Never leak internal exception details to API clients
                AuditLog.Log("API", "Error processing request: " + ex.Message);
                try { SendJson(ctx, 500, new { error = "Internal server error" }); } catch { }
            }
        }

        private void HandleDashboard(HttpListenerContext ctx)
        {
            var connected = new List<object>();
            foreach (var c in _communicator.ConnectedClients)
                connected.Add(new { c.StationName, c.CurrentUser, State = c.State.ToString(), c.SessionMinutesElapsed, c.SessionCost });

            SendJson(ctx, 200, new
            {
                online_clients = _communicator.ConnectedClientCount,
                traffic_level = new SmartPricing().GetCurrentTrafficLevel(),
                connected = connected,
                server_time = DateTime.UtcNow
            });
        }

        private void HandleStations(HttpListenerContext ctx)
        {
            var stations = new StationManager().GetAllStations();
            var result = stations.Select(s => new { s.Id, s.Name, s.IpAddress, s.Status, s.Category });
            SendJson(ctx, 200, result);
        }

        private void HandleUsers(HttpListenerContext ctx)
        {
            string search = ctx.Request.QueryString["q"] ?? "";
            var users = Database.Instance.Query("SELECT username, display_name, balance, is_active FROM users WHERE username LIKE @q OR display_name LIKE @q LIMIT 50",
                cmd => cmd.Parameters.AddWithValue("@q", $"%{search}%"),
                r => new { Username = r.GetString(0), DisplayName = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1), Balance = r.GetDecimal(2), Active = r.GetBoolean(3) });
            SendJson(ctx, 200, users);
        }

        private void HandleSessionAction(HttpListenerContext ctx, string path)
        {
            // Station mutations require admin-level API key
            if (!_currentIsAdmin)
            {
                SendJson(ctx, 403, new { error = "Forbidden. Admin API key required for station actions." });
                return;
            }
            string action = path.Split('/').LastOrDefault() ?? "";
            string body = ReadBody(ctx.Request);
            var data = JsonConvert.DeserializeObject<Dictionary<string, string>>(body);
            string station = data != null && data.TryGetValue("station", out var st) ? st : "";

            if (string.IsNullOrEmpty(station)) { SendJson(ctx, 400, new { error = "Station name required" }); return; }

            switch (action)
            {
                case "lock": SendJson(ctx, 200, new { status = "lock_removed" }); break;
                case "unlock": _communicator.UnlockStation(station); SendJson(ctx, 200, new { status = "unlocked" }); break;
                case "shutdown": _communicator.ShutdownStation(station); SendJson(ctx, 200, new { status = "shutdown_sent" }); break;
                case "restart": _communicator.RestartStation(station); SendJson(ctx, 200, new { status = "restart_sent" }); break;
                case "logout": _communicator.ForceLogoutStation(station); SendJson(ctx, 200, new { status = "force_logout_sent" }); break;
                default: SendJson(ctx, 400, new { error = $"Unknown action: {action}" }); break;
            }
        }

        private void HandleAddCredit(HttpListenerContext ctx)
        {
            // Credit changes require admin-level API key
            if (!_currentIsAdmin)
            {
                SendJson(ctx, 403, new { error = "Forbidden. Admin API key required to add credit." });
                return;
            }
            string body = ReadBody(ctx.Request);
            var data = JsonConvert.DeserializeObject<Dictionary<string, string>>(body);
            if (data == null || !data.TryGetValue("username", out var user) || !data.TryGetValue("amount", out var amountStr))
            { SendJson(ctx, 400, new { error = "username and amount required" }); return; }

            if (!decimal.TryParse(amountStr, out decimal amount) || amount <= 0)
            { SendJson(ctx, 400, new { error = "Invalid amount" }); return; }

            new UserManager().AddCredit(user, amount);
            SendJson(ctx, 200, new { status = "ok", username = user, amount = amount });
        }

        private void HandleReports(HttpListenerContext ctx)
        {
            string type = ctx.Request.QueryString["type"] ?? "revenue";
            int days = int.TryParse(ctx.Request.QueryString["days"], out int d) ? d : 30;
            var report = new ReportEngine().GetRevenueReport(DateTime.UtcNow.AddDays(-days), DateTime.UtcNow);
            SendJson(ctx, 200, report);
        }

        private void SendJson(HttpListenerContext ctx, int statusCode, object data)
        {
            ctx.Response.StatusCode = statusCode;
            ctx.Response.ContentType = "application/json; charset=utf-8";
            ctx.Response.AddHeader("Access-Control-Allow-Origin", "*");
            byte[] buf = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data));
            ctx.Response.ContentLength64 = buf.Length;
            ctx.Response.OutputStream.Write(buf, 0, buf.Length);
            ctx.Response.OutputStream.Close();
        }

        private string ReadBody(HttpListenerRequest req)
        {
            using (var reader = new StreamReader(req.InputStream, Encoding.UTF8)) return reader.ReadToEnd();
        }

        public void Dispose() { Stop(); }
    }
}
