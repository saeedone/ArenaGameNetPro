using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using GameNet.Shared;

namespace GameNet.Server.Core
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 2: Lightweight REST API server.
    ///
    /// Exposes GameNet data and operations to external apps (mobile clients,
    /// web dashboards, integration scripts) over HTTP+JSON. Runs on a
    /// background thread via <see cref="HttpListener"/> (built-in — no extra
    /// NuGet needed) and is fully independent of the existing
    /// <see cref="MobileApiController"/> (which is retained for backward
    /// compat with the existing API tab UI).
    ///
    /// Endpoints (all under the configured prefix, default http://+:8080/):
    ///   GET  /api/clients                  → JSON list of all connected clients
    ///   GET  /api/clients/{station}        → JSON details for one client
    ///   POST /api/clients/{station}/time   → add time (body: {"minutes": 30})
    ///   POST /api/clients/{station}/lock   → lock the client
    ///   POST /api/clients/{station}/unlock → unlock the client
    ///   POST /api/clients/{station}/shutdown → shutdown the client
    ///   POST /api/clients/{station}/restart  → restart the client
    ///   GET  /api/users                    → JSON list of all users
    ///   POST /api/users/{username}/credit  → add credit (body: {"amount": 5000})
    ///   GET  /api/reports/daily            → today's sessions + income
    ///   GET  /api/reports/income           → income summary (today, week, month)
    ///   GET  /api/status                   → server status (uptime, clients, income)
    ///   POST /api/auth/login               → operator login → returns token
    ///
    /// Auth: every endpoint EXCEPT /api/auth/login requires either an
    /// `Authorization: Bearer &lt;token&gt;` header or a `?token=&lt;token&gt;`
    /// query parameter. Login returns a random 32-byte base64url token;
    /// tokens live for the lifetime of the server process (no expiry — a
    /// simple LAN-only model). All requests are logged to the audit log.
    /// </summary>
    public static class RestApiServer
    {
        private static HttpListener _listener;
        private static Thread _thread;
        private static volatile bool _running;
        private static int _port;

        /// <summary>
        /// SECURITY FIX: tokens used to map only to an issue timestamp, so
        /// the only check performed on every request was "is this token
        /// known and not expired?" — the operator's actual
        /// <see cref="OperatorPermission"/> flags (ViewClients, AddCredit,
        /// ShutdownClients, ManageUsers, ViewReports, ApiAccess, ...) were
        /// never consulted anywhere in this file, even though every one of
        /// those permissions already exists and is enforced in the desktop
        /// UI. In practice that meant ANY operator who could log in at all
        /// — including a front-desk role with no AddCredit or
        /// ShutdownClients permission — could use the REST API to add
        /// unlimited credit to any customer account or remotely lock/
        /// shutdown/restart any station, completely bypassing the
        /// permission system. Tokens now carry the issuing operator's
        /// permissions so each endpoint can require the same permission the
        /// desktop app requires for the equivalent action.
        /// </summary>
        private sealed class TokenInfo
        {
            public DateTime IssuedAt;
            public string Username;
            public OperatorPermission Permissions;
        }

        private static readonly ConcurrentDictionary<string, TokenInfo> _tokens = new ConcurrentDictionary<string, TokenInfo>();
        // process-wide start time for /api/status uptime
        private static readonly DateTime _startedAt = DateTime.UtcNow;

        /// <summary>True if the API server is currently listening.</summary>
        public static bool IsRunning => _running;

        /// <summary>Number of currently-issued auth tokens.</summary>
        public static int ActiveTokenCount => _tokens.Count;

        public static void Start(int port)
        {
            if (_running) return;
            if (port <= 0 || port > 65535) throw new ArgumentOutOfRangeException(nameof(port));
            _port = port;
            _listener = new HttpListener();
            try { _listener.Prefixes.Add($"http://+:{port}/"); }
            catch (HttpListenerException)
            {
                // "+:" prefix requires admin / urlacl reservation. Fall back
                // to localhost-only so the server still starts for local
                // development — remote clients will not be able to connect
                // until the operator runs `netsh http add urlacl ...`.
                _listener.Prefixes.Clear();
                _listener.Prefixes.Add($"http://localhost:{port}/");
                AuditLog.Log("RestApi", $"Started in localhost-only mode (port {port}). Remote access requires urlacl reservation.");
            }
            try { _listener.Start(); }
            catch (Exception ex)
            {
                AuditLog.Log("RestApi", "Failed to start HttpListener: " + ex.Message);
                throw;
            }
            _running = true;
            _thread = new Thread(HandleLoop) { IsBackground = true, Name = "RestApiServer" };
            _thread.Start();
            AuditLog.Log("RestApi", $"REST API server started on port {port}");
        }

        public static void Stop()
        {
            if (!_running) return;
            _running = false;
            try { _listener?.Stop(); } catch { }
            try { _thread?.Join(2000); } catch { }
            _tokens.Clear();
            AuditLog.Log("RestApi", "REST API server stopped");
        }

        private static void HandleLoop()
        {
            while (_running)
            {
                try
                {
                    var ctx = _listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => SafeProcess(ctx));
                }
                catch
                {
                    // FIX B7: on transient errors (e.g. HttpListener raised
                    // an exception but we're still flagged as running),
                    // sleep briefly before retrying. Without this delay the
                    // catch block spins at 100% CPU until the listener is
                    // stopped — burning a core and saturating the log with
                    // repeated error entries.
                    if (!_running) break;
                    try { System.Threading.Thread.Sleep(1000); } catch { }
                }
            }
        }

        private static void SafeProcess(HttpListenerContext ctx)
        {
            try { Process(ctx); }
            catch (Exception ex)
            {
                AuditLog.Log("RestApi", "Unhandled error in SafeProcess: " + ex.Message);
                try { SendJson(ctx, 500, new { error = "Internal server error" }); } catch { }
            }
            finally { try { ctx.Response.Close(); } catch { } }
        }

        private static void Process(HttpListenerContext ctx)
        {
            var req = ctx.Request;
            var resp = ctx.Response;
            string method = req.HttpMethod;
            string path = (req.Url?.AbsolutePath ?? "").TrimEnd('/');
            string clientIp = req.RemoteEndPoint?.Address?.ToString() ?? "";
            try { IntrusionDetectionSystem.RecordApiCall(clientIp); } catch { }

            AuditLog.Log("RestApi", $"{method} {path} from {clientIp}");

            // CORS header so web dashboards on a different origin can call us
            resp.AddHeader("Access-Control-Allow-Origin", "*");
            resp.AddHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
            resp.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
            if (method == "OPTIONS") { resp.StatusCode = 204; return; }

            // ---- /api/auth/login is the only unauthenticated JSON endpoint ----
            if (path.Equals("/api/auth/login", StringComparison.OrdinalIgnoreCase) && method == "POST")
            {
                HandleLogin(ctx);
                return;
            }

            // FIX SEC-2/FUNC-1: ZarinPal calls this URL directly in the
            // customer's browser after payment — it can't send our Bearer
            // token, so (like login) it must be unauthenticated. This route
            // previously did not exist anywhere in the codebase at all:
            // PaymentGateway.VerifyPayment was fully implemented (idempotent,
            // signature-checked, transactional) but had ZERO callers outside
            // its own file — nothing ever invoked it, so a customer could pay
            // real money via ZarinPal and their balance would never be
            // credited. The old default callback URL
            // (http://localhost:9090/payment/callback) pointed at the raw
            // TCP kiosk-protocol port, which doesn't speak HTTP at all, so
            // even a correctly-configured ZarinPal merchant could never have
            // reached a listener. See PaymentForm.cs / ClientCommunicator.
            // HandlePaymentRequest for the corresponding callback-URL fix.
            if (path.Equals("/payment/callback", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                HandlePaymentCallback(ctx);
                return;
            }

            // ---- all other endpoints require a token ----
            string token = ExtractToken(ctx);
            // FIX B18: ValidateToken enforces a 24-hour expiry check so a
            // stolen/leaked token has a bounded lifetime. Previously tokens
            // were stored with a timestamp but the timestamp was never
            // consulted — a token issued today was valid forever.
            if (string.IsNullOrEmpty(token) || !ValidateToken(token, out TokenInfo tokenInfo))
            {
                SendJson(ctx, 401, new { error = "Unauthorized. POST /api/auth/login first." });
                return;
            }

            // ---- route table ----
            // SECURITY FIX: each route now requires the same OperatorPermission
            // flag the equivalent desktop-app feature requires (see the
            // TokenInfo comment above for why this was missing entirely).
            if (path.Equals("/api/clients", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.ViewClients)) return;
                HandleListClients(ctx);
            }
            else if (path.StartsWith("/api/clients/", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.ViewClients)) return;
                HandleGetClient(ctx, path);
            }
            else if (path.StartsWith("/api/clients/", StringComparison.OrdinalIgnoreCase) && method == "POST")
            {
                // HandleClientAction covers time/lock/unlock (session control)
                // as well as shutdown/restart (more disruptive) — it checks
                // the finer-grained permission itself once it knows the action.
                HandleClientAction(ctx, path, tokenInfo);
            }
            else if (path.Equals("/api/users", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.ManageUsers)) return;
                HandleListUsers(ctx);
            }
            else if (path.StartsWith("/api/users/", StringComparison.OrdinalIgnoreCase) && method == "POST")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.AddCredit)) return;
                HandleAddUserCredit(ctx, path, tokenInfo);
            }
            else if (path.Equals("/api/reports/daily", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.ViewReports)) return;
                HandleReportDaily(ctx);
            }
            else if (path.Equals("/api/reports/income", StringComparison.OrdinalIgnoreCase) && method == "GET")
            {
                if (!RequirePermission(ctx, tokenInfo, OperatorPermission.ViewReports)) return;
                HandleReportIncome(ctx);
            }
            else if (path.Equals("/api/status", StringComparison.OrdinalIgnoreCase) && method == "GET")
                HandleStatus(ctx); // no extra permission beyond ApiAccess (already required at login)
            else
                SendJson(ctx, 404, new { error = "Not found", path = path, method = method });
        }

        /// <summary>
        /// Returns true (and lets the caller proceed) if the token's operator
        /// has the required permission. Otherwise sends a 403 response,
        /// audit-logs the denial, and returns false so the caller returns
        /// immediately without running the handler.
        /// </summary>
        private static bool RequirePermission(HttpListenerContext ctx, TokenInfo tokenInfo, OperatorPermission required)
        {
            if ((tokenInfo.Permissions & required) == required) return true;
            AuditLog.Log("RestApi", $"Forbidden: {tokenInfo.Username} lacks {required} for {ctx.Request.HttpMethod} {ctx.Request.Url?.AbsolutePath}");
            SendJson(ctx, 403, new { error = $"Forbidden. This operator does not have the '{required}' permission." });
            return false;
        }

        // === Auth ===

        private static void HandleLogin(HttpListenerContext ctx)
        {
            var body = ReadBody(ctx.Request);
            string username = null, password = null;
            try
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, string>>(body);
                if (data != null)
                {
                    data.TryGetValue("username", out username);
                    data.TryGetValue("password", out password);
                }
            }
            catch { /* fall through to invalid creds */ }

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                SendJson(ctx, 400, new { error = "username and password required" });
                return;
            }

            Operator op;
            try { op = new OperatorManager().Authenticate(username, password); }
            catch (UnauthorizedAccessException ex) { SendJson(ctx, 401, new { error = ex.Message }); return; }
            catch (Exception ex) { AuditLog.Log("RestApi", "Login error: " + ex.Message); SendJson(ctx, 500, new { error = "Login failed" }); return; }

            // Skip 2FA in the API path for now — operators who have 2FA enabled
            // must use the desktop login. Documented as a known limitation.
            var tfa = new TwoFactorAuth();
            if (tfa.Is2FAEnabled(op.Id))
            {
                SendJson(ctx, 403, new { error = "2FA is enabled for this operator — use the desktop login (API 2FA not supported in this build)." });
                return;
            }

            // SECURITY FIX: OperatorPermission.ApiAccess exists specifically
            // to gate REST API usage, but it was never checked — every
            // operator who could log in to the desktop app could also mint
            // an API token, regardless of role. Now an operator without
            // ApiAccess is rejected here, before any token is issued.
            if ((op.Permissions & OperatorPermission.ApiAccess) != OperatorPermission.ApiAccess)
            {
                AuditLog.Log("RestApi", $"Login rejected: {op.Username} lacks ApiAccess permission.");
                SendJson(ctx, 403, new { error = "This operator account does not have API access permission." });
                return;
            }

            string token = GenerateToken();
            _tokens[token] = new TokenInfo { IssuedAt = DateTime.UtcNow, Username = op.Username, Permissions = op.Permissions };
            // FIX LONGTERM-2: ValidateToken only removes an expired token
            // when something later tries to USE that exact token — a token
            // issued once and never reused after expiring (a realistic
            // pattern: an admin opens the API dashboard once, never comes
            // back) sat in _tokens forever. Low volume compared to
            // audit_log, but still unbounded growth over long-term
            // operation. Piggyback a sweep on every new login (infrequent
            // enough to be cheap, frequent enough to actually bound growth).
            foreach (var kvp in _tokens)
            {
                if (DateTime.UtcNow - kvp.Value.IssuedAt > TimeSpan.FromHours(24))
                    _tokens.TryRemove(kvp.Key, out _);
            }
            AuditLog.Log("RestApi", $"Operator {op.Username} authenticated via REST API");
            SendJson(ctx, 200, new { token = token, username = op.Username, role = op.RoleName, permissions = op.Permissions.ToString() });
        }

        /// <summary>
        /// FIX SEC-2/FUNC-1: handles ZarinPal's redirect back to the
        /// customer's browser after payment (GET ?Authority=...&amp;Status=OK|NOK).
        /// This is the piece that was completely missing — see the long
        /// comment where this route is registered in Process() above.
        ///
        /// The amount used for verification/crediting is looked up from
        /// payment_transactions by authority — NEVER taken from the query
        /// string — because the query string comes from the customer's
        /// browser and is fully attacker-controllable; only the amount we
        /// ourselves stored when RequestPayment ran can be trusted.
        /// </summary>
        private static void HandlePaymentCallback(HttpListenerContext ctx)
        {
            string authority = ctx.Request.QueryString["Authority"] ?? ctx.Request.QueryString["authority"] ?? "";
            string status = ctx.Request.QueryString["Status"] ?? ctx.Request.QueryString["status"] ?? "";

            if (string.IsNullOrEmpty(authority))
            {
                SendHtml(ctx, 400, PaymentResultPage(false, "درخواست نامعتبر است (Authority یافت نشد)."));
                return;
            }

            try
            {
                var existing = Database.Instance.QueryOne(
                    "SELECT amount, status FROM payment_transactions WHERE authority = @a",
                    cmd => cmd.Parameters.AddWithValue("@a", authority),
                    r => new { Amount = r.GetDecimal(0), Status = r.GetString(1) });

                if (existing == null)
                {
                    AuditLog.Log("RestApi", "Payment callback: unknown authority " + authority);
                    SendHtml(ctx, 404, PaymentResultPage(false, "تراکنشی با این شناسه یافت نشد."));
                    return;
                }

                if (!string.Equals(status, "OK", StringComparison.OrdinalIgnoreCase))
                {
                    // Customer cancelled on ZarinPal's page, or payment failed
                    // there — mark it so it doesn't sit as "pending" forever
                    // and doesn't get confused with a transaction still in
                    // progress. Only touches rows still pending (idempotent /
                    // doesn't clobber an already-verified row from a race).
                    try
                    {
                        Database.Instance.Execute(
                            "UPDATE payment_transactions SET status = 'cancelled' WHERE authority = @a AND status = 'pending'",
                            cmd => cmd.Parameters.AddWithValue("@a", authority));
                    }
                    catch (Exception ex) { AuditLog.Log("RestApi", "Payment cancel-mark failed: " + ex.Message); }

                    SendHtml(ctx, 200, PaymentResultPage(false, "پرداخت لغو شد یا ناموفق بود."));
                    return;
                }

                string merchantId = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_merchant'", null, r => r.GetString(0)) ?? "";
                string sandboxVal = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_sandbox'", null, r => r.GetString(0));
                var gateway = new PaymentGateway(merchantId, sandbox: sandboxVal == "1");

                var result = gateway.VerifyPayment(authority, existing.Amount);
                if (result.Success)
                    SendHtml(ctx, 200, PaymentResultPage(true, $"پرداخت با موفقیت انجام شد. مبلغ {existing.Amount:N0} تومان به حساب شما اضافه شد. کد پیگیری: {result.RefId}"));
                else
                    SendHtml(ctx, 200, PaymentResultPage(false, "تایید پرداخت ناموفق بود: " + (result.Message ?? "")));
            }
            catch (Exception ex)
            {
                AuditLog.Log("RestApi", "Payment callback error: " + ex.Message);
                SendHtml(ctx, 500, PaymentResultPage(false, "خطای داخلی سرور در پردازش پرداخت."));
            }
        }

        private static string PaymentResultPage(bool success, string message)
        {
            string color = success ? "#a6e3a1" : "#f38ba8";
            string icon = success ? "✅" : "❌";
            return "<!DOCTYPE html><html dir=\"rtl\" lang=\"fa\"><head><meta charset=\"utf-8\"><title>نتیجه پرداخت</title>" +
                   "<style>body{background:#1e1e2e;color:#cdd6f4;font-family:Tahoma,Segoe UI,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center}" +
                   ".box{background:#313244;padding:40px;border-radius:16px;max-width:420px}" +
                   "h1{color:" + color + ";font-size:28px}p{font-size:16px;line-height:1.8}</style></head>" +
                   "<body><div class=\"box\"><h1>" + icon + "</h1><p>" + WebUtility.HtmlEncode(message) + "</p>" +
                   "<p style=\"opacity:.7;font-size:13px\">این پنجره را می‌توانید ببندید.</p></div></body></html>";
        }

        private static void SendHtml(HttpListenerContext ctx, int statusCode, string html)
        {
            ctx.Response.StatusCode = statusCode;
            ctx.Response.ContentType = "text/html; charset=utf-8";
            byte[] buf = Encoding.UTF8.GetBytes(html);
            ctx.Response.ContentLength64 = buf.Length;
            try { ctx.Response.OutputStream.Write(buf, 0, buf.Length); } catch { }
            try { ctx.Response.OutputStream.Close(); } catch { }
        }

        private static string GenerateToken()
        {
            using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create())
            {
                var bytes = new byte[32];
                rng.GetBytes(bytes);
                return Convert.ToBase64String(bytes).Replace("/", "_").Replace("+", "-").TrimEnd('=');
            }
        }

        private static string ExtractToken(HttpListenerContext ctx)
        {
            string authHeader = ctx.Request.Headers["Authorization"] ?? "";
            if (authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                return authHeader.Substring(7).Trim();
            string q = ctx.Request.QueryString["token"];
            return q ?? "";
        }

        /// <summary>
        /// FIX B18: validates that a token is known AND not older than 24
        /// hours. Expired tokens are removed from the dictionary and rejected.
        /// Also returns the token's associated <see cref="TokenInfo"/> (issuing
        /// operator + permissions) so callers can enforce per-endpoint
        /// permission checks.
        /// </summary>
        private static bool ValidateToken(string token, out TokenInfo info)
        {
            info = null;
            if (string.IsNullOrEmpty(token)) return false;
            if (!_tokens.TryGetValue(token, out var found)) return false;
            if (DateTime.UtcNow - found.IssuedAt > TimeSpan.FromHours(24))
            {
                _tokens.TryRemove(token, out _);
                return false;
            }
            info = found;
            return true;
        }

        // === Clients ===

        private static void HandleListClients(HttpListenerContext ctx)
        {
            var comm = ClientCommunicatorInstance;
            if (comm == null) { SendJson(ctx, 503, new { error = "Server not initialized" }); return; }
            var list = comm.GetAllRawConnections().Select(c => new
            {
                station = c.StationName,
                client_ip = c.ClientIp,
                state = c.State.ToString(),
                user = c.User,
                game = c.Game,
                minutes_elapsed = c.Minutes,
                cost = c.Cost,
                last_heartbeat = c.LastHeartbeat,
                connected_at = c.ConnectedAt,
                session_start = c.SessionStart,
                mac = c.MacAddress,
                client_version = c.ClientVersion
            }).ToList();
            SendJson(ctx, 200, new { count = list.Count, clients = list });
        }

        private static void HandleGetClient(HttpListenerContext ctx, string path)
        {
            var comm = ClientCommunicatorInstance;
            if (comm == null) { SendJson(ctx, 503, new { error = "Server not initialized" }); return; }
            // FIX B13: use the RAW URL path so encoded slashes (%2F) inside
            // the station name are preserved. The previous code used
            // Uri.AbsolutePath (via the `path` arg), which auto-decodes %2F
            // to '/' — so a station name like "station%2F1" became
            // "station/1" and the subsequent IndexOf('/') split broke.
            // We split the raw path on '/' FIRST, then unescape each segment
            // separately so an encoded slash stays inside the segment.
            string station;
            try
            {
                var segs = GetRawPathSegments(ctx.Request);
                // segs[0] = "api", segs[1] = "clients", segs[2] = station
                if (segs.Length < 3 || segs[0] != "api" || segs[1] != "clients")
                { SendJson(ctx, 400, new { error = "Invalid path" }); return; }
                station = Uri.UnescapeDataString(segs[2]);
            }
            catch (Exception ex) { SendJson(ctx, 400, new { error = "Bad path: " + ex.Message }); return; }
            if (string.IsNullOrEmpty(station)) { SendJson(ctx, 400, new { error = "Station name required" }); return; }
            var match = comm.GetAllRawConnections().FirstOrDefault(c => string.Equals(c.StationName, station, StringComparison.OrdinalIgnoreCase));
            if (match.StationName == null) { SendJson(ctx, 404, new { error = $"No client with station '{station}'" }); return; }
            SendJson(ctx, 200, new
            {
                station = match.StationName,
                client_ip = match.ClientIp,
                state = match.State.ToString(),
                user = match.User,
                game = match.Game,
                minutes_elapsed = match.Minutes,
                cost = match.Cost,
                last_heartbeat = match.LastHeartbeat,
                connected_at = match.ConnectedAt,
                session_start = match.SessionStart,
                mac = match.MacAddress,
                client_version = match.ClientVersion
            });
        }

        private static void HandleClientAction(HttpListenerContext ctx, string path, TokenInfo tokenInfo)
        {
            var comm = ClientCommunicatorInstance;
            if (comm == null) { SendJson(ctx, 503, new { error = "Server not initialized" }); return; }
            // FIX B13: parse the RAW URL path so an encoded slash (%2F) inside
            // the station name doesn't break the segment split. We split on
            // '/' FIRST (preserving %2F inside each segment), then unescape
            // each segment separately.
            // Expected segments: ["api", "clients", station, action]
            string station, action;
            try
            {
                var segs = GetRawPathSegments(ctx.Request);
                if (segs.Length < 4 || segs[0] != "api" || segs[1] != "clients")
                { SendJson(ctx, 400, new { error = "Missing action. Use /api/clients/{station}/{action}" }); return; }
                station = Uri.UnescapeDataString(segs[2]);
                action = Uri.UnescapeDataString(segs[3]).ToLowerInvariant();
            }
            catch (Exception ex) { SendJson(ctx, 400, new { error = "Bad path: " + ex.Message }); return; }

            // SECURITY FIX: shutdown/restart are far more disruptive than
            // adding time or locking/unlocking a session, and the desktop UI
            // already gates them behind separate permissions — mirror that
            // split here instead of only requiring "some token" as before.
            bool isDisruptive = action == "shutdown" || action == "restart";
            var neededPermission = isDisruptive ? OperatorPermission.ShutdownClients : OperatorPermission.StartStopSession;
            if (!RequirePermission(ctx, tokenInfo, neededPermission)) return;

            switch (action)
            {
                case "time":
                    int minutes = 0;
                    try
                    {
                        var body = ReadBody(ctx.Request);
                        var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(body ?? "");
                        if (data != null && data.TryGetValue("minutes", out var m))
                            int.TryParse(m?.ToString(), out minutes);
                    }
                    catch { }
                    if (minutes <= 0) { SendJson(ctx, 400, new { error = "Body must be JSON: {\"minutes\": 30}" }); return; }
                    try
                    {
                        comm.AddTimeToStation(station, minutes);
                        SendJson(ctx, 200, new { status = "ok", station = station, minutes_added = minutes });
                    }
                    catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
                    break;
                case "lock":
                    try { SendJson(ctx, 200, new { status = "lock_removed", station = station }); }
                    catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
                    break;
                case "unlock":
                    try { comm.UnlockStation(station); SendJson(ctx, 200, new { status = "unlocked", station = station }); }
                    catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
                    break;
                case "shutdown":
                    try { comm.ShutdownStation(station); SendJson(ctx, 200, new { status = "shutdown_sent", station = station }); }
                    catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
                    break;
                case "restart":
                    try { comm.RestartStation(station); SendJson(ctx, 200, new { status = "restart_sent", station = station }); }
                    catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
                    break;
                default:
                    SendJson(ctx, 400, new { error = $"Unknown action: {action}" });
                    break;
            }
        }

        // === Users ===

        private static void HandleListUsers(HttpListenerContext ctx)
        {
            try
            {
                var users = Database.Instance.Query("SELECT username, display_name, balance, is_active, created_at, phone FROM users ORDER BY username",
                    null,
                    r => new
                    {
                        username = r.GetString(0),
                        display_name = r.IsDBNull(1) ? r.GetString(0) : r.GetString(1),
                        balance = r.GetDecimal(2),
                        is_active = r.GetBoolean(3),
                        created_at = r.GetDateTime(4),
                        phone = r.IsDBNull(5) ? "" : r.GetString(5)
                    });
                SendJson(ctx, 200, new { count = users.Count, users = users });
            }
            catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
        }

        private static void HandleAddUserCredit(HttpListenerContext ctx, string path, TokenInfo tokenInfo)
        {
            // FIX B13: parse the RAW URL path so encoded slashes in the
            // username don't break the split. Segments: ["api", "users",
            // username, "credit"].
            string username;
            try
            {
                var segs = GetRawPathSegments(ctx.Request);
                if (segs.Length < 4 || segs[0] != "api" || segs[1] != "users")
                { SendJson(ctx, 400, new { error = "Use /api/users/{username}/credit" }); return; }
                username = Uri.UnescapeDataString(segs[2]);
                if (!Uri.UnescapeDataString(segs[3]).Equals("credit", StringComparison.OrdinalIgnoreCase))
                { SendJson(ctx, 400, new { error = "Use /api/users/{username}/credit" }); return; }
            }
            catch (Exception ex) { SendJson(ctx, 400, new { error = "Bad path: " + ex.Message }); return; }
            decimal amount = 0;
            try
            {
                var body = ReadBody(ctx.Request);
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(body ?? "");
                if (data != null && data.TryGetValue("amount", out var a))
                    decimal.TryParse(a?.ToString(), out amount);
            }
            catch { }
            if (amount <= 0) { SendJson(ctx, 400, new { error = "Body must be JSON: {\"amount\": 5000}" }); return; }
            try
            {
                new UserManager().AddCredit(username, amount);
                AuditLog.Log("RestApi", $"{tokenInfo.Username} added {amount:N0} credit to {username} via API");
                SendJson(ctx, 200, new { status = "ok", username = username, amount_added = amount });
            }
            catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
        }

        // === Reports ===

        private static void HandleReportDaily(HttpListenerContext ctx)
        {
            try
            {
                var todayStart = DateTime.UtcNow.Date;
                var todayEnd = todayStart.AddDays(1);
                var sessions = Database.Instance.Query(
                    "SELECT username, station_name, start_time, end_time, duration_minutes, total_cost, current_game FROM client_sessions WHERE start_time >= @s AND start_time < @e ORDER BY start_time DESC LIMIT 200",
                    cmd => { cmd.Parameters.AddWithValue("@s", todayStart.ToString("o")); cmd.Parameters.AddWithValue("@e", todayEnd.ToString("o")); },
                    r => new
                    {
                        username = r.IsDBNull(0) ? "" : r.GetString(0),
                        station = r.IsDBNull(1) ? "" : r.GetString(1),
                        start = r.GetDateTime(2),
                        end = r.IsDBNull(3) ? (DateTime?)null : r.GetDateTime(3),
                        minutes = r.IsDBNull(4) ? 0 : r.GetInt32(4),
                        cost = r.IsDBNull(5) ? 0m : r.GetDecimal(5),
                        game = r.IsDBNull(6) ? "" : r.GetString(6)
                    });
                decimal income = sessions.Sum(s => s.cost);
                SendJson(ctx, 200, new { date = todayStart.ToString("yyyy-MM-dd"), session_count = sessions.Count, total_income = income, sessions = sessions });
            }
            catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
        }

        private static void HandleReportIncome(HttpListenerContext ctx)
        {
            try
            {
                var now = DateTime.UtcNow;
                var todayStart = now.Date;
                var weekStart = todayStart.AddDays(-7);
                var monthStart = todayStart.AddDays(-30);

                decimal today = SumIncome(todayStart, now);
                decimal week = SumIncome(weekStart, now);
                decimal month = SumIncome(monthStart, now);

                SendJson(ctx, 200, new
                {
                    today_income = today,
                    week_income = week,
                    month_income = month,
                    today_sessions = CountSessions(todayStart, now),
                    week_sessions = CountSessions(weekStart, now),
                    month_sessions = CountSessions(monthStart, now),
                    generated_at = now
                });
            }
            catch (Exception ex) { SendJson(ctx, 500, new { error = ex.Message }); }
        }

        private static decimal SumIncome(DateTime start, DateTime end)
        {
            return Database.Instance.QueryOne("SELECT COALESCE(SUM(total_cost),0) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                r => r.GetDecimal(0));
        }

        private static int CountSessions(DateTime start, DateTime end)
        {
            return Database.Instance.QueryOne("SELECT COUNT(*) FROM client_sessions WHERE start_time >= @s AND start_time <= @e",
                cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                r => r.GetInt32(0));
        }

        // === Status ===

        private static void HandleStatus(HttpListenerContext ctx)
        {
            var comm = ClientCommunicatorInstance;
            int clientCount = comm?.ConnectedClientCount ?? 0;
            decimal todayIncome = 0;
            try { todayIncome = SumIncome(DateTime.UtcNow.Date, DateTime.UtcNow); } catch { }
            SendJson(ctx, 200, new
            {
                server_version = "1.0",
                started_at = _startedAt,
                uptime_seconds = (long)(DateTime.UtcNow - _startedAt).TotalSeconds,
                connected_clients = clientCount,
                today_income = todayIncome,
                database_provider = Database.Provider.ToString(),
                api_active_tokens = _tokens.Count
            });
        }

        // === Helpers ===

        /// <summary>
        /// Returns the live ClientCommunicator singleton. MainForm stores the
        /// reference via <see cref="SetClientCommunicator"/> when the server
        /// boots. Returns null if the server hasn't started yet.
        /// </summary>
        private static ClientCommunicator _communicator;
        public static ClientCommunicator ClientCommunicatorInstance => _communicator;
        public static void SetClientCommunicator(ClientCommunicator comm) { _communicator = comm; }

        private static void SendJson(HttpListenerContext ctx, int statusCode, object data)
        {
            ctx.Response.StatusCode = statusCode;
            ctx.Response.ContentType = "application/json; charset=utf-8";
            byte[] buf = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data, Formatting.Indented));
            ctx.Response.ContentLength64 = buf.Length;
            try { ctx.Response.OutputStream.Write(buf, 0, buf.Length); } catch { }
            try { ctx.Response.OutputStream.Close(); } catch { }
        }

        private static string ReadBody(HttpListenerRequest req)
        {
            try
            {
                if (!req.HasEntityBody) return "";
                using (var reader = new StreamReader(req.InputStream, Encoding.UTF8)) return reader.ReadToEnd();
            }
            catch { return ""; }
        }

        /// <summary>
        /// FIX B13: returns the path segments of the RAW URL (preserving
        /// percent-encoded characters). The HttpListenerRequest.RawUrl
        /// property is the URL exactly as the client sent it — it does NOT
        /// decode %2F to '/' the way Uri.AbsolutePath does. We strip the
        /// query string (if any) and split on '/' so encoded slashes inside
        /// a segment (e.g. a station name like "station%2F1") survive the
        /// split and can be unescaped AFTER the split.
        /// </summary>
        private static string[] GetRawPathSegments(HttpListenerRequest req)
        {
            string raw = req.RawUrl ?? "";
            // Strip query string if present.
            int q = raw.IndexOf('?');
            if (q >= 0) raw = raw.Substring(0, q);
            // Decode + in the path (some clients encode spaces as +).
            // Note: we do NOT call Uri.UnescapeDataString on the whole
            // string here — that would decode %2F too, which is exactly
            // what we want to avoid.
            return raw.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private static string UrlDecode(string s)
        {
            try { return Uri.UnescapeDataString(s); } catch { return s; }
        }
    }
}
