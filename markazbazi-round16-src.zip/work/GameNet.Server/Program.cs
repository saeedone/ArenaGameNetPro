﻿using System;
using System.Windows.Forms;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;

namespace GameNet.Server
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            // Round 12 self-repair: "GameNet.Server.exe --guard <pid>" is the server's guard
            // (no window): it starts the server again after a crash or a hang of 2 minutes.
            if (GameNet.Shared.SelfHeal.Guardian.IsGuardInvocation(args))
            {
                Environment.ExitCode = GameNet.Shared.SelfHeal.Guardian.RunGuard(args, new GameNet.Shared.SelfHeal.GuardOptions
                {
                    Key = "Server",
                    HangSeconds = 120,
                    ConfigFiles = () => new[] { OptionsPath() },
                });
                return;
            }

            // Self-repair: the diagnostics journal starts first (diagnostics.log next to the
            // exe, or in %APPDATA%\GameNet when that folder is read-only).
            FaultJournal.Initialize("Server", AppDomain.CurrentDomain.BaseDirectory);

            // FIX-MONITOR-ADD5 TASK B1: Global exception handlers + crash
            // logger. Attached at the very top of Main so ANY exception —
            // whether on the UI thread (Application.ThreadException) or on
            // a threadpool / background thread (AppDomain.UnhandledException)
            // — gets written to crash_log.txt next to the server exe before
            // the process dies. Without this, an unhandled exception on a
            // ThreadPool thread (e.g. from ClientCommunicator's read loop)
            // would crash the server silently with no diagnostic trail.
            AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
            {
                // Self-repair: record the diagnosis; it is shown on the next start.
                try { FaultJournal.RecordCrash(FaultCatalog.ClassifyException(e.ExceptionObject as Exception, true), e.ExceptionObject as Exception, "UnhandledException"); } catch { }
                try {
                    var ex = e.ExceptionObject as Exception;
                    System.IO.File.AppendAllText(
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash_log.txt"),
                        DateTime.Now.ToString("o") + " | FATAL | " + ex?.ToString() + "\n" + new string('=', 80) + "\n");
                } catch { }
                // Round 12: no message box here. The process ends after this handler, and the
                // box kept the dead server open until someone clicked it, so the guard could
                // not start it again. The reason is shown at the next start.
            };

            Application.ThreadException += (sender, e) =>
            {
                // Self-repair: record the diagnosis; it is shown on the next start.
                try { FaultJournal.RecordCrash(FaultCatalog.ClassifyException(e.Exception, true), e.Exception, "UI"); } catch { }
                try {
                    System.IO.File.AppendAllText(
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash_log.txt"),
                        DateTime.Now.ToString("o") + " | UI | " + e.Exception?.ToString() + "\n" + new string('=', 80) + "\n");
                } catch { }
                try { MessageBox.Show("خطا:\n\n" + e.Exception?.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning); } catch { }
            };

            // FIX B8: single-instance guard. The most common cause of the
            // "won't open" symptom is a previous GameNet.Server.exe still
            // running (holding the TCP port + the gamenet.db SQLite handle).
            // Without this guard, the second instance would start, fail to
            // bind the port, throw inside the MainForm constructor, and exit
            // silently — leaving the operator confused. With the guard the
            // operator gets a clear Persian dialog telling them to close the
            // existing instance first.
            bool createdNew;
            using (var mutex = new System.Threading.Mutex(true, "Global\\GameNet-Server-Singleton", out createdNew))
            {
                if (!createdNew)
                {
                    // Round 12: on purpose, so a guard does not keep starting a second copy.
                    GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server");
                    MessageBox.Show("سرور GameNet از قبل در حال اجراست.\nبرای باز کردن مجدد، ابتدا نسخه فعلی را ببندید.",
                        "GameNet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Round 12 self-repair: start (or find) the guard, and record what it did
                // since the last start (shown in the diagnostics journal).
                try
                {
                    foreach (var ev in GameNet.Shared.SelfHeal.Guardian.TakeEvents("Server"))
                    {
                        var parts = ev.Split('\t');
                        if (parts.Length >= 3)
                        {
                            FaultJournal.Raise(parts[1], parts[0] + " " + parts[2]);
                            _guardEvents.Add(parts[0] + " " + parts[2]); // round 14: also to the activity journal
                        }
                    }
                    GameNet.Shared.SelfHeal.Guardian.StartWatching("Server");
                    Microsoft.Win32.SystemEvents.SessionEnding += (s2, e2) =>
                    {
                        try { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server"); } catch { }
                    };
                }
                catch { }

                // Round 12: options.json — a damaged file gets its last-good copy back
                // (LoadStaticOptions silently fell back to defaults, and the next save
                // overwrote the operator's settings with them); a good file is copied.
                CheckOptionsFile();

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                // Round 11: the 3D program icon on every window.
                GameNet.Shared.AppIcon.InstallAsDefault("server.ico");

                // Round 11: the start-up splash (a fixed 2-second wait, nothing loaded
                // meanwhile) was removed at the user's request.

                // Initialize database
                // FIX L5: use an ABSOLUTE path next to the server exe. The previous
                // "Data Source=gamenet.db" is a relative path that resolves against
                // the process's current working directory — which is whatever the
                // operator's shell happened to be in when they double-clicked the
                // exe (or, when launched by a service, the service's working dir).
                // That made the DB file appear in random places (Desktop, System32,
                // the service account's home dir) and broke the BackupManager's
                // "restore from the file next to the exe" logic. Absolute path
                // guarantees the DB lives next to GameNet.Server.exe.
                string dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet.db");

                // ADD-MULTI-FEATURES Feature 1 (MySQL support):
                // Read DatabaseProvider + MySqlConnectionString from options.json.
                // Default is SQLite so existing installs keep working. When MySQL
                // is selected, Database.InitializeMySQL opens a MySql.Data
                // connection and stamps Database.Provider; the SQLite singleton is
                // still created (in-memory) so legacy Execute/Query callers don't
                // throw — see Database.InitializeMySQL doc comment for migration
                // notes.
                string dbProvider = "sqlite";
                string mysqlConnStr = "";
                try
                {
                    var opts = Forms.OptionsForm.LoadStaticOptions();
                    if (opts != null)
                    {
                        if (!string.IsNullOrWhiteSpace(opts.DatabaseProvider))
                            dbProvider = opts.DatabaseProvider.Trim().ToLowerInvariant();
                        if (!string.IsNullOrWhiteSpace(opts.MySqlConnectionString))
                            mysqlConnStr = opts.MySqlConnectionString;
                    }
                }
                catch (Exception ex)
                {
                    Core.AuditLog.Log("Program", "Read DatabaseProvider options failed: " + ex.Message);
                    FaultJournal.Raise("CFG-002", "options.json could not be read at start-up: " + ex.Message);
                }

                // FIX B3: wrap Database.Initialize / InitializeMySQL in try/catch.
                // A corrupt or locked gamenet.db (e.g. opened by another process,
                // antivirus scanning, broken WAL file) makes Initialize throw —
                // previously this killed the server silently. Now the operator
                // gets a clear Persian error dialog explaining the likely cause.
                if (dbProvider == "mysql" && !string.IsNullOrWhiteSpace(mysqlConnStr))
                {
                    try
                    {
                        Core.Database.InitializeMySQL(mysqlConnStr);
                    }
                    catch (Exception ex)
                    {
                        try { Core.AuditLog.Log("Program", "Database.InitializeMySQL failed: " + ex.Message); } catch { }
                        FaultJournal.Raise("DB-001", "MySQL: " + ex.Message);
                        MessageBox.Show("خطای پایگاه داده MySQL:\n" + ex.Message +
                            "\n\nسرور به جای آن از SQLite استفاده خواهد کرد.",
                            "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        try { Core.Database.Initialize($"Data Source={dbPath}"); }
                        catch (Exception ex2)
                        {
                            MessageBox.Show("خطای پایگاه داده:\n" + ex2.Message +
                                "\n\nممکن است فایل gamenet.db قفل یا خراب باشد.",
                                "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server"); return; } // round 12: on purpose
                        }
                    }
                }
                else
                {
                    // Round 12: check gamenet.db before opening it; a damaged file is
                    // replaced by the newest good backup if the operator agrees.
                    try { Core.DatabaseSelfRepair.CheckAndRepair(dbPath); }
                    catch (Exception ex) { try { Core.AuditLog.Log("Program", "DatabaseSelfRepair failed: " + ex.Message); } catch { } }
                    try
                    {
                        Core.Database.Initialize($"Data Source={dbPath}");
                        Core.DatabaseSelfRepair.MakeDailyCopyInBackground(dbPath); // round 12
                        // Round 14: activity journal — server start, old lines cleaned up.
                        Core.ActivityJournal.Cleanup(180);
                        Core.ActivityJournal.Record(Core.ActivityJournal.Server,
                            GameNet.Shared.SelfHeal.Guardian.WasRestarted(args) ? "سرور خودکار دوباره روشن شد (بعد از خرابی)" : "سرور روشن شد");
                        foreach (var line in _guardEvents)
                            Core.ActivityJournal.Record(Core.ActivityJournal.Repair, "سرور: " + line);
                    }
                    catch (Exception ex)
                    {
                        try { Core.AuditLog.Log("Program", "Database.Initialize failed: " + ex.Message); } catch { }
                        FaultJournal.Raise("DB-001", "SQLite: " + ex.Message);
                        MessageBox.Show("خطای پایگاه داده:\n" + ex.Message +
                            "\n\nممکن است فایل gamenet.db قفل یا خراب باشد.",
                            "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server"); return; } // round 12: on purpose
                    }
                }

                // Ensure default operator exists (for server admin panel login)
                // FIX B4: OperatorManager.EnsureDefaultOperator already wraps its
                // own body in try/catch — but wrap the call too just in case.
                try { Core.OperatorManager.EnsureDefaultOperator(); }
                catch (Exception ex) { try { Core.AuditLog.Log("Program", "EnsureDefaultOperator failed: " + ex.Message); } catch { } }

                // Ensure default client user exists (for CLIENT/kiosk login).
                // Without this, the client login screen has no credentials to
                // authenticate against — the "admin/password doesn't work on
                // client" bug.
                try { Core.UserManager.EnsureDefaultUser(); }
                catch (Exception ex) { try { Core.AuditLog.Log("Program", "EnsureDefaultUser failed: " + ex.Message); } catch { } }

                // FIX B12: 2FA recovery. If a file `disable_2fa.txt` exists next
                // to the exe, clear all 2FA secrets in the operators table and
                // delete the file. This is the operator's emergency recovery
                // path when they lose their Authenticator device — without it
                // they would be permanently locked out of the server UI.
                try
                {
                    string disable2FaPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "disable_2fa.txt");
                    if (System.IO.File.Exists(disable2FaPath))
                    {
                        try
                        {
                            Core.Database.Instance.Execute("UPDATE operators SET two_factor_secret = NULL, two_factor_enabled = 0", null);
                            System.IO.File.Delete(disable2FaPath);
                            Core.AuditLog.Log("Program", "2FA disabled for all operators (disable_2fa.txt was present).");
                            MessageBox.Show("احراز هویت دو مرحله‌ای برای همه اپراتورها غیرفعال شد.\nفایل disable_2fa.txt حذف شد.\n\nبرای امنیت، دوباره 2FA را فعال کنید.",
                                "GameNet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex2) { try { Core.AuditLog.Log("Program", "2FA disable failed: " + ex2.Message); } catch { } }
                    }
                }
                catch { }

                // STEP 1: Force operator login BEFORE showing the main window.
                // The server UI must never be accessible without authentication.
                Operator currentOperator = null;
                // FIX 19: create a new OperatorLoginForm instance per attempt —
                // reusing a single disposed instance across multiple ShowDialog
                // calls can leave the form in a half-disposed (broken-render) state.
                for (int attempt = 0; attempt < 3; attempt++)
                {
                    using (var loginForm = new Forms.OperatorLoginForm())
                    {
                        if (loginForm.ShowDialog() == DialogResult.OK && loginForm.CurrentOperator != null)
                        {
                            currentOperator = loginForm.CurrentOperator;
                            break;
                        }
                        if (loginForm.DialogResult == DialogResult.Cancel)
                        {
                            // User clicked cancel — exit the server entirely.
                            { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server"); return; } // round 12: on purpose
                        }
                    }
                }

                if (currentOperator == null)
                {
                    // Too many failed attempts — exit.
                    MessageBox.Show("تعداد تلاش‌های ناموفق زیاد است. سرور بسته می‌شود.", "GameNet", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    { GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server"); return; } // round 12: on purpose
                }

                // STEP 2: Run the main window with the authenticated operator.
                // FIX B2: wrap Application.Run in try/catch so any uncaught
                // exception from the MainForm constructor (after authentication
                // succeeded) shows a clear Persian error dialog instead of
                // silently crashing. The error is also logged via AuditLog.
                try
                {
                    Application.Run(new Forms.MainForm(currentOperator));
                    // Round 12: the operator closed the server: the guard lets it go.
                    GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server");
                }
                catch (Exception ex)
                {
                    // Round 12: a start-up failure is shown to the operator; restarting would
                    // only repeat it, so the guard is told this exit is on purpose.
                    GameNet.Shared.SelfHeal.Guardian.MarkIntentionalExit("Server");
                    try { Core.AuditLog.Log("Program", "FATAL: " + ex.ToString()); } catch { }
                    MessageBox.Show("خطای بحرانی در راه‌اندازی سرور:\n\n" + ex.Message +
                        "\n\nلطفاً با پشتیبانی تماس بگیرید.",
                        "GameNet - خطای بحرانی", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } // end using mutex
        }

        private static readonly System.Collections.Generic.List<string> _guardEvents = new System.Collections.Generic.List<string>();

        private static string OptionsPath()
        {
            return System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
        }

        /// <summary>Round 12: last-good copy of options.json (see LastGoodConfig).</summary>
        private static void CheckOptionsFile()
        {
            string path = OptionsPath();
            try
            {
                if (!System.IO.File.Exists(path)) return;
                if (OptionsReadable(path)) { GameNet.Shared.SelfHeal.LastGoodConfig.Snapshot(path); return; }
                if (GameNet.Shared.SelfHeal.LastGoodConfig.Restore(path) && OptionsReadable(path))
                    FaultJournal.Raise("HEAL-004", path);
                else
                    FaultJournal.Raise("CFG-002", "options.json is damaged and no last-good copy could be used");
            }
            catch { }
        }

        private static bool OptionsReadable(string path)
        {
            try
            {
                var text = System.IO.File.ReadAllText(path);
                if (string.IsNullOrWhiteSpace(text)) return false;
                return Newtonsoft.Json.JsonConvert.DeserializeObject<Forms.OptionsForm.OptionsData>(text) != null;
            }
            catch { return false; }
        }
    }
}
