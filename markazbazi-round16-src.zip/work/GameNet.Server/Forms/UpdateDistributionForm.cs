using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Update + file transfer + crash report management form. Three tabs:
    ///   1. Updates — package a new client build, push to all/selected kiosks
    ///   2. File transfer — send an arbitrary file to a specific kiosk
    ///   3. Crash reports — view client crash logs collected by the server
    /// </summary>
    public class UpdateDistributionForm : Form
    {
        private readonly ClientCommunicator _comm;
        private readonly UpdateDistributor _upd = new UpdateDistributor();
        private TabControl _tabs;
        private DataGridView _dgvCrashes;
        private Timer _timer;

        public UpdateDistributionForm(ClientCommunicator comm)
        {
            _comm = comm;
            this.Text = "📦 آپدیت + انتقال فایل + گزارش کرش";
            this.Size = new Size(1000, 650);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshCrashes(null, null);
            _timer = new Timer { Interval = 15000 };
            _timer.Tick += RefreshCrashes;
            _timer.Start();
        }

        private void BuildUi()
        {
            _tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9F) };

            // === Tab 1: Updates ===
            var tabUpdates = new TabPage("🔄 آپدیت کلاینت") { BackColor = Color.FromArgb(240, 240, 240) };

            var lblTitle = new Label { Text = "🔄 توزیع آپدیت کلاینت", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 10), AutoSize = true };
            var lblInstructions = new Label
            {
                Text = "📋 راهنما:\n" +
                       "1. فایل GameNet.Client.exe جدید را در پوشه «updates» کنار سرور کپی کنید\n" +
                       "2. فایل version.txt در همان پوشه بسازید با محتوای:\n" +
                       "   خط 1: شماره نسخه (مثلاً 8.1)\n" +
                       "   خط 2: optional — «mandatory» برای آپدیت اجباری\n" +
                       "   خط 3: optional — یادداشت نسخه\n" +
                       "3. روی «بررسی آپدیت» کلیک کنید\n" +
                       "4. روی «ارسال به همه کلاینت‌ها» کلیک کنید",
                Location = new Point(15, 40), Size = new Size(700, 100), Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130)
            };

            var lblStatus = new Label { Name = "lblUpdStatus", Text = "وضعیت: بررسی نشده", Location = new Point(15, 150), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20) };

            var btnCheck = new Button { Text = "🔍 بررسی آپدیت", Location = new Point(15, 180), Size = new Size(180, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnCheck.Click += (s, e) => CheckUpdate(lblStatus);

            var btnOpenFolder = new Button { Text = "📂 باز کردن پوشه updates", Location = new Point(205, 180), Size = new Size(200, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213)) };
            btnOpenFolder.Click += (s, e) => { try { System.Diagnostics.Process.Start(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "updates")); } catch { } };

            var btnPushAll = new Button { Text = "📡 ارسال به همه کلاینت‌ها", Location = new Point(415, 180), Size = new Size(220, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnPushAll.Click += (s, e) => PushUpdateToAll(lblStatus);

            tabUpdates.Controls.AddRange(new Control[] { lblTitle, lblInstructions, lblStatus, btnCheck, btnOpenFolder, btnPushAll });

            // === Tab 2: File transfer ===
            var tabFile = new TabPage("📁 انتقال فایل") { BackColor = Color.FromArgb(240, 240, 240) };

            var lblFTitle = new Label { Text = "📁 انتقال فایل به کلاینت", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 10), AutoSize = true };

            var lblStation = new Label { Text = "ایستگاه هدف:", Location = new Point(15, 45), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var cboStation = new ComboBox { Name = "cboStation", Location = new Point(120, 42), Size = new Size(250, 28), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };

            var lblFile = new Label { Text = "فایل:", Location = new Point(15, 80), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtFile = new TextBox { Name = "txtFile", Location = new Point(120, 77), Size = new Size(400, 28), ReadOnly = true, Font = new Font("Segoe UI", 9F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnBrowse = new Button { Text = "...", Location = new Point(530, 76), Size = new Size(35, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnBrowse.Click += (s, e) =>
            {
                using (var dlg = new OpenFileDialog { Title = "انتخاب فایل" })
                    if (dlg.ShowDialog() == DialogResult.OK) txtFile.Text = dlg.FileName;
            };

            var lblTarget = new Label { Text = "مسیر مقصد در کلاینت:", Location = new Point(15, 115), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtTarget = new TextBox { Location = new Point(180, 112), Size = new Size(385, 28), Font = new Font("Consolas", 9F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtTarget.Text = @"C:\Games\";

            var btnSend = new Button { Text = "📤 ارسال فایل", Location = new Point(15, 150), Size = new Size(200, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSend.Click += (s, e) => SendFile(cboStation, txtFile, txtTarget);

            tabFile.Controls.AddRange(new Control[] { lblFTitle, lblStation, cboStation, lblFile, txtFile, btnBrowse, lblTarget, txtTarget, btnSend });

            // === Tab 3: Crash reports ===
            var tabCrashes = new TabPage("💥 گزارش کرش") { BackColor = Color.FromArgb(240, 240, 240) };

            _dgvCrashes = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvCrashes.Columns.Add("colCTime", "زمان کرش");
            _dgvCrashes.Columns.Add("colCStation", "ایستگاه");
            _dgvCrashes.Columns.Add("colCVersion", "نسخه");
            _dgvCrashes.Columns.Add("colCType", "نوع خطا");
            _dgvCrashes.Columns.Add("colCMsg", "پیام");
            _dgvCrashes.Columns.Add("colCAction", "آخرین عملیات");

            var btnRefreshCrashes = new Button { Text = "🔄 بازخوانی", Dock = DockStyle.Bottom, Height = 35, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRefreshCrashes.Click += (s, e) => RefreshCrashes(null, null);
            var btnClearCrashes = new Button { Text = "🧹 پاک‌سازی گزارش‌ها", Dock = DockStyle.Bottom, Height = 35, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnClearCrashes.Click += (s, e) =>
            {
                if (MessageBox.Show("پاک کردن همه گزارش‌های کرش؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Database.Instance.Execute("DELETE FROM client_crash_reports", null);
                    RefreshCrashes(null, null);
                }
            };

            tabCrashes.Controls.AddRange(new Control[] { _dgvCrashes, btnClearCrashes, btnRefreshCrashes });

            _tabs.TabPages.AddRange(new TabPage[] { tabUpdates, tabFile, tabCrashes });
            Controls.Add(_tabs);

            // Populate station combo + refresh on tab change
            _tabs.SelectedIndexChanged += (s, e) => { if (_tabs.SelectedIndex == 1) PopulateStations(cboStation); };
        }

        private void CheckUpdate(Label lblStatus)
        {
            try
            {
                var offer = _upd.GetLatestUpdate();
                if (offer == null)
                {
                    lblStatus.Text = "⚠️ آپدیتی موجود نیست. فایل را در پوشه updates قرار دهید.";
                    lblStatus.ForeColor = Color.FromArgb(180, 140, 20);
                    return;
                }
                lblStatus.Text = $"✅ آپدیت موجود: نسخه {offer.Version} | حجم: {offer.FileSize / 1024} KB | SHA: {offer.Sha256?.Substring(0, 12)}…";
                lblStatus.ForeColor = Color.FromArgb(20, 130, 50);
            }
            catch (Exception ex) { lblStatus.Text = "❌ خطا: " + ex.Message; lblStatus.ForeColor = Color.FromArgb(200, 30, 60); }
        }

        private void PushUpdateToAll(Label lblStatus)
        {
            var offer = _upd.GetLatestUpdate();
            if (offer == null) { MessageBox.Show("آپدیتی موجود نیست."); return; }

            int count = 0;
            foreach (var c in _comm.GetAllRawConnections())
            {
                try { _comm.OfferUpdate(c.StationName); count++; } catch { }
            }
            lblStatus.Text = $"📡 آپدیت v{offer.Version} به {count} کلاینت ارسال شد.";
            lblStatus.ForeColor = Color.FromArgb(20, 130, 50);
            MessageBox.Show($"آپدیت به {count} کلاینت پیشنهاد شد.\nکلاینت‌ها به طور خودکار دانلود و نصب می‌کنند.", "ارسال شد", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void PopulateStations(ComboBox cbo)
        {
            cbo.Items.Clear();
            foreach (var c in _comm.GetAllRawConnections())
                if (!string.IsNullOrEmpty(c.StationName) && c.StationName != "(در حال اتصال...)")
                    cbo.Items.Add(c.StationName);
            if (cbo.Items.Count > 0) cbo.SelectedIndex = 0;
        }

        private void SendFile(ComboBox cbo, TextBox txtFile, TextBox txtTarget)
        {
            if (cbo.SelectedItem == null) { MessageBox.Show("ایستگاه را انتخاب کنید."); return; }
            if (string.IsNullOrWhiteSpace(txtFile.Text) || !File.Exists(txtFile.Text)) { MessageBox.Show("فایل معتبر انتخاب کنید."); return; }

            string station = cbo.SelectedItem.ToString();
            string filePath = txtFile.Text.Trim();
            string targetPath = txtTarget.Text.Trim();

            try
            {
                _comm.SendFileToStation(station, filePath, targetPath, "ارسال دستی");
                MessageBox.Show($"فایل به {station} ارسال شد.\nاندازه: {new FileInfo(filePath).Length / 1024} KB", "ارسال شد", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); }
        }

        private void RefreshCrashes(object s, EventArgs e)
        {
            try
            {
                _dgvCrashes.Rows.Clear();
                var crashes = Database.Instance.Query(
                    "SELECT crashed_at, station_name, client_version, exception_type, exception_message, last_action FROM client_crash_reports ORDER BY id DESC LIMIT 100",
                    null,
                    r => (
                        r.GetDateTime(0),
                        r.IsDBNull(1) ? "" : r.GetString(1),
                        r.IsDBNull(2) ? "" : r.GetString(2),
                        r.IsDBNull(3) ? "" : r.GetString(3),
                        r.IsDBNull(4) ? "" : r.GetString(4),
                        r.IsDBNull(5) ? "" : r.GetString(5)
                    ));
                foreach (var c in crashes)
                    _dgvCrashes.Rows.Add(c.Item1.ToLocalTime().ToString("MM-dd HH:mm:ss"), c.Item2, c.Item3, c.Item4, c.Item5, c.Item6);
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
