﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class EquipmentForm : Form
    {
        private EquipmentManager _mgr = new EquipmentManager();

        public EquipmentForm()
        {
            this.Text = "مدیریت تجهیزات"; this.Size = new Size(900, 500);
            this.BackColor = ThemeManager.BackgroundColor; this.ForeColor = Color.FromArgb(40, 40, 40);

            var dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("colId", "شناسه"); dgv.Columns["colId"].Visible = false;
            dgv.Columns.Add("colName", "نام"); dgv.Columns.Add("colStation", "ایستگاه");
            dgv.Columns.Add("colCat", "دسته"); dgv.Columns.Add("colStatus", "وضعیت");
            dgv.Columns.Add("colNotes", "یادداشت");

            var pnl = new Panel { Dock = DockStyle.Bottom, Height = 100, BackColor = Color.FromArgb(255, 255, 255), Padding = new Padding(10) };

            var txtName = new TextBox { Location = new Point(10, 30), Size = new Size(150, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "نام:", Location = new Point(10, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtName);

            var txtStation = new TextBox { Location = new Point(175, 30), Size = new Size(120, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "ایستگاه:", Location = new Point(175, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtStation);

            var txtCat = new TextBox { Location = new Point(310, 30), Size = new Size(120, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "دسته:", Location = new Point(310, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtCat);

            var btnAdd = new Button { Text = "افزودن", Location = new Point(450, 25), Size = new Size(100, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnAdd.Click += (s, e) => { try { _mgr.AddEquipment(txtName.Text, txtStation.Text, txtCat.Text); LoadEq(dgv); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            pnl.Controls.Add(btnAdd);

            var btnDelete = new Button { Text = "حذف", Location = new Point(560, 25), Size = new Size(80, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnDelete.Click += (s, e) => { if (dgv.SelectedRows.Count > 0 && MessageBox.Show("حذف؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes) { _mgr.DeleteEquipment(Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value)); LoadEq(dgv); } };
            pnl.Controls.Add(btnDelete);

            Controls.AddRange(new Control[] { dgv, pnl });
            LoadEq(dgv);
        }

        private void LoadEq(DataGridView dgv)
        {
            dgv.Rows.Clear();
            foreach (var eq in _mgr.GetAllEquipment())
                dgv.Rows.Add(eq.Id, eq.Name, eq.StationName, eq.Category, eq.Status, eq.Notes);
        }
    }
}
