using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Wait-queue management form. Lets the operator:
    ///   • Add users to the queue (pick resource type + VIP flag)
    ///   • See the live queue (waiting + called) with estimated wait times
    ///   • Call the next user when a station becomes free
    ///   • Mark a called user as served / cancel / expire
    ///   • Clear the queue at end of day
    /// Auto-refreshes every 5 seconds and auto-expires stale calls.
    /// </summary>
    public class QueueForm : Form
    {
        private readonly QueueManager _mgr = new QueueManager();
        private DataGridView _dgvWaiting, _dgvCalled;
        private Timer _timer, _expireTimer;
        private Label _lblWaitingCount, _lblCalledCount, _lblTotalToday;
        private TextBox _txtUser;
        private ComboBox _cboResource;
        private CheckBox _chkVip;
        private NotifyIcon _notifyIcon;

        public QueueForm()
        {
            this.Text = "🎟️ صف انتظار";
            this.Size = new Size(1000, 700);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshAll(null, null);

            _timer = new Timer { Interval = 5000 };
            _timer.Tick += RefreshAll;
            _timer.Start();

            // Expire stale calls every 60s
            _expireTimer = new Timer { Interval = 60000 };
            _expireTimer.Tick += (s, e) => { try { _mgr.ExpireStaleCalls(10); } catch { } };
            _expireTimer.Start();
        }

        private void BuildUi()
        {
            // === Top: stats + add panel ===
            var topPanel = new Panel { Dock = DockStyle.Top, Height = 110, BackColor = Color.FromArgb(240, 240, 240) };

            // Stats
            int sx = 15;
            _lblWaitingCount = MkStat(topPanel, ref sx, "🎟️ در انتظار", "0", Color.FromArgb(249, 226, 175));
            _lblCalledCount = MkStat(topPanel, ref sx, "📞 فراخوانی شده", "0", Color.FromArgb(137, 180, 250));
            _lblTotalToday = MkStat(topPanel, ref sx, "📊 کل امروز", "0", Color.FromArgb(166, 227, 161));

            // Add-to-queue row
            var lblUser = new Label { Text = "👤 نام کاربری:", Location = new Point(15, 60), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _txtUser = new TextBox { Location = new Point(130, 57), Size = new Size(180, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblRes = new Label { Text = "🖥️ نوع:", Location = new Point(320, 60), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _cboResource = new ComboBox { Location = new Point(370, 57), Size = new Size(120, 28), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            _cboResource.Items.AddRange(new object[] { "Any", "PC", "PS4", "PS5", "Xbox" });
            _cboResource.SelectedIndex = 0;

            _chkVip = new CheckBox { Text = "⭐ VIP", Location = new Point(500, 60), AutoSize = true, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(180, 140, 20) };

            var btnAdd = new Button { Text = "➕ افزودن به صف", Location = new Point(580, 55), Size = new Size(160, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnAdd.Click += (s, e) => AddToQueue();

            var btnClear = new Button { Text = "🧹 پاک کردن صف", Location = new Point(750, 55), Size = new Size(150, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnClear.Click += (s, e) =>
            {
                if (MessageBox.Show("پاک کردن کل صف؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    _mgr.ClearAll("پاک‌سازی دستی");
                    RefreshAll(null, null);
                }
            };

            topPanel.Controls.AddRange(new Control[] { lblUser, _txtUser, lblRes, _cboResource, _chkVip, btnAdd, btnClear });

            // === Split: waiting (left) + called (right) ===
            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 500, BackColor = Color.FromArgb(240, 240, 240) };

            // Waiting panel
            var pnlWaiting = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 240, 240) };
            var lblWaiting = new Label { Text = "🎟️ لیست انتظار (به ترتیب اولویت)", Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(240, 240, 240) };

            _dgvWaiting = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvWaiting.Columns.Add("colWId", "شناسه"); _dgvWaiting.Columns["colWId"].Visible = false;
            _dgvWaiting.Columns.Add("colWPos", "#");
            _dgvWaiting.Columns.Add("colWUser", "کاربر");
            _dgvWaiting.Columns.Add("colWRes", "نوع");
            _dgvWaiting.Columns.Add("colWVip", "VIP");
            _dgvWaiting.Columns.Add("colWEst", "انتظار تقریبی");
            _dgvWaiting.Columns.Add("colWTime", "زمان ورود");

            var btnCallNext = new Button { Text = "📞 فراخوانی نفر بعدی", Dock = DockStyle.Bottom, Height = 40, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnCallNext.Click += (s, e) => CallNextUser();
            var btnCancelWaiting = new Button { Text = "❌ لغو انتخاب‌شده", Dock = DockStyle.Bottom, Height = 35, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnCancelWaiting.Click += (s, e) => CancelSelectedWaiting();

            pnlWaiting.Controls.AddRange(new Control[] { _dgvWaiting, btnCancelWaiting, btnCallNext, lblWaiting });

            // Called panel
            var pnlCalled = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 240, 240) };
            var lblCalled = new Label { Text = "📞 فراخوانی شده (منتظر شروع نشست)", Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(240, 240, 240) };

            _dgvCalled = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvCalled.Columns.Add("colCId", "شناسه"); _dgvCalled.Columns["colCId"].Visible = false;
            _dgvCalled.Columns.Add("colCUser", "کاربر");
            _dgvCalled.Columns.Add("colCRes", "نوع");
            _dgvCalled.Columns.Add("colCTime", "زمان فراخوانی");
            _dgvCalled.Columns.Add("colCElapsed", "گذشته (دقیقه)");

            var btnServed = new Button { Text = "✅ شروع نشست (سرو شد)", Dock = DockStyle.Bottom, Height = 40, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnServed.Click += (s, e) => MarkServed();
            var btnCancelCalled = new Button { Text = "❌ لغو (بی‌پاسخ)", Dock = DockStyle.Bottom, Height = 35, BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnCancelCalled.Click += (s, e) => CancelSelectedCalled();

            pnlCalled.Controls.AddRange(new Control[] { _dgvCalled, btnCancelCalled, btnServed, lblCalled });

            split.Panel1.Controls.Add(pnlWaiting);
            split.Panel2.Controls.Add(pnlCalled);

            Controls.AddRange(new Control[] { split, topPanel });

            // Notify icon for "user called" alerts
            try
            {
                _notifyIcon = new NotifyIcon { Visible = true, Icon = SystemIcons.Information, Text = "GameNet Queue" };
            }
            catch { /* may not be available in some contexts */ }
        }

        private Label MkStat(Panel parent, ref int x, string title, string value, Color color)
        {
            var pnl = new Panel { Location = new Point(x, 8), Size = new Size(160, 44), BackColor = Color.FromArgb(230, 230, 235) };
            var lblT = new Label { Text = title, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(8, 4), AutoSize = true };
            var lblV = new Label { Text = value, Font = new Font("Segoe UI", 13F, FontStyle.Bold), ForeColor = color, Location = new Point(8, 20), AutoSize = true };
            pnl.Controls.AddRange(new Control[] { lblT, lblV });
            parent.Controls.Add(pnl);
            x += 168;
            return lblV;
        }

        private void AddToQueue()
        {
            if (string.IsNullOrWhiteSpace(_txtUser.Text)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
            try
            {
                _mgr.Enqueue(_txtUser.Text.Trim(), _cboResource.SelectedItem.ToString(), _chkVip.Checked);
                MessageBox.Show("✅ کاربر به صف اضافه شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _txtUser.Clear();
                _chkVip.Checked = false;
                RefreshAll(null, null);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void CallNextUser()
        {
            try
            {
                _mgr.CallNext(_cboResource.SelectedItem.ToString());
                RefreshAll(null, null);
                try { _notifyIcon?.ShowBalloonTip(3000, "صف انتظار", "نفر بعدی فراخوانی شد!", ToolTipIcon.Info); } catch { }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
        }

        private void CancelSelectedWaiting()
        {
            if (_dgvWaiting.SelectedRows.Count == 0) { MessageBox.Show("یک مورد انتخاب کنید."); return; }
            int id = (int)_dgvWaiting.SelectedRows[0].Cells[0].Value;
            try { _mgr.Cancel(id, "لغو توسط اپراتور"); RefreshAll(null, null); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
        }

        private void CancelSelectedCalled()
        {
            if (_dgvCalled.SelectedRows.Count == 0) { MessageBox.Show("یک مورد انتخاب کنید."); return; }
            int id = (int)_dgvCalled.SelectedRows[0].Cells[0].Value;
            try { _mgr.Cancel(id, "بی‌پاسخ"); RefreshAll(null, null); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
        }

        private void MarkServed()
        {
            if (_dgvCalled.SelectedRows.Count == 0) { MessageBox.Show("یک مورد انتخاب کنید."); return; }
            int id = (int)_dgvCalled.SelectedRows[0].Cells[0].Value;
            try { _mgr.MarkServed(id); RefreshAll(null, null); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
        }

        private void RefreshAll(object s, EventArgs e)
        {
            try
            {
                // Waiting
                _dgvWaiting.Rows.Clear();
                var waiting = _mgr.GetWaiting();
                foreach (var w in waiting)
                {
                    _dgvWaiting.Rows.Add(w.Id, w.Position, w.Username, w.ResourceType,
                        w.Vip ? "⭐ بله" : "—",
                        w.EstWaitMin > 0 ? $"~{w.EstWaitMin} دقیقه" : "نامشخص",
                        w.CreatedAt.ToLocalTime().ToString("HH:mm"));
                }
                _lblWaitingCount.Text = waiting.Count.ToString();

                // Called
                _dgvCalled.Rows.Clear();
                var called = _mgr.GetCalled();
                foreach (var c in called)
                {
                    int elapsed = (int)Math.Round((DateTime.UtcNow - c.CalledAt).TotalMinutes);
                    _dgvCalled.Rows.Add(c.Id, c.Username, c.ResourceType,
                        c.CalledAt.ToLocalTime().ToString("HH:mm"),
                        elapsed + " دقیقه");
                }
                _lblCalledCount.Text = called.Count.ToString();

                // Total today
                try
                {
                    int totalToday = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM wait_queue WHERE date(created_at) = date('now')",
                        null, r => r.GetInt32(0));
                    _lblTotalToday.Text = totalToday.ToString();
                }
                catch { _lblTotalToday.Text = "-"; }
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            _expireTimer?.Stop(); _expireTimer?.Dispose();
            try { _notifyIcon?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }
}
