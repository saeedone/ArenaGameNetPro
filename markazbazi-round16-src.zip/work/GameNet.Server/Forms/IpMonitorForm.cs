using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// IP Monitor form. Shows every connected client's IP, station name,
    /// current user, connection time, and last-heartbeat age.
    /// </summary>
    public class IpMonitorForm : Form
    {
        private ClientCommunicator _communicator;
        private DataGridView _dgv;
        private Button _btnRefresh;
        private Label _lblCount;
        private Timer _autoRefresh;

        public IpMonitorForm(ClientCommunicator communicator)
        {
            _communicator = communicator;

            this.Text = "مانیتور IP - GameNet";
            this.Size = new Size(900, 540);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            int y = 12;

            _btnRefresh = new Button
            {
                Text = "🔄 بروزرسانی", Location = new Point(20, y), Size = new Size(140, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnRefresh.Click += (s, e) => LoadConnections();

            _lblCount = new Label
            {
                Location = new Point(180, y + 6), AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
            };

            y += 44;

            _dgv = new DataGridView
            {
                Location = new Point(20, y),
                Size = new Size(840, 430),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 24 },
            };
            _dgv.Columns.Add("colIp", "IP");
            _dgv.Columns.Add("colMac", "MAC / Machine");
            _dgv.Columns.Add("colStation", "ایستگاه");
            _dgv.Columns.Add("colUser", "کاربر");
            _dgv.Columns.Add("colConn", "زمان اتصال");
            _dgv.Columns.Add("colHeartbeat", "Heartbeat");
            _dgv.Columns.Add("colState", "وضعیت");

            Controls.AddRange(new Control[] { _btnRefresh, _lblCount, _dgv });

            _autoRefresh = new Timer { Interval = 2000 };
            _autoRefresh.Tick += (s, e) => LoadConnections();
            _autoRefresh.Start();

            this.FormClosing += (s, e) => { try { _autoRefresh.Stop(); } catch { } };

            LoadConnections();
        }

        private void LoadConnections()
        {
            _dgv.Rows.Clear();
            if (_communicator == null)
            {
                _lblCount.Text = "ارتباط برقرار نیست";
                return;
            }

            try
            {
                var conns = _communicator.GetAllRawConnections();
                foreach (var c in conns)
                {
                    var hbAge = DateTime.UtcNow - c.LastHeartbeat;
                    string hb = hbAge.TotalSeconds < 60 ? $"{(int)hbAge.TotalSeconds}s ago" : $"{(int)hbAge.TotalMinutes}m ago";
                    string state = c.State.ToString();
                    string mac = c.OsVersion ?? "—"; // OsVersion slot is the closest we have to a MAC column in the tuple; fall back to "—"
                    _dgv.Rows.Add(c.ClientIp, mac, c.StationName, c.User, c.ConnectedAt.ToLocalTime().ToString("HH:mm:ss"), hb, state);

                    // Color-code: red if heartbeat is stale, green if active user.
                    int idx = _dgv.Rows.Count - 1;
                    if (hbAge > TimeSpan.FromSeconds(90))
                        _dgv.Rows[idx].DefaultCellStyle.ForeColor = Color.FromArgb(200, 30, 60);
                    else if (!string.IsNullOrEmpty(c.User) && c.User != "-")
                        _dgv.Rows[idx].DefaultCellStyle.ForeColor = Color.FromArgb(20, 130, 50);
                }
                _lblCount.Text = $"کلاینت‌های متصل: {conns.Count}";
            }
            catch (Exception ex)
            {
                _lblCount.Text = "خطا در بارگذاری";
                AuditLog.Log("IpMonitorForm", "Load error: " + ex.Message);
            }
        }
    }
}
