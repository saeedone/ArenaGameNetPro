﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class PricingForm : Form
    {
        private PricingManager _mgr = new PricingManager();
        private DataGridView dgv;

        public PricingForm()
        {
            this.Text = "مدیریت تعرفه‌ها"; this.Size = new Size(700, 500);
            this.BackColor = ThemeManager.BackgroundColor; this.ForeColor = Color.FromArgb(40, 40, 40);

            dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("colId", "شناسه"); dgv.Columns["colId"].Visible = false;
            dgv.Columns.Add("colName", "نام"); dgv.Columns.Add("colPrice", "قیمت ساعتی (تومان)");
            dgv.Columns.Add("colMin", "حداقل هزینه"); dgv.Columns.Add("colRound", "رند کردن (دقیقه)");
            dgv.Columns.Add("colDefault", "پیش‌فرض");

            var pnl = new Panel { Dock = DockStyle.Bottom, Height = 200, BackColor = Color.FromArgb(255, 255, 255), Padding = new Padding(15) };

            var txtName = new TextBox { Location = new Point(15, 30), Size = new Size(200, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "نام تعرفه:", Location = new Point(15, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtName);

            var txtPrice = new TextBox { Location = new Point(230, 30), Size = new Size(150, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "15000" };
            pnl.Controls.Add(new Label { Text = "قیمت ساعتی:", Location = new Point(230, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtPrice);

            var txtMin = new TextBox { Location = new Point(395, 30), Size = new Size(120, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "2500" };
            pnl.Controls.Add(new Label { Text = "حداقل هزینه:", Location = new Point(395, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtMin);

            var txtRound = new TextBox { Location = new Point(530, 30), Size = new Size(100, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "10" };
            pnl.Controls.Add(new Label { Text = "رند (دقیقه):", Location = new Point(530, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtRound);

            var btnCreate = new Button { Text = "ایجاد تعرفه", Location = new Point(15, 70), Size = new Size(150, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnCreate.Click += (s, e) => { try { _mgr.CreatePlan(txtName.Text, decimal.Parse(txtPrice.Text), decimal.Parse(txtMin.Text), int.Parse(txtRound.Text)); LoadPlans(); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            pnl.Controls.Add(btnCreate);

            var btnDefault = new Button { Text = "تنظیم پیش‌فرض", Location = new Point(180, 70), Size = new Size(150, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnDefault.Click += (s, e) => { if (dgv.SelectedRows.Count > 0) { _mgr.SetDefaultPlan(Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value)); LoadPlans(); } };
            pnl.Controls.Add(btnDefault);

            var btnDelete = new Button { Text = "حذف", Location = new Point(345, 70), Size = new Size(100, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnDelete.Click += (s, e) => { if (dgv.SelectedRows.Count > 0 && MessageBox.Show("حذف؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes) try { _mgr.DeletePlan(Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value)); LoadPlans(); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            pnl.Controls.Add(btnDelete);

            Controls.AddRange(new Control[] { dgv, pnl });
            LoadPlans();
        }

        private void LoadPlans()
        {
            dgv.Rows.Clear();
            foreach (var p in _mgr.GetAllPlans())
                dgv.Rows.Add(p.Id, p.Name, p.PricePerHour.ToString("N0"), p.MinimumCharge.ToString("N0"), p.RoundingMinutes, p.IsDefault ? "✓" : "");
        }
    }
}
