using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Live revenue dashboard with custom-drawn bar + line charts (no
    /// external charting dependency). Shows:
    ///   • Today's hourly revenue (bar chart, 24 bars)
    ///   • Last 7 days daily revenue (line chart)
    ///   • Last 30 days daily revenue (bar chart)
    ///   • Top 5 games by revenue
    ///   • Top 5 users by spend
    /// Auto-refreshes every 60 seconds.
    /// </summary>
    public class RevenueChartForm : Form
    {
        private Timer _timer;
        private TabControl _tabs;
        private ChartCanvas _hourlyChart, _weeklyChart, _monthlyChart;
        private ListView _lvTopGames, _lvTopUsers;
        private Label _lblTotalDay, _lblTotalWeek, _lblTotalMonth, _lblAvgSession;

        public RevenueChartForm()
        {
            this.Text = "📈 نمودار درآمد زنده";
            this.Size = new Size(1100, 700);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshAll(null, null);
            _timer = new Timer { Interval = 60000 };
            _timer.Tick += RefreshAll;
            _timer.Start();
        }

        private void BuildUi()
        {
            // Top stats bar
            var statsBar = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.FromArgb(240, 240, 240) };
            int sx = 15;
            _lblTotalDay = MkStat(statsBar, ref sx, "💰 درآمد امروز", "0 ت", Color.FromArgb(166, 227, 161));
            _lblTotalWeek = MkStat(statsBar, ref sx, "📅 درآمد هفته", "0 ت", Color.FromArgb(137, 180, 250));
            _lblTotalMonth = MkStat(statsBar, ref sx, "🗓️ درآمد ماه", "0 ت", Color.FromArgb(249, 226, 175));
            _lblAvgSession = MkStat(statsBar, ref sx, "⏱️ میانگین جلسه", "0 دقیقه", Color.FromArgb(203, 166, 247));

            // Tabbed charts
            _tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9F) };

            var tabHourly = new TabPage("📊 ساعتی (امروز)") { BackColor = Color.FromArgb(240, 240, 240) };
            _hourlyChart = new ChartCanvas { Dock = DockStyle.Fill, Title = "درآمد ساعتی امروز", ChartColor = Color.FromArgb(137, 180, 250) };
            tabHourly.Controls.Add(_hourlyChart);

            var tabWeekly = new TabPage("📈 هفتگی (۷ روز)") { BackColor = Color.FromArgb(240, 240, 240) };
            _weeklyChart = new ChartCanvas { Dock = DockStyle.Fill, Title = "درآمد ۷ روز اخیر", ChartColor = Color.FromArgb(166, 227, 161), IsLine = true };
            tabWeekly.Controls.Add(_weeklyChart);

            var tabMonthly = new TabPage("📊 ماهانه (۳۰ روز)") { BackColor = Color.FromArgb(240, 240, 240) };
            _monthlyChart = new ChartCanvas { Dock = DockStyle.Fill, Title = "درآمد ۳۰ روز اخیر", ChartColor = Color.FromArgb(249, 226, 175) };
            tabMonthly.Controls.Add(_monthlyChart);

            var tabTop = new TabPage("🏆 برترین‌ها") { BackColor = Color.FromArgb(240, 240, 240) };
            var split = new SplitContainer { Dock = DockStyle.Fill, SplitterDistance = 500, BackColor = Color.FromArgb(240, 240, 240) };
            _lvTopGames = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40) };
            _lvTopGames.Columns.Add("بازی", 250);
            _lvTopGames.Columns.Add("درآمد (تومان)", 150);
            _lvTopGames.Columns.Add("تعداد جلسات", 100);
            _lvTopUsers = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40) };
            _lvTopUsers.Columns.Add("کاربر", 200);
            _lvTopUsers.Columns.Add("مجموع هزینه (تومان)", 180);
            _lvTopUsers.Columns.Add("تعداد جلسات", 100);
            var lblGames = new Label { Text = "🎮 برترین بازی‌ها", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Dock = DockStyle.Top, Height = 30, TextAlign = ContentAlignment.MiddleCenter };
            var lblUsers = new Label { Text = "👤 برترین کاربران", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50), Dock = DockStyle.Top, Height = 30, TextAlign = ContentAlignment.MiddleCenter };
            split.Panel1.Controls.AddRange(new Control[] { _lvTopGames, lblGames });
            split.Panel2.Controls.AddRange(new Control[] { _lvTopUsers, lblUsers });
            tabTop.Controls.Add(split);

            _tabs.TabPages.AddRange(new TabPage[] { tabHourly, tabWeekly, tabMonthly, tabTop });

            Controls.AddRange(new Control[] { _tabs, statsBar });
        }

        private Label MkStat(Panel parent, ref int x, string title, string value, Color color)
        {
            var pnl = new Panel { Location = new Point(x, 8), Size = new Size(180, 54), BackColor = Color.FromArgb(230, 230, 235) };
            var lblT = new Label { Text = title, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(8, 4), AutoSize = true };
            var lblV = new Label { Text = value, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = color, Location = new Point(8, 22), AutoSize = true };
            pnl.Controls.AddRange(new Control[] { lblT, lblV });
            parent.Controls.Add(pnl);
            x += 188;
            return lblV;
        }

        private void RefreshAll(object s, EventArgs e)
        {
            try
            {
                // Hourly today
                var hourly = GetHourlyRevenue();
                _hourlyChart.SetData(hourly.Select(h => (double)h.Revenue).ToArray(),
                    hourly.Select(h => h.Hour.ToString("00")).ToArray(), "تومان");

                // Weekly (7 days)
                var weekly = GetDailyRevenue(7);
                _weeklyChart.SetData(weekly.Select(d => (double)d.Revenue).ToArray(),
                    weekly.Select(d => d.Date.ToString("MM-dd")).ToArray(), "تومان");

                // Monthly (30 days)
                var monthly = GetDailyRevenue(30);
                _monthlyChart.SetData(monthly.Select(d => (double)d.Revenue).ToArray(),
                    monthly.Select(d => d.Date.ToString("MM-dd")).ToArray(), "تومان");

                // Top games & users
                LoadTopGames();
                LoadTopUsers();

                // Stats
                decimal totalDay = hourly.Sum(h => h.Revenue);
                decimal totalWeek = weekly.Sum(d => d.Revenue);
                decimal totalMonth = monthly.Sum(d => d.Revenue);
                _lblTotalDay.Text = totalDay.ToString("N0") + " ت";
                _lblTotalWeek.Text = totalWeek.ToString("N0") + " ت";
                _lblTotalMonth.Text = totalMonth.ToString("N0") + " ت";

                try
                {
                    var avgMin = Database.Instance.QueryOne("SELECT AVG(duration_minutes) FROM client_sessions WHERE end_time IS NOT NULL AND duration_minutes > 0 AND end_time > @c", cmd => cmd.Parameters.AddWithValue("@c", DateTime.UtcNow.AddDays(-1).ToString("o")), r => r.IsDBNull(0) ? 0 : Math.Round(r.GetDouble(0)));
                    _lblAvgSession.Text = avgMin + " دقیقه";
                }
                catch { _lblAvgSession.Text = "-"; }
            }
            catch (Exception ex) { AuditLog.Log("RevenueChart", "Refresh error: " + ex.Message); }
        }

        private List<(int Hour, decimal Revenue)> GetHourlyRevenue()
        {
            var result = new List<(int, decimal)>();
            try
            {
                var today = DateTime.Today;
                var rows = Database.Instance.Query(
                    "SELECT strftime('%H', start_time) as hr, SUM(total_cost) as rev FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @ts GROUP BY hr ORDER BY hr",
                    cmd => cmd.Parameters.AddWithValue("@ts", today.ToString("o")),
                    r => (Hour: int.Parse(r.GetString(0)), Revenue: r.IsDBNull(1) ? 0m : r.GetDecimal(1)));
                // Fill all 24 hours
                for (int h = 0; h < 24; h++)
                {
                    var row = rows.FirstOrDefault(x => x.Hour == h);
                    result.Add((h, row.Revenue));
                }
            }
            catch { for (int h = 0; h < 24; h++) result.Add((h, 0)); }
            return result;
        }

        private List<(DateTime Date, decimal Revenue)> GetDailyRevenue(int days)
        {
            var result = new List<(DateTime, decimal)>();
            try
            {
                var start = DateTime.Today.AddDays(-days + 1);
                var rows = Database.Instance.Query(
                    "SELECT date(start_time) as dt, SUM(total_cost) as rev FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @ts GROUP BY dt ORDER BY dt",
                    cmd => cmd.Parameters.AddWithValue("@ts", start.ToString("o")),
                    r => (Date: DateTime.Parse(r.GetString(0)), Revenue: r.IsDBNull(1) ? 0m : r.GetDecimal(1)));
                for (int i = 0; i < days; i++)
                {
                    var date = start.AddDays(i);
                    var row = rows.FirstOrDefault(x => x.Date.Date == date.Date);
                    result.Add((date, row.Revenue));
                }
            }
            catch { for (int i = 0; i < days; i++) result.Add((DateTime.Today.AddDays(-days + 1 + i), 0)); }
            return result;
        }

        private void LoadTopGames()
        {
            try
            {
                _lvTopGames.Items.Clear();
                var rows = Database.Instance.Query(
                    "SELECT current_game, SUM(total_cost) as rev, COUNT(*) as cnt FROM client_sessions WHERE end_time IS NOT NULL AND current_game != '' AND start_time >= @ts GROUP BY current_game ORDER BY rev DESC LIMIT 5",
                    cmd => cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.AddDays(-30).ToString("o")),
                    r => new ListViewItem(new[] { r.GetString(0), r.IsDBNull(1) ? "0" : r.GetDecimal(1).ToString("N0"), r.GetInt32(2).ToString() }));
                foreach (var item in rows) _lvTopGames.Items.Add(item);
            }
            catch { }
        }

        private void LoadTopUsers()
        {
            try
            {
                _lvTopUsers.Items.Clear();
                var rows = Database.Instance.Query(
                    "SELECT username, SUM(total_cost) as rev, COUNT(*) as cnt FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @ts GROUP BY username ORDER BY rev DESC LIMIT 5",
                    cmd => cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.AddDays(-30).ToString("o")),
                    r => new ListViewItem(new[] { r.GetString(0), r.IsDBNull(1) ? "0" : r.GetDecimal(1).ToString("N0"), r.GetInt32(2).ToString() }));
                foreach (var item in rows) _lvTopUsers.Items.Add(item);
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }

    /// <summary>
    /// Lightweight custom chart canvas — draws either a bar chart or a line
    /// chart from a double[] + string[] labels. No external dependencies.
    /// </summary>
    internal class ChartCanvas : Control
    {
        private double[] _values = new double[0];
        private string[] _labels = new string[0];
        private string _yAxisLabel = "";
        public string Title = "";
        public Color ChartColor = Color.FromArgb(137, 180, 250);
        public bool IsLine = false;

        public ChartCanvas()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.BackColor = ThemeManager.BackgroundColor;
        }

        public void SetData(double[] values, string[] labels, string yAxisLabel = "")
        {
            _values = values ?? new double[0];
            _labels = labels ?? new string[0];
            _yAxisLabel = yAxisLabel ?? "";
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Title
            if (!string.IsNullOrEmpty(Title))
                g.DrawString(Title, new Font("Segoe UI", 12F, FontStyle.Bold), new SolidBrush(Color.FromArgb(137, 180, 250)), 20, 10);

            if (_values.Length == 0)
            {
                g.DrawString("داده‌ای موجود نیست", new Font("Segoe UI", 10F), new SolidBrush(Color.FromArgb(148, 226, 213)), 20, 50);
                return;
            }

            // Chart area
            int left = 60, top = 50, right = 20, bottom = 50;
            int cw = this.Width - left - right;
            int ch = this.Height - top - bottom;
            if (cw < 50 || ch < 50) return;

            double max = _values.Length > 0 ? _values.Max() : 0;
            if (max <= 0) max = 1;

            // Y axis grid (4 lines)
            var gridPen = new Pen(Color.FromArgb(50, 50, 70), 1) { DashStyle = DashStyle.Dot };
            var axisBrush = new SolidBrush(Color.FromArgb(148, 226, 213));
            var axisFont = new Font("Segoe UI", 8F);
            for (int i = 0; i <= 4; i++)
            {
                double val = max * (4 - i) / 4;
                int y = top + (ch * i / 4);
                g.DrawLine(gridPen, left, y, left + cw, y);
                g.DrawString(FormatValue(val), axisFont, axisBrush, 5, y - 8);
            }

            // X axis labels + bars/line
            int n = _values.Length;
            int barWidth = n > 0 ? cw / n : cw;

            if (IsLine)
            {
                // Line chart
                var pts = new List<PointF>();
                for (int i = 0; i < n; i++)
                {
                    float x = left + (n == 1 ? cw / 2 : (cw * i / (n - 1)));
                    float y = top + ch - (float)(_values[i] / max * ch);
                    pts.Add(new PointF(x, y));
                }
                if (pts.Count > 1)
                {
                    g.DrawLines(new Pen(ChartColor, 2), pts.ToArray());
                    foreach (var p in pts)
                    {
                        g.FillEllipse(new SolidBrush(ChartColor), p.X - 3, p.Y - 3, 6, 6);
                    }
                }
            }
            else
            {
                // Bar chart
                var barBrush = new SolidBrush(Color.FromArgb(ChartColor.R, ChartColor.G, ChartColor.B));
                var barBrushLight = new SolidBrush(Color.FromArgb(Math.Min(255, ChartColor.R + 30), Math.Min(255, ChartColor.G + 30), Math.Min(255, ChartColor.B + 30)));
                for (int i = 0; i < n; i++)
                {
                    int bh = (int)(_values[i] / max * ch);
                    if (bh <= 0) continue;
                    int bx = left + i * barWidth + 2;
                    int by = top + ch - bh;
                    int bw = Math.Max(2, barWidth - 4);
                    g.FillRectangle(barBrush, bx, by, bw, bh);
                    // Top highlight
                    g.FillRectangle(barBrushLight, bx, by, bw, 2);
                }
            }

            // X labels
            var labelBrush = new SolidBrush(Color.FromArgb(40, 40, 40));
            int labelEvery = Math.Max(1, n / 12); // show ~12 labels max
            for (int i = 0; i < n; i += labelEvery)
            {
                int x = left + i * barWidth + barWidth / 2;
                string label = i < _labels.Length ? _labels[i] : "";
                var sz = g.MeasureString(label, axisFont);
                g.DrawString(label, axisFont, labelBrush, x - sz.Width / 2, top + ch + 5);
            }
        }

        private string FormatValue(double v)
        {
            if (v >= 1000000) return (v / 1000000).ToString("0.0") + "M";
            if (v >= 1000) return (v / 1000).ToString("0") + "k";
            return v.ToString("0");
        }
    }
}
