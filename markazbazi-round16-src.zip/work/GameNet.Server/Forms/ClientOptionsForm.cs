using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using GameNet.Server.Core;
using Newtonsoft.Json;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// HandyCafe-style client configuration form. Lets the operator edit the
    /// settings the client kiosk uses (admin credentials, server host, mode
    /// toggles, network adapter / port, sound events, advanced timeouts,
    /// language). Persists to client_options.json next to the server exe.
    ///
    /// Tabs:
    ///   1. General  — admin username/password (with repeat), server IP,
    ///                 auto-connect, uninstall-client button.
    ///   2. Options  — 9 client-side behaviour toggles (shutdown, PC name,
    ///                 ordering, restart-after-payment, hide times/cost...).
    ///   3. Network  — adapter combo, server port, UDP port, TLS checkbox.
    ///   4. Event    — three sound events (login / timer-end / order) each
    ///                 with a checkbox + TextBox + Browse button.
    ///   5. Advanced — heartbeat interval, connect timeout, reconnect retries,
    ///                 drag-to-move, screensaver enable + delay.
    ///   6. Language — combo (فارسی / English / العربية).
    /// </summary>
    public class ClientOptionsForm : Form
    {
        // === Theme palette ===
        private static readonly Color _bg     = Color.FromArgb(240, 240, 240);
        private static readonly Color _panel  = Color.FromArgb(230, 230, 235);
        private static readonly Color _input  = Color.FromArgb(220, 220, 225);
        private static readonly Color _fg     = Color.FromArgb(40, 40, 40);
        private static readonly Color _accent = Color.FromArgb(137, 180, 250);
        private static readonly Color _muted  = Color.FromArgb(148, 226, 213);
        private static readonly Color _ok     = Color.FromArgb(166, 227, 161);
        private static readonly Color _warn   = Color.FromArgb(249, 226, 175);
        private static readonly Color _danger = Color.FromArgb(243, 139, 168);
        private static readonly Font  _f      = new Font("Segoe UI", 9F);
        private static readonly Font  _fb     = new Font("Segoe UI", 9F, FontStyle.Bold);
        private static readonly Font  _fh     = new Font("Segoe UI", 11F, FontStyle.Bold);

        private readonly string _savePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client_options.json");

        private ClientOptionsData _data;

        // === General tab controls ===
        private TextBox _txtAdminUser, _txtAdminPass, _txtAdminPass2, _txtServerIp;
        private CheckBox _chkAuto;

        // === Options tab checkboxes (9) ===
        private readonly List<CheckBox> _optChks = new List<CheckBox>();

        // === Network tab controls ===
        private ComboBox _cboAdapter;
        private NumericUpDown _numPort, _numUdp;
        private CheckBox _chkTls;

        // === Event tab controls (3 sound events) ===
        private readonly List<CheckBox> _evtChks = new List<CheckBox>();
        private readonly List<TextBox>  _evtTxts = new List<TextBox>();

        // === Advanced tab controls ===
        private NumericUpDown _numHeartbeat, _numTimeout, _numReconnect, _numScreensaver;
        private CheckBox _chkDrag, _chkScreensaver;

        // === Language tab controls ===
        private ComboBox _cboLang;

        // === Reflection-friendly property keys ===
        private static readonly string[] _optKeys =
        {
            "DisableWindowsShutdown",
            "ShowPcNameOnScreen",
            "EnableClientOrdering",
            "CloseAppsOnLogout",
            "RestartAfterPayment",
            "ShutdownAfterPayment",
            "HideRemainingTime",
            "HideStartTime",
            "HideCost"
        };
        private static readonly string[] _optLabels =
        {
            "□ غیرفعال‌سازی خاموش ویندوز",
            "□ نمایش نام PC روی صفحه",
            "□ فعال‌سازی سفارش از کلاینت",
            "□ بستن برنامه‌ها هنگام خروج",
            "□ ری‌استارت پس از پرداخت",
            "□ خاموش پس از پرداخت",
            "□ مخفی زمان باقی‌مانده",
            "□ مخفی زمان شروع",
            "□ مخفی هزینه"
        };

        private static readonly string[] _evtKeys =
        {
            "SoundOnLoginRequest",
            "SoundOnTimerEnd",
            "SoundOnOrder"
        };
        private static readonly string[] _evtLabels =
        {
            "□ پخش صدا هنگام درخواست ورود",
            "□ پخش صدا هنگام اتمام تایمر",
            "□ پخش صدا هنگام سفارش"
        };

        public ClientOptionsForm()
        {
            this.Text = "💻 تنظیمات کلاینت - Client Options";
            this.Size = new Size(820, 660);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = _bg;
            this.ForeColor = _fg;
            this.RightToLeft = RightToLeft.Yes;
            this.MinimumSize = new Size(760, 600);

            _data = LoadData();

            BuildUi();
        }

        // ----------------------------------------------------------------
        //  UI construction
        // ----------------------------------------------------------------
        private void BuildUi()
        {
            var lblHeader = new Label
            {
                Text = "💻 تنظیمات نرم‌افزار کلاینت",
                Font = _fh,
                ForeColor = _accent,
                Dock = DockStyle.Top,
                Height = 36,
                TextAlign = ContentAlignment.MiddleCenter,
            };

            var tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = _f,
                Appearance = TabAppearance.Normal,
                Padding = new Point(14, 8),
            };
            StyleTabControl(tabs);

            tabs.TabPages.Add(BuildGeneralTab());
            tabs.TabPages.Add(BuildOptionsTab());
            tabs.TabPages.Add(BuildNetworkTab());
            tabs.TabPages.Add(BuildEventTab());
            tabs.TabPages.Add(BuildAdvancedTab());
            tabs.TabPages.Add(BuildLanguageTab());

            var btnBar = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = _panel,
                Padding = new Padding(10, 8, 10, 8),
            };

            var btnCancel = new Button
            {
                Text = "انصراف",
                Size = new Size(110, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _danger,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
                DialogResult = DialogResult.Cancel,
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            var btnOk = new Button
            {
                Text = "✓ تایید",
                Size = new Size(110, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _ok,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
                DialogResult = DialogResult.OK,
            };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => Save();

            btnOk.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnCancel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnBar.Controls.AddRange(new Control[] { btnCancel, btnOk });
            btnBar.Layout += (s, e) =>
            {
                btnOk.Location = new Point(btnBar.Width - 10 - 110, 8);
                btnCancel.Location = new Point(btnOk.Left - 10 - 110, 8);
            };

            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;

            this.Controls.Clear();
            this.Controls.Add(tabs);
            this.Controls.Add(btnBar);
            this.Controls.Add(lblHeader);
            lblHeader.SendToBack();
        }

        private void StyleTabControl(TabControl tc)
        {
            tc.DrawMode = TabDrawMode.OwnerDrawFixed;
            tc.DrawItem += (s, e) =>
            {
                var g = e.Graphics;
                var tab = tc.TabPages[e.Index];
                bool sel = e.Index == tc.SelectedIndex;
                var bg = sel ? _input : _panel;
                var fg = sel ? _accent : _fg;
                using (var b = new SolidBrush(bg))
                    g.FillRectangle(b, e.Bounds);
                if (sel)
                    using (var p = new Pen(_accent, 3))
                        g.DrawLine(p, e.Bounds.Left, e.Bounds.Top, e.Bounds.Right, e.Bounds.Top);
                var sf = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center,
                    FormatFlags = StringFormatFlags.DirectionRightToLeft
                };
                using (var br = new SolidBrush(fg))
                    g.DrawString(tab.Text, sel ? _fb : _f, br, e.Bounds, sf);
            };
        }

        // ----------------------------------------------------------------
        //  Tab 1: General
        // ----------------------------------------------------------------
        private TabPage BuildGeneralTab()
        {
            var page = NewTab("📋 عمومی");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            int y = 12;
            host.Controls.Add(MkLabel("نام کاربری ادمین:", 12, y, _fg, _fb)); y += 22;
            _txtAdminUser = MkTextBox(12, y, 380, _data.AdminUsername ?? "ADMIN");
            host.Controls.Add(_txtAdminUser); y += 36;

            host.Controls.Add(MkLabel("رمز عبور ادمین:", 12, y, _fg, _fb)); y += 22;
            _txtAdminPass = MkTextBox(12, y, 380, _data.AdminPassword ?? "", true);
            host.Controls.Add(_txtAdminPass); y += 36;

            host.Controls.Add(MkLabel("تکرار رمز عبور:", 12, y, _fg, _fb)); y += 22;
            _txtAdminPass2 = MkTextBox(12, y, 380, _data.AdminPassword ?? "", true);
            host.Controls.Add(_txtAdminPass2); y += 36;

            host.Controls.Add(MkLabel("IP/Host سرور:", 12, y, _fg, _fb)); y += 22;
            _txtServerIp = MkTextBox(12, y, 380, _data.ServerIp ?? "127.0.0.1");
            host.Controls.Add(_txtServerIp); y += 36;

            _chkAuto = new CheckBox
            {
                Text = "□ خودکار (اتصال خودکار به سرور)",
                Font = _f,
                ForeColor = _fg,
                BackColor = _panel,
                Location = new Point(12, y),
                AutoSize = false,
                Size = new Size(380, 26),
                Checked = _data.AutoConnect,
                CheckAlign = ContentAlignment.MiddleLeft,
                TextAlign = ContentAlignment.MiddleLeft,
            };
            _chkAuto.CheckedChanged += (s, e) => _data.AutoConnect = _chkAuto.Checked;
            host.Controls.Add(_chkAuto); y += 40;

            var btnUninstall = new Button
            {
                Text = "🗑️ حذف کلاینت",
                Location = new Point(12, y),
                Size = new Size(160, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _danger,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
            };
            btnUninstall.FlatAppearance.BorderSize = 0;
            btnUninstall.Click += (s, e) =>
            {
                if (MessageBox.Show(
                        "⚠️ این تنظیمات یک سفارش حذف کلاینت به ایستگاه‌های متصل ارسال می‌کند.\n" +
                        "نرم‌افزار کلاینت باید به‌صورت دستی از روی هر دستگاه حذف شود.\n\nادامه؟",
                        "حذف کلاینت", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                    == DialogResult.Yes)
                {
                    try { AuditLog.Log("ClientOptions", "Uninstall-client order requested from ClientOptionsForm"); } catch { }
                    MessageBox.Show("✅ سفارش حذف کلاینت در لاگ ثبت شد.", "ارسال شد",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };
            host.Controls.Add(btnUninstall);

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 2: Options — 9 behaviour toggles
        // ----------------------------------------------------------------
        private TabPage BuildOptionsTab()
        {
            var page = NewTab("⚙️ Options");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            int y = 12;
            for (int i = 0; i < _optKeys.Length; i++)
            {
                var cb = new CheckBox
                {
                    Text = _optLabels[i],
                    Tag = _optKeys[i],
                    AutoSize = false,
                    Size = new Size(720, 26),
                    Location = new Point(12, y),
                    Font = _f,
                    ForeColor = _fg,
                    BackColor = _panel,
                    Checked = GetBool(_data, _optKeys[i]),
                    CheckAlign = ContentAlignment.MiddleLeft,
                    TextAlign = ContentAlignment.MiddleLeft,
                };
                cb.CheckedChanged += (s, e) => SetBool(_data, _optKeys[i], cb.Checked);
                _optChks.Add(cb);
                host.Controls.Add(cb);
                y += 30;
            }

            host.Controls.Add(MkLabel(
                "ℹ️ این تنظیمات رفتار نرم‌افزار کلاینت را روی هر ایستگاه کنترل می‌کنند.",
                12, y + 4, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 3: Network — adapter / ports / TLS
        // ----------------------------------------------------------------
        private TabPage BuildNetworkTab()
        {
            var page = NewTab("🌐 Network");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            int y = 12;
            host.Controls.Add(MkLabel("آداپتور شبکه:", 12, y, _fg, _fb)); y += 22;
            _cboAdapter = new ComboBox
            {
                Location = new Point(12, y),
                Size = new Size(380, 28),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat,
                BackColor = _input,
                ForeColor = _fg,
                Font = _f,
            };
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus == OperationalStatus.Up &&
                        ni.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                        _cboAdapter.Items.Add(ni.Name);
                }
            }
            catch { }
            if (_cboAdapter.Items.Count == 0) _cboAdapter.Items.Add("(پیش‌فرض)");
            if (!string.IsNullOrEmpty(_data.NetworkAdapter) && _cboAdapter.Items.Contains(_data.NetworkAdapter))
                _cboAdapter.SelectedItem = _data.NetworkAdapter;
            else if (_cboAdapter.Items.Count > 0)
                _cboAdapter.SelectedIndex = 0;
            host.Controls.Add(_cboAdapter); y += 36;

            host.Controls.Add(MkLabel("پورت سرور:", 12, y, _fg, _fb)); y += 22;
            _numPort = MkNumeric(12, y, 9090, 1, 65535, _data.ServerPort);
            host.Controls.Add(_numPort); y += 36;

            host.Controls.Add(MkLabel("پورت UDP:", 12, y, _fg, _fb)); y += 22;
            _numUdp = MkNumeric(12, y, 9091, 1, 65535, _data.UdpPort);
            host.Controls.Add(_numUdp); y += 36;

            _chkTls = new CheckBox
            {
                // BUG FIX: this checkbox saved to _data.UseTls (part of
                // ClientOptionsData / client_options.json), but the client's
                // actual connection code (ConnectionSettings.UseTls) reads
                // its TLS setting from a completely different file
                // (server_settings.txt), only changeable via a LOCAL dialog
                // on the client machine itself. This checkbox did nothing —
                // an operator could enable it here, see no error, and
                // reasonably assume TLS was now active, when nothing had
                // actually changed on the client at all. Relabeled to state
                // that plainly rather than silently leaving it misleading.
                Text = "□ استفاده از TLS (⚠️ این گزینه فقط محلی روی کلاینت قابل تنظیم است — این چک‌باکس اثری روی کلاینت واقعی ندارد)",
                Font = _f,
                ForeColor = _fg,
                BackColor = _panel,
                Location = new Point(12, y),
                AutoSize = false,
                Size = new Size(560, 40),
                Checked = _data.UseTls,
                CheckAlign = ContentAlignment.MiddleLeft,
                TextAlign = ContentAlignment.MiddleLeft,
            };
            _chkTls.CheckedChanged += (s, e) => _data.UseTls = _chkTls.Checked;
            host.Controls.Add(_chkTls);

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 4: Event — three sound events with checkbox + path + Browse
        // ----------------------------------------------------------------
        private TabPage BuildEventTab()
        {
            var page = NewTab("🔔 Event");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            int y = 12;
            for (int i = 0; i < _evtKeys.Length; i++)
            {
                var cb = new CheckBox
                {
                    Text = _evtLabels[i],
                    Tag = _evtKeys[i],
                    AutoSize = false,
                    Size = new Size(720, 26),
                    Location = new Point(12, y),
                    Font = _f,
                    ForeColor = _fg,
                    BackColor = _panel,
                    Checked = GetBool(_data, _evtKeys[i]),
                    CheckAlign = ContentAlignment.MiddleLeft,
                    TextAlign = ContentAlignment.MiddleLeft,
                };
                var key = _evtKeys[i];
                cb.CheckedChanged += (s, e) => SetBool(_data, key, cb.Checked);
                _evtChks.Add(cb);
                host.Controls.Add(cb);
                y += 30;

                var txt = MkTextBox(12, y, 540,
                    i == 0 ? _data.SoundOnLoginRequestPath :
                    i == 1 ? _data.SoundOnTimerEndPath :
                             _data.SoundOnOrderPath);
                _evtTxts.Add(txt);
                host.Controls.Add(txt);

                var btnBrowse = new Button
                {
                    Text = "📁 ...",
                    Location = new Point(560, y - 2),
                    Size = new Size(60, 28),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = _accent,
                    ForeColor = _bg,
                    Font = _fb,
                    Cursor = Cursors.Hand,
                };
                btnBrowse.FlatAppearance.BorderSize = 0;
                var idx = i;
                btnBrowse.Click += (s, e) =>
                {
                    using (var dlg = new OpenFileDialog
                    {
                        Filter = "Audio files|*.wav;*.mp3|All files|*.*",
                        Title = "انتخاب فایل صوتی"
                    })
                    {
                        if (dlg.ShowDialog() == DialogResult.OK)
                            txt.Text = dlg.FileName;
                    }
                };
                host.Controls.Add(btnBrowse);
                y += 38;
            }

            host.Controls.Add(MkLabel(
                "ℹ️ فایل صوتی باید روی کلاینت قابل دسترس باشد (یا از مسیر نسبی استفاده شود).",
                12, y + 4, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 5: Advanced
        // ----------------------------------------------------------------
        private TabPage BuildAdvancedTab()
        {
            var page = NewTab("🛠️ Advanced");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            int y = 12;
            host.Controls.Add(MkLabel("فاصله heartbeat (ثانیه):", 12, y, _fg, _fb)); y += 22;
            _numHeartbeat = MkNumeric(12, y, 15, 1, 3600, _data.HeartbeatInterval);
            host.Controls.Add(_numHeartbeat); y += 36;

            host.Controls.Add(MkLabel("timeout اتصال (ثانیه):", 12, y, _fg, _fb)); y += 22;
            _numTimeout = MkNumeric(12, y, 10, 1, 600, _data.ConnectTimeout);
            host.Controls.Add(_numTimeout); y += 36;

            host.Controls.Add(MkLabel("حداکثر تلاش reconnect:", 12, y, _fg, _fb)); y += 22;
            _numReconnect = MkNumeric(12, y, 50, 0, 10000, _data.MaxReconnectAttempts);
            host.Controls.Add(_numReconnect); y += 36;

            _chkDrag = new CheckBox
            {
                Text = "□ کشیدن برای جابجایی",
                Font = _f,
                ForeColor = _fg,
                BackColor = _panel,
                Location = new Point(12, y),
                AutoSize = false,
                Size = new Size(380, 26),
                Checked = _data.DragToMove,
                CheckAlign = ContentAlignment.MiddleLeft,
                TextAlign = ContentAlignment.MiddleLeft,
            };
            _chkDrag.CheckedChanged += (s, e) => _data.DragToMove = _chkDrag.Checked;
            host.Controls.Add(_chkDrag); y += 36;

            _chkScreensaver = new CheckBox
            {
                Text = "□ اسکرین‌سیور",
                Font = _f,
                ForeColor = _fg,
                BackColor = _panel,
                Location = new Point(12, y),
                AutoSize = false,
                Size = new Size(380, 26),
                Checked = _data.ScreensaverEnabled,
                CheckAlign = ContentAlignment.MiddleLeft,
                TextAlign = ContentAlignment.MiddleLeft,
            };
            _chkScreensaver.CheckedChanged += (s, e) => _data.ScreensaverEnabled = _chkScreensaver.Checked;
            host.Controls.Add(_chkScreensaver); y += 36;

            host.Controls.Add(MkLabel("زمان اسکرین‌سیور (دقیقه):", 12, y, _fg, _fb)); y += 22;
            _numScreensaver = MkNumeric(12, y, 3, 1, 240, _data.ScreensaverMinutes);
            host.Controls.Add(_numScreensaver);

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 6: Language
        // ----------------------------------------------------------------
        private TabPage BuildLanguageTab()
        {
            var page = NewTab("🌐 Language");
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12) };

            host.Controls.Add(MkLabel("زبان رابط کاربری کلاینت:", 12, 12, _fg, _fb));
            _cboLang = new ComboBox
            {
                Location = new Point(12, 38),
                Size = new Size(280, 28),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat,
                BackColor = _input,
                ForeColor = _fg,
                Font = _f,
            };
            _cboLang.Items.AddRange(new object[] { "فارسی", "English", "العربية" });
            switch ((_data.Language ?? "fa").ToLowerInvariant())
            {
                case "en": _cboLang.SelectedIndex = 1; break;
                case "ar": _cboLang.SelectedIndex = 2; break;
                default:   _cboLang.SelectedIndex = 0; break;
            }
            host.Controls.Add(_cboLang);

            host.Controls.Add(MkLabel(
                "ℹ️ تغییر زبان روی نرم‌افزار کلاینت اعمال می‌شود نه روی سرور.",
                12, 80, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Helpers
        // ----------------------------------------------------------------
        private static TabPage NewTab(string title)
        {
            return new TabPage(title)
            {
                BackColor = _bg,
                ForeColor = _fg,
                Font = _f,
                Padding = new Padding(0),
                UseVisualStyleBackColor = false,
            };
        }

        private static Label MkLabel(string text, int x, int y, Color color, Font font)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = color,
                Font = font,
                BackColor = Color.Transparent,
            };
        }

        private static TextBox MkTextBox(int x, int y, int w, string initial, bool password = false)
        {
            var tb = new TextBox
            {
                Location = new Point(x, y),
                Size = new Size(w, 28),
                Font = _f,
                BackColor = _input,
                ForeColor = _fg,
                BorderStyle = BorderStyle.FixedSingle,
                Text = initial ?? "",
            };
            if (password)
            {
                tb.UseSystemPasswordChar = true;
            }
            return tb;
        }

        private static NumericUpDown MkNumeric(int x, int y, int def, int min, int max, int initial)
        {
            var n = new NumericUpDown
            {
                Location = new Point(x, y),
                Size = new Size(120, 28),
                Font = _f,
                Minimum = min,
                Maximum = max,
                Value = Math.Max(min, Math.Min(max, initial <= 0 ? def : initial)),
                BackColor = _input,
                ForeColor = _fg,
                BorderStyle = BorderStyle.FixedSingle,
            };
            return n;
        }

        // ----------------------------------------------------------------
        //  Reflection helpers
        // ----------------------------------------------------------------
        private static bool GetBool(ClientOptionsData d, string name)
        {
            try
            {
                var prop = typeof(ClientOptionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    return (bool)prop.GetValue(d);
            }
            catch { }
            return false;
        }

        private static void SetBool(ClientOptionsData d, string name, bool value)
        {
            try
            {
                var prop = typeof(ClientOptionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    prop.SetValue(d, value);
            }
            catch { }
        }

        // ----------------------------------------------------------------
        //  Persistence — client_options.json next to the server exe
        // ----------------------------------------------------------------
        private ClientOptionsData LoadData()
        {
            try
            {
                if (File.Exists(_savePath))
                {
                    var json = File.ReadAllText(_savePath);
                    var data = JsonConvert.DeserializeObject<ClientOptionsData>(json);
                    if (data != null) return data;
                }
            }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine("LoadData: " + ex.Message); }
            return new ClientOptionsData();
        }

        private void Save()
        {
            // Validate password repeat.
            if (!string.IsNullOrEmpty(_txtAdminPass.Text) &&
                _txtAdminPass.Text != _txtAdminPass2.Text)
            {
                MessageBox.Show("رمز عبور و تکرار آن مطابقت ندارند.", "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.DialogResult = DialogResult.None;
                return;
            }

            // Push all control values into the data model.
            _data.AdminUsername = _txtAdminUser.Text.Trim();
            _data.AdminPassword = _txtAdminPass.Text;
            _data.ServerIp      = _txtServerIp.Text.Trim();
            _data.AutoConnect   = _chkAuto.Checked;

            // Options tab checkboxes already wrote via CheckedChanged.

            _data.NetworkAdapter = _cboAdapter.SelectedItem?.ToString() ?? "";
            _data.ServerPort     = (int)_numPort.Value;
            _data.UdpPort        = (int)_numUdp.Value;
            _data.UseTls         = _chkTls.Checked;

            // Event tab — paths.
            if (_evtTxts.Count > 0) _data.SoundOnLoginRequestPath = _evtTxts[0].Text;
            if (_evtTxts.Count > 1) _data.SoundOnTimerEndPath     = _evtTxts[1].Text;
            if (_evtTxts.Count > 2) _data.SoundOnOrderPath        = _evtTxts[2].Text;

            // Advanced tab.
            _data.HeartbeatInterval     = (int)_numHeartbeat.Value;
            _data.ConnectTimeout        = (int)_numTimeout.Value;
            _data.MaxReconnectAttempts  = (int)_numReconnect.Value;
            _data.DragToMove            = _chkDrag.Checked;
            _data.ScreensaverEnabled    = _chkScreensaver.Checked;
            _data.ScreensaverMinutes    = (int)_numScreensaver.Value;

            // Language tab.
            switch (_cboLang.SelectedIndex)
            {
                case 1:  _data.Language = "en"; break;
                case 2:  _data.Language = "ar"; break;
                default: _data.Language = "fa"; break;
            }

            try
            {
                File.WriteAllText(_savePath, JsonConvert.SerializeObject(_data, Formatting.Indented));
                try { AuditLog.Log("ClientOptions", "Saved client_options.json"); } catch { }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ذخیره تنظیمات کلاینت: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ----------------------------------------------------------------
        //  Persisted model
        // ----------------------------------------------------------------
        public class ClientOptionsData
        {
            // --- General ---
            public string AdminUsername { get; set; } = "ADMIN";
            public string AdminPassword { get; set; } = "";
            public string ServerIp      { get; set; } = "127.0.0.1";
            public bool   AutoConnect   { get; set; } = true;

            // --- Options tab (9 bools) ---
            public bool DisableWindowsShutdown { get; set; }
            public bool ShowPcNameOnScreen     { get; set; } = true;
            public bool EnableClientOrdering   { get; set; } = true;
            public bool CloseAppsOnLogout      { get; set; } = true;
            public bool RestartAfterPayment    { get; set; }
            public bool ShutdownAfterPayment   { get; set; }
            public bool HideRemainingTime      { get; set; }
            public bool HideStartTime          { get; set; }
            public bool HideCost               { get; set; }

            // --- Network ---
            public string NetworkAdapter { get; set; } = "";
            public int    ServerPort     { get; set; } = 9090;
            public int    UdpPort        { get; set; } = 9091;
            public bool   UseTls         { get; set; }

            // --- Event tab ---
            public bool   SoundOnLoginRequest     { get; set; } = true;
            public string SoundOnLoginRequestPath { get; set; } = "";
            public bool   SoundOnTimerEnd         { get; set; } = true;
            public string SoundOnTimerEndPath     { get; set; } = "";
            public bool   SoundOnOrder            { get; set; } = true;
            public string SoundOnOrderPath        { get; set; } = "";

            // --- Advanced ---
            public int  HeartbeatInterval    { get; set; } = 15;
            public int  ConnectTimeout       { get; set; } = 10;
            public int  MaxReconnectAttempts { get; set; } = 50;
            public bool DragToMove           { get; set; } = true;
            public bool ScreensaverEnabled   { get; set; } = true;
            public int  ScreensaverMinutes   { get; set; } = 3;

            // --- Language ---
            public string Language { get; set; } = "fa";
        }
    }
}
