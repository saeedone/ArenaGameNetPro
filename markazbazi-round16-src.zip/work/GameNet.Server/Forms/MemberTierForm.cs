using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Member Tier management form: view tiers, user progress, manually adjust.
    /// </summary>
    public class MemberTierForm : Form
    {
        private ListView _lvTiers, _lvUserProgress;
        private MemberTierManager _tierMgr;

        public MemberTierForm()
        {
            _tierMgr = new MemberTierManager();

            this.Text = "سطح‌های عضویت - GameNet";
            this.Size = new Size(900, 650);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت سطح‌های عضویت",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Tier list
            var lblTiers = new Label { Text = "سطح‌ها:", Location = new Point(20, 45), AutoSize = true, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50) };
            _lvTiers = new ListView
            {
                Location = new Point(20, 70),
                Size = new Size(840, 180),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvTiers.Columns.Add("ID", 40);
            _lvTiers.Columns.Add("نام", 120);
            _lvTiers.Columns.Add("تخفیف", 80);
            _lvTiers.Columns.Add("امتیاز لازم", 100);
            _lvTiers.Columns.Add("حداقل شارژ", 110);
            _lvTiers.Columns.Add("وضعیت", 60);
            _lvTiers.Columns.Add("توضیحات", 250);

            // User progress list
            var lblProgress = new Label { Text = "پیشرفت کاربران:", Location = new Point(20, 260), AutoSize = true, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20) };
            _lvUserProgress = new ListView
            {
                Location = new Point(20, 285),
                Size = new Size(840, 280),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvUserProgress.Columns.Add("کاربر", 120);
            _lvUserProgress.Columns.Add("سطح فعلی", 120);
            _lvUserProgress.Columns.Add("امتیاز", 80);
            _lvUserProgress.Columns.Add("مجموع هزینه", 120);
            _lvUserProgress.Columns.Add("سطح بعدی", 120);
            _lvUserProgress.Columns.Add("امتیاز تا سطح بعد", 120);

            var btnRefresh = new Button
            {
                Text = "به‌روزرسانی", Location = new Point(20, 575), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnRefresh.Click += (s, e) => RefreshData();

            var btnAddPoints = new Button
            {
                Text = "افزودن امتیاز", Location = new Point(150, 575), Size = new Size(130, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnAddPoints.Click += (s, e) =>
            {
                if (_lvUserProgress.SelectedItems.Count == 0) return;
                string username = _lvUserProgress.SelectedItems[0].Text;
                string input = Microsoft.VisualBasic.Interaction.InputBox($"مبلغ هزینه برای {username} (تومان):", "افزودن امتیاز", "100000", -1, -1);
                if (decimal.TryParse(input, out decimal amount) && amount > 0)
                {
                    _tierMgr.AddPointsForSpending(username, amount);
                    RefreshData();
                    MessageBox.Show("امتیاز اضافه شد");
                }
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblTiers, _lvTiers, lblProgress, _lvUserProgress, btnRefresh, btnAddPoints });
            RefreshData();
        }

        private void RefreshData()
        {
            // Tiers
            _lvTiers.Items.Clear();
            var tiers = _tierMgr.GetAllTiers();
            foreach (var t in tiers)
            {
                var item = new ListViewItem(t.Id.ToString());
                item.SubItems.Add(t.Name);
                item.SubItems.Add($"{t.DiscountPercent}%");
                item.SubItems.Add(t.RequiredPoints.ToString());
                item.SubItems.Add($"{t.MinTopUp:N0}");
                item.SubItems.Add(t.IsActive ? "فعال" : "غیرفعال");
                item.SubItems.Add(t.Description);
                item.Tag = t.Id;

                try { item.ForeColor = ColorTranslator.FromHtml(t.Color); } catch { }

                _lvTiers.Items.Add(item);
            }

            // User progress
            _lvUserProgress.Items.Clear();
            var users = Database.Instance.Query(
                "SELECT username FROM users WHERE is_active = 1 ORDER BY username",
                null,
                r => r.GetString(0));

            foreach (var username in users)
            {
                try
                {
                    var info = _tierMgr.GetUserTierInfo(username);
                    if (info == null) continue;

                    var item = new ListViewItem(username);
                    item.SubItems.Add(info.CurrentTier?.Name ?? "-");
                    item.SubItems.Add(info.CurrentPoints.ToString());
                    item.SubItems.Add($"{info.TotalSpent:N0}");
                    item.SubItems.Add(info.NextTier?.Name ?? "بالاترین سطح");
                    item.SubItems.Add(info.PointsToNextTier > 0 ? info.PointsToNextTier.ToString() : "-");
                    _lvUserProgress.Items.Add(item);
                }
                catch { }
            }
        }
    }
}
