using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class ThemeForm : Form
    {
        private readonly ThemeBuilder _builder = new ThemeBuilder();
        private AppThemePreset _currentTheme;

        public ThemeForm()
        {
            _currentTheme = _builder.GetCurrentTheme();
            this.Text = "تنظیمات ظاهری";
            this.Size = new Size(700, 520);
            this.BackColor = _currentTheme.Background;
            this.ForeColor = _currentTheme.Text;
            this.StartPosition = FormStartPosition.CenterScreen;

            var lblTitle = new Label { Text = "🎨 تنظیمات ظاهری و تم", Font = new Font("Segoe UI", 16F, FontStyle.Bold), ForeColor = _currentTheme.Primary, Location = new Point(20, 15), AutoSize = true };

            var lblPresets = new Label { Text = "تم‌های آماده:", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = _currentTheme.Accent, Location = new Point(20, 55), AutoSize = true };

            var presets = _builder.GetPresetThemes();
            int y = 85;
            foreach (var preset in presets)
            {
                var pnl = new Panel { Location = new Point(20, y), Size = new Size(640, 35), BackColor = preset.Surface };
                var lblName = new Label { Text = preset.Name, Location = new Point(10, 8), AutoSize = true, ForeColor = preset.Text, Font = new Font("Segoe UI", 10F) };
                var pnlColors = new Panel { Location = new Point(200, 5), Size = new Size(30, 25), BackColor = preset.Primary };
                var pnlColors2 = new Panel { Location = new Point(235, 5), Size = new Size(30, 25), BackColor = preset.Accent };
                var pnlColors3 = new Panel { Location = new Point(270, 5), Size = new Size(30, 25), BackColor = preset.Warning };
                var pnlColors4 = new Panel { Location = new Point(305, 5), Size = new Size(30, 25), BackColor = preset.Error };
                var btnApply = new Button { Text = "اعمال", Location = new Point(560, 3), Size = new Size(70, 28), BackColor = preset.Primary, FlatStyle = FlatStyle.Flat, ForeColor = preset.Background, Font = new Font("Segoe UI", 9F) };
                var capturedPreset = preset;
                btnApply.Click += (s, e) =>
                {
                    _currentTheme = capturedPreset;
                    _builder.SaveTheme(_currentTheme);
                    MessageBox.Show($"تم {capturedPreset.Name} اعمال شد. برنامه را ری‌استارت کنید.");
                };
                pnl.Controls.AddRange(new Control[] { lblName, pnlColors, pnlColors2, pnlColors3, pnlColors4, btnApply });
                this.Controls.Add(pnl);
                y += 42;
            }

            // Custom colors
            var grpCustom = new GroupBox { Text = "رنگ‌های سفارشی", Location = new Point(20, 370), Size = new Size(640, 110), ForeColor = _currentTheme.Accent, BackColor = _currentTheme.Surface };
            string[] colorLabels = { "پس‌زمینه", "سطح", "اصلی", "متن", "تاکید", "هشدار", "خطا" };
            string[] colorProps = { "Background", "Surface", "Primary", "Text", "Accent", "Warning", "Error" };
            Color[] currentColors = { _currentTheme.Background, _currentTheme.Surface, _currentTheme.Primary, _currentTheme.Text, _currentTheme.Accent, _currentTheme.Warning, _currentTheme.Error };
            for (int i = 0; i < 7; i++)
            {
                var btn = new Button { Text = colorLabels[i], Location = new Point(10 + i * 90, 25), Size = new Size(82, 35), BackColor = currentColors[i], FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8F) };
                btn.Click += (s, e) =>
                {
                    using (var dlg = new ColorDialog())
                    {
                        if (dlg.ShowDialog() == DialogResult.OK) btn.BackColor = dlg.Color;
                    }
                };
                grpCustom.Controls.Add(btn);
            }
            var btnApplyCustom = new Button { Text = "✅ اعمال رنگ‌های سفارشی", Location = new Point(200, 70), Size = new Size(240, 30), BackColor = _currentTheme.Primary, FlatStyle = FlatStyle.Flat, ForeColor = _currentTheme.Background, Font = new Font("Segoe UI", 10F, FontStyle.Bold) };
            btnApplyCustom.Click += (s, e) =>
            {
                var buttons = grpCustom.Controls.OfType<Button>().Where(b => b.Text != "✅ اعمال رنگ‌های سفارشی").ToList();
                _currentTheme.Name = "Custom";
                _currentTheme.Background = buttons[0].BackColor; _currentTheme.Surface = buttons[1].BackColor;
                _currentTheme.Primary = buttons[2].BackColor; _currentTheme.Text = buttons[3].BackColor;
                _currentTheme.Accent = buttons[4].BackColor; _currentTheme.Warning = buttons[5].BackColor;
                _currentTheme.Error = buttons[6].BackColor;
                _builder.SaveTheme(_currentTheme);
                MessageBox.Show("تم سفارشی ذخیره شد!");
            };
            grpCustom.Controls.Add(btnApplyCustom);

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblPresets);
            this.Controls.Add(grpCustom);
        }
    }
}
