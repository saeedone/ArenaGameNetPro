using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Console (PS4 / PS5 / Xbox) reservation and session management form.
    /// Lets the operator:
    ///   - Register consoles (add PS4/PS5/Xbox stations)
    ///   - Book time slots ahead (reservations)
    ///   - Start walk-in sessions (pay-as-you-go)
    ///   - End sessions and charge the user
    ///   - View today's reservations and active sessions
    /// Embedded as a tab in the main server window.
    /// </summary>
    public class ConsoleReservationForm : Form
    {
        private readonly ConsoleReservationManager _mgr = new ConsoleReservationManager();
        private DataGridView _dgvConsoles, _dgvReservations, _dgvActive;
        private Timer _timer;
        private Label _lblConsoleCount, _lblActiveCount, _lblReservationCount;

        public ConsoleReservationForm()
        {
            this.Text = "🎮 مدیریت کنسول‌ها (PS4 / PS5 / Xbox)";
            this.Size = new Size(1200, 720);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshAll(null, null);

            _timer = new Timer { Interval = 5000 };
            _timer.Tick += RefreshAll;
            _timer.Start();
        }

        private void BuildUi()
        {
            // === Top stats ===
            var statsBar = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(240, 240, 240) };
            int sx = 15;
            _lblConsoleCount = MkStat(statsBar, ref sx, "🎮 کنسول‌ها", "0", Color.FromArgb(137, 180, 250));
            _lblActiveCount = MkStat(statsBar, ref sx, "🟢 نشست‌های فعال", "0", Color.FromArgb(166, 227, 161));
            _lblReservationCount = MkStat(statsBar, ref sx, "📅 رزروهای امروز", "0", Color.FromArgb(249, 226, 175));

            // === Tabbed area: consoles / reservations / active sessions ===
            var tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9F) };

            // Tab 1: Consoles management
            var tabConsoles = new TabPage("🎮 کنسول‌ها") { BackColor = Color.FromArgb(240, 240, 240) };
            _dgvConsoles = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvConsoles.Columns.Add("colId", "شناسه"); _dgvConsoles.Columns["colId"].Visible = false;
            _dgvConsoles.Columns.Add("colName", "نام کنسول");
            _dgvConsoles.Columns.Add("colType", "نوع");
            _dgvConsoles.Columns.Add("colStatus", "وضعیت");

            var consoleToolbar = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnAddPs4 = MkBtn("+ افزودن PS4", Color.FromArgb(137, 180, 250), 5, 7);
            btnAddPs4.Click += (s, e) => AddConsole("PS4");
            var btnAddPs5 = MkBtn("+ افزودن PS5", Color.FromArgb(203, 166, 247), 140, 7);
            btnAddPs5.Click += (s, e) => AddConsole("PS5");
            var btnAddXbox = MkBtn("+ افزودن Xbox", Color.FromArgb(166, 227, 161), 275, 7);
            btnAddXbox.Click += (s, e) => AddConsole("Xbox");
            var btnDeleteConsole = MkBtn("🗑 حذف کنسول", Color.FromArgb(243, 139, 168), 410, 7);
            btnDeleteConsole.Click += (s, e) => DeleteConsole();
            consoleToolbar.Controls.AddRange(new Control[] { btnAddPs4, btnAddPs5, btnAddXbox, btnDeleteConsole });
            tabConsoles.Controls.AddRange(new Control[] { _dgvConsoles, consoleToolbar });

            // Tab 2: Active sessions (walk-in, in-progress)
            var tabActive = new TabPage("🟢 نشست‌های فعال") { BackColor = Color.FromArgb(240, 240, 240) };
            _dgvActive = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvActive.Columns.Add("colAId", "شناسه"); _dgvActive.Columns["colAId"].Visible = false;
            _dgvActive.Columns.Add("colAUser", "کاربر");
            _dgvActive.Columns.Add("colAConsole", "کنسول");
            _dgvActive.Columns.Add("colAType", "نوع");
            _dgvActive.Columns.Add("colAStart", "شروع");
            _dgvActive.Columns.Add("colAElapsed", "زمان گذشته (دقیقه)");

            var activeToolbar = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnStartSession = MkBtn("▶️ شروع نشست (Walk-in)", Color.FromArgb(166, 227, 161), 5, 7);
            btnStartSession.Size = new Size(200, 32);
            btnStartSession.Click += (s, e) => StartWalkInSession();
            var btnEndSession = MkBtn("⏹️ پایان نشست", Color.FromArgb(243, 139, 168), 215, 7);
            btnEndSession.Click += (s, e) => EndSession();
            activeToolbar.Controls.AddRange(new Control[] { btnStartSession, btnEndSession });
            tabActive.Controls.AddRange(new Control[] { _dgvActive, activeToolbar });

            // Tab 3: Reservations (booked ahead)
            var tabReservations = new TabPage("📅 رزروها") { BackColor = Color.FromArgb(240, 240, 240) };
            _dgvReservations = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvReservations.Columns.Add("colRId", "شناسه"); _dgvReservations.Columns["colRId"].Visible = false;
            _dgvReservations.Columns.Add("colRUser", "کاربر");
            _dgvReservations.Columns.Add("colRConsole", "کنسول");
            _dgvReservations.Columns.Add("colRStart", "شروع");
            _dgvReservations.Columns.Add("colREnd", "پایان");
            _dgvReservations.Columns.Add("colRStatus", "وضعیت");
            _dgvReservations.Columns.Add("colRNotes", "یادداشت");

            _dgvReservations.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (_dgvReservations.Columns[e.ColumnIndex].Name == "colRStatus")
                {
                    var v = e.Value?.ToString() ?? "";
                    if (v == "active") { e.CellStyle.ForeColor = Color.FromArgb(20, 130, 50); e.Value = "فعال"; }
                    else if (v == "cancelled") { e.CellStyle.ForeColor = Color.FromArgb(200, 30, 60); e.Value = "لغو شده"; }
                }
            };

            var resToolbar = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnAddRes = MkBtn("➕ رزرو جدید", Color.FromArgb(166, 227, 161), 5, 7);
            btnAddRes.Click += (s, e) => AddReservation();
            var btnCancelRes = MkBtn("❌ لغو رزرو", Color.FromArgb(243, 139, 168), 140, 7);
            btnCancelRes.Click += (s, e) => CancelReservation();
            resToolbar.Controls.AddRange(new Control[] { btnAddRes, btnCancelRes });
            tabReservations.Controls.AddRange(new Control[] { _dgvReservations, resToolbar });

            tabs.TabPages.AddRange(new TabPage[] { tabConsoles, tabActive, tabReservations });

            Controls.AddRange(new Control[] { tabs, statsBar });
        }

        private Label MkStat(Panel parent, ref int x, string title, string value, Color color)
        {
            var pnl = new Panel { Location = new Point(x, 8), Size = new Size(160, 44), BackColor = Color.FromArgb(230, 230, 235) };
            var lblT = new Label { Text = title, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(8, 4), AutoSize = true };
            var lblV = new Label { Text = value, Font = new Font("Segoe UI", 13F, FontStyle.Bold), ForeColor = color, Location = new Point(8, 20), AutoSize = true };
            pnl.Controls.AddRange(new Control[] { lblT, lblV });
            parent.Controls.Add(pnl);
            x += 168;
            return lblV;
        }

        private Button MkBtn(string text, Color bg, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(130, 32),
                BackColor = bg,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
            };
        }

        private void RefreshAll(object s, EventArgs e)
        {
            // Consoles
            _dgvConsoles.Rows.Clear();
            var consoles = _mgr.GetConsoles();
            foreach (var c in consoles)
                _dgvConsoles.Rows.Add(c.Id, c.Name, c.Category, c.Status == "available" ? "موجود" : c.Status);
            _lblConsoleCount.Text = consoles.Count.ToString();

            // Active sessions
            _dgvActive.Rows.Clear();
            var active = _mgr.GetActiveSessions();
            foreach (var a in active)
                _dgvActive.Rows.Add(a.Id, a.Username, a.ConsoleName, a.ConsoleType, a.StartTime.ToString("HH:mm"), a.ElapsedMinutes.ToString());
            _lblActiveCount.Text = active.Count.ToString();

            // Today's reservations
            _dgvReservations.Rows.Clear();
            var reservations = _mgr.GetTodayReservations();
            foreach (var r in reservations)
                _dgvReservations.Rows.Add(r.Id, r.Username, r.ConsoleName, r.Start.ToString("HH:mm"), r.End.ToString("HH:mm"), r.Status, r.Notes);
            _lblReservationCount.Text = reservations.Count.ToString();
        }

        private void AddConsole(string type)
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox($"نام کنسول {type} را وارد کنید (مثلاً: {type}-1):", $"افزودن {type}", $"{type}-1");
            if (string.IsNullOrWhiteSpace(name)) return;
            try
            {
                _mgr.AddConsole(name.Trim(), type);
                MessageBox.Show($"کنسول {name} ({type}) اضافه شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshAll(null, null);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DeleteConsole()
        {
            if (_dgvConsoles.SelectedRows.Count == 0) { MessageBox.Show("یک کنسول انتخاب کنید."); return; }
            int id = (int)_dgvConsoles.SelectedRows[0].Cells[0].Value;
            string name = _dgvConsoles.SelectedRows[0].Cells[1].Value.ToString();
            if (MessageBox.Show($"حذف کنسول {name}؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Database.Instance.Execute("DELETE FROM stations WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", id));
                RefreshAll(null, null);
            }
        }

        private void StartWalkInSession()
        {
            using (var dlg = new WalkInSessionForm(_mgr))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    RefreshAll(null, null);
            }
        }

        private void EndSession()
        {
            if (_dgvActive.SelectedRows.Count == 0) { MessageBox.Show("یک نشست فعال انتخاب کنید."); return; }
            int id = (int)_dgvActive.SelectedRows[0].Cells[0].Value;
            string consoleName = _dgvActive.SelectedRows[0].Cells[2].Value.ToString();
            string consoleType = _dgvActive.SelectedRows[0].Cells[3].Value.ToString();

            // Get the console-type-specific price
            decimal price = _mgr.GetConsolePrice(consoleType);
            if (price <= 0) price = 20000; // fallback: 20,000 T/h

            if (MessageBox.Show($"پایان نشست #{id}؟\nقیمت ساعتی: {price:N0} تومان", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    decimal cost = _mgr.EndSession(id, price);
                    MessageBox.Show($"نشست پایان یافت.\nهزینه: {cost:N0} تومان\nاز موجودی کاربر کسر شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshAll(null, null);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void AddReservation()
        {
            using (var dlg = new ReservationDialog(_mgr))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    RefreshAll(null, null);
            }
        }

        private void CancelReservation()
        {
            if (_dgvReservations.SelectedRows.Count == 0) { MessageBox.Show("یک رزرو انتخاب کنید."); return; }
            int id = (int)_dgvReservations.SelectedRows[0].Cells[0].Value;
            string reason = Microsoft.VisualBasic.Interaction.InputBox("دلیل لغو:", "لغو رزرو", "لغو توسط اپراتور");
            if (string.IsNullOrWhiteSpace(reason)) return;
            try
            {
                _mgr.CancelReservation(id, reason);
                RefreshAll(null, null);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }

    /// <summary>Dialog to start a walk-in console session.</summary>
    internal class WalkInSessionForm : Form
    {
        private readonly ConsoleReservationManager _mgr;
        private TextBox _txtUser;
        private ComboBox _cboConsole;

        public WalkInSessionForm(ConsoleReservationManager mgr)
        {
            _mgr = mgr;
            this.Text = "شروع نشست (Walk-in)";
            this.Size = new Size(420, 230);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lblUser = new Label { Text = "نام کاربری:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtUser = new TextBox { Location = new Point(20, 45), Size = new Size(360, 30), Font = new Font("Segoe UI", 11F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblConsole = new Label { Text = "کنسول:", Location = new Point(20, 85), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cboConsole = new ComboBox { Location = new Point(20, 110), Size = new Size(360, 30), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            foreach (var c in _mgr.GetConsoles())
                _cboConsole.Items.Add($"{c.Name} ({c.Category})");
            if (_cboConsole.Items.Count > 0) _cboConsole.SelectedIndex = 0;

            var btnOk = new Button { Text = "▶️ شروع نشست", Location = new Point(20, 155), Size = new Size(175, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)), DialogResult = DialogResult.OK };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(205, 155), Size = new Size(175, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)), DialogResult = DialogResult.Cancel };

            btnOk.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtUser.Text)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
                if (_cboConsole.SelectedItem == null) { MessageBox.Show("کنسول را انتخاب کنید."); return; }
                var parts = _cboConsole.SelectedItem.ToString().Split('(');
                string consoleName = parts[0].Trim();
                string consoleType = parts.Length > 1 ? parts[1].TrimEnd(')') : "PS4";
                try
                {
                    _mgr.StartSession(_txtUser.Text.Trim(), consoleName, consoleType);
                    MessageBox.Show("نشست شروع شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            this.Controls.AddRange(new Control[] { lblUser, _txtUser, lblConsole, _cboConsole, btnOk, btnCancel });
        }
    }

    /// <summary>Dialog to create a console reservation (time slot booking).</summary>
    internal class ReservationDialog : Form
    {
        private readonly ConsoleReservationManager _mgr;
        private TextBox _txtUser;
        private ComboBox _cboConsole;
        private DateTimePicker _dtpStart, _dtpEnd;

        public ReservationDialog(ConsoleReservationManager mgr)
        {
            _mgr = mgr;
            this.Text = "رزرو زمان کنسول";
            this.Size = new Size(450, 320);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lblUser = new Label { Text = "نام کاربری:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtUser = new TextBox { Location = new Point(20, 40), Size = new Size(390, 30), Font = new Font("Segoe UI", 11F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblConsole = new Label { Text = "کنسول:", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cboConsole = new ComboBox { Location = new Point(20, 105), Size = new Size(390, 30), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F) };
            foreach (var c in _mgr.GetConsoles())
                _cboConsole.Items.Add($"{c.Name} ({c.Category})");
            if (_cboConsole.Items.Count > 0) _cboConsole.SelectedIndex = 0;

            var lblStart = new Label { Text = "از زمان:", Location = new Point(20, 145), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpStart = new DateTimePicker { Location = new Point(20, 170), Size = new Size(190, 30), Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Font = new Font("Segoe UI", 10F), Value = DateTime.Now };

            var lblEnd = new Label { Text = "تا زمان:", Location = new Point(220, 145), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpEnd = new DateTimePicker { Location = new Point(220, 170), Size = new Size(190, 30), Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Font = new Font("Segoe UI", 10F), Value = DateTime.Now.AddHours(1) };

            var btnOk = new Button { Text = "📅 ثبت رزرو", Location = new Point(20, 215), Size = new Size(190, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)), DialogResult = DialogResult.OK };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(220, 215), Size = new Size(190, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)), DialogResult = DialogResult.Cancel };

            btnOk.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtUser.Text)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
                if (_cboConsole.SelectedItem == null) { MessageBox.Show("کنسول را انتخاب کنید."); return; }
                if (_dtpEnd.Value <= _dtpStart.Value) { MessageBox.Show("زمان پایان باید بعد از شروع باشد."); return; }
                var parts = _cboConsole.SelectedItem.ToString().Split('(');
                string consoleName = parts[0].Trim();
                string consoleType = parts.Length > 1 ? parts[1].TrimEnd(')') : "PS4";
                try
                {
                    _mgr.CreateReservation(_txtUser.Text.Trim(), consoleName, consoleType, _dtpStart.Value, _dtpEnd.Value);
                    MessageBox.Show("رزرو ثبت شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            this.Controls.AddRange(new Control[] { lblUser, _txtUser, lblConsole, _cboConsole, lblStart, _dtpStart, lblEnd, _dtpEnd, btnOk, btnCancel });
        }
    }
}
