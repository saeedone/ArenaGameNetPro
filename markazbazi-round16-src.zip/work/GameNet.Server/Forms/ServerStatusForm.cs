using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Server status form. Shows server uptime, connected clients count,
    /// database file size, today's income, active sessions count, total
    /// users count, and API/WebSocket status.
    /// </summary>
    public class ServerStatusForm : Form
    {
        private ClientCommunicator _communicator;
        private readonly bool _apiRunning;
        private readonly bool _wsRunning;

        private Label _lblUptime, _lblClients, _lblDbSize, _lblIncome, _lblSessions, _lblUsers, _lblApi, _lblWs;
        private Timer _refreshTimer;
        private readonly DateTime _startedAt = Process.GetCurrentProcess().StartTime;

        public ServerStatusForm(ClientCommunicator communicator, bool apiRunning, bool wsRunning)
        {
            _communicator = communicator;
            _apiRunning = apiRunning;
            _wsRunning = wsRunning;

            this.Text = "وضعیت سرور - GameNet";
            this.Size = new Size(700, 560);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            var lblTitle = new Label
            {
                Text = "📊 وضعیت سرور",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 12),
                AutoSize = true,
            };

            int y = 56;
            _lblUptime   = AddRow("⏱️ زمان فعال (Uptime):", y); y += 38;
            _lblClients  = AddRow("📡 کلاینت‌های متصل:", y); y += 38;
            _lblSessions = AddRow("🎮 نشست‌های فعال:", y); y += 38;
            _lblUsers    = AddRow("👥 کل کاربران:", y); y += 38;
            _lblIncome   = AddRow("💰 درآمد امروز:", y); y += 38;
            _lblDbSize   = AddRow("💾 حجم پایگاه داده:", y); y += 38;
            _lblApi      = AddRow("📱 API (HTTP):", y); y += 38;
            _lblWs       = AddRow("🌐 WebSocket:", y); y += 38;

            Controls.Add(lblTitle);

            _refreshTimer = new Timer { Interval = 1000 };
            _refreshTimer.Tick += (s, e) => RefreshStatus();
            _refreshTimer.Start();

            this.FormClosing += (s, e) => { try { _refreshTimer.Stop(); } catch { } };

            RefreshStatus();
        }

        private Label AddRow(string title, int y)
        {
            var lblTitle = new Label
            {
                Text = title,
                Location = new Point(20, y + 6),
                AutoSize = true,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            var lblValue = new Label
            {
                Location = new Point(280, y + 2),
                Size = new Size(380, 32),
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
                TextAlign = ContentAlignment.MiddleLeft,
            };
            Controls.Add(lblTitle);
            Controls.Add(lblValue);
            return lblValue;
        }

        private void RefreshStatus()
        {
            try
            {
                var up = DateTime.Now - _startedAt;
                _lblUptime.Text = $"{(int)up.TotalDays} روز، {up.Hours:00}:{up.Minutes:00}:{up.Seconds:00}";

                int clients = _communicator?.ConnectedClientCount ?? 0;
                _lblClients.Text = clients.ToString() + " کلاینت";

                // Active sessions count
                int sessions = 0;
                try
                {
                    sessions = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM client_sessions WHERE state = 1 AND is_connected = 1",
                        null, r => r.GetInt32(0));
                }
                catch { }
                _lblSessions.Text = sessions.ToString() + " نشست";

                // Total users
                int users = 0;
                try
                {
                    users = Database.Instance.QueryOne("SELECT COUNT(*) FROM users", null, r => r.GetInt32(0));
                }
                catch { }
                _lblUsers.Text = users.ToString() + " کاربر";

                // Today's income
                decimal income = 0;
                try
                {
                    income = Database.Instance.QueryOne(
                        "SELECT COALESCE(SUM(total_cost), 0) FROM client_sessions WHERE end_time IS NOT NULL AND date(start_time) = date('now')",
                        null, r => r.GetDecimal(0));
                }
                catch { }
                _lblIncome.Text = income.ToString("N0") + " تومان";

                // DB size
                long dbSize = 0;
                try
                {
                    string path = Database.Instance.DatabaseFilePath;
                    if (!string.IsNullOrEmpty(path) && File.Exists(path))
                    {
                        dbSize = new FileInfo(path).Length;
                    }
                }
                catch { }
                _lblDbSize.Text = dbSize <= 0 ? "—" : (dbSize / 1024.0 / 1024.0).ToString("F2") + " MB";

                _lblApi.Text = _apiRunning ? "✅ فعال" : "❌ غیرفعال";
                _lblApi.ForeColor = _apiRunning ? Color.FromArgb(166, 227, 161) : Color.FromArgb(243, 139, 168);

                _lblWs.Text = _wsRunning ? "✅ فعال" : "❌ غیرفعال";
                _lblWs.ForeColor = _wsRunning ? Color.FromArgb(166, 227, 161) : Color.FromArgb(243, 139, 168);
            }
            catch { }
        }
    }
}
