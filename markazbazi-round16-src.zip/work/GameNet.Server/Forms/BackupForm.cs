using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Backup management form: create, restore, schedule backups.
    /// </summary>
    public class BackupForm : Form
    {
        private ListView _lvBackups;
        private BackupManager _backupMgr;
        private NumericUpDown _nudInterval;
        private CheckBox _chkAutoBackup;

        public BackupForm()
        {
            _backupMgr = new BackupManager();

            this.Text = "پشتیبان‌گیری - GameNet";
            this.Size = new Size(800, 550);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت پشتیبان‌گیری",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Buttons
            var btnCreate = new Button
            {
                Text = "ایجاد پشتیبان", Location = new Point(20, 50), Size = new Size(160, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnCreate.Click += (s, e) =>
            {
                try
                {
                    var info = _backupMgr.CreateBackup("پشتیبان دستی");
                    MessageBox.Show($"پشتیبان ایجاد شد: {info.Filename}\nحجم: {info.FileSize / 1024} KB", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshList();
                }
                catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            var btnCleanup = new Button
            {
                Text = "پاکسازی قدیمی‌ها", Location = new Point(190, 50), Size = new Size(160, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            btnCleanup.Click += (s, e) =>
            {
                int deleted = _backupMgr.CleanupOldBackups(10);
                MessageBox.Show($"{deleted} پشتیبان قدیمی حذف شد", "پاکسازی", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshList();
            };

            var btnDelete = new Button
            {
                Text = "حذف انتخاب‌شده", Location = new Point(360, 50), Size = new Size(140, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnDelete.Click += (s, e) =>
            {
                if (_lvBackups.SelectedItems.Count == 0) return;
                int id = (int)_lvBackups.SelectedItems[0].Tag;
                if (MessageBox.Show("آیا از حذف این پشتیبان مطمئن هستید؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    _backupMgr.DeleteBackup(id);
                    RefreshList();
                }
            };

            var btnRestore = new Button
            {
                Text = "بازیابی", Location = new Point(510, 50), Size = new Size(120, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213))
            };
            btnRestore.Click += (s, e) =>
            {
                if (_lvBackups.SelectedItems.Count == 0) return;
                string filename = _lvBackups.SelectedItems[0].SubItems[1].Text;
                if (MessageBox.Show($"آیا از بازیابی {filename} مطمئن هستید؟\nسرور باید ری‌استارت شود.", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    if (_backupMgr.RestoreBackup(filename))
                        MessageBox.Show("بازیابی موفق. لطفاً سرور را ری‌استارت کنید.");
                    else
                        MessageBox.Show("خطا در بازیابی!");
                }
            };

            // Auto-backup settings
            _chkAutoBackup = new CheckBox
            {
                Text = "پشتیبان‌گیری خودکار هر",
                Location = new Point(20, 100),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(40, 40, 40),
                Checked = false
            };

            _nudInterval = new NumericUpDown
            {
                Location = new Point(200, 98), Size = new Size(60, 28),
                Minimum = 1, Maximum = 168, Value = 6,
                Font = new Font("Segoe UI", 10F)
            };

            var lblHours = new Label { Text = "ساعت", Location = new Point(270, 100), AutoSize = true, Font = new Font("Segoe UI", 10F) };

            var btnSaveSettings = new Button
            {
                Text = "ذخیره تنظیمات", Location = new Point(320, 96), Size = new Size(120, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnSaveSettings.Click += (s, e) =>
            {
                if (_chkAutoBackup.Checked)
                {
                    _backupMgr.StartAutoBackup((int)_nudInterval.Value);
                    MessageBox.Show($"پشتیبان‌گیری خودکار هر {_nudInterval.Value} ساعت فعال شد");
                }
                else
                {
                    _backupMgr.StopAutoBackup();
                    MessageBox.Show("پشتیبان‌گیری خودکار غیرفعال شد");
                }
            };

            // Backup list
            _lvBackups = new ListView
            {
                Location = new Point(20, 140),
                Size = new Size(740, 340),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvBackups.Columns.Add("ID", 40);
            _lvBackups.Columns.Add("فایل", 250);
            _lvBackups.Columns.Add("حجم", 80);
            _lvBackups.Columns.Add("نوع", 80);
            _lvBackups.Columns.Add("توضیحات", 150);
            _lvBackups.Columns.Add("تاریخ", 140);

            this.Controls.AddRange(new Control[] { lblTitle, btnCreate, btnCleanup, btnDelete, btnRestore, _chkAutoBackup, _nudInterval, lblHours, btnSaveSettings, _lvBackups });
            RefreshList();
        }

        private void RefreshList()
        {
            _lvBackups.Items.Clear();
            var backups = _backupMgr.GetBackups();
            foreach (var b in backups)
            {
                var item = new ListViewItem(b.Id.ToString());
                item.SubItems.Add(b.Filename);
                item.SubItems.Add($"{b.FileSize / 1024} KB");
                item.SubItems.Add(b.BackupType == "scheduled" ? "خودکار" : "دستی");
                item.SubItems.Add(b.Description);
                item.SubItems.Add(b.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"));
                item.Tag = b.Id;
                _lvBackups.Items.Add(item);
            }
        }
    }
}
