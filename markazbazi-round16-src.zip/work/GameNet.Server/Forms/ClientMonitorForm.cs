using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Enhanced real-time client monitor. Shows every connected kiosk with
    /// live CPU / RAM / disk usage, session cost, elapsed time, current game,
    /// and a per-client quick-action toolbar (lock, unlock, force-logout,
    /// shutdown, message, add-credit, view-details). Auto-refreshes every
    /// 2 seconds with a pulse animation on the connection count.
    /// </summary>
    public class ClientMonitorForm : Form
    {
        private ClientCommunicator _comm;
        private Timer _timer;
        private DataGridView dgv;
        private Label _lblCount, _lblOnline, _lblInSession, _lblLocked;
        // FIX-MONITOR-ADD5 TASK A: removed _cpuBar / _ramBar / _detailPanel —
        // the CPU/RAM info is already shown in the dgv columns (colCpu,
        // colRam), and the 40px bottom panel stole vertical space from the
        // grid. The _lblSelectedStation is now hosted in the top stats bar.
        private Label _lblSelectedStation;

        // FIX RIGHT-PANEL: live info labels for the right-side session panel.
        private Label _lblInfoStation, _lblInfoIp, _lblInfoPrice, _lblInfoUser;
        private Label _lblInfoUsed, _lblInfoRemaining, _lblInfoCost;
        private CheckBox _chkWarn5Min, _chkBeepMin;
        // Track last warned minute so we only beep once per minute.
        private int _lastWarnMinute = -1;
        // Round 11: per-station warning state. _lastWarnMinute was one value for all
        // stations, so with two stations in the last 5 minutes only one was warned.
        private readonly Dictionary<string, int> _lastWarnByStation = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _expiredAnnounced = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        // Admin status — checked at construction time.
        private bool _isAdminOperator = false;
        private bool IsAdminOperator => _isAdminOperator;

        // Cached static fonts to avoid GDI handle leak in CellFormatting (FIX 17).
        private static readonly Font _boldFont = new Font("Segoe UI", 9F, FontStyle.Bold);
        private static readonly Font _normalFont = new Font("Segoe UI", 9F);

        // FIX M1: cache of operator usernames so CellFormatting (which fires
        // per cell per paint — i.e. dozens of times per second on a busy grid)
        // doesn't query the DB on every paint. Refreshed every 60s in Refresh.
        private HashSet<string> _operatorUsernames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private DateTime _operatorCacheAt = DateTime.MinValue;

        public ClientMonitorForm(ClientCommunicator comm) : this(comm, false) { }

        public ClientMonitorForm(ClientCommunicator comm, bool isAdmin)
        {
            _comm = comm;
            _isAdminOperator = isAdmin;
            this.Text = "مانیتور کلاینت‌ها - نظارت زنده";
            // FIX-MONITOR-ADD5 TASK A: enlarged from 1200x700 to 1400x800 and
            // start Maximized so the dgv gets the full screen — the operator's
            // primary complaint was that not all clients were visible. With
            // Maximized + MinimumSize on the dgv, every connected kiosk row
            // fits without scrolling even on a 30-station game-net.
            this.Size = new Size(1400, 800);
            this.MinimumSize = new Size(1024, 600);
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();

            _timer = new Timer { Interval = 2000 };
            _timer.Tick += Refresh;
            _timer.Start();
            Refresh(null, null);
        }

        private void BuildUi()
        {
            // === Top stats bar (compact, single row, Height=30 per FIX-MONITOR-ADD5) ===
            var statsBar = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.FromArgb(240, 240, 240) };
            int sx = 5;
            _lblCount = MkStat(statsBar, ref sx, "🔌 کل", "0", Color.FromArgb(137, 180, 250));
            _lblOnline = MkStat(statsBar, ref sx, "🟢 آنلاین", "0", Color.FromArgb(166, 227, 161));
            _lblInSession = MkStat(statsBar, ref sx, "🎮 در جلسه", "0", Color.FromArgb(249, 226, 175));
            _lblLocked = MkStat(statsBar, ref sx, "🔒 قفل", "0", Color.FromArgb(243, 139, 168));
            // FIX-MONITOR-ADD5 TASK A: moved the "selected station" label up
            // into the stats bar (right-anchored) so the bottom _detailPanel
            // (which stole 40px from the dgv) could be removed entirely.
            _lblSelectedStation = new Label
            {
                Text = "⚡ انتخاب: -",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            statsBar.Resize += (s, e) => _lblSelectedStation.Location = new Point(statsBar.Width - _lblSelectedStation.PreferredWidth - 12, 7);
            statsBar.Controls.Add(_lblSelectedStation);

            // === ONE compact action toolbar (bottom, Height=34 per FIX-MONITOR-ADD5) ===
            // FIX-MONITOR-ADD5 TASK A: previously 3 separate bottom panels
            // (toolbar1 34px + toolbar3 28px + _detailPanel 40px = 102px of
            // chrome) stole vertical space from the grid. Now there is ONE
            // 34px toolbar with per-client actions on the left + a single
            // "📦 گروهی ▼" button on the right that opens a dropdown of all
            // bulk operations. The dgv now gets the entire remaining height.
            var toolbar1 = new Panel { Dock = DockStyle.Bottom, Height = 34, BackColor = Color.FromArgb(240, 240, 240) };
            int bx = 5;
            var btnRefresh = MkToolBtn(toolbar1, ref bx, "refresh", "بروز", Color.FromArgb(137, 180, 250), (s, e) => Refresh(null, null));
            var btnUnlock = MkToolBtn(toolbar1, ref bx, "lock", "باز", Color.FromArgb(166, 227, 161), (s, e) => ActOnSelected(st => { _comm.UnlockStation(st); Log("باز: " + st); ToastNotification.Show(this, $"🔓 {st} باز شد", ToastType.Success, 2500); }));
            var btnLogout = MkToolBtn(toolbar1, ref bx, "exit", "خروج", Color.FromArgb(243, 139, 168), (s, e) => ActOnSelected(st => { if (Confirm("خروج اجباری " + st + "؟")) { _comm.ForceLogoutStation(st); Log("خروج: " + st); ToastNotification.Show(this, $"🚪 {st} خارج شد", ToastType.Info, 2500); } }));
            var btnMsg = MkToolBtn(toolbar1, ref bx, "msg", "پیام", Color.FromArgb(203, 166, 247), (s, e) => ActOnSelected(st => { string m = InputBox("پیام به " + st + ":", "ارسال پیام"); if (!string.IsNullOrEmpty(m)) _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage, new ServerMessagePayload { Title = "پیام اپراتور", Body = m, Level = "info" })); }));
            var btnAddCredit = MkToolBtn(toolbar1, ref bx, "money", "شارژ", Color.FromArgb(166, 227, 161), (s, e) => AddCreditToSelectedClient());
            var btnScreenshot = MkToolBtn(toolbar1, ref bx, "camera", "عکس", Color.FromArgb(203, 166, 247), (s, e) => RequestScreenshot());
            var btnShutdown = MkToolBtn(toolbar1, ref bx, "shutdown", "خاموش", Color.FromArgb(243, 139, 168), (s, e) => ActOnSelected(st => { if (Confirm("⚠️ خاموش " + st + "؟")) { _comm.ShutdownStation(st); ToastNotification.Show(this, $"⏻ {st} خاموش شد", ToastType.Warning, 3000); } }));
            var btnRestart = MkToolBtn(toolbar1, ref bx, "restart", "ری‌استارت", Color.FromArgb(250, 179, 135), (s, e) => ActOnSelected(st => { if (Confirm("ری‌استارت " + st + "؟")) { _comm.RestartStation(st); ToastNotification.Show(this, $"🔄 {st} ری‌استارت شد", ToastType.Info, 3000); } }));
            var btnAdd10 = MkToolBtn(toolbar1, ref bx, "play", "+10", Color.FromArgb(249, 226, 175), (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 10, "+10")));
            var btnAdd30 = MkToolBtn(toolbar1, ref bx, "play", "+30", Color.FromArgb(249, 226, 175), (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 30, "+30")));
            var btnAdd60 = MkToolBtn(toolbar1, ref bx, "play", "+60", Color.FromArgb(249, 226, 175), (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 60, "+60")));
            var btnUnlimited = MkToolBtn(toolbar1, ref bx, "play", "نامحدود", Color.FromArgb(137, 180, 250), (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 2, 0, "نامحدود")));
            var btnEndNow = MkToolBtn(toolbar1, ref bx, "stop", "پایان", Color.FromArgb(243, 139, 168), (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 3, 0, "پایان نشست")));

            // "📦 گروهی ▼" button — anchored to the right edge of the toolbar.
            // Click opens a ContextMenuStrip with all the bulk/all-clients
            // operations that used to live in the deleted toolbar3 panel.
            var btnBulk = new Button
            {
                Text = "📦 گروهی ▼",
                Size = new Size(110, 28),
                BackColor = Color.FromArgb(230, 230, 235),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 140, 130),
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            btnBulk.FlatAppearance.BorderSize = 0;
            btnBulk.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 220, 225);
            btnBulk.FlatAppearance.MouseDownBackColor = Color.FromArgb(69, 71, 90);
            btnBulk.Click += (s, e) => BuildBulkOpsMenu().Show(btnBulk, new Point(0, btnBulk.Height));
            toolbar1.Resize += (s, e) => btnBulk.Location = new Point(toolbar1.Width - btnBulk.Width - 6, 3);
            toolbar1.Controls.Add(btnBulk);

            // === Main grid ===
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                // BUG FIX: this 800x300 floor was added back when this form
                // could be shown standalone as its own resizable window —
                // but it's now only ever embedded into a tab via MainForm's
                // CreateFormForKey, which sizes it to whatever the tab's
                // actual content area is. Combined with the right-side
                // action panel next to it, an 800px floor demanded far more
                // width than some tab layouts actually have, pushing client
                // rows out of view — DataGridView has its own internal
                // scrollbars as a fallback, so no safety net is lost by
                // removing this.
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                BorderStyle = BorderStyle.None,
                GridColor = Color.FromArgb(50, 50, 70),
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(255, 255, 255),
                    ForeColor = Color.FromArgb(40, 40, 40),
                    SelectionBackColor = Color.FromArgb(69, 71, 90),
                    SelectionForeColor = Color.White,
                    Font = _normalFont,
                    Padding = new Padding(4),
                },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(240, 240, 240),
                    ForeColor = Color.FromArgb(30, 80, 180),
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                    Padding = new Padding(4),
                },
                EnableHeadersVisualStyles = false,
            };
            // FIX GRID-COLUMNS: reduced from 19 to 8 essential columns so
            // each row is readable and the grid doesn't overflow horizontally.
            // The removed columns (OS, MAC, Version, Mode, Disk, Heartbeat,
            // Window, Game, Start, End) are still available in the right-side
            // info panel for the selected station.
            dgv.Columns.Add("colStation", "💻 ایستگاه");
            dgv.Columns.Add("colIp", "🌐 IP");
            dgv.Columns.Add("colState", "📊 وضعیت");
            dgv.Columns.Add("colUser", "👤 کاربر");
            dgv.Columns.Add("colRemaining", "⏳ باقی‌مانده");
            dgv.Columns.Add("colUsed", "⏱️ استفاده");
            dgv.Columns.Add("colCost", "💰 هزینه");
            dgv.Columns.Add("colCpu", "🖥️ CPU");

            // Set explicit column widths so the grid fits nicely.
            dgv.Columns["colStation"].Width = 100;
            dgv.Columns["colIp"].Width = 110;
            dgv.Columns["colState"].Width = 80;
            dgv.Columns["colUser"].Width = 90;
            dgv.Columns["colRemaining"].Width = 90;
            dgv.Columns["colUsed"].Width = 80;
            dgv.Columns["colCost"].Width = 90;
            dgv.Columns["colCpu"].Width = 60;
            // Disable auto-fill so explicit widths are respected.
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            // === Right-click context menu — RESTORED per user request.
            // FIX CONTEXT-MENU: re-enable the right-click context menu so the
            // operator can right-click on a client row and see all actions.
            dgv.ContextMenuStrip = BuildContextMenu();

            // FIX DEAD-CONFIG-7: OptionsForm's "عملکرد دابل‌کلیک" (login vs
            // payment) was saved but the grid never had a double-click
            // handler at all — double-clicking a station row did nothing.
            // Reuses the exact same actions already available from the
            // right-click menu (login submenu items / the پرداخت item)
            // rather than inventing new behavior, shown as a small popup
            // at the cursor so the operator doesn't have to right-click
            // then hover into a submenu for the action they use most.
            dgv.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                dgv.ClearSelection();
                dgv.Rows[e.RowIndex].Selected = true;
                ShowDoubleClickMenu();
            };

            // Color the state column
            dgv.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (dgv.Columns[e.ColumnIndex].Name == "colState")
                {
                    var v = e.Value?.ToString() ?? "";
                    if (v.Contains("جلسه")) { e.CellStyle.ForeColor = Color.FromArgb(20, 130, 50); e.CellStyle.Font = _boldFont; }
                    else if (v.Contains("متصل")) { e.CellStyle.ForeColor = Color.FromArgb(30, 80, 180); }
                    else if (v.Contains("قفل")) { e.CellStyle.ForeColor = Color.FromArgb(200, 30, 60); }
                    else { e.CellStyle.ForeColor = Color.FromArgb(200, 100, 30); }
                }
                else if (dgv.Columns[e.ColumnIndex].Name == "colUser")
                {
                    var v = e.Value?.ToString() ?? "";
                    // Highlight admin users
                    if (v.Equals("admin", StringComparison.OrdinalIgnoreCase))
                    {
                        e.Value = "👑 " + v + " (ادمین)";
                        e.CellStyle.ForeColor = Color.FromArgb(180, 140, 20);
                        e.CellStyle.Font = _boldFont;
                    }
                    else if (v != "-" && !string.IsNullOrEmpty(v))
                    {
                        // FIX M1: check the cached set instead of querying the
                        // DB on every cell paint. The cache is refreshed every
                        // 60s in Refresh() — see MaybeRefreshOperatorCache.
                        if (_operatorUsernames.Contains(v))
                        {
                            e.Value = "🔑 " + v + " (اپراتور)";
                            e.CellStyle.ForeColor = Color.FromArgb(130, 50, 180);
                            e.CellStyle.Font = _boldFont;
                        }
                    }
                }
                else if (dgv.Columns[e.ColumnIndex].Name == "colCpu" || dgv.Columns[e.ColumnIndex].Name == "colRam")
                {
                    var v = e.Value?.ToString() ?? "";
                    double pct;
                    if (double.TryParse(v.TrimEnd(' ', '%'), out pct))
                    {
                        if (pct >= 85) e.CellStyle.ForeColor = Color.FromArgb(200, 30, 60);
                        else if (pct >= 60) e.CellStyle.ForeColor = Color.FromArgb(180, 140, 20);
                        else e.CellStyle.ForeColor = Color.FromArgb(20, 130, 50);
                    }
                }
            };

            dgv.SelectionChanged += (s, e) =>
            {
                if (dgv.SelectedRows.Count > 0)
                {
                    _lblSelectedStation.Text = "⚡ انتخاب: " + dgv.SelectedRows[0].Cells[0].Value;
                    // Re-anchor the right-aligned label after text changes
                    // (AutoSize means the label width changes with content).
                    try
                    {
                        var parentBar = _lblSelectedStation.Parent;
                        if (parentBar != null)
                            _lblSelectedStation.Location = new Point(
                                parentBar.Width - _lblSelectedStation.PreferredWidth - 12,
                                _lblSelectedStation.Location.Y);
                    } catch { }
                }
            };

            // === Add controls: dgv (Fill) + ONE toolbar (Bottom) + statsBar (Top) ===
            // FIX-MONITOR-ADD5 TASK A: removed _detailPanel (40px) and the
            // separate bulk-ops toolbar3 (28px) — dgv now gets the entire
            // remaining vertical space. Bulk ops moved into a dropdown menu
            // shown by the "📦 گروهی ▼" button on the single remaining toolbar.
            this.Controls.Clear();
            this.Controls.Add(dgv);         // back (Fill)
            this.Controls.Add(toolbar1);    // Bottom (34px — per-client actions + bulk dropdown)
            this.Controls.Add(statsBar);    // Top (front-most)
            dgv.SendToBack();
            statsBar.BringToFront();
            this.PerformLayout();
        }

        /// <summary>
        /// FIX RIGHT-PANEL: builds the right-side action panel that replaces
        /// the old right-click context menu. All per-client actions are now
        /// visible as buttons in a scrollable panel on the right edge.
        /// </summary>
        private Panel BuildRightActionPanel()
        {
            var panel = new Panel
            {
                Dock = DockStyle.Right,
                Width = 250,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(8, 8, 8, 8),
                AutoScroll = true,
            };

            int y = 8;
            var font = new Font("Segoe UI", 9F);
            var fontBold = new Font("Segoe UI", 10F, FontStyle.Bold);
            var fontBig = new Font("Segoe UI", 14F, FontStyle.Bold);
            var fontSmall = new Font("Segoe UI", 8F);

            // === بخش ۱: اطلاعات زنده مشتری ===
            var lblInfoHeader = new Label { Text = "📊 اطلاعات زنده", Font = fontBold, ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(lblInfoHeader);
            y += 28;

            // ایستگاه انتخابی
            _lblInfoStation = new Label { Text = "🎯 ایستگاه: ---", Font = font, ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(_lblInfoStation);
            y += 20;

            // IP
            _lblInfoIp = new Label { Text = "🌐 IP: ---", Font = font, ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(_lblInfoIp);
            y += 20;

            // قیمت هر ساعت
            _lblInfoPrice = new Label { Text = "💰 قیمت/ساعت: ---", Font = font, ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(_lblInfoPrice);
            y += 20;

            // کاربر
            _lblInfoUser = new Label { Text = "👤 کاربر: ---", Font = font, ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(_lblInfoUser);
            y += 24;

            // جدول اطلاعات زمان
            var timePanel = new Panel { Location = new Point(8, y), Size = new Size(panel.ClientSize.Width - 16, 90), BackColor = Color.FromArgb(230, 230, 235) };
            int ty = 8;
            Action<string, string, Color> addTimeRow = (label, value, color) =>
            {
                var lbl = new Label { Text = label, Font = fontSmall, ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(8, ty), AutoSize = true };
                var val = new Label { Text = value, Font = new Font("Consolas", 11F, FontStyle.Bold), ForeColor = color, Location = new Point(100, ty), AutoSize = true };
                timePanel.Controls.Add(lbl);
                timePanel.Controls.Add(val);
                ty += 26;
                if (label.Contains("استفاده")) _lblInfoUsed = val;
                else if (label.Contains("باقی")) _lblInfoRemaining = val;
                else if (label.Contains("هزینه")) _lblInfoCost = val;
            };
            addTimeRow("⏱️ استفاده:", "00:00:00", Color.FromArgb(40, 40, 40));
            addTimeRow("⏳ باقی‌مانده:", "نامحدود", Color.FromArgb(249, 226, 175));
            addTimeRow("💸 هزینه:", "۰ ت", Color.FromArgb(243, 139, 168));
            panel.Controls.Add(timePanel);
            y += 100;

            // هشدار ۵ دقیقه‌ای
            var warnPanel = new Panel { Location = new Point(8, y), Size = new Size(panel.ClientSize.Width - 16, 50), BackColor = Color.FromArgb(230, 230, 235) };
            var lblWarn = new Label { Text = "⚠️ هشدار ۵ دقیقه‌ای", Font = fontSmall, ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(8, 6), AutoSize = true };
            _chkWarn5Min = new CheckBox { Text = "فعال", Font = fontSmall, ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(8, 24), Checked = true, AutoSize = true, BackColor = Color.FromArgb(230, 230, 235) };
            var lblBeep = new Label { Text = "🔔 بوق هر دقیقه", Font = fontSmall, ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(120, 6), AutoSize = true };
            _chkBeepMin = new CheckBox { Text = "فعال", Font = fontSmall, ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(120, 24), Checked = true, AutoSize = true, BackColor = Color.FromArgb(230, 230, 235) };
            warnPanel.Controls.AddRange(new Control[] { lblWarn, _chkWarn5Min, lblBeep, _chkBeepMin });
            panel.Controls.Add(warnPanel);
            y += 60;

            // === جدول جداکننده ===
            var sep1 = new Label { Text = new string('─', 30), Font = fontSmall, ForeColor = Color.FromArgb(220, 220, 225), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(sep1);
            y += 20;

            // === بخش ۲: عملیات سریع ===
            // FIX BUTTON-LAYOUT: each button checks IsAdminOnly setting from DB.
            // If IsAdminOnly=true AND user is NOT admin → skip.
            // If IsAdminOnly=false → show to everyone.
            var lblOpsHeader = new Label { Text = "⚡ عملیات سریع", Font = fontBold, ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(lblOpsHeader);
            y += 28;

            // Helper: add a button respecting the admin-only setting from DB.
            Action<string, string, Color, Action<string>> addBtnIfVisible = (key, text, color, action) =>
            {
                // Check if this button is admin-only in the DB.
                bool adminOnly = ButtonLayoutManager.IsAdminOnly(key);
                // If admin-only and user is not admin → don't show.
                if (adminOnly && !IsAdminOperator) return;

                var btn = new Button
                {
                    Text = text, Font = font, ForeColor = Color.FromArgb(40, 40, 40),
                    BackColor = Color.FromArgb(230, 230, 235), FlatStyle = FlatStyle.Flat,
                    Location = new Point(8, y), Size = new Size(panel.ClientSize.Width - 16, 28),
                    Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.FlatAppearance.MouseOverBackColor = color;
                btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(220, 220, 225);
                btn.Click += (s, e) => ActOnSelected(st => action(st));
                panel.Controls.Add(btn);
                y += 32;
            };

            // All buttons — visibility controlled by ButtonLayoutManager.
            addBtnIfVisible("time_add10", "⏱️ +۱۰ دقیقه", Color.FromArgb(249, 226, 175), st => _comm.SetSessionTime(st, 1, 10, "+10"));
            addBtnIfVisible("time_add30", "⏱️ +۳۰ دقیقه", Color.FromArgb(249, 226, 175), st => _comm.SetSessionTime(st, 1, 30, "+30"));
            addBtnIfVisible("time_add60", "⏱️ +۶۰ دقیقه", Color.FromArgb(249, 226, 175), st => _comm.SetSessionTime(st, 1, 60, "+60"));
            addBtnIfVisible("time_unlimited", "♾️ نامحدود", Color.FromArgb(137, 180, 250), st => _comm.SetSessionTime(st, 2, 0, "نامحدود"));
            addBtnIfVisible("time_end", "⏹️ پایان نشست", Color.FromArgb(243, 139, 168), st => _comm.SetSessionTime(st, 3, 0, "پایان"));
            addBtnIfVisible("add_credit", "➕ افزایش اعتبار", Color.FromArgb(166, 227, 161), st => AddCreditToSelectedClient());
            addBtnIfVisible("screenshot", "📷 اسکرین‌شات", Color.FromArgb(203, 166, 247), st => RequestScreenshot());
            addBtnIfVisible("send_message", "💬 پیام", Color.FromArgb(203, 166, 247), st => { string m = InputBox("پیام به " + st + ":", "ارسال پیام"); if (!string.IsNullOrEmpty(m)) _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage, new ServerMessagePayload { Title = "پیام اپراتور", Body = m, Level = "info" })); });
            addBtnIfVisible("unlock_station", "🔓 باز کردن قفل", Color.FromArgb(166, 227, 161), st => { _comm.UnlockStation(st); Log("باز کردن: " + st); });
            addBtnIfVisible("force_logout", "🚪 خروج اجباری", Color.FromArgb(243, 139, 168), st => { if (Confirm("خروج اجباری " + st + "؟")) _comm.ForceLogoutStation(st); });
            addBtnIfVisible("shutdown", "⏻ خاموش کلاینت", Color.FromArgb(243, 139, 168), st => { if (Confirm("⚠️ خاموش " + st + "؟")) _comm.ShutdownStation(st); });
            addBtnIfVisible("restart", "🔄 ری‌استارت", Color.FromArgb(250, 179, 135), st => { if (Confirm("ری‌استارت " + st + "؟")) _comm.RestartStation(st); });
            addBtnIfVisible("internet_off", "🌐 قطع اینترنت", Color.FromArgb(243, 139, 168), st => _comm.ControlInternet(st, false));
            addBtnIfVisible("internet_on", "🌐 وصل اینترنت", Color.FromArgb(166, 227, 161), st => _comm.ControlInternet(st, true));
            addBtnIfVisible("mute_off", "🔇 قطع صدا", Color.FromArgb(243, 139, 168), st => _comm.MuteClient(st, true));
            addBtnIfVisible("mute_on", "🔊 وصل صدا", Color.FromArgb(166, 227, 161), st => _comm.MuteClient(st, false));
            addBtnIfVisible("remote_desktop", "🖥️ مدیریت ریموت", Color.FromArgb(137, 180, 250), st => _comm.RemoteDesktop(st));
            // NEW FEATURE (real video+audio codec, per request): the real
            // built-in alternative to the mstsc.exe launcher above — opens
            // a quality dialog, then starts genuine H.264+AAC streaming.
            addBtnIfVisible("video_stream", "🎥 پخش زنده ویدیو + صدا", Color.FromArgb(203, 166, 247), st => OpenVideoStreamDialog(st));
            // Round 11: live picture in our own window with mouse + keyboard control.
            addBtnIfVisible("live_control", "🖥️ مانیتورینگ + کنترل", Color.FromArgb(137, 180, 250), st => OpenLiveControl(st));

            // === جدول جداکننده ===
            var sep2 = new Label { Text = new string('─', 30), Font = fontSmall, ForeColor = Color.FromArgb(220, 220, 225), Location = new Point(8, y), AutoSize = true };
            panel.Controls.Add(sep2);
            y += 20;

            // === بخش ۳: پنل مدیر (فقط admin) ===
            if (IsAdminOperator)
            {
                var lblAdminHeader = new Label { Text = "👑 پنل مدیر", Font = fontBold, ForeColor = Color.FromArgb(0, 140, 180), Location = new Point(8, y), AutoSize = true };
                panel.Controls.Add(lblAdminHeader);
                y += 28;

                // --- قابلیت‌های قابل فعال/غیرفعال ---
                var lblToggleHeader = new Label { Text = "🎛️ قابلیت‌ها (فعال/غیرفعال)", Font = fontSmall, ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(8, y), AutoSize = true };
                panel.Controls.Add(lblToggleHeader);
                y += 22;

                var adminPanel = new Panel { Location = new Point(8, y), Size = new Size(panel.ClientSize.Width - 16, 220), BackColor = Color.FromArgb(230, 230, 235), AutoScroll = true };
                int ay = 6;
                Action<string, bool> addToggle = (text, defaultOn) =>
                {
                    var cb = new CheckBox { Text = text, Font = fontSmall, ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(8, ay), Checked = defaultOn, AutoSize = true, BackColor = Color.FromArgb(230, 230, 235) };
                    adminPanel.Controls.Add(cb);
                    ay += 24;
                };
                addToggle("🌐 کنترل اینترنت کلاینت", true);
                addToggle("🔊 کنترل صدا", true);
                addToggle("🖥️ مدیریت ریموت", true);
                addToggle("📷 اسکرین‌شات خودکار", false);
                addToggle("📊 مانیتور CPU/RAM", true);
                addToggle("🚫 محدودیت‌ها", false);
                addToggle("📁 مرورگر فایل", false);
                addToggle("🔄 آپدیت خودکار کلاینت", false);
                addToggle("🔒 قفل Task Manager", true);
                addToggle("⌨️ قفل کلید Win", true);
                panel.Controls.Add(adminPanel);
                y += 230;

                // --- دکمه مدیریت چیدمان دکمه‌ها ---
                y += 8;
                var btnLayoutManager = new Button
                {
                    Text = "🎛️ مدیریت چیدمان دکمه‌ها",
                    Font = fontBold,
                    ForeColor = Color.Black,
                    BackColor = Color.FromArgb(0, 240, 255),
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(8, y),
                    Size = new Size(panel.ClientSize.Width - 16, 36),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                };
                btnLayoutManager.FlatAppearance.BorderSize = 0;
                btnLayoutManager.Click += (s, e) => ShowButtonLayoutManager();
                panel.Controls.Add(btnLayoutManager);
            }

            return panel;
        }

        /// <summary>
        /// Shows a dialog where the admin can toggle which buttons are visible
        /// to regular operators vs admin-only.
        /// </summary>
        private void ShowButtonLayoutManager()
        {
            try
            {
                using (var dlg = new Form())
                {
                    dlg.Text = "🎛️ مدیریت چیدمان دکمه‌ها - markazbazi";
                    dlg.Size = new Size(500, 600);
                    dlg.StartPosition = FormStartPosition.CenterParent;
                    dlg.BackColor = Color.FromArgb(240, 240, 240);
                    dlg.ForeColor = Color.FromArgb(40, 40, 40);
                    dlg.RightToLeft = RightToLeft.Yes;
                    dlg.Font = new Font("Segoe UI", 9F);

                    var lblTitle = new Label
                    {
                        Text = "🎛️ مدیریت چیدمان دکمه‌ها",
                        Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                        ForeColor = Color.FromArgb(0, 140, 180),
                        Location = new Point(20, 15),
                        AutoSize = true,
                    };
                    var lblDesc = new Label
                    {
                        Text = "تیک بزنید = فقط مدیر می‌بیند\nتیک بردارید = همه می‌بینند",
                        Font = new Font("Segoe UI", 9F),
                        ForeColor = Color.FromArgb(180, 140, 20),
                        Location = new Point(20, 55),
                        AutoSize = true,
                    };

                    var scrollPanel = new Panel
                    {
                        Location = new Point(20, 100),
                        Size = new Size(440, 400),
                        BackColor = Color.FromArgb(230, 230, 235),
                        AutoScroll = true,
                    };

                    var entries = ButtonLayoutManager.GetAll();
                    int cy = 10;
                    var checkboxes = new Dictionary<string, CheckBox>();
                    foreach (var entry in entries)
                    {
                        var cb = new CheckBox
                        {
                            Text = entry.Label + "  (" + entry.Key + ")",
                            Font = new Font("Segoe UI", 9F),
                            ForeColor = Color.FromArgb(40, 40, 40),
                            Location = new Point(10, cy),
                            Checked = entry.IsAdminOnly,
                            AutoSize = true,
                            BackColor = Color.FromArgb(230, 230, 235),
                        };
                        scrollPanel.Controls.Add(cb);
                        checkboxes[entry.Key] = cb;
                        cy += 28;
                    }

                    var btnSave = new Button
                    {
                        Text = "💾 ذخیره",
                        Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                        ForeColor = Color.Black,
                        BackColor = Color.FromArgb(166, 227, 161),
                        FlatStyle = FlatStyle.Flat,
                        Location = new Point(20, 515),
                        Size = new Size(200, 40),
                        Cursor = Cursors.Hand,
                    };
                    btnSave.FlatAppearance.BorderSize = 0;
                    btnSave.Click += (s, e) =>
                    {
                        try
                        {
                            foreach (var kvp in checkboxes)
                            {
                                ButtonLayoutManager.SetAdminOnly(kvp.Key, kvp.Value.Checked);
                            }
                            MessageBox.Show("✅ تنظیمات ذخیره شد.\nبرای اعمال تغییرات، صفحه کلاینت‌ها رو دوباره باز کنید.", "ذخیره", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dlg.Close();
                        }
                        catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    };

                    var btnCancel = new Button
                    {
                        Text = "انصراف",
                        Font = new Font("Segoe UI", 10F),
                        ForeColor = Color.Black,
                        BackColor = Color.FromArgb(243, 139, 168),
                        FlatStyle = FlatStyle.Flat,
                        Location = new Point(240, 515),
                        Size = new Size(100, 40),
                        Cursor = Cursors.Hand,
                    };
                    btnCancel.FlatAppearance.BorderSize = 0;
                    btnCancel.Click += (s, e) => dlg.Close();

                    dlg.Controls.AddRange(new Control[] { lblTitle, lblDesc, scrollPanel, btnSave, btnCancel });
                    dlg.ShowDialog(this);
                }
            }
            catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        /// <summary>
        /// FIX-MONITOR-ADD5 TASK A: builds the bulk/all-clients operations
        /// menu shown when the operator clicks "📦 گروهی ▼". Replaces the
        /// old toolbar3 panel — same items, just tucked into a dropdown so
        /// the grid gets more vertical space.
        /// </summary>
        private ContextMenuStrip BuildBulkOpsMenu()
        {
            var ctx = new ContextMenuStrip
            {
                BackColor = ThemeManager.SurfaceColor,
                ForeColor = ThemeManager.TextColor,
                Font = new Font("Segoe UI", 9F),
            };
            ctx.Items.Add(Mi("🔓 باز کردن همه", Color.FromArgb(166, 227, 161), (s, e) => { if (Confirm("باز کردن همه؟")) _comm.UnlockAll(); }));
            ctx.Items.Add(Mi("📢 پیام گروهی", Color.FromArgb(148, 226, 213), (s, e) => { string m = InputBox("پیام به همه:", "پیام گروهی"); if (!string.IsNullOrEmpty(m)) { foreach (var c in _comm.GetAllRawConnections()) _comm.SendToStation(c.StationName, new NetMessage(MessageType.ServerMessage, new ServerMessagePayload { Title = "اطلاعیه", Body = m, Level = "info" })); MessageBox.Show("ارسال شد."); } }));
            ctx.Items.Add(Mi("🔇 قطع صدا همه", Color.FromArgb(203, 166, 247), (s, e) => { if (Confirm("قطع صدا همه؟")) { foreach (var c in _comm.GetAllRawConnections()) _comm.MuteClient(c.StationName, true); } }));
            ctx.Items.Add(new ToolStripSeparator());
            ctx.Items.Add(Mi("⏻ خاموش همه", Color.FromArgb(243, 139, 168), (s, e) => { if (Confirm("⚠️ خاموش همه؟")) _comm.ShutdownAll(); }));
            ctx.Items.Add(Mi("🔄 ری‌استارت همه", Color.FromArgb(250, 179, 135), (s, e) => { if (Confirm("ری‌استارت همه؟")) _comm.RestartAll(); }));
            ctx.Items.Add(Mi("⚡ Wake All", Color.FromArgb(166, 227, 161), (s, e) => { if (Confirm("روشن کردن همه؟")) _comm.WakeAll(); }));
            ctx.Items.Add(new ToolStripSeparator());
            ctx.Items.Add(Mi("🖥️ ریموت دسکتاپ", Color.FromArgb(203, 166, 247), (s, e) => ActOnSelected(st => _comm.RemoteDesktop(st))));
            // FIX FEATURE-1: force-close a hung/frozen game. "بستن نرم (Alt+F4)"
            // tries a graceful close first; "بستن اجباری" kills the whole
            // process tree immediately — the one that actually recovers a
            // truly hung game, which previously had NO remedy at all short
            // of physically walking to the machine and holding its power
            // button.
            ctx.Items.Add(Mi("🎮 بستن بازی (نرم)", Color.FromArgb(250, 179, 135), (s, e) => ActOnSelected(st => _comm.CloseGame(st, force: false))));
            ctx.Items.Add(Mi("🎮 بستن بازی (اجباری - برای هنگ کردن)", Color.FromArgb(243, 139, 168), (s, e) => { if (Confirm("بازی به‌صورت اجباری بسته شود؟ کار ذخیره‌نشده از دست می‌رود.")) ActOnSelected(st => _comm.CloseGame(st, force: true)); }));
            ctx.Items.Add(Mi("🔌 USB روشن", Color.FromArgb(148, 226, 213), (s, e) => ActOnSelected(st => _comm.ControlUsb(st, true))));
            ctx.Items.Add(Mi("🚫 USB خاموش", Color.FromArgb(243, 139, 168), (s, e) => ActOnSelected(st => _comm.ControlUsb(st, false))));
            ctx.Items.Add(Mi("🌐 نت روشن", Color.FromArgb(137, 180, 250), (s, e) => ActOnSelected(st => _comm.ControlInternet(st, true))));
            ctx.Items.Add(Mi("🚫 نت قطع", Color.FromArgb(243, 139, 168), (s, e) => ActOnSelected(st => _comm.ControlInternet(st, false))));
            ctx.Items.Add(new ToolStripSeparator());
            ctx.Items.Add(Mi("📊 گزارش مالی", Color.FromArgb(137, 180, 250), (s, e) => { try { new AdvancedReportForm().Show(); } catch { } }));
            ctx.Items.Add(Mi("🎁 تخفیف روزانه", Color.FromArgb(249, 226, 175), (s, e) =>
            {
                string pct = InputBox("درصد تخفیف برای امروز (۱-۱۰۰):", "تخفیف روزانه");
                if (int.TryParse(pct, out int p) && p > 0 && p <= 100)
                {
                    Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('daily_discount_pct', @v)", cmd => cmd.Parameters.AddWithValue("@v", p.ToString()));
                    MessageBox.Show($"✅ تخفیف {p}% برای امروز فعال شد.");
                }
            }));
            ThemeMenu(ctx);
            return ctx;
        }

        private Label MkStat(Panel parent, ref int x, string title, string value, Color color)
        {
            // Compact stat box for the 30px-tall stats bar.
            var pnl = new Panel { Location = new Point(x, 3), Size = new Size(120, 24), BackColor = ThemeManager.SurfaceColor };
            var lblTitle = new Label { Text = title, Font = new Font("Segoe UI", 7F), ForeColor = ThemeManager.TextColor, Location = new Point(5, 1), AutoSize = true };
            var lblValue = new Label { Text = value, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(color), Location = new Point(55, 5), AutoSize = true };
            pnl.Controls.AddRange(new Control[] { lblTitle, lblValue });
            parent.Controls.Add(pnl);
            x += 125;
            return lblValue;
        }

        private Button MkToolBtn(Panel parent, ref int x, string text, Color bg, EventHandler onClick)
        {
            var b = new Button
            {
                Text = text,
                Location = new Point(x, 10),
                Size = new Size(115, 32),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(bg),
            };
            b.Click += onClick;
            parent.Controls.Add(b);
            x += 120;
            return b;
        }

        /// <summary>
        /// Icon + label toolbar button — renders a vector icon (from IconPainter)
        /// to the left of the text, matching the reference image's secondary
        /// action toolbar (Play / Stop / Lock / Camera / Chat / Volume / Shutdown
        /// / Restart / etc.). The icon is recolored to match the dark toolbar.
        /// </summary>
        private Button MkToolBtn(Panel parent, ref int x, string iconName, string text, Color accent, EventHandler onClick)
        {
            var b = new Button
            {
                Text = text,
                Image = IconPainter.Get(iconName, 20),
                ImageAlign = ContentAlignment.MiddleLeft,
                TextAlign = ContentAlignment.MiddleRight,
                Location = new Point(x, 8),
                Size = new Size(125, 34),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(accent),
                Cursor = Cursors.Hand,
            };
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 220, 225);
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(69, 71, 90);
            b.Click += onClick;
            parent.Controls.Add(b);
            x += 130;
            return b;
        }

        // ----------------------------------------------------------------
        //  Right-click context menu — comprehensive HandyCafe-style menu
        //  with login submenus, time/payment/advanced/control categories,
        //  remote management, USB protection, command/BAT send, update.
        // ----------------------------------------------------------------
        private ContextMenuStrip BuildContextMenu()
        {
            var ctx = new ContextMenuStrip
            {
                BackColor = ThemeManager.SurfaceColor,
                ForeColor = ThemeManager.TextColor,
                Font = new Font("Segoe UI", 9F),
            };

            // Helper: dark-themed menu item with accent color.
            Func<string, Color, ToolStripMenuItem> mi = (text, color) =>
                new ToolStripMenuItem(text) { ForeColor = ThemeManager.ThemedAccent(color) };

            // Helper: shows a "coming soon" message for unimplemented items.
            EventHandler soon = (s, e) =>
                MessageBox.Show("این قابلیت به‌زودی", "اطلاع",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

            // ----- 🔑 ورود (Login) -----
            var miLogin = mi("🔑 ورود", Color.FromArgb(166, 227, 161));
            miLogin.DropDownItems.Add("🎮 بازی", null, (s, e) => ActOnSelected(st => { _comm.SendToStation(st, new NetMessage(MessageType.ServerStartSession, new { Mode = "game" })); Log("ورود بازی: " + st); }));
            miLogin.DropDownItems.Add("🌐 همه شبکه", null, (s, e) => ActOnSelected(st => { _comm.SendToStation(st, new NetMessage(MessageType.ServerStartSession, new { Mode = "network" })); Log("ورود شبکه: " + st); }));
            miLogin.DropDownItems.Add("👤 ورود ادمین", null, (s, e) => ActOnSelected(st => { _comm.UnlockStation(st); Log("ورود ادمین: " + st); }));
            miLogin.DropDownItems.Add("🎫 پیش‌پرداخت", null, (s, e) => ActOnSelected(st =>
            {
                string amt = InputBox("مبلغ پیش‌پرداخت برای " + st + " (تومان):", "پیش‌پرداخت");
                if (decimal.TryParse(amt, out decimal a) && a > 0)
                    _comm.SetSessionTime(st, 1, (int)(a / 1000), "پیش‌پرداخت");
            }));
            ctx.Items.Add(miLogin);

            // ----- 🖥️ مانیتورینگ زنده + کنترل (round 11) -----
            ctx.Items.Add(Mi("🖥️ مانیتورینگ زنده + کنترل موس و کیبورد", Color.FromArgb(137, 180, 250), (s, e) => ActOnSelected(st => OpenLiveControl(st))));

            // ----- 🎫 پیش‌پرداخت (Prepaid — quick topup) -----
            ctx.Items.Add(Mi("🎫 پیش‌پرداخت", Color.FromArgb(249, 226, 175), (s, e) =>
                ActOnSelected(st =>
                {
                    string amt = InputBox("مبلغ پیش‌پرداخت برای " + st + " (تومان):", "پیش‌پرداخت سریع");
                    if (decimal.TryParse(amt, out decimal a) && a > 0)
                    {
                        // Find the row's user; if none, just add time as minutes.
                        if (dgv.SelectedRows.Count > 0)
                        {
                            string user = dgv.SelectedRows[0].Cells[3].Value?.ToString();
                            if (!string.IsNullOrEmpty(user) && user != "-")
                                _comm.AddCreditToClient(st, user, a, "پیش‌پرداخت سریع");
                            else
                                _comm.SetSessionTime(st, 1, (int)(a / 1000), "پیش‌پرداخت سریع");
                        }
                    }
                })));

            // ----- 🎮 Play and Pay -----
            ctx.Items.Add(Mi("🎮 Play and Pay", Color.FromArgb(249, 226, 175), (s, e) =>
                ActOnSelected(st =>
                {
                    _comm.SendToStation(st, new NetMessage(MessageType.ServerStartSession, new { Mode = "playandpay" }));
                    Log("حالت Play and Pay: " + st);
                })));

            // ----- 📋 سایر (Other) -----
            var miOther = mi("📋 سایر", Color.FromArgb(148, 226, 213));
            miOther.DropDownItems.Add("💻 تغییر PC", null, (s, e) => ChangePcForSelected());
            ctx.Items.Add(miOther);

            ctx.Items.Add(new ToolStripSeparator());

            // ----- 🚪 خروج (Logout) -----
            ctx.Items.Add(Mi("🚪 خروج", Color.FromArgb(243, 139, 168), (s, e) =>
                ActOnSelected(st => { if (Confirm("خروج " + st + "؟")) { _comm.ForceLogoutStation(st); Log("خروج: " + st); } })));

            // ----- 💳 پرداخت (Payment) -----
            ctx.Items.Add(Mi("💳 پرداخت", Color.FromArgb(166, 227, 161), (s, e) =>
                ActOnSelected(st =>
                {
                    string amt = InputBox("مبلغ پرداخت برای " + st + " (تومان):", "پرداخت");
                    if (decimal.TryParse(amt, out decimal a) && a > 0)
                    {
                        if (dgv.SelectedRows.Count > 0)
                        {
                            string user = dgv.SelectedRows[0].Cells[3].Value?.ToString();
                            if (!string.IsNullOrEmpty(user) && user != "-")
                                _comm.AddCreditToClient(st, user, a, "پرداخت دستی");
                            else
                                _comm.SetSessionTime(st, 1, (int)(a / 1000), "پرداخت دستی");
                        }
                    }
                })));

            // ----- 🔄 ورود مجدد (Relogin) -----
            ctx.Items.Add(Mi("🔄 ورود مجدد", Color.FromArgb(250, 179, 135), (s, e) =>
                ActOnSelected(st =>
                {
                    if (Confirm("ورود مجدد " + st + "؟ (خروج + شروع نشست)"))
                    {
                        _comm.ForceLogoutStation(st, "ورود مجدد");
                        _comm.UnlockStation(st);
                        Log("ورود مجدد: " + st);
                    }
                })));

            // ----- ▶️ ادامه (Continue) -----
            ctx.Items.Add(Mi("▶️ ادامه", Color.FromArgb(166, 227, 161), (s, e) =>
                ActOnSelected(st => { _comm.UnlockStation(st); Log("ادامه نشست: " + st); })));

            ctx.Items.Add(new ToolStripSeparator());

            // ----- ⏱️ زمان (Time) -----
            var miTime = mi("⏱️ زمان", Color.FromArgb(249, 226, 175));
            miTime.DropDownItems.Add("+10 دقیقه", null, (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 10, "+10")));
            miTime.DropDownItems.Add("+30 دقیقه", null, (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 30, "+30")));
            miTime.DropDownItems.Add("+60 دقیقه", null, (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 1, 60, "+60")));
            miTime.DropDownItems.Add(new ToolStripSeparator());
            miTime.DropDownItems.Add("♾️ نامحدود", null, (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 2, 0, "نامحدود")));
            miTime.DropDownItems.Add("⏹️ پایان", null, (s, e) => ActOnSelected(st => _comm.SetSessionTime(st, 3, 0, "پایان")));
            ctx.Items.Add(miTime);

            // ----- 📅 رزرو (Reservation) — round 11 -----
            // One short menu: "new reservation" opens a 3-field window; the next
            // reservations of this PC are listed underneath (click one to cancel it).
            // It used to be two items at the bottom of the time submenu, and the old
            // window needed an existing account and a PC in the stations table.
            var miRes = mi("📅 رزرو", Color.FromArgb(137, 180, 250));
            miRes.DropDownOpening += (s, e) => FillReservationMenu(miRes);
            miRes.DropDownItems.Add("..."); // placeholder so the arrow shows
            ctx.Items.Add(miRes);

            // ----- 💻 تغییر PC (Change PC) -----
            ctx.Items.Add(Mi("💻 تغییر PC", Color.FromArgb(148, 226, 213), (s, e) => ChangePcForSelected()));

            // ----- ❌ لغو پرداخت (Cancel Payment) -----
            // FIX 7: end the source station's session immediately (action=3 =
            // EndNow) and confirm. This is what HandyCafe calls "cancel
            // payment" — the operator voids the running session so the
            // user isn't billed for the remaining time.
            ctx.Items.Add(Mi("❌ لغو پرداخت", Color.FromArgb(243, 139, 168), (s, e) =>
                ActOnSelected(st =>
                {
                    if (!Confirm("لغو پرداخت برای " + st + "؟ نشست فوری پایان می‌یابد.")) return;
                    try
                    {
                        _comm.SetSessionTime(st, 3, 0, "لغو پرداخت");
                        Log("لغو پرداخت: " + st);
                        MessageBox.Show("پرداخت لغو شد.", "لغو پرداخت",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("خطا: " + ex.Message, "خطا",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                })));

            // ----- 🔄 انتقال پرداخت (Transfer Payment) -----
            // FIX 7: end the source session, read the source user's remaining
            // balance, and add that amount as credit to the target station's
            // user (if any). Falls back to adding time to the target station
            // if the target has no logged-in user.
            ctx.Items.Add(Mi("🔄 انتقال پرداخت", Color.FromArgb(250, 179, 135), (s, e) =>
                ActOnSelected(st =>
                {
                    string target = InputBox("انتقال پرداخت از " + st + " به ایستگاه (نام):", "انتقال پرداخت");
                    if (string.IsNullOrWhiteSpace(target)) return;
                    target = target.Trim();
                    try
                    {
                        // Source user + balance
                        string srcUser = null;
                        decimal srcBalance = 0m;
                        if (dgv.SelectedRows.Count > 0)
                        {
                            srcUser = dgv.SelectedRows[0].Cells[3].Value?.ToString();
                            if (!string.IsNullOrEmpty(srcUser) && srcUser != "-")
                            {
                                var u = new UserManager().FindByUsername(srcUser);
                                if (u != null) srcBalance = u.Balance;
                            }
                        }

                        // End the source session (finalises the bill).
                        _comm.SetSessionTime(st, 3, 0, "انتقال پرداخت به " + target);

                        // Add the source balance to the target station's user
                        // (if they have one) or convert to minutes otherwise.
                        var tconn = _comm.GetAllRawConnections()
                            .FirstOrDefault(c => c.StationName == target);
                        if (tconn.StationName != null &&
                            !string.IsNullOrEmpty(tconn.User) && tconn.User != "-" &&
                            srcBalance > 0m)
                        {
                            _comm.AddCreditToClient(target, tconn.User, srcBalance,
                                "انتقال پرداخت از " + st);
                        }
                        else if (srcBalance > 0m)
                        {
                            // No logged-in user on target — convert balance to
                            // minutes at 1000 toman/hour (approximate).
                            int mins = (int)(srcBalance / 1000m * 60m);
                            if (mins > 0) _comm.SetSessionTime(target, 1, mins, "انتقال پرداخت");
                        }

                        Log($"انتقال پرداخت: {st} → {target} (مبلغ: {srcBalance:N0})");
                        MessageBox.Show(
                            $"✅ انتقال پرداخت ثبت شد.\nمنبع: {st}\nهدف: {target}\nمبلغ منتقل‌شده: {srcBalance:N0} تومان",
                            "انتقال پرداخت", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("خطا: " + ex.Message, "خطا",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                })));

            ctx.Items.Add(new ToolStripSeparator());

            // ----- 🔍 پیشرفته (Advanced) -----
            var miAdv = mi("🔍 پیشرفته", Color.FromArgb(203, 166, 247));
            miAdv.DropDownItems.Add("📷 اسکرین‌شات", null, (s, e) => RequestScreenshot());
            // FIX 8: send a request-to-collect message to the kiosk. The
            // client-side handler (ClientEngine.HandleServerMessage) recognises
            // these titles and gathers the data locally, then sends a reply.
            miAdv.DropDownItems.Add("📋 لیست برنامه‌ها", null, (s, e) =>
                ActOnSelected(st =>
                {
                    _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                        new ServerMessagePayload { Title = "app-list-request", Body = "", Level = "info" }));
                    MessageBox.Show("لیست برنامه‌ها درخواست شد.", "لیست برنامه‌ها",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }));
            miAdv.DropDownItems.Add("❌ بستن برنامه فعال", null, (s, e) =>
                ActOnSelected(st => _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                    new ServerMessagePayload { Title = "بستن برنامه فعال", Body = "close-active", Level = "warning" }))));
            miAdv.DropDownItems.Add("📦 برنامه‌های نصب‌شده", null, (s, e) =>
                ActOnSelected(st =>
                {
                    _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                        new ServerMessagePayload { Title = "installed-programs-request", Body = "", Level = "info" }));
                    MessageBox.Show("لیست برنامه‌های نصب‌شده درخواست شد.", "برنامه‌های نصب‌شده",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }));
            miAdv.DropDownItems.Add("🚫 محدودیت‌ها", null, (s, e) =>
                {
                    using (var f = new RestrictionsForm(_comm)) f.ShowDialog(this);
                });
            miAdv.DropDownItems.Add("🌐 وب‌سایت‌های بازدید‌شده", null, (s, e) =>
                ActOnSelected(st =>
                {
                    _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                        new ServerMessagePayload { Title = "visited-websites-request", Body = "", Level = "info" }));
                    MessageBox.Show("لیست وب‌سایت‌های بازدید‌شده درخواست شد.", "وب‌سایت‌های بازدید‌شده",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }));
            var miAdvVol = miAdv.DropDownItems.Add("🔊 کنترل صدا") as ToolStripMenuItem;
            miAdvVol.DropDownItems.Add("🔇 قطع صدا", null, (s, e) => ActOnSelected(st => _comm.MuteClient(st, true)));
            miAdvVol.DropDownItems.Add("🔊 وصل صدا", null, (s, e) => ActOnSelected(st => _comm.MuteClient(st, false)));
            // FIX 8: Browse — prompt for a URL and send it to the kiosk, which
            // opens it in the default browser via Process.Start.
            miAdv.DropDownItems.Add("📁 مرورگر", null, (s, e) =>
                ActOnSelected(st =>
                {
                    string url = InputBox("URL را وارد کنید:", "مرورگر");
                    if (!string.IsNullOrWhiteSpace(url))
                    {
                        _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                            new ServerMessagePayload { Title = "open-url", Body = url.Trim(), Level = "info" }));
                        MessageBox.Show("URL ارسال شد.", "مرورگر",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }));
            miAdv.DropDownItems.Add("🖥️ مدیریت ریموت", null, (s, e) => ActOnSelected(st => _comm.RemoteDesktop(st)));
            ctx.Items.Add(miAdv);

            // ----- 🎛️ کنترل (Control) -----
            var miCtrl = mi("🎛️ کنترل", Color.FromArgb(137, 180, 250));
            // FIX LOCK-REMOVE: removed "🔒 بستن HandyClient" (lock) per user request.
            miCtrl.DropDownItems.Add("🔄 ری‌استارت کلاینت", null, (s, e) =>
                ActOnSelected(st => { if (Confirm("ری‌استارت " + st + "؟")) _comm.RestartStation(st); }));
            miCtrl.DropDownItems.Add("👤 لاگ‌اوف کلاینت", null, (s, e) =>
                ActOnSelected(st => { if (Confirm("لاگ‌اوف " + st + "؟")) _comm.ForceLogoutStation(st, "لاگ‌اوف"); }));
            miCtrl.DropDownItems.Add("⏻ خاموش کلاینت", null, (s, e) =>
                ActOnSelected(st => { if (Confirm("⚠️ خاموش " + st + "؟")) _comm.ShutdownStation(st); }));
            ctx.Items.Add(miCtrl);

            ctx.Items.Add(new ToolStripSeparator());

            // ----- 💬 ارسال پیام (Send Message) -----
            ctx.Items.Add(Mi("💬 ارسال پیام", Color.FromArgb(203, 166, 247), (s, e) =>
                ActOnSelected(st =>
                {
                    string m = InputBox("پیام به " + st + ":", "ارسال پیام");
                    if (!string.IsNullOrEmpty(m))
                        _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                            new ServerMessagePayload { Title = "پیام اپراتور", Body = m, Level = "info" }));
                })));

            // ----- 🌐 ارسال URL (Forward URL) -----
            ctx.Items.Add(Mi("🌐 ارسال URL", Color.FromArgb(137, 180, 250), (s, e) =>
                ActOnSelected(st =>
                {
                    string url = InputBox("آدرس وب‌سایت برای " + st + ":", "ارسال URL");
                    if (!string.IsNullOrEmpty(url))
                        _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                            new ServerMessagePayload { Title = "open-url", Body = url, Level = "info" }));
                })));

            // ----- 📁 ارسال فایل (Send File) -----
            ctx.Items.Add(Mi("📁 ارسال فایل", Color.FromArgb(166, 227, 161), (s, e) =>
                ActOnSelected(st =>
                {
                    using (var dlg = new OpenFileDialog { Title = "فایل برای ارسال به " + st })
                    {
                        if (dlg.ShowDialog() == DialogResult.OK)
                        {
                            try
                            {
                                bool ok = _comm.SendFileToStation(st, dlg.FileName,
                                    System.IO.Path.GetFileName(dlg.FileName), "ارسال از سرور");
                                MessageBox.Show(ok ? "✅ ارسال شد." : "❌ ارسال ناموفق بود.",
                                    "ارسال فایل", MessageBoxButtons.OK,
                                    ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                            }
                            catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا"); }
                        }
                    }
                })));

            ctx.Items.Add(new ToolStripSeparator());

            // ----- ℹ️ اطلاعات سیستم (System Info) -----
            var miInfo = mi("ℹ️ اطلاعات سیستم", Color.FromArgb(148, 226, 213));
            miInfo.DropDownItems.Add("🌐 IP", null, (s, e) => ShowSelectedField("آدرس IP", 1));
            miInfo.DropDownItems.Add("🔌 MAC", null, (s, e) => ShowSelectedField("MAC آدرس", 16)); // colMac (FIX 3)
            miInfo.DropDownItems.Add("💻 OS", null, (s, e) => ShowSelectedField("سیستم‌عامل", 15)); // colOs (FIX 2/3 shifted)
            miInfo.DropDownItems.Add("🔢 نسخه", null, (s, e) => ShowSelectedField("نسخه کلاینت", 17)); // colVersion (FIX 3)
            ctx.Items.Add(miInfo);

            // ----- 🔌 محافظت USB (USB Protection) -----
            var miUsb = mi("🔌 محافظت USB", Color.FromArgb(148, 226, 213));
            miUsb.DropDownItems.Add("✅ روشن", null, (s, e) => ActOnSelected(st => _comm.ControlUsb(st, true)));
            miUsb.DropDownItems.Add("🚫 خاموش", null, (s, e) => ActOnSelected(st => _comm.ControlUsb(st, false)));
            ctx.Items.Add(miUsb);

            // ----- ⌨️ ارسال دستور (Send Command) -----
            var miCmd = mi("⌨️ ارسال دستور", Color.FromArgb(203, 166, 247));
            miCmd.DropDownItems.Add("CMD", null, (s, e) =>
                ActOnSelected(st =>
                {
                    string cmd = InputBox("دستور CMD برای " + st + ":", "ارسال دستور");
                    if (!string.IsNullOrEmpty(cmd))
                        _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                            new ServerMessagePayload { Title = "run-cmd", Body = cmd, Level = "warning" }));
                }));
            miCmd.DropDownItems.Add("PowerShell", null, (s, e) =>
                ActOnSelected(st =>
                {
                    string cmd = InputBox("دستور PowerShell برای " + st + ":", "ارسال دستور");
                    if (!string.IsNullOrEmpty(cmd))
                        _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                            new ServerMessagePayload { Title = "run-powershell", Body = cmd, Level = "warning" }));
                }));
            ctx.Items.Add(miCmd);

            // ----- 📦 ارسال BAT (Send BAT) -----
            ctx.Items.Add(Mi("📦 ارسال BAT", Color.FromArgb(250, 179, 135), (s, e) =>
                ActOnSelected(st =>
                {
                    using (var dlg = new OpenFileDialog
                    {
                        Title = "انتخاب فایل BAT برای " + st,
                        Filter = "Batch files|*.bat;*.cmd|All files|*.*"
                    })
                    {
                        if (dlg.ShowDialog() == DialogResult.OK)
                        {
                            try
                            {
                                // FIX AUDIT-FIX-FINAL Bug E: previously sent
                                // the file via SendFileToStation with targetPath
                                // = the SERVER's full path, which the client's
                                // allow-list validation would reject (path not
                                // in allow-list). Even if the file arrived,
                                // the run-bat body was just the filename
                                // ("test.bat") and the client's
                                // File.Exists(body) check looked in the
                                // process CWD — which is rarely the same as
                                // the file-transfer destination.
                                //
                                // New approach: read the BAT content on the
                                // server and send it INLINE as the run-bat
                                // body. The client's HandleControlMessage
                                // sees body.Length >= 260 or File.Exists is
                                // false, so it writes body to %TEMP%\
                                // gamenet_cmd.bat and runs it via cmd /c.
                                // This works regardless of the kiosk's CWD
                                // and doesn't depend on the file-transfer
                                // allow-list.
                                string batContent = System.IO.File.ReadAllText(dlg.FileName);
                                _comm.SendToStation(st, new NetMessage(MessageType.ServerMessage,
                                    new ServerMessagePayload { Title = "run-bat", Body = batContent, Level = "warning" }));
                                MessageBox.Show("✅ دستور BAT ارسال شد.", "ارسال BAT",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا"); }
                        }
                    }
                })));

            ctx.Items.Add(new ToolStripSeparator());

            // ----- 🔄 آپدیت (Update) -----
            var miUpd = mi("🔄 آپدیت", Color.FromArgb(166, 227, 161));
            miUpd.DropDownItems.Add("🔍 بررسی آپدیت", null, (s, e) => ActOnSelected(st => _comm.OfferUpdate(st)));
            miUpd.DropDownItems.Add("⬇️ آپدیت اجباری", null, (s, e) =>
                ActOnSelected(st =>
                {
                    if (Confirm("آپدیت اجباری " + st + "؟"))
                    {
                        _comm.OfferUpdate(st);
                        Log("آپدیت اجباری: " + st);
                    }
                }));
            ctx.Items.Add(miUpd);

            ctx.Items.Add(new ToolStripSeparator());

            // ----- 🗑️ حذف از لیست (Remove from list) -----
            ctx.Items.Add(Mi("🗑️ حذف از لیست", Color.FromArgb(243, 139, 168), (s, e) =>
                {
                    if (dgv.SelectedRows.Count == 0)
                    { MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه"); return; }
                    string st = dgv.SelectedRows[0].Cells[0].Value?.ToString();
                    if (Confirm("حذف " + st + " از لیست نمایش (اتصال قطع نمی‌شود)؟"))
                    {
                        try
                        {
                            foreach (DataGridViewRow r in dgv.SelectedRows)
                                if (!r.IsNewRow) dgv.Rows.Remove(r);
                            Log("حذف از لیست: " + st);
                        }
                        catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا"); }
                    }
                }));

            // Theme every dropdown so the submenus match the dark palette.
            ThemeMenu(ctx);
            return ctx;
        }

        /// <summary>Recursively applies the dark theme to a menu + all submenus.</summary>
        private static void ThemeMenu(ToolStripDropDown menu)
        {
            menu.BackColor = ThemeManager.SurfaceColor;
            menu.ForeColor = ThemeManager.TextColor;
            menu.RenderMode = ToolStripRenderMode.System;
            foreach (ToolStripItem item in menu.Items)
            {
                if (item is ToolStripMenuItem tsi)
                {
                    // Preserve per-item accent color (already set on ForeColor).
                    if (tsi.ForeColor == Color.Black || tsi.ForeColor.IsEmpty)
                        tsi.ForeColor = ThemeManager.TextColor;
                    else tsi.ForeColor = ThemeManager.ThemedAccent(tsi.ForeColor);
                    tsi.BackColor = ThemeManager.SurfaceColor;
                    if (tsi.HasDropDownItems) ThemeMenu(tsi.DropDown);
                }
                else if (item is ToolStripSeparator sep)
                {
                    sep.BackColor = ThemeManager.SurfaceColor;
                }
            }
        }

        /// <summary>Factory: standalone ToolStripMenuItem with click handler.</summary>
        private static ToolStripMenuItem Mi(string text, Color accent, EventHandler onClick)
        {
            var m = new ToolStripMenuItem(text) { ForeColor = ThemeManager.ThemedAccent(accent) };
            m.Click += onClick;
            return m;
        }

        /// <summary>Shows a MessageBox with a single field from the selected row.</summary>
        private void ShowSelectedField(string label, int colIndex)
        {
            if (dgv.SelectedRows.Count == 0)
            { MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه"); return; }
            string station = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            string value = dgv.SelectedRows[0].Cells[colIndex].Value?.ToString() ?? "-";
            MessageBox.Show($"ایستگاه: {station}\n{label}: {value}", "اطلاعات سیستم",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>Asks the operator for a new station name to "move" the
        /// selected client's session to (logical re-assignment, not a real
        /// session migration — that requires server-side session transfer
        /// which is a separate task).</summary>
        private void ChangePcForSelected()
        {
            if (dgv.SelectedRows.Count == 0)
            { MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه"); return; }
            string cur = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            string neu = InputBox("نام ایستگاه جدید برای انتقال از " + cur + ":", "تغییر PC");
            if (string.IsNullOrWhiteSpace(neu)) return;
            try
            {
                Database.Instance.Execute(
                    "UPDATE client_sessions SET station_name = @n WHERE station_name = @o AND is_connected = 1",
                    cmd => { cmd.Parameters.AddWithValue("@n", neu.Trim()); cmd.Parameters.AddWithValue("@o", cur); });
                // FIX H8: also rename the in-memory ClientInfo so the live grid
                // reflects the change immediately — without this, the monitor
                // kept showing the old name until the kiosk reconnected
                // (ClientInfo.StationName was only ever set in HandleHello).
                _comm.RenameStation(cur, neu.Trim());
                Log("تغییر PC: " + cur + " → " + neu);
                MessageBox.Show($"✅ درخواست تغییر PC ثبت شد:\n{cur} → {neu}", "تغییر PC",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا"); }
        }

        private void Refresh(object s, EventArgs e)
        {
            try
            {
            // FIX M1: refresh the operator-username cache at most once per
            // 60s. The CellFormatting handler reads this set instead of
            // querying the DB per cell paint.
            MaybeRefreshOperatorCache();

            // FIX H10: save the selected station name before clearing so we
            // can restore the selection after re-adding rows. Previously the
            // 2s refresh tick cleared dgv.Rows and re-added them, losing the
            // selection (and the detail-panel CPU/RAM bars) every time.
            string selectedStation = null;
            if (dgv.SelectedRows.Count > 0)
                selectedStation = dgv.SelectedRows[0].Cells[0].Value?.ToString();

            int online = 0, inSession = 0, locked = 0;
            dgv.Rows.Clear();
            int restoreRow = -1;
            foreach (var c in _comm.GetAllRawConnections())
            {
                string state = GetState(c.State);
                if (state.Contains("متصل")) online++;
                if (state.Contains("جلسه")) inSession++;
                if (state.Contains("قفل")) locked++;

                var heartbeat = DateTime.UtcNow - (c.LastHeartbeat);
                string hb = heartbeat.TotalSeconds < 10 ? "🟢 اخیر" : heartbeat.TotalSeconds < 30 ? "🟡 کند" : "🔴 قطع";

                string stationCell = string.IsNullOrEmpty(c.StationName) ? "(نامشخص)" : c.StationName;

                // FIX 2/H2: compute the 4 time columns from the connection tuple.
                //   - start: SessionStart (set in CompleteLogin) converted to
                //            local time, HH:mm:ss. Falls back to ConnectedAt for
                //            clients that haven't logged in yet. Using
                //            ConnectedAt for an in-session client made the
                //            "Used Time" column start before the user logged in.
                //   - end:   derived from TimeCapMinutes (0 = "نامحدود").
                //   - remaining: derived from end - now.
                //   - used:  elapsed since SessionStart, formatted HH:MM:SS.
                DateTime sessionStart = c.SessionStart != default(DateTime) ? c.SessionStart : c.ConnectedAt;
                DateTime startTimeLocal = sessionStart == default(DateTime) ? DateTime.MinValue : sessionStart.ToLocalTime();
                string startStr = startTimeLocal == DateTime.MinValue ? "-" : startTimeLocal.ToString("HH:mm:ss");
                bool isInSession = !string.IsNullOrEmpty(c.User) && c.User != "-" && c.State != ClientState.Disconnected;
                // FIX L14: use the real TimeCapMinutes from the server's
                // SetSessionTime handler instead of always showing "نامحدود".
                string endStr;
                string remainingStr;
                if (isInSession && c.TimeCapMinutes > 0)
                {
                    DateTime endTimeUtc = sessionStart.AddMinutes(c.TimeCapMinutes);
                    endStr = endTimeUtc.ToLocalTime().ToString("HH:mm:ss");
                    var rem = endTimeUtc - DateTime.UtcNow;
                    if (rem.TotalSeconds < 0) rem = TimeSpan.Zero;
                    remainingStr = $"{(int)rem.TotalHours:00}:{rem.Minutes:00}:{rem.Seconds:00}";
                }
                else if (isInSession)
                {
                    endStr = "نامحدود";
                    remainingStr = "نامحدود";
                }
                else
                {
                    endStr = "-";
                    remainingStr = "-";
                }
                string usedStr;
                if (sessionStart == default(DateTime))
                {
                    usedStr = "-";
                }
                else
                {
                    var used = DateTime.UtcNow - sessionStart;
                    if (used.TotalSeconds < 0) used = TimeSpan.Zero;
                    usedStr = $"{(int)used.TotalHours:00}:{used.Minutes:00}:{used.Seconds:00}";
                }

                // FIX M2: surface the REAL MAC and client version from the
                // GetAllRawConnections tuple (was a hardcoded "8.1" string and
                // the IP shown as MAC).
                string mac = string.IsNullOrEmpty(c.MacAddress) ? "-" : c.MacAddress;
                string version = string.IsNullOrEmpty(c.ClientVersion) ? "-" : c.ClientVersion;

                // FIX L11: assertion guards the fragile positional Rows.Add
                // call below — if a future maintainer adds/removes a column
                // in BuildUi without updating the Add args, the runtime
                // throws an ArgumentException at the first refresh. The
                // assertion makes the contract explicit and fires in DEBUG
                // FIX GRID-COLUMNS: only 8 columns now (was 19).
                int rowIdx = dgv.Rows.Add(
                    stationCell,
                    string.IsNullOrEmpty(c.ClientIp) ? "-" : c.ClientIp,
                    state,
                    string.IsNullOrEmpty(c.User) ? "-" : c.User,
                    remainingStr,
                    usedStr,
                    c.Cost > 0 ? c.Cost.ToString("N0") + " ت" : "-",
                    c.Cpu > 0 ? c.Cpu.ToString("0") + "%" : "-"
                );

                // Track which row matches the previously-selected station.
                if (selectedStation != null && stationCell == selectedStation)
                    restoreRow = rowIdx;
            }

            // Restore the selection.
            if (restoreRow >= 0 && restoreRow < dgv.Rows.Count)
            {
                dgv.Rows[restoreRow].Selected = true;
            }

            _lblCount.Text = (_comm.ConnectedClientCount).ToString();
            _lblOnline.Text = online.ToString();
            _lblInSession.Text = inSession.ToString();
            _lblLocked.Text = locked.ToString();

            // FIX RIGHT-PANEL: update the live info labels on the right panel.
            UpdateRightPanelInfo(selectedStation);

            // FIX RIGHT-PANEL: check for 5-minute warning on all in-session clients.
            Check5MinuteWarning();

            // FIX-MONITOR-ADD5 TASK A: the _cpuBar / _ramBar update block was
            // removed along with the _detailPanel — those columns are already
            // visible in the dgv (colCpu, colRam) and the bars just duplicated
            // the same data while stealing 40px of vertical grid space.
            }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine("ClientMonitorForm.Refresh error: " + ex.Message); }
        }

        /// <summary>
        /// Updates the right-side live info panel with the selected station's data.
        /// </summary>
        private void UpdateRightPanelInfo(string selectedStation)
        {
            try
            {
                if (_lblInfoStation == null) return;
                if (string.IsNullOrEmpty(selectedStation) || dgv.SelectedRows.Count == 0)
                {
                    _lblInfoStation.Text = "🎯 ایستگاه: ---";
                    _lblInfoIp.Text = "🌐 IP: ---";
                    _lblInfoPrice.Text = "💰 قیمت/ساعت: ---";
                    _lblInfoUser.Text = "👤 کاربر: ---";
                    if (_lblInfoUsed != null) _lblInfoUsed.Text = "00:00:00";
                    if (_lblInfoRemaining != null) _lblInfoRemaining.Text = "نامحدود";
                    if (_lblInfoCost != null) _lblInfoCost.Text = "۰ ت";
                    return;
                }

                var row = dgv.SelectedRows[0];
                string station = row.Cells[0].Value?.ToString() ?? "---";
                string ip = row.Cells[1].Value?.ToString() ?? "---";
                string user = row.Cells[3].Value?.ToString() ?? "---";
                string remaining = row.Cells[4].Value?.ToString() ?? "نامحدود";
                string used = row.Cells[5].Value?.ToString() ?? "00:00:00";
                string cost = row.Cells[6].Value?.ToString() ?? "۰";

                _lblInfoStation.Text = "🎯 ایستگاه: " + station;
                _lblInfoIp.Text = "🌐 IP: " + ip;
                _lblInfoUser.Text = "👤 کاربر: " + user;

                // Get price per hour from DB
                decimal pricePerHour = 15000;
                try
                {
                    var p = Database.Instance.QueryOne("SELECT price_per_hour FROM pricing WHERE is_default = 1 ORDER BY id DESC LIMIT 1", null, r => r.GetDecimal(0));
                    if (p > 0) pricePerHour = p;
                }
                catch { }
                _lblInfoPrice.Text = "💰 قیمت/ساعت: " + pricePerHour.ToString("N0") + " ت";

                if (_lblInfoUsed != null) _lblInfoUsed.Text = used;
                if (_lblInfoRemaining != null) _lblInfoRemaining.Text = remaining;
                if (_lblInfoCost != null) _lblInfoCost.Text = cost + " ت";
            }
            catch { }
        }

        /// <summary>
        /// Checks all in-session clients for the 5-minute warning.
        /// When ≤5 minutes remain: shows a toast notification.
        /// When ≤5 minutes remain: beeps every minute (if _chkBeepMin is checked).
        /// </summary>
        private void Check5MinuteWarning()
        {
            try
            {
                if (_chkWarn5Min == null || !_chkWarn5Min.Checked) return;
                var conns = _comm?.GetAllRawConnections();
                if (conns == null) return;

                foreach (var c in conns)
                {
                    // Parse remaining time from the connection tuple.
                    // c.TimeCapMinutes = total minutes allotted; c.SessionStart = when session started.
                    if (c.TimeCapMinutes <= 0 || c.SessionStart == default(DateTime))
                    {
                        // unlimited / no session: no warning; forget old state (round 11)
                        _expiredAnnounced.Remove(c.StationName ?? "");
                        _lastWarnByStation.Remove(c.StationName ?? "");
                        continue;
                    }

                    var elapsed = DateTime.UtcNow - c.SessionStart;
                    var total = TimeSpan.FromMinutes(c.TimeCapMinutes);
                    var remaining = total - elapsed;
                    string stKey = c.StationName ?? "";
                    if (remaining.TotalSeconds <= 0)
                    {
                        // Round 11: tell the operator once that this station's time is over.
                        if (_expiredAnnounced.Add(stKey))
                        {
                            try { if (_chkBeepMin == null || _chkBeepMin.Checked) SoundNotification.PlayTimeEnd(stKey); } catch { }
                            try { ToastNotification.Show(this, $"⏰ زمان {stKey} تمام شد", ToastType.Warning, 5000); } catch { }
                        }
                        continue; // already expired
                    }
                    _expiredAnnounced.Remove(stKey); // time was added: announce again next time

                    int remainingMinutes = (int)Math.Ceiling(remaining.TotalMinutes);

                    // 5-minute warning: when remaining crosses 5 minutes
                    int lastForStation;
                    if (!_lastWarnByStation.TryGetValue(stKey, out lastForStation)) lastForStation = -1;
                    if (remainingMinutes > 5) _lastWarnByStation.Remove(stKey);
                    if (remainingMinutes <= 5 && remainingMinutes > 0)
                    {
                        // Show toast notification (only once per minute change, per station)
                        if (remainingMinutes != lastForStation)
                        {
                            _lastWarnByStation[stKey] = remainingMinutes;
                            _lastWarnMinute = remainingMinutes;
                            try
                            {
                                ToastNotification.Show(this,
                                    $"⚠️ هشدار زمان\n{c.StationName}: {remainingMinutes} دقیقه تا پایان نشست",
                                    ToastType.Warning, 5000);
                            }
                            catch { }

                            // Beep if enabled
                            // Round 11: WAV cue instead of Console.Beep, which blocked the UI
                            // thread for 300 ms. The full chime plays at 5 minutes; the later
                            // minutes keep the short system beep.
                            if (_chkBeepMin != null && _chkBeepMin.Checked)
                            {
                                try
                                {
                                    if (remainingMinutes == 5 || lastForStation == -1) SoundNotification.PlayFiveMinutes(stKey);
                                    else System.Media.SystemSounds.Asterisk.Play();
                                }
                                catch { }
                            }

                            // Also send a message to the client kiosk
                            try
                            {
                                _comm.SendToStation(c.StationName, new NetMessage(MessageType.ServerTimeWarning,
                                    new ServerTimeWarningPayload
                                    {
                                        MinutesRemaining = remainingMinutes,
                                        Message = $"⚠️ {remainingMinutes} دقیقه تا پایان نشست شما",
                                        IsCritical = remainingMinutes <= 2
                                    }));
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
        }

        private string GetState(ClientState s)
        {
            switch (s)
            {
                case ClientState.InSession: return "🎮 در جلسه";
                case ClientState.Connected: return "🟢 متصل";
                case ClientState.Locked: return "🔒 قفل";
                case ClientState.Disconnected: return "⚫ قطع";
                default: return s.ToString();
            }
        }

        /// <summary>
        /// FIX M1 — Refreshes the cached set of operator usernames at most
        /// once per 60 seconds. Called from Refresh() (every 2s). The cache
        /// backs the CellFormatting handler so it can tag operator rows
        /// without querying the DB on every cell paint (which fired dozens
        /// of times per second on a busy grid and caused noticeable UI lag).
        /// </summary>
        private void MaybeRefreshOperatorCache()
        {
            if ((DateTime.UtcNow - _operatorCacheAt).TotalSeconds < 60) return;
            try
            {
                var mgr = new OperatorManager();
                // OperatorManager exposes a list-all method on most builds;
                // fall back to the raw DB query if the helper is unavailable.
                var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    foreach (var op in Database.Instance.Query(
                        "SELECT username FROM operators WHERE is_active = 1",
                        null, r => r.GetString(0)))
                    {
                        if (!string.IsNullOrEmpty(op)) names.Add(op);
                    }
                }
                catch { }
                _operatorUsernames = names;
                _operatorCacheAt = DateTime.UtcNow;
            }
            catch { /* keep stale cache; try again next tick */ }
        }

        /// <summary>
        /// FIX DEAD-CONFIG-7: shows just the login or payment actions at
        /// the cursor, based on OptionsForm's DoubleClickAction ("login" or
        /// "payment"). Built fresh each call (mirrors BuildContextMenu's own
        /// pattern) so it always reflects the currently-selected row.
        /// </summary>
        private void ShowDoubleClickMenu()
        {
            string action = "login";
            try { action = OptionsForm.LoadStaticOptions()?.DoubleClickAction ?? "login"; } catch { }

            var popup = new ContextMenuStrip { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 9F) };

            if (action == "payment")
            {
                popup.Items.Add("💳 پرداخت", null, (s, e) => ActOnSelected(st =>
                {
                    string amt = InputBox("مبلغ پرداخت برای " + st + " (تومان):", "پرداخت");
                    if (decimal.TryParse(amt, out decimal a) && a > 0)
                    {
                        string user = dgv.SelectedRows.Count > 0 ? dgv.SelectedRows[0].Cells[3].Value?.ToString() : null;
                        if (!string.IsNullOrEmpty(user) && user != "-")
                            _comm.AddCreditToClient(st, user, a, "پرداخت دستی (دابل‌کلیک)");
                        else
                            _comm.SetSessionTime(st, 1, (int)(a / 1000), "پرداخت دستی (دابل‌کلیک)");
                    }
                }));
            }
            else
            {
                popup.Items.Add("🎮 بازی", null, (s, e) => ActOnSelected(st => { _comm.SendToStation(st, new NetMessage(MessageType.ServerStartSession, new { Mode = "game" })); Log("ورود بازی (دابل‌کلیک): " + st); }));
                popup.Items.Add("🌐 همه شبکه", null, (s, e) => ActOnSelected(st => { _comm.SendToStation(st, new NetMessage(MessageType.ServerStartSession, new { Mode = "network" })); Log("ورود شبکه (دابل‌کلیک): " + st); }));
                popup.Items.Add("👤 ورود ادمین", null, (s, e) => ActOnSelected(st => { _comm.UnlockStation(st); Log("ورود ادمین (دابل‌کلیک): " + st); }));
            }

            popup.Show(Cursor.Position);
        }


        private void ActOnSelected(Action<string> action)
        {
            if (dgv.SelectedRows.Count == 0) { MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه"); return; }
            string st = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            if (!string.IsNullOrEmpty(st) && st != "(نامشخص)") action(st);
        }

        private bool Confirm(string msg) => MessageBox.Show(msg, "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;

        private string InputBox(string prompt, string title)
        {
            return Microsoft.VisualBasic.Interaction.InputBox(prompt, title);
        }

        private void Log(string msg) { try { AuditLog.Log("ClientMonitor", msg); } catch { } }

        /// <summary>
        /// Requests a live screenshot from the selected client and opens a
        /// viewer dialog that auto-refreshes every 10 seconds. Called from
        /// the right-click context menu.
        /// </summary>
        private void RequestScreenshot()
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string stationName = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            if (string.IsNullOrEmpty(stationName) || stationName == "(نامشخص)")
            {
                MessageBox.Show("نام ایستگاه نامعتبر است.", "خطا");
                return;
            }

            // ADD-TOAST-THEME Feature 1: notify via non-blocking toast that
            // the screenshot request was dispatched. The viewer dialog opens
            // immediately after; the toast (top-most, bottom-right anchored)
            // stays visible so the operator can confirm the request went out.
            ToastNotification.Show(this, "📸 درخواست ارسال شد", ToastType.Info, 2500);

            using (var viewer = new ScreenshotViewerForm(stationName, _comm))
            {
                viewer.ShowDialog(this);
            }
        }

        /// <summary>
        /// Adds credit to the selected client's user. Shows a dialog to
        /// enter the amount, adds it via the communicator (which also
        /// notifies the client so its session timer updates), and confirms.
        /// </summary>
        private void AddCreditToSelectedClient()
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("ابتدا یک کلاینت انتخاب کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string stationName = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            string username = dgv.SelectedRows[0].Cells[3].Value?.ToString(); // colUser
            if (string.IsNullOrEmpty(stationName) || stationName == "(نامشخص)")
            {
                MessageBox.Show("نام ایستگاه نامعتبر است.", "خطا");
                return;
            }
            if (string.IsNullOrEmpty(username) || username == "-")
            {
                MessageBox.Show("این کلاینت کاربری در حال بازی ندارد.\nمی‌توانید از تب «👥 کاربران» اعتبار اضافه کنید.", "کاربر ندارد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string amountStr = Microsoft.VisualBasic.Interaction.InputBox(
                $"افزایش اعتبار برای:\nکاربر: {username}\nایستگاه: {stationName}\n\nمبلغ (تومان):",
                "افزایش اعتبار", "10000");
            if (string.IsNullOrWhiteSpace(amountStr)) return;
            if (!decimal.TryParse(amountStr, out decimal amount) || amount <= 0)
            {
                MessageBox.Show("مبلغ معتبر وارد کنید.", "خطا");
                return;
            }

            try
            {
                _comm.AddCreditToClient(stationName, username, amount, "افزایش دستی از مانیتور کلاینت‌ها");
                // ADD-TOAST-THEME Feature 1: success toast instead of modal
                // MessageBox. The client is notified via the existing
                // AddCreditToClient → ServerAddCredit message path; the
                // operator just needs a non-blocking confirmation.
                ToastNotification.Show(this,
                    $"💰 اعتبار اضافه شد\n{username}: +{amount:N0} تومان",
                    ToastType.Success, 3000);
            }
            catch (Exception ex)
            {
                // Error stays modal — the operator needs to see what went
                // wrong (e.g., DB locked, user not found) and act on it.
                MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Round 11: opens the live monitoring + remote control window (not modal, so
        /// several stations can be watched at once; a second click on the same station
        /// brings its window to the front).
        /// </summary>
        private void OpenLiveControl(string station)
        {
            if (string.IsNullOrEmpty(station) || station == "(نامشخص)") return;
            foreach (Form f in Application.OpenForms)
            {
                var lc = f as LiveControlForm;
                if (lc != null && !lc.IsDisposed && lc.Tag as string == station)
                {
                    if (lc.WindowState == FormWindowState.Minimized) lc.WindowState = FormWindowState.Normal;
                    lc.Activate();
                    return;
                }
            }
            try
            {
                var form = new LiveControlForm(station, _comm) { Tag = station };
                form.Show();
                Log("مانیتورینگ زنده: " + station);
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        /// <summary>Round 11: builds the 📅 رزرو submenu for the selected station.</summary>
        private void FillReservationMenu(ToolStripMenuItem miRes)
        {
            miRes.DropDownItems.Clear();
            string station = dgv.SelectedRows.Count > 0 ? dgv.SelectedRows[0].Cells[0].Value?.ToString() : null;
            if (string.IsNullOrEmpty(station) || station == "(نامشخص)")
            {
                miRes.DropDownItems.Add(new ToolStripMenuItem("ابتدا یک سیستم را انتخاب کنید") { Enabled = false });
                return;
            }
            miRes.DropDownItems.Add("➕ رزرو جدید برای " + station + "…", null, (s, e) => ReserveStation());
            miRes.DropDownItems.Add(new ToolStripSeparator());
            List<(int Id, string Name, DateTime Start, DateTime End, string Notes)> list;
            try { list = new ReservationManager().GetUpcoming(station); }
            catch (Exception ex) { list = new List<(int Id, string Name, DateTime Start, DateTime End, string Notes)>(); Log("خطای خواندن رزروها: " + ex.Message); }
            if (list.Count == 0)
                miRes.DropDownItems.Add(new ToolStripMenuItem("رزروی ندارد") { Enabled = false });
            foreach (var r in list)
            {
                var res = r;
                string day = res.Start.Date == DateTime.Today ? "امروز" : res.Start.Date == DateTime.Today.AddDays(1) ? "فردا" : res.Start.ToString("MM/dd");
                bool now = res.Start <= DateTime.Now && res.End > DateTime.Now;
                var item = new ToolStripMenuItem((now ? "🟢 الان " : "🕒 ") + day + " " + res.Start.ToString("HH:mm") + "–" + res.End.ToString("HH:mm") + " · " + res.Name)
                {
                    ToolTipText = "برای لغو کلیک کنید" + (string.IsNullOrEmpty(res.Notes) ? "" : "\n" + res.Notes),
                };
                item.Click += (s, e) =>
                {
                    if (MessageBox.Show(this, "رزرو " + res.Name + " (" + res.Start.ToString("HH:mm") + "–" + res.End.ToString("HH:mm") + ") لغو شود؟",
                        "لغو رزرو", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                    try { new ReservationManager().Cancel(res.Id, "لغو توسط اپراتور"); Log("لغو رزرو: " + station + " · " + res.Name); }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                };
                miRes.DropDownItems.Add(item);
            }
            miRes.DropDownItems.Add(new ToolStripSeparator());
            miRes.DropDownItems.Add("📋 همه رزروهای این سیستم…", null, (s, e) => ViewStationReservations());
        }

        /// <summary>
        /// Opens the PC reservation dialog for the currently-selected station.
        /// Called from the right-click context menu.
        /// </summary>
        private void ReserveStation()
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("ابتدا یک ایستگاه انتخاب کنید (روی آن کلیک کنید).", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string stationName = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            if (string.IsNullOrEmpty(stationName) || stationName == "(نامشخص)")
            {
                MessageBox.Show("نام ایستگاه نامعتبر است.", "خطا");
                return;
            }

            // Round 11: the simple window (name, start, duration).
            using (var dlg = new QuickReservationDialog(stationName))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    Log("رزرو PC: " + stationName + " برای " + dlg.CustomerName + " از " + dlg.StartTime.ToString("HH:mm") + " تا " + dlg.EndTime.ToString("HH:mm"));
                    try { ToastNotification.Show(this, "✅ رزرو ثبت شد\n" + stationName + " · " + dlg.CustomerName + "\n" + dlg.StartTime.ToString("HH:mm") + " تا " + dlg.EndTime.ToString("HH:mm"), ToastType.Success, 4000); } catch { }
                }
            }
        }

        /// <summary>
        /// Shows all reservations for the selected station in a modal list.
        /// Called from the right-click context menu.
        /// </summary>
        private void ViewStationReservations()
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("ابتدا یک ایستگاه انتخاب کنید.", "توجه");
                return;
            }
            string stationName = dgv.SelectedRows[0].Cells[0].Value?.ToString();
            using (var dlg = new StationReservationsDialog(stationName))
            {
                dlg.ShowDialog(this);
            }
        }

        // NEW FEATURE (real video+audio codec, per request): small dialog
        // to pick quality before starting a real H.264+AAC stream from a
        // station. Quality is deliberately adjustable rather than
        // hardcoded — the right tradeoff between smoothness and load on a
        // specific kiosk PC's CPU can't be known in advance without
        // real-hardware testing, which isn't available here.
        private bool _videoStatusSubscribed;
        private void OpenVideoStreamDialog(string stationName)
        {
            if (!_videoStatusSubscribed)
            {
                _comm.OnVideoStreamStatus += OnVideoStreamStatus;
                _videoStatusSubscribed = true;
            }

            using (var dlg = new Form
            {
                Text = "تنظیمات کیفیت پخش زنده: " + stationName,
                Size = new Size(380, 300),
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                MaximizeBox = false,
                MinimizeBox = false,
                RightToLeft = RightToLeft.Yes,
                RightToLeftLayout = true,
            })
            {
                var lblFps = new Label { Text = "نرخ فریم (فریم بر ثانیه):", Location = new Point(15, 15), AutoSize = true };
                var numFps = new NumericUpDown { Location = new Point(15, 38), Size = new Size(120, 26), Minimum = 5, Maximum = 60, Value = 30 }; // round 11: 30 fps default
                var lblScale = new Label { Text = "درصد اندازه تصویر (کمتر = روان‌تر روی سیستم‌های ضعیف):", Location = new Point(15, 72), AutoSize = true, MaximumSize = new Size(340, 0) };
                var numScale = new NumericUpDown { Location = new Point(15, 108), Size = new Size(120, 26), Minimum = 25, Maximum = 100, Value = 100, Increment = 25 };
                var lblBitrate = new Label { Text = "بیت‌ریت ویدیو (کیلوبیت بر ثانیه):", Location = new Point(15, 142), AutoSize = true };
                var numBitrate = new NumericUpDown { Location = new Point(15, 165), Size = new Size(120, 26), Minimum = 500, Maximum = 20000, Increment = 500, Value = 6000 }; // round 11: sharper default
                var chkAudio = new CheckBox { Text = "پخش صدا هم انجام شود (نیازمند فعال‌بودن Stereo Mix روی کلاینت)", Location = new Point(15, 200), Size = new Size(340, 40), Checked = true };

                var btnStart = new Button { Text = "▶️ شروع پخش", Location = new Point(15, 245), Size = new Size(160, 36), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat };
                var btnCancel = new Button { Text = "انصراف", Location = new Point(190, 245), Size = new Size(160, 36), BackColor = Color.FromArgb(220, 220, 225), FlatStyle = FlatStyle.Flat };
                btnStart.Click += (s, e) =>
                {
                    _comm.StartVideoStream(stationName, (int)numFps.Value, (int)numScale.Value, (int)numBitrate.Value, 128, chkAudio.Checked);
                    dlg.DialogResult = DialogResult.OK;
                    dlg.Close();
                    MessageBox.Show(this, "درخواست پخش ارسال شد. اگر روی کلاینت FFmpeg نصب نباشد، پیام خطا نمایش داده خواهد شد.", "در حال شروع...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };
                btnCancel.Click += (s, e) => { dlg.DialogResult = DialogResult.Cancel; dlg.Close(); };

                dlg.Controls.AddRange(new Control[] { lblFps, numFps, lblScale, numScale, lblBitrate, numBitrate, chkAudio, btnStart, btnCancel });
                dlg.ShowDialog(this);
            }
        }

        private void OnVideoStreamStatus(string stationName, VideoStreamStatusPayload status)
        {
            try
            {
                if (this.InvokeRequired) { this.BeginInvoke((Action)(() => ShowVideoStreamStatus(stationName, status))); return; }
                ShowVideoStreamStatus(stationName, status);
            }
            catch { }
        }

        private void ShowVideoStreamStatus(string stationName, VideoStreamStatusPayload status)
        {
            if (status.Started)
            {
                Log($"🎥 پخش زنده برای {stationName} با موفقیت شروع شد.");
            }
            else
            {
                MessageBox.Show(this,
                    "پخش زنده برای " + stationName + " شروع نشد:\n\n" + status.Error +
                    "\n\nاحتمالاً باید FFmpeg را روی این کلاینت نصب کنید (رایگان، از ffmpeg.org) و به PATH ویندوز اضافه کنید.",
                    "خطا در شروع پخش زنده", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Log($"❌ پخش زنده برای {stationName} ناموفق: {status.Error}");
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop();
            _timer?.Dispose();
            if (_videoStatusSubscribed) { try { _comm.OnVideoStreamStatus -= OnVideoStreamStatus; } catch { } }
            base.OnFormClosing(e);
        }
    }

    /// <summary>
    /// Dialog to create a PC station reservation (book a time slot for a
    /// specific kiosk). Validates user, time range, and overlap.
    /// </summary>
    internal class PcReservationDialog : Form
    {
        private readonly ReservationManager _resMgr = new ReservationManager();
        private readonly string _stationName;
        private TextBox _txtUser;
        private DateTimePicker _dtpStart, _dtpEnd;
        private TextBox _txtNotes;

        public string Username { get; private set; }
        public DateTime StartTime { get; private set; }
        public DateTime EndTime { get; private set; }

        public PcReservationDialog(string stationName)
        {
            _stationName = stationName;
            this.Text = "📅 رزرو ایستگاه: " + stationName;
            this.Size = new Size(470, 350);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lblTitle = new Label { Text = "📅 رزرو زمان برای ایستگاه", Font = new Font("Segoe UI", 13F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 12), AutoSize = true };
            var lblStation = new Label { Text = "ایستگاه: " + stationName, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(20, 40), AutoSize = true };

            var lblUser = new Label { Text = "نام کاربری:", Font = new Font("Segoe UI", 10F), Location = new Point(20, 72), AutoSize = true };
            _txtUser = new TextBox { Location = new Point(20, 95), Size = new Size(420, 30), Font = new Font("Segoe UI", 11F), BackColor = Color.White, ForeColor = Color.FromArgb(40, 40, 40) };

            var lblStart = new Label { Text = "از تاریخ/ساعت:", Font = new Font("Segoe UI", 10F), Location = new Point(20, 132), AutoSize = true };
            _dtpStart = new DateTimePicker { Location = new Point(20, 155), Size = new Size(205, 30), Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Font = new Font("Segoe UI", 10F), Value = DateTime.Now.AddHours(1) };

            var lblEnd = new Label { Text = "تا تاریخ/ساعت:", Font = new Font("Segoe UI", 10F), Location = new Point(235, 132), AutoSize = true };
            _dtpEnd = new DateTimePicker { Location = new Point(235, 155), Size = new Size(205, 30), Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Font = new Font("Segoe UI", 10F), Value = DateTime.Now.AddHours(2) };

            var lblNotes = new Label { Text = "یادداشت (اختیاری):", Font = new Font("Segoe UI", 10F), Location = new Point(20, 192), AutoSize = true };
            _txtNotes = new TextBox { Location = new Point(20, 215), Size = new Size(420, 30), Font = new Font("Segoe UI", 10F), BackColor = Color.White, ForeColor = Color.FromArgb(40, 40, 40) };

            var btnOk = new Button { Text = "✓ ثبت رزرو", Location = new Point(20, 260), Size = new Size(205, 38), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)), DialogResult = DialogResult.OK };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(235, 260), Size = new Size(205, 38), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)), DialogResult = DialogResult.Cancel };

            btnOk.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtUser.Text))
                { MessageBox.Show("نام کاربری را وارد کنید.", "توجه"); return; }
                if (_dtpEnd.Value <= _dtpStart.Value)
                { MessageBox.Show("زمان پایان باید بعد از شروع باشد.", "خطا"); return; }
                try
                {
                    _resMgr.Create(_txtUser.Text.Trim(), _stationName, _dtpStart.Value, _dtpEnd.Value, _txtNotes.Text.Trim());
                    Username = _txtUser.Text.Trim();
                    StartTime = _dtpStart.Value;
                    EndTime = _dtpEnd.Value;
                    MessageBox.Show($"✅ رزرو ثبت شد!\n\nایستگاه: {_stationName}\nکاربر: {Username}\nاز: {StartTime:yyyy/MM/dd HH:mm}\nتا: {EndTime:yyyy/MM/dd HH:mm}",
                        "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblStation, lblUser, _txtUser, lblStart, _dtpStart, lblEnd, _dtpEnd, lblNotes, _txtNotes, btnOk, btnCancel });
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }
    }

    /// <summary>
    /// Shows all reservations (active + cancelled) for a given station in a
    /// read-only grid. Lets the operator cancel an active reservation.
    /// </summary>
    internal class StationReservationsDialog : Form
    {
        private readonly ReservationManager _resMgr = new ReservationManager();
        private readonly string _stationName;
        private DataGridView _dgv;
        private Timer _timer;

        public StationReservationsDialog(string stationName)
        {
            _stationName = stationName;
            this.Text = "📋 رزروهای ایستگاه: " + stationName;
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            var lblTitle = new Label { Text = "📋 رزروهای ایستگاه: " + stationName, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Dock = DockStyle.Top, Height = 35, TextAlign = ContentAlignment.MiddleCenter };

            _dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgv.Columns.Add("colId", "شناسه"); _dgv.Columns["colId"].Visible = false;
            _dgv.Columns.Add("colUser", "کاربر");
            _dgv.Columns.Add("colStart", "شروع");
            _dgv.Columns.Add("colEnd", "پایان");
            _dgv.Columns.Add("colStatus", "وضعیت");
            _dgv.Columns.Add("colNotes", "یادداشت");

            _dgv.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (_dgv.Columns[e.ColumnIndex].Name == "colStatus")
                {
                    var v = e.Value?.ToString() ?? "";
                    if (v == "active") { e.CellStyle.ForeColor = Color.FromArgb(20, 130, 50); e.Value = "🟢 فعال"; }
                    else if (v == "cancelled") { e.CellStyle.ForeColor = Color.FromArgb(200, 30, 60); e.Value = "❌ لغو شده"; }
                }
            };

            var toolbar = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(10, 7), Size = new Size(120, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRefresh.Click += (s, e) => LoadReservations();
            var btnCancelRes = new Button { Text = "❌ لغو رزرو انتخاب‌شده", Location = new Point(140, 7), Size = new Size(200, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnCancelRes.Click += (s, e) =>
            {
                if (_dgv.SelectedRows.Count == 0) { MessageBox.Show("یک رزرو انتخاب کنید."); return; }
                int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
                string reason = Microsoft.VisualBasic.Interaction.InputBox("دلیل لغو:", "لغو رزرو", "لغو توسط اپراتور");
                if (string.IsNullOrWhiteSpace(reason)) return;
                try { _resMgr.Cancel(id, reason); LoadReservations(); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };
            toolbar.Controls.AddRange(new Control[] { btnRefresh, btnCancelRes });

            this.Controls.AddRange(new Control[] { _dgv, toolbar, lblTitle });

            LoadReservations();
            _timer = new Timer { Interval = 5000 };
            _timer.Tick += (s, e) => LoadReservations();
            _timer.Start();
        }

        private void LoadReservations()
        {
            _dgv.Rows.Clear();
            var reservations = Database.Instance.Query(
                "SELECT id, username, start_time, end_time, status, notes FROM reservations WHERE station_name = @s ORDER BY start_time DESC",
                cmd => cmd.Parameters.AddWithValue("@s", _stationName),
                r => (
                    r.GetInt32(0),
                    r.GetString(1),
                    r.GetDateTime(2),
                    r.GetDateTime(3),
                    r.GetString(4),
                    r.IsDBNull(5) ? "" : r.GetString(5)
                ));
            foreach (var r in reservations)
                _dgv.Rows.Add(r.Item1, r.Item2, r.Item3.ToString("yyyy/MM/dd HH:mm"), r.Item4.ToString("yyyy/MM/dd HH:mm"), r.Item5, r.Item6);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }

    /// <summary>
    /// Modal dialog that shows a live screenshot of a client kiosk and
    /// auto-refreshes every 10 seconds. Subscribes to the communicator's
    /// OnScreenshotReceived event so the response is shown as soon as it
    /// arrives. Also lets the operator manually refresh and save the image.
    /// </summary>
    internal class ScreenshotViewerForm : Form
    {
        private readonly string _stationName;
        private readonly ClientCommunicator _comm;
        private PictureBox _pictureBox;
        private Label _lblStatus, _lblInfo;
        private Button _btnRefresh, _btnSave, _btnAutoRefresh, _btnControl;
        private Timer _autoTimer;
        private bool _subscribed;
        private bool _autoRefresh = true;
        // NEW FEATURE (remote input, per request): off by default — moving
        // the mouse over the preview to just LOOK at it should never move
        // the customer's actual cursor. The operator explicitly turns this
        // on when they intend to take control.
        private bool _controlEnabled = false;
        private DateTime _lastReceived;
        private int _lastImgWidth, _lastImgHeight;

        public ScreenshotViewerForm(string stationName, ClientCommunicator comm)
        {
            _stationName = stationName;
            _comm = comm;
            this.Text = "📸 مانیتورینگ زنده: " + stationName;
            this.Size = new Size(1000, 620);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            // Needed so KeyDown/KeyUp fire on this form while in control
            // mode, regardless of which child control notionally has focus.
            this.KeyPreview = true;

            BuildUi();

            try
            {
                _comm.OnScreenshotReceived += OnScreenshotReceived;
                _subscribed = true;
            }
            catch { }

            // BUG FIX (per request): this used to refresh once every 10
            // SECONDS (~0.1 FPS) — not laggy, just never built as anything
            // resembling live video. 400ms (~2.5 FPS) is a large, honest
            // improvement over a full-resolution JPEG-over-TCP request/
            // response design without saturating a typical LAN or the
            // client's CPU on every single frame. This is still frame
            // polling, not a true video codec — see the chat message
            // alongside this fix for that distinction stated plainly.
            // Round 11: every 400 ms (150 requests a minute) went past the server's
            // 30-messages-per-minute limit per station within seconds, and the limiter
            // then dropped ALL of that station's messages for 15 minutes (heartbeats too,
            // so the station looked offline). 3 s stays inside the limit. For a smooth
            // picture use "مانیتورینگ زنده + کنترل" (LiveControlForm).
            _autoTimer = new Timer { Interval = 3000 };
            _autoTimer.Tick += (s, e) => { if (_autoRefresh) RequestNew(); };
            _autoTimer.Start();

            // Request the first screenshot immediately
            RequestNew();
        }

        private void BuildUi()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.FromArgb(240, 240, 240) };
            _lblStatus = new Label { Text = "⏳ در حال درخواست تصویر...", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(15, 15), AutoSize = true };
            _btnRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(340, 10), Size = new Size(100, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            _btnRefresh.Click += (s, e) => RequestNew();
            _btnSave = new Button { Text = "💾 ذخیره", Location = new Point(450, 10), Size = new Size(100, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            _btnSave.Click += (s, e) => SaveCurrent();
            _btnAutoRefresh = new Button { Text = "⏱️ توقف خودکار", Location = new Point(560, 10), Size = new Size(130, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            _btnAutoRefresh.Click += (s, e) =>
            {
                _autoRefresh = !_autoRefresh;
                _btnAutoRefresh.Text = _autoRefresh ? "⏱️ توقف خودکار" : "▶️ شروع خودکار";
                _btnAutoRefresh.BackColor = _autoRefresh ? Color.FromArgb(243, 139, 168) : Color.FromArgb(166, 227, 161);
            };
            // NEW FEATURE (remote input, per request): explicit on/off
            // toggle for taking control, kept visually distinct (red when
            // live) so it's always obvious to the operator whether their
            // mouse/keyboard is currently being forwarded to the customer's
            // PC.
            _btnControl = new Button { Text = "🖱️ کنترل: خاموش", Location = new Point(700, 10), Size = new Size(150, 32), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 30, 46) };
            _btnControl.Click += (s, e) =>
            {
                _controlEnabled = !_controlEnabled;
                _btnControl.Text = _controlEnabled ? "🖱️ کنترل: روشن" : "🖱️ کنترل: خاموش";
                _btnControl.BackColor = _controlEnabled ? Color.FromArgb(243, 139, 168) : Color.FromArgb(166, 227, 161);
                if (_controlEnabled) this.ActiveControl = _pictureBox; // ensure key events reach us
            };
            toolbar.Controls.AddRange(new Control[] { _lblStatus, _btnRefresh, _btnSave, _btnAutoRefresh, _btnControl });

            _pictureBox = new PictureBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(20, 20, 31),
                SizeMode = PictureBoxSizeMode.Zoom,
                TabStop = true,
            };
            // NEW FEATURE (remote input): forward mouse events to the
            // client whenever control mode is on. NormalizedFromClient
            // accounts for PictureBoxSizeMode.Zoom's letterboxing — the
            // displayed image is centered and scaled to fit while
            // preserving aspect ratio, so a raw pixel position within the
            // PictureBox is NOT the same as a position within the image
            // without correcting for that offset and scale first.
            _pictureBox.MouseMove += (s, e) => SendMouseEvent("mousemove", e);
            _pictureBox.MouseDown += (s, e) => SendMouseEvent("mousedown", e);
            _pictureBox.MouseUp += (s, e) => SendMouseEvent("mouseup", e);
            _pictureBox.MouseWheel += (s, e) => SendMouseEvent("mousewheel", e);
            _pictureBox.Click += (s, e) => { if (_controlEnabled) this.ActiveControl = _pictureBox; };

            _lblInfo = new Label { Dock = DockStyle.Bottom, Height = 25, Text = "", Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(20, 140, 130), BackColor = Color.FromArgb(240, 240, 240), TextAlign = ContentAlignment.MiddleCenter };

            this.Controls.AddRange(new Control[] { _pictureBox, _lblInfo, toolbar });

            // NEW FEATURE (remote input): keyboard forwarding while control
            // mode is on. KeyPreview=true (set in the constructor) means
            // these fire regardless of which child control has focus.
            this.KeyDown += (s, e) => { if (_controlEnabled) { _comm.SendRemoteInput(_stationName, "keydown", 0, 0, keyCode: (int)e.KeyCode); e.Handled = true; e.SuppressKeyPress = true; } };
            this.KeyUp += (s, e) => { if (_controlEnabled) { _comm.SendRemoteInput(_stationName, "keyup", 0, 0, keyCode: (int)e.KeyCode); e.Handled = true; } };
        }

        /// <summary>
        /// Converts a mouse event's PictureBox-relative pixel position into
        /// the 0.0–1.0 normalized coordinates ServerRemoteInput expects,
        /// correctly accounting for PictureBoxSizeMode.Zoom's letterboxing.
        /// Does nothing if control mode is off, or if the click landed in
        /// the letterbox bars rather than on the actual image.
        /// </summary>
        private void SendMouseEvent(string type, MouseEventArgs e)
        {
            if (!_controlEnabled) return;
            if (_pictureBox.Image == null || _lastImgWidth == 0 || _lastImgHeight == 0) return;

            double scale = Math.Min((double)_pictureBox.Width / _lastImgWidth, (double)_pictureBox.Height / _lastImgHeight);
            double displayedW = _lastImgWidth * scale;
            double displayedH = _lastImgHeight * scale;
            double offsetX = (_pictureBox.Width - displayedW) / 2.0;
            double offsetY = (_pictureBox.Height - displayedH) / 2.0;

            double imgX = e.X - offsetX;
            double imgY = e.Y - offsetY;
            // Outside the actual displayed image (in the letterbox bars) —
            // ignore rather than send a nonsensical position.
            if (imgX < 0 || imgY < 0 || imgX > displayedW || imgY > displayedH) return;

            double normX = imgX / displayedW;
            double normY = imgY / displayedH;
            string button = e.Button == MouseButtons.Right ? "right" : e.Button == MouseButtons.Middle ? "middle" : "left";
            try { _comm.SendRemoteInput(_stationName, type, normX, normY, button, e.Delta); } catch { }
        }

        private void RequestNew()
        {
            _lblStatus.Text = "⏳ در حال درخواست تصویر...";
            _lblStatus.ForeColor = Color.FromArgb(180, 140, 20);
            try { _comm.RequestScreenshot(_stationName, 75); }
            catch (Exception ex) { _lblStatus.Text = "❌ خطا: " + ex.Message; _lblStatus.ForeColor = Color.FromArgb(200, 30, 60); }
        }

        private void OnScreenshotReceived(string station, ScreenshotResponsePayload payload)
        {
            if (station != _stationName) return;
            try
            {
                if (this.InvokeRequired)
                    this.BeginInvoke((Action)(() => ApplyScreenshot(payload)));
                else
                    ApplyScreenshot(payload);
            }
            catch { }
        }

        private void ApplyScreenshot(ScreenshotResponsePayload payload)
        {
            if (payload == null || !payload.Success || string.IsNullOrEmpty(payload.ImageBase64))
            {
                _lblStatus.Text = "❌ خطا: " + (payload?.Error ?? "تصویر دریافت نشد");
                _lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
                return;
            }
            try
            {
                byte[] bytes = Convert.FromBase64String(payload.ImageBase64);
                // FIX (FIX-FINAL-10 B3): do NOT dispose the MemoryStream.
                // Image.FromStream keeps a reference to the stream and reads
                // from it lazily. Disposing the stream (via `using`) right
                // after FromStream leaves the Image holding a disposed
                // stream — the next paint throws ArgumentException ("Parameter
                // is not valid") or renders a blank box. Let the Image own
                // the stream; it gets disposed when the PictureBox.Image is
                // replaced (previous Image.Dispose() below) or when the
                // form closes.
                var ms = new System.IO.MemoryStream(bytes);
                var img = System.Drawing.Image.FromStream(ms);
                if (_pictureBox.Image != null) _pictureBox.Image.Dispose();
                _pictureBox.Image = img;
                // NEW FEATURE (remote input): remembered so SendMouseEvent
                // can correctly map PictureBox pixel coordinates back to the
                // image's own coordinate space (see its comment above).
                _lastImgWidth = payload.Width;
                _lastImgHeight = payload.Height;
                _lastReceived = payload.CapturedAt.ToLocalTime();
                _lblStatus.Text = "✅ دریافت شد: " + _lastReceived.ToString("HH:mm:ss");
                _lblStatus.ForeColor = Color.FromArgb(20, 130, 50);
                _lblInfo.Text = $"{_stationName}  |  {payload.Width}×{payload.Height}  |  {bytes.Length / 1024} KB  |  آخرین به‌روزرسانی: {_lastReceived:HH:mm:ss}"
                    + (_controlEnabled ? "  |  🖱️ کنترل از راه دور فعال است" : "");
            }
            catch (Exception ex)
            {
                _lblStatus.Text = "❌ خطای پردازش تصویر: " + ex.Message;
                _lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
            }
        }

        private void SaveCurrent()
        {
            if (_pictureBox.Image == null) { MessageBox.Show("تصویری برای ذخیره وجود ندارد."); return; }
            using (var dlg = new SaveFileDialog { Filter = "JPEG|*.jpg", FileName = $"screenshot_{_stationName}_{DateTime.Now:yyyyMMdd_HHmmss}.jpg" })
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try { _pictureBox.Image.Save(dlg.FileName, System.Drawing.Imaging.ImageFormat.Jpeg); MessageBox.Show("ذخیره شد."); }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); }
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_subscribed) try { _comm.OnScreenshotReceived -= OnScreenshotReceived; } catch { }
            _autoTimer?.Stop(); _autoTimer?.Dispose();
            if (_pictureBox.Image != null) { _pictureBox.Image.Dispose(); }
            base.OnFormClosing(e);
        }
    }
}
