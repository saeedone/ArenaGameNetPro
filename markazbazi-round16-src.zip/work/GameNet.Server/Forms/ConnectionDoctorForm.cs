using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared.Diagnostics;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Round 15: "🩺 عیب‌یابی اتصال" — everything on the server side that decides whether
    /// kiosks appear: listening port, TLS and where the certificate is read from (and the
    /// working folder, the usual reason a certificate "disappears"), this server's IP
    /// addresses (to type on the kiosks), Windows Firewall with a fix button, stations
    /// connected now, stations ignored by the message limit, and the refused connections
    /// of the last hours with their reason.
    /// </summary>
    internal sealed class ConnectionDoctorForm : Form
    {
        private readonly ClientCommunicator _comm;
        private readonly TextBox _box;
        private readonly DataGridView _grid;
        private readonly Button _btnFix, _btnRefresh;

        public ConnectionDoctorForm(ClientCommunicator comm)
        {
            _comm = comm;
            Text = "🩺 عیب‌یابی اتصال";
            Size = new Size(1100, 720);
            BackColor = Color.White;
            RightToLeft = RightToLeft.Yes;
            Font = new Font("Segoe UI", 10F);

            var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(8, 8, 8, 0), FlowDirection = FlowDirection.RightToLeft, BackColor = Color.FromArgb(240, 242, 247) };
            _btnRefresh = Mk("🔄 بررسی دوباره", Color.FromArgb(30, 80, 180));
            _btnFix = Mk("🔧 درست کردن فایروال ویندوز", Color.FromArgb(200, 90, 20));
            var btnCopy = Mk("📋 کپی گزارش", Color.FromArgb(90, 90, 110));
            _btnRefresh.Click += (s, e) => Reload(true);
            _btnFix.Click += (s, e) =>
            {
                _btnFix.Enabled = false;
                bool ok = false;
                try { ok = ServerFirewall.Fix(this); } catch { }
                _btnFix.Enabled = true;
                MessageBox.Show(this, ok ? "✅ فایروال برای کیوسک‌ها باز شد." : "انجام نشد (تأیید مدیر ویندوز داده نشد؟). سرور را با «Run as administrator» باز کنید و دوباره بزنید.", "فایروال", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                Reload(false);
            };
            btnCopy.Click += (s, e) => { try { Clipboard.SetText(_box.Text); } catch { } };
            bar.Controls.AddRange(new Control[] { _btnRefresh, _btnFix, btnCopy });

            _box = new TextBox { Multiline = true, ReadOnly = true, Dock = DockStyle.Top, Height = 330, ScrollBars = ScrollBars.Vertical, BackColor = Color.White, Font = new Font("Segoe UI", 10.5F), RightToLeft = RightToLeft.Yes };
            var lblGrid = new Label { Dock = DockStyle.Top, Height = 28, Text = "  اتصال‌های ردشده و مشکلات شبکه در ۶ ساعت اخیر (جدیدترین بالا):", Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 60, 140), TextAlign = ContentAlignment.MiddleRight };
            _grid = new DataGridView
            {
                Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = Color.White, BorderStyle = BorderStyle.None,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, EnableHeadersVisualStyles = false,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(232, 236, 245), ForeColor = Color.FromArgb(30, 60, 140) },
                DefaultCellStyle = new DataGridViewCellStyle { ForeColor = Color.Black, WrapMode = DataGridViewTriState.True },
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
            };
            _grid.Columns.Add("t", "زمان"); _grid.Columns["t"].FillWeight = 10;
            _grid.Columns.Add("c", "کد"); _grid.Columns["c"].FillWeight = 8;
            _grid.Columns.Add("w", "علت"); _grid.Columns["w"].FillWeight = 30;
            _grid.Columns.Add("a", "چه باید کرد"); _grid.Columns["a"].FillWeight = 32;
            _grid.Columns.Add("d", "جزئیات (IP و ...)"); _grid.Columns["d"].FillWeight = 20;

            Controls.Add(_grid); Controls.Add(lblGrid); Controls.Add(_box); Controls.Add(bar);
            // Embedded in a tab (not a top-level window), so Shown never fires: the first
            // time it becomes visible the firewall is checked too.
            bool first = true;
            VisibleChanged += (s, e) => { if (Visible) { Reload(first); first = false; } };
        }

        private static Button Mk(string t, Color c)
        {
            var b = new Button { Text = t, AutoSize = true, Height = 30, FlatStyle = FlatStyle.Flat, BackColor = c, ForeColor = Color.White, Margin = new Padding(6, 0, 0, 0), Font = new Font("Segoe UI", 9.5F, FontStyle.Bold) };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private void Reload(bool recheckFirewall)
        {
            if (recheckFirewall)
            {
                // netsh can take a few seconds: check in the background, then redraw.
                _btnRefresh.Enabled = false;
                System.Threading.ThreadPool.QueueUserWorkItem(_ =>
                {
                    string why;
                    try { ServerFirewall.Check(out why); } catch { }
                    try { BeginInvoke((Action)(() => { _btnRefresh.Enabled = true; Reload(false); })); } catch { }
                });
            }
            var sb = new StringBuilder();
            Action<string, string> line = (i, t) => sb.Append(i).Append("  ").Append(t).Append("\r\n");
            try
            {
                int port = _comm?.Port ?? 0;
                line("ℹ️", "سرور روی پورت " + port + " منتظر کیوسک‌هاست. همین عدد باید در تنظیمات اتصال کیوسک‌ها باشد.");

                var ips = new List<string>();
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address))
                            ips.Add(ua.Address + " (" + ni.Name + ")");
                }
                line("ℹ️", "IP این سرور (این را در «تنظیمات کلاینت › General» کیوسک‌ها بنویسید): " + (ips.Count == 0 ? "هیچ — کارت شبکه وصل نیست!" : string.Join("   ·   ", ips)));

                bool tls = _comm != null && _comm.UseTls;
                line("ℹ️", "TLS سرور: " + (tls ? "روشن" : "خاموش") + " — در همهٔ کیوسک‌ها هم باید " + (tls ? "روشن" : "خاموش") + " باشد.");
                string certPath = _comm?.CertificateFullPath ?? "";
                string exeDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
                string cwd = Environment.CurrentDirectory.TrimEnd('\\');
                if (tls)
                {
                    if (_comm.CertificateLoaded) line("✅", "گواهی TLS بارگذاری شد: " + certPath);
                    else line("❌", "گواهی TLS بارگذاری نشد (" + certPath + "). با TLS روشن، سرور همهٔ کیوسک‌ها را رد می‌کند و هیچ سیستمی نشان داده نمی‌شود.");
                    string certDir = "";
                    try { certDir = Path.GetDirectoryName(certPath).TrimEnd('\\'); } catch { }
                    if (!string.Equals(certDir, exeDir, StringComparison.OrdinalIgnoreCase))
                        line("❌", "سرور از پوشهٔ «" + cwd + "» اجرا شده، نه از پوشهٔ خودش («" + exeDir + "»). برای همین گواهی در جای دیگری جست‌وجو یا تازه ساخته می‌شود و کیوسک‌هایی که کلید قبلی را ذخیره کرده‌اند وصل نمی‌شوند. این اتفاق با «اجرای خودکار ویندوز» یا میان‌بری که «Start in» آن پوشهٔ دیگری است رخ می‌دهد. فعلاً سرور را با دوبار کلیک روی خود GameNet.Server.exe باز کنید (پیشنهاد P1).");
                }

                line(ServerFirewall.LastOk ? "✅" : "❌", "فایروال ویندوز: " + ServerFirewall.LastStatus + (ServerFirewall.LastOk ? "" : " — دکمهٔ «درست کردن فایروال ویندوز» را بزنید."));

                int all = _comm?.ConnectedClientCount ?? 0, welcomed = _comm?.WelcomedCount ?? 0;
                line(welcomed > 0 ? "✅" : "⚠️", "الان " + welcomed + " کیوسک وصل و پذیرفته شده" + (all > welcomed ? "، و " + (all - welcomed) + " اتصال هنوز خودش را معرفی نکرده (در حال اتصال...)" : "") + ".");
                if (all > welcomed)
                    line("ℹ️", "اتصالی که «در حال اتصال» می‌ماند معمولاً یعنی TLS دو طرف یکی نیست یا کیوسک کلید قدیمی سرور را دارد. روی همان کیوسک «🩺 تست اتصال به سرور» را بزنید.");

                var blocked = _comm?.RateLimitedNow() ?? new List<GameNet.Server.Core.BlockedEntry>();
                if (blocked.Count == 0) line("✅", "هیچ کیوسکی به‌خاطر پیام زیاد مسدود نیست.");
                foreach (var b in blocked)
                    line("❌", b.Key + " به‌خاطر بیش از ۳۰ پیام در دقیقه تا " + b.BlockedUntil.ToLocalTime().ToString("HH:mm") + " نادیده گرفته می‌شود و در این مدت نشان داده نمی‌شود (پیشنهاد P18).");

                string password = "";
                try { password = OptionsForm.LoadStaticOptions()?.ServerClientPassword ?? ""; } catch { }
                line("ℹ️", string.IsNullOrEmpty(password)
                    ? "رمز اتصال کیوسک در سرور خالی است، پس بررسی نمی‌شود."
                    : "رمز اتصال کیوسک تنظیم شده (" + password.Length + " حرف). باید با «Server/Client Password» زبانهٔ Advanced کیوسک‌ها یکی باشد (پیش‌فرض کیوسک: HANDYCAFE).");
            }
            catch (Exception ex) { line("❌", "بررسی کامل نشد: " + ex.Message); }
            _box.Text = sb.ToString();

            // refused connections and network faults (server journal, last 6 hours)
            try
            {
                _grid.Rows.Clear();
                var since = DateTime.UtcNow.AddHours(-6);
                var hist = FaultJournal.ReadHistory(2000);
                for (int i = hist.Count - 1; i >= 0; i--)
                {
                    var r = hist[i];
                    if (r.TimeUtc < since || r.Code == null) continue;
                    if (!(r.Code.StartsWith("NET") || r.Code.StartsWith("TLS") || r.Code.StartsWith("AUTH") || r.Code == "SRV-004" || r.Code.StartsWith("CFG"))) continue;
                    _grid.Rows.Add(r.TimeUtc.ToLocalTime().ToString("MM/dd HH:mm:ss"), r.Code, r.Title + " — " + r.Cause, r.Action, r.Detail);
                    if (_grid.Rows.Count >= 300) break;
                }
                if (_grid.Rows.Count == 0) _grid.Rows.Add("", "", "در ۶ ساعت اخیر هیچ اتصال ردشده یا مشکل شبکه‌ای ثبت نشده.", "اگر کیوسک‌ها باز هم دیده نمی‌شوند، اتصالشان اصلاً به سرور نمی‌رسد: فایروال سرور یا IP/پورت کیوسک.", "");
            }
            catch { }
        }
    }
}
