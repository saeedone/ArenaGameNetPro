using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Reports form: revenue, station utilization, top users with date range filter.
    /// </summary>
    public class ReportForm : Form
    {
        private DateTimePicker _dtpFrom, _dtpTo;
        private ComboBox _cmbReportType;
        private ListView _lvData;
        private Label _lblSummary;

        public ReportForm()
        {
            this.Text = "گزارش‌ها - GameNet";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Filter panel
            var lblFrom = new Label { Text = "از تاریخ:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpFrom = new DateTimePicker { Location = new Point(100, 12), Size = new Size(200, 30), Format = DateTimePickerFormat.Short, Value = DateTime.UtcNow.Date.AddDays(-30) };

            var lblTo = new Label { Text = "تا تاریخ:", Location = new Point(320, 15), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpTo = new DateTimePicker { Location = new Point(400, 12), Size = new Size(200, 30), Format = DateTimePickerFormat.Short, Value = DateTime.UtcNow.Date };

            var lblType = new Label { Text = "نوع گزارش:", Location = new Point(620, 15), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cmbReportType = new ComboBox
            {
                Location = new Point(700, 12), Size = new Size(160, 30), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            _cmbReportType.Items.AddRange(new object[] { "درآمد", "ایستگاه‌ها", "کاربران برتر" });
            _cmbReportType.SelectedIndex = 0;

            var btnGenerate = new Button
            {
                Text = "تولید گزارش", Location = new Point(20, 50), Size = new Size(150, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnGenerate.Click += (s, e) => GenerateReport();

            var btnToday = new Button
            {
                Text = "امروز", Location = new Point(180, 50), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnToday.Click += (s, e) => { _dtpFrom.Value = DateTime.UtcNow.Date; _dtpTo.Value = DateTime.UtcNow.Date; GenerateReport(); };

            var btnWeek = new Button
            {
                Text = "هفته", Location = new Point(270, 50), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213))
            };
            btnWeek.Click += (s, e) => { _dtpFrom.Value = DateTime.UtcNow.Date.AddDays(-7); _dtpTo.Value = DateTime.UtcNow.Date; GenerateReport(); };

            var btnMonth = new Button
            {
                Text = "ماه", Location = new Point(360, 50), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            btnMonth.Click += (s, e) => { _dtpFrom.Value = DateTime.UtcNow.Date.AddDays(-30); _dtpTo.Value = DateTime.UtcNow.Date; GenerateReport(); };

            // Summary label
            _lblSummary = new Label
            {
                Location = new Point(20, 95), AutoSize = true,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20)
            };

            // Data list
            _lvData = new ListView
            {
                Location = new Point(20, 125),
                Size = new Size(840, 400),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };

            this.Controls.AddRange(new Control[] { lblFrom, _dtpFrom, lblTo, _dtpTo, lblType, _cmbReportType, btnGenerate, btnToday, btnWeek, btnMonth, _lblSummary, _lvData });

            GenerateReport();
        }

        private void GenerateReport()
        {
            _lvData.Columns.Clear();
            _lvData.Items.Clear();

            var from = _dtpFrom.Value.Date;
            var to = _dtpTo.Value.Date.AddDays(1);
            var engine = new ReportEngine();

            switch (_cmbReportType.SelectedIndex)
            {
                case 0: // Revenue
                    GenerateRevenueReport(engine, from, to);
                    break;
                case 1: // Stations
                    GenerateStationReport(engine, from, to);
                    break;
                case 2: // Top Users
                    GenerateTopUsersReport(engine, from, to);
                    break;
            }
        }

        private void GenerateRevenueReport(ReportEngine engine, DateTime from, DateTime to)
        {
            _lvData.Columns.Add("تاریخ", 120);
            _lvData.Columns.Add("درآمد جلسات", 120);
            _lvData.Columns.Add("درآمد غذا", 100);
            _lvData.Columns.Add("درآمد پرینت", 100);
            _lvData.Columns.Add("جلسات", 80);
            _lvData.Columns.Add("کاربران", 80);

            var report = engine.GetRevenueReport(from, to);
            _lblSummary.Text = $"جمع درآمد: {report.TotalRevenue:N0} تومان | جلسات: {report.TotalSessions} | میانگین هزینه: {report.AverageSessionCost:N0} تومان";

            foreach (var day in report.DailyBreakdown)
            {
                var item = new ListViewItem(day.Date.ToString("yyyy/MM/dd"));
                item.SubItems.Add($"{day.Revenue:N0}");
                item.SubItems.Add("0");
                item.SubItems.Add("0");
                item.SubItems.Add(day.Sessions.ToString());
                item.SubItems.Add(day.UniqueUsers.ToString());
                _lvData.Items.Add(item);
            }
        }

        private void GenerateStationReport(ReportEngine engine, DateTime from, DateTime to)
        {
            _lvData.Columns.Add("ایستگاه", 150);
            _lvData.Columns.Add("جلسات", 100);
            _lvData.Columns.Add("دقایق", 100);
            _lvData.Columns.Add("درآمد", 120);
            _lvData.Columns.Add("بهره‌وری", 100);

            var data = engine.GetStationUtilization(from, to);
            decimal totalRev = 0;
            foreach (var s in data) totalRev += s.TotalRevenue;
            _lblSummary.Text = $"تعداد ایستگاه‌ها: {data.Count} | جمع درآمد: {totalRev:N0} تومان";

            foreach (var s in data)
            {
                var item = new ListViewItem(s.StationName);
                item.SubItems.Add(s.TotalSessions.ToString());
                item.SubItems.Add(s.TotalMinutes.ToString());
                item.SubItems.Add($"{s.TotalRevenue:N0}");
                item.SubItems.Add($"{s.UtilizationPercent:F1}%");
                _lvData.Items.Add(item);
            }
        }

        private void GenerateTopUsersReport(ReportEngine engine, DateTime from, DateTime to)
        {
            _lvData.Columns.Add("نام کاربری", 150);
            _lvData.Columns.Add("نام نمایشی", 150);
            _lvData.Columns.Add("جلسات", 100);
            _lvData.Columns.Add("هزینه کل", 120);
            _lvData.Columns.Add("دقایق", 100);

            var data = engine.GetTopUsers(from, to, 30);
            _lblSummary.Text = $"تعداد کاربران: {data.Count}";

            foreach (var u in data)
            {
                var item = new ListViewItem(u.Username);
                item.SubItems.Add(u.DisplayName);
                item.SubItems.Add(u.TotalSessions.ToString());
                item.SubItems.Add($"{u.TotalSpent:N0}");
                item.SubItems.Add(u.TotalMinutes.ToString());
                _lvData.Items.Add(item);
            }
        }
    }
}
