using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Cafeteria / Orders form (HandyCafe-style). Lets the operator pick a
    /// user + menu item, set quantity + cost, build an order-lines list,
    /// and either pay or cancel the order. "Transfer to Client" sends the
    /// order summary to the selected client station as a chat message so
    /// the kiosk can display it.
    /// </summary>
    public class OrdersForm : Form
    {
        private ClientCommunicator _communicator;

        private ComboBox _cboUser, _cboItem;
        private TextBox _txtCost;
        private NumericUpDown _nudQty;
        private Button _btnAdd, _btnDelete;
        private DataGridView _dgv;
        private Label _lblTotal;
        private Button _btnPayment, _btnCancelOrder, _btnTransfer;

        // In-memory menu (with default prices). Mirrors what would be in
        // the food_items table if seeded.
        private readonly List<MenuItemDef> _menu = new List<MenuItemDef>
        {
            new MenuItemDef { Name = "نوشابه",  Price = 15000 },
            new MenuItemDef { Name = "چای",     Price = 8000  },
            new MenuItemDef { Name = "قهوه",    Price = 25000 },
            new MenuItemDef { Name = "ساندویچ", Price = 45000 },
            new MenuItemDef { Name = "پیتزا",   Price = 95000 },
        };

        private readonly List<OrderLine> _cart = new List<OrderLine>();

        public OrdersForm() : this(null) { }

        public OrdersForm(ClientCommunicator communicator)
        {
            _communicator = communicator;

            this.Text = "بوفه / کافه‌تریا - GameNet";
            this.Size = new Size(920, 640);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            int y = 12;

            // ---- Top: user + item pickers ----
            var lblUser = new Label { Text = "👤 کاربر:", Location = new Point(20, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _cboUser = new ComboBox
            {
                Location = new Point(90, y), Size = new Size(180, 28), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40)
            };
            LoadUsers();

            var lblItem = new Label { Text = "🍽️ مورد:", Location = new Point(290, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _cboItem = new ComboBox
            {
                Location = new Point(360, y), Size = new Size(180, 28), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40)
            };
            foreach (var m in _menu) _cboItem.Items.Add(m.Name);
            if (_cboItem.Items.Count > 0) _cboItem.SelectedIndex = 0;
            _cboItem.SelectedIndexChanged += (s, e) =>
            {
                var m = _menu.FirstOrDefault(x => x.Name == (_cboItem.SelectedItem?.ToString() ?? ""));
                if (m != null) _txtCost.Text = m.Price.ToString("N0");
            };

            var lblQty = new Label { Text = "تعداد:", Location = new Point(560, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _nudQty = new NumericUpDown { Location = new Point(620, y), Size = new Size(70, 28), Minimum = 1, Maximum = 999, Value = 1, Font = new Font("Segoe UI", 10F) };

            var lblCost = new Label { Text = "قیمت:", Location = new Point(710, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtCost = new TextBox { Location = new Point(770, y), Size = new Size(120, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "0" };

            y += 38;

            _btnAdd = new Button
            {
                Text = "➕ افزودن", Location = new Point(20, y), Size = new Size(130, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnAdd.Click += (s, e) => AddLine();

            _btnDelete = new Button
            {
                Text = "❌ حذف سطر", Location = new Point(160, y), Size = new Size(130, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            _btnDelete.Click += (s, e) => DeleteLine();

            _lblTotal = new Label
            {
                Text = "جمع کل: 0 تومان",
                Location = new Point(330, y + 4),
                AutoSize = true,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
            };

            y += 46;

            // ---- Order-lines grid ----
            _dgv = new DataGridView
            {
                Location = new Point(20, y),
                Size = new Size(870, 360),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 24 },
            };
            _dgv.Columns.Add("colItem", "مورد");
            _dgv.Columns.Add("colQty", "تعداد");
            _dgv.Columns.Add("colUnit", "قیمت واحد");
            _dgv.Columns.Add("colLine", "جمع سطر");
            _dgv.Columns[1].Width = 60;
            _dgv.Columns[2].Width = 110;
            _dgv.Columns[3].Width = 110;

            y += 370;

            // ---- Bottom action buttons ----
            _btnPayment = new Button
            {
                Text = "💳 پرداخت", Location = new Point(20, y), Size = new Size(150, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnPayment.Click += (s, e) => DoPayment();

            _btnCancelOrder = new Button
            {
                Text = "🚫 لغو سفارش", Location = new Point(180, y), Size = new Size(150, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            _btnCancelOrder.Click += (s, e) => DoCancelOrder();

            _btnTransfer = new Button
            {
                Text = "📤 ارسال به کلاینت", Location = new Point(340, y), Size = new Size(180, 38),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnTransfer.Click += (s, e) => DoTransfer();

            Controls.AddRange(new Control[] {
                lblUser, _cboUser, lblItem, _cboItem, lblQty, _nudQty, lblCost, _txtCost,
                _btnAdd, _btnDelete, _lblTotal,
                _dgv,
                _btnPayment, _btnCancelOrder, _btnTransfer
            });

            // Initialize cost text with first menu item.
            if (_cboItem.SelectedIndex >= 0)
            {
                var m = _menu[_cboItem.SelectedIndex];
                _txtCost.Text = m.Price.ToString("N0");
            }
        }

        private void LoadUsers()
        {
            try
            {
                _cboUser.Items.Clear();
                var users = new UserManager().GetAllUsers();
                foreach (var u in users) _cboUser.Items.Add(u.Username);
                if (_cboUser.Items.Count > 0) _cboUser.SelectedIndex = 0;
            }
            catch { }
        }

        private void AddLine()
        {
            string item = _cboItem.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(item))
            {
                MessageBox.Show("یک مورد انتخاب کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            decimal cost;
            if (!decimal.TryParse(_txtCost.Text.Replace(",", "").Trim(), out cost) || cost < 0)
            {
                MessageBox.Show("قیمت معتبر نیست.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int qty = (int)_nudQty.Value;
            _cart.Add(new OrderLine { Item = item, Qty = qty, UnitCost = cost });
            RefreshGrid();
        }

        private void DeleteLine()
        {
            if (_dgv.SelectedRows.Count == 0) return;
            int idx = _dgv.SelectedRows[0].Index;
            if (idx >= 0 && idx < _cart.Count)
            {
                _cart.RemoveAt(idx);
                RefreshGrid();
            }
        }

        private void RefreshGrid()
        {
            _dgv.Rows.Clear();
            decimal total = 0;
            foreach (var l in _cart)
            {
                decimal line = l.UnitCost * l.Qty;
                total += line;
                _dgv.Rows.Add(l.Item, l.Qty.ToString(), l.UnitCost.ToString("N0"), line.ToString("N0"));
            }
            _lblTotal.Text = $"جمع کل: {total:N0} تومان";
        }

        private void DoPayment()
        {
            if (_cart.Count == 0)
            {
                MessageBox.Show("سبد خالی است.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string username = _cboUser.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("کاربر را انتخاب کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal total = _cart.Sum(l => l.UnitCost * l.Qty);
            try
            {
                // Persist via FoodOrderSystem if food_items seeded; fall back to
                // direct cash deduction on the user balance.
                try
                {
                    var mgr = new UserManager();
                    mgr.AddCredit(username, -total, "Cafeteria order");
                }
                catch (Exception ex) { AuditLog.Log("OrdersForm", "AddCredit(-) failed: " + ex.Message); }

                AuditLog.Log("OrdersForm", $"Order paid by {username}: {_cart.Count} items, total {total:N0} Toman");
                MessageBox.Show($"✅ سفارش با موفقیت ثبت شد.\nجمع: {total:N0} تومان\nکاربر: {username}", "پرداخت", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _cart.Clear();
                RefreshGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DoCancelOrder()
        {
            if (_cart.Count == 0) return;
            if (MessageBox.Show("لغو کل سفارش؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _cart.Clear();
                RefreshGrid();
            }
        }

        private void DoTransfer()
        {
            if (_cart.Count == 0)
            {
                MessageBox.Show("سبد خالی است.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (_communicator == null)
            {
                MessageBox.Show("ارتباط با کلاینت برقرار نیست.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                string username = _cboUser.SelectedItem?.ToString() ?? "";
                decimal total = _cart.Sum(l => l.UnitCost * l.Qty);
                string summary = $"📋 سفارش بوفه - {username}\n" +
                                 string.Join("\n", _cart.Select(l => $"• {l.Item} × {l.Qty} = {(l.UnitCost * l.Qty):N0}")) +
                                 $"\nجمع: {total:N0} تومان";
                // Find a connected station for this user (if any).
                var conns = _communicator.GetAllRawConnections();
                var target = conns.FirstOrDefault(c => c.User == username);
                if (target.StationName == null)
                {
                    MessageBox.Show("این کاربر در حال حاضر به کلاینتی متصل نیست.", "ارسال به کلاینت", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _communicator.SendToStation(target.StationName,
                    new NetMessage(MessageType.ServerChatReceive,
                        new ChatReceivePayload
                        {
                            SenderUsername = "Operator",
                            SenderDisplayName = "اپراتور",
                            Message = summary,
                            Timestamp = DateTime.UtcNow,
                            IsBroadcast = false,
                            IsSystem = true
                        }));
                AuditLog.Log("OrdersForm", $"Transferred order summary to {target.StationName} for {username}");
                MessageBox.Show($"✅ سفارش به کلاینت {target.StationName} ارسال شد.", "ارسال به کلاینت", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ارسال: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private class MenuItemDef { public string Name; public decimal Price; }
        private class OrderLine { public string Item; public int Qty; public decimal UnitCost; }
    }
}
