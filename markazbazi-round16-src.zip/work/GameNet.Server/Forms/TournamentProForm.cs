using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// PRO "tournaments+": lists the same tournament records as the Tournaments tab
    /// (TournamentManager) with participant counts. "Add" opens the Tournaments form,
    /// where tournaments are created. Before this change the add button only showed a
    /// placeholder message and the grid never received any rows.
    /// </summary>
    public class TournamentProForm : Form
    {
        private readonly TournamentManager _mgr = new TournamentManager();
        private readonly DataGridView dgv;

        public TournamentProForm()
        {
            this.Text = "🏆 مسابقات+ - markazbazi";
            this.Size = new Size(900, 600);
            this.BackColor = Color.FromArgb(30, 30, 46);
            this.ForeColor = Color.FromArgb(205, 214, 244);
            this.Font = new Font("Segoe UI", 9F);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(40, 40, 60),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                BorderStyle = BorderStyle.None
            };
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(205, 214, 244);
            dgv.DefaultCellStyle.BackColor = Color.FromArgb(40, 40, 60);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(35, 35, 52);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250));
            dgv.Columns.Add("Id", "ID");
            dgv.Columns.Add("Name", "نام مسابقه");
            dgv.Columns.Add("Game", "بازی");
            dgv.Columns.Add("Players", "بازیکنان");
            dgv.Columns.Add("Prize", "جایزه");
            dgv.Columns.Add("Start", "شروع");
            dgv.Columns.Add("Status", "وضعیت");

            var pnl = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.FromArgb(35, 35, 52) };
            var btnAdd = new Button
            {
                Text = "➕ افزودن",
                Location = new Point(10, 10),
                Size = new Size(90, 30),
                BackColor = Color.FromArgb(0, 240, 255),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            var btnRefresh = new Button
            {
                Text = "🔄 بارگذاری",
                Location = new Point(110, 10),
                Size = new Size(90, 30),
                BackColor = Color.FromArgb(137, 180, 250),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += (s, e) =>
            {
                using (var f = new TournamentForm())
                {
                    f.ShowDialog();
                }
                LoadData();
            };
            btnRefresh.Click += (s, e) => LoadData();
            pnl.Controls.AddRange(new Control[] { btnAdd, btnRefresh });

            this.Controls.Add(dgv);
            this.Controls.Add(pnl);
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                dgv.Rows.Clear();
                foreach (TournamentInfo t in _mgr.GetAllTournaments())
                {
                    int cur = _mgr.CountParticipants(t.Id);
                    dgv.Rows.Add(
                        t.Id,
                        t.Name,
                        t.Game,
                        cur + "/" + t.MaxParticipants,
                        t.Prize.ToString("N0") + " ت",
                        t.StartTime.ToLocalTime().ToString("yyyy/MM/dd HH:mm"),
                        TranslateStatus(t.Status));
                }
            }
            catch (Exception ex)
            {
                try
                {
                    dgv.Rows.Clear();
                    dgv.Rows.Add("⚠️ خطا در بارگذاری اطلاعات: " + ex.Message);
                }
                catch { }
            }
        }

        private static string TranslateStatus(string s)
        {
            switch (s)
            {
                case "open": return "🟢 باز";
                case "full": return "🟡 تکمیل";
                case "completed": return "✅ پایان‌یافته";
                default: return s;
            }
        }
    }
}
