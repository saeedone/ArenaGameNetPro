using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Settings & extensions management form. Combines:
    ///   - Birthday rewards config
    ///   - Referral system management
    ///   - Telegram bot config
    ///   - Dark/Light theme toggle
    ///   - Billing interval config
    ///   - JSON backup export
    ///   - Report export to HTML (in-app viewer, no Excel)
    /// </summary>
    public class ExtensionsForm : Form
    {
        private TabControl _tabs;

        public ExtensionsForm()
        {
            this.Text = "⚙️ تنظیمات و افزونه‌ها";
            this.Size = new Size(900, 650);
            this.BackColor = Color.FromArgb(255, 255, 255);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
        }

        private void BuildUi()
        {
            _tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9F) };

            // === Tab 1: Birthday ===
            var tabBirthday = new TabPage("🎂 تولد") { BackColor = Color.FromArgb(255, 255, 255) };
            var lblBTitle = new Label { Text = "🎂 پاداش تولد", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(200, 100, 30), Location = new Point(15, 10), AutoSize = true };
            var lblBInfo = new Label { Text = "مبلغ پاداش تولد را تنظیم کنید.\nدر روز تولد کاربر، خودکار اعتبار اضافه می‌شود.\n(تاریخ تولد در فیلد یادداشت کاربر با فرمت BD:MM-DD)", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(15, 40), Size = new Size(500, 50) };
            var lblBAmount = new Label { Text = "مبلغ پاداش (تومان):", Location = new Point(15, 100), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var txtBAmount = new TextBox { Location = new Point(200, 97), Size = new Size(150, 30), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            txtBAmount.Text = BirthdayRewardManager.DefaultRewardAmount.ToString();
            var btnBSave = new Button { Text = "💾 ذخیره", Location = new Point(360, 95), Size = new Size(100, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnBSave.Click += (s, e) =>
            {
                if (decimal.TryParse(txtBAmount.Text, out decimal amt) && amt > 0)
                {
                    Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('birthday_reward_amount', @v)", cmd => cmd.Parameters.AddWithValue("@v", amt.ToString()));
                    MessageBox.Show("✅ مبلغ پاداش تولد ذخیره شد.");
                }
            };
            var btnBCheck = new Button { Text = "🔍 بررسی تولدهای امروز", Location = new Point(15, 140), Size = new Size(250, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnBCheck.Click += (s, e) => { BirthdayRewardManager.CheckAndRewardBirthdays(); MessageBox.Show("✅ بررسی انجام شد."); };
            tabBirthday.Controls.AddRange(new Control[] { lblBTitle, lblBInfo, lblBAmount, txtBAmount, btnBSave, btnBCheck });

            // === Tab 2: Referral ===
            var tabRef = new TabPage("👥 معرفی دوستان") { BackColor = Color.FromArgb(255, 255, 255) };
            var lblRTitle = new Label { Text = "👥 سیستم معرفی دوستان", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(15, 10), AutoSize = true };
            var lblRInfo = new Label { Text = "کاربر با دعوت دوستان اعتبار دریافت می‌کند.\nکد معرفی هر کاربر نمایش داده می‌شود.", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(15, 40), Size = new Size(500, 40) };
            var lblRUser = new Label { Text = "نام کاربری:", Location = new Point(15, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var txtRUser = new TextBox { Location = new Point(120, 87), Size = new Size(200, 30), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnRCode = new Button { Text = "🔑 دریافت کد", Location = new Point(330, 85), Size = new Size(150, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            var lblRCode = new Label { Text = "کد: ---", Location = new Point(15, 130), AutoSize = true, Font = new Font("Consolas", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20) };
            btnRCode.Click += (s, e) => { if (!string.IsNullOrWhiteSpace(txtRUser.Text)) { string code = ReferralManager.GetReferralCode(txtRUser.Text.Trim()); lblRCode.Text = $"🔑 کد: {code}"; } };
            var dgvRef = new DataGridView { Location = new Point(15, 170), Size = new Size(830, 350), BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false, DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40) }, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) }, EnableHeadersVisualStyles = false };
            dgvRef.Columns.Add("colRef", "معرف");
            dgvRef.Columns.Add("colReferred", "معرفی‌شده");
            dgvRef.Columns.Add("colRR", "پاداش معرف");
            dgvRef.Columns.Add("colRD", "پاداش معرفی‌شده");
            dgvRef.Columns.Add("colDate", "تاریخ");
            var btnRRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(500, 85), Size = new Size(100, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRRefresh.Click += (s, e) => { dgvRef.Rows.Clear(); foreach (var h in ReferralManager.GetHistory()) dgvRef.Rows.Add(h.Referrer, h.Referred, h.ReferrerReward.ToString("N0"), h.RefereeReward.ToString("N0"), h.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm")); };
            tabRef.Controls.AddRange(new Control[] { lblRTitle, lblRInfo, lblRUser, txtRUser, btnRCode, lblRCode, dgvRef, btnRRefresh });

            // === Tab 3: Telegram ===
            var tabTg = new TabPage("📤 تلگرام") { BackColor = Color.FromArgb(255, 255, 255) };
            var lblTgTitle = new Label { Text = "📤 اطلاع‌رسانی تلگرام", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 10), AutoSize = true };
            var lblTgInfo = new Label { Text = "ربات تلگرام را تنظیم کنید تا رویدادهای مهم (کرش/هشدار/شارژ) به اپراتور ارسال شود.\n\n1. در تلگرام به @BotFather پیام دهید و یک ربات بسازید.\n2. توکن را در زیر وارد کنید.\n3. chat_id خود را دریافت کنید و وارد کنید.", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(15, 40), Size = new Size(600, 70) };
            var lblTgToken = new Label { Text = "توکن ربات:", Location = new Point(15, 120), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var txtTgToken = new TextBox { Location = new Point(150, 117), Size = new Size(400, 30), Font = new Font("Consolas", 9F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var lblTgChat = new Label { Text = "Chat ID:", Location = new Point(15, 160), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var txtTgChat = new TextBox { Location = new Point(150, 157), Size = new Size(200, 30), Font = new Font("Consolas", 9F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnTgSave = new Button { Text = "💾 ذخیره", Location = new Point(15, 200), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnTgSave.Click += (s, e) => {
                TelegramNotifier.Configure(txtTgToken.Text.Trim(), txtTgChat.Text.Trim());
                // FIX-MONITOR-ADD5 TASK B5: also persist to options.json so
                // the values survive a server restart. The new
                // TelegramNotifier only holds the in-memory copy; OptionsForm
                // is the canonical store.
                try
                {
                    var opts = OptionsForm.LoadStaticOptions() ?? new OptionsForm.OptionsData();
                    opts.TelegramBotToken = txtTgToken.Text.Trim();
                    opts.TelegramChatId = txtTgChat.Text.Trim();
                    OptionsForm.SaveStaticOptions(opts);
                }
                catch { }
                MessageBox.Show("✅ تنظیمات تلگرام ذخیره شد.");
            };
            var btnTgTest = new Button { Text = "🧪 تست", Location = new Point(145, 200), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnTgTest.Click += (s, e) => { TelegramNotifier.Send("🧪 پیام تست از GameNet Server"); MessageBox.Show("پیام تست ارسال شد."); };
            // FIX-MONITOR-ADD5 TASK B5: TelegramNotifier.LoadConfig() was
            // removed (the new class loads from options.json, not the DB).
            // The textbox values below are populated from options.json
            // first (canonical store), falling back to the legacy DB-backed
            // settings table so existing installs that stored the token
            // there still show their saved values.
            // Load saved values
            try
            {
                var opts = OptionsForm.LoadStaticOptions();
                if (opts != null && !string.IsNullOrEmpty(opts.TelegramBotToken))
                    txtTgToken.Text = opts.TelegramBotToken;
                else
                    txtTgToken.Text = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = 'telegram_bot_token'", null, r => r.GetString(0)) ?? "";
            }
            catch { }
            try
            {
                var opts = OptionsForm.LoadStaticOptions();
                if (opts != null && !string.IsNullOrEmpty(opts.TelegramChatId))
                    txtTgChat.Text = opts.TelegramChatId;
                else
                    txtTgChat.Text = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = 'telegram_chat_id'", null, r => r.GetString(0)) ?? "";
            }
            catch { }
            tabTg.Controls.AddRange(new Control[] { lblTgTitle, lblTgInfo, lblTgToken, txtTgToken, lblTgChat, txtTgChat, btnTgSave, btnTgTest });

            // === Tab 4: Theme + Billing ===
            var tabSettings = new TabPage("🎨 تم + صورت‌حساب") { BackColor = Color.FromArgb(255, 255, 255) };
            var lblSTitle = new Label { Text = "🎨 تم و تنظیمات صورت‌حساب", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(130, 50, 180), Location = new Point(15, 10), AutoSize = true };
            var btnTheme = new Button { Text = ServerThemeManager.IsDarkMode ? "🌙 حالت تاریک (کلیک برای روشن)" : "☀️ حالت روشن (کلیک برای تیره)", Location = new Point(15, 40), Size = new Size(400, 40), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(203, 166, 247)) };
            btnTheme.Click += (s, e) => { ServerThemeManager.Toggle(); btnTheme.Text = ServerThemeManager.IsDarkMode ? "🌙 حالت تاریک (کلیک برای روشن)" : "☀️ حالت روشن (کلیک برای تیره)"; MessageBox.Show("تم تغییر کرد. سرور را دوباره باز کنید."); };
            ServerThemeManager.Load();

            var lblBI = new Label { Text = "⏱️ بازه صورت‌حساب (ثانیه):", Location = new Point(15, 100), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var numBI = new NumericUpDown { Location = new Point(250, 97), Size = new Size(80, 30), Minimum = 10, Maximum = 600, Value = BillingConfig.IntervalSeconds, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnSaveBI = new Button { Text = "💾", Location = new Point(340, 95), Size = new Size(40, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSaveBI.Click += (s, e) => { BillingConfig.IntervalSeconds = (int)numBI.Value; MessageBox.Show("✅ ذخیره شد."); };

            var lblMinC = new Label { Text = "💰 حداقل هزینه (تومان):", Location = new Point(15, 140), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var numMinC = new NumericUpDown { Location = new Point(250, 137), Size = new Size(100, 30), Minimum = 0, Maximum = 100000, Value = (decimal)BillingConfig.MinimumCharge, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnSaveMC = new Button { Text = "💾", Location = new Point(360, 135), Size = new Size(40, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSaveMC.Click += (s, e) => { BillingConfig.MinimumCharge = numMinC.Value; MessageBox.Show("✅ ذخیره شد."); };

            var lblRound = new Label { Text = "🔄 رند کردن (دقیقه):", Location = new Point(15, 180), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var numRound = new NumericUpDown { Location = new Point(250, 177), Size = new Size(80, 30), Minimum = 1, Maximum = 60, Value = BillingConfig.RoundingMinutes, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnSaveRound = new Button { Text = "💾", Location = new Point(340, 175), Size = new Size(40, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSaveRound.Click += (s, e) => { BillingConfig.RoundingMinutes = (int)numRound.Value; MessageBox.Show("✅ ذخیره شد."); };

            var lblWarn = new Label { Text = "⏰ هشدار زمان (دقیقه):", Location = new Point(15, 220), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            var numWarn = new NumericUpDown { Location = new Point(250, 217), Size = new Size(80, 30), Minimum = 1, Maximum = 60, Value = BillingConfig.WarningMinutes, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnSaveWarn = new Button { Text = "💾", Location = new Point(340, 215), Size = new Size(40, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSaveWarn.Click += (s, e) => { BillingConfig.WarningMinutes = (int)numWarn.Value; MessageBox.Show("✅ ذخیره شد."); };

            tabSettings.Controls.AddRange(new Control[] { lblSTitle, btnTheme, lblBI, numBI, btnSaveBI, lblMinC, numMinC, btnSaveMC, lblRound, numRound, btnSaveRound, lblWarn, numWarn, btnSaveWarn });

            // === Tab 5: JSON Backup + Report Export ===
            var tabBackup = new TabPage("💾 بکاپ JSON") { BackColor = Color.FromArgb(255, 255, 255) };
            var lblJTitle = new Label { Text = "💾 بکاپ کامل JSON", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(15, 10), AutoSize = true };
            var lblJInfo = new Label { Text = "تمام جداول دیتابیس به فرمت JSON ذخیره می‌شوند.\nاین فرمت قابل انتقال به هر سیستمی است.", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(15, 40), Size = new Size(500, 40) };
            var btnJExport = new Button { Text = "💾 خروجی JSON", Location = new Point(15, 90), Size = new Size(200, 40), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnJExport.Click += (s, e) => { string path = JsonBackupManager.ExportToJson(); if (path != null) MessageBox.Show($"✅ بکاپ JSON ذخیره شد:\n{path}"); else MessageBox.Show("❌ خطا در بکاپ."); };
            var btnRHtml = new Button { Text = "📊 خروجی گزارش HTML", Location = new Point(225, 90), Size = new Size(200, 40), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRHtml.Click += (s, e) =>
            {
                try
                {
                    var rows = Database.Instance.Query("SELECT username, COUNT(*) as cnt, SUM(total_cost) as rev FROM client_sessions WHERE end_time IS NOT NULL AND date(start_time) = date('now') GROUP BY username ORDER BY rev DESC",
                        null, r => new List<string> { r.GetString(0), r.GetInt32(1).ToString(), (r.IsDBNull(2) ? 0 : r.GetDecimal(2)).ToString("N0") });
                    ReportExporter.SaveAndOpenHtml("گزارش درآمد امروز", new List<string> { "کاربر", "تعداد نشست", "درآمد" }, rows);
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); }
            };
            tabBackup.Controls.AddRange(new Control[] { lblJTitle, lblJInfo, btnJExport, btnRHtml });

            _tabs.TabPages.AddRange(new TabPage[] { tabBirthday, tabRef, tabTg, tabSettings, tabBackup });
            this.Controls.Add(_tabs);
        }
    }
}
