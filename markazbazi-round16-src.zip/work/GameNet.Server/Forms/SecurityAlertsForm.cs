using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Phase 4.2 — Real-time security alerts panel. Shows live IDS alerts
    /// with severity color-coding, lets the operator acknowledge them, and
    /// subscribes to the IDS OnAlert event so new alerts pop in without a
    /// manual refresh. Also surfaces a quick health summary at the top.
    /// </summary>
    public class SecurityAlertsForm : Form
    {
        private DataGridView _dgv;
        private Label _lblCount, _lblCritical, _lblHigh, _lblMedium;
        private Timer _timer;
        private bool _subscribed;

        public SecurityAlertsForm()
        {
            this.Text = "🚨 هشدارهای امنیتی زنده";
            this.Size = new Size(1000, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshAlerts(null, null);

            // Subscribe to live alerts
            try
            {
                IntrusionDetectionSystem.OnAlert += OnLiveAlert;
                _subscribed = true;
            }
            catch { }

            _timer = new Timer { Interval = 5000 };
            _timer.Tick += RefreshAlerts;
            _timer.Start();

            // Start IDS if not already running
            try { IntrusionDetectionSystem.Initialize(); } catch { }
        }

        private void BuildUi()
        {
            // Top stats
            var statsBar = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(240, 240, 240) };
            int sx = 15;
            _lblCount = MkStat(statsBar, ref sx, "🔔 کل هشدارها", "0", Color.FromArgb(137, 180, 250));
            _lblCritical = MkStat(statsBar, ref sx, "🔴 بحرانی", "0", Color.FromArgb(243, 139, 168));
            _lblHigh = MkStat(statsBar, ref sx, "🟠 بالا", "0", Color.FromArgb(249, 226, 175));
            _lblMedium = MkStat(statsBar, ref sx, "🟡 متوسط", "0", Color.FromArgb(250, 179, 135));

            // Grid
            _dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgv.Columns.Add("colId", "شناسه"); _dgv.Columns["colId"].Visible = false;
            _dgv.Columns.Add("colTime", "زمان");
            _dgv.Columns.Add("colType", "نوع");
            _dgv.Columns.Add("colSeverity", "شدت");
            _dgv.Columns.Add("colMessage", "پیام");
            _dgv.Columns.Add("colIp", "IP");
            _dgv.Columns.Add("colOp", "اپراتور");
            _dgv.Columns.Add("colAck", "وضعیت");

            _dgv.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (_dgv.Columns[e.ColumnIndex].Name == "colSeverity")
                {
                    var v = e.Value?.ToString() ?? "";
                    if (v == "Critical") { e.CellStyle.ForeColor = Color.FromArgb(200, 30, 60); e.CellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold); e.Value = "🔴 بحرانی"; }
                    else if (v == "High") { e.CellStyle.ForeColor = Color.FromArgb(180, 140, 20); e.Value = "🟠 بالا"; }
                    else if (v == "Medium") { e.CellStyle.ForeColor = Color.FromArgb(200, 100, 30); e.Value = "🟡 متوسط"; }
                    else { e.CellStyle.ForeColor = Color.FromArgb(20, 140, 130); e.Value = "🔵 پایین"; }
                }
                else if (_dgv.Columns[e.ColumnIndex].Name == "colAck")
                {
                    var v = e.Value?.ToString() ?? "";
                    e.Value = v == "True" ? "✅ تأیید شده" : "⏳ جدید";
                    e.CellStyle.ForeColor = v == "True" ? Color.FromArgb(166, 227, 161) : Color.FromArgb(249, 226, 175);
                }
            };

            // Toolbar
            var toolbar = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnAck = new Button { Text = "✅ تأیید انتخاب‌شده", Location = new Point(10, 7), Size = new Size(180, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnAck.Click += (s, e) =>
            {
                if (_dgv.SelectedRows.Count > 0)
                {
                    int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
                    IntrusionDetectionSystem.AcknowledgeAlert(id);
                    RefreshAlerts(null, null);
                }
            };
            var btnAckAll = new Button { Text = "✅ تأیید همه", Location = new Point(200, 7), Size = new Size(150, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnAckAll.Click += (s, e) => { IntrusionDetectionSystem.AcknowledgeAll(); RefreshAlerts(null, null); };
            var btnRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(360, 7), Size = new Size(120, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213)) };
            btnRefresh.Click += (s, e) => RefreshAlerts(null, null);

            toolbar.Controls.AddRange(new Control[] { btnAck, btnAckAll, btnRefresh });

            Controls.AddRange(new Control[] { _dgv, toolbar, statsBar });
        }

        private Label MkStat(Panel parent, ref int x, string title, string value, Color color)
        {
            var pnl = new Panel { Location = new Point(x, 8), Size = new Size(160, 44), BackColor = Color.FromArgb(230, 230, 235) };
            var lblT = new Label { Text = title, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(8, 4), AutoSize = true };
            var lblV = new Label { Text = value, Font = new Font("Segoe UI", 13F, FontStyle.Bold), ForeColor = color, Location = new Point(8, 20), AutoSize = true };
            pnl.Controls.AddRange(new Control[] { lblT, lblV });
            parent.Controls.Add(pnl);
            x += 168;
            return lblV;
        }

        private void OnLiveAlert(SecurityAlert alert)
        {
            // Marshal to UI thread
            try
            {
                if (this.InvokeRequired)
                    this.BeginInvoke((Action)(() => RefreshAlerts(null, null)));
                else
                    RefreshAlerts(null, null);
            }
            catch { }
        }

        private void RefreshAlerts(object s, EventArgs e)
        {
            try
            {
                var alerts = IntrusionDetectionSystem.GetRecentAlerts(100);
                _dgv.Rows.Clear();
                foreach (var a in alerts)
                    _dgv.Rows.Add(a.Id, a.Timestamp.ToLocalTime().ToString("MM-dd HH:mm:ss"), a.Type, a.Severity, a.Message, a.ClientIp, a.OperatorName, a.IsAcknowledged.ToString());

                _lblCount.Text = alerts.Count.ToString();
                _lblCritical.Text = alerts.Count(a => a.Severity == "Critical").ToString();
                _lblHigh.Text = alerts.Count(a => a.Severity == "High").ToString();
                _lblMedium.Text = alerts.Count(a => a.Severity == "Medium").ToString();
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_subscribed) try { IntrusionDetectionSystem.OnAlert -= OnLiveAlert; } catch { }
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
