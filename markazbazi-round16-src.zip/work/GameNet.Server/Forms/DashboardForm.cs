using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Live, chart-rich dashboard — the FIRST thing the operator sees when the
    /// server opens. Shows real-time income, client activity, and popular games.
    ///
    /// Layout (top → bottom, all docked so the form fills its tab-page host):
    ///   ┌──────────────────────────────────────────────────────────────────┐
    ///   │  📊 داشبورد زنده                              [🔄 بروزرسانی]      │  Header (Top, 44px)
    ///   ├──────────────────────────────────────────────────────────────────┤
    ///   │  💰 درآمد امروز │ 🖥️ کلاینت‌های فعال │ 👥 کل کاربران │ 📊 نشست‌های امروز │  KPI row (Top, 116px)
    ///   ├──────────────────────────────────────────────────────────────────┤
    ///   │  درآمد ساعتی امروز (bar)        │  بازی‌های محبوب (h-bar)         │  Charts row (Top, 300px)
    ///   ├──────────────────────────────────────────────────────────────────┤
    ///   │  فعالیت اخیر  (DataGridView, last 20 audit_log rows)            │  Activity feed (Fill)
    ///   └──────────────────────────────────────────────────────────────────┘
    ///
    /// Refresh cadence:
    ///   • KPI cards + activity feed: every 5 seconds (fast timer)
    ///   • Charts: every 30 seconds (slow timer, avoids DB load)
    ///   • Manual refresh button: refreshes everything immediately
    ///
    /// Charts are drawn with GDI+ (custom <see cref="BarChartControl"/> /
    /// <see cref="HBarChartControl"/>) — no external charting dependency,
    /// consistent with <see cref="RevenueChartForm"/>'s ChartCanvas. This
    /// avoids any runtime dependency on System.Windows.Forms.DataVisualization
    /// (which is not in the GAC on non-Windows / clean Windows installs).
    /// </summary>
    public class DashboardForm : Form
    {
        private readonly ClientCommunicator _communicator;
        private System.Windows.Forms.Timer _fastTimer; // 5s  — KPIs + activity feed
        private System.Windows.Forms.Timer _slowTimer; // 30s — charts

        // KPI value labels (the big numbers)
        private Label _lblIncomeToday, _lblActiveClients, _lblTotalUsers, _lblSessionsToday;
        // KPI cards (panels) — kept so we can re-skin on theme change
        private Panel _cardIncome, _cardClients, _cardUsers, _cardSessions;

        // Charts
        private BarChartControl _hourlyChart;
        private HBarChartControl _gamesChart;

        // Activity feed
        private DataGridView _gvActivity;
        private Label _lblActivityTitle;

        // Header
        private Button _btnRefresh;
        private Label _lblHeaderTitle;

        // Charts row container (SplitContainer) — kept for resize handling
        private SplitContainer _chartsSplit;

        public DashboardForm(ClientCommunicator communicator)
        {
            _communicator = communicator;

            // === Form setup ===
            this.Text = "داشبورد زنده - GameNet";
            this.Size = new Size(1200, 760);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;
            this.Font = new Font("Segoe UI", 9F);
            this.DoubleBuffered = true;
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = ThemeManager.TextColor;

            BuildUi();

            // Apply the current theme to the whole form (walks the control tree).
            try { ThemeManager.ApplyTheme(this); } catch { }
            ApplyChartTheme();

            // Initial data load — charts first (so the operator sees the big
            // picture), then KPIs + activity feed.
            try { RefreshCharts(); } catch { }
            try { RefreshFast(); } catch { }

            // === Timers ===
            _fastTimer = new System.Windows.Forms.Timer { Interval = 5000 };
            _fastTimer.Tick += (s, e) => SafeRefreshFast();
            _fastTimer.Start();

            _slowTimer = new System.Windows.Forms.Timer { Interval = 30000 };
            _slowTimer.Tick += (s, e) => SafeRefreshCharts();
            _slowTimer.Start();
        }

        // ==================================================================================
        // UI construction
        // ==================================================================================

        private void BuildUi()
        {
            // Docking order matters: controls added FIRST are at the BACK and
            // dock LAST (so they fill what's left). We want top→bottom:
            // Header, KPI row, Charts row, Activity feed. So we add in the
            // reverse order: Activity (Fill) first, then Charts, KPI, Header.

            BuildActivityFeed();        // Fill
            BuildChartsRow();           // Top, 300px
            BuildKpiRow();              // Top, 116px
            BuildHeader();              // Top, 44px (frontmost)
        }

        // ── Header (title + refresh button) ─────────────────────────────────
        private void BuildHeader()
        {
            var header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 44,
                BackColor = ThemeManager.SurfaceColor,
            };

            _lblHeaderTitle = new Label
            {
                Text = "📊 داشبورد زنده",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = ThemeManager.AccentColor,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 12, 0),
            };

            _btnRefresh = new Button
            {
                Text = "🔄 بروزرسانی",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Size = new Size(120, 30),
                BackColor = ThemeManager.AccentColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Cursor = Cursors.Hand,
            };
            _btnRefresh.FlatAppearance.BorderSize = 0;
            _btnRefresh.Click += (s, e) =>
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;
                    RefreshCharts();
                    RefreshFast();
                    ToastNotification.Show(this, "داشبورد بروزرسانی شد", ToastType.Success, 1800);
                }
                catch (Exception ex)
                {
                    ToastNotification.Show(this, "خطا در بروزرسانی: " + ex.Message, ToastType.Error, 3000);
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                }
            };

            header.Controls.Add(_lblHeaderTitle);
            header.Controls.Add(_btnRefresh);
            // Position the refresh button at the right edge (RTL: visually left).
            // Using Anchor=Right + manual location because Dock=Fill on the label
            // would cover the button otherwise.
            header.Resize += (s, e) =>
            {
                _btnRefresh.Location = new Point(header.Width - _btnRefresh.Width - 10, 7);
            };
            // Trigger initial layout
            _btnRefresh.Location = new Point(header.Width - _btnRefresh.Width - 10, 7);

            this.Controls.Add(header);
        }

        // ── KPI row (4 cards) ────────────────────────────────────────────────
        private void BuildKpiRow()
        {
            var row = new Panel
            {
                Dock = DockStyle.Top,
                Height = 116,
                Padding = new Padding(10, 10, 10, 8),
                BackColor = ThemeManager.BackgroundColor,
            };
            row.Layout += (s, e) => LayoutKpiCards(row);

            _cardIncome   = MakeKpiCard("💰", "درآمد امروز",          "0",  ThemeManager.SuccessColor, out _lblIncomeToday);
            _cardClients  = MakeKpiCard("🖥️", "کلاینت‌های فعال",       "0",  ThemeManager.AccentColor,  out _lblActiveClients);
            _cardUsers    = MakeKpiCard("👥", "کل کاربران",            "0",  ThemeManager.WarningColor, out _lblTotalUsers);
            _cardSessions = MakeKpiCard("📊", "نشست‌های امروز",        "0",  ThemeManager.SuccessColor, out _lblSessionsToday);

            row.Controls.Add(_cardIncome);
            row.Controls.Add(_cardClients);
            row.Controls.Add(_cardUsers);
            row.Controls.Add(_cardSessions);

            this.Controls.Add(row);
            // Initial layout
            LayoutKpiCards(row);
        }

        private Panel MakeKpiCard(string icon, string title, string value, Color accentColor, out Label valueLabel)
        {
            var card = new Panel
            {
                Size = new Size(260, 96),
                BackColor = ThemeManager.SurfaceColor,
            };

            // Colored icon strip on the right (RTL: visually right edge accent)
            var iconStrip = new Panel
            {
                Size = new Size(6, 96),
                BackColor = accentColor,
                Dock = DockStyle.Right,
            };

            var lblIcon = new Label
            {
                Text = icon,
                Font = new Font("Segoe UI", 22F),
                ForeColor = accentColor,
                Location = new Point(12, 24),
                AutoSize = true,
            };

            var lblTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(147, 153, 178),
                Location = new Point(64, 16),
                AutoSize = true,
            };

            var lblValue = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                ForeColor = accentColor,
                Location = new Point(64, 42),
                AutoSize = true,
            };

            card.Controls.Add(iconStrip);
            card.Controls.Add(lblIcon);
            card.Controls.Add(lblTitle);
            card.Controls.Add(lblValue);

            valueLabel = lblValue;
            return card;
        }

        private void LayoutKpiCards(Panel row)
        {
            // 4 cards, evenly spaced, anchored to fill the row width.
            int count = 4;
            int gap = 10;
            int totalGap = gap * (count + 1);
            int cardW = Math.Max(180, (row.Width - totalGap) / count);
            int cardH = Math.Min(96, row.Height - 18);
            // RTL: place cards right-to-left so the first card is at the right.
            int x = gap;
            foreach (Control c in row.Controls)
            {
                c.Size = new Size(cardW, cardH);
                c.Location = new Point(x, 9);
                x += cardW + gap;
            }
        }

        // ── Charts row (2 charts side by side) ──────────────────────────────
        private void BuildChartsRow()
        {
            var row = new Panel
            {
                Dock = DockStyle.Top,
                Height = 300,
                Padding = new Padding(10, 4, 10, 8),
                BackColor = ThemeManager.BackgroundColor,
            };

            _chartsSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 540,
                BackColor = ThemeManager.BackgroundColor,
                SplitterWidth = 8,
            };

            // Left: hourly income bar chart
            var leftPanel = new Panel { Dock = DockStyle.Fill, BackColor = ThemeManager.SurfaceColor, Padding = new Padding(2) };
            _hourlyChart = new BarChartControl
            {
                Dock = DockStyle.Fill,
                Title = "درآمد ساعتی امروز",
                BarColor = ThemeManager.SuccessColor,
                YAxisLabel = "تومان",
            };
            leftPanel.Controls.Add(_hourlyChart);
            _chartsSplit.Panel1.Controls.Add(leftPanel);

            // Right: popular games horizontal bar chart
            var rightPanel = new Panel { Dock = DockStyle.Fill, BackColor = ThemeManager.SurfaceColor, Padding = new Padding(2) };
            _gamesChart = new HBarChartControl
            {
                Dock = DockStyle.Fill,
                Title = "بازی‌های محبوب",
            };
            rightPanel.Controls.Add(_gamesChart);
            _chartsSplit.Panel2.Controls.Add(rightPanel);

            row.Controls.Add(_chartsSplit);
            this.Controls.Add(row);
        }

        // ── Activity feed (DataGridView, full width) ────────────────────────
        private void BuildActivityFeed()
        {
            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10, 4, 10, 10),
                BackColor = ThemeManager.BackgroundColor,
            };

            _lblActivityTitle = new Label
            {
                Text = "فعالیت اخیر",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = ThemeManager.AccentColor,
                Dock = DockStyle.Top,
                Height = 26,
                TextAlign = ContentAlignment.MiddleLeft,
            };

            _gvActivity = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = ThemeManager.SurfaceColor,
                BorderStyle = BorderStyle.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    ForeColor = ThemeManager.AccentColor,
                    BackColor = ThemeManager.SurfaceColor,
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Segoe UI", 9F),
                    ForeColor = ThemeManager.TextColor,
                    BackColor = ThemeManager.SurfaceColor,
                    SelectionBackColor = ThemeManager.AccentColor,
                    SelectionForeColor = Color.White,
                },
                EnableHeadersVisualStyles = false,
                RowHeadersVisible = false,
                GridColor = ThemeManager.BorderColor,
            };

            _gvActivity.Columns.Add("colTime", "زمان");
            _gvActivity.Columns.Add("colCategory", "دسته");
            _gvActivity.Columns.Add("colAction", "رویداد");
            _gvActivity.Columns.Add("colDetails", "جزئیات");
            _gvActivity.Columns["colDetails"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _gvActivity.Columns["colTime"].Width = 130;
            _gvActivity.Columns["colCategory"].Width = 90;
            _gvActivity.Columns["colAction"].Width = 130;

            panel.Controls.Add(_gvActivity);
            panel.Controls.Add(_lblActivityTitle);
            this.Controls.Add(panel);
        }

        // ==================================================================================
        // Theme
        // ==================================================================================

        /// <summary>
        /// Re-applies theme colors to the custom chart controls + KPI cards.
        /// Called after construction and whenever the theme might have changed.
        /// (ThemeManager.ApplyTheme walks the form tree but doesn't know about
        /// our custom chart controls, so we refresh them manually.)
        /// </summary>
        private void ApplyChartTheme()
        {
            try
            {
                if (_hourlyChart != null)
                {
                    _hourlyChart.BarColor = ThemeManager.SuccessColor;
                    _hourlyChart.Invalidate();
                }
                if (_gamesChart != null) _gamesChart.Invalidate();
            }
            catch { }
        }

        // ==================================================================================
        // Data refresh
        // ==================================================================================

        private void SafeRefreshFast()
        {
            try { RefreshFast(); }
            catch (Exception ex) { AuditLog.Log("Dashboard", "Fast refresh error: " + ex.Message); }
        }

        private void SafeRefreshCharts()
        {
            try { RefreshCharts(); }
            catch (Exception ex) { AuditLog.Log("Dashboard", "Chart refresh error: " + ex.Message); }
        }

        /// <summary>Refreshes KPI cards + activity feed (called every 5s).</summary>
        /// <remarks>
        /// FIX B14: the previous version ran 4 SELECT queries + 1 audit_log
        /// query synchronously on the UI thread (the Timer.Tick handler).
        /// Each query blocks the message pump — on a busy server the 5s
        /// timer could stack 2-3 ticks of latency, freezing the dashboard
        /// repaint and the rest of the UI. Now the queries run on a
        /// ThreadPool thread via Task.Run, and a single BeginInvoke
        /// marshals the results to the UI thread for control updates.
        /// </remarks>
        private void RefreshFast()
        {
            // Skip if the form is closing/closed — the timer may have
            // already queued a Tick before we stopped it.
            if (this.IsDisposed || !this.IsHandleCreated) return;

            System.Threading.Tasks.Task.Run(() =>
            {
                // Capture all the data on the background thread — NO UI
                // access from here.
                string incomeStr;
                try
                {
                    // FIX-MONITOR-ADD5 TASK B4: cache the income KPI query for
                    // 30s. The dashboard's RefreshFast tick fires every 5s,
                    // but the SUM(total_cost) over today's client_sessions
                    // only changes meaningfully every 30s+ (a 1-hour session
                    // billed at 5000t/h adds ~1.4t per second; rounding to N0
                    // means the displayed value rarely changes inside a 30s
                    // window). Caching drops the SQLite load by 6x and
                    // eliminates the brief writer-lock stall that the live
                    // ClientCommunicator was hitting on every tick.
                    decimal income = DataCache.GetOrCompute(
                        "dashboard:income_today",
                        () => Database.Instance.QueryOne(
                            "SELECT COALESCE(SUM(total_cost),0) FROM client_sessions WHERE date(start_time)=date('now')",
                            null,
                            r => r.IsDBNull(0) ? 0m : Convert.ToDecimal(r.GetValue(0))),
                        TimeSpan.FromSeconds(30));
                    incomeStr = FormatToman(income);
                }
                catch (Exception ex) { AuditLog.Log("Dashboard", "Income KPI query failed: " + ex.Message); incomeStr = "—"; }

                string activeStr;
                try
                {
                    int active = 0;
                    if (_communicator != null)
                    {
                        active = _communicator.GetAllRawConnections()
                            .Count(c => c.State == ClientState.InSession);
                    }
                    activeStr = active.ToString();
                }
                catch (Exception ex) { AuditLog.Log("Dashboard", "Active clients KPI query failed: " + ex.Message); activeStr = "—"; }

                string usersStr;
                try
                {
                    int totalUsers = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM users",
                        null,
                        r => r.GetInt32(0));
                    usersStr = totalUsers.ToString();
                }
                catch (Exception ex) { AuditLog.Log("Dashboard", "Users KPI query failed: " + ex.Message); usersStr = "—"; }

                string sessionsStr;
                try
                {
                    int sessions = Database.Instance.QueryOne(
                        "SELECT COUNT(*) FROM client_sessions WHERE date(start_time)=date('now')",
                        null,
                        r => r.GetInt32(0));
                    sessionsStr = sessions.ToString();
                }
                catch (Exception ex) { AuditLog.Log("Dashboard", "Sessions KPI query failed: " + ex.Message); sessionsStr = "—"; }

                // Activity feed — capture the rows on the background thread,
                // then marshal to the UI for grid population.
                List<ActivityRow> activityRows = null;
                try
                {
                    activityRows = Database.Instance.Query(
                        "SELECT id, category, action, details, timestamp FROM audit_log ORDER BY id DESC LIMIT 20",
                        null,
                        r => new ActivityRow
                        {
                            Time = r.IsDBNull(4) ? "—" : ParseTimestamp(r.GetString(4)).ToString("yyyy-MM-dd HH:mm:ss"),
                            Category = r.IsDBNull(1) ? "" : r.GetString(1),
                            ActionLabel = MapEventLabel(r.IsDBNull(2) ? "" : r.GetString(2)),
                            RawAction = r.IsDBNull(2) ? "" : r.GetString(2),
                            Details = r.IsDBNull(3) ? "" : r.GetString(3),
                        });
                }
                catch (Exception ex) { AuditLog.Log("Dashboard", "Activity feed query failed: " + ex.Message); activityRows = null; }

                // Marshal the captured data to the UI thread for control updates.
                try
                {
                    if (!this.IsDisposed && this.IsHandleCreated)
                    {
                        this.BeginInvoke((Action)(() =>
                        {
                            try
                            {
                                if (this.IsDisposed) return;
                                _lblIncomeToday.Text = incomeStr;
                                _lblActiveClients.Text = activeStr;
                                _lblTotalUsers.Text = usersStr;
                                _lblSessionsToday.Text = sessionsStr;

                                if (activityRows != null)
                                {
                                    PopulateActivityGrid(activityRows);
                                }
                            }
                            catch (Exception ex) { AuditLog.Log("Dashboard", "Fast refresh UI update error: " + ex.Message); }
                        }));
                    }
                }
                catch (InvalidOperationException) { /* form closed mid-task */ }
                catch (Exception ex) { AuditLog.Log("Dashboard", "BeginInvoke failed: " + ex.Message); }
            });
        }

        /// <summary>Refreshes the two charts (called every 30s).</summary>
        private void RefreshCharts()
        {
            // ── Left chart: hourly income today (24 bars, 00-23) ──────────────
            var hourly = new Dictionary<string, double>();
            try
            {
                // Initialize all 24 hours to 0 so empty hours still show a slot.
                for (int h = 0; h < 24; h++) hourly[h.ToString("00")] = 0;

                var rows = Database.Instance.Query(
                    "SELECT strftime('%H', start_time) as hour, SUM(total_cost) as income FROM client_sessions WHERE date(start_time)=date('now') GROUP BY hour",
                    null,
                    r =>
                    {
                        string hr = r.IsDBNull(0) ? "00" : r.GetString(0);
                        decimal inc = r.IsDBNull(1) ? 0m : Convert.ToDecimal(r.GetValue(1));
                        return new { Hour = hr, Income = inc };
                    });
                foreach (var r in rows)
                {
                    if (hourly.ContainsKey(r.Hour)) hourly[r.Hour] = (double)r.Income;
                }
            }
            catch (Exception ex) { AuditLog.Log("Dashboard", "Hourly chart query failed: " + ex.Message); }

            _hourlyChart.SetData(
                hourly.Values.ToArray(),
                hourly.Keys.ToArray());

            // ── Right chart: popular games (top 5 by session count) ───────────
            var games = new List<KeyValuePair<string, double>>();
            try
            {
                var rows = Database.Instance.Query(
                    "SELECT current_game, COUNT(*) as cnt FROM client_sessions WHERE current_game != '' AND current_game IS NOT NULL GROUP BY current_game ORDER BY cnt DESC LIMIT 5",
                    null,
                    r => new { Game = r.IsDBNull(0) ? "؟" : r.GetString(0), Count = (double)r.GetInt32(1) });
                foreach (var r in rows) games.Add(new KeyValuePair<string, double>(r.Game, r.Count));
            }
            catch (Exception ex) { AuditLog.Log("Dashboard", "Games chart query failed: " + ex.Message); }

            _gamesChart.SetData(games);
        }

        /// <summary>Refreshes the activity feed DataGridView (last 20 audit_log rows).</summary>
        /// <remarks>
        /// FIX B14: this method now runs on the UI thread ONLY to populate the
        /// grid from a pre-fetched list when called from the manual refresh
        /// button. The DB query inside is acceptable for one-off manual use.
        /// For periodic refresh, <see cref="RefreshFast"/> runs the same query
        /// on a background thread and calls <see cref="PopulateActivityGrid"/>
        /// directly.
        /// </remarks>
        private void RefreshActivity()
        {
            if (_gvActivity.InvokeRequired)
            {
                try { _gvActivity.BeginInvoke(new Action(RefreshActivity)); } catch { }
                return;
            }

            List<ActivityRow> rows;
            try
            {
                rows = Database.Instance.Query(
                    "SELECT id, category, action, details, timestamp FROM audit_log ORDER BY id DESC LIMIT 20",
                    null,
                    r => new ActivityRow
                    {
                        Time = r.IsDBNull(4) ? "—" : ParseTimestamp(r.GetString(4)).ToString("yyyy-MM-dd HH:mm:ss"),
                        Category = r.IsDBNull(1) ? "" : r.GetString(1),
                        ActionLabel = MapEventLabel(r.IsDBNull(2) ? "" : r.GetString(2)),
                        RawAction = r.IsDBNull(2) ? "" : r.GetString(2),
                        Details = r.IsDBNull(3) ? "" : r.GetString(3),
                    });
            }
            catch (Exception ex)
            {
                AuditLog.Log("Dashboard", "Activity feed query failed: " + ex.Message);
                return;
            }
            PopulateActivityGrid(rows);
        }

        /// <summary>
        /// FIX B14: pure UI-thread helper that fills the activity grid from a
        /// pre-fetched list. Must be called on the UI thread.
        /// </summary>
        private void PopulateActivityGrid(List<ActivityRow> rows)
        {
            if (_gvActivity == null || _gvActivity.IsDisposed) return;
            try
            {
                _gvActivity.RowsClearSafe();
                if (rows != null)
                {
                    foreach (var r in rows)
                    {
                        _gvActivity.Rows.Add(r.Time, r.Category, r.ActionLabel, r.Details);
                    }
                }

                // Color-code rows by event type for quick scanning
                foreach (DataGridViewRow row in _gvActivity.Rows)
                {
                    try
                    {
                        string ev = Convert.ToString(row.Cells["colAction"].Value) ?? "";
                        if (ev.IndexOf("ورود", StringComparison.Ordinal) >= 0 || ev.IndexOf("login", StringComparison.OrdinalIgnoreCase) >= 0)
                            row.DefaultCellStyle.ForeColor = ThemeManager.SuccessColor;
                        else if (ev.IndexOf("خروج", StringComparison.Ordinal) >= 0 || ev.IndexOf("logout", StringComparison.OrdinalIgnoreCase) >= 0)
                            row.DefaultCellStyle.ForeColor = ThemeManager.WarningColor;
                        else if (ev.IndexOf("شارژ", StringComparison.Ordinal) >= 0 || ev.IndexOf("topup", StringComparison.OrdinalIgnoreCase) >= 0)
                            row.DefaultCellStyle.ForeColor = ThemeManager.AccentColor;
                        else if (ev.IndexOf("پایان", StringComparison.Ordinal) >= 0 || ev.IndexOf("end", StringComparison.OrdinalIgnoreCase) >= 0 || ev.IndexOf("خطا", StringComparison.Ordinal) >= 0 || ev.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0)
                            row.DefaultCellStyle.ForeColor = ThemeManager.ErrorColor;
                    }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("Dashboard", "PopulateActivityGrid error: " + ex.Message);
            }
        }

        /// <summary>Maps a raw audit action to a friendlier Persian event label.</summary>
        private static string MapEventLabel(string action)
        {
            if (string.IsNullOrEmpty(action)) return "—";
            string a = action.ToLowerInvariant();
            if (a.Contains("login")) return "🔑 ورود";
            if (a.Contains("logout")) return "🚪 خروج";
            if (a.Contains("topup") || a.Contains("recharge") || a.Contains("charge") || a.Contains("credit")) return "💰 شارژ";
            if (a.Contains("session") && (a.Contains("end") || a.Contains("stop") || a.Contains("close"))) return "🏁 پایان نشست";
            if (a.Contains("session") && (a.Contains("start") || a.Contains("begin"))) return "▶️ شروع نشست";
            if (a.Contains("lock")) return "🔒 قفل";
            if (a.Contains("unlock")) return "🔓 باز کردن";
            if (a.Contains("shutdown")) return "⏻ خاموشی";
            if (a.Contains("restart")) return "🔄 ری‌استارت";
            if (a.Contains("error") || a.Contains("fail")) return "❌ خطا";
            if (a.Contains("backup")) return "💾 بکاپ";
            // Default: return the raw action (truncated) so nothing is hidden.
            return action.Length > 40 ? action.Substring(0, 40) + "…" : action;
        }

        private static DateTime ParseTimestamp(string s)
        {
            DateTime dt;
            if (DateTime.TryParse(s, null, System.Globalization.DateTimeStyles.RoundtripKind, out dt))
                return dt.Kind == DateTimeKind.Utc ? dt.ToLocalTime() : dt;
            return DateTime.MinValue;
        }

        private static string FormatToman(decimal amount)
        {
            if (amount == 0) return "0";
            return amount.ToString("N0");
        }

        // FIX B14: plain DTO for the activity feed rows. The previous code
        // used an anonymous type which can't cross thread boundaries easily
        // (Task.Run returns the result via the captured closure, but the
        // explicit type makes the data flow clearer and lets us pre-compute
        // the display strings on the background thread).
        private sealed class ActivityRow
        {
            public string Time;
            public string Category;
            public string ActionLabel;
            public string RawAction;
            public string Details;
        }

        // ==================================================================================
        // Lifecycle
        // ==================================================================================

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // Re-apply theme once the form is fully loaded (handles any controls
            // that ThemeManager.ApplyTheme missed during construction).
            try { ThemeManager.ApplyTheme(this); ApplyChartTheme(); } catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { _fastTimer?.Stop(); _fastTimer?.Dispose(); } catch { }
            try { _slowTimer?.Stop(); _slowTimer?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }

    // ==================================================================================
    // Custom chart controls (GDI+ — no external dependency)
    // ==================================================================================

    /// <summary>
    /// Vertical bar chart. Draws a title, a Y-axis with 4 grid lines, and one
    /// bar per data point. Empty data shows a "داده‌ای موجود نیست" placeholder.
    /// Theme-aware: reads ThemeManager colors on every paint so a theme switch
    /// is picked up on the next invalidate.
    /// </summary>
    internal class BarChartControl : Control
    {
        private double[] _values = new double[0];
        private string[] _labels = new string[0];
        public string Title = "";
        public string YAxisLabel = "";
        public Color BarColor = Color.FromArgb(166, 227, 161);

        // FIX B4: static cached fonts. The previous OnPaint created ~5 Font
        // objects on every paint (called at 30Hz on the dashboard timer + on
        // every resize). Each Font wraps a GDI handle — they were never
        // disposed, leaking ~150 handles/minute. Static fonts live for the
        // process lifetime and are never disposed.
        private static readonly Font _titleFont = new Font("Segoe UI", 11F, FontStyle.Bold);
        private static readonly Font _emptyFont = new Font("Segoe UI", 10F);
        private static readonly Font _axisFont = new Font("Segoe UI", 7.5F);

        public BarChartControl()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.BackColor = ThemeManager.SurfaceColor;
        }

        public void SetData(double[] values, string[] labels)
        {
            _values = values ?? new double[0];
            _labels = labels ?? new string[0];
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color surface = ThemeManager.SurfaceColor;
            Color text = ThemeManager.TextColor;
            Color accent = ThemeManager.AccentColor;
            Color border = ThemeManager.BorderColor;
            Color muted = Color.FromArgb(147, 153, 178);

            // Title
            if (!string.IsNullOrEmpty(Title))
            {
                using (var titleBrush = new SolidBrush(accent))
                    g.DrawString(Title, _titleFont, titleBrush, 14, 8);
            }

            if (_values.Length == 0)
            {
                using (var emptyBrush = new SolidBrush(muted))
                    g.DrawString("داده‌ای موجود نیست", _emptyFont, emptyBrush, 20, 50);
                return;
            }

            // Chart area (leave room for title, Y labels, X labels)
            int left = 56, top = 36, right = 14, bottom = 34;
            int cw = this.Width - left - right;
            int ch = this.Height - top - bottom;
            if (cw < 40 || ch < 40) return;

            double max = _values.Max();
            if (max <= 0) max = 1;

            // Y axis grid (4 lines) + labels
            // FIX B4: wrap the Pen in `using` so its GDI handle is released.
            using (var gridPen = new Pen(border, 1) { DashStyle = DashStyle.Dot })
            using (var mutedBrush = new SolidBrush(muted))
            {
                for (int i = 0; i <= 4; i++)
                {
                    double val = max * (4 - i) / 4;
                    int y = top + (ch * i / 4);
                    g.DrawLine(gridPen, left, y, left + cw, y);
                    g.DrawString(FormatValue(val), _axisFont, mutedBrush, 4, y - 7);
                }
            }

            // Bars
            int n = _values.Length;
            int slot = cw / n;
            int barW = Math.Max(3, slot - 3);
            // FIX B4: dispose the bar brushes after painting (created once
            // per OnPaint, not once per bar).
            using (var barBrush = new SolidBrush(BarColor))
            using (var barBrushLight = new SolidBrush(Color.FromArgb(
                Math.Min(255, BarColor.R + 35),
                Math.Min(255, BarColor.G + 35),
                Math.Min(255, BarColor.B + 35))))
            {
                for (int i = 0; i < n; i++)
                {
                    if (_values[i] <= 0) continue;
                    int bh = (int)(_values[i] / max * ch);
                    if (bh < 1) bh = 1;
                    int bx = left + i * slot + (slot - barW) / 2;
                    int by = top + ch - bh;
                    g.FillRectangle(barBrush, bx, by, barW, bh);
                    g.FillRectangle(barBrushLight, bx, by, barW, 2); // top highlight
                }
            }

            // X axis labels — show every Nth label so they don't overlap.
            using (var labelBrush = new SolidBrush(text))
            {
                int labelEvery = Math.Max(1, n / 12);
                for (int i = 0; i < n; i += labelEvery)
                {
                    int x = left + i * slot + slot / 2;
                    string label = i < _labels.Length ? _labels[i] : "";
                    var sz = g.MeasureString(label, _axisFont);
                    g.DrawString(label, _axisFont, labelBrush, x - sz.Width / 2, top + ch + 6);
                }
            }
        }

        private static string FormatValue(double v)
        {
            if (v >= 1000000) return (v / 1000000).ToString("0.0") + "M";
            if (v >= 1000) return (v / 1000).ToString("0") + "k";
            return v.ToString("0");
        }
    }

    /// <summary>
    /// Horizontal bar chart — ideal for "top N" lists where the labels (game
    /// names) are long. Each row = label on the right (RTL) + colored bar
    /// extending left. Empty data shows a "داده‌ای موجود نیست" placeholder.
    /// </summary>
    internal class HBarChartControl : Control
    {
        private List<KeyValuePair<string, double>> _data = new List<KeyValuePair<string, double>>();
        public string Title = "";
        private static readonly Color[] Palette = new Color[]
        {
            Color.FromArgb(137, 180, 250), // accent blue
            Color.FromArgb(166, 227, 161), // green
            Color.FromArgb(249, 226, 175), // yellow
            Color.FromArgb(203, 166, 247), // purple
            Color.FromArgb(148, 226, 213), // teal
            Color.FromArgb(243, 139, 168), // red
        };

        // FIX B4: static cached fonts (see BarChartControl for rationale).
        private static readonly Font _titleFont = new Font("Segoe UI", 11F, FontStyle.Bold);
        private static readonly Font _emptyFont = new Font("Segoe UI", 10F);
        private static readonly Font _labelFont = new Font("Segoe UI", 9F);
        private static readonly Font _valueFont = new Font("Segoe UI", 8.5F);

        public HBarChartControl()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.BackColor = ThemeManager.SurfaceColor;
        }

        public void SetData(List<KeyValuePair<string, double>> data)
        {
            _data = data ?? new List<KeyValuePair<string, double>>();
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color surface = ThemeManager.SurfaceColor;
            Color text = ThemeManager.TextColor;
            Color accent = ThemeManager.AccentColor;
            Color border = ThemeManager.BorderColor;
            Color muted = Color.FromArgb(147, 153, 178);

            // Title
            if (!string.IsNullOrEmpty(Title))
            {
                using (var titleBrush = new SolidBrush(accent))
                    g.DrawString(Title, _titleFont, titleBrush, 14, 8);
            }

            if (_data.Count == 0)
            {
                using (var emptyBrush = new SolidBrush(muted))
                    g.DrawString("داده‌ای موجود نیست", _emptyFont, emptyBrush, 20, 50);
                return;
            }

            // Layout: title at top, then N rows. Each row has a label area on
            // the right (RTL) and a bar area on the left.
            int top = 36;
            int pad = 12;
            int bottomPad = 10;
            int labelW = 140;
            int availH = this.Height - top - bottomPad;
            int n = _data.Count;
            int rowH = availH / n;
            if (rowH < 18) rowH = 18;
            int barH = Math.Max(8, rowH - 8);

            double max = _data.Max(x => x.Value);
            if (max <= 0) max = 1;

            var barAreaX = pad;
            var barAreaW = this.Width - pad - labelW - pad;

            // Grid: vertical line separating labels from bars
            // FIX B4: dispose the Pen + text brush. Previously created per
            // paint and never disposed.
            using (var gridPen = new Pen(border, 1))
            using (var textBrush = new SolidBrush(text))
            {
                g.DrawLine(gridPen, this.Width - pad - labelW, top - 4, this.Width - pad - labelW, top + availH);

                for (int i = 0; i < n; i++)
                {
                    var kvp = _data[i];
                    int rowY = top + i * rowH;
                    int barY = rowY + (rowH - barH) / 2;
                    int barLen = (int)(kvp.Value / max * barAreaW);
                    if (barLen < 2) barLen = 2;

                    Color c = Palette[i % Palette.Length];
                    // Bar (extends from left toward the label area)
                    // FIX B4: dispose the bar brushes inside the loop. Each
                    // iteration created 2 SolidBrush instances that were never
                    // released — at 30Hz repaint × N rows this leaked hundreds
                    // of GDI handles per minute.
                    using (var barBrush = new SolidBrush(c))
                    using (var lightBrush = new SolidBrush(Color.FromArgb(Math.Min(255, c.R + 35), Math.Min(255, c.G + 35), Math.Min(255, c.B + 35))))
                    {
                        g.FillRectangle(barBrush, barAreaX, barY, barLen, barH);
                        // Light top edge
                        g.FillRectangle(lightBrush, barAreaX, barY, barLen, 2);
                    }

                    // Value at the end of the bar
                    string valStr = kvp.Value.ToString("0");
                    g.DrawString(valStr, _valueFont, textBrush, barAreaX + barLen + 4, barY - 1);

                    // Label (right side, right-aligned to the grid line)
                    string label = kvp.Key;
                    if (label.Length > 18) label = label.Substring(0, 17) + "…";
                    var lblSz = g.MeasureString(label, _labelFont);
                    g.DrawString(label, _labelFont, textBrush, this.Width - pad - labelW + 6, rowY + (rowH - (int)lblSz.Height) / 2);
                }
            }
        }
    }

    /// <summary>Small extension so we can clear rows without a try/catch at every call site.</summary>
    internal static class DataGridViewExtensions
    {
        public static void RowsClearSafe(this DataGridView dgv)
        {
            try { dgv.Rows.Clear(); } catch { }
        }
    }
}
