using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Chat form: send/receive messages to/from clients. Supports direct and broadcast messaging.
    /// </summary>
    public class ChatForm : Form
    {
        private ClientCommunicator _communicator;
        private ListBox _lbUsers;
        private RichTextBox _rtbChat;
        private TextBox _txtMessage;
        private ChatManager _chatMgr;

        public ChatForm(ClientCommunicator communicator)
        {
            _communicator = communicator;
            _chatMgr = new ChatManager();

            this.Text = "چت - GameNet";
            this.Size = new Size(800, 550);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Users list
            var lblUsers = new Label { Text = "کاربران آنلاین:", Location = new Point(20, 10), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180) };
            _lbUsers = new ListBox
            {
                Location = new Point(20, 35), Size = new Size(180, 450),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F)
            };
            _lbUsers.Items.Add("[همه - پخش عمومی]");
            RefreshUserList();

            // Chat area
            _rtbChat = new RichTextBox
            {
                Location = new Point(220, 35), Size = new Size(540, 380),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 11F),
                ReadOnly = true,
                ScrollBars = RichTextBoxScrollBars.Vertical
            };

            // Message input
            _txtMessage = new TextBox
            {
                Location = new Point(220, 425), Size = new Size(420, 35),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(128, 128, 128),
                Font = new Font("Segoe UI", 11F),
                Text = "پیام خود را بنویسید..."
            };
            _txtMessage.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) SendMessage(); };
            var _placeholderText = "پیام خود را بنویسید...";
            _txtMessage.GotFocus += (s, e) => { if (_txtMessage.Text == _placeholderText) { _txtMessage.Text = ""; _txtMessage.ForeColor = Color.FromArgb(40, 40, 40); } };
            _txtMessage.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(_txtMessage.Text)) { _txtMessage.Text = _placeholderText; _txtMessage.ForeColor = Color.FromArgb(128, 128, 128); } };

            var btnSend = new Button
            {
                Text = "ارسال", Location = new Point(650, 425), Size = new Size(110, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnSend.Click += (s, e) => SendMessage();

            var btnRefresh = new Button
            {
                Text = "به‌روزرسانی", Location = new Point(220, 470), Size = new Size(110, 30),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213))
            };
            btnRefresh.Click += (s, e) => { RefreshUserList(); LoadChatHistory(); };

            this.Controls.AddRange(new Control[] { lblUsers, _lbUsers, _rtbChat, _txtMessage, btnSend, btnRefresh });

            _lbUsers.SelectedIndexChanged += (s, e) => LoadChatHistory();
            LoadChatHistory();
        }

        private void SendMessage()
        {
            string msg = _txtMessage.Text.Trim();
            if (string.IsNullOrEmpty(msg)) return;

            bool isBroadcast = _lbUsers.SelectedIndex == 0 || _lbUsers.SelectedIndex == -1;
            string target = isBroadcast ? null : _lbUsers.SelectedItem?.ToString();

            try
            {
                var chatMsg = _chatMgr.SendMessage("operator", msg, target, isBroadcast);

                // Send to client(s) via communicator
                if (isBroadcast)
                {
                    _communicator?.BroadcastMessage(new NetMessage(MessageType.ServerChatReceive, chatMsg));
                }
                else if (!string.IsNullOrEmpty(target))
                {
                    // Send to specific station that this user is on
                    foreach (var client in _communicator?.ConnectedClients ?? new List<ConnectedClient>())
                    {
                        if (client.CurrentUser == target)
                        {
                            _communicator.SendToStation(client.StationName, new NetMessage(MessageType.ServerChatReceive, chatMsg));
                            break;
                        }
                    }
                }

                _txtMessage.Clear();
                AppendChatMessage(chatMsg);
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void LoadChatHistory()
        {
            _rtbChat.Clear();
            string target = _lbUsers.SelectedIndex > 0 ? _lbUsers.SelectedItem?.ToString() : null;

            ChatHistoryPayload history;
            if (!string.IsNullOrEmpty(target))
                history = _chatMgr.GetConversation("operator", target);
            else
                history = _chatMgr.GetRecentBroadcasts();

            foreach (var msg in history.Messages)
                AppendChatMessage(msg);
        }

        private void AppendChatMessage(ChatReceivePayload msg)
        {
            string time = msg.Timestamp.ToLocalTime().ToString("HH:mm");
            string sender = msg.IsSystem ? "سیستم" : msg.SenderDisplayName;
            _rtbChat.SelectionStart = _rtbChat.TextLength;
            _rtbChat.SelectionLength = 0;
            _rtbChat.SelectionColor = msg.IsSystem ? Color.FromArgb(243, 139, 168) :
                                      msg.SenderUsername == "operator" ? Color.FromArgb(137, 180, 250) :
                                      Color.FromArgb(166, 227, 161);
            _rtbChat.AppendText($"[{time}] {sender}: ");
            _rtbChat.SelectionColor = Color.FromArgb(40, 40, 40);
            _rtbChat.AppendText($"{msg.Message}\n");
            _rtbChat.ScrollToCaret();
        }

        private void RefreshUserList()
        {
            string selected = _lbUsers.SelectedIndex > 0 ? _lbUsers.SelectedItem?.ToString() : null;
            _lbUsers.Items.Clear();
            _lbUsers.Items.Add("[همه - پخش عمومی]");

            if (_communicator != null)
            {
                foreach (var client in _communicator.ConnectedClients)
                {
                    if (!string.IsNullOrEmpty(client.CurrentUser) && !_lbUsers.Items.Contains(client.CurrentUser))
                        _lbUsers.Items.Add(client.CurrentUser);
                }
            }

            if (selected != null && _lbUsers.Items.Contains(selected))
                _lbUsers.SelectedItem = selected;
            else
                _lbUsers.SelectedIndex = 0;
        }
    }
}
