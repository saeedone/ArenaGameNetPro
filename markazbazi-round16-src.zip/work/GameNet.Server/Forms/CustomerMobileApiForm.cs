using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// PRO: Customer mobile API placeholder form. Displays the list of
    /// mobile-API features the system can expose to the customer-facing
    /// mobile app, and a one-line message explaining that this is a
    /// placeholder for the upcoming mobile API. No CRUD — read-only.
    /// </summary>
    public class CustomerMobileApiForm : Form
    {
        private readonly CustomerMobileApi _api = new CustomerMobileApi();

        public CustomerMobileApiForm()
        {
            this.Text = "API موبایل مشتری - markazbazi";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            BuildUi();
        }

        private void BuildUi()
        {
            var pnl = new Panel { Dock = DockStyle.Top, Height = 90, BackColor = Color.FromArgb(255, 255, 255), Padding = new Padding(15) };
            var lblTitle = new Label
            {
                Text = "📱 API موبایل مشتری",
                Location = new Point(10, 10),
                AutoSize = true,
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
            };
            var lblMsg = new Label
            {
                Text = "این یک ماژول جایگزین (placeholder) برای API موبایل آینده است. ویژگی‌های زیر در نسخه نهایی در دسترس مشتریان خواهد بود.",
                Location = new Point(10, 45),
                Size = new Size(860, 40),
                ForeColor = Color.FromArgb(180, 140, 20),
                Font = new Font("Segoe UI", 9F),
            };
            pnl.Controls.AddRange(new Control[] { lblTitle, lblMsg });

            var dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            dgv.Columns.Add("colName", "ویژگی");
            dgv.Columns.Add("colEndpoint", "مسیر API");
            dgv.Columns.Add("colAvail", "در دسترس");

            try
            {
                foreach (var f in _api.GetFeatures())
                    dgv.Rows.Add(f.Name, f.Endpoint, f.Available ? "✅ بله" : "❌ خیر");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }

            Controls.AddRange(new Control[] { dgv, pnl });

            // Pop a one-time info message — the task spec says "mobileapi
            // just shows a message".
            this.Shown += (s, e) =>
            {
                MessageBox.Show(
                    "📱 API موبایل مشتری در حال حاضر یک ماژول جایگزین (placeholder) است.\n\n" +
                    "در نسخه نهایی، اپلیکیشن موبایل مشتری می‌تواند از این API برای:\n" +
                    "  • مشاهده موجودی و تاریخچه نشست‌ها\n" +
                    "  • شارژ آنلاین حساب\n" +
                    "  • مشاهده امتیازات وفاداری و کدهای تخفیف\n" +
                    "  • رزرو ایستگاه و سفارش غذا\n" +
                    "  • پشتیبانی آنلاین\n\n" +
                    "استفاده کند.\n\n" +
                    "آدرس پایه: " + _api.GetBaseUrl(),
                    "اطلاعیه API موبایل",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            };
        }
    }
}
