using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Debt management form: create debts, view unpaid, mark as paid.
    /// </summary>
    public class DebtForm : Form
    {
        private ListView _lvDebts;
        private TextBox _txtUsername, _txtAmount, _txtDescription, _txtNotes;
        private DateTimePicker _dtpDueDate;
        private CheckBox _chkNoDueDate;
        private Label _lblTotalDebt;

        public DebtForm()
        {
            this.Text = "مدیریت بدهی - GameNet";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت بدهی‌ها (مچال)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Input fields
            var lblUser = new Label { Text = "کاربر:", Location = new Point(20, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtUsername = new TextBox { Location = new Point(80, 48), Size = new Size(150, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblAmount = new Label { Text = "مبلغ:", Location = new Point(250, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtAmount = new TextBox { Location = new Point(300, 48), Size = new Size(120, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblDesc = new Label { Text = "توضیحات:", Location = new Point(440, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtDescription = new TextBox { Location = new Point(510, 48), Size = new Size(200, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            _chkNoDueDate = new CheckBox
            {
                Text = "بدون سررسید", Location = new Point(20, 90), AutoSize = true,
                Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40), Checked = true
            };
            var lblDue = new Label { Text = "سررسید:", Location = new Point(170, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpDueDate = new DateTimePicker { Location = new Point(230, 88), Size = new Size(150, 30), Format = DateTimePickerFormat.Short, Enabled = false };
            _chkNoDueDate.CheckedChanged += (s, e) => _dtpDueDate.Enabled = !_chkNoDueDate.Checked;

            var lblNotes = new Label { Text = "یادداشت:", Location = new Point(400, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtNotes = new TextBox { Location = new Point(470, 88), Size = new Size(240, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            // Buttons
            var btnCreate = new Button
            {
                Text = "ثبت بدهی", Location = new Point(20, 130), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnCreate.Click += (s, e) => CreateDebt();

            var btnPay = new Button
            {
                Text = "پرداخت کامل", Location = new Point(150, 130), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnPay.Click += (s, e) => PayDebt();

            var btnPartialPay = new Button
            {
                Text = "پرداخت جزئی", Location = new Point(280, 130), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            btnPartialPay.Click += (s, e) => PartialPayDebt();

            var btnDelete = new Button
            {
                Text = "حذف", Location = new Point(410, 130), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnDelete.Click += (s, e) => DeleteDebt();

            // Stats
            _lblTotalDebt = new Label
            {
                Location = new Point(520, 133), AutoSize = true,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(200, 30, 60)
            };

            // Debt list
            _lvDebts = new ListView
            {
                Location = new Point(20, 175),
                Size = new Size(840, 360),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvDebts.Columns.Add("ID", 40);
            _lvDebts.Columns.Add("کاربر", 120);
            _lvDebts.Columns.Add("مبلغ", 100);
            _lvDebts.Columns.Add("توضیحات", 200);
            _lvDebts.Columns.Add("وضعیت", 70);
            _lvDebts.Columns.Add("تاریخ ایجاد", 120);
            _lvDebts.Columns.Add("سررسید", 100);
            _lvDebts.Columns.Add("تاریخ پرداخت", 120);

            _lvDebts.SelectedIndexChanged += (s, e) =>
            {
                if (_lvDebts.SelectedItems.Count == 0) return;
                var item = _lvDebts.SelectedItems[0];
                _txtUsername.Text = item.SubItems[1].Text;
                _txtAmount.Text = item.SubItems[2].Text.Replace(",", "");
                _txtDescription.Text = item.SubItems[3].Text;
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblUser, _txtUsername, lblAmount, _txtAmount, lblDesc, _txtDescription, _chkNoDueDate, lblDue, _dtpDueDate, lblNotes, _txtNotes, btnCreate, btnPay, btnPartialPay, btnDelete, _lblTotalDebt, _lvDebts });
            RefreshList();
        }

        private void CreateDebt()
        {
            // FIX SEV-2: was decimal.Parse (throws a raw, unfriendly
            // English exception message like "Input string was not in a
            // correct format" on bad input) with no amount>0 check —
            // inconsistent with PayDebt's PartialPay handler a few lines
            // down, which already used TryParse correctly. Matches that
            // pattern now.
            if (string.IsNullOrWhiteSpace(_txtUsername.Text))
            {
                MessageBox.Show("نام کاربری را وارد کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!decimal.TryParse(_txtAmount.Text, out decimal amount) || amount <= 0)
            {
                MessageBox.Show("مبلغ معتبر وارد کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                DateTime? dueDate = _chkNoDueDate.Checked ? (DateTime?)null : _dtpDueDate.Value;
                new DebtManager().CreateDebt(_txtUsername.Text, amount, _txtDescription.Text, dueDate, _txtNotes.Text, "operator");
                _txtUsername.Clear(); _txtAmount.Clear(); _txtDescription.Clear(); _txtNotes.Clear();
                RefreshList();
                MessageBox.Show("بدهی ثبت شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void PayDebt()
        {
            if (_lvDebts.SelectedItems.Count == 0) return;
            int id = (int)_lvDebts.SelectedItems[0].Tag;
            try
            {
                new DebtManager().PayDebt(id);
                RefreshList();
                MessageBox.Show("بدهی پرداخت شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void PartialPayDebt()
        {
            if (_lvDebts.SelectedItems.Count == 0) return;
            int id = (int)_lvDebts.SelectedItems[0].Tag;
            string input = Microsoft.VisualBasic.Interaction.InputBox("مبلغ پرداخت (تومان):", "پرداخت جزئی", "0", -1, -1);
            if (decimal.TryParse(input, out decimal amount) && amount > 0)
            {
                try
                {
                    new DebtManager().PartialPayDebt(id, amount);
                    RefreshList();
                    MessageBox.Show("پرداخت جزئی انجام شد");
                }
                catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
            }
        }

        private void DeleteDebt()
        {
            if (_lvDebts.SelectedItems.Count == 0) return;
            int id = (int)_lvDebts.SelectedItems[0].Tag;
            if (MessageBox.Show("آیا از حذف مطمئن هستید؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                new DebtManager().DeleteDebt(id);
                RefreshList();
            }
        }

        private void RefreshList()
        {
            _lvDebts.Items.Clear();
            var mgr = new DebtManager();
            var debts = mgr.GetAllUnpaidDebts();

            // Also load paid debts
            var allDebts = Database.Instance.Query(
                "SELECT id, username, amount, description, is_paid, created_at, due_date, paid_at, notes FROM debts ORDER BY is_paid ASC, created_at DESC LIMIT 100",
                null,
                r => new DebtPayload
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    Amount = r.GetDecimal(2),
                    Description = r.IsDBNull(3) ? "" : r.GetString(3),
                    IsPaid = r.GetBoolean(4),
                    CreatedAt = r.GetDateTime(5),
                    DueDate = r.IsDBNull(6) ? (DateTime?)null : r.GetDateTime(6),
                    PaidAt = r.IsDBNull(7) ? (DateTime?)null : r.GetDateTime(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8)
                });

            decimal totalDebt = 0;
            foreach (var d in allDebts)
            {
                var item = new ListViewItem(d.Id.ToString());
                item.SubItems.Add(d.Username);
                item.SubItems.Add($"{d.Amount:N0}");
                item.SubItems.Add(d.Description);
                item.SubItems.Add(d.IsPaid ? "پرداخت" : "معلق");
                item.SubItems.Add(d.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd"));
                item.SubItems.Add(d.DueDate?.ToLocalTime().ToString("yyyy/MM/dd") ?? "-");
                item.SubItems.Add(d.PaidAt?.ToLocalTime().ToString("yyyy/MM/dd") ?? "-");
                item.Tag = d.Id;

                if (!d.IsPaid)
                {
                    totalDebt += d.Amount;
                    item.ForeColor = Color.FromArgb(200, 30, 60);
                }
                else
                {
                    item.ForeColor = Color.FromArgb(20, 130, 50);
                }

                _lvDebts.Items.Add(item);
            }

            _lblTotalDebt.Text = $"جمع بدهی‌های معلق: {totalDebt:N0} تومان";
        }
    }
}
