using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Advanced report generator with print/preview support. Produces a
    /// structured text + table report (no external PDF library needed —
    /// uses the built-in PrintDocument which can print to "Microsoft Print
    /// to PDF" on Windows 10+). Reports:
    ///   • Daily revenue report
    ///   • Weekly summary
    ///   • User activity report
    ///   • Session log report
    ///   • Financial summary
    /// The operator picks a date range and report type, previews it, then
    /// prints/saves to PDF.
    /// </summary>
    public class AdvancedReportForm : Form
    {
        private ComboBox _cboReportType;
        private DateTimePicker _dtpStart, _dtpEnd;
        private TextBox _txtPreview;
        private Button _btnGenerate, _btnPrint, _btnSave, _btnSaveCsv;
        private PrintDocument _printDoc;
        private string _currentReportText = "";
        private string _currentCsv = "";

        public AdvancedReportForm()
        {
            this.Text = "📊 گزارش‌گیری پیشرفته";
            this.Size = new Size(900, 700);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
        }

        private void BuildUi()
        {
            // Top control panel
            var topPanel = new Panel { Dock = DockStyle.Top, Height = 80, BackColor = Color.FromArgb(240, 240, 240) };

            var lblType = new Label { Text = "نوع گزارش:", Location = new Point(15, 10), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _cboReportType = new ComboBox { Location = new Point(15, 30), Size = new Size(250, 30), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            _cboReportType.Items.AddRange(new object[] {
                "📊 گزارش درآمد روزانه",
                "📅 گزارش خلاصه هفتگی",
                "👤 گزارش فعالیت کاربر",
                "⏱️ گزارش لاگ جلسات",
                "💰 گزارش خلاصه مالی",
                // ADD-MULTI-FEATURES Feature 5: new report types
                "🎮 درآمد بر اساس بازی",
                "🕐 درآمد بر اساس ساعت روز",
                "💻 درآمد بر اساس ایستگاه",
                "📊 ماهانه (۳۰ روز گذشته)",
            });
            _cboReportType.SelectedIndex = 0;

            var lblStart = new Label { Text = "از تاریخ:", Location = new Point(285, 10), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _dtpStart = new DateTimePicker { Location = new Point(285, 30), Size = new Size(180, 30), Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 10F), Value = DateTime.Today.AddDays(-7) };

            var lblEnd = new Label { Text = "تا تاریخ:", Location = new Point(480, 10), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _dtpEnd = new DateTimePicker { Location = new Point(480, 30), Size = new Size(180, 30), Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 10F), Value = DateTime.Today };

            _btnGenerate = new Button { Text = "🔄 تولید گزارش", Location = new Point(680, 28), Size = new Size(190, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            _btnGenerate.Click += (s, e) => GenerateReport();

            topPanel.Controls.AddRange(new Control[] { lblType, _cboReportType, lblStart, _dtpStart, lblEnd, _dtpEnd, _btnGenerate });

            // Preview
            _txtPreview = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                Font = new Font("Consolas", 10F),
                BackColor = Color.FromArgb(255, 255, 255),
                ForeColor = Color.FromArgb(40, 40, 40),
            };

            // Bottom buttons
            var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 50, BackColor = Color.FromArgb(240, 240, 240) };
            _btnPrint = new Button { Text = "🖨️ چاپ / ذخیره PDF", Location = new Point(15, 10), Size = new Size(180, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            _btnPrint.Click += (s, e) => PrintReport();
            _btnSave = new Button { Text = "💾 ذخیره متنی", Location = new Point(205, 10), Size = new Size(140, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)) };
            _btnSave.Click += (s, e) => SaveReport();
            // ADD-MULTI-FEATURES Feature 5: CSV export — opens Excel/LibreOffice
            // when double-clicked. The CSV uses semicolon as the column separator
            // (Persian locale uses ; as list separator) and includes a UTF-8 BOM
            // so Excel renders Persian text correctly.
            _btnSaveCsv = new Button { Text = "📊 ذخیره CSV (Excel)", Location = new Point(355, 10), Size = new Size(180, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            _btnSaveCsv.Click += (s, e) => SaveCsv();

            bottomPanel.Controls.AddRange(new Control[] { _btnPrint, _btnSave, _btnSaveCsv });

            Controls.AddRange(new Control[] { _txtPreview, bottomPanel, topPanel });
        }

        private void GenerateReport()
        {
            try
            {
                int type = _cboReportType.SelectedIndex;
                DateTime start = _dtpStart.Value.Date;
                DateTime end = _dtpEnd.Value.Date.AddDays(1).AddSeconds(-1);

                switch (type)
                {
                    case 0: _currentReportText = GenerateRevenueReport(start, end); break;
                    case 1: _currentReportText = GenerateWeeklySummary(start, end); break;
                    case 2: _currentReportText = GenerateUserActivityReport(start, end); break;
                    case 3: _currentReportText = GenerateSessionLogReport(start, end); break;
                    case 4: _currentReportText = GenerateFinancialSummary(start, end); break;
                    // ADD-MULTI-FEATURES Feature 5: new report types
                    case 5: _currentReportText = GenerateIncomeByGame(start, end); break;
                    case 6: _currentReportText = GenerateIncomeByHour(start, end); break;
                    case 7: _currentReportText = GenerateIncomeByStation(start, end); break;
                    case 8: _currentReportText = GenerateMonthlySummary(); break;
                }
                _txtPreview.Text = _currentReportText;
            }
            catch (Exception ex)
            {
                _txtPreview.Text = "خطا در تولید گزارش: " + ex.Message;
            }
        }

        private string GenerateRevenueReport(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش درآمد روزانه");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var rows = Database.Instance.Query(
                    "SELECT date(start_time) as dt, COUNT(*) as cnt, SUM(total_cost) as rev, AVG(duration_minutes) as avgmin FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e GROUP BY dt ORDER BY dt",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (Date: r.GetString(0), Count: r.GetInt32(1), Revenue: r.IsDBNull(2) ? 0m : r.GetDecimal(2), AvgMin: r.IsDBNull(3) ? 0 : Math.Round(r.GetDouble(3))));

                sb.AppendLine($"{"تاریخ",-15} {"تعداد جلسات",-15} {"درآمد (تومان)",-20} {"میانگین زمان",-15}");
                sb.AppendLine(new string('-', 65));
                decimal total = 0; int totalCnt = 0;
                foreach (var r in rows)
                {
                    sb.AppendLine($"{r.Date,-15} {r.Count,-15} {r.Revenue:N0,-20} {r.AvgMin} دقیقه");
                    total += r.Revenue; totalCnt += r.Count;
                }
                sb.AppendLine(new string('-', 65));
                sb.AppendLine($"{"مجموع",-15} {totalCnt,-15} {total:N0,-20}");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        private string GenerateWeeklySummary(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش خلاصه هفتگی");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var totalRevenue = Database.Instance.QueryOne("SELECT COALESCE(SUM(total_cost),0) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetDecimal(0));
                var totalSessions = Database.Instance.QueryOne("SELECT COUNT(*) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetInt32(0));
                var uniqueUsers = Database.Instance.QueryOne("SELECT COUNT(DISTINCT username) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetInt32(0));
                var avgMin = Database.Instance.QueryOne("SELECT AVG(duration_minutes) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.IsDBNull(0) ? 0 : Math.Round(r.GetDouble(0)));

                sb.AppendLine($"💰 مجموع درآمد:     {totalRevenue:N0} تومان");
                sb.AppendLine($"🎮 تعداد جلسات:     {totalSessions}");
                sb.AppendLine($"👤 کاربران یکتا:    {uniqueUsers}");
                sb.AppendLine($"⏱️ میانگین زمان جلسه: {avgMin} دقیقه");
                sb.AppendLine($"📊 میانگین درآمد/جلسه: {(totalSessions > 0 ? totalRevenue / totalSessions : 0):N0} تومان");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        private string GenerateUserActivityReport(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش فعالیت کاربران");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var rows = Database.Instance.Query(
                    "SELECT username, COUNT(*) as cnt, SUM(total_cost) as rev, AVG(duration_minutes) as avgmin FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e GROUP BY username ORDER BY rev DESC",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (User: r.GetString(0), Count: r.GetInt32(1), Revenue: r.IsDBNull(2) ? 0m : r.GetDecimal(2), AvgMin: r.IsDBNull(3) ? 0 : Math.Round(r.GetDouble(3))));

                sb.AppendLine($"{"نام کاربری",-20} {"تعداد جلسات",-15} {"مجموع هزینه",-20} {"میانگین زمان",-15}");
                sb.AppendLine(new string('-', 70));
                foreach (var r in rows)
                    sb.AppendLine($"{r.User,-20} {r.Count,-15} {r.Revenue:N0,-20} {r.AvgMin} دقیقه");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        private string GenerateSessionLogReport(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش لاگ جلسات");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var rows = Database.Instance.Query(
                    "SELECT username, station_name, start_time, end_time, duration_minutes, total_cost, current_game FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e ORDER BY start_time DESC LIMIT 200",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (
                        User: r.GetString(0),
                        Station: r.IsDBNull(1) ? "-" : r.GetString(1),
                        Start: r.GetDateTime(2),
                        End: r.IsDBNull(3) ? (DateTime?)null : r.GetDateTime(3),
                        Min: r.IsDBNull(4) ? 0 : r.GetInt32(4),
                        Cost: r.IsDBNull(5) ? 0m : r.GetDecimal(5),
                        Game: r.IsDBNull(6) ? "-" : r.GetString(6)
                    ));

                sb.AppendLine($"{"کاربر",-15} {"ایستگاه",-12} {"شروع",-17} {"مدت",-10} {"هزینه",-12} {"بازی",-15}");
                sb.AppendLine(new string('-', 81));
                foreach (var r in rows)
                    sb.AppendLine($"{r.User,-15} {r.Station,-12} {r.Start:MM-dd HH:mm}  {r.Min + " د",-10} {r.Cost:N0,-12} {r.Game,-15}");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        private string GenerateFinancialSummary(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش خلاصه مالی");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var sessionRevenue = Database.Instance.QueryOne("SELECT COALESCE(SUM(total_cost),0) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); }, r => r.GetDecimal(0));
                var printRevenue = Database.Instance.QueryOne("SELECT COALESCE(SUM(total_cost),0) FROM print_jobs WHERE status = 'completed' AND created_at >= @s AND created_at <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); }, r => r.GetDecimal(0));
                var foodRevenue = Database.Instance.QueryOne("SELECT COALESCE(SUM(fi.price * fo.quantity),0) FROM food_orders fo JOIN food_items fi ON fo.food_item_id = fi.id WHERE fo.status = 'delivered' AND fo.created_at >= @s AND fo.created_at <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); }, r => r.GetDecimal(0));
                var unpaidDebt = Database.Instance.QueryOne("SELECT COALESCE(SUM(amount),0) FROM debts WHERE is_paid = 0",
                    null, r => r.GetDecimal(0));

                sb.AppendLine($"🎮 درآمد جلسات:     {sessionRevenue:N0} تومان");
                sb.AppendLine($"🖨️ درآمد پرینت:     {printRevenue:N0} تومان");
                sb.AppendLine($"🍽️ درآمد غذا:       {foodRevenue:N0} تومان");
                sb.AppendLine($"───────────────────────────────────");
                sb.AppendLine($"💰 مجموع درآمد:     {sessionRevenue + printRevenue + foodRevenue:N0} تومان");
                sb.AppendLine();
                sb.AppendLine($"⚠️ بدهی معلق:       {unpaidDebt:N0} تومان");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        private void PrintReport()
        {
            if (string.IsNullOrEmpty(_currentReportText))
            {
                MessageBox.Show("ابتدا گزارش را تولید کنید.");
                return;
            }
            try
            {
                _printDoc = new PrintDocument();
                _printDoc.DocumentName = "GameNet Report " + DateTime.Now.ToString("yyyyMMdd");
                _printDoc.PrintPage += (s, e) =>
                {
                    var font = new Font("Consolas", 9F);
                    var brush = new SolidBrush(Color.Black);
                    // Print the report text (simple — no wrapping for long lines)
                    string[] lines = _currentReportText.Split('\n');
                    float y = 30;
                    foreach (var line in lines)
                    {
                        e.Graphics.DrawString(line.TrimEnd('\r'), font, brush, 30, y);
                        y += font.GetHeight(e.Graphics) + 2;
                        if (y > e.MarginBounds.Bottom) { e.HasMorePages = true; return; }
                    }
                    e.HasMorePages = false;
                };
                // Show print dialog so the operator can pick "Microsoft Print to PDF"
                using (var dlg = new PrintDialog { Document = _printDoc, UseEXDialog = true })
                {
                    if (dlg.ShowDialog() == DialogResult.OK)
                        _printDoc.Print();
                }
            }
            catch (Exception ex) { MessageBox.Show("خطای چاپ: " + ex.Message); }
        }

        private void SaveReport()
        {
            if (string.IsNullOrEmpty(_currentReportText)) { MessageBox.Show("ابتدا گزارش را تولید کنید."); return; }
            using (var dlg = new SaveFileDialog { Filter = "Text|*.txt", FileName = "gamenet_report_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".txt" })
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try { File.WriteAllText(dlg.FileName, _currentReportText, System.Text.Encoding.UTF8); MessageBox.Show("ذخیره شد."); }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); }
                }
            }
        }

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 5: saves the current report as a CSV
        /// file with a UTF-8 BOM (so Excel renders Persian correctly) and
        /// semicolon separator (matches the Persian locale's list separator).
        /// The CSV content is built per-report-type by the Generate* methods
        /// that also populate _currentCsv. If the selected report didn't
        /// produce a CSV (e.g. weekly summary), we synthesize a 2-column
        /// CSV from the text preview's lines.
        /// </summary>
        private void SaveCsv()
        {
            if (string.IsNullOrEmpty(_currentReportText)) { MessageBox.Show("ابتدا گزارش را تولید کنید."); return; }
            string csv = _currentCsv;
            if (string.IsNullOrEmpty(csv))
            {
                // Fallback: synthesize a single-column CSV from the text lines.
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("Row");
                foreach (var line in _currentReportText.Split('\n'))
                    sb.AppendLine("\"" + line.TrimEnd('\r').Replace("\"", "\"\"") + "\"");
                csv = sb.ToString();
            }
            using (var dlg = new SaveFileDialog { Filter = "CSV|*.csv", FileName = "gamenet_report_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".csv" })
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // UTF-8 BOM so Excel detects Persian correctly.
                        var enc = new System.Text.UTF8Encoding(true);
                        File.WriteAllText(dlg.FileName, csv, enc);
                        MessageBox.Show("✅ فایل CSV با موفقیت ذخیره شد.\n" + dlg.FileName, "ذخیره CSV", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); }
                }
            }
        }

        // ================================================================
        //  ADD-MULTI-FEATURES Feature 5: new report generators
        // ================================================================

        private string GenerateIncomeByGame(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           درآمد بر اساس بازی");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            var rows = new List<(string Game, int Sessions, decimal Revenue, int Minutes)>();
            try
            {
                rows = Database.Instance.Query(
                    "SELECT COALESCE(NULLIF(current_game, ''), '(نامشخص)') as g, COUNT(*) as cnt, SUM(total_cost) as rev, SUM(duration_minutes) as mins FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e GROUP BY g ORDER BY rev DESC",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (Game: r.GetString(0), Sessions: r.GetInt32(1), Revenue: r.IsDBNull(2) ? 0m : r.GetDecimal(2), Minutes: r.IsDBNull(3) ? 0 : r.GetInt32(3)));
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); return sb.ToString(); }

            sb.AppendLine($"{"بازی",-25} {"تعداد",-10} {"درآمد",-20} {"دقیقه",-12}");
            sb.AppendLine(new string('-', 67));
            decimal total = 0;
            foreach (var r in rows)
            {
                sb.AppendLine($"{r.Game,-25} {r.Sessions,-10} {r.Revenue:N0,-20} {r.Minutes,-12}");
                total += r.Revenue;
            }
            sb.AppendLine(new string('-', 67));
            sb.AppendLine($"{"مجموع",-25} {rows.Sum(r => r.Sessions),-10} {total:N0,-20}");
            sb.AppendLine();
            sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");

            // CSV representation
            var csv = new System.Text.StringBuilder();
            csv.AppendLine("Game;Sessions;Revenue;Minutes");
            foreach (var r in rows) csv.AppendLine($"{CsvEsc(r.Game)};{r.Sessions};{r.Revenue};{r.Minutes}");
            csv.AppendLine($"Total;{rows.Sum(r => r.Sessions)};{total};{rows.Sum(r => r.Minutes)}");
            _currentCsv = csv.ToString();

            return sb.ToString();
        }

        private string GenerateIncomeByHour(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           درآمد بر اساس ساعت روز (ساعات اوج)");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            var rows = new List<(int Hour, int Count, decimal Revenue)>();
            try
            {
                rows = Database.Instance.Query(
                    "SELECT CAST(strftime('%H', start_time) AS INTEGER) as h, COUNT(*) as cnt, SUM(total_cost) as rev FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e GROUP BY h ORDER BY h",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (Hour: r.GetInt32(0), Count: r.GetInt32(1), Revenue: r.IsDBNull(2) ? 0m : r.GetDecimal(2)));
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); return sb.ToString(); }

            // Build full 0..23 table with zeros for missing hours.
            var byHour = new (int Count, decimal Revenue)[24];
            foreach (var r in rows) byHour[r.Hour] = (r.Count, r.Revenue);

            sb.AppendLine($"{"ساعت",-8} {"تعداد",-10} {"درآمد",-20} {"نمودار"}");
            sb.AppendLine(new string('-', 70));
            decimal max = byHour.Max(x => x.Revenue);
            for (int h = 0; h < 24; h++)
            {
                int bars = max > 0 ? (int)(byHour[h].Revenue / max * 30) : 0;
                string bar = new string('█', Math.Max(0, bars));
                sb.AppendLine($"{h:00,-8} {byHour[h].Count,-10} {byHour[h].Revenue:N0,-20} {bar}");
            }
            decimal total = byHour.Sum(x => x.Revenue);
            int peakHour = byHour.Select((x, i) => (x.Revenue, i)).OrderByDescending(t => t.Revenue).First().i;
            sb.AppendLine(new string('-', 70));
            sb.AppendLine($"مجموع درآمد: {total:N0} تومان");
            sb.AppendLine($"ساعت اوج: {peakHour:00}:۰۰ ({byHour[peakHour].Revenue:N0} تومان)");
            sb.AppendLine();
            sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");

            var csv = new System.Text.StringBuilder();
            csv.AppendLine("Hour;Sessions;Revenue");
            for (int h = 0; h < 24; h++) csv.AppendLine($"{h:00};{byHour[h].Count};{byHour[h].Revenue}");
            csv.AppendLine($"PeakHour;{peakHour:00};{byHour[peakHour].Revenue}");
            _currentCsv = csv.ToString();

            return sb.ToString();
        }

        private string GenerateIncomeByStation(DateTime start, DateTime end)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           درآمد بر اساس ایستگاه");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            var rows = new List<(string Station, int Sessions, decimal Revenue, int Minutes)>();
            try
            {
                rows = Database.Instance.Query(
                    "SELECT COALESCE(NULLIF(station_name, ''), '(نامشخص)') as s, COUNT(*) as cnt, SUM(total_cost) as rev, SUM(duration_minutes) as mins FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e GROUP BY s ORDER BY rev DESC",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => (Station: r.GetString(0), Sessions: r.GetInt32(1), Revenue: r.IsDBNull(2) ? 0m : r.GetDecimal(2), Minutes: r.IsDBNull(3) ? 0 : r.GetInt32(3)));
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); return sb.ToString(); }

            sb.AppendLine($"{"ایستگاه",-18} {"تعداد",-10} {"درآمد",-20} {"دقیقه",-10}");
            sb.AppendLine(new string('-', 60));
            decimal total = 0;
            foreach (var r in rows)
            {
                sb.AppendLine($"{r.Station,-18} {r.Sessions,-10} {r.Revenue:N0,-20} {r.Minutes,-10}");
                total += r.Revenue;
            }
            sb.AppendLine(new string('-', 60));
            sb.AppendLine($"{"مجموع",-18} {rows.Sum(r => r.Sessions),-10} {total:N0,-20}");
            sb.AppendLine();
            sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");

            var csv = new System.Text.StringBuilder();
            csv.AppendLine("Station;Sessions;Revenue;Minutes");
            foreach (var r in rows) csv.AppendLine($"{CsvEsc(r.Station)};{r.Sessions};{r.Revenue};{r.Minutes}");
            csv.AppendLine($"Total;{rows.Sum(r => r.Sessions)};{total};{rows.Sum(r => r.Minutes)}");
            _currentCsv = csv.ToString();

            return sb.ToString();
        }

        private string GenerateMonthlySummary()
        {
            var end = DateTime.UtcNow;
            var start = end.AddDays(-30);
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine("           گزارش ماهانه (۳۰ روز گذشته)");
            sb.AppendLine($"           از {start:yyyy/MM/dd} تا {end:yyyy/MM/dd}");
            sb.AppendLine("═══════════════════════════════════════════════════");
            sb.AppendLine();

            try
            {
                var totalRevenue = Database.Instance.QueryOne("SELECT COALESCE(SUM(total_cost),0) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetDecimal(0));
                var totalSessions = Database.Instance.QueryOne("SELECT COUNT(*) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetInt32(0));
                var uniqueUsers = Database.Instance.QueryOne("SELECT COUNT(DISTINCT username) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.GetInt32(0));
                var avgMin = Database.Instance.QueryOne("SELECT AVG(duration_minutes) FROM client_sessions WHERE end_time IS NOT NULL AND start_time >= @s AND start_time <= @e",
                    cmd => { cmd.Parameters.AddWithValue("@s", start.ToString("o")); cmd.Parameters.AddWithValue("@e", end.ToString("o")); },
                    r => r.IsDBNull(0) ? 0 : Math.Round(r.GetDouble(0)));
                var dailyAvg = totalSessions / 30m;

                sb.AppendLine($"💰 مجموع درآمد:     {totalRevenue:N0} تومان");
                sb.AppendLine($"🎮 تعداد جلسات:     {totalSessions}");
                sb.AppendLine($"📊 میانگین جلسه/روز: {dailyAvg:F1}");
                sb.AppendLine($"👤 کاربران یکتا:    {uniqueUsers}");
                sb.AppendLine($"⏱️ میانگین زمان جلسه: {avgMin} دقیقه");
                sb.AppendLine($"📊 میانگین درآمد/جلسه: {(totalSessions > 0 ? totalRevenue / totalSessions : 0):N0} تومان");
                sb.AppendLine();
                sb.AppendLine($"تاریخ تولید: {DateTime.Now:yyyy/MM/dd HH:mm}");

                var csv = new System.Text.StringBuilder();
                csv.AppendLine("Metric;Value");
                csv.AppendLine($"TotalRevenue;{totalRevenue}");
                csv.AppendLine($"TotalSessions;{totalSessions}");
                csv.AppendLine($"DailyAvg;{dailyAvg:F1}");
                csv.AppendLine($"UniqueUsers;{uniqueUsers}");
                csv.AppendLine($"AvgMinutes;{avgMin}");
                _currentCsv = csv.ToString();
            }
            catch (Exception ex) { sb.AppendLine("خطا: " + ex.Message); }

            return sb.ToString();
        }

        /// <summary>Escapes a string for safe inclusion in a CSV cell (RFC 4180).</summary>
        private static string CsvEsc(string s)
        {
            if (s == null) return "";
            if (s.IndexOfAny(new[] { ';', '"', '\n', '\r' }) >= 0)
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
    }
}
