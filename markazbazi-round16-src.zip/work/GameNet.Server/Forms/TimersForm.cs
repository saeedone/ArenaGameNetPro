using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Timers management form (HandyCafe-style). Lets the operator start a
    /// named timer with an hour price + time period, see all active timers
    /// in a grid (name, start/end, used/remaining, price, status), and pay
    /// to close a timer. Also exposes a mini orders section so the operator
    /// can add cafeteria items to the active timer's bill.
    /// </summary>
    public class TimersForm : Form
    {
        private ClientCommunicator _communicator;

        private TextBox _txtName, _txtHourPrice;
        private ComboBox _cboPeriod;
        private Button _btnStart, _btnPayment;
        private DataGridView _dgv;
        private Label _lblTick;

        // Mini orders section
        private ComboBox _cboItem;
        private NumericUpDown _nudQty;
        private Button _btnAddItem;
        private TextBox _txtOrderTotal;

        private readonly List<TimerEntry> _timers = new List<TimerEntry>();
        private readonly List<string> _menu = new List<string> { "نوشابه", "چای", "قهوه", "ساندویچ", "پیتزا" };
        private readonly Timer _refreshTimer;

        public TimersForm() : this(null) { }

        public TimersForm(ClientCommunicator communicator)
        {
            _communicator = communicator;

            this.Text = "تایمرها - GameNet";
            this.Size = new Size(940, 660);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            // ---- Top: input panel ----
            int y = 12;
            var lblName = new Label { Text = "نام تایمر:", Location = new Point(20, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtName = new TextBox { Location = new Point(110, y), Size = new Size(180, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblPrice = new Label { Text = "قیمت ساعت:", Location = new Point(310, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtHourPrice = new TextBox { Location = new Point(400, y), Size = new Size(120, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F), Text = "15000" };

            var lblPeriod = new Label { Text = "مدت (دقیقه):", Location = new Point(540, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _cboPeriod = new ComboBox
            {
                Location = new Point(640, y), Size = new Size(100, 28), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            _cboPeriod.Items.AddRange(new object[] { 30, 60, 90, 120, 180, 240, 360, 480 });
            _cboPeriod.SelectedIndex = 1;

            _btnStart = new Button
            {
                Text = "▶ شروع", Location = new Point(760, y - 1), Size = new Size(80, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnStart.Click += (s, e) => StartTimer();

            _btnPayment = new Button
            {
                Text = "💳 پرداخت", Location = new Point(846, y - 1), Size = new Size(80, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            _btnPayment.Click += (s, e) => PayTimer();

            y += 38;

            // ---- Active timers grid ----
            _dgv = new DataGridView
            {
                Location = new Point(20, y),
                Size = new Size(900, 380),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 24 },
            };
            _dgv.Columns.Add("colName", "نام تایمر");
            _dgv.Columns.Add("colStart", "شروع");
            _dgv.Columns.Add("colEnd", "پایان");
            _dgv.Columns.Add("colUsed", "استفاده");
            _dgv.Columns.Add("colRemain", "باقی‌مانده");
            _dgv.Columns.Add("colPrice", "قیمت");
            _dgv.Columns.Add("colStatus", "وضعیت");

            y += 388;

            // ---- Mini orders section ----
            var lblOrders = new Label { Text = "🥤 افزودن سفارش به تایمر انتخاب‌شده:", Location = new Point(20, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180) };
            y += 28;
            _cboItem = new ComboBox
            {
                Location = new Point(20, y), Size = new Size(160, 28), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            foreach (var m in _menu) _cboItem.Items.Add(m);
            if (_cboItem.Items.Count > 0) _cboItem.SelectedIndex = 0;

            _nudQty = new NumericUpDown { Location = new Point(190, y), Size = new Size(70, 28), Minimum = 1, Maximum = 999, Value = 1, Font = new Font("Segoe UI", 10F) };

            _btnAddItem = new Button
            {
                Text = "➕ افزودن", Location = new Point(270, y - 1), Size = new Size(110, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnAddItem.Click += (s, e) => AddItemToSelected();

            var lblTotalTitle = new Label { Text = "مجموع سفارش:", Location = new Point(400, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtOrderTotal = new TextBox { Location = new Point(510, y), Size = new Size(150, 28), ReadOnly = true, BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(180, 140, 20), Font = new Font("Segoe UI", 10F), Text = "0" };

            _lblTick = new Label { Text = "⏱️ ---", Location = new Point(700, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 130, 50) };

            Controls.AddRange(new Control[] {
                lblName, _txtName, lblPrice, _txtHourPrice, lblPeriod, _cboPeriod,
                _btnStart, _btnPayment,
                _dgv,
                lblOrders,
                _cboItem, _nudQty, _btnAddItem, lblTotalTitle, _txtOrderTotal,
                _lblTick
            });

            _refreshTimer = new Timer { Interval = 1000 };
            _refreshTimer.Tick += (s, e) => RefreshGrid();
            _refreshTimer.Start();

            this.FormClosing += (s, e) => { try { _refreshTimer.Stop(); } catch { } };
        }

        private void StartTimer()
        {
            string name = _txtName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("نام تایمر را وارد کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            decimal hourPrice;
            if (!decimal.TryParse(_txtHourPrice.Text.Replace(",", "").Trim(), out hourPrice) || hourPrice < 0)
            {
                MessageBox.Show("قیمت ساعت معتبر نیست.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int period = (int)(_cboPeriod.SelectedItem ?? 60);

            var entry = new TimerEntry
            {
                Name = name,
                Start = DateTime.Now,
                PeriodMinutes = period,
                HourPrice = hourPrice,
                Status = "فعال",
                Orders = new List<OrderLineDef>()
            };
            _timers.Add(entry);
            AuditLog.Log("TimersForm", $"Timer '{name}' started: {period} min @ {hourPrice:N0} T/h");
            RefreshGrid();
            _txtName.Clear();
        }

        private void PayTimer()
        {
            if (_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("یک تایمر را انتخاب کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int idx = _dgv.SelectedRows[0].Index;
            if (idx < 0 || idx >= _timers.Count) return;
            var t = _timers[idx];
            var used = DateTime.Now - t.Start;
            int usedMin = (int)used.TotalMinutes;
            decimal timeCost = (decimal)(used.TotalHours) * t.HourPrice;
            decimal orderCost = t.Orders.Sum(o => o.Qty * o.UnitCost);
            decimal total = timeCost + orderCost;
            t.Status = "پایان‌یافته";
            t.End = DateTime.Now;
            AuditLog.Log("TimersForm", $"Timer '{t.Name}' paid: time={timeCost:N0}, orders={orderCost:N0}, total={total:N0}");
            MessageBox.Show($"✅ تایمر '{t.Name}' تسویه شد.\n\n" +
                            $"⏱️ زمان استفاده: {usedMin} دقیقه\n" +
                            $"💰 هزینه زمان: {timeCost:N0} تومان\n" +
                            $"🥤 هزینه سفارش: {orderCost:N0} تومان\n" +
                            $"─────────────────\n" +
                            $"جمع کل: {total:N0} تومان",
                            "پرداخت تایمر", MessageBoxButtons.OK, MessageBoxIcon.Information);
            _timers.RemoveAt(idx);
            RefreshGrid();
        }

        private void AddItemToSelected()
        {
            if (_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("یک تایمر را انتخاب کنید.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int idx = _dgv.SelectedRows[0].Index;
            if (idx < 0 || idx >= _timers.Count) return;
            string item = _cboItem.SelectedItem?.ToString() ?? "";
            int qty = (int)_nudQty.Value;
            decimal price = 0;
            // Simple default price map; could be loaded from food_items.
            switch (item)
            {
                case "نوشابه":  price = 15000; break;
                case "چای":     price = 8000;  break;
                case "قهوه":    price = 25000; break;
                case "ساندویچ": price = 45000; break;
                case "پیتزا":   price = 95000; break;
            }
            _timers[idx].Orders.Add(new OrderLineDef { Item = item, Qty = qty, UnitCost = price });
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            // Update the tick label even if nothing selected.
            try
            {
                if (_dgv.SelectedRows.Count > 0)
                {
                    int idx = _dgv.SelectedRows[0].Index;
                    if (idx >= 0 && idx < _timers.Count)
                    {
                        var t = _timers[idx];
                        var used = DateTime.Now - t.Start;
                        _lblTick.Text = $"⏱️ {t.Name}: {(int)used.TotalHours:00}:{used.Minutes:00}:{used.Seconds:00}";
                        decimal orderCost = t.Orders.Sum(o => o.Qty * o.UnitCost);
                        _txtOrderTotal.Text = orderCost.ToString("N0");
                    }
                }
            }
            catch { }

            if (_timers.Count == 0)
            {
                _dgv.Rows.Clear();
                return;
            }

            // Rebuild rows but preserve selection.
            int selectedIdx = _dgv.SelectedRows.Count > 0 ? _dgv.SelectedRows[0].Index : -1;
            _dgv.Rows.Clear();
            for (int i = 0; i < _timers.Count; i++)
            {
                var t = _timers[i];
                var used = DateTime.Now - t.Start;
                int usedMin = (int)used.TotalMinutes;
                int remainingMin = Math.Max(0, t.PeriodMinutes - usedMin);
                decimal cost = (decimal)used.TotalHours * t.HourPrice;
                string usedStr = $"{(int)used.TotalHours:00}:{used.Minutes:00}:{used.Seconds:00}";
                string remainStr = t.Status == "فعال" ? $"{remainingMin / 60:00}:{remainingMin % 60:00}:00" : "—";
                string endStr = t.Status == "فعال" ? t.Start.AddMinutes(t.PeriodMinutes).ToString("HH:mm:ss") : (t.End?.ToString("HH:mm:ss") ?? "—");
                _dgv.Rows.Add(t.Name, t.Start.ToString("HH:mm:ss"), endStr, usedStr, remainStr, cost.ToString("N0"), t.Status);
            }
            if (selectedIdx >= 0 && selectedIdx < _dgv.Rows.Count)
            {
                _dgv.ClearSelection();
                _dgv.Rows[selectedIdx].Selected = true;
            }
        }

        private class TimerEntry
        {
            public string Name;
            public DateTime Start;
            public DateTime? End;
            public int PeriodMinutes;
            public decimal HourPrice;
            public string Status;
            public List<OrderLineDef> Orders;
        }

        private class OrderLineDef { public string Item; public int Qty; public decimal UnitCost; }
    }
}
