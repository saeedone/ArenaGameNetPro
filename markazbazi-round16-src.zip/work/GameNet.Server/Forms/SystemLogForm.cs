using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// System log viewer. Lets the operator browse the audit_log table with
    /// date range + type filters and export the current view to CSV.
    /// </summary>
    public class SystemLogForm : Form
    {
        private DateTimePicker _dtpFrom, _dtpTo;
        private CheckBox _chkShowAll;
        private ComboBox _cmbType;
        private Button _btnShow, _btnExport;
        private DataGridView _dgv;
        private Label _lblCount;

        public SystemLogForm()
        {
            this.Text = "گزارش سیستم - GameNet";
            this.Size = new Size(940, 620);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            int y = 12;
            var lblFrom = new Label { Text = "از تاریخ:", Location = new Point(20, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpFrom = new DateTimePicker { Location = new Point(100, y), Size = new Size(160, 28), Format = DateTimePickerFormat.Short, Value = DateTime.UtcNow.Date.AddDays(-7) };

            var lblTo = new Label { Text = "تا تاریخ:", Location = new Point(280, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpTo = new DateTimePicker { Location = new Point(350, y), Size = new Size(160, 28), Format = DateTimePickerFormat.Short, Value = DateTime.UtcNow.Date };

            _chkShowAll = new CheckBox { Text = "نمایش همه", Location = new Point(520, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblType = new Label { Text = "نوع:", Location = new Point(660, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cmbType = new ComboBox
            {
                Location = new Point(700, y), Size = new Size(120, 28), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            _cmbType.Items.AddRange(new object[] { "همه", "Info", "Warning", "Error" });
            _cmbType.SelectedIndex = 0;

            y += 36;

            _btnShow = new Button
            {
                Text = "🔍 نمایش", Location = new Point(20, y), Size = new Size(120, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnShow.Click += (s, e) => LoadLogs();

            _btnExport = new Button
            {
                Text = "💾 خروجی CSV", Location = new Point(150, y), Size = new Size(140, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnExport.Click += (s, e) => ExportCsv();

            _lblCount = new Label
            {
                Location = new Point(310, y + 6), AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
            };

            y += 44;

            _dgv = new DataGridView
            {
                Location = new Point(20, y),
                Size = new Size(900, 470),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 22 },
            };
            _dgv.Columns.Add("colDate", "تاریخ");
            _dgv.Columns.Add("colTime", "زمان");
            _dgv.Columns.Add("colType", "نوع");
            _dgv.Columns.Add("colCat", "دسته");
            _dgv.Columns.Add("colDesc", "توضیحات");
            _dgv.Columns[0].Width = 90;
            _dgv.Columns[1].Width = 80;
            _dgv.Columns[2].Width = 70;
            _dgv.Columns[3].Width = 120;
            _dgv.Columns[4].FillWeight = 300;

            Controls.AddRange(new Control[] {
                lblFrom, _dtpFrom, lblTo, _dtpTo, _chkShowAll,
                lblType, _cmbType,
                _btnShow, _btnExport, _lblCount,
                _dgv
            });

            LoadLogs();
        }

        private void LoadLogs()
        {
            _dgv.Rows.Clear();
            try
            {
                DateTime fromUtc = _chkShowAll.Checked ? DateTime.MinValue : _dtpFrom.Value.Date;
                DateTime toUtc   = _chkShowAll.Checked ? DateTime.MaxValue : _dtpTo.Value.Date.AddDays(1);

                // Pull the latest 5000 rows so the UI stays responsive.
                var rows = Database.Instance.Query(
                    "SELECT id, category, action, details, timestamp FROM audit_log ORDER BY id DESC LIMIT 5000",
                    null,
                    r => new
                    {
                        Id = r.GetInt32(0),
                        Category = r.GetString(1),
                        Action = r.GetString(2),
                        Details = r.IsDBNull(3) ? "" : r.GetString(3),
                        Timestamp = r.GetDateTime(4)
                    });

                string typeFilter = _cmbType.SelectedItem?.ToString() ?? "همه";
                int shown = 0;
                foreach (var r in rows)
                {
                    if (r.Timestamp < fromUtc || r.Timestamp > toUtc) continue;

                    // Infer type: any log row whose category/action/details
                    // contains "error" / "warning" / "fail" gets that type.
                    string hay = (r.Category + " " + r.Action + " " + r.Details).ToLowerInvariant();
                    string type = "Info";
                    if (hay.Contains("error") || hay.Contains("exception") || hay.Contains("fail") || hay.Contains("crash"))
                        type = "Error";
                    else if (hay.Contains("warn"))
                        type = "Warning";

                    if (typeFilter != "همه" && typeFilter != type) continue;

                    var local = r.Timestamp.ToLocalTime();
                    _dgv.Rows.Add(local.ToString("yyyy/MM/dd"), local.ToString("HH:mm:ss"), type, r.Category, r.Action + (string.IsNullOrEmpty(r.Details) ? "" : " — " + r.Details));
                    shown++;
                    if (shown >= 1000) break; // cap UI rows
                }

                // Color-code by type
                foreach (DataGridViewRow row in _dgv.Rows)
                {
                    string t = row.Cells[2].Value?.ToString() ?? "";
                    if (t == "Error") row.DefaultCellStyle.ForeColor = Color.FromArgb(200, 30, 60);
                    else if (t == "Warning") row.DefaultCellStyle.ForeColor = Color.FromArgb(180, 140, 20);
                }

                _lblCount.Text = $"تعداد: {shown} رکورد";
            }
            catch (Exception ex)
            {
                _lblCount.Text = "خطا در بارگذاری";
                MessageBox.Show("خطا در بارگذاری لاگ: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportCsv()
        {
            if (_dgv.Rows.Count == 0)
            {
                MessageBox.Show("داده‌ای برای خروجی وجود ندارد.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            try
            {
                using (var sfd = new SaveFileDialog())
                {
                    sfd.Filter = "CSV (*.csv)|*.csv";
                    sfd.FileName = "system_log_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";
                    if (sfd.ShowDialog(this) != DialogResult.OK) return;

                    using (var w = new StreamWriter(sfd.FileName, false, System.Text.Encoding.UTF8))
                    {
                        // BOM so Excel opens UTF-8 properly.
                        w.WriteLine("Date,Time,Type,Category,Description");
                        foreach (DataGridViewRow row in _dgv.Rows)
                        {
                            string[] fields = new string[5];
                            for (int i = 0; i < 5; i++)
                            {
                                string v = row.Cells[i].Value?.ToString() ?? "";
                                v = v.Replace("\"", "\"\"");
                                fields[i] = "\"" + v + "\"";
                            }
                            w.WriteLine(string.Join(",", fields));
                        }
                    }
                    AuditLog.Log("SystemLogForm", "Exported CSV to " + sfd.FileName);
                    MessageBox.Show("✅ خروجی CSV ذخیره شد:\n" + sfd.FileName, "خروجی", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در خروجی: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
