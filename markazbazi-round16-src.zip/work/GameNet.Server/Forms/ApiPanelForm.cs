using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Control panel for the Mobile API and WebSocket server. Lets the operator
    /// start/stop each service and shows the API keys and connection URLs.
    /// Replaces the old two-button approach with a single management surface.
    /// </summary>
    public class ApiPanelForm : Form
    {
        private readonly ClientCommunicator _communicator;
        private readonly MainForm _mainForm;
        private Button _btnStartApi, _btnStopApi, _btnStartWs, _btnStopWs, _btnCopyKey, _btnCopyAdminKey;
        private Label _lblApiStatus, _lblWsStatus, _lblApiKey, _lblAdminKey, _lblApiUrl, _lblWsUrl;
        private TextBox _txtApiKey, _txtAdminKey;

        public ApiPanelForm(ClientCommunicator communicator, MainForm mainForm)
        {
            _communicator = communicator;
            _mainForm = mainForm;

            this.Text = "API و WebSocket";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
        }

        private void BuildUi()
        {
            int y = 20;

            // === Mobile API Section ===
            var lblApiTitle = new Label
            {
                Text = "📱 API موبایل (HTTP REST)",
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 35;

            _lblApiStatus = new Label
            {
                Text = "وضعیت: ⏸️ غیرفعال",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(200, 30, 60),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 28;

            _lblApiUrl = new Label
            {
                Text = "آدرس: http://<IP-سرور>:8080/api/dashboard",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 28;

            _btnStartApi = MkBtn("▶️ شروع API", Color.FromArgb(166, 227, 161), 20, y);
            _btnStartApi.Click += (s, e) =>
            {
                try
                {
                    string key = _mainForm.StartMobileApi();
                    _lblApiStatus.Text = "وضعیت: ✅ فعال";
                    _lblApiStatus.ForeColor = Color.FromArgb(20, 130, 50);
                    _txtApiKey.Text = key;
                    _txtAdminKey.Text = _mainForm.GetAdminApiKeySafe();
                    MessageBox.Show("API موبایل با موفقیت فعال شد.\nکلیدها در پایین نمایش داده شده‌اند.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            _btnStopApi = MkBtn("⏹️ توقف API", Color.FromArgb(243, 139, 168), 200, y);
            _btnStopApi.Click += (s, e) =>
            {
                _mainForm.StopMobileApiSafe();
                _lblApiStatus.Text = "وضعیت: ⏸️ غیرفعال";
                _lblApiStatus.ForeColor = Color.FromArgb(200, 30, 60);
            };
            y += 50;

            // API keys
            _lblApiKey = new Label { Text = "🔑 کلید فقط‌خواندنی (Read-Only):", Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(20, y), AutoSize = true };
            y += 25;
            _txtApiKey = new TextBox { Location = new Point(20, y), Size = new Size(700, 28), ReadOnly = true, Font = new Font("Consolas", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            _btnCopyKey = MkBtn("📋 کپی", Color.FromArgb(137, 180, 250), 730, y - 2);
            _btnCopyKey.Size = new Size(80, 30);
            _btnCopyKey.Click += (s, e) => { try { Clipboard.SetText(_txtApiKey.Text); MessageBox.Show("کپی شد."); } catch { } };
            y += 38;

            _lblAdminKey = new Label { Text = "🔐 کلید ادمین (دسترسی کامل - تغییر اعتبار/ایستگاه):", Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20), Location = new Point(20, y), AutoSize = true };
            y += 25;
            _txtAdminKey = new TextBox { Location = new Point(20, y), Size = new Size(700, 28), ReadOnly = true, Font = new Font("Consolas", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(180, 140, 20) };
            _btnCopyAdminKey = MkBtn("📋 کپی", Color.FromArgb(137, 180, 250), 730, y - 2);
            _btnCopyAdminKey.Size = new Size(80, 30);
            _btnCopyAdminKey.Click += (s, e) => { try { Clipboard.SetText(_txtAdminKey.Text); MessageBox.Show("کپی شد."); } catch { } };
            y += 50;

            // === WebSocket Section ===
            var lblWsTitle = new Label
            {
                Text = "🌐 WebSocket سرور",
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(130, 50, 180),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 35;

            _lblWsStatus = new Label
            {
                Text = "وضعیت: ⏸️ غیرفعال",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(200, 30, 60),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 28;

            _lblWsUrl = new Label
            {
                Text = "آدرس: ws://<IP-سرور>:9091/ws/",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(20, y),
                AutoSize = true,
            };
            y += 28;

            _btnStartWs = MkBtn("▶️ شروع WebSocket", Color.FromArgb(166, 227, 161), 20, y);
            _btnStartWs.Click += (s, e) =>
            {
                try
                {
                    _mainForm.StartWebSocket();
                    _lblWsStatus.Text = "وضعیت: ✅ فعال";
                    _lblWsStatus.ForeColor = Color.FromArgb(20, 130, 50);
                    MessageBox.Show("WebSocket سرور فعال شد.\nپورت: 9091", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            _btnStopWs = MkBtn("⏹️ توقف WebSocket", Color.FromArgb(243, 139, 168), 200, y);
            _btnStopWs.Click += (s, e) =>
            {
                _mainForm.StopWebSocketSafe();
                _lblWsStatus.Text = "وضعیت: ⏸️ غیرفعال";
                _lblWsStatus.ForeColor = Color.FromArgb(200, 30, 60);
            };
            y += 50;

            // === Usage notes ===
            var lblNotes = new Label
            {
                Text = "📖 راهنما:\n\n" +
                       "• کلید فقط‌خواندنی برای مشاهده داشبورد و گزارش‌ها استفاده می‌شود.\n" +
                       "• کلید ادمین برای تغییر اعتبار کاربران و کنترل ایستگاه‌ها لازم است.\n" +
                       "• هر دو کلید در فایل api_key.txt کنار برنامه ذخیره می‌شوند و بعد از راه‌اندازی مجدد سرور ثابت می‌مانند.\n" +
                       "• برای استفاده از API، در هدر درخواست بنویسید: Authorization: Bearer <کلید>\n" +
                       "• نمونه: GET http://سرور:8080/api/dashboard",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(20, y),
                Size = new Size(830, 110),
            };

            this.Controls.AddRange(new Control[] {
                lblApiTitle, _lblApiStatus, _lblApiUrl, _btnStartApi, _btnStopApi,
                _lblApiKey, _txtApiKey, _btnCopyKey,
                _lblAdminKey, _txtAdminKey, _btnCopyAdminKey,
                lblWsTitle, _lblWsStatus, _lblWsUrl, _btnStartWs, _btnStopWs,
                lblNotes
            });
        }

        private Button MkBtn(string text, Color bg, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 34),
                BackColor = bg,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
            };
        }
    }
}
