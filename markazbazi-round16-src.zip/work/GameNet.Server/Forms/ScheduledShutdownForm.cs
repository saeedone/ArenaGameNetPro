using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Scheduled shutdown form. Lets the operator pick a future time at
    /// which all connected clients should be shut down. A countdown is
    /// displayed; the operator can cancel the schedule before it fires.
    /// </summary>
    public class ScheduledShutdownForm : Form
    {
        private ClientCommunicator _communicator;
        private DateTimePicker _dtpWhen;
        private Button _btnSchedule, _btnCancel;
        private Label _lblCountdown, _lblStatus;
        private Timer _tickTimer;
        private DateTime? _scheduledAt;

        public ScheduledShutdownForm(ClientCommunicator communicator)
        {
            _communicator = communicator;

            this.Text = "خاموشی زمان‌بندی - GameNet";
            this.Size = new Size(620, 360);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            var lblTitle = new Label
            {
                Text = "⏰ خاموشی زمان‌بندی کلاینت‌ها",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(200, 30, 60),
                Location = new Point(20, 15),
                AutoSize = true,
            };

            var lblWhen = new Label
            {
                Text = "زمان خاموشی:",
                Location = new Point(20, 65),
                AutoSize = true,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };

            _dtpWhen = new DateTimePicker
            {
                Location = new Point(170, 62),
                Size = new Size(240, 30),
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "yyyy/MM/dd HH:mm",
                Value = DateTime.Now.AddMinutes(30),
                Font = new Font("Segoe UI", 11F),
                MinDate = DateTime.Now,
            };

            _btnSchedule = new Button
            {
                Text = "📅 زمان‌بندی", Location = new Point(20, 110), Size = new Size(180, 40),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            _btnSchedule.Click += (s, e) => Schedule();

            _btnCancel = new Button
            {
                Text = "🚫 لغو زمان‌بندی", Location = new Point(220, 110), Size = new Size(180, 40),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)),
                Enabled = false,
            };
            _btnCancel.Click += (s, e) => CancelSchedule();

            _lblStatus = new Label
            {
                Text = "وضعیت: هیچ زمان‌بندی فعالی وجود ندارد.",
                Location = new Point(20, 165),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };

            _lblCountdown = new Label
            {
                Text = "",
                Location = new Point(20, 200),
                Size = new Size(560, 60),
                Font = new Font("Segoe UI", 22F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
                TextAlign = ContentAlignment.MiddleCenter,
            };

            Controls.AddRange(new Control[] { lblTitle, lblWhen, _dtpWhen, _btnSchedule, _btnCancel, _lblStatus, _lblCountdown });

            _tickTimer = new Timer { Interval = 500 };
            _tickTimer.Tick += (s, e) => Tick();
            _tickTimer.Start();

            this.FormClosing += (s, e) => { try { _tickTimer.Stop(); } catch { } };
        }

        private void Schedule()
        {
            DateTime when = _dtpWhen.Value;
            if (when <= DateTime.Now)
            {
                MessageBox.Show("زمان خاموشی باید در آینده باشد.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _scheduledAt = when;
            _btnSchedule.Enabled = false;
            _btnCancel.Enabled = true;
            _dtpWhen.Enabled = false;
            _lblStatus.Text = $"وضعیت: خاموشی زمان‌بندی شد برای {when:yyyy/MM/dd HH:mm}";
            _lblStatus.ForeColor = Color.FromArgb(180, 140, 20);
            AuditLog.Log("ScheduledShutdown", $"Scheduled shutdown for {when:o}");
            Tick();
        }

        private void CancelSchedule()
        {
            _scheduledAt = null;
            _btnSchedule.Enabled = true;
            _btnCancel.Enabled = false;
            _dtpWhen.Enabled = true;
            _lblStatus.Text = "وضعیت: زمان‌بندی لغو شد.";
            _lblStatus.ForeColor = Color.FromArgb(40, 40, 40);
            _lblCountdown.Text = "";
            AuditLog.Log("ScheduledShutdown", "Cancelled scheduled shutdown");
        }

        private void Tick()
        {
            if (!_scheduledAt.HasValue)
            {
                _lblCountdown.Text = "";
                return;
            }
            var remaining = _scheduledAt.Value - DateTime.Now;
            if (remaining.TotalSeconds <= 0)
            {
                // Fire!
                _lblCountdown.Text = "خاموش کردن کلاینت‌ها…";
                _lblStatus.Text = "وضعیت: در حال خاموش کردن همه کلاینت‌ها…";
                try
                {
                    if (_communicator != null)
                    {
                        _communicator.ShutdownAll();
                        AuditLog.Log("ScheduledShutdown", "Fired: ShutdownAll invoked");
                    }
                }
                catch (Exception ex)
                {
                    AuditLog.Log("ScheduledShutdown", "Fire error: " + ex.Message);
                }
                _scheduledAt = null;
                _btnSchedule.Enabled = true;
                _btnCancel.Enabled = false;
                _dtpWhen.Enabled = true;
                return;
            }
            _lblCountdown.Text = $"{(int)remaining.TotalHours:00}:{remaining.Minutes:00}:{remaining.Seconds:00}";
        }
    }
}
