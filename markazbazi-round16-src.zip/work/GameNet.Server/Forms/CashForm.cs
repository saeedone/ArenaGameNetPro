using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Cash register form. Shows today's cash in / cash out / net, plus a
    /// list of today's cash-affecting transactions (sessions, food orders,
    /// topup requests, print jobs, debts).
    /// </summary>
    public class CashForm : Form
    {
        public CashForm()
        {
            this.Text = "صندوق - GameNet";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Title
            var lblTitle = new Label
            {
                Text = "💵 صندوق روز جاری",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 12),
                AutoSize = true,
            };

            // Summary labels
            var lblInTitle = new Label { Text = "پرداختی‌ها (درآمد):", Location = new Point(20, 55), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 130, 50) };
            var lblIn = new Label { Location = new Point(180, 52), AutoSize = true, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50), Name = "lblIn" };

            var lblOutTitle = new Label { Text = "پرداخت‌ها (هزینه):", Location = new Point(380, 55), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(200, 30, 60) };
            var lblOut = new Label { Location = new Point(540, 52), AutoSize = true, Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(200, 30, 60), Name = "lblOut" };

            var lblNetTitle = new Label { Text = "خالص صندوق:", Location = new Point(20, 95), AutoSize = true, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(180, 140, 20) };
            var lblNet = new Label { Location = new Point(180, 92), AutoSize = true, Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20), Name = "lblNet" };

            // Transactions grid
            var dgv = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(840, 400),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 22 },
            };
            dgv.Columns.Add("colTime", "زمان");
            dgv.Columns.Add("colUser", "کاربر");
            dgv.Columns.Add("colAmount", "مبلغ (تومان)");
            dgv.Columns.Add("colType", "نوع");
            dgv.Columns.Add("colNote", "توضیح");
            dgv.Columns[0].Width = 80;
            dgv.Columns[1].Width = 130;
            dgv.Columns[2].Width = 130;
            dgv.Columns[3].Width = 110;
            dgv.Columns[4].FillWeight = 280;

            Controls.AddRange(new Control[] { lblTitle, lblInTitle, lblIn, lblOutTitle, lblOut, lblNetTitle, lblNet, dgv });

            // Populate
            decimal cashIn = 0, cashOut = 0;
            try
            {
                // Sessions (revenue from completed sessions today)
                var sessions = Database.Instance.Query(
                    "SELECT start_time, username, total_cost FROM client_sessions WHERE end_time IS NOT NULL AND date(start_time) = date('now') AND total_cost > 0",
                    null,
                    r => new { Time = r.GetDateTime(0), User = r.IsDBNull(1) ? "-" : r.GetString(1), Amount = r.GetDecimal(2) });
                foreach (var s in sessions)
                {
                    cashIn += s.Amount;
                    dgv.Rows.Add(s.Time.ToLocalTime().ToString("HH:mm:ss"), s.User, s.Amount.ToString("N0"), "نشست", "هزینه نشست کلاینت");
                }

                // Topup requests approved today
                try
                {
                    var topups = Database.Instance.Query(
                        "SELECT requested_at, username, amount FROM topup_requests WHERE status = 'approved' AND date(responded_at) = date('now')",
                        null,
                        r => new { Time = r.GetDateTime(0), User = r.GetString(1), Amount = r.GetDecimal(2) });
                    foreach (var t in topups)
                    {
                        cashIn += t.Amount;
                        dgv.Rows.Add(t.Time.ToLocalTime().ToString("HH:mm:ss"), t.User, t.Amount.ToString("N0"), "شارژ", "شارژ اعتبار");
                    }
                }
                catch { }

                // Print jobs today
                try
                {
                    var prints = Database.Instance.Query(
                        "SELECT created_at, username, cost FROM print_jobs WHERE date(created_at) = date('now') AND cost > 0",
                        null,
                        r => new { Time = r.GetDateTime(0), User = r.GetString(1), Amount = r.GetDecimal(2) });
                    foreach (var p in prints)
                    {
                        cashIn += p.Amount;
                        dgv.Rows.Add(p.Time.ToLocalTime().ToString("HH:mm:ss"), p.User, p.Amount.ToString("N0"), "پرینت", "هزینه پرینت");
                    }
                }
                catch { }

                // Unpaid debts marked paid today = cashIn; new debts created today = cashOut (allowance)
                try
                {
                    var debtsPaid = Database.Instance.Query(
                        "SELECT paid_at, username, amount FROM debts WHERE is_paid = 1 AND date(paid_at) = date('now')",
                        null,
                        r => new { Time = r.GetDateTime(0), User = r.GetString(1), Amount = r.GetDecimal(2) });
                    foreach (var d in debtsPaid)
                    {
                        cashIn += d.Amount;
                        dgv.Rows.Add(d.Time.ToLocalTime().ToString("HH:mm:ss"), d.User, d.Amount.ToString("N0"), "بدهی", "تسویه بدهی");
                    }
                }
                catch { }

                // Color-code by type
                foreach (DataGridViewRow row in dgv.Rows)
                {
                    string t = row.Cells[3].Value?.ToString() ?? "";
                    if (t == "هزینه" || t == "پرداخت")
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(200, 30, 60);
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("CashForm", "Load error: " + ex.Message);
            }

            lblIn.Text  = cashIn.ToString("N0") + " ت";
            lblOut.Text = cashOut.ToString("N0") + " ت";
            lblNet.Text = (cashIn - cashOut).ToString("N0") + " ت";

            // Export button
            var btnExport = new Button
            {
                Text = "💾 خروجی CSV", Location = new Point(720, 95), Size = new Size(140, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnExport.Click += (s, e) =>
            {
                try
                {
                    using (var sfd = new SaveFileDialog())
                    {
                        sfd.Filter = "CSV (*.csv)|*.csv";
                        sfd.FileName = "cash_" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
                        if (sfd.ShowDialog(this) != DialogResult.OK) return;
                        using (var w = new System.IO.StreamWriter(sfd.FileName, false, System.Text.Encoding.UTF8))
                        {
                            w.WriteLine("Time,User,Amount,Type,Note");
                            foreach (DataGridViewRow row in dgv.Rows)
                            {
                                var fields = new List<string>();
                                for (int i = 0; i < 5; i++)
                                {
                                    string v = row.Cells[i].Value?.ToString() ?? "";
                                    v = v.Replace("\"", "\"\"");
                                    fields.Add("\"" + v + "\"");
                                }
                                w.WriteLine(string.Join(",", fields));
                            }
                        }
                        MessageBox.Show("ذخیره شد: " + sfd.FileName, "خروجی", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            Controls.Add(btnExport);
        }
    }
}
