using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 9: enhanced multi-branch management form.
    ///
    /// Adds (relative to the original BranchForm):
    ///   • Server IP + Server Port fields when creating/editing a branch
    ///   • "🔍 وضعیت شعبه" button that queries the branch's REST API
    ///     (GET /api/status) and shows the result (uptime, clients, income)
    ///   • Tooltip explaining that the branch must have RestApiServer
    ///     enabled (ApiPort > 0 in its options.json) for live status to work
    /// </summary>
    public class BranchForm : Form
    {
        private readonly BranchManager _mgr = new BranchManager();
        private DataGridView _dgv;
        private TextBox _txtName, _txtAddr, _txtPhone, _txtMgr, _txtIp, _txtPort;
        private NumericUpDown _numStations;
        private Button _btnAdd, _btnDelete, _btnQueryStatus, _btnRefresh;
        private Label _lblStatusResult;

        public BranchForm()
        {
            this.Text = "🏪 مدیریت شعب";
            this.Size = new Size(820, 620);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            var lblTitle = new Label { Text = "🏪 مدیریت شعب", Font = new Font("Segoe UI", 16F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 12), AutoSize = true };

            var grpNew = new GroupBox { Text = "شعبه جدید / ویرایش", Location = new Point(20, 50), Size = new Size(760, 130), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };

            var lblName = new Label { Text = "نام:", Location = new Point(10, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtName = new TextBox { Location = new Point(60, 22), Size = new Size(120, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblAddr = new Label { Text = "آدرس:", Location = new Point(195, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtAddr = new TextBox { Location = new Point(245, 22), Size = new Size(200, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblPhone = new Label { Text = "تلفن:", Location = new Point(455, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPhone = new TextBox { Location = new Point(500, 22), Size = new Size(100, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblMgr = new Label { Text = "مدیر:", Location = new Point(10, 55), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtMgr = new TextBox { Location = new Point(60, 52), Size = new Size(120, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblStations = new Label { Text = "تعداد سیستم:", Location = new Point(195, 55), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _numStations = new NumericUpDown { Location = new Point(290, 52), Size = new Size(60, 25), Minimum = 0, Maximum = 500, Value = 10, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            // ADD-MULTI-FEATURES Feature 9: server IP + port for REST queries
            var lblIp = new Label { Text = "IP سرور:", Location = new Point(10, 85), AutoSize = true, ForeColor = Color.FromArgb(20, 140, 130) };
            _txtIp = new TextBox { Location = new Point(80, 82), Size = new Size(150, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtIp.Text = "127.0.0.1";

            var lblPort = new Label { Text = "پورت API:", Location = new Point(240, 85), AutoSize = true, ForeColor = Color.FromArgb(20, 140, 130) };
            _txtPort = new TextBox { Location = new Point(310, 82), Size = new Size(70, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPort.Text = "8080";

            _btnAdd = new Button { Text = "➕ افزودن", Location = new Point(620, 78), Size = new Size(120, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            _btnAdd.Click += (s, e) => AddBranch();

            grpNew.Controls.AddRange(new Control[] { lblName, _txtName, lblAddr, _txtAddr, lblPhone, _txtPhone, lblMgr, _txtMgr, lblStations, _numStations, lblIp, _txtIp, lblPort, _txtPort, _btnAdd });

            _dgv = new DataGridView {
                Location = new Point(20, 195), Size = new Size(760, 280),
                BackgroundColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40),
                EnableHeadersVisualStyles = false,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(30, 80, 180) },
                GridColor = Color.FromArgb(69, 71, 90),
                AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            };
            _dgv.Columns.AddRange(new[] {
                new DataGridViewTextBoxColumn { HeaderText = "ID", Width = 40, FillWeight = 30 },
                new DataGridViewTextBoxColumn { HeaderText = "نام", Width = 120, FillWeight = 100 },
                new DataGridViewTextBoxColumn { HeaderText = "آدرس", Width = 200, FillWeight = 150 },
                new DataGridViewTextBoxColumn { HeaderText = "تلفن", Width = 100, FillWeight = 80 },
                new DataGridViewTextBoxColumn { HeaderText = "مدیر", Width = 100, FillWeight = 80 },
                new DataGridViewTextBoxColumn { HeaderText = "سیستم‌ها", Width = 60, FillWeight = 50 },
                new DataGridViewTextBoxColumn { HeaderText = "IP سرور", Width = 110, FillWeight = 90 },
                new DataGridViewTextBoxColumn { HeaderText = "پورت", Width = 50, FillWeight = 40 },
                new DataGridViewTextBoxColumn { HeaderText = "وضعیت", Width = 60, FillWeight = 50 },
            });
            _dgv.SelectionChanged += (s, e) => LoadSelectedIntoFields();

            _btnDelete = new Button { Text = "🗑️ حذف", Location = new Point(20, 485), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            _btnDelete.Click += (s, e) => DeleteSelected();

            _btnQueryStatus = new Button { Text = "🔍 وضعیت شعبه", Location = new Point(150, 485), Size = new Size(160, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            _btnQueryStatus.Click += (s, e) => QueryStatus();

            _btnRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(320, 485), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            _btnRefresh.Click += (s, e) => RefreshGrid();

            _lblStatusResult = new Label {
                Text = "نتیجه: ---",
                Location = new Point(20, 530),
                Size = new Size(760, 50),
                ForeColor = Color.FromArgb(20, 140, 130),
                Font = new Font("Segoe UI", 9F),
                AutoSize = false,
            };

            this.Controls.AddRange(new Control[] { lblTitle, grpNew, _dgv, _btnDelete, _btnQueryStatus, _btnRefresh, _lblStatusResult });
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            _dgv.Rows.Clear();
            try
            {
                foreach (var b in _mgr.GetAllBranches())
                    _dgv.Rows.Add(b.Id, b.Name, b.Address, b.Phone, b.ManagerName, b.StationCount, b.ServerIp, b.ServerPort, b.IsActive ? "فعال" : "غیرفعال");
            }
            catch (Exception ex)
            {
                // BUG FIX: same class of bug found across the PRO forms — a
                // bare "catch { }" left the grid silently empty on any
                // failure, indistinguishable from the feature doing nothing.
                try { _dgv.Rows.Clear(); _dgv.Rows.Add("", "⚠️ خطا: " + ex.Message); } catch { }
            }
        }

        private void LoadSelectedIntoFields()
        {
            if (_dgv.SelectedRows.Count == 0) return;
            var row = _dgv.SelectedRows[0];
            _txtName.Text = (string)row.Cells[1].Value;
            _txtAddr.Text = (string)row.Cells[2].Value;
            _txtPhone.Text = (string)row.Cells[3].Value;
            _txtMgr.Text = (string)row.Cells[4].Value;
            _numStations.Value = Convert.ToInt32(row.Cells[5].Value);
            _txtIp.Text = (string)row.Cells[6].Value;
            _txtPort.Text = row.Cells[7].Value?.ToString() ?? "8080";
        }

        private void AddBranch()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_txtName.Text)) { MessageBox.Show("نام شعبه را وارد کنید."); return; }
                int port = 8080;
                if (!int.TryParse(_txtPort.Text, out port) || port <= 0) port = 8080;
                _mgr.CreateBranch(_txtName.Text, _txtAddr.Text, _txtPhone.Text, _txtMgr.Text, (int)_numStations.Value, _txtIp.Text.Trim(), port);
                RefreshGrid();
                MessageBox.Show("✅ شعبه اضافه شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DeleteSelected()
        {
            if (_dgv.SelectedRows.Count == 0) { MessageBox.Show("یک شعبه انتخاب کنید."); return; }
            int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
            if (MessageBox.Show("حذف این شعبه؟", "تایید", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            _mgr.DeleteBranch(id);
            RefreshGrid();
        }

        /// <summary>
        /// ADD-MULTI-FEATURES Feature 9: queries the selected branch's
        /// /api/status endpoint (via BranchManager.QueryBranchStatus) and
        /// shows the parsed result (uptime, clients, today income). The
        /// remote branch must have RestApiServer enabled (ApiPort > 0 in
        /// its options.json).
        /// </summary>
        private void QueryStatus()
        {
            if (_dgv.SelectedRows.Count == 0) { MessageBox.Show("یک شعبه انتخاب کنید."); return; }
            int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
            _lblStatusResult.Text = "⏳ در حال دریافت وضعیت از شعبه...";
            _lblStatusResult.ForeColor = Color.FromArgb(180, 140, 20);
            Application.DoEvents();
            try
            {
                // Run the HTTP query on a background thread so the UI doesn't
                // freeze for the 3-second timeout when the branch is offline.
                string json = null;
                var t = new System.Threading.Thread(() => { json = _mgr.QueryBranchStatus(id); });
                t.Start();
                if (!t.Join(4000))
                {
                    _lblStatusResult.Text = "❌_TIMEOUT: شعبه در ۴ ثانیه پاسخ نداد. IP/پورت/فایروال را بررسی کنید.";
                    _lblStatusResult.ForeColor = Color.FromArgb(200, 30, 60);
                    return;
                }
                if (string.IsNullOrEmpty(json))
                {
                    _lblStatusResult.Text = "❌ خطا در دریافت وضعیت. شعبه آفلاین است یا REST API غیرفعال است (ApiPort در options.json).";
                    _lblStatusResult.ForeColor = Color.FromArgb(200, 30, 60);
                    return;
                }
                var st = _mgr.ParseBranchStatus(json);
                if (st == null)
                {
                    _lblStatusResult.Text = "❌ پاسخ نامعتبر از شعبه:\n" + (json.Length > 200 ? json.Substring(0, 200) + "…" : json);
                    _lblStatusResult.ForeColor = Color.FromArgb(200, 30, 60);
                    return;
                }
                _lblStatusResult.Text = $"✅ نسخه: {st.server_version}  |  آپ‌تایم: {st.uptime_seconds / 60:N0} دقیقه  |  کلاینت‌ها: {st.connected_clients}  |  درآمد امروز: {st.today_income:N0} تومان  |  دیتابیس: {st.database_provider}";
                _lblStatusResult.ForeColor = Color.FromArgb(20, 130, 50);
            }
            catch (Exception ex)
            {
                _lblStatusResult.Text = "❌ خطا: " + ex.Message;
                _lblStatusResult.ForeColor = Color.FromArgb(200, 30, 60);
            }
        }
    }
}
