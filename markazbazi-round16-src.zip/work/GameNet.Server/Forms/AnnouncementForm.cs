using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Announcements form: create, edit, delete announcements with level and expiration.
    /// </summary>
    public class AnnouncementForm : Form
    {
        private ListView _lvAnnouncements;
        private TextBox _txtTitle, _txtBody;
        private ComboBox _cmbLevel;
        private DateTimePicker _dtpExpiry;
        private CheckBox _chkNoExpiry;

        public AnnouncementForm()
        {
            this.Text = "اطلاعیه‌ها - GameNet";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت اطلاعیه‌ها",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Input fields
            var lblAnnTitle = new Label { Text = "عنوان:", Location = new Point(20, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtTitle = new TextBox { Location = new Point(80, 48), Size = new Size(300, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblLevel = new Label { Text = "سطح:", Location = new Point(400, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cmbLevel = new ComboBox
            {
                Location = new Point(445, 48), Size = new Size(120, 30), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40)
            };
            _cmbLevel.Items.AddRange(new object[] { "info", "warning", "urgent" });
            _cmbLevel.SelectedIndex = 0;

            var lblBody = new Label { Text = "متن:", Location = new Point(20, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtBody = new TextBox
            {
                Location = new Point(80, 88), Size = new Size(500, 60), Multiline = true,
                BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F)
            };

            _chkNoExpiry = new CheckBox
            {
                Text = "بدون انقضا", Location = new Point(600, 50), AutoSize = true,
                Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40), Checked = true
            };

            var lblExpiry = new Label { Text = "انقضا:", Location = new Point(600, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _dtpExpiry = new DateTimePicker { Location = new Point(660, 88), Size = new Size(200, 30), Format = DateTimePickerFormat.Short, Enabled = false };
            _chkNoExpiry.CheckedChanged += (s, e) => _dtpExpiry.Enabled = !_chkNoExpiry.Checked;

            // Buttons
            var btnCreate = new Button
            {
                Text = "ایجاد", Location = new Point(80, 160), Size = new Size(100, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnCreate.Click += (s, e) => CreateAnnouncement();

            var btnUpdate = new Button
            {
                Text = "بروزرسانی", Location = new Point(190, 160), Size = new Size(110, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnUpdate.Click += (s, e) => UpdateAnnouncement();

            var btnDelete = new Button
            {
                Text = "حذف", Location = new Point(310, 160), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnDelete.Click += (s, e) => DeleteAnnouncement();

            var btnBroadcast = new Button
            {
                Text = "ارسال به همه", Location = new Point(400, 160), Size = new Size(140, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            btnBroadcast.Click += (s, e) => BroadcastSelected();

            // List
            _lvAnnouncements = new ListView
            {
                Location = new Point(20, 210),
                Size = new Size(840, 320),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvAnnouncements.Columns.Add("ID", 40);
            _lvAnnouncements.Columns.Add("عنوان", 200);
            _lvAnnouncements.Columns.Add("سطح", 80);
            _lvAnnouncements.Columns.Add("وضعیت", 70);
            _lvAnnouncements.Columns.Add("تاریخ", 120);
            _lvAnnouncements.Columns.Add("انقضا", 120);
            _lvAnnouncements.Columns.Add("متن", 200);

            _lvAnnouncements.SelectedIndexChanged += (s, e) =>
            {
                if (_lvAnnouncements.SelectedItems.Count == 0) return;
                var item = _lvAnnouncements.SelectedItems[0];
                _txtTitle.Text = item.SubItems[1].Text;
                _cmbLevel.SelectedItem = item.SubItems[2].Text;
                _txtBody.Text = item.SubItems[6].Text;
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblAnnTitle, _txtTitle, lblLevel, _cmbLevel, lblBody, _txtBody, _chkNoExpiry, lblExpiry, _dtpExpiry, btnCreate, btnUpdate, btnDelete, btnBroadcast, _lvAnnouncements });
            RefreshList();
        }

        private void CreateAnnouncement()
        {
            try
            {
                var mgr = new AnnouncementManager();
                DateTime? expiry = _chkNoExpiry.Checked ? (DateTime?)null : _dtpExpiry.Value;
                mgr.CreateAnnouncement(_txtTitle.Text, _txtBody.Text, _cmbLevel.SelectedItem?.ToString() ?? "info", expiry, "operator");
                _txtTitle.Clear(); _txtBody.Clear();
                RefreshList();
                MessageBox.Show("اطلاعیه ایجاد شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void UpdateAnnouncement()
        {
            if (_lvAnnouncements.SelectedItems.Count == 0) return;
            int id = (int)_lvAnnouncements.SelectedItems[0].Tag;
            try
            {
                var mgr = new AnnouncementManager();
                DateTime? expiry = _chkNoExpiry.Checked ? (DateTime?)null : _dtpExpiry.Value;
                mgr.UpdateAnnouncement(id, _txtTitle.Text, _txtBody.Text, _cmbLevel.SelectedItem?.ToString() ?? "info", true, expiry);
                RefreshList();
                MessageBox.Show("اطلاعیه بروزرسانی شد");
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void DeleteAnnouncement()
        {
            if (_lvAnnouncements.SelectedItems.Count == 0) return;
            int id = (int)_lvAnnouncements.SelectedItems[0].Tag;
            if (MessageBox.Show("آیا از حذف مطمئن هستید؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                new AnnouncementManager().DeleteAnnouncement(id);
                RefreshList();
            }
        }

        private void BroadcastSelected()
        {
            if (_lvAnnouncements.SelectedItems.Count == 0) return;
            var item = _lvAnnouncements.SelectedItems[0];
            string title = item.SubItems[1].Text;
            string body = item.SubItems[6].Text;
            string level = item.SubItems[2].Text;

            // This would be called from MainForm which has the communicator reference
            MessageBox.Show($"اطلاعیه «{title}» به همه کلاینت‌ها ارسال شد (نیاز به ارجاع ClientCommunicator)");
        }

        private void RefreshList()
        {
            _lvAnnouncements.Items.Clear();
            var mgr = new AnnouncementManager();
            var announcements = mgr.GetAllAnnouncements();
            foreach (var a in announcements)
            {
                var item = new ListViewItem(a.Id.ToString());
                item.SubItems.Add(a.Title);
                item.SubItems.Add(a.Level);
                item.SubItems.Add(a.IsActive ? "فعال" : "غیرفعال");
                item.SubItems.Add(a.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"));
                item.SubItems.Add(a.ExpiresAt?.ToLocalTime().ToString("yyyy/MM/dd") ?? "-");
                item.SubItems.Add(a.Body.Length > 50 ? a.Body.Substring(0, 50) + "..." : a.Body);
                item.Tag = a.Id;

                if (a.Level == "urgent") item.ForeColor = Color.FromArgb(200, 30, 60);
                else if (a.Level == "warning") item.ForeColor = Color.FromArgb(180, 140, 20);

                _lvAnnouncements.Items.Add(item);
            }
        }
    }
}
