using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Print/Scan management form: view pending jobs, complete/cancel jobs, view pricing.
    /// </summary>
    public class PrintForm : Form
    {
        private ListView _lvJobs;
        private PrintManager _printMgr;

        public PrintForm()
        {
            _printMgr = new PrintManager();

            this.Text = "مدیریت پرینت - GameNet";
            this.Size = new Size(850, 550);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت پرینت و اسکن",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Pricing info
            var lblPricing = new Label
            {
                Text = "قیمت‌ها: سیاه‌سفید ۲,۰۰۰ | رنگی ۵,۰۰۰ | اسکن ۳,۰۰۰ تومان/صفحه",
                Location = new Point(20, 45), AutoSize = true,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(180, 140, 20)
            };

            // Buttons
            var btnComplete = new Button
            {
                Text = "تکمیل پرینت", Location = new Point(20, 75), Size = new Size(140, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnComplete.Click += (s, e) =>
            {
                if (_lvJobs.SelectedItems.Count == 0) return;
                int id = (int)_lvJobs.SelectedItems[0].Tag;
                _printMgr.CompletePrintJob(id);
                RefreshList();
                MessageBox.Show("پرینت تکمیل شد");
            };

            var btnCancel = new Button
            {
                Text = "لغو و بازگشت وجه", Location = new Point(170, 75), Size = new Size(160, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnCancel.Click += (s, e) =>
            {
                if (_lvJobs.SelectedItems.Count == 0) return;
                int id = (int)_lvJobs.SelectedItems[0].Tag;
                if (MessageBox.Show("آیا از لغو و بازگشت وجه مطمئن هستید؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    _printMgr.CancelPrintJob(id);
                    RefreshList();
                    MessageBox.Show("پرینت لغو شد و وجه بازگشت داده شد");
                }
            };

            var btnRefresh = new Button
            {
                Text = "به‌روزرسانی", Location = new Point(340, 75), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnRefresh.Click += (s, e) => RefreshList();

            // Stats
            var _lblStats = new Label
            {
                Location = new Point(500, 80), AutoSize = true,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 140, 130)
            };

            // Job list
            _lvJobs = new ListView
            {
                Location = new Point(20, 120),
                Size = new Size(800, 370),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvJobs.Columns.Add("ID", 40);
            _lvJobs.Columns.Add("کاربر", 100);
            _lvJobs.Columns.Add("ایستگاه", 100);
            _lvJobs.Columns.Add("سند", 120);
            _lvJobs.Columns.Add("صفحات", 60);
            _lvJobs.Columns.Add("نوع", 60);
            _lvJobs.Columns.Add("هزینه", 90);
            _lvJobs.Columns.Add("وضعیت", 80);
            _lvJobs.Columns.Add("تاریخ", 130);
            _lvJobs.Columns.Add("یادداشت", 120);

            this.Controls.AddRange(new Control[] { lblTitle, lblPricing, btnComplete, btnCancel, btnRefresh, _lblStats, _lvJobs });
            RefreshList();
        }

        private void RefreshList()
        {
            _lvJobs.Items.Clear();

            var stats = _printMgr.GetPrintStats();
            var pending = Database.Instance.Query(
                "SELECT id, username, station_name, document_name, pages, print_type, cost, status, notes, created_at, completed_at FROM print_jobs ORDER BY CASE WHEN status = 'pending' THEN 0 ELSE 1 END, created_at DESC LIMIT 100",
                null,
                r => new PrintManager.PrintJobInfo
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    StationName = r.IsDBNull(2) ? "" : r.GetString(2),
                    DocumentName = r.IsDBNull(3) ? "" : r.GetString(3),
                    Pages = r.GetInt32(4),
                    PrintType = r.GetString(5),
                    Cost = r.GetDecimal(6),
                    Status = r.GetString(7),
                    Notes = r.IsDBNull(8) ? "" : r.GetString(8),
                    CreatedAt = r.GetDateTime(9),
                    CompletedAt = r.IsDBNull(10) ? (DateTime?)null : r.GetDateTime(10)
                });

            foreach (var j in pending)
            {
                var item = new ListViewItem(j.Id.ToString());
                item.SubItems.Add(j.Username);
                item.SubItems.Add(j.StationName);
                item.SubItems.Add(j.DocumentName);
                item.SubItems.Add(j.Pages.ToString());
                item.SubItems.Add(j.PrintType == "color" ? "رنگی" : j.PrintType == "scan" ? "اسکن" : "سیاه‌سفید");
                item.SubItems.Add($"{j.Cost:N0}");
                item.SubItems.Add(j.Status == "pending" ? "در انتظار" : j.Status == "completed" ? "تکمیل" : "لغو");
                item.SubItems.Add(j.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"));
                item.SubItems.Add(j.Notes);
                item.Tag = j.Id;

                if (j.Status == "pending")
                    item.ForeColor = Color.FromArgb(180, 140, 20);
                else if (j.Status == "completed")
                    item.ForeColor = Color.FromArgb(20, 130, 50);
                else
                    item.ForeColor = Color.FromArgb(147, 153, 178);

                _lvJobs.Items.Add(item);
            }
        }
    }
}
