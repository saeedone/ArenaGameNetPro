using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class PaymentForm : Form
    {
        private readonly PaymentGateway _gateway;
        private DataGridView _dgvTransactions;

        public PaymentForm()
        {
            // FIX SEC-2/FUNC-1: pass a real, reachable callback URL instead
            // of PaymentGateway's broken default (see PaymentCallbackHelper
            // + RestApiServer.HandlePaymentCallback for the full picture).
            string callbackUrl = Core.PaymentCallbackHelper.GetCallbackUrlOrNull();
            _gateway = new PaymentGateway(
                Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_merchant'", null, r => r.GetString(0)) ?? "",
                callbackUrl: callbackUrl ?? "http://localhost:9090/payment/callback");
            this.Text = "درگاه پرداخت";
            this.Size = new Size(700, 550);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;

            var lblTitle = new Label { Text = "💳 درگاه پرداخت (زرین‌پال)", Font = new Font("Segoe UI", 16F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 15), AutoSize = true };

            var grpConfig = new GroupBox { Text = "تنظیمات درگاه", Location = new Point(20, 55), Size = new Size(640, 145), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var lblMerchant = new Label { Text = "Merchant ID:", Location = new Point(10, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtMerchant = new TextBox { Location = new Point(120, 22), Size = new Size(400, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var chkSandbox = new CheckBox { Text = "حالت تست (Sandbox)", Location = new Point(10, 60), Checked = true, ForeColor = Color.FromArgb(40, 40, 40) };
            // FIX SEC-2/FUNC-1: the operator must tell us the address their
            // customers can actually reach (a public domain/IP for a real
            // ZarinPal merchant) — this can't be guessed reliably, and
            // guessing wrong silently breaks crediting exactly like the
            // hardcoded default this replaces did.
            var lblCallback = new Label { Text = "آدرس بازگشت (Callback Base):", Location = new Point(10, 90), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtCallback = new TextBox { Location = new Point(220, 87), Size = new Size(300, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Text = Database.Instance.QueryOne("SELECT value FROM settings WHERE key = 'zarinpal_callback_base'", null, r => r.GetString(0)) ?? "" };
            // NOTE: TextBox.PlaceholderText doesn't exist in classic WinForms
            // (net472) — this project targets net472, not .NET 5+ WinForms —
            // so the hint goes in a tooltip instead of a placeholder.
            var tipCallback = new ToolTip();
            tipCallback.SetToolTip(txtCallback, "مثال: http://your-domain.com — خالی بگذارید تا از IP شبکه محلی استفاده شود (فقط برای تست/LAN کافی است)");
            var btnSaveConfig = new Button { Text = "ذخیره", Location = new Point(530, 22), Size = new Size(100, 30), BackColor = Color.FromArgb(166, 227, 161), FlatStyle = FlatStyle.Flat };
            btnSaveConfig.Click += (s, e) =>
            {
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('zarinpal_merchant', @v)", cmd => cmd.Parameters.AddWithValue("@v", txtMerchant.Text));
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('zarinpal_sandbox', @v)", cmd => cmd.Parameters.AddWithValue("@v", chkSandbox.Checked ? "1" : "0"));
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('zarinpal_callback_base', @v)", cmd => cmd.Parameters.AddWithValue("@v", txtCallback.Text.Trim()));
                MessageBox.Show("تنظیمات ذخیره شد!");
            };
            grpConfig.Controls.AddRange(new Control[] { lblMerchant, txtMerchant, chkSandbox, lblCallback, txtCallback, btnSaveConfig });

            // FIX SEC-2/FUNC-1: make the previously-silent failure mode
            // visible — without the REST API port enabled, ZarinPal has
            // nowhere to call back to and payments will never be credited
            // automatically, no matter what's configured above.
            if (Core.PaymentCallbackHelper.GetCallbackUrlOrNull() == null)
            {
                var lblWarn = new Label
                {
                    Text = "⚠️ پورت API غیرفعال است — بدون آن، تایید خودکار پرداخت کار نمی‌کند. آن را از «تنظیمات کلی → API» فعال کنید.",
                    Location = new Point(20, 200), Size = new Size(640, 20), AutoSize = false,
                    ForeColor = Color.FromArgb(200, 30, 60), Font = new Font("Segoe UI", 9F, FontStyle.Bold)
                };
                this.Controls.Add(lblWarn);
            }

            var grpNewPay = new GroupBox { Text = "پرداخت جدید", Location = new Point(20, 170), Size = new Size(640, 80), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var lblUser = new Label { Text = "کاربر:", Location = new Point(10, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtUser = new TextBox { Location = new Point(60, 22), Size = new Size(150, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var lblAmount = new Label { Text = "مبلغ (تومان):", Location = new Point(230, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtAmount = new TextBox { Location = new Point(330, 22), Size = new Size(150, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnPay = new Button { Text = "🔗 ایجاد لینک پرداخت", Location = new Point(500, 20), Size = new Size(130, 30), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnPay.Click += (s, e) =>
            {
                try
                {
                    decimal amt = decimal.Parse(txtAmount.Text);
                    var result = _gateway.RequestPayment(txtUser.Text, amt);
                    if (result.Success) { Clipboard.SetText(result.PaymentUrl); MessageBox.Show($"لینک پرداخت کپی شد:\n{result.PaymentUrl}"); }
                    else MessageBox.Show($"خطا: {result.Message}");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            };
            grpNewPay.Controls.AddRange(new Control[] { lblUser, txtUser, lblAmount, txtAmount, btnPay });

            _dgvTransactions = new DataGridView { Location = new Point(20, 270), Size = new Size(640, 220), BackgroundColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), EnableHeadersVisualStyles = false, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(30, 80, 180) }, GridColor = Color.FromArgb(69, 71, 90), AllowUserToAddRows = false, ReadOnly = true };
            _dgvTransactions.Columns.AddRange(new[] { new DataGridViewTextBoxColumn { HeaderText = "کاربر", Width = 100 }, new DataGridViewTextBoxColumn { HeaderText = "مبلغ", Width = 100 }, new DataGridViewTextBoxColumn { HeaderText = "وضعیت", Width = 80 }, new DataGridViewTextBoxColumn { HeaderText = "شماره مرجع", Width = 120 }, new DataGridViewTextBoxColumn { HeaderText = "تاریخ", Width = 130 } });
            var btnRefresh = new Button { Text = "🔄 بروزرسانی", Location = new Point(510, 500), Size = new Size(150, 35), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat };
            btnRefresh.Click += (s, e) => RefreshTransactions();

            this.Controls.AddRange(new Control[] { lblTitle, grpConfig, grpNewPay, _dgvTransactions, btnRefresh });
            RefreshTransactions();
        }

        private void RefreshTransactions()
        {
            _dgvTransactions.Rows.Clear();
            try { foreach (var tx in _gateway.GetTransactions()) _dgvTransactions.Rows.Add(tx.Username, tx.Amount.ToString("N0"), tx.Status, tx.RefId, tx.CreatedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm")); } catch { }
        }
    }
}
