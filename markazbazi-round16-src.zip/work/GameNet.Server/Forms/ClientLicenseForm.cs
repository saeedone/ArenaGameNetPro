using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Client license / station registration management form. Lets the
    /// operator:
    ///   • Register a new station manually (name + MAC → fingerprint)
    ///   • Approve pending clients (auto-added on first connect)
    ///   • Revoke a client (block it from reconnecting)
    ///   • Toggle auto-approve (auto-approve new clients on first connect)
    ///   • See last-seen timestamps to spot offline kiosks
    /// </summary>
    public class ClientLicenseForm : Form
    {
        private readonly ClientLicenseManager _mgr = new ClientLicenseManager();
        private DataGridView _dgv;
        private Timer _timer;
        private CheckBox _chkAutoApprove;
        private Label _lblPending;

        public ClientLicenseForm()
        {
            this.Text = "🔑 لایسنس کلاینت‌ها";
            this.Size = new Size(1000, 650);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshList(null, null);
            _timer = new Timer { Interval = 10000 };
            _timer.Tick += RefreshList;
            _timer.Start();
        }

        private void BuildUi()
        {
            // Top toolbar
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 100, BackColor = Color.FromArgb(240, 240, 240) };

            var lblTitle = new Label { Text = "🔑 مدیریت لایسنس کلاینت‌ها", Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 8), AutoSize = true };

            var lblName = new Label { Text = "نام ایستگاه:", Location = new Point(15, 38), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtName = new TextBox { Location = new Point(110, 35), Size = new Size(150, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblMac = new Label { Text = "MAC (اختیاری):", Location = new Point(270, 38), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtMac = new TextBox { Location = new Point(370, 35), Size = new Size(150, 28), Font = new Font("Consolas", 9F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblFp = new Label { Text = "اثر انگشت:", Location = new Point(530, 38), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtFp = new TextBox { Location = new Point(610, 35), Size = new Size(250, 28), Font = new Font("Consolas", 8F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            // FIX H2: the operator MUST paste the fingerprint the client sent
            // in its first ClientHello. The previous code auto-generated the
            // fingerprint with GenerateFingerprint(name, mac, windowsSerial="")
            // — but the client uses the REAL Windows ProductId, so the two
            // fingerprints NEVER matched. The auto-approve path (which runs
            // on first connect) is the correct way to register kiosks; the
            // operator should only use this manual form to approve pending
            // kiosks or paste a known fingerprint.
            var lblFpHint = new Label { Text = "اثر انگشت را از کلاینت کپی کنید (یا خالی بگذارید تا کلاینت در اولین اتصال خودکار ثبت شود)", Location = new Point(610, 60), AutoSize = true, Font = new Font("Segoe UI", 7F), ForeColor = Color.FromArgb(20, 140, 130) };

            var btnRegister = new Button { Text = "➕ ثبت ایستگاه", Location = new Point(15, 65), Size = new Size(140, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnRegister.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtName.Text)) { MessageBox.Show("نام ایستگاه را وارد کنید."); return; }
                try
                {
                    // FIX H2: if the operator didn't paste a fingerprint, we
                    // CANNOT auto-generate one — the client computes its
                    // fingerprint with the real Windows ProductId, which the
                    // server doesn't know. Auto-generating with
                    // GenerateFingerprint(name, mac, "") produces a DIFFERENT
                    // hash that will NEVER match → the pre-registered station
                    // is useless. Instead, if no fingerprint is provided,
                    // register with an empty fingerprint and rely on
                    // auto-approve-on-first-connect to update it. If a
                    // fingerprint IS provided (pasted from the client's
                    // ClientHello), use it verbatim.
                    string fp = string.IsNullOrWhiteSpace(txtFp.Text) ? "" : txtFp.Text.Trim();
                    var (id, token) = _mgr.RegisterStation(txtName.Text.Trim(), fp, txtMac.Text.Trim(), "operator");
                    MessageBox.Show($"✅ ایستگاه ثبت شد.\nنام: {txtName.Text}\nتوکن لایسنس:\n{token}\n\nاین توکن را به کلاینت بدهید.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtName.Clear(); txtMac.Clear(); txtFp.Clear();
                    RefreshList(null, null);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            _chkAutoApprove = new CheckBox { Text = "تأیید خودکار کلاینت‌های جدید (پیش‌فرض: روشن)", Location = new Point(170, 70), AutoSize = true, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(180, 140, 20) };
            // Default to checked (auto-approve ON) so first-run deployments work.
            _chkAutoApprove.Checked = true;
            try
            {
                var v = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = 'license_auto_approve'", null, r => r.GetString(0));
                // Only override the default if the setting was explicitly set
                if (!string.IsNullOrEmpty(v)) _chkAutoApprove.Checked = string.Equals(v, "True", StringComparison.OrdinalIgnoreCase);
            }
            catch { }
            _chkAutoApprove.CheckedChanged += (s, e) =>
            {
                Database.Instance.Execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('license_auto_approve', @v)",
                    cmd => cmd.Parameters.AddWithValue("@v", _chkAutoApprove.Checked.ToString()));
                MessageBox.Show("تنظیم ذخیره شد.");
            };

            _lblPending = new Label { Text = "", Location = new Point(400, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(200, 30, 60) };

            toolbar.Controls.AddRange(new Control[] { lblTitle, lblName, txtName, lblMac, txtMac, lblFp, txtFp, lblFpHint, btnRegister, _chkAutoApprove, _lblPending });

            // Grid
            _dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgv.Columns.Add("colId", "شناسه"); _dgv.Columns["colId"].Visible = false;
            _dgv.Columns.Add("colName", "نام ایستگاه");
            _dgv.Columns.Add("colFp", "اثر انگشت");
            _dgv.Columns.Add("colMac", "MAC");
            _dgv.Columns.Add("colStatus", "وضعیت");
            _dgv.Columns.Add("colApprovedBy", "تأیید توسط");
            _dgv.Columns.Add("colLastSeen", "آخرین دیدار");
            _dgv.Columns.Add("colNotes", "یادداشت");

            // Bottom buttons
            var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 45, BackColor = Color.FromArgb(240, 240, 240) };
            var btnApprove = new Button { Text = "✅ تأیید کلاینت", Location = new Point(15, 7), Size = new Size(170, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnApprove.Click += (s, e) =>
            {
                if (_dgv.SelectedRows.Count == 0) { MessageBox.Show("یک کلاینت انتخاب کنید."); return; }
                int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
                try
                {
                    string token = _mgr.ApproveClient(id, "operator");
                    MessageBox.Show($"✅ کلاینت تأیید شد.\nتوکن لایسنس:\n{token}\n\nاین توکن را به کلاینت بدهید.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshList(null, null);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };
            var btnRevoke = new Button { Text = "🚫 باطل کردن لایسنس", Location = new Point(195, 7), Size = new Size(200, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnRevoke.Click += (s, e) =>
            {
                if (_dgv.SelectedRows.Count == 0) { MessageBox.Show("یک کلاینت انتخاب کنید."); return; }
                int id = (int)_dgv.SelectedRows[0].Cells[0].Value;
                if (MessageBox.Show("باطل کردن لایسنس این کلاینت؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try { _mgr.RevokeClient(id, "باطل توسط اپراتور"); RefreshList(null, null); }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
                }
            };
            var btnRefresh = new Button { Text = "🔄 بازخوانی", Location = new Point(405, 7), Size = new Size(120, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRefresh.Click += (s, e) => RefreshList(null, null);
            bottomPanel.Controls.AddRange(new Control[] { btnApprove, btnRevoke, btnRefresh });

            Controls.AddRange(new Control[] { _dgv, bottomPanel, toolbar });
        }

        private void RefreshList(object s, EventArgs e)
        {
            try
            {
                _dgv.Rows.Clear();
                int pending = 0;
                foreach (var c in _mgr.GetAllClients())
                {
                    string status;
                    if (c.Revoked) { status = "❌ باطل"; }
                    else if (!c.Approved) { status = "⏳ در انتظار تأیید"; pending++; }
                    else { status = "✅ تأیید شده"; }

                    _dgv.Rows.Add(c.Id, c.StationName, c.Fingerprint.Length > 16 ? c.Fingerprint.Substring(0, 16) + "…" : c.Fingerprint,
                        c.Mac, status, c.ApprovedBy,
                        c.LastSeenAt.HasValue ? c.LastSeenAt.Value.ToLocalTime().ToString("MM-dd HH:mm") : "—",
                        c.Notes);
                }
                _lblPending.Text = pending > 0 ? $"⏳ {pending} کلاینت در انتظار تأیید" : "";
            }
            catch (Exception ex)
            {
                // BUG FIX: same silent-failure class as elsewhere — this
                // list of pending/approved client licenses would just go
                // blank on any error, with the operator having no way to
                // tell "no clients yet" apart from "something broke."
                try { _dgv.Rows.Clear(); _lblPending.Text = "⚠️ خطا در بارگذاری لیست کلاینت‌ها: " + ex.Message; } catch { }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
