using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 4: Tournament management form.
    ///
    /// Three sections:
    ///   1. Create new tournament (name, game, entry fee, prize, max, start time)
    ///   2. Active tournaments grid (open / full status) — select a row to
    ///      register a user, view participants, or set results
    ///   3. Participants grid for the selected tournament
    ///
    /// Accessible from the Tools menu (Tools ▸ بیشتر ▸ 🏆 مسابقات) and the
    /// "سیستم" sidebar tab.
    /// </summary>
    public class TournamentForm : Form
    {
        private readonly TournamentManager _mgr = new TournamentManager();

        private TextBox _txtName, _txtGame, _txtEntry, _txtPrize, _txtMax, _txtUser;
        private DateTimePicker _dtpStart;
        private DataGridView _dgvTourn, _dgvPart;
        private Button _btnCreate, _btnRegister, _btnSetResult, _btnDelete, _btnRefresh, _btnViewPart;
        private Label _lblSelectedTourn;

        private int _selectedTournId = 0;

        public TournamentForm()
        {
            this.Text = "🏆 مدیریت مسابقات";
            this.Size = new Size(980, 720);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            BuildUi();
            LoadTournaments();
        }

        private void BuildUi()
        {
            // === Create panel ===
            var grpCreate = new GroupBox
            {
                Text = "➕ ساخت مسابقه جدید",
                Location = new Point(15, 12),
                Size = new Size(930, 110),
                ForeColor = Color.FromArgb(20, 130, 50),
                BackColor = Color.FromArgb(255, 255, 255),
            };

            var lblName = new Label { Text = "نام مسابقه:", Location = new Point(15, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtName = new TextBox { Location = new Point(120, 22), Size = new Size(180, 28), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblGame = new Label { Text = "بازی:", Location = new Point(310, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtGame = new TextBox { Location = new Point(360, 22), Size = new Size(150, 28), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblEntry = new Label { Text = "مبلغ ورود:", Location = new Point(520, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtEntry = new TextBox { Location = new Point(610, 22), Size = new Size(110, 28), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Text = "0" };

            var lblPrize = new Label { Text = "جایزه:", Location = new Point(730, 25), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPrize = new TextBox { Location = new Point(800, 22), Size = new Size(110, 28), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Text = "0" };

            var lblMax = new Label { Text = "حداکثر شرکت‌کننده:", Location = new Point(15, 60), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtMax = new TextBox { Location = new Point(150, 57), Size = new Size(70, 28), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Text = "8" };

            var lblStart = new Label { Text = "زمان شروع:", Location = new Point(240, 60), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _dtpStart = new DateTimePicker { Location = new Point(330, 57), Size = new Size(220, 28), Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Value = DateTime.Now.AddHours(2) };

            _btnCreate = new Button
            {
                Text = "✅ ایجاد مسابقه",
                Location = new Point(660, 55),
                Size = new Size(250, 32),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)),
            };
            _btnCreate.Click += (s, e) => CreateTournament();

            grpCreate.Controls.AddRange(new Control[] { lblName, _txtName, lblGame, _txtGame, lblEntry, _txtEntry, lblPrize, _txtPrize, lblMax, _txtMax, lblStart, _dtpStart, _btnCreate });

            // === Tournaments grid ===
            var lblTourn = new Label { Text = "📋 مسابقات فعال", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 130), AutoSize = true };

            _dgvTourn = new DataGridView
            {
                Location = new Point(15, 160),
                Size = new Size(930, 230),
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvTourn.Columns.Add("colTId", "شناسه"); _dgvTourn.Columns["colTId"].Visible = false;
            _dgvTourn.Columns.Add("colTN", "نام مسابقه");
            _dgvTourn.Columns.Add("colTG", "بازی");
            _dgvTourn.Columns.Add("colTE", "مبلغ ورود");
            _dgvTourn.Columns.Add("colTP", "جایزه");
            _dgvTourn.Columns.Add("colTC", "ظرفیت");
            _dgvTourn.Columns.Add("colTS", "شروع");
            _dgvTourn.Columns.Add("colTSt", "وضعیت");
            _dgvTourn.SelectionChanged += (s, e) => OnTournSelectionChanged();

            // === Participants grid ===
            var lblPart = new Label { Text = "👥 شرکت‌کنندگان مسابقه انتخاب‌شده", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 400), AutoSize = true };
            _lblSelectedTourn = new Label { Text = "مسابقه: ---", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130), Location = new Point(280, 405), AutoSize = true };

            _dgvPart = new DataGridView
            {
                Location = new Point(15, 430),
                Size = new Size(930, 180),
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgvPart.Columns.Add("colPU", "نام کاربری");
            _dgvPart.Columns.Add("colPR", "زمان ثبت‌نام");

            // === Action bar ===
            var lblUser = new Label { Text = "نام کاربری برای ثبت‌نام:", Location = new Point(15, 625), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _txtUser = new TextBox { Location = new Point(180, 622), Size = new Size(180, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            _btnRegister = MkBtn("➕ ثبت‌نام", Color.FromArgb(166, 227, 161), 370, 620);
            _btnRegister.Click += (s, e) => Register();
            _btnSetResult = MkBtn("🏆 تعیین نتیجه", Color.FromArgb(249, 226, 175), 510, 620);
            _btnSetResult.Click += (s, e) => SetResult();
            _btnViewPart = MkBtn("🔄 بارگذاری شرکت‌کنندگان", Color.FromArgb(137, 180, 250), 660, 620);
            _btnViewPart.Click += (s, e) => LoadParticipants();
            _btnDelete = MkBtn("🗑️ حذف مسابقه", Color.FromArgb(243, 139, 168), 15, 660);
            _btnDelete.Click += (s, e) => DeleteSelected();
            _btnRefresh = MkBtn("🔄 بازخوانی مسابقات", Color.FromArgb(137, 180, 250), 200, 660);
            _btnRefresh.Click += (s, e) => LoadTournaments();

            this.Controls.AddRange(new Control[] {
                grpCreate,
                lblTourn, _dgvTourn,
                lblPart, _lblSelectedTourn, _dgvPart,
                lblUser, _txtUser,
                _btnRegister, _btnSetResult, _btnViewPart, _btnDelete, _btnRefresh,
            });
        }

        private Button MkBtn(string text, Color bg, int x, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(140, 32),
                BackColor = bg,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
            };
        }

        private void CreateTournament()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_txtName.Text)) { MessageBox.Show("نام مسابقه را وارد کنید."); return; }
                if (string.IsNullOrWhiteSpace(_txtGame.Text)) { MessageBox.Show("نام بازی را وارد کنید."); return; }
                if (!decimal.TryParse(_txtEntry.Text, out decimal entry) || entry < 0) { MessageBox.Show("مبلغ ورود معتبر وارد کنید."); return; }
                if (!decimal.TryParse(_txtPrize.Text, out decimal prize) || prize < 0) { MessageBox.Show("جایزه معتبر وارد کنید."); return; }
                if (!int.TryParse(_txtMax.Text, out int max) || max < 2) { MessageBox.Show("حداکثر شرکت‌کننده باید ≥ ۲ باشد."); return; }
                int id = _mgr.CreateTournament(_txtName.Text.Trim(), _txtGame.Text.Trim(), entry, prize, max, _dtpStart.Value);
                ToastNotification.Show(this, $"✅ مسابقه با شناسه {id} ساخته شد.", ToastType.Success, 2500);
                _txtName.Clear(); _txtGame.Clear();
                LoadTournaments();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void LoadTournaments()
        {
            try
            {
                _dgvTourn.Rows.Clear();
                foreach (var t in _mgr.GetActiveTournaments())
                {
                    int cur = _mgr.CountParticipants(t.Id);
                    _dgvTourn.Rows.Add(t.Id, t.Name, t.Game, t.EntryFee.ToString("N0") + " ت", t.Prize.ToString("N0") + " ت", $"{cur}/{t.MaxParticipants}", t.StartTime.ToLocalTime().ToString("yyyy/MM/dd HH:mm"), TranslateStatus(t.Status));
                }
            }
            catch { }
        }

        private void OnTournSelectionChanged()
        {
            if (_dgvTourn.SelectedRows.Count == 0) return;
            _selectedTournId = (int)_dgvTourn.SelectedRows[0].Cells[0].Value;
            string name = (string)_dgvTourn.SelectedRows[0].Cells[1].Value;
            _lblSelectedTourn.Text = "مسابقه: " + name;
            LoadParticipants();
        }

        private void LoadParticipants()
        {
            if (_selectedTournId <= 0) return;
            try
            {
                _dgvPart.Rows.Clear();
                foreach (var p in _mgr.GetTournamentParticipants(_selectedTournId))
                    _dgvPart.Rows.Add(p.Username, p.RegisteredAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"));
            }
            catch { }
        }

        private void Register()
        {
            if (_selectedTournId <= 0) { MessageBox.Show("ابتدا یک مسابقه انتخاب کنید."); return; }
            if (string.IsNullOrWhiteSpace(_txtUser.Text)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
            try
            {
                _mgr.RegisterUser(_selectedTournId, _txtUser.Text.Trim());
                ToastNotification.Show(this, $"✅ {_txtUser.Text} ثبت‌نام شد.", ToastType.Success, 2000);
                _txtUser.Clear();
                LoadParticipants();
                LoadTournaments(); // status may flip to 'full'
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void SetResult()
        {
            if (_selectedTournId <= 0) { MessageBox.Show("ابتدا یک مسابقه انتخاب کنید."); return; }
            if (_dgvPart.Rows.Count < 1) { MessageBox.Show("حداقل یک شرکت‌کننده لازم است."); return; }

            // Show a small dialog asking for winner + runner-up usernames.
            using (var dlg = new Form
            {
                Text = "تعیین نتیجه مسابقه",
                Size = new Size(420, 220),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                RightToLeft = RightToLeft.Yes,
            })
            {
                var lblW = new Label { Text = "برنده:", Location = new Point(20, 20), AutoSize = true };
                var txtW = new TextBox { Location = new Point(110, 17), Size = new Size(260, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
                var lblR = new Label { Text = "نایب قهرمان:", Location = new Point(20, 60), AutoSize = true };
                var txtR = new TextBox { Location = new Point(110, 57), Size = new Size(260, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };

                // Pre-fill with first two participants as a hint.
                if (_dgvPart.Rows.Count >= 1) txtW.Text = (string)_dgvPart.Rows[0].Cells[0].Value;
                if (_dgvPart.Rows.Count >= 2) txtR.Text = (string)_dgvPart.Rows[1].Cells[0].Value;

                var btnOk = new Button { Text = "✅ ثبت", DialogResult = DialogResult.OK, Location = new Point(110, 110), Size = new Size(120, 36), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
                var btnCancel = new Button { Text = "انصراف", DialogResult = DialogResult.Cancel, Location = new Point(250, 110), Size = new Size(120, 36), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
                dlg.Controls.AddRange(new Control[] { lblW, txtW, lblR, txtR, btnOk, btnCancel });
                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCancel;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        _mgr.SetResult(_selectedTournId, txtW.Text.Trim(), txtR.Text.Trim());
                        ToastNotification.Show(this, "🏆 نتیجه مسابقه ثبت شد.", ToastType.Success, 2500);
                        LoadTournaments();
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            }
        }

        private void DeleteSelected()
        {
            if (_selectedTournId <= 0) { MessageBox.Show("ابتدا یک مسابقه انتخاب کنید."); return; }
            if (MessageBox.Show("حذف این مسابقه و همه شرکت‌کنندگان آن؟", "تایید", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                _mgr.DeleteTournament(_selectedTournId);
                _selectedTournId = 0;
                _lblSelectedTourn.Text = "مسابقه: ---";
                _dgvPart.Rows.Clear();
                LoadTournaments();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private string TranslateStatus(string s)
        {
            switch (s)
            {
                case "open": return "🟢 باز";
                case "full": return "🟡 تکمیل";
                case "completed": return "✅ پایان‌یافته";
                default: return s;
            }
        }
    }
}
