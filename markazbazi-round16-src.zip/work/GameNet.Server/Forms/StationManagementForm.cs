﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class StationManagementForm : Form
    {
        private StationManager _mgr = new StationManager();

        public StationManagementForm()
        {
            this.Text = "مدیریت ایستگاه‌ها"; this.Size = new Size(900, 500);
            this.BackColor = ThemeManager.BackgroundColor; this.ForeColor = Color.FromArgb(40, 40, 40);

            var dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("colId", "شناسه"); dgv.Columns["colId"].Visible = false;
            dgv.Columns.Add("colName", "نام ایستگاه"); dgv.Columns.Add("colIp", "آدرس IP");
            dgv.Columns.Add("colMac", "MAC"); dgv.Columns.Add("colCat", "دسته");
            dgv.Columns.Add("colStatus", "وضعیت");

            var pnl = new Panel { Dock = DockStyle.Bottom, Height = 130, BackColor = Color.FromArgb(255, 255, 255), Padding = new Padding(10) };

            var txtName = new TextBox { Location = new Point(10, 30), Size = new Size(120, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "نام:", Location = new Point(10, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtName);

            var txtIp = new TextBox { Location = new Point(145, 30), Size = new Size(130, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "IP:", Location = new Point(145, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtIp);

            var txtMac = new TextBox { Location = new Point(290, 30), Size = new Size(130, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "MAC:", Location = new Point(290, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtMac);

            var txtCat = new TextBox { Location = new Point(435, 30), Size = new Size(120, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            pnl.Controls.Add(new Label { Text = "دسته:", Location = new Point(435, 10), ForeColor = Color.FromArgb(40, 40, 40) });
            pnl.Controls.Add(txtCat);

            var btnAdd = new Button { Text = "ایجاد", Location = new Point(10, 70), Size = new Size(100, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnAdd.Click += (s, e) => { try { _mgr.CreateStation(txtName.Text, txtIp.Text, txtMac.Text, category: txtCat.Text); LoadStations(dgv); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            pnl.Controls.Add(btnAdd);

            var btnScan = new Button { Text = "اسکن شبکه", Location = new Point(120, 70), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnScan.Click += (s, e) => { var scanner = new NetworkScanner(); var devices = new System.Collections.Generic.List<ScannedDevice>(); scanner.OnDeviceFound += d => devices.Add(d); scanner.OnScanComplete += devs => this.Invoke((Action)(() => { int c = _mgr.AutoCreateFromScan(devs); LoadStations(dgv); MessageBox.Show($"{c} ایستگاه جدید ایجاد شد"); })); System.Threading.ThreadPool.QueueUserWorkItem(_ => scanner.ScanNetwork()); MessageBox.Show("اسکن شروع شد..."); };
            pnl.Controls.Add(btnScan);

            var btnWakeOnLan = new Button { Text = "Wake-on-LAN", Location = new Point(255, 70), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(148, 226, 213)) };
            btnWakeOnLan.Click += (s, e) => { if (dgv.SelectedRows.Count > 0) { string mac = dgv.SelectedRows[0].Cells[3].Value?.ToString(); if (!string.IsNullOrEmpty(mac) && WakeOnLan.IsValidMacAddress(mac)) { WakeOnLan.SendMagicPacket(mac); MessageBox.Show("بسته WOL ارسال شد"); } else MessageBox.Show("MAC آدرس معتبر نیست"); } };
            pnl.Controls.Add(btnWakeOnLan);

            var btnDelete = new Button { Text = "حذف", Location = new Point(390, 70), Size = new Size(80, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnDelete.Click += (s, e) => { if (dgv.SelectedRows.Count > 0 && MessageBox.Show("حذف؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes) { _mgr.DeleteStation(Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value)); LoadStations(dgv); } };
            pnl.Controls.Add(btnDelete);

            Controls.AddRange(new Control[] { dgv, pnl });
            LoadStations(dgv);
        }

        private void LoadStations(DataGridView dgv)
        {
            dgv.Rows.Clear();
            foreach (var s in _mgr.GetAllStations())
                dgv.Rows.Add(s.Id, s.Name, s.IpAddress, s.MacAddress, s.Category, s.Status);
        }
    }
}
