using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// PRO live dashboard: the stations that are connected right now, with their
    /// live session values. Uses the same source as the client monitor
    /// (ClientCommunicator.GetAllRawConnections) and refreshes every 3 seconds.
    /// Before this change the form only created its columns and never added rows,
    /// so the tab always showed an empty grid.
    /// </summary>
    public class LiveDashboardForm : Form
    {
        private readonly ClientCommunicator _comm;
        private readonly DataGridView dgv;
        private readonly Timer tmr;

        public LiveDashboardForm(ClientCommunicator comm)
        {
            _comm = comm;

            this.Text = "📊 داشبورد زنده - markazbazi";
            this.Size = new Size(900, 600);
            this.BackColor = Color.FromArgb(30, 30, 46);
            this.ForeColor = Color.FromArgb(205, 214, 244);
            this.Font = new Font("Segoe UI", 9F);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.FromArgb(40, 40, 60),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                BorderStyle = BorderStyle.None
            };
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(205, 214, 244);
            dgv.DefaultCellStyle.BackColor = Color.FromArgb(40, 40, 60);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(35, 35, 52);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250));
            dgv.Columns.Add("Station", "ایستگاه");
            dgv.Columns.Add("User", "کاربر");
            dgv.Columns.Add("Minutes", "زمان");
            dgv.Columns.Add("Cost", "هزینه");
            dgv.Columns.Add("Cpu", "CPU");
            dgv.Columns.Add("Ram", "RAM");

            var pnl = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.FromArgb(35, 35, 52) };
            var btnRefresh = new Button
            {
                Text = "🔄 بارگذاری",
                Location = new Point(10, 10),
                Size = new Size(90, 30),
                BackColor = Color.FromArgb(137, 180, 250),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnRefresh.Click += (s, e) => LoadData();
            pnl.Controls.Add(btnRefresh);

            this.Controls.Add(dgv);
            this.Controls.Add(pnl);

            LoadData();
            tmr = new Timer { Interval = 3000 };
            tmr.Tick += (s, e) => LoadData();
            tmr.Start();
            this.FormClosing += (s, e) => tmr.Stop();
        }

        private void LoadData()
        {
            try
            {
                dgv.Rows.Clear();
                if (_comm == null) return;

                foreach (var c in _comm.GetAllRawConnections())
                {
                    // A socket that has not completed the hello is not a station yet.
                    if (c.State == GameNet.Shared.ClientState.Disconnected) continue;

                    dgv.Rows.Add(
                        string.IsNullOrEmpty(c.StationName) ? "(نامشخص)" : c.StationName,
                        string.IsNullOrEmpty(c.User) ? "-" : c.User,
                        c.Minutes,
                        c.Cost.ToString("N0"),
                        c.Cpu.ToString("0.0"),
                        c.Ram.ToString("0.0"));
                }
            }
            catch (Exception ex)
            {
                try
                {
                    dgv.Rows.Clear();
                    dgv.Rows.Add("⚠️ خطا در بارگذاری اطلاعات: " + ex.Message);
                }
                catch { }
            }
        }
    }
}
