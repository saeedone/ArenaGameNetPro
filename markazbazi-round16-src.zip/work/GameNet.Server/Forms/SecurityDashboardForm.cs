using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Phase 3.4 — Central security dashboard. Shows the status of every
    /// security subsystem in one place: TLS, master key age, session
    /// timeout, network ACL, audit chain integrity, backup encryption.
    /// Lets the operator rotate keys, create secure backups, and configure
    /// the network whitelist from a single screen.
    /// </summary>
    public class SecurityDashboardForm : Form
    {
        private Timer _timer;

        public SecurityDashboardForm()
        {
            this.Text = "🛡️ داشبورد امنیت";
            this.Size = new Size(900, 700);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
            RefreshStatus(null, null);
            _timer = new Timer { Interval = 10000 };
            _timer.Tick += RefreshStatus;
            _timer.Start();
        }

        private void BuildUi()
        {
            var scrollPanel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.FromArgb(240, 240, 240) };
            int y = 10;

            // === Section 1: Key Rotation ===
            y = AddSectionHeader(scrollPanel, y, "🔑 مدیریت کلیدها (Key Rotation)");
            y = AddKeyRotationCard(scrollPanel, y);

            // === Section 2: Network Access Control ===
            y = AddSectionHeader(scrollPanel, y + 15, "🌐 کنترل دسترسی شبکه");
            y = AddNetworkAclCard(scrollPanel, y);

            // === Section 3: Audit Chain Integrity ===
            y = AddSectionHeader(scrollPanel, y + 15, "📜 یکپارچگی زنجیره Audit");
            y = AddAuditChainCard(scrollPanel, y);

            // === Section 4: Secure Backup ===
            y = AddSectionHeader(scrollPanel, y + 15, "💾 پشتیبان رمزنگاری‌شده");
            y = AddSecureBackupCard(scrollPanel, y);

            // === Section 5: Session & TLS status ===
            y = AddSectionHeader(scrollPanel, y + 15, "🔐 وضعیت نشست و TLS");
            y = AddSessionTlsCard(scrollPanel, y);

            Controls.Add(scrollPanel);
        }

        private int AddSectionHeader(Panel parent, int y, string text)
        {
            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(15, y),
                AutoSize = true,
            };
            parent.Controls.Add(lbl);
            return y + 30;
        }

        private int AddKeyRotationCard(Panel parent, int y)
        {
            var card = new Panel { Location = new Point(15, y), Size = new Size(840, 120), BackColor = Color.FromArgb(230, 230, 235) };

            var lblMaster = new Label { Text = " کلید اصلی: ", Font = new Font("Segoe UI", 9F), Location = new Point(10, 8), AutoSize = true };
            var lblMasterStatus = new Label { Name = "lblMasterStatus", Font = new Font("Segoe UI", 9F, FontStyle.Bold), Location = new Point(120, 8), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };
            var lblMasterAge = new Label { Name = "lblMasterAge", Font = new Font("Segoe UI", 9F), Location = new Point(10, 30), AutoSize = true, ForeColor = Color.FromArgb(20, 140, 130) };

            var lblCert = new Label { Text = "گواهی TLS: ", Font = new Font("Segoe UI", 9F), Location = new Point(10, 55), AutoSize = true };
            var lblCertStatus = new Label { Name = "lblCertStatus", Font = new Font("Segoe UI", 9F, FontStyle.Bold), Location = new Point(120, 55), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };

            var btnRotateKey = new Button { Text = "🔄 چرخش کلید اصلی", Location = new Point(10, 82), Size = new Size(200, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)) };
            btnRotateKey.Click += (s, e) =>
            {
                if (MessageBox.Show("⚠️ چرخش کلید اصلی؟\nاین عملیات تمام داده‌های رمزنگاری‌شده را دوباره رمز می‌کند.\nمدت زمان: چند ثانیه تا چند دقیقه.\n\nادامه؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        int n = KeyRotationManager.RotateMasterKey();
                        MessageBox.Show($"✅ چرخش کلید کامل شد.\n{n} فیلد دوباره رمزنگاری شد.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshStatus(null, null);
                    }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            };

            var btnRotateCert = new Button { Text = "🔄 چرخش گواهی TLS", Location = new Point(220, 82), Size = new Size(200, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(203, 166, 247)) };
            btnRotateCert.Click += (s, e) =>
            {
                if (MessageBox.Show("⚠️ چرخش گواهی TLS؟\nبعد از این کار، فایل server_cert.pem جدید را به همه کلاینت‌ها کپی کنید.\n\nادامه؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        KeyRotationManager.RotateTlsCertificate();
                        MessageBox.Show("✅ گواهی جدید ساخته شد.\nحالا server_cert.pem جدید را به کلاینت‌ها بدهید!", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshStatus(null, null);
                    }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            };

            card.Controls.AddRange(new Control[] { lblMaster, lblMasterStatus, lblMasterAge, lblCert, lblCertStatus, btnRotateKey, btnRotateCert });
            parent.Controls.Add(card);
            return y + 130;
        }

        private int AddNetworkAclCard(Panel parent, int y)
        {
            var card = new Panel { Location = new Point(15, y), Size = new Size(840, 100), BackColor = Color.FromArgb(230, 230, 235) };

            var lblCidr = new Label { Text = "CIDR محدوده مجاز:", Font = new Font("Segoe UI", 9F), Location = new Point(10, 8), AutoSize = true };
            var txtCidr = new TextBox { Name = "txtCidr", Location = new Point(150, 5), Size = new Size(200, 28), Font = new Font("Consolas", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtCidr.Text = NetworkAccessControl.GetCidrFilter();
            var btnSetCidr = new Button { Text = "ذخیره", Location = new Point(360, 4), Size = new Size(80, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnSetCidr.Click += (s, e) =>
            {
                try { NetworkAccessControl.SetCidrFilter(txtCidr.Text.Trim()); MessageBox.Show("CIDR ذخیره شد."); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            var btnAddMac = new Button { Text = "+ افزودن MAC", Location = new Point(10, 45), Size = new Size(200, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnAddMac.Click += (s, e) =>
            {
                string mac = Microsoft.VisualBasic.Interaction.InputBox("MAC آدرس (مثال: 00:1A:2B:3C:4D:5E):", "افزودن MAC به whitelist");
                if (!string.IsNullOrWhiteSpace(mac))
                {
                    try { NetworkAccessControl.AddWhitelistEntry(mac); MessageBox.Show("MAC اضافه شد."); }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
                }
            };

            var lblWhitelistCount = new Label { Name = "lblWhitelistCount", Font = new Font("Segoe UI", 9F), Location = new Point(220, 50), AutoSize = true, ForeColor = Color.FromArgb(20, 140, 130) };

            card.Controls.AddRange(new Control[] { lblCidr, txtCidr, btnSetCidr, btnAddMac, lblWhitelistCount });
            parent.Controls.Add(card);
            return y + 110;
        }

        private int AddAuditChainCard(Panel parent, int y)
        {
            var card = new Panel { Location = new Point(15, y), Size = new Size(840, 80), BackColor = Color.FromArgb(230, 230, 235) };

            var lblChainStatus = new Label { Name = "lblChainStatus", Font = new Font("Segoe UI", 10F, FontStyle.Bold), Location = new Point(10, 10), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };

            var btnVerify = new Button { Text = "🔍 بررسی زنجیره", Location = new Point(10, 40), Size = new Size(180, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnVerify.Click += (s, e) =>
            {
                var (ok, brokenId, reason) = TamperProofAuditLog.VerifyChain();
                if (ok) MessageBox.Show("✅ زنجیره Audit سالم است — هیچ دستکاری‌ای تشخیص داده نشد.", "سالم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else MessageBox.Show($"❌ زنجیره خراب است!\nورودی #{brokenId}: {reason}", "تخریب", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RefreshStatus(null, null);
            };

            card.Controls.AddRange(new Control[] { lblChainStatus, btnVerify });
            parent.Controls.Add(card);
            return y + 90;
        }

        private int AddSecureBackupCard(Panel parent, int y)
        {
            var card = new Panel { Location = new Point(15, y), Size = new Size(840, 80), BackColor = Color.FromArgb(230, 230, 235) };

            var btnBackup = new Button { Text = "💾 پشتیبان رمزنگاری‌شده", Location = new Point(10, 10), Size = new Size(220, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnBackup.Click += (s, e) =>
            {
                try
                {
                    string path = SecureBackupManager.CreateEncryptedBackup("Manual secure backup");
                    MessageBox.Show($"✅ پشتیبان رمزنگاری‌شده ساخته شد:\n{path}", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            var btnBackupOffsite = new Button { Text = "☁️ پشتیبان + آپلود Offsite", Location = new Point(240, 10), Size = new Size(220, 30), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)) };
            btnBackupOffsite.Click += (s, e) =>
            {
                try
                {
                    string path = SecureBackupManager.CreateAndUploadOffsite("Manual offsite backup");
                    MessageBox.Show($"✅ پشتیبان ساخته و آپلود شد:\n{path}", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            var lblOffsiteUrl = new Label { Name = "lblOffsiteUrl", Font = new Font("Segoe UI", 9F), Location = new Point(10, 48), AutoSize = true, ForeColor = Color.FromArgb(20, 140, 130) };

            card.Controls.AddRange(new Control[] { btnBackup, btnBackupOffsite, lblOffsiteUrl });
            parent.Controls.Add(card);
            return y + 90;
        }

        private int AddSessionTlsCard(Panel parent, int y)
        {
            var card = new Panel { Location = new Point(15, y), Size = new Size(840, 90), BackColor = Color.FromArgb(230, 230, 235) };

            var lblSession = new Label { Name = "lblSession", Font = new Font("Segoe UI", 9F), Location = new Point(10, 8), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };
            var lblTls = new Label { Name = "lblTls", Font = new Font("Segoe UI", 9F), Location = new Point(10, 30), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };
            var lblHmac = new Label { Name = "lblHmac", Font = new Font("Segoe UI", 9F), Location = new Point(10, 52), AutoSize = true, ForeColor = Color.FromArgb(20, 130, 50) };

            card.Controls.AddRange(new Control[] { lblSession, lblTls, lblHmac });
            parent.Controls.Add(card);
            return y + 100;
        }

        private void RefreshStatus(object s, EventArgs e)
        {
            try
            {
                // Key rotation
                var ks = KeyRotationManager.GetKeyStatus();
                var lblMasterStatus = this.Controls.Find("lblMasterStatus", true).FirstOrDefault() as Label;
                var lblMasterAge = this.Controls.Find("lblMasterAge", true).FirstOrDefault() as Label;
                var lblCertStatus = this.Controls.Find("lblCertStatus", true).FirstOrDefault() as Label;
                if (lblMasterStatus != null)
                {
                    if (ks.MasterKeyRotationDue) { lblMasterStatus.Text = "🔴 نیاز به چرخش"; lblMasterStatus.ForeColor = Color.FromArgb(200, 30, 60); }
                    else if (ks.MasterKeyRotationWarning) { lblMasterStatus.Text = "🟡 نزدیک چرخش"; lblMasterStatus.ForeColor = Color.FromArgb(180, 140, 20); }
                    else { lblMasterStatus.Text = "🟢 سالم"; lblMasterStatus.ForeColor = Color.FromArgb(20, 130, 50); }
                }
                if (lblMasterAge != null)
                    lblMasterAge.Text = $"   سن: {ks.MasterKeyAgeDays:0} روز (حداکثر: {KeyRotationManager.RotationIntervalDays} روز)";
                if (lblCertStatus != null)
                {
                    if (ks.CertRotationDue) { lblCertStatus.Text = $"🔴 منقضی می‌شود: {ks.CertNotAfter:yyyy-MM-dd}"; lblCertStatus.ForeColor = Color.FromArgb(200, 30, 60); }
                    else if (ks.CertRotationWarning) { lblCertStatus.Text = $"🟡 منقضی می‌شود: {ks.CertNotAfter:yyyy-MM-dd}"; lblCertStatus.ForeColor = Color.FromArgb(180, 140, 20); }
                    else { lblCertStatus.Text = $"🟢 معتبر تا {ks.CertNotAfter:yyyy-MM-dd}"; lblCertStatus.ForeColor = Color.FromArgb(20, 130, 50); }
                }

                // Network ACL
                var lblWhitelistCount = this.Controls.Find("lblWhitelistCount", true).FirstOrDefault() as Label;
                if (lblWhitelistCount != null)
                {
                    var wl = NetworkAccessControl.GetWhitelist();
                    string cidr = NetworkAccessControl.GetCidrFilter();
                    lblWhitelistCount.Text = $"تعداد MAC در whitelist: {wl.Count}  |  CIDR: {(string.IsNullOrEmpty(cidr) ? "غیرفعال" : cidr)}";
                }

                // Audit chain
                var lblChainStatus = this.Controls.Find("lblChainStatus", true).FirstOrDefault() as Label;
                if (lblChainStatus != null)
                {
                    var (ok, brokenId, reason) = TamperProofAuditLog.VerifyChain();
                    if (ok) { lblChainStatus.Text = "🟢 زنجیره Audit سالم است"; lblChainStatus.ForeColor = Color.FromArgb(20, 130, 50); }
                    else { lblChainStatus.Text = $"❌ زنجیره خراب است — ورودی #{brokenId}"; lblChainStatus.ForeColor = Color.FromArgb(200, 30, 60); }
                }

                // Secure backup
                var lblOffsiteUrl = this.Controls.Find("lblOffsiteUrl", true).FirstOrDefault() as Label;
                if (lblOffsiteUrl != null)
                {
                    string url = Database.Instance.QueryOne<string>("SELECT value FROM settings WHERE key = 'offsite_url'", null, r => r.GetString(0)) ?? "";
                    lblOffsiteUrl.Text = string.IsNullOrEmpty(url) ? "Offsite: غیرفعال (تنظیم نشده)" : $"Offsite: {url}";
                }

                // Session/TLS/HMAC
                var lblSession = this.Controls.Find("lblSession", true).FirstOrDefault() as Label;
                if (lblSession != null) lblSession.Text = "⏱️  Session Timeout: ✅ فعال (۱۵ دقیقه)";
                var lblTls = this.Controls.Find("lblTls", true).FirstOrDefault() as Label;
                if (lblTls != null) lblTls.Text = "🔒  TLS: ✅ فعال (گواهی خودکار)";
                var lblHmac = this.Controls.Find("lblHmac", true).FirstOrDefault() as Label;
                if (lblHmac != null) lblHmac.Text = "✍️  HMAC امضای پیام: ✅ فعال + Anti-replay";
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop(); _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
