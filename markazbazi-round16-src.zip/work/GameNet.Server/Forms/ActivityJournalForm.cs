using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Round 14: "🕵️ وقتی نبودم" — reads ActivityJournal. Presets: since my last exit,
    /// today, yesterday, last 7 days, or any range; filter by kind and a search text;
    /// a count per kind; export to CSV (opens in Excel).
    /// </summary>
    internal sealed class ActivityJournalForm : Form
    {
        private readonly ComboBox _cboRange, _cboKind;
        private readonly DateTimePicker _dtFrom, _dtTo;
        private readonly TextBox _txtSearch;
        private readonly DataGridView _grid;
        private readonly Label _lblSummary;
        private List<ActivityJournal.Entry> _rows = new List<ActivityJournal.Entry>();
        private static readonly PersianCalendar Pc = new PersianCalendar();

        public ActivityJournalForm()
        {
            Text = "🕵️ وقتی نبودم";
            Size = new Size(1100, 700);
            BackColor = Color.White;
            RightToLeft = RightToLeft.Yes;
            Font = new Font("Segoe UI", 10F);

            var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(8, 8, 8, 0), WrapContents = false, FlowDirection = FlowDirection.RightToLeft, BackColor = Color.FromArgb(240, 242, 247) };
            _cboRange = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 190 };
            _cboRange.Items.AddRange(new object[] { "از آخرین خروج من", "امروز", "دیروز", "۷ روز گذشته", "۳۰ روز گذشته", "بازهٔ دلخواه" });
            _dtFrom = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Width = 150, RightToLeftLayout = false };
            _dtTo = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy/MM/dd HH:mm", Width = 150, RightToLeftLayout = false };
            _cboKind = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 170 };
            _cboKind.Items.Add("همهٔ رخدادها");
            _cboKind.Items.AddRange(ActivityJournal.Kinds);
            _cboKind.SelectedIndex = 0;
            _txtSearch = new TextBox { Width = 170 };
            var btnShow = MkButton("🔍 نمایش", Color.FromArgb(30, 80, 180));
            var btnCsv = MkButton("💾 خروجی Excel", Color.FromArgb(46, 140, 67));
            btnShow.Click += (s, e) => Reload();
            btnCsv.Click += (s, e) => ExportCsv();
            _txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Reload(); } };
            _cboRange.SelectedIndexChanged += (s, e) => { ApplyPreset(); Reload(); };
            _cboKind.SelectedIndexChanged += (s, e) => Reload();
            bar.Controls.AddRange(new Control[]
            {
                new Label { Text = "بازه:", AutoSize = true, Margin = new Padding(4, 6, 2, 0) }, _cboRange,
                new Label { Text = "از", AutoSize = true, Margin = new Padding(8, 6, 2, 0) }, _dtFrom,
                new Label { Text = "تا", AutoSize = true, Margin = new Padding(8, 6, 2, 0) }, _dtTo,
                new Label { Text = "نوع:", AutoSize = true, Margin = new Padding(8, 6, 2, 0) }, _cboKind,
                new Label { Text = "جست‌وجو:", AutoSize = true, Margin = new Padding(8, 6, 2, 0) }, _txtSearch,
                btnShow, btnCsv,
            });

            _lblSummary = new Label { Dock = DockStyle.Top, Height = 54, Padding = new Padding(10, 6, 10, 0), ForeColor = Color.FromArgb(40, 40, 60), BackColor = Color.FromArgb(250, 250, 253) };

            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                EnableHeadersVisualStyles = false,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(232, 236, 245), ForeColor = Color.FromArgb(30, 60, 140), Font = new Font("Segoe UI", 10F, FontStyle.Bold) },
                DefaultCellStyle = new DataGridViewCellStyle { ForeColor = Color.FromArgb(30, 30, 40), SelectionBackColor = Color.FromArgb(200, 215, 245), SelectionForeColor = Color.Black, WrapMode = DataGridViewTriState.True },
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(248, 249, 252) },
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
            };
            _grid.Columns.Add("time", "زمان"); _grid.Columns["time"].FillWeight = 16;
            _grid.Columns.Add("kind", "نوع"); _grid.Columns["kind"].FillWeight = 14;
            _grid.Columns.Add("station", "سیستم"); _grid.Columns["station"].FillWeight = 10;
            _grid.Columns.Add("op", "اپراتور"); _grid.Columns["op"].FillWeight = 10;
            _grid.Columns.Add("text", "شرح"); _grid.Columns["text"].FillWeight = 50;

            Controls.Add(_grid);
            Controls.Add(_lblSummary);
            Controls.Add(bar);

            _cboRange.SelectedIndex = 0; // triggers ApplyPreset + Reload
        }

        private static Button MkButton(string text, Color back)
        {
            var b = new Button { Text = text, AutoSize = true, FlatStyle = FlatStyle.Flat, BackColor = back, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), Margin = new Padding(8, 0, 0, 0), Height = 30 };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private void ApplyPreset()
        {
            var now = DateTime.Now;
            bool custom = _cboRange.SelectedIndex == 5;
            _dtFrom.Enabled = _dtTo.Enabled = custom;
            if (custom) return;
            DateTime from;
            DateTime to = now;
            switch (_cboRange.SelectedIndex)
            {
                case 0:
                    var leave = ActivityJournal.LastLeaveOf(ActivityJournal.CurrentOperator);
                    from = leave.HasValue ? leave.Value.ToLocalTime() : now.Date.AddDays(-1);
                    break;
                case 1: from = now.Date; break;
                case 2: from = now.Date.AddDays(-1); to = now.Date.AddSeconds(-1); break;
                case 3: from = now.Date.AddDays(-7); break;
                default: from = now.Date.AddDays(-30); break;
            }
            _dtFrom.Value = from < _dtFrom.MinDate ? _dtFrom.MinDate : from;
            _dtTo.Value = to;
        }

        private static string Fa(DateTime t)
        {
            try
            {
                return string.Format("{0:0000}/{1:00}/{2:00} {3:HH:mm:ss}", Pc.GetYear(t), Pc.GetMonth(t), Pc.GetDayOfMonth(t), t);
            }
            catch { return t.ToString("yyyy/MM/dd HH:mm:ss"); }
        }

        private void Reload()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                DateTime fromUtc = _dtFrom.Value.ToUniversalTime();
                DateTime toUtc = (_cboRange.SelectedIndex == 5 ? _dtTo.Value : (_cboRange.SelectedIndex == 2 ? _dtTo.Value : DateTime.Now.AddMinutes(1))).ToUniversalTime();
                string kind = _cboKind.SelectedIndex > 0 ? _cboKind.SelectedItem as string : null;
                _rows = ActivityJournal.Query(fromUtc, toUtc, kind, _txtSearch.Text);
                _grid.SuspendLayout();
                _grid.Rows.Clear();
                foreach (var r in _rows)
                    _grid.Rows.Add(Fa(r.Time), r.Kind, r.Station, r.Operator, r.Text);
                _grid.ResumeLayout();

                var counts = _rows.GroupBy(r => r.Kind).OrderByDescending(g => g.Count()).Select(g => g.Key + ": " + g.Count());
                _lblSummary.Text = "از " + Fa(fromUtc.ToLocalTime()) + " تا " + Fa(toUtc.ToLocalTime()) + " — " + _rows.Count + " رخداد" +
                    (_rows.Count >= 5000 ? " (فقط ۵۰۰۰ مورد آخر نشان داده شد؛ بازه را کوچک‌تر کنید)" : "") +
                    "\n" + string.Join("   ·   ", counts);
            }
            catch (Exception ex) { _lblSummary.Text = "خطا در خواندن گزارش: " + ex.Message; }
            finally { Cursor = Cursors.Default; }
        }

        private void ExportCsv()
        {
            if (_rows.Count == 0) { MessageBox.Show(this, "رخدادی برای خروجی نیست."); return; }
            using (var dlg = new SaveFileDialog { Filter = "CSV (Excel)|*.csv", FileName = "gamenet_activity_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".csv" })
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("زمان,نوع,سیستم,اپراتور,شرح");
                    Func<string, string> q = v => "\"" + (v ?? "").Replace("\"", "\"\"") + "\"";
                    foreach (var r in _rows)
                        sb.AppendLine(string.Join(",", q(Fa(r.Time)), q(r.Kind), q(r.Station), q(r.Operator), q(r.Text)));
                    File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true)); // BOM: Excel shows Persian correctly
                    MessageBox.Show(this, "ذخیره شد.", "خروجی", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "خطا"); }
            }
        }
    }
}
