using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Loyalty + discount-code management form. Two tabs:
    ///   1. Loyalty — set earn/redeem rates, look up a user's point balance
    ///      and history, redeem points for credit.
    ///   2. Discount codes — create, list, deactivate, delete codes.
    /// </summary>
    public class LoyaltyForm : Form
    {
        private readonly LoyaltyManager _mgr = new LoyaltyManager();

        public LoyaltyForm()
        {
            this.Text = "🏆 وفاداری + کد تخفیف";
            this.Size = new Size(1000, 650);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;

            BuildUi();
        }

        private void BuildUi()
        {
            var tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9F) };

            // === Tab 1: Loyalty ===
            var tabLoyalty = new TabPage("🏆 امتیازات وفاداری") { BackColor = Color.FromArgb(240, 240, 240) };

            var lblRates = new Label { Text = "⚙️ تنظیمات نرخ‌ها", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 10), AutoSize = true };

            var lblEarn = new Label { Text = "هر X تومان = ۱ امتیاز:", Location = new Point(15, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtEarn = new TextBox { Location = new Point(180, 37), Size = new Size(120, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtEarn.Text = _mgr.GetEarnRate().ToString("0");

            var lblRedeem = new Label { Text = "هر امتیاز = X تومان اعتبار:", Location = new Point(320, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtRedeem = new TextBox { Location = new Point(520, 37), Size = new Size(120, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtRedeem.Text = _mgr.GetRedeemRate().ToString("0");

            var btnSaveRates = new Button { Text = "💾 ذخیره نرخ‌ها", Location = new Point(660, 35), Size = new Size(140, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnSaveRates.Click += (s, e) =>
            {
                try
                {
                    if (decimal.TryParse(txtEarn.Text, out decimal earn) && earn > 0) _mgr.SetEarnRate(earn);
                    if (decimal.TryParse(txtRedeem.Text, out decimal redeem) && redeem > 0) _mgr.SetRedeemRate(redeem);
                    MessageBox.Show("نرخ‌ها ذخیره شدند.");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            // User lookup
            var lblLookup = new Label { Text = "🔍 جستجوی کاربر", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 85), AutoSize = true };
            var lblUser = new Label { Text = "نام کاربری:", Location = new Point(15, 115), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtUser = new TextBox { Location = new Point(120, 112), Size = new Size(200, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnLookup = new Button { Text = "🔍 نمایش", Location = new Point(330, 110), Size = new Size(100, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };

            var lblPoints = new Label { Text = "امتیاز فعلی: ---", Location = new Point(450, 115), AutoSize = true, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50) };
            var lblTotalEarned = new Label { Text = "کل کسب‌شده: ---", Location = new Point(600, 115), AutoSize = true, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130) };
            var lblTotalRedeemed = new Label { Text = "کل خرج‌شده: ---", Location = new Point(750, 115), AutoSize = true, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130) };

            var lblRedeemPts = new Label { Text = "تعداد امتیاز برای تبدیل:", Location = new Point(15, 150), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtRedeemPts = new TextBox { Location = new Point(180, 147), Size = new Size(120, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnRedeem = new Button { Text = "💰 تبدیل به اعتبار", Location = new Point(310, 145), Size = new Size(170, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)) };
            btnRedeem.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtUser.Text)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
                if (!int.TryParse(txtRedeemPts.Text, out int pts) || pts <= 0) { MessageBox.Show("تعداد امتیاز معتبر وارد کنید."); return; }
                try
                {
                    decimal credit = _mgr.RedeemPoints(txtUser.Text.Trim(), pts);
                    MessageBox.Show($"✅ {pts} امتیاز تبدیل شد به {credit:N0} تومان اعتبار.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLookup.PerformClick();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            // History grid
            var dgvHistory = new DataGridView
            {
                Location = new Point(15, 190), Size = new Size(940, 380),
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            dgvHistory.Columns.Add("colPts", "امتیاز");
            dgvHistory.Columns.Add("colReason", "دلیل");
            dgvHistory.Columns.Add("colCost", "هزینه جلسه");
            dgvHistory.Columns.Add("colDate", "تاریخ");

            btnLookup.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtUser.Text)) return;
                try
                {
                    var summary = _mgr.GetPointSummary(txtUser.Text.Trim());
                    lblPoints.Text = $"امتیاز فعلی: {summary.Points}";
                    lblTotalEarned.Text = $"کل کسب‌شده: {summary.TotalEarned}";
                    lblTotalRedeemed.Text = $"کل خرج‌شده: {summary.TotalRedeemed}";
                    dgvHistory.Rows.Clear();
                    foreach (var h in _mgr.GetHistory(txtUser.Text.Trim()))
                    {
                        string ptsStr = h.Points > 0 ? "+" + h.Points : h.Points.ToString();
                        dgvHistory.Rows.Add(ptsStr, h.Reason, h.SessionCost > 0 ? h.SessionCost.ToString("N0") + " ت" : "-", h.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd HH:mm"));
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            tabLoyalty.Controls.AddRange(new Control[] { lblRates, lblEarn, txtEarn, lblRedeem, txtRedeem, btnSaveRates, lblLookup, lblUser, txtUser, btnLookup, lblPoints, lblTotalEarned, lblTotalRedeemed, lblRedeemPts, txtRedeemPts, btnRedeem, dgvHistory });

            // === Tab 2: Discount codes ===
            var tabCodes = new TabPage("🎫 کد تخفیف") { BackColor = Color.FromArgb(240, 240, 240) };

            // Create code panel
            var lblCreate = new Label { Text = "➕ ساخت کد جدید", Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(15, 10), AutoSize = true };

            var lblCode = new Label { Text = "کد (خالی=تصادفی):", Location = new Point(15, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtCode = new TextBox { Location = new Point(180, 37), Size = new Size(150, 28), Font = new Font("Consolas", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblType = new Label { Text = "نوع:", Location = new Point(340, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var cboType = new ComboBox { Location = new Point(380, 37), Size = new Size(120, 28), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cboType.Items.AddRange(new object[] { "Percent", "Fixed" });
            cboType.SelectedIndex = 0;

            var lblValue = new Label { Text = "مقدار:", Location = new Point(510, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtValue = new TextBox { Location = new Point(560, 37), Size = new Size(80, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtValue.Text = "10";

            var lblMaxUses = new Label { Text = "سقف استفاده (۰=نامحدود):", Location = new Point(650, 40), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtMaxUses = new TextBox { Location = new Point(830, 37), Size = new Size(80, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            txtMaxUses.Text = "0";

            var lblExp = new Label { Text = "انقضا (خالی=بدون انقضا):", Location = new Point(15, 75), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var dtpExp = new DateTimePicker { Location = new Point(180, 72), Size = new Size(200, 28), Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 9F), Value = DateTime.UtcNow.AddDays(30), ShowCheckBox = true, Checked = false };

            var chkSingleUse = new CheckBox { Text = "یکبار استفاده برای هر کاربر", Location = new Point(400, 75), AutoSize = true, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(20, 140, 130) };

            var lblDesc = new Label { Text = "توضیحات:", Location = new Point(620, 75), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            var txtDesc = new TextBox { Location = new Point(700, 72), Size = new Size(210, 28), Font = new Font("Segoe UI", 9F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };

            // Codes grid
            var dgvCodes = new DataGridView
            {
                Location = new Point(15, 155), Size = new Size(940, 420),
                BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            dgvCodes.Columns.Add("colCId", "شناسه"); dgvCodes.Columns["colCId"].Visible = false;
            dgvCodes.Columns.Add("colCCode", "کد");
            dgvCodes.Columns.Add("colCType", "نوع");
            dgvCodes.Columns.Add("colCValue", "مقدار");
            dgvCodes.Columns.Add("colCUses", "استفاده/سقف");
            dgvCodes.Columns.Add("colCExp", "انقضا");
            dgvCodes.Columns.Add("colCActive", "فعال");
            dgvCodes.Columns.Add("colCDesc", "توضیحات");

            var btnCreate = new Button { Text = "✅ ساخت کد", Location = new Point(15, 110), Size = new Size(200, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnCreate.Click += (s, e) =>
            {
                try
                {
                    if (!decimal.TryParse(txtValue.Text, out decimal val) || val <= 0) { MessageBox.Show("مقدار معتبر وارد کنید."); return; }
                    if (!int.TryParse(txtMaxUses.Text, out int maxUses) || maxUses < 0) { MessageBox.Show("سقف استفاده معتبر وارد کنید."); return; }
                    DateTime? exp = dtpExp.Checked ? dtpExp.Value.ToUniversalTime() : (DateTime?)null;
                    string code = _mgr.CreateDiscountCode(txtCode.Text.Trim(), cboType.SelectedItem.ToString(), val, maxUses, exp, chkSingleUse.Checked, txtDesc.Text.Trim());
                    MessageBox.Show($"✅ کد ساخته شد: {code}", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCode.Clear(); txtDesc.Clear();
                    LoadCodes(dgvCodes);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا"); }
            };

            var btnDeactivate = new Button { Text = "🚫 غیرفعال‌کردن", Location = new Point(225, 110), Size = new Size(170, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)) };
            btnDeactivate.Click += (s, e) =>
            {
                if (dgvCodes.SelectedRows.Count == 0) { MessageBox.Show("یک کد انتخاب کنید."); return; }
                int id = (int)dgvCodes.SelectedRows[0].Cells[0].Value;
                _mgr.DeactivateCode(id);
                LoadCodes(dgvCodes);
            };
            var btnDelete = new Button { Text = "🗑 حذف", Location = new Point(405, 110), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnDelete.Click += (s, e) =>
            {
                if (dgvCodes.SelectedRows.Count == 0) { MessageBox.Show("یک کد انتخاب کنید."); return; }
                int id = (int)dgvCodes.SelectedRows[0].Cells[0].Value;
                if (MessageBox.Show("حذف این کد؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    _mgr.DeleteCode(id);
                    LoadCodes(dgvCodes);
                }
            };
            var btnRefreshCodes = new Button { Text = "🔄 بازخوانی", Location = new Point(535, 110), Size = new Size(120, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
            btnRefreshCodes.Click += (s, e) => LoadCodes(dgvCodes);

            tabCodes.Controls.AddRange(new Control[] { lblCreate, lblCode, txtCode, lblType, cboType, lblValue, txtValue, lblMaxUses, txtMaxUses, lblExp, dtpExp, chkSingleUse, lblDesc, txtDesc, btnCreate, btnDeactivate, btnDelete, btnRefreshCodes, dgvCodes });

            tabs.TabPages.AddRange(new TabPage[] { tabLoyalty, tabCodes });
            Controls.Add(tabs);

            LoadCodes(dgvCodes);
        }

        private void LoadCodes(DataGridView dgv)
        {
            try
            {
                dgv.Rows.Clear();
                foreach (var c in _mgr.GetAllCodes())
                {
                    string typeStr = c.Type == "Percent" ? c.Value + "%" : c.Value.ToString("N0") + " ت";
                    string usesStr = c.MaxUses == 0 ? $"{c.CurrentUses} / ∞" : $"{c.CurrentUses} / {c.MaxUses}";
                    string expStr = string.IsNullOrEmpty(c.Expiry) ? "-" : (DateTime.TryParse(c.Expiry, out DateTime d) ? d.ToLocalTime().ToString("yyyy/MM/dd") : "-");
                    dgv.Rows.Add(c.Id, c.Code, typeStr, c.Value, usesStr, expStr, c.IsActive ? "✅ بله" : "❌ خیر", c.Description);
                }
            }
            catch { }
        }
    }
}
