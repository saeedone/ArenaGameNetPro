using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// File synchronization window (HandyCafe-style). Lets the operator
    /// define sync tasks (host + local path + info), analyze / start / stop
    /// them, and watch a log panel of sync events. The actual file transfer
    /// is delegated to the existing UpdateDistributor + ClientCommunicator.
    /// </summary>
    public class SyncForm : Form
    {
        private ClientCommunicator _communicator;
        private UpdateDistributor _distributor;

        private DataGridView _dgv;
        private TextBox _txtLocalPath, _txtHost, _txtInfo;
        private Button _btnBrowse, _btnAdd, _btnDelete, _btnSyncNow, _btnAnalyze, _btnStop;
        private TextBox _txtLog;
        private Label _lblStatus;
        // FIX DEAD-CONFIG-6: needs to be a field (not a constructor-local
        // var) so ApplySyncOptions() can toggle its visibility for
        // OptionsForm's "نمایش لاگ همگام‌سازی" (ShowSyncLog).
        private Label _lblLog;

        private readonly List<SyncTask> _tasks = new List<SyncTask>();
        private int _nextId = 1;

        public SyncForm() : this(null) { }

        public SyncForm(ClientCommunicator communicator)
        {
            _communicator = communicator;
            _distributor = new UpdateDistributor();

            this.Text = "همگام‌سازی - GameNet";
            this.Size = new Size(940, 660);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            int y = 12;

            // ---- Inputs ----
            var lblHost = new Label { Text = "میزبان (Host):", Location = new Point(20, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtHost = new TextBox { Location = new Point(110, y), Size = new Size(150, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblInfo = new Label { Text = "اطلاعات:", Location = new Point(280, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtInfo = new TextBox { Location = new Point(340, y), Size = new Size(200, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblPath = new Label { Text = "مسیر محلی:", Location = new Point(560, y + 4), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtLocalPath = new TextBox { Location = new Point(640, y), Size = new Size(180, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F), ReadOnly = true };
            _btnBrowse = new Button
            {
                Text = "…", Location = new Point(830, y - 1), Size = new Size(70, 32),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnBrowse.Click += (s, e) =>
            {
                using (var fbd = new FolderBrowserDialog())
                {
                    if (fbd.ShowDialog(this) == DialogResult.OK)
                        _txtLocalPath.Text = fbd.SelectedPath;
                }
            };

            y += 36;

            _btnAdd = new Button
            {
                Text = "➕ افزودن", Location = new Point(20, y), Size = new Size(120, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnAdd.Click += (s, e) => AddTask();

            _btnDelete = new Button
            {
                Text = "❌ حذف", Location = new Point(150, y), Size = new Size(120, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            _btnDelete.Click += (s, e) => DeleteTask();

            _btnSyncNow = new Button
            {
                Text = "🔄 Sync Now", Location = new Point(280, y), Size = new Size(130, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnSyncNow.Click += (s, e) => SyncNow();

            _btnAnalyze = new Button
            {
                Text = "🔍 Analyze", Location = new Point(420, y), Size = new Size(120, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            _btnAnalyze.Click += (s, e) => Analyze();

            _btnStop = new Button
            {
                Text = "⏹ Stop", Location = new Point(550, y), Size = new Size(110, 34),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            _btnStop.Click += (s, e) => StopAll();

            _lblStatus = new Label
            {
                Text = "وضعیت: آماده", Location = new Point(680, y + 6), AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50)
            };

            y += 44;

            // ---- Tasks grid ----
            _dgv = new DataGridView
            {
                Location = new Point(20, y),
                Size = new Size(880, 280),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 24 },
            };
            _dgv.Columns.Add("colHost", "میزبان");
            _dgv.Columns.Add("colInfo", "اطلاعات");
            _dgv.Columns.Add("colStatus", "وضعیت");
            _dgv.Columns.Add("colStarted", "شروع");
            _dgv.Columns.Add("colEta", "تخمین زمان");

            y += 290;

            // ---- Log panel ----
            var lblLog = new Label { Text = "📋 لاگ همگام‌سازی:", Location = new Point(20, y), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180) };
            _lblLog = lblLog;
            y += 24;
            _txtLog = new TextBox
            {
                Location = new Point(20, y),
                Size = new Size(880, 140),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Consolas", 9F),
            };

            Controls.AddRange(new Control[] {
                lblHost, _txtHost, lblInfo, _txtInfo, lblPath, _txtLocalPath, _btnBrowse,
                _btnAdd, _btnDelete, _btnSyncNow, _btnAnalyze, _btnStop, _lblStatus,
                _dgv,
                lblLog, _txtLog
            });

            Log(" آماده. مسیر محلی: " + _distributor.GetUpdatesDir());

            // FIX DEAD-CONFIG-6: load previously-defined tasks (used to be
            // lost every time this window closed) and apply the
            // SyncEnabled/ShowSyncLog options.
            LoadPersistedTasks();
            ApplySyncOptions();
        }

        /// <summary>
        /// FIX DEAD-CONFIG-6: reads sync_tasks.json (via SyncTaskStore) into
        /// _tasks so previously-defined tasks survive closing this window,
        /// and are available to SyncScheduler for automatic runs even when
        /// this form isn't open at all.
        /// </summary>
        private void LoadPersistedTasks()
        {
            try
            {
                var records = SyncTaskStore.Load();
                _tasks.Clear();
                foreach (var r in records)
                {
                    _tasks.Add(new SyncTask { Id = r.Id, Host = r.Host, Info = r.Info, LocalPath = r.LocalPath, Status = "آماده", StartedAt = null, EstimatedTime = "—" });
                    if (r.Id >= _nextId) _nextId = r.Id + 1;
                }
                RefreshGrid();
            }
            catch (Exception ex) { Log("خطا در بارگذاری تسک‌های ذخیره‌شده: " + ex.Message); }
        }

        private void SaveTasksToStore()
        {
            try
            {
                var records = new List<SyncTaskStore.SyncTaskRecord>();
                foreach (var t in _tasks)
                    records.Add(new SyncTaskStore.SyncTaskRecord { Id = t.Id, Host = t.Host, Info = t.Info, LocalPath = t.LocalPath });
                SyncTaskStore.Save(records);
            }
            catch (Exception ex) { Log("خطا در ذخیره تسک‌ها: " + ex.Message); }
        }

        /// <summary>
        /// FIX DEAD-CONFIG-6: applies OptionsForm's SyncEnabled (master
        /// on/off — disables manual sync too when off, since the operator
        /// explicitly turned the whole feature off) and ShowSyncLog
        /// (log panel visibility), which previously had no effect anywhere.
        /// </summary>
        private void ApplySyncOptions()
        {
            try
            {
                var opts = OptionsForm.LoadStaticOptions();
                bool enabled = opts?.SyncEnabled ?? true;
                _btnSyncNow.Enabled = enabled;
                _btnAdd.Enabled = enabled;
                if (!enabled)
                {
                    _lblStatus.Text = "وضعیت: همگام‌سازی غیرفعال است (در تنظیمات فعال کنید)";
                    _lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
                }
                bool showLog = opts?.ShowSyncLog ?? true;
                _txtLog.Visible = showLog;
                _lblLog.Visible = showLog;
            }
            catch (Exception ex) { Log("خطا در اعمال تنظیمات همگام‌سازی: " + ex.Message); }
        }

        private void Log(string msg)
        {
            if (InvokeRequired) { this.BeginInvoke((Action)(() => Log(msg))); return; }
            _txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
        }

        private void AddTask()
        {
            string host = _txtHost.Text.Trim();
            string info = _txtInfo.Text.Trim();
            string path = _txtLocalPath.Text.Trim();
            if (string.IsNullOrEmpty(host))
            {
                MessageBox.Show("میزبان را وارد کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var t = new SyncTask
            {
                Id = _nextId++,
                Host = host,
                Info = info,
                LocalPath = path,
                Status = "آماده",
                StartedAt = null,
                EstimatedTime = "—"
            };
            _tasks.Add(t);
            RefreshGrid();
            SaveTasksToStore();
            Log($"افزودن تسک #{t.Id}: host={host}, path={path}");
        }

        private void DeleteTask()
        {
            if (_dgv.SelectedRows.Count == 0) return;
            int idx = _dgv.SelectedRows[0].Index;
            if (idx < 0 || idx >= _tasks.Count) return;
            var t = _tasks[idx];
            _tasks.RemoveAt(idx);
            RefreshGrid();
            SaveTasksToStore();
            Log($"حذف تسک #{t.Id}");
        }

        private void SyncNow()
        {
            var syncOpts = OptionsForm.LoadStaticOptions();
            if (syncOpts != null && !syncOpts.SyncEnabled)
            {
                Log("همگام‌سازی در تنظیمات غیرفعال است.");
                MessageBox.Show("همگام‌سازی غیرفعال است. آن را از تنظیمات کلی فعال کنید.", "غیرفعال", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (_communicator == null)
            {
                Log("ارتباط با کلاینت برقرار نیست — همگام‌سازی لغو شد.");
                MessageBox.Show("ارتباط با کلاینت برقرار نیست.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int count = _communicator.ConnectedClientCount;
            Log($"شروع همگام‌سازی با {count} کلاینت متصل…");
            _lblStatus.Text = "وضعیت: در حال همگام‌سازی…";
            _lblStatus.ForeColor = Color.FromArgb(180, 140, 20);

            // Run distribution in background.
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    foreach (var t in _tasks)
                    {
                        t.Status = "در حال اجرا";
                        t.StartedAt = DateTime.Now;
                        this.BeginInvoke((Action)(() => RefreshGrid()));
                        Log($"تسک #{t.Id} ({t.Host}): شروع توزیع…");

                        // If a local path was specified and contains files,
                        // we count them; otherwise we fall back to the
                        // standard update-distributor flow.
                        int fileCount = 0;
                        try
                        {
                            if (!string.IsNullOrEmpty(t.LocalPath) && Directory.Exists(t.LocalPath))
                                fileCount = Directory.GetFiles(t.LocalPath, "*", SearchOption.AllDirectories).Length;
                        }
                        catch { }

                        if (fileCount > 0)
                            Log($"تسک #{t.Id}: {fileCount} فایل در مسیر محلی یافت شد.");
                        else
                            Log($"تسک #{t.Id}: مسیر محلی خالی است — استفاده از پوشه updates.");

                        _communicator.OfferUpdateToAll();

                        t.Status = "تکمیل شد";
                        t.EstimatedTime = (DateTime.Now - t.StartedAt.Value).TotalSeconds.ToString("0.0") + "s";
                        this.BeginInvoke((Action)(() => RefreshGrid()));
                        Log($"تسک #{t.Id}: توزیع آپدیت به همه کلاینت‌ها ارسال شد.");
                    }
                    this.BeginInvoke((Action)(() =>
                    {
                        _lblStatus.Text = "وضعیت: تکمیل شد";
                        _lblStatus.ForeColor = Color.FromArgb(20, 130, 50);
                    }));
                }
                catch (Exception ex)
                {
                    Log("خطای همگام‌سازی: " + ex.Message);
                    this.BeginInvoke((Action)(() =>
                    {
                        _lblStatus.Text = "وضعیت: خطا";
                        _lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
                    }));
                }
            });
        }

        private void Analyze()
        {
            Log("🔍 تحلیل تسک‌ها:");
            foreach (var t in _tasks)
            {
                int files = 0;
                long size = 0;
                try
                {
                    if (!string.IsNullOrEmpty(t.LocalPath) && Directory.Exists(t.LocalPath))
                    {
                        var fis = new DirectoryInfo(t.LocalPath).GetFiles("*", SearchOption.AllDirectories);
                        files = fis.Length;
                        foreach (var fi in fis) size += fi.Length;
                    }
                }
                catch { }
                Log($"  • #{t.Id} host={t.Host}: {files} فایل، {size / 1024.0 / 1024.0:F1} MB");
            }
            int conns = _communicator?.ConnectedClientCount ?? 0;
            Log($"کلاینت‌های متصل: {conns}");
        }

        private void StopAll()
        {
            foreach (var t in _tasks)
            {
                if (t.Status == "در حال اجرا")
                {
                    t.Status = "متوقف شد";
                    Log($"تسک #{t.Id}: متوقف شد.");
                }
            }
            RefreshGrid();
            _lblStatus.Text = "وضعیت: متوقف شد";
            _lblStatus.ForeColor = Color.FromArgb(200, 30, 60);
        }

        private void RefreshGrid()
        {
            _dgv.Rows.Clear();
            foreach (var t in _tasks)
            {
                _dgv.Rows.Add(t.Host, t.Info, t.Status, t.StartedAt?.ToString("HH:mm:ss") ?? "—", t.EstimatedTime);
            }
        }

        private class SyncTask
        {
            public int Id;
            public string Host;
            public string Info;
            public string LocalPath;
            public string Status;
            public DateTime? StartedAt;
            public string EstimatedTime;
        }
    }
}
