using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class OperatorLoginForm : Form
    {
        private Operator _currentOperator;
        public Operator CurrentOperator => _currentOperator;

        private TextBox txtUsername, txtPassword;
        private Button btnLogin, btnCancel;
        private LinkLabel linkForgot;

        public OperatorLoginForm()
        {
            // REDESIGN: rebuilt to match the requested login-dialog layout —
            // title, username field, password field, a "forgot password"
            // link, and Login/Cancel buttons with check/X icons side by
            // side. Built with this app's own icons and colors (not traced
            // from any other product's artwork) — same structure, original
            // visual assets. This supersedes an earlier fix that had
            // removed the forgot-password link; the current explicit
            // request calls for it, so it's back.
            this.Text = "ورود اپراتور";
            this.Size = new Size(420, 320);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;

            var lblTitle = new Label
            {
                Text = "🔐 ورود اپراتور",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(60, 60, 60),
                Location = new Point(110, 18),
                AutoSize = true,
                BackColor = Color.Transparent,
            };

            var lblUsername = new Label
            {
                Text = "نام کاربری:",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(60, 60, 60),
                Location = new Point(35, 75),
                AutoSize = true,
                BackColor = Color.Transparent,
            };

            txtUsername = new TextBox
            {
                Location = new Point(35, 100),
                Size = new Size(300, 27),
                Font = new Font("Segoe UI", 11F),
                BackColor = Color.White,
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            // Accent underline beneath the username field.
            var underline1 = new Panel { Location = new Point(35, 128), Size = new Size(300, 3), BackColor = Color.FromArgb(137, 180, 250) };
            // Small account/lock icon beside the fields.
            var lblIcon = new Label { Text = "🔒", Font = new Font("Segoe UI", 22F), Location = new Point(345, 95), AutoSize = true, BackColor = Color.Transparent };

            var lblPassword = new Label
            {
                Text = "رمز عبور:",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(60, 60, 60),
                Location = new Point(35, 150),
                AutoSize = true,
                BackColor = Color.Transparent,
            };

            txtPassword = new TextBox
            {
                Location = new Point(35, 175),
                Size = new Size(300, 27),
                Font = new Font("Segoe UI", 11F),
                UseSystemPasswordChar = true,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };

            linkForgot = new LinkLabel
            {
                Text = "رمز عبور خود را فراموش کرده‌اید؟",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                LinkColor = Color.FromArgb(200, 60, 70),
                ActiveLinkColor = Color.FromArgb(230, 100, 90),
                VisitedLinkColor = Color.FromArgb(200, 60, 70),
                LinkBehavior = LinkBehavior.HoverUnderline,
                AutoSize = true,
                BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleCenter,
            };
            linkForgot.Location = new Point((this.ClientSize.Width - linkForgot.PreferredWidth) / 2, 212);
            linkForgot.LinkClicked += (s, e) =>
                MessageBox.Show(this, "برای بازیابی رمز عبور با مدیر سیستم تماس بگیرید.", "بازیابی رمز عبور", MessageBoxButtons.OK, MessageBoxIcon.Information);

            btnLogin = new Button
            {
                Text = "✔  ورود",
                Location = new Point(35, 245),
                Size = new Size(145, 40),
                BackColor = Color.FromArgb(166, 227, 161),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            btnLogin.FlatAppearance.BorderSize = 0;

            btnCancel = new Button
            {
                Text = "✖  انصراف",
                Location = new Point(190, 245),
                Size = new Size(145, 40),
                BackColor = Color.FromArgb(243, 139, 168),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            btnLogin.Click += DoLogin;
            btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            txtPassword.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) DoLogin(s, e); };
            txtUsername.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { txtPassword.Focus(); e.SuppressKeyPress = true; } };

            Controls.AddRange(new Control[] { lblTitle, lblUsername, txtUsername, underline1, lblIcon, lblPassword, txtPassword, linkForgot, btnLogin, btnCancel });
            this.AcceptButton = btnLogin;
            this.CancelButton = btnCancel;
        }

        private void DoLogin(object s, EventArgs e)
        {
            try
            {
                var op = new OperatorManager().Authenticate(txtUsername.Text.Trim(), txtPassword.Text);
                var tfa = new TwoFactorAuth();
                if (tfa.Is2FAEnabled(op.Id))
                {
                    string code = PromptFor2FACode(op);
                    if (string.IsNullOrEmpty(code)) { txtPassword.Clear(); return; }
                    if (!tfa.ValidateOperator2FA(op.Id, code))
                    {
                        MessageBox.Show("کد احراز هویت دو مرحله‌ای نامعتبر است.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AuditLog.Log("OperatorLogin", $"2FA failed for {op.Username}");
                        txtPassword.Clear(); return;
                    }
                    AuditLog.Log("OperatorLogin", $"2FA succeeded for {op.Username}");
                }
                _currentOperator = op;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (UnauthorizedAccessException ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); txtPassword.Clear(); }
            catch (Exception ex) { MessageBox.Show(this, "خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); try { txtPassword.Clear(); } catch { } }
        }

        private string PromptFor2FACode(Operator op)
        {
            string code = null;
            using (var dlg = new Form())
            {
                dlg.Text = "احراز هویت دو مرحله‌ای";
                dlg.Size = new Size(380, 220);
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false; dlg.MinimizeBox = false;
                dlg.BackColor = Color.FromArgb(240, 240, 240);
                dlg.ForeColor = Color.FromArgb(40, 40, 40);
                dlg.RightToLeft = RightToLeft.Yes;

                var lbl = new Label { Text = "کد ۶ رقمی Authenticator را وارد کنید:", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(60, 60, 60), Location = new Point(20, 20), AutoSize = true };
                var txt = new TextBox { Location = new Point(20, 60), Size = new Size(320, 35), Font = new Font("Consolas", 16F), MaxLength = 6, BackColor = Color.White, ForeColor = Color.FromArgb(40, 40, 40) };
                var btnOk = new Button { Text = "✅ تأیید", Location = new Point(20, 115), Size = new Size(155, 38), BackColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(40, 40, 40), DialogResult = DialogResult.OK };
                var btnCancel2 = new Button { Text = "❌ انصراف", Location = new Point(185, 115), Size = new Size(155, 38), BackColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(40, 40, 40), DialogResult = DialogResult.Cancel };

                txt.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { dlg.DialogResult = DialogResult.OK; dlg.Close(); } };

                dlg.Controls.AddRange(new Control[] { lbl, txt, btnOk, btnCancel2 });
                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCancel2;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                    code = txt.Text.Trim();
            }
            return code;
        }
    }
}
