using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Round 11: the simple reservation window of the monitoring right-click menu.
    /// Three choices only: customer name, start (today / tomorrow + time) and a
    /// duration button. Phone is optional. No account and no date-picker needed.
    /// </summary>
    internal sealed class QuickReservationDialog : Form
    {
        private readonly string _station;
        private readonly TextBox _txtName, _txtPhone;
        private readonly ComboBox _cboDay;
        private readonly DateTimePicker _dtpTime;
        private readonly Label _lblSummary;
        private readonly Button[] _durButtons;
        private int _minutes = 60;

        private static readonly int[] Durations = { 30, 60, 90, 120, 180 };
        private static readonly string[] DurationText = { "۳۰ دقیقه", "۱ ساعت", "۱٫۵ ساعت", "۲ ساعت", "۳ ساعت" };

        public DateTime StartTime { get; private set; }
        public DateTime EndTime { get; private set; }
        public string CustomerName { get; private set; }

        public QuickReservationDialog(string stationName)
        {
            _station = stationName;
            Text = "📅 رزرو " + stationName;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(420, 330);
            BackColor = Color.White;
            ForeColor = Color.FromArgb(40, 40, 40);
            RightToLeft = RightToLeft.Yes;
            RightToLeftLayout = true;
            Font = new Font("Segoe UI", 10F);

            var lblTitle = new Label { Text = "📅 رزرو سیستم " + stationName, Location = new Point(16, 12), AutoSize = true, Font = new Font("Segoe UI", 13F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180) };

            var lblName = new Label { Text = "نام مشتری:", Location = new Point(16, 56), AutoSize = true };
            _txtName = new TextBox { Location = new Point(130, 52), Size = new Size(272, 28), BackColor = Color.White };
            var lblPhone = new Label { Text = "تلفن (اختیاری):", Location = new Point(16, 92), AutoSize = true };
            _txtPhone = new TextBox { Location = new Point(130, 88), Size = new Size(272, 28), BackColor = Color.White };

            var lblStart = new Label { Text = "شروع:", Location = new Point(16, 130), AutoSize = true };
            _cboDay = new ComboBox { Location = new Point(130, 126), Size = new Size(110, 28), DropDownStyle = ComboBoxStyle.DropDownList };
            _cboDay.Items.AddRange(new object[] { "امروز", "فردا" });
            _cboDay.SelectedIndex = 0;
            _dtpTime = new DateTimePicker { Location = new Point(250, 126), Size = new Size(152, 28), Format = DateTimePickerFormat.Custom, CustomFormat = "HH:mm", ShowUpDown = true, RightToLeftLayout = false };
            // default: the next half hour
            var now = DateTime.Now;
            var next = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute < 30 ? 30 : 0, 0);
            if (now.Minute >= 30) next = next.AddHours(1);
            _dtpTime.Value = next;

            var lblDur = new Label { Text = "مدت:", Location = new Point(16, 172), AutoSize = true };
            _durButtons = new Button[Durations.Length];
            int x = 130;
            for (int i = 0; i < Durations.Length; i++)
            {
                int m = Durations[i];
                var b = new Button { Text = DurationText[i], Location = new Point(x, 166), Size = new Size(52, 34), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5F), Tag = m };
                b.Click += (s, e) => { _minutes = m; UpdateUi(); };
                _durButtons[i] = b;
                x += 55;
            }

            _lblSummary = new Label { Location = new Point(16, 214), Size = new Size(388, 48), ForeColor = Color.FromArgb(20, 120, 60), Font = new Font("Segoe UI", 10F, FontStyle.Bold) };

            var btnOk = new Button { Text = "✅ ثبت رزرو", Location = new Point(16, 274), Size = new Size(190, 40), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(46, 160, 67), ForeColor = Color.White, Font = new Font("Segoe UI", 10.5F, FontStyle.Bold) };
            var btnCancel = new Button { Text = "انصراف", Location = new Point(214, 274), Size = new Size(190, 40), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(230, 230, 235), DialogResult = DialogResult.Cancel };
            btnOk.FlatAppearance.BorderSize = 0; btnCancel.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => Save();

            _cboDay.SelectedIndexChanged += (s, e) => UpdateUi();
            _dtpTime.ValueChanged += (s, e) => UpdateUi();

            Controls.AddRange(new Control[] { lblTitle, lblName, _txtName, lblPhone, _txtPhone, lblStart, _cboDay, _dtpTime, lblDur, _lblSummary, btnOk, btnCancel });
            Controls.AddRange(_durButtons);
            AcceptButton = btnOk;
            CancelButton = btnCancel;
            UpdateUi();
        }

        private DateTime ComputeStart()
        {
            var d = DateTime.Today.AddDays(_cboDay.SelectedIndex == 1 ? 1 : 0);
            return d.AddHours(_dtpTime.Value.Hour).AddMinutes(_dtpTime.Value.Minute);
        }

        private void UpdateUi()
        {
            foreach (var b in _durButtons)
            {
                bool on = (int)b.Tag == _minutes;
                b.BackColor = on ? Color.FromArgb(30, 80, 180) : Color.FromArgb(235, 238, 245);
                b.ForeColor = on ? Color.White : Color.FromArgb(40, 40, 40);
            }
            var st = ComputeStart();
            var en = st.AddMinutes(_minutes);
            _lblSummary.Text = (_cboDay.SelectedIndex == 1 ? "فردا" : "امروز") + " از " + st.ToString("HH:mm") + " تا " + en.ToString("HH:mm")
                + (en <= DateTime.Now ? "\n⚠️ این زمان گذشته است" : "");
        }

        private void Save()
        {
            var st = ComputeStart();
            var en = st.AddMinutes(_minutes);
            try
            {
                new ReservationManager().CreateQuick(_txtName.Text, _station, st, en, _txtPhone.Text);
                CustomerName = _txtName.Text.Trim();
                StartTime = st; EndTime = en;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "رزرو ثبت نشد", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
