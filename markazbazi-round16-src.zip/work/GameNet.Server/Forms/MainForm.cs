using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;
using GameNet.Shared.Diagnostics;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Main server form with a tabbed interface. Every management module is
    /// embedded as a child form (TopLevel=false) inside its own tab page, so
    /// the operator has everything in one window — no separate floating
    /// windows. Tabs are created lazily (on first click) to keep startup fast.
    /// </summary>
    public class MainForm : Form
    {
        private ClientCommunicator _communicator;
        private MobileApiController _mobileApi;
        private WebSocketServer _webSocket;
        private SmartNotification _notifications;
        private LocalizationManager _localization;
        private RateLimiter _rateLimiter;
        private AutoRecharge _autoRecharge;
        private Timer _autoRechargeTimer;
        private Timer _statusTimer;
        // BUG FIX: removed the whole session-lock (idle-timeout) feature per
        // request — it locked the entire server/admin app after 15 minutes
        // of inactivity, requiring the operator to re-enter their password.
        // It was already effectively dead (Tick handler and Start() were
        // both commented out), but the supporting fields, CheckIdleTimeout,
        // the activity-tracking message filter, and the whole
        // SessionLockForm class were all still present. Removed all of it.
        // FIX AUDIT-FIX-FINAL Bug C: clockTimer was a local variable in
        // BuildStatusStrip and was never disposed on form close, leaking
        // a 1Hz timer that kept firing Tick handlers (which swallowed
        // ObjectDisposedException silently). Promoted to a field so
        // OnFormClosing can stop+dispose it.
        private Timer _clockTimer;
        // FIX-MONITOR-ADD5 TASK B2: auto-backup timer. Every 6 hours, copies
        // gamenet.db to a backup/ folder next to the server exe, keeping the
        // last 10 backups. Stops + disposes in OnFormClosing.
        private Timer _backupTimer;

        // FIX DEAD-CONFIG-1: backs OptionsForm's "نمایش آیکون در system tray"
        // checkbox, which previously had no effect at all.
        private bool _showTrayIcon;
        private NotifyIcon _trayIcon;
        // FIX DEAD-CONFIG-6: backs ScheduledSync/ScheduledSyncMinutes.
        private Core.SyncScheduler _syncScheduler;
        // FIX LONGTERM-1: prunes log-type tables so they don't grow
        // unbounded over long-term (1+ year) continuous operation.
        private Core.DatabaseMaintenanceScheduler _dbMaintenance;

        private Operator _currentOperator;
        private readonly OperatorManager _operatorManager = new OperatorManager();

        // Tabbed UI
        private TabControl _tabs;
        private Label _lblTitle;
        private Label _lblStatus;
        private Button _btnLogin;
        private ComboBox _cboLanguage;
        private Label _lblActiveSystem;
        private Panel _topBar;
        // FIX AUDIT-FIX-POSTUPDATE Bug T2: btnTheme was a local variable in
        // BuildTopBar, so its Text could not be re-synced after ThemeManager.
        // LoadTheme() loads the persisted theme from theme.json. The button
        // text (🌙/☀️) was set at construction time using the DEFAULT theme
        // (Dark), so if theme.json said "light", the button showed 🌙 even
        // though the form was themed light. Promoted to a field so the ctor
        // can update its Text after LoadTheme.
        private Button _btnTheme;

        // Left sidebar (Session Control Panel — matches reference image)
        private Panel _leftSidebar;
        private Label _lblStartTime;
        private Label _lblEndTime;
        private Label _lblUsedTime;
        private Label _lblRemainingTime;
        private Label _lblPrice;
        private NumericUpDown _numCustomTime;
        private CheckBox _chkPlayAndPay;
        private Label _lblSelectedStation;

        // Bottom panel (Camera preview + Activity Log — matches reference image)
        private Panel _bottomPanel;
        private Panel _cameraPreview;
        private Label _cameraLabel;
        private DataGridView _activityGrid;

        // Toolbars (referenced by the View menu toggles)
        private Panel _primaryToolbar;
        private Panel _secondaryToolbar;

        // Center content container — holds _leftSidebar (Left) + _tabs (Fill).
        // This is the KEY fix: by putting the sidebar + tabs inside a single
        // Fill container, the sidebar only spans the center area's height (not
        // the full form height including the top toolbar). Without this, the
        // sidebar overlapped the top toolbars, which is what caused the
        // "tabs stacking below each other" visual bug.
        private Panel _centerContainer;

        // Status strip (bottom — matches reference image)
        private StatusStrip _statusStrip;
        private ToolStripStatusLabel _ssRole;
        private ToolStripStatusLabel _ssClients;
        private ToolStripStatusLabel _ssOnline;
        private ToolStripStatusLabel _ssIdle;
        private ToolStripStatusLabel _ssUnreachable;
        private ToolStripStatusLabel _ssDateTime;

        // Currently selected station (for the left sidebar live session view)
        private string _selectedStation;

        // References to the 8 primary toolbar buttons + their definitions, so
        // ApplyLanguage can update the labels when the operator switches FA/EN/AR.
        private readonly List<Button> _primaryButtons = new List<Button>();
        private readonly List<(string Key, string Icon, string En, string Fa, string Ar, Color Color)> _primaryDefs = new List<(string, string, string, string, string, Color)>();

        // Cache of already-created embedded forms so switching back to a tab
        // is instant (no re-creation).
        private readonly Dictionary<string, Form> _embeddedForms = new Dictionary<string, Form>();

        // Tab definitions: (key, title, category, permission, factory)
        // Organized into 8 categories. The sidebar shows categories as
        // collapsible groups; clicking a group expands its tabs.
        private readonly List<TabDef> _tabDefs = new List<TabDef>
        {
            // === نظارت ===
            new TabDef("dashboard",  "📊 داشبورد",        "نظارت", OperatorPermission.ViewClients,         () => null),
            new TabDef("clients",    "📡 کلاینت‌ها",       "نظارت", OperatorPermission.ViewClients,         () => null),
            new TabDef("ipmonitor",  "🌐 مانیتور IP",     "نظارت", OperatorPermission.ViewClients,         () => null),
            new TabDef("serverstatus","📊 وضعیت سرور",     "نظارت", OperatorPermission.ViewClients,         () => null),

            // === مدیریت ===
            new TabDef("users",      "👥 کاربران",         "مدیریت", OperatorPermission.ManageUsers,         () => null),
            new TabDef("pricing",    "💰 تعرفه‌ها",        "مدیریت", OperatorPermission.ManagePricing,       () => null),
            new TabDef("stations",   "💻 ایستگاه‌ها",      "مدیریت", OperatorPermission.ManageGames,         () => null),
            new TabDef("equipment",  "🔧 تجهیزات",         "مدیریت", OperatorPermission.ManageGames,         () => null),
            new TabDef("consoles",   "🎮 کنسول PS4/PS5",  "مدیریت", OperatorPermission.ManageGames,         () => null),

            // === مالی ===
            new TabDef("tickets",    "🎫 تیکت‌ها",         "مالی", OperatorPermission.ManageTickets,       () => null),
            new TabDef("packages",   "📦 بسته‌ها",         "مالی", OperatorPermission.ManagePackages,      () => null),
            new TabDef("debt",       "💳 بدهی",            "مالی", OperatorPermission.ManageDebts,         () => null),
            new TabDef("print",      "🖨️ پرینت",          "مالی", OperatorPermission.ManagePrint,         () => null),
            new TabDef("payment",    "💳 درگاه پرداخت",   "مالی", OperatorPermission.ManagePayments,      () => null),
            new TabDef("orders",     "🥤 بوفه/کافه‌تریا",  "مالی", OperatorPermission.ManageUsers,         () => null),
            new TabDef("cash",       "💵 صندوق",          "مالی", OperatorPermission.ViewReports,         () => null),

            // === تایمرها و میانبرها و لاگ و همگام‌سازی ===
            new TabDef("timers",     "⏱️ تایمرها",        "ابزار", OperatorPermission.ManageUsers,         () => null),
            new TabDef("shortcuts",  "⭐ میانبرها",        "ابزار", OperatorPermission.ManageUsers,         () => null),
            new TabDef("syslog",     "📋 گزارش سیستم",    "ابزار", OperatorPermission.ViewReports,         () => null),
            new TabDef("sync",       "🔄 همگام‌سازی",      "ابزار", OperatorPermission.ManageBackups,       () => null),
            new TabDef("schedshutdown","⏰ خاموشی زمان‌بندی","ابزار",OperatorPermission.ManageSecurity,     () => null),

            // === مشتری ===
            new TabDef("tiers",      "🏅 عضویت",           "مشتری", OperatorPermission.ManageTiers,         () => null),
            new TabDef("loyalty",    "🏆 وفاداری + تخفیف", "مشتری", OperatorPermission.ManageTiers,         () => null),
            new TabDef("vip",        "💎 VIP",             "مشتری", OperatorPermission.ManageTiers,         () => null),
            new TabDef("queue",      "🎟️ صف انتظار",       "مشتری", OperatorPermission.ManageUsers,         () => null),

            // === ارتباط ===
            new TabDef("chat",       "💬 چت",             "ارتباط", OperatorPermission.ChatAccess,          () => null),
            new TabDef("announce",   "📢 اطلاعیه‌ها",      "ارتباط", OperatorPermission.ManageAnnouncements, () => null),

            // === گزارش ===
            new TabDef("reports",    "📈 گزارش‌ها",        "گزارش", OperatorPermission.ViewReports,         () => null),
            new TabDef("advreports", "📊 گزارش پیشرفته",   "گزارش", OperatorPermission.ViewReports,         () => null),
            new TabDef("revenue",    "💰 نمودار درآمد",     "گزارش", OperatorPermission.ViewReports,         () => null),
            // Round 14: what happened while the owner was away.
            new TabDef("journal",    "🕵️ وقتی نبودم",      "گزارش", OperatorPermission.ViewReports,         () => null),

            // === مسابقات ===
            new TabDef("tournaments", "🏆 مسابقات",        "سیستم", OperatorPermission.ManageUsers,         () => null),

            // === امنیت ===
            new TabDef("security",   "🛡️ امنیت",          "امنیت", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("secdash",    "🔐 داشبورد امنیت",  "امنیت", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("licenses",   "🔑 لایسنس",          "امنیت", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("secalerts",  "🚨 هشدارها",        "امنیت", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("winharden",  "🪟 سخت‌سازی ویندوز", "امنیت", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("restrictions", "🚫 محدودیت‌ها",     "امنیت", OperatorPermission.ManageSecurity,      () => null),

            // === سیستم ===
            new TabDef("backup",     "💾 پشتیبان",         "سیستم", OperatorPermission.ManageBackups,       () => null),
            new TabDef("updates",    "📦 آپدیت + انتقال", "سیستم", OperatorPermission.ManageBackups,       () => null),
            new TabDef("api",        "📱 API",            "سیستم", OperatorPermission.ApiAccess,           () => null),
            new TabDef("theme",      "🎨 ظاهر",           "سیستم", OperatorPermission.ManageThemes,        () => null),
            new TabDef("smartprice", "🤖 قیمت هوشمند",    "سیستم", OperatorPermission.SmartPricing,        () => null),
            new TabDef("branches",   "🏪 شعب",            "سیستم", OperatorPermission.ManageBranches,      () => null),
            new TabDef("features",   "🎛️ قابلیت کلاینت",  "سیستم", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("extensions", "⚙️ تنظیمات+افزونه",  "سیستم", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("clientoptions", "💻 تنظیمات کلاینت", "سیستم", OperatorPermission.ManageSecurity,   () => null),
            // Round 15: why stations do or do not appear.
            new TabDef("conndoctor", "🩺 عیب‌یابی اتصال", "سیستم", OperatorPermission.ViewClients,       () => null),
            // === PRO ماژول‌های حرفه‌ای ===
            new TabDef("staff",       "👤 پرسنل",           "PRO", OperatorPermission.ManageUsers,         () => null),
            new TabDef("discount",    "🎟️ تخفیف",           "PRO", OperatorPermission.ManagePricing,       () => null),
            new TabDef("analytics",   "📊 تحلیل",           "PRO", OperatorPermission.ViewReports,         () => null),
            new TabDef("aiprice",     "🤖 قیمت هوشمند",     "PRO", OperatorPermission.ManagePricing,       () => null),
            new TabDef("livedash",    "📊 داشبورد زنده",    "PRO", OperatorPermission.ViewClients,         () => null),
            new TabDef("advloyalty",  "🏆 وفاداری+",        "PRO", OperatorPermission.ManageTiers,         () => null),
            new TabDef("smartloyalty","🤝 وفاداری هوشمند",  "PRO", OperatorPermission.ManageTiers,         () => null),
            new TabDef("aianalytics", "📈 تحلیل AI",        "PRO", OperatorPermission.ViewReports,         () => null),
            new TabDef("gamemgr",     "🎮 مدیریت بازی‌ها",  "PRO", OperatorPermission.ManageGames,         () => null),
            new TabDef("tournamentpro","🏆 مسابقات+",        "PRO", OperatorPermission.ManageUsers,         () => null),
            new TabDef("advsecurity", "🔒 امنیت پیشرفته",   "PRO", OperatorPermission.ManageSecurity,      () => null),
            new TabDef("mobileapi",   "📱 API موبایل",      "PRO", OperatorPermission.ApiAccess,           () => null),
        };

        public MainForm() : this(null) { }

        public MainForm(Operator authenticatedOperator)
        {
            _localization = new LocalizationManager();
            _localization.LoadLanguagePreference();

            this.Text = "مرکز بازی - مدیریت گیم‌نت";
            GameNet.Shared.AppIcon.Apply(this); // round 11: 3D program icon
            // Larger default size so all panels (menubar + topbar + primary toolbar
            // + secondary toolbar + center[sidebar+tabs] + bottom panel + status
            // strip) fit without clipping. 1600x1000 gives enough vertical space
            // for the ~700px of stacked top/bottom chrome plus ~300px+ for the
            // center content. Also start maximized so the user sees everything
            // immediately on launch.
            this.Size = new Size(1600, 1000);
            this.MinimumSize = new Size(1280, 800);
            // Start maximized — ensures all toolbars and panels are visible
            // without manual resizing, regardless of the user's screen
            // resolution. The operator can still restore down to 1280x800 min.
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            // Glassmorphism: use a slightly translucent dark background with
            // a subtle blue tint. WinForms doesn't support true blur, but we
            // emulate the look with a layered dark-blue palette + reduced
            // opacity on the top bar.
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            // Subtle glass effect — 98% opacity so the desktop barely shows
            // through (full transparency would make controls hard to read).
            this.Opacity = 0.98;

            BuildTopBar();
            BuildTabbedInterface();

            // Start backend services
            // FIX H1: read options.json BEFORE constructing the ClientCommunicator
            // so the user-configured TcpServerPort (saved in OptionsForm → Advanced)
            // is actually applied. Previously options.json was written but only
            // PricingButtons was ever read back — every other setting (port,
            // default price, backup schedule, …) was dead config.
            int tcpPort = Protocol.DefaultPort;
            decimal defaultHourPrice = 0m;
            bool autoBackupEnabled = false;
            int backupIntervalHours = 24;
            try
            {
                var opts = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                if (opts != null)
                {
                    if (opts.TcpServerPort > 0) tcpPort = opts.TcpServerPort;
                    if (opts.DefaultHourPrice > 0) defaultHourPrice = opts.DefaultHourPrice;
                    autoBackupEnabled = opts.AutoBackup;
                    if (opts.BackupIntervalHours > 0) backupIntervalHours = opts.BackupIntervalHours;
                    // FIX DEAD-CONFIG-1: apply the Run-at-startup registry
                    // key on every launch so it stays in sync with the
                    // checkbox even if the user toggled it, then closed the
                    // options dialog, and the server was later started a
                    // different way (e.g. double-click vs the Run key).
                    try { Core.ServerAutoStartup.Apply(opts.RunServerAtStartup); } catch (Exception ex) { AuditLog.Log("MainForm", "ServerAutoStartup.Apply failed: " + ex.Message); }
                    _showTrayIcon = opts.ShowTrayIcon;
                    // TODO: still not wired to a consumer — IdleShutdownEnabled/
                    // Minutes, WarnUserEnabled/Message, DoubleClickAction,
                    // SyncEnabled, BandwidthLimit, BannerTopText, Language,
                    // Style, and the dozens of pricing/print/operator entries.
                    // These are saved but currently not read by their
                    // respective consumers (each module owns its own defaults).
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("MainForm", "Load options.json failed: " + ex.Message);
                FaultJournal.Raise("CFG-002", "options.json could not be read: " + ex.Message);
            }

            // FIX DEAD-CONFIG-1: build the tray icon (or don't) based on the
            // option we just loaded, and let minimize hide-to-tray instead
            // of just sitting on the taskbar like before.
            try { BuildTrayIcon(); } catch (Exception ex) { AuditLog.Log("MainForm", "BuildTrayIcon failed: " + ex.Message); }
            this.Resize += MainForm_Resize;

            // FIX B1/B10: wrap communicator + rate-limiter construction and
            // Start() in a try/catch. The most common cause of the "won't
            // open" problem is _communicator.Start() throwing because a
            // previous server instance is still bound to the TCP port —
            // previously that exception escaped the constructor, broke
            // Application.Run, and the process exited silently. Now the
            // operator gets a clear error dialog (in Persian) telling them
            // to kill the stale GameNet.Server.exe via Task Manager.
            // Re-throw so Program.cs's outer catch also logs + shows.
            try
            {
                _communicator = new ClientCommunicator(tcpPort);
                _rateLimiter = new RateLimiter();
                _communicator.Start();
                // FIX DEAD-CONFIG-6: scheduled sync — checks
                // SyncEnabled/ScheduledSync/ScheduledSyncMinutes internally
                // on every tick, so it's always safe to start.
                _syncScheduler = new Core.SyncScheduler(_communicator);
                _syncScheduler.Start();
                // FIX LONGTERM-1: log-table pruning, checked hourly, actually
                // runs once/24h — see DatabaseMaintenanceScheduler for why.
                _dbMaintenance = new Core.DatabaseMaintenanceScheduler();
                _dbMaintenance.Start();
            }
            catch (Exception ex)
            {
                try { AuditLog.Log("MainForm", "Communicator start failed: " + ex.Message); } catch { }
                MessageBox.Show("خطای راه‌اندازی سرور: " + ex.Message + "\n\nممکن است سرور قبلی همچنان در حال اجرا باشد.\nTask Manager را بررسی کنید و GameNet.Server را ببندید.",
                    "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw; // re-throw so Program.cs catch handles it
            }

            // Self-repair: Error and Critical faults are announced as toasts while the server
            // runs, and the explanation of a crash from the previous run is shown once.
            WireDiagnostics();

            // Round 15: Windows Firewall check for the kiosk port (after the window shows).
            ServerFirewall.TcpPort = tcpPort;
            this.Shown += (sf, ef) => { try { ServerFirewall.CheckAtStartup(this); } catch { } };

            // FIX-MINOR-UPDATE IMPROVE B: auto-detect the version of the
            // staged client exe in updates/ on startup so the operator's
            // "🔄 آپدیت همه کلاینت‌ها" button reports the right version
            // without the operator having to manually maintain version.txt.
            // If no markazbazi.Client.exe is staged yet, no-op silently — the
            // operator will be prompted by PickAndStageClientExe the first
            // time they click the update button.
            try
            {
                string updatesDir = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "updates");
                string clientExePath = System.IO.Path.Combine(updatesDir, "GameNet.Client.exe");
                if (System.IO.File.Exists(clientExePath))
                {
                    var ver = System.Diagnostics.FileVersionInfo.GetVersionInfo(clientExePath);
                    string version = ver.FileVersion;
                    if (string.IsNullOrEmpty(version)) version = ver.ProductVersion;
                    if (string.IsNullOrEmpty(version)) version = "1.0";
                    string versionFile = System.IO.Path.Combine(updatesDir, "version.txt");
                    System.IO.File.WriteAllText(versionFile, version);
                    AuditLog.Log("Update", $"Auto-detected client version {version} in updates/ folder");
                }
            }
            catch { }

            // ADD-MULTI-FEATURES Feature 2: REST API server (token-auth).
            // Exposes /api/clients, /api/users, /api/status, /api/reports/*
            // etc. for external mobile/web integrations. Port comes from
            // options.json (ApiPort); 0 = disabled (default). The server is
            // independent of the existing MobileApiController (which is still
            // available via the API tab for backward compat with the old
            // API-key-based endpoints).
            try
            {
                RestApiServer.SetClientCommunicator(_communicator);
                int apiPort = 0;
                var opts = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                if (opts != null) apiPort = opts.ApiPort;
                if (apiPort > 0) RestApiServer.Start(apiPort);
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "RestApiServer start failed: " + ex.Message); }

            // ADD-MULTI-FEATURES Feature 6: TLS — read UseTls from options.json
            // and enable it on the communicator. The communicator's TlsWrapper
            // auto-generates a self-signed cert on first run when UseTls=true.
            // Fix 1: default is ON. An explicit UseTls=false saved in options.json is
            // still honoured, so an installation whose kiosks are not yet on TLS keeps running.
            try
            {
                var opts2 = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                _communicator.UseTls = (opts2 == null) || opts2.UseTls;
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "UseTls option read failed: " + ex.Message); }

            // FIX-MONITOR-ADD5 TASK B5: read the Telegram bot token + chat
            // id from options.json and configure the notifier. Notifications
            // are no-ops until both fields are non-empty. Done BEFORE the
            // event handlers below are wired so the first topup / session-
            // end / disconnect event after startup can fire a Telegram
            // message.
            try
            {
                var optsTg = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                if (optsTg != null)
                    TelegramNotifier.Configure(optsTg.TelegramBotToken, optsTg.TelegramChatId);
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "TelegramNotifier configure failed: " + ex.Message); }

            // FIX H1: apply DefaultHourPrice to the pricing table so OptionsForm
            // changes are reflected in the billing engine. Idempotent — only
            // updates the default row if the saved value is positive.
            if (defaultHourPrice > 0)
            {
                try
                {
                    Database.Instance.Execute(
                        "UPDATE pricing SET price_per_hour = @p WHERE is_default = 1",
                        cmd => cmd.Parameters.AddWithValue("@p", defaultHourPrice));
                }
                catch (Exception ex) { AuditLog.Log("MainForm", "Apply DefaultHourPrice failed: " + ex.Message); }
            }

            // FIX H1: wire AutoBackup. The BackupManager already has a
            // StartAutoBackup(intervalHours) method that was never called.
            if (autoBackupEnabled)
            {
                try
                {
                    var bm = new BackupManager();
                    bm.StartAutoBackup(backupIntervalHours);
                    AuditLog.Log("MainForm", $"Auto-backup enabled, every {backupIntervalHours}h");
                }
                catch (Exception ex) { AuditLog.Log("MainForm", "AutoBackup start failed: " + ex.Message); }
            }

            // FIX H3: subscribe to OnScreenshotReceived so the camera button
            // (camShotBtn in BuildBottomPanel) actually displays the screenshot
            // it requests. Previously the request was sent but the response was
            // only consumed by the standalone ScreenshotViewerForm modal dialog —
            // the bottom-panel preview pane kept showing the static camera icon.
            // Now the latest screenshot is rendered into _cameraPreview as a
            // PictureBox, replacing the placeholder icon. The handler marshals
            // to the UI thread via BeginInvoke (the event fires on the network
            // reader thread).
            try
            {
                _communicator.OnScreenshotReceived += (station, payload) =>
                {
                    try
                    {
                        if (this.IsDisposed || !this.IsHandleCreated) return;
                        this.BeginInvoke((Action)(() => DisplayScreenshotInPreview(station, payload)));
                    }
                    catch (InvalidOperationException) { /* form closing/closed */ }
                    catch { }
                };

                // ADD-MULTI-FEATURES Feature 8: WebSocket live updates.
                // Forward the key ClientCommunicator events to LiveUpdates so
                // web dashboard clients (connected via WS) get real-time
                // notifications. The handler is fire-and-forget — exceptions
                // in LiveUpdates.Broadcast are swallowed internally so they
                // can never crash the network thread.
                _communicator.OnClientConnected += client =>
                {
                    LiveUpdates.Broadcast("client_connected", new { station = client.StationName, ip = client.ClientIp, user = client.CurrentUser });
                };
                _communicator.OnClientDisconnected += station =>
                {
                    LiveUpdates.Broadcast("client_disconnected", new { station = station });
                    // FIX-MONITOR-ADD5 TASK B5: push a Telegram notification
                    // so the operator is alerted even when away from the
                    // server UI. Fire-and-forget on a ThreadPool thread so
                    // the 5s HTTP timeout never blocks the communicator's
                    // event dispatch loop.
                    System.Threading.Tasks.Task.Run(() =>
                    {
                        try { TelegramNotifier.NotifyDisconnect(station); } catch { }
                    });
                };
                _communicator.OnSessionStarted += (station, session) =>
                {
                    LiveUpdates.Broadcast("session_started", new { station = station, user = session.Username, session_id = session.SessionId });
                };
                _communicator.OnSessionEnded += (station, session) =>
                {
                    LiveUpdates.Broadcast("session_ended", new { station = station, user = session.Username, minutes = session.DurationMinutes, cost = session.TotalCost });
                    // FIX-MONITOR-ADD5 TASK B5: push a Telegram notification
                    // when a billable session ends — gives the operator a
                    // running log of who-played-what-amount without having
                    // to check the dashboard.
                    System.Threading.Tasks.Task.Run(() =>
                    {
                        try { TelegramNotifier.NotifySessionEnd(station, session.Username, session.DurationMinutes, session.TotalCost); } catch { }
                    });
                };
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "OnScreenshotReceived subscription failed: " + ex.Message); }

            // FIX B11: guard SmartNotification + AutoRecharge construction.
            // Both are non-critical — a failure here should NOT prevent the
            // server from starting. Previously a constructor exception
            // escaped and killed Application.Run.
            try { _notifications = new SmartNotification(_communicator); } catch (Exception ex) { AuditLog.Log("MainForm", "SmartNotification init failed: " + ex.Message); }
            try { _autoRecharge = new AutoRecharge(); } catch (Exception ex) { AuditLog.Log("MainForm", "AutoRecharge init failed: " + ex.Message); }

            // FIX 2: wire the dead quick-topup feature. Clients send
            // ClientTopupRequest, the server saves it to the DB and raises
            // OnTopupRequest — but nobody was subscribed, so RespondToTopup
            // was never called and the user got no feedback.
            //
            // ADD-TOAST-THEME Feature 1: the prior fix used a modal Yes/No
            // MessageBox which blocked the 1Hz _clockTimer thread (sidebar
            // / camera preview / activity-log refresh froze until the
            // operator clicked Yes or No — documented as H10 KNOWN
            // LIMITATION in the prior pass). Now the request is auto-
            // approved and surfaced as a non-modal Toast — the operator
            // is informed without the UI freezing, and the kiosk gets its
            // response immediately. Operators who want stricter control
            // can review the topup_requests table (status='approved' rows
            // are logged with the auto-approval reason) and reverse an
            // approval via the Users tab if needed.
            _communicator.OnTopupRequest += (station, payload) =>
            {
                try
                {
                    // Auto-approve so the kiosk gets an immediate response.
                    _communicator.RespondToTopup(station, payload.Username, true, payload.Amount, "تأیید خودکار (toast)");
                }
                catch (Exception ex) { AuditLog.Log("Topup", "Auto-approve failed: " + ex.Message); }

                // FIX-MONITOR-ADD5 TASK B3: play the topup sound so the
                // operator is audibly alerted to the new request — even if
                // they're not looking at the screen. Marshalled to the UI
                // thread because SystemSounds.Play is technically a UI
                // affordance (it interacts with the user's audio mixer
                // session, which is bound to the foreground window).
                try { this.BeginInvoke((Action)(() => SoundNotification.PlayTopup())); }
                catch { /* form closing/closed */ }

                // FIX-MONITOR-ADD5 TASK B5: push a Telegram notification so
                // the operator is alerted on their phone if they're away
                // from the server UI. Fire-and-forget on a ThreadPool thread
                // so the 5s HTTP timeout never blocks the communicator.
                System.Threading.Tasks.Task.Run(() =>
                {
                    try { TelegramNotifier.NotifyTopup(station, payload.Username, payload.Amount); } catch { }
                });

                try
                {
                    if (this.IsDisposed || !this.IsHandleCreated) return;
                    this.BeginInvoke((Action)(() =>
                    {
                        ToastNotification.Show(this,
                            $"💰 درخواست شارژ\n{station} · {payload.Username}\n{payload.Amount:N0} تومان — تأیید شد",
                            ToastType.Success, 4000);
                    }));
                }
                catch (InvalidOperationException) { /* form closing/closed */ }
                catch { }
            };

            // Round 11: customer requests and messages reach the operator with a sound
            // and a small card (approve / reject / reply). Before this they were stored
            // as chat lines that nobody was shown.
            _communicator.OnCustomerRequest += (station, user, kind, minutes) =>
            {
                try { SoundNotification.PlayTimeRequest(station); } catch { }
                try
                {
                    if (this.IsDisposed || !this.IsHandleCreated) return;
                    this.BeginInvoke((Action)(() =>
                    {
                        try { CustomerRequestPrompt.ShowRequest(this, _communicator, station, user, kind, minutes); }
                        catch (Exception ex) { AuditLog.Log("Request", "Prompt failed: " + ex.Message); }
                    }));
                }
                catch (InvalidOperationException) { /* form closing/closed */ }
                catch { }
            };
            _communicator.OnCustomerMessage += (station, user, text) =>
            {
                try { SoundNotification.PlayCustomerMessage(station); } catch { }
                try
                {
                    if (this.IsDisposed || !this.IsHandleCreated) return;
                    this.BeginInvoke((Action)(() =>
                    {
                        try { CustomerRequestPrompt.ShowMessage(this, _communicator, station, user, text); }
                        catch (Exception ex) { AuditLog.Log("Request", "Message card failed: " + ex.Message); }
                    }));
                }
                catch (InvalidOperationException) { }
                catch { }
            };
            // Round 12: kiosk crash and self-repair reports reach the operator. The server
            // stored them in client_crash_reports, but nothing showed them.
            _communicator.OnCrashReport += (station, report) =>
            {
                try
                {
                    string type = report?.ExceptionType ?? "";
                    string text;
                    if (type == "GuardRestart:HEAL-002") text = "🔄 " + station + " هنگ کرده بود و خودکار دوباره باز شد";
                    else if (type == "GuardRestart:HEAL-003") text = "⚠️ " + station + " پشت سر هم بسته شد؛ تنظیمات سالم قبلی برگردانده شد";
                    else if (type.StartsWith("GuardRestart:")) text = "🔄 " + station + " بسته شده بود و خودکار دوباره باز شد";
                    else text = "💥 خطای برنامه در " + station + ": " + type + " — " + (report?.ExceptionMessage ?? "");
                    if (text.Length > 200) text = text.Substring(0, 200) + "…";
                    SoundNotification.PlayCue("time_end.wav", System.Media.SystemSounds.Hand, "crash|" + station, 20);
                    if (this.IsDisposed || !this.IsHandleCreated) return;
                    this.BeginInvoke((Action)(() =>
                    {
                        try { ToastNotification.Show(this, text, type.StartsWith("GuardRestart:") ? ToastType.Warning : ToastType.Error, 7000); } catch { }
                    }));
                }
                catch { }
            };

            // Round 11: a sound when a station's kiosk connects (the PC was switched on).
            // At most once per station every 30 s, so reconnects do not keep chiming.
            _communicator.OnClientConnected += client =>
            {
                try { SoundNotification.PlayClientOnline(client?.StationName ?? ""); } catch { }
                try { ActivityJournal.Record(ActivityJournal.Station, "سیستم روشن / وصل شد" + (string.IsNullOrEmpty(client?.ClientIp) ? "" : " (" + client.ClientIp + ")"), client?.StationName); } catch { }
            };
            // Round 14: journal of stations and sessions.
            _communicator.OnClientDisconnected += station =>
            {
                try { ActivityJournal.Record(ActivityJournal.Station, "سیستم خاموش / قطع شد", station); } catch { }
            };
            _communicator.OnSessionStarted += (station, session) =>
            {
                try { ActivityJournal.Record(ActivityJournal.Session, "شروع نشست" + (string.IsNullOrEmpty(session?.Username) ? "" : " — مشتری «" + session.Username + "»"), station); } catch { }
            };
            _communicator.OnSessionEnded += (station, session) =>
            {
                try { ActivityJournal.Record(ActivityJournal.Session, "پایان نشست" + (session == null ? "" : " — «" + session.Username + "»، " + session.DurationMinutes + " دقیقه، " + session.TotalCost.ToString("N0") + " تومان"), station); } catch { }
            };

            // Phase 4 — Start the Intrusion Detection System so suspicious
            // activity (brute force, credential stuffing, API scraping,
            // privilege escalation) is flagged in real time.
            try { IntrusionDetectionSystem.Initialize(); } catch { }

            // If an operator was authenticated at startup (Program.cs), use it
            // directly so all tabs are immediately accessible. Otherwise the
            // operator can still log in via the top-bar button.
            if (authenticatedOperator != null)
            {
                _currentOperator = authenticatedOperator;
                AuditLog.Log("MainForm", $"Operator {_currentOperator.Username} session started at launch");
                // Round 14: journal + "since you left" notice once the window exists.
                var opAtLaunch = _currentOperator;
                this.Shown += (s0, e0) => JournalLogin(opAtLaunch);
            }

            UpdateStatusBar();
            _statusTimer = new Timer { Interval = 2000 };
            _statusTimer.Tick += (s, e) => UpdateStatusBar();
            _statusTimer.Start();

            _autoRechargeTimer = new Timer { Interval = 300000 };
            _autoRechargeTimer.Tick += (s, e) => { try { _autoRecharge.ProcessAutoRecharges(); } catch { } };
            _autoRechargeTimer.Start();

            // FIX-MONITOR-ADD5 TASK B2: auto-backup the SQLite database every
            // 6 hours. Copies gamenet.db to backup/gamenet_<timestamp>.db,
            // keeping only the last 10 backups (older ones are deleted). All
            // errors are swallowed — backup is best-effort and must never
            // crash the server. The 6h cadence is conservative: a busy
            // game-net's DB doesn't change much in 6h (sessions are mostly
            // appended), and the file copy is fast (<1MB).
            _backupTimer = new Timer { Interval = 6 * 60 * 60 * 1000 }; // 6 hours
            _backupTimer.Tick += (s, e) =>
            {
                try
                {
                    string dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamenet.db");
                    string backupDir = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "backup");
                    System.IO.Directory.CreateDirectory(backupDir);
                    string backupPath = System.IO.Path.Combine(backupDir,
                        "gamenet_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".db");
                    if (System.IO.File.Exists(dbPath))
                        System.IO.File.Copy(dbPath, backupPath, true);
                    // Keep only the last 10 backups — older ones are deleted
                    // so the disk doesn't fill up over months of uptime.
                    var oldBackups = System.IO.Directory.GetFiles(backupDir, "gamenet_*.db")
                        .OrderByDescending(f => f).Skip(10);
                    foreach (var old in oldBackups)
                        try { System.IO.File.Delete(old); } catch { }
                }
                catch { /* best-effort — never crash the server on backup failure */ }
            };
            _backupTimer.Start();

            // Open the dashboard tab by default
            if (_tabs.TabPages.Count > 0)
                _tabs.SelectedIndex = 0;

            // Apply saved language preference to UI
            try { ApplyLanguage(); } catch { }

            // ADD-TOAST-THEME Feature 2: load the persisted dark/light theme
            // from theme.json (next to the server exe) and apply it to the
            // whole form. Done at the END of the ctor so all UI is built
            // first — ApplyTheme walks the control tree and recolors every
            // container / editable control / label that has a theme-able
            // surface. Subsequent toggles via the top-bar button or the
            // View → 🎨 تم menu item re-call ApplyTheme(this) live.
            try
            {
                ThemeManager.LoadTheme();
                ThemeManager.ApplyTheme(this);
                // FIX AUDIT-FIX-POSTUPDATE Bug T2: re-sync the theme button's
                // caption so it reflects the LOADED theme (not the default
                // Dark). Without this, a server whose theme.json says "light"
                // would show the ☀️-should-be-🌙 button caption mismatched
                // with the actually-light form on startup.
                if (_btnTheme != null)
                    _btnTheme.Text = ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙" : "☀️";
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "ThemeManager init failed: " + ex.Message); }
        }

        private void BuildTopBar()
        {
            _topBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Color.FromArgb(225, 225, 230), // slightly darker for depth
            };

            _lblTitle = new Label
            {
                Text = "🎮 markazbazi",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(15, 8),
                AutoSize = true,
            };

            _lblStatus = new Label
            {
                Text = "وضعیت: در حال شروع...",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 130, 50),
                Location = new Point(15, 30),
                AutoSize = true,
            };

            _btnLogin = new Button
            {
                Text = "👤 ورود اپراتور",
                Location = new Point(_topBar.Width - 380, 9),
                Size = new Size(140, 32),
                BackColor = Color.FromArgb(249, 226, 175),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(225, 225, 230),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            _btnLogin.Click += (s, e) => DoOperatorLogin();

            // Language selector
            _cboLanguage = new ComboBox
            {
                Location = new Point(_topBar.Width - 230, 10),
                Size = new Size(80, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9F),
                BackColor = Color.FromArgb(230, 230, 235),
                ForeColor = Color.FromArgb(40, 40, 40),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            _cboLanguage.Items.AddRange(new object[] { "🇮🇷 فا", "🇬🇧 EN", "🇸🇦 عر" });
            _cboLanguage.SelectedIndex = 0;
            _cboLanguage.SelectedIndexChanged += (s, e) =>
            {
                string lang = _cboLanguage.SelectedIndex == 0 ? "fa" : _cboLanguage.SelectedIndex == 1 ? "en" : "ar";
                try
                {
                    _localization.CurrentLanguage = lang;
                    ApplyLanguage();
                    // No MessageBox — it blocks and looks like a stuck window.
                    // The UI itself visibly changing is all the confirmation needed.
                }
                catch { }
            };

            // ADD-TOAST-THEME Feature 2: dark/light theme toggle button.
            // Sits between the language combo and the active-system label.
            // Clicking it flips ThemeManager.CurrentTheme, re-applies the
            // palette to the whole form, and persists to theme.json. The
            // button caption swaps between 🌙 (dark active) and ☀️ (light
            // active) so the operator sees the *current* theme at a glance.
            // FIX AUDIT-FIX-POSTUPDATE Bug T2: store the button in a field
            // (_btnTheme) so the ctor can re-sync its Text after
            // ThemeManager.LoadTheme() runs (LoadTheme may flip the current
            // theme from the default Dark to the persisted Light, leaving
            // the button caption stale).
            _btnTheme = new Button
            {
                Text = ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙" : "☀️",
                Location = new Point(_topBar.Width - 144, 9),
                Size = new Size(36, 32),
                BackColor = Color.FromArgb(230, 230, 235),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12F),
                ForeColor = Color.FromArgb(40, 40, 40),
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            _btnTheme.FlatAppearance.BorderSize = 0;
            _btnTheme.Click += (s, e) =>
            {
                ThemeManager.ToggleTheme();
                ThemeManager.ApplyTheme(this);
                _btnTheme.Text = ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙" : "☀️";
                // No MessageBox — toast gives non-blocking confirmation.
                ToastNotification.Show(this,
                    ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙 تم تیره فعال شد" : "☀️ تم روشن فعال شد",
                    ToastType.Info, 2000);
            };

            // Active system display
            _lblActiveSystem = new Label
            {
                Text = "🖥️ سیستم فعال: ---",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(180, 140, 20),
                Location = new Point(_topBar.Width - 100, 15),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };

            _topBar.Controls.Add(_lblTitle);
            _topBar.Controls.Add(_lblStatus);
            _topBar.Controls.Add(_btnLogin);
            _topBar.Controls.Add(_cboLanguage);
            _topBar.Controls.Add(_btnTheme);
            _topBar.Controls.Add(_lblActiveSystem); // FIX 10: was missing — label was invisible
            _topBar.Resize += (s, e) => {
                _btnLogin.Location = new Point(_topBar.Width - 380, 9);
                _cboLanguage.Location = new Point(_topBar.Width - 230, 10);
                _btnTheme.Location = new Point(_topBar.Width - 144, 9);
                _lblActiveSystem.Location = new Point(_topBar.Width - 100, 15);
            };
            // Don't add _topBar to Controls here — it's added at the end of
            // BuildTabbedInterface in the correct z-order. Adding it now would
            // put it at the back of the z-order, then later BringToFront calls
            // on other controls would push it behind, breaking the top stack.
        }

        private void BuildTabbedInterface()
        {
            // === Top menu strip (File / Reporting / View / Tools / Help) —
            // matches the reference image's classic Windows menu bar.
            var menuStrip = new MenuStrip
            {
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(225, 225, 230),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 9F),
                Padding = new Padding(4, 2, 4, 2),
            };
            
            // BUG FIX: these were hardcoded to literal English strings
            // regardless of the selected language, and (like every dropdown
            // item) were never revisited when the language changed — Tag
            // now carries the (fa,en,ar) triple so LocalizeMenuTree can
            // update them like everything else.
            bool isFaChrome = _localization.CurrentLanguage == "fa";
            bool isEnChrome = _localization.CurrentLanguage == "en";
            var miFile = new ToolStripMenuItem(isFaChrome ? "پرونده" : isEnChrome ? "File" : "ملف") { ForeColor = Color.FromArgb(40, 40, 40), Tag = ("پرونده", "File", "ملف") };
            var miReporting = new ToolStripMenuItem(isFaChrome ? "گزارش‌گیری" : isEnChrome ? "Reporting" : "التقارير") { ForeColor = Color.FromArgb(40, 40, 40), Tag = ("گزارش‌گیری", "Reporting", "التقارير") };
            var miView = new ToolStripMenuItem(isFaChrome ? "نمایش" : isEnChrome ? "View" : "عرض") { ForeColor = Color.FromArgb(40, 40, 40), Tag = ("نمایش", "View", "عرض") };
            var miTools = new ToolStripMenuItem(isFaChrome ? "ابزار" : isEnChrome ? "Tools" : "أدوات") { ForeColor = Color.FromArgb(40, 40, 40), Tag = ("ابزار", "Tools", "أدوات") };
            var miHelp = new ToolStripMenuItem(isFaChrome ? "راهنما" : isEnChrome ? "Help" : "مساعدة") { ForeColor = Color.FromArgb(40, 40, 40), Tag = ("راهنما", "Help", "مساعدة") };

            // File menu items
            var miExit = new ToolStripMenuItem("Exit", null, (s, e) => this.Close()) { ForeColor = Color.FromArgb(40, 40, 40) };
            miFile.DropDownItems.Add(miExit);

            // Reporting menu → opens report modules (tab keys match _tabDefs)
            AddMenuModule(miReporting, "reports", Color.FromArgb(137, 180, 250));
            AddMenuModule(miReporting, "advreports", Color.FromArgb(137, 180, 250));
            AddMenuModule(miReporting, "revenue", Color.FromArgb(249, 226, 175));
            miReporting.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            AddMenuModule(miReporting, "cash", Color.FromArgb(166, 227, 161));
            AddMenuModule(miReporting, "orders", Color.FromArgb(249, 226, 175));
            AddMenuModule(miReporting, "debt", Color.FromArgb(243, 139, 168));

            // ============================================================
            //  View menu  (enhanced to match HandyCafe layout)
            // ============================================================
            //  ├── Monitoring ▸ (Iconic / Detailed / Grid)
            //  ├── Timers
            //  ├── Shortcuts ▸ (Iconic / Detailed / Grid)
            //  ├── ---
            //  ├── ✓ Toolbar / Statusbar / Left panel / Bottom panel
            //  ├── ---
            //  ├── ✓ Use Small Icons / Grid
            //  ├── ---
            //  └── Language: FA / EN / AR
            // ============================================================
            var miViewMonitoring = new ToolStripMenuItem("📊 مانیتورینگ")
            {
                ForeColor = Color.FromArgb(30, 80, 180),
                BackColor = Color.FromArgb(230, 230, 235),
            };
            var miMonIconic   = new ToolStripMenuItem("🎯 آیکونی",   null, (s, e) => SetMonitoringMode("iconic"))   { ForeColor = Color.FromArgb(40, 40, 40) };
            var miMonDetailed = new ToolStripMenuItem("📋 جزئیات",   null, (s, e) => SetMonitoringMode("detailed")) { ForeColor = Color.FromArgb(40, 40, 40) };
            var miMonGrid     = new ToolStripMenuItem("🔲 شبکه‌ای",  null, (s, e) => SetMonitoringMode("grid"))     { ForeColor = Color.FromArgb(40, 40, 40) };
            miViewMonitoring.DropDownItems.AddRange(new ToolStripItem[] { miMonIconic, miMonDetailed, miMonGrid });
            miView.DropDownItems.Add(miViewMonitoring);

            // Timers (opens TimersForm tab)
            AddMenuModule(miView, "timers", Color.FromArgb(243, 139, 168));

            // Shortcuts view-mode submenu (visual mode of the shortcuts tab, not the tab itself)
            var miViewShortcuts = new ToolStripMenuItem("⭐ میانبرها")
            {
                ForeColor = Color.FromArgb(180, 140, 20),
                BackColor = Color.FromArgb(230, 230, 235),
            };
            var miShIconic   = new ToolStripMenuItem("🎯 آیکونی",  null, (s, e) => SetShortcutsViewMode("iconic"))   { ForeColor = Color.FromArgb(40, 40, 40) };
            var miShDetailed = new ToolStripMenuItem("📋 جزئیات",  null, (s, e) => SetShortcutsViewMode("detailed")) { ForeColor = Color.FromArgb(40, 40, 40) };
            var miShGrid     = new ToolStripMenuItem("🔲 شبکه‌ای", null, (s, e) => SetShortcutsViewMode("grid"))     { ForeColor = Color.FromArgb(40, 40, 40) };
            miViewShortcuts.DropDownItems.AddRange(new ToolStripItem[] { miShIconic, miShDetailed, miShGrid });
            miView.DropDownItems.Add(miViewShortcuts);

            miView.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // View → panel visibility toggles (toolbar / statusbar / left panel / bottom panel)
            var miViewToolbar = new ToolStripMenuItem("✓ نوار ابزار") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = true };
            miViewToolbar.Click += (s, e) =>
            {
                miViewToolbar.Checked = !miViewToolbar.Checked;
                if (_primaryToolbar != null)   _primaryToolbar.Visible   = miViewToolbar.Checked;
                if (_secondaryToolbar != null) _secondaryToolbar.Visible = miViewToolbar.Checked;
            };
            var miViewStatusbar = new ToolStripMenuItem("✓ نوار وضعیت") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = true };
            miViewStatusbar.Click += (s, e) =>
            {
                miViewStatusbar.Checked = !miViewStatusbar.Checked;
                if (_statusStrip != null) _statusStrip.Visible = miViewStatusbar.Checked;
            };
            var miViewLeft = new ToolStripMenuItem("✓ پنل چپ") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = true };
            miViewLeft.Click += (s, e) =>
            {
                miViewLeft.Checked = !miViewLeft.Checked;
                if (_leftSidebar != null) _leftSidebar.Visible = miViewLeft.Checked;
            };
            var miViewBottom = new ToolStripMenuItem("✓ پنل پایین") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = true };
            miViewBottom.Click += (s, e) =>
            {
                miViewBottom.Checked = !miViewBottom.Checked;
                if (_bottomPanel != null) _bottomPanel.Visible = miViewBottom.Checked;
            };
            miView.DropDownItems.AddRange(new ToolStripItem[] { miViewToolbar, miViewStatusbar, miViewLeft, miViewBottom });

            miView.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // View → use small icons / grid (cosmetic toggles, kept simple)
            var miSmallIcons = new ToolStripMenuItem("✓ آیکون‌های کوچک") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = false };
            miSmallIcons.Click += (s, e) =>
            {
                miSmallIcons.Checked = !miSmallIcons.Checked;
                try
                {
                    int newSize = miSmallIcons.Checked ? 24 : 34;
                    foreach (var btn in _primaryButtons)
                    {
                        var img = btn.Image;
                        var key = (string)btn.Tag;
                        // Look up icon name from primary defs by matching key
                        var def = _primaryDefs.Find(d => d.Key == key);
                        if (def.Key != null) btn.Image = IconPainter.Get(def.Icon, newSize);
                        if (img != null) img.Dispose();
                    }
                }
                catch { }
            };
            var miGrid = new ToolStripMenuItem("✓ شبکه (Grid)") { ForeColor = Color.FromArgb(40, 40, 40), BackColor = Color.FromArgb(230, 230, 235), Checked = false };
            miGrid.Click += (s, e) => { miGrid.Checked = !miGrid.Checked; SetMonitoringMode(miGrid.Checked ? "grid" : "iconic"); };
            miView.DropDownItems.AddRange(new ToolStripItem[] { miSmallIcons, miGrid });

            miView.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // View → language
            var miLangFa = new ToolStripMenuItem("🇮🇷 زبان: فارسی", null, (s, e) => { _cboLanguage.SelectedIndex = 0; }) { ForeColor = Color.FromArgb(40, 40, 40) };
            var miLangEn = new ToolStripMenuItem("🇬🇧 Language: English", null, (s, e) => { _cboLanguage.SelectedIndex = 1; }) { ForeColor = Color.FromArgb(40, 40, 40) };
            var miLangAr = new ToolStripMenuItem("🇸🇦 اللغة: العربية", null, (s, e) => { _cboLanguage.SelectedIndex = 2; }) { ForeColor = Color.FromArgb(40, 40, 40) };
            miView.DropDownItems.AddRange(new ToolStripItem[] { miLangFa, miLangEn, miLangAr });

            // ADD-TOAST-THEME Feature 2: View → 🎨 تم — toggles Dark/Light
            // theme. Same effect as the top-bar 🌙/☀️ button, but reachable
            // from the keyboard via the menu bar (Alt+V → T).
            miView.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            var miToggleTheme = new ToolStripMenuItem("🎨 تم (تیره/روشن)", null, (s, e) =>
            {
                ThemeManager.ToggleTheme();
                ThemeManager.ApplyTheme(this);
                // FIX AUDIT-FIX-POSTUPDATE Bug T2: keep the top-bar theme
                // button caption in sync when the theme is toggled via the
                // View menu (was only updated when the button itself was
                // clicked, so the menu path left the button stale).
                if (_btnTheme != null)
                    _btnTheme.Text = ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙" : "☀️";
                ToastNotification.Show(this,
                    ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙 تم تیره فعال شد" : "☀️ تم روشن فعال شد",
                    ToastType.Info, 2000);
            }) { ForeColor = Color.FromArgb(20, 140, 130) };
            miView.DropDownItems.Add(miToggleTheme);

            // FIX THEME-MENU: add a direct "🎨 تم‌ها" entry to the View menu
            // so the operator can find the full ThemeForm (15 presets) without
            // digging through Tools → بیشتر... → ظاهر.
            AddMenuModule(miView, "theme", Color.FromArgb(148, 226, 213));

            // ============================================================
            //  Tools menu  (reorganized to match HandyCafe layout)
            // ============================================================
            //  ├── General Settings (opens OptionsForm)
            //  ├── ---
            //  ├── Cash / Cafeteria / Ticket
            //  ├── ---
            //  ├── WakeUp Clients ▸ (All Network / Select Computer)
            //  ├── IP Monitor / Scheduled Shutdown
            //  ├── ---
            //  ├── Change Operator / Server Status / Fonts /
            //  │  Restrictions / Options
            //  ├── ---
            //  ├── Timers / Shortcuts / System Log / Sync
            //  ├── ---
            //  └── More ▸  (all other modules retained for muscle memory)
            // ============================================================

            // General Settings → OptionsForm (new comprehensive dialog)
            var miGeneral = new ToolStripMenuItem("⚙️ تنظیمات کلی...", null, (s, e) =>
            {
                using (var f = new OptionsForm()) f.ShowDialog(this);
                // FIX DEAD-CONFIG-1: re-apply the two settings we now wire
                // (RunServerAtStartup, ShowTrayIcon) immediately after the
                // dialog closes, instead of only on the next process start —
                // otherwise the operator toggles the checkbox, sees nothing
                // change, and assumes it's still broken.
                try
                {
                    var opts = GameNet.Server.Forms.OptionsForm.LoadStaticOptions();
                    if (opts != null)
                    {
                        Core.ServerAutoStartup.Apply(opts.RunServerAtStartup);
                        _showTrayIcon = opts.ShowTrayIcon;
                        BuildTrayIcon();

                        // FIX DEAD-CONFIG-8: OptionsForm's "سبک ظاهری"
                        // (Style: Windows/Dark/Modern) was saved but never
                        // applied — the server's actual theming system
                        // (ThemeManager, live-toggled via the 🌙/☀️ button)
                        // only supports Dark/Light. Honest partial fix: map
                        // "Dark" → Dark and both "Windows"/"Modern" → Light
                        // (this codebase has no separate chrome-style
                        // renderer for those two, so they can't be told
                        // apart visually — see README-worthy caveat). Only
                        // applied here, right after the operator explicitly
                        // changed it in this dialog, not on every startup —
                        // otherwise this would fight with the 🌙/☀️ button's
                        // own live theme.json state on unrelated launches.
                        var wantTheme = opts.Style == "Dark" ? AppTheme.Dark : AppTheme.Light;
                        if (ThemeManager.CurrentTheme != wantTheme)
                        {
                            ThemeManager.CurrentTheme = wantTheme;
                            ThemeManager.ApplyTheme(this);
                            if (_btnTheme != null) _btnTheme.Text = ThemeManager.CurrentTheme == AppTheme.Dark ? "🌙" : "☀️";
                        }
                    }
                }
                catch (Exception ex) { AuditLog.Log("MainForm", "Re-apply options after OptionsForm close failed: " + ex.Message); }
            }) { ForeColor = Color.FromArgb(20, 140, 130), BackColor = Color.FromArgb(230, 230, 235) };
            miTools.DropDownItems.Add(miGeneral);
            miTools.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            AddMenuModule(miTools, "cash", Color.FromArgb(166, 227, 161));
            AddMenuModule(miTools, "orders", Color.FromArgb(249, 226, 175));
            AddMenuModule(miTools, "tickets", Color.FromArgb(249, 226, 175));
            miTools.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // WakeUp Clients submenu: All Network / Select Computer
            var miWakeUp = new ToolStripMenuItem("⚡ روشن کردن کلاینت‌ها")
            {
                ForeColor = Color.FromArgb(20, 130, 50),
                BackColor = Color.FromArgb(230, 230, 235),
            };
            var miWakeAll = new ToolStripMenuItem("🌐 همه شبکه", null, (s, e) =>
            {
                try { _communicator?.WakeAll(); AuditLog.Log("Tools", "WakeAll invoked"); MessageBox.Show("✅ دستور Wake-on-LAN به همه ایستگاه‌ها ارسال شد.", "WakeUp", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }) { ForeColor = Color.FromArgb(40, 40, 40) };
            var miWakeOne = new ToolStripMenuItem("💻 انتخاب کامپیوتر...", null, (s, e) =>
            {
                string station = Microsoft.VisualBasic.Interaction.InputBox("نام ایستگاه (Station Name) را وارد کنید:", "روشن کردن کلاینت", "");
                if (string.IsNullOrWhiteSpace(station)) return;
                WakeStationByName(station.Trim());
            }) { ForeColor = Color.FromArgb(40, 40, 40) };
            miWakeUp.DropDownItems.AddRange(new ToolStripItem[] { miWakeAll, miWakeOne });
            miTools.DropDownItems.Add(miWakeUp);

            AddMenuModule(miTools, "ipmonitor", Color.FromArgb(137, 180, 250));
            AddMenuModule(miTools, "schedshutdown", Color.FromArgb(243, 139, 168));
            miTools.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // Change operator — action (not a tab).
            var miChangeOp = new ToolStripMenuItem("👤 تغییر اپراتور...", null, (s, e) => DoOperatorLogin()) { ForeColor = Color.FromArgb(130, 50, 180), BackColor = Color.FromArgb(230, 230, 235) };
            miTools.DropDownItems.Add(miChangeOp);

            AddMenuModule(miTools, "serverstatus", Color.FromArgb(137, 180, 250));

            // Fonts → opens standard FontDialog and applies selection to controls
            var miFonts = new ToolStripMenuItem("🔤 فونت‌ها...", null, (s, e) =>
            {
                using (var fd = new FontDialog { ShowColor = false, Font = this.Font ?? new Font("Segoe UI", 9F) })
                {
                    if (fd.ShowDialog(this) == DialogResult.OK)
                    {
                        ApplyFontToMainControls(fd.Font);
                        try { AuditLog.Log("MainForm", "Operator changed font to " + fd.Font.Name + " " + fd.Font.Size); } catch { }
                    }
                }
            }) { ForeColor = Color.FromArgb(180, 140, 20), BackColor = Color.FromArgb(230, 230, 235) };
            miTools.DropDownItems.Add(miFonts);

            AddMenuModule(miTools, "security", Color.FromArgb(243, 139, 168));

            // Options → also opens the new OptionsForm (same as General Settings)
            var miOptions = new ToolStripMenuItem("⚙️ تنظیمات...", null, (s, e) =>
            {
                using (var f = new OptionsForm()) f.ShowDialog(this);
            }) { ForeColor = Color.FromArgb(20, 140, 130), BackColor = Color.FromArgb(230, 230, 235) };
            miTools.DropDownItems.Add(miOptions);
            // Self-repair: read-only fault viewer (what failed, why, and what the software repaired).
            var miDiagnostics = new ToolStripMenuItem("🩺 عیب‌یابی و گزارش خطاها", null, (s, e) =>
            {
                using (var dv = new DiagnosticsViewer()) dv.ShowDialog(this);
            }) { ForeColor = Color.FromArgb(20, 140, 130), BackColor = Color.FromArgb(230, 230, 235) };
            miTools.DropDownItems.Add(miDiagnostics);
            miTools.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            AddMenuModule(miTools, "timers", Color.FromArgb(243, 139, 168));
            AddMenuModule(miTools, "shortcuts", Color.FromArgb(249, 226, 175));
            AddMenuModule(miTools, "syslog", Color.FromArgb(137, 180, 250));
            AddMenuModule(miTools, "sync", Color.FromArgb(166, 227, 161));
            miTools.DropDownItems.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });

            // BUG FIX: PRO was previously only reachable as a nested flyout
            // submenu inside Tools (miTools.DropDownItems.Add(miPRO)).
            // Nested ToolStripMenuItem flyouts are a known source of
            // unreliable clicks in WinForms — especially combined with the
            // RTL layout this app uses for Persian/Arabic, where the flyout
            // direction calculation can misfire and the submenu fails to
            // open or closes immediately. Promoting PRO to a real top-level
            // menu item (same level as File/Reporting/View/Tools/Help)
            // removes that whole class of failure.
            var miPRO = new ToolStripMenuItem(isFaChrome ? "پرو" : isEnChrome ? "PRO" : "PRO") { ForeColor = Color.FromArgb(0, 140, 180), BackColor = Color.FromArgb(230, 230, 235), Tag = ("پرو", "PRO", "PRO") };
            AddMenuModule(miPRO, "staff", Color.FromArgb(137, 180, 250));
            AddMenuModule(miPRO, "discount", Color.FromArgb(166, 227, 161));
            AddMenuModule(miPRO, "analytics", Color.FromArgb(249, 226, 175));
            AddMenuModule(miPRO, "aiprice", Color.FromArgb(0, 240, 255));
            AddMenuModule(miPRO, "livedash", Color.FromArgb(177, 76, 255));
            AddMenuModule(miPRO, "advloyalty", Color.FromArgb(250, 179, 135));
            AddMenuModule(miPRO, "smartloyalty", Color.FromArgb(61, 219, 122));
            AddMenuModule(miPRO, "aianalytics", Color.FromArgb(0, 240, 255));
            AddMenuModule(miPRO, "gamemgr", Color.FromArgb(137, 180, 250));
            AddMenuModule(miPRO, "tournamentpro", Color.FromArgb(177, 76, 255));
            AddMenuModule(miPRO, "advsecurity", Color.FromArgb(255, 59, 92));
            AddMenuModule(miPRO, "mobileapi", Color.FromArgb(166, 227, 161));
            // (previously: miTools.DropDownItems.Add(miPRO) + a separator —
            // removed now that PRO is promoted to a top-level menu item.)

            // All other modules retained under a "بیشتر..." submenu so we don't
            // lose operator muscle-memory. (Pricing / Stations / Equipment /
            // Consoles / Packages / Debt / Payment / Tiers / Loyalty / Queue /
            // Chat / Announce / SecurityDashboard / Licenses / Alerts /
            // WinHardening / Backup / Updates / API / Theme / SmartPricing /
            // Branches / Features / Extensions.)
            var miMore = new ToolStripMenuItem(isFaChrome ? "▸ بیشتر..." : isEnChrome ? "▸ More..." : "▸ المزيد...")
            {
                ForeColor = Color.FromArgb(30, 80, 180),
                BackColor = Color.FromArgb(230, 230, 235),
                Tag = ("▸ بیشتر...", "▸ More...", "▸ المزيد..."),
            };
            AddMenuModule(miMore, "pricing", Color.FromArgb(249, 226, 175));
            AddMenuModule(miMore, "stations", Color.FromArgb(166, 227, 161));
            AddMenuModule(miMore, "equipment", Color.FromArgb(166, 227, 161));
            AddMenuModule(miMore, "consoles", Color.FromArgb(166, 227, 161));
            AddMenuModule(miMore, "packages", Color.FromArgb(249, 226, 175));
            AddMenuModule(miMore, "debt", Color.FromArgb(249, 226, 175));
            AddMenuModule(miMore, "payment", Color.FromArgb(249, 226, 175));
            AddMenuModule(miMore, "tiers", Color.FromArgb(250, 179, 135));
            AddMenuModule(miMore, "loyalty", Color.FromArgb(250, 179, 135));
            AddMenuModule(miMore, "queue", Color.FromArgb(250, 179, 135));
            AddMenuModule(miMore, "chat", Color.FromArgb(203, 166, 247));
            AddMenuModule(miMore, "announce", Color.FromArgb(203, 166, 247));
            AddMenuModule(miMore, "secdash", Color.FromArgb(243, 139, 168));
            AddMenuModule(miMore, "licenses", Color.FromArgb(243, 139, 168));
            AddMenuModule(miMore, "secalerts", Color.FromArgb(243, 139, 168));
            AddMenuModule(miMore, "winharden", Color.FromArgb(243, 139, 168));
            AddMenuModule(miMore, "restrictions", Color.FromArgb(243, 139, 168));
            AddMenuModule(miMore, "backup", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "updates", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "api", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "theme", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "smartprice", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "branches", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "features", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "extensions", Color.FromArgb(148, 226, 213));
            AddMenuModule(miMore, "clientoptions", Color.FromArgb(137, 180, 250));
            AddMenuModule(miMore, "tournaments", Color.FromArgb(250, 179, 135));
            AddMenuModule(miMore, "vip", Color.FromArgb(250, 179, 135));
            miTools.DropDownItems.Add(miMore);

            // ============================================================
            //  Help menu  (enhanced to match HandyCafe)
            // ============================================================
            var miRegister = new ToolStripMenuItem("📝 ثبت‌نام...", null, (s, e) =>
            {
                string code = Microsoft.VisualBasic.Interaction.InputBox("کد لایسنس خود را وارد کنید:", "ثبت‌نام لایسنس", "");
                if (string.IsNullOrWhiteSpace(code)) return;
                MessageBox.Show("ثبت‌نام لایسنس\n\nکد واردشده: " + code + "\n(در نسخه دمو — لایسنس ثبت نشد.)",
                    "ثبت‌نام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miUpdateLic = new ToolStripMenuItem("🔄 به‌روزرسانی لایسنس...", null, (s, e) =>
            {
                MessageBox.Show("به‌روزرسانی لایسنس\n\nدر نسخه دمو، این قابلیت پیاده‌سازی نشده است.",
                    "به‌روزرسانی لایسنس", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miLostLic = new ToolStripMenuItem("❓ گم کردن اطلاعات لایسنس...", null, (s, e) =>
            {
                MessageBox.Show("بازیابی لایسنس\n\nدر صورت گم شدن اطلاعات لایسنس، با پشتیبانی تماس بگیرید.\nEmail: support@gamenet.local",
                    "گم کردن اطلاعات لایسنس", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miHelpGuide = new ToolStripMenuItem("📖 راهنما", null, (s, e) =>
            {
                MessageBox.Show(
                    "📖 راهنمای GameNet Server\n\n" +
                    "۱. برای شروع، روی دکمه «ورود اپراتور» کلیک کنید.\n" +
                    "۲. از نوار ابزار بالا، ماژول مورد نظر را انتخاب کنید (نظارت، کاربران، سفارش‌ها، ...).\n" +
                    "۳. برای روشن کردن کلاینت‌ها: ابزار ▸ روشن کردن کلاینت‌ها ▸ همه شبکه.\n" +
                    "۴. برای خاموشی زمان‌بندی شده: ابزار ▸ خاموشی زمان‌بندی.\n" +
                    "۵. برای تنظیمات کامل: ابزار ▸ تنظیمات کلی.\n\n" +
                    "برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.",
                    "راهنما", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miOnline = new ToolStripMenuItem("🌐 مرکز بازی آنلاین...", null, (s, e) =>
            {
                try { System.Diagnostics.Process.Start("https://gamenet.local/online"); }
                catch { MessageBox.Show("مرورگر باز نشد. آدرس: https://gamenet.local/online", "آنلاین", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miCheckUpdates = new ToolStripMenuItem("✅ بررسی به‌روزرسانی...", null, (s, e) =>
            {
                MessageBox.Show("بررسی به‌روزرسانی...\n\nشما در حال استفاده از نسخه 8.0 هستید.\nبه‌روزرسانی‌ای موجود نیست.",
                    "بررسی به‌روزرسانی", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miSupport = new ToolStripMenuItem("🛠️ پشتیبانی...", null, (s, e) =>
            {
                MessageBox.Show(
                    "🛠️ پشتیبانی مرکز بازی\n\n" +
                    "ساعات پشتیبانی: شنبه تا پنج‌شنبه، ۹ تا ۱۸\n" +
                    "تلفن: 021-12345678\n" +
                    "ایمیل: support@gamenet.local\n" +
                    "تلگرام: @gamenet_support",
                    "پشتیبانی", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miContact = new ToolStripMenuItem("📞 تماس...", null, (s, e) =>
            {
                MessageBox.Show(
                    "📞 اطلاعات تماس\n\n" +
                    "شرکت مرکز بازی\n" +
                    "تهران، ایران\n" +
                    "تلفن: 021-12345678\n" +
                    "ایمیل: info@gamenet.local\n" +
                    "وب‌سایت: https://gamenet.local",
                    "تماس", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }) { ForeColor = Color.FromArgb(40, 40, 40) };

            var miAbout = new ToolStripMenuItem("ℹ️ درباره...", null, (s, e) =>
                MessageBox.Show("markazbazi\nسامانه مدیریت گیم‌نت\n© 2026", "درباره",
                    MessageBoxButtons.OK, MessageBoxIcon.Information)) { ForeColor = Color.FromArgb(40, 40, 40) };

            miHelp.DropDownItems.AddRange(new ToolStripItem[]
            {
                miRegister, miUpdateLic, miLostLic,
                new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) },
                miHelpGuide, miOnline, miCheckUpdates,
                new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) },
                miSupport, miContact,
                new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) },
                miAbout,
            });

            menuStrip.Items.AddRange(new ToolStripItem[] { miFile, miReporting, miView, miTools, miPRO, miHelp });
            this.Controls.Add(menuStrip);
            // Don't SendToBack here — z-order is finalized at the end of this method.

            // === Primary icon toolbar (matches the reference image EXACTLY):
            // a single row of 8 icon+text buttons: Monitoring / Members /
            // Orders / Timers / Shortcuts / System Log / Market / Sync.
            // NO dropdowns, NO category groups — clicking a button switches
            // directly to that module. Everything else moved to Tools menu.
            var toolbar = _primaryToolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 78,
                BackColor = Color.FromArgb(225, 225, 230),
                Padding = new Padding(4, 4, 4, 4),
            };

            // The 8 primary modules — each is one of the existing tab defs.
            // (key in _tabDefs, icon name, EN label, FA label, AR label, accent)
            var primaryButtons = new[]
            {
                new { Key = "clients",    Icon = "monitor",  En = "Monitoring",  Fa = "نظارت",     Ar = "مراقبة",   Color = Color.FromArgb(137, 180, 250) },
                new { Key = "users",      Icon = "members",  En = "Members",     Fa = "کاربران",   Ar = "الأعضاء",  Color = Color.FromArgb(166, 227, 161) },
                new { Key = "orders",     Icon = "orders",   En = "Orders",      Fa = "سفارش‌ها",  Ar = "الطلبات",  Color = Color.FromArgb(249, 226, 175) },
                new { Key = "timers",     Icon = "timers",   En = "Timers",      Fa = "تایمرها",   Ar = "المؤقتات", Color = Color.FromArgb(243, 139, 168) },
                new { Key = "shortcuts",  Icon = "shortcuts",En = "Shortcuts",   Fa = "میانبرها",  Ar = "اختصارات", Color = Color.FromArgb(249, 226, 175) },
                new { Key = "syslog",     Icon = "log",      En = "System Log",  Fa = "گزارش سیستم", Ar = "سجل النظام", Color = Color.FromArgb(137, 180, 250) },
                new { Key = "sync",       Icon = "sync",     En = "Sync",        Fa = "همگام‌سازی", Ar = "مزامنة",   Color = Color.FromArgb(166, 227, 161) },
                new { Key = "cash",       Icon = "market",   En = "Cash",        Fa = "صندوق",     Ar = "الصندوق",  Color = Color.FromArgb(137, 180, 250) },
                // FIX PRO-BUTTON: add a direct PRO button to the primary toolbar
                // so the operator can access PRO modules without digging through
                // the Tools menu. Opens the first PRO module (staff).
                new { Key = "staff",      Icon = "members",  En = "PRO Staff",   Fa = "⚡ پرو",    Ar = "⚡ PRO",   Color = Color.FromArgb(0, 240, 255) },
            };
            // For "shortcuts" we need a dedicated tab key. Add a synthetic
            // Shortcuts tab below that hosts the ExtensionsForm (which contains
            // the daily-discount, QR-login, ambient-music shortcuts).

            int x = 4;
            foreach (var pb in primaryButtons)
            {
                Bitmap icon = IconPainter.Get(pb.Icon, 34);
                string labelText = _localization.CurrentLanguage == "en" ? pb.En :
                                   _localization.CurrentLanguage == "ar" ? pb.Ar : pb.Fa;

                var btn = new Button
                {
                    Text = labelText,
                    Image = icon,
                    ImageAlign = ContentAlignment.TopCenter,
                    TextAlign = ContentAlignment.BottomCenter,
                    Location = new Point(x, 4),
                    Size = new Size(120, 70),
                    BackColor = Color.FromArgb(230, 230, 235),
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    ForeColor = pb.Color,
                    Tag = pb.Key,
                    Cursor = Cursors.Hand,
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 220, 225);
                btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(200, 200, 210);

                // Click → open the module the same way the menus do. OpenModuleByKey
                // selects the tab AND loads its content. Selecting the tab alone does
                // nothing when that tab is already selected (no SelectedIndexChanged),
                // so a module refused before login kept its lock message until another
                // tab was selected.
                string key = pb.Key;
                btn.Click += (s, e) => OpenModuleByKey(key);

                toolbar.Controls.Add(btn);
                _primaryButtons.Add(btn);
                _primaryDefs.Add((pb.Key, pb.Icon, pb.En, pb.Fa, pb.Ar, pb.Color));
                x += 124;
            }

            // === Secondary action toolbar (matches the reference image's row 2):
            // a thin strip of small icon-only buttons for quick per-client
            // operations. These mirror the reference image's secondary toolbar
            // (Play / Stop / Refresh / Undo / Redo / Smiley / Profile / Camera /
            // Printer / Save / Folder / New Page / Search / Screen / Globe /
            // Close / Record / Power / Database / RefreshUser).
            var secondaryBar = _secondaryToolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 42,
                BackColor = Color.FromArgb(20, 20, 31),
                Padding = new Padding(4, 4, 4, 4),
            };

            // Build a helper that creates a small icon-only button.
            // Each button is 32x32 with a 22px icon, no text. Hover shows
            // a tooltip with the action name.
            var secActions = new[]
            {
                new { Icon = "play",          Tip = "شروع نشست (Play)",            Color = Color.FromArgb(166, 227, 161) },
                new { Icon = "stop",          Tip = "توقف نشست (Stop)",             Color = Color.FromArgb(243, 139, 168) },
                new { Icon = "refresh",       Tip = "بروزرسانی لیست",                Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "undo",          Tip = "بازگشت (Undo)",                 Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "redo",          Tip = "جلو (Redo)",                    Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "smiley",        Tip = "ارسال شکلک به کلاینت",           Color = Color.FromArgb(249, 226, 175) },
                new { Icon = "profile",       Tip = "پروفایل کلاینت",                Color = Color.FromArgb(203, 166, 247) },
                new { Icon = "camera",        Tip = "اسکرین‌شات از کلاینت",           Color = Color.FromArgb(250, 179, 135) },
                new { Icon = "printer",       Tip = "پرینت رسید",                    Color = Color.FromArgb(40, 40, 40) },
                new { Icon = "save",          Tip = "ذخیره گزارش",                   Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "folder",        Tip = "باز کردن پوشه بکاپ",             Color = Color.FromArgb(249, 226, 175) },
                new { Icon = "newpage",       Tip = "نشست جدید",                     Color = Color.FromArgb(166, 227, 161) },
                new { Icon = "search",        Tip = "جستجوی کلاینت",                  Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "screen",        Tip = "مشاهده صفحه کلاینت (ریموت)",      Color = Color.FromArgb(148, 226, 213) },
                new { Icon = "globe",         Tip = "کنترل اینترنت کلاینت",            Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "close",         Tip = "بستن اتصال کلاینت",              Color = Color.FromArgb(243, 139, 168) },
                new { Icon = "record",        Tip = "ضبط صفحه کلاینت",                Color = Color.FromArgb(243, 139, 168) },
                new { Icon = "power",         Tip = "خاموش کردن کلاینت",              Color = Color.FromArgb(249, 226, 175) },
                new { Icon = "database",      Tip = "مدیریت پایگاه داده",             Color = Color.FromArgb(166, 227, 161) },
                new { Icon = "refresh_user",  Tip = "همگام‌سازی مجدد کاربران",          Color = Color.FromArgb(137, 180, 250) },
                new { Icon = "sync",          Tip = "🔄 آپدیت همه کلاینت‌ها (توزیع خودکار)", Color = Color.FromArgb(166, 227, 161) },
                new { Icon = "help",          Tip = "راهنما",                         Color = Color.FromArgb(137, 180, 250) },
            };

            int sx = 6;
            var secTip = new ToolTip { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(40, 40, 40), StripAmpersands = false };
            foreach (var a in secActions)
            {
                Bitmap secIcon = IconPainter.Get(a.Icon, 22);
                var sb = new Button
                {
                    Image = secIcon,
                    Location = new Point(sx, 5),
                    Size = new Size(32, 32),
                    BackColor = Color.FromArgb(230, 230, 235),
                    FlatStyle = FlatStyle.Flat,
                    Cursor = Cursors.Hand,
                    Tag = a.Icon,
                    TabStop = false,
                };
                sb.FlatAppearance.BorderSize = 0;
                sb.FlatAppearance.MouseOverBackColor = Color.FromArgb(220, 220, 225);
                sb.FlatAppearance.MouseDownBackColor = Color.FromArgb(200, 200, 210);
                secTip.SetToolTip(sb, a.Tip);

                // Wire each secondary button to a sensible action. Most operate
                // on the currently-selected client in the ClientMonitorForm;
                // others switch tabs or trigger global operations.
                string iconName = a.Icon;
                sb.Click += (s, e) => HandleSecondaryAction(iconName);

                secondaryBar.Controls.Add(sb);
                sx += 36;
            }

            // === TabControl (hidden strip, content host) ===
            _tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9F),
                Appearance = TabAppearance.FlatButtons,
                ItemSize = new Size(0, 1),
                Alignment = TabAlignment.Top,
                BackColor = Color.FromArgb(255, 255, 255),
            };

            foreach (var def in _tabDefs)
            {
                var page = new TabPage(def.Title)
                {
                    BackColor = Color.FromArgb(255, 255, 255),
                    Padding = new Padding(0),
                };
                page.Tag = def.Key;
                _tabs.TabPages.Add(page);
            }

            _tabs.SelectedIndexChanged += (s, e) =>
            {
                var page = _tabs.SelectedTab;
                if (page == null) return;
                string key = (string)page.Tag;
                EnsureTabContent(page, key);
                // Round 14: journal "tab opened" (the same tab again within 2 minutes once).
                try
                {
                    if (key != _lastTabLogKey || (DateTime.UtcNow - _lastTabLogAt).TotalMinutes > 2)
                    {
                        _lastTabLogKey = key; _lastTabLogAt = DateTime.UtcNow;
                        ActivityJournal.Record(ActivityJournal.Tab, "باز کردن تب «" + page.Text.Trim() + "»" + (_deniedTabs.Contains(key) ? " (بدون دسترسی)" : ""));
                    }
                }
                catch { }
            };

            // Don't add _tabs to this.Controls — it will be re-parented into
            // _centerContainer below. secondaryBar and toolbar are added to
            // the form (top edge).
            this.Controls.Add(secondaryBar);
            this.Controls.Add(toolbar);

            // Build the 3 panels that match the reference image: left sidebar
            // (session control), bottom panel (camera + activity log), and
            // the bottom status strip.
            BuildLeftSidebar();
            BuildBottomPanel();
            BuildStatusStrip();

            // === THE KEY FIX: wrap _leftSidebar + _tabs in a center container ===
            // Previously _leftSidebar was Dock=Left on the FORM directly, which
            // made it span the full form height — including behind the top
            // toolbars. That caused the sidebar's controls to appear on top of
            // the primary toolbar, and the TabControl to be pushed into a tiny
            // strip — looking like "tabs stacking below each other".
            //
            // Now: _centerContainer is Dock=Fill on the FORM. Inside it, we put
            // _leftSidebar (Dock=Left) and _tabs (Dock=Fill). The center
            // container only occupies the rectangle BETWEEN the top stack and
            // the bottom stack, so the sidebar's height = that rectangle's
            // height — exactly what we want.
            _centerContainer = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(255, 255, 255),
            };
            // Add _tabs FIRST (it will be at the back = Fill = fills the whole
            // center container). Then add _leftSidebar (it will be at the
            // front = Left = claims its 270px strip from the left edge,
            // pushing _tabs to fill the remaining width to the right).
            // This is the reliable way to do side-by-side docking in WinForms:
            // Fill control at back, edge controls at front, in the order you
            // add them.
            _centerContainer.Controls.Add(_tabs);        // back (Fill)
            _centerContainer.Controls.Add(_leftSidebar); // front (Left)
            _tabs.Visible = true;
            _leftSidebar.Visible = true;

            // Add the center container to the form.
            this.Controls.Add(_centerContainer);

            // === Form-level docking z-order ===
            // FIX LAYOUT-1 (found via user report: "toolbars/menu/bottom bars
            // not in the right place, tabs stacked, content underneath not
            // clearing"): WinForms resolves Dock in z-order from FRONT
            // (index 0) to BACK — each docked control claims space from
            // whatever's left AFTER every control with a lower index has
            // already claimed its share. A Dock=Fill control claims ALL
            // remaining space at the point it's processed.
            //
            // The old order put _centerContainer (Fill) at index 4 — BEFORE
            // _bottomPanel (5) and _statusStrip (6). That means Fill grabbed
            // the entire remaining rectangle first, including the strip that
            // was supposed to be reserved for the bottom panel and status
            // strip, which then had to squeeze into whatever was left (zero,
            // in the worst case) — rendering squashed/overlapping/hidden
            // behind the tab content. This is almost certainly the root
            // cause of the reported "پایین/تولبار درست جا نیست" symptom.
            //
            // Fix: every edge-docked control (Top AND Bottom) must be
            // resolved BEFORE the Fill control. Fill must be LAST (highest
            // index / furthest back) so it only ever claims the genuine
            // leftover rectangle.
            //
            // Correct front→back order (index 0 = front = resolved first):
            //   [0] menuStrip         (Dock=Top, very top)
            //   [1] _topBar           (Dock=Top)
            //   [2] toolbar           (Dock=Top, primary 8 buttons)
            //   [3] secondaryBar      (Dock=Top, 21 small icons)
            //   [4] _bottomPanel      (Dock=Bottom)
            //   [5] _statusStrip      (Dock=Bottom, very bottom)
            //   [6] _centerContainer  (Dock=Fill — sidebar + tabs — LAST)
            this.Controls.Add(_topBar);   // was deferred from BuildTopBar
            this.Controls.SetChildIndex(_centerContainer, 6); // Fill — resolved LAST, only gets genuine leftover space
            this.Controls.SetChildIndex(_statusStrip, 5);     // bottom edge, very bottom
            this.Controls.SetChildIndex(_bottomPanel, 4);
            this.Controls.SetChildIndex(secondaryBar, 3);     // top edge
            this.Controls.SetChildIndex(toolbar, 2);
            this.Controls.SetChildIndex(_topBar, 1);
            this.Controls.SetChildIndex(menuStrip, 0);         // very top

            // Force a layout pass so all docked controls recompute their bounds.
            this.PerformLayout();
        }

        /// <summary>
        /// Builds the left sidebar (Session Control Panel) matching the
        /// reference image: session time info, big red price display, time
        /// preset buttons (10/15/30/45/60/90/120/180/240), custom time input,
        /// Limit Time / Convert to Unlimited buttons, and a Play and Pay
        /// checkbox.
        /// </summary>
        private void BuildLeftSidebar()
        {
            _leftSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 270,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(8, 8, 8, 8),
                // Enable AutoScroll so when the window is too short to show
                // all sidebar controls (station label + tabs + info + price +
                // 9 time presets + custom input + Limit/Unlimited + Play&Pay),
                // a vertical scrollbar appears instead of clipping the bottom.
                AutoScroll = true,
            };

            int y = 8;
            _lblSelectedStation = new Label
            {
                Text = "🎯 ایستگاه انتخابی: ---",
                Location = new Point(8, y),
                Size = new Size(254, 20),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 140, 20),
                TextAlign = ContentAlignment.MiddleCenter,
            };
            _leftSidebar.Controls.Add(_lblSelectedStation);
            y += 24;

            // Tabs: Time / Orders / Queue (visual, Time active)
            var tabTime = new Button { Text = "⏱️ زمان", Location = new Point(8, y), Size = new Size(82, 26), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8F, FontStyle.Bold), ForeColor = Color.FromArgb(240, 240, 240) };
            var tabOrders = new Button { Text = "📋 سفارش", Location = new Point(94, y), Size = new Size(82, 26), BackColor = Color.FromArgb(230, 230, 235), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(40, 40, 40) };
            var tabQueue = new Button { Text = "🎟️ صف", Location = new Point(180, y), Size = new Size(82, 26), BackColor = Color.FromArgb(230, 230, 235), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8F), ForeColor = Color.FromArgb(40, 40, 40) };
            _leftSidebar.Controls.Add(tabTime);
            _leftSidebar.Controls.Add(tabOrders);
            _leftSidebar.Controls.Add(tabQueue);
            y += 32;

            // Session info block
            var infoPanel = new Panel
            {
                Location = new Point(8, y),
                Size = new Size(254, 110),
                BackColor = Color.FromArgb(230, 230, 235),
            };
            int iy = 6;
            AddInfoRow(infoPanel, "زمان شروع:", "00:00:00", 6, ref iy, out _lblStartTime);
            AddInfoRow(infoPanel, "زمان پایان:", "00:00:00", 6, ref iy, out _lblEndTime);
            AddInfoRow(infoPanel, "زمان استفاده:", "00:00:00", 6, ref iy, out _lblUsedTime);
            AddInfoRow(infoPanel, "زمان باقی‌مانده:", "00:00:00", 6, ref iy, out _lblRemainingTime);
            _leftSidebar.Controls.Add(infoPanel);
            y += 116;

            // Big red price display
            _lblPrice = new Label
            {
                Text = "۰ تومان",
                Location = new Point(8, y),
                Size = new Size(254, 40),
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                ForeColor = Color.FromArgb(200, 30, 60),
                BackColor = Color.FromArgb(230, 230, 235),
                TextAlign = ContentAlignment.MiddleCenter,
            };
            _leftSidebar.Controls.Add(_lblPrice);
            y += 46;

            // Time preset buttons grid: 10, 15, 30 / 45, 60, 90 / 120, 180, 240
            // FIX 5: read the saved values from options.json (OptionsForm →
            // Pricing → Buttons panel) so the operator's customised quick-time
            // presets show up here too. Falls back to the hardcoded defaults
            // if options.json is missing, malformed, or doesn't yet have the
            // PricingButtons field.
            int[] presets = { 10, 15, 30, 45, 60, 90, 120, 180, 240 };
            try
            {
                var optionsPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
                if (System.IO.File.Exists(optionsPath))
                {
                    var json = System.IO.File.ReadAllText(optionsPath);
                    var data = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                    if (data != null && data.ContainsKey("PricingButtons"))
                    {
                        var parts = data["PricingButtons"].Split(',');
                        if (parts.Length >= 9)
                        {
                            var loaded = new int[9];
                            for (int i = 0; i < 9; i++)
                                if (int.TryParse(parts[i].Trim(), out loaded[i])) presets[i] = loaded[i];
                        }
                    }
                }
            }
            catch { }
            for (int i = 0; i < presets.Length; i++)
            {
                int minutes = presets[i];
                int col = i % 3, row = i / 3;
                var b = new Button
                {
                    Text = minutes.ToString(),
                    Location = new Point(8 + col * 84, y + row * 32),
                    Size = new Size(80, 28),
                    BackColor = Color.FromArgb(220, 220, 225),
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    ForeColor = Color.FromArgb(40, 40, 40),
                    Cursor = Cursors.Hand,
                };
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(200, 200, 210);
                b.Click += (s, e) => AddTimeToSelected(minutes);
                _leftSidebar.Controls.Add(b);
            }
            y += 3 * 32 + 6;

            // Custom time input + "+" button
            var lblCustom = new Label
            {
                Text = "زمان دلخواه (دقیقه):",
                Location = new Point(8, y),
                Size = new Size(254, 18),
                Font = new Font("Segoe UI", 8F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            _leftSidebar.Controls.Add(lblCustom);
            y += 22;

            _numCustomTime = new NumericUpDown
            {
                Location = new Point(8, y),
                Size = new Size(170, 28),
                Minimum = 0,
                Maximum = 999,
                Value = 0,
                Font = new Font("Segoe UI", 10F),
                BackColor = Color.FromArgb(230, 230, 235),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            _leftSidebar.Controls.Add(_numCustomTime);

            var btnAddCustom = new Button
            {
                Text = "➕ افزودن",
                Location = new Point(182, y),
                Size = new Size(80, 28),
                BackColor = Color.FromArgb(166, 227, 161),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
                Cursor = Cursors.Hand,
            };
            btnAddCustom.Click += (s, e) => AddTimeToSelected((int)_numCustomTime.Value);
            _leftSidebar.Controls.Add(btnAddCustom);
            y += 36;

            // Limit Time / Convert to Unlimited
            var btnLimit = new Button
            {
                Text = "⏱️ محدود کردن زمان",
                Location = new Point(8, y),
                Size = new Size(122, 30),
                BackColor = Color.FromArgb(249, 226, 175),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
                Cursor = Cursors.Hand,
            };
            btnLimit.Click += (s, e) => ActOnSelectedStation(st => _communicator.SetSessionTime(st, 1, (int)_numCustomTime.Value, "محدود کردن زمان"));
            _leftSidebar.Controls.Add(btnLimit);

            var btnUnlimited = new Button
            {
                Text = "♾️ نامحدود",
                Location = new Point(140, y),
                Size = new Size(122, 30),
                BackColor = Color.FromArgb(137, 180, 250),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
                Cursor = Cursors.Hand,
            };
            btnUnlimited.Click += (s, e) => ActOnSelectedStation(st => _communicator.SetSessionTime(st, 2, 0, "نامحدود"));
            _leftSidebar.Controls.Add(btnUnlimited);
            y += 36;

            // Play and Pay checkbox
            _chkPlayAndPay = new CheckBox
            {
                Text = "🎮 Play and Pay (بازی کن، بعد پرداخت کن)",
                Location = new Point(8, y),
                Size = new Size(254, 24),
                Font = new Font("Segoe UI", 8F),
                ForeColor = Color.FromArgb(130, 50, 180),
                Checked = false,
            };
            _leftSidebar.Controls.Add(_chkPlayAndPay);

            // NOTE: _leftSidebar is NOT added to this.Controls here.
            // BuildTabbedInterface re-parents it into _centerContainer so it
            // doesn't span the full form height (which would overlap the top
            // toolbars). If we added it to the form now, the later re-parent
            // would move it, but cleaner to never add it here.
        }

        private void AddInfoRow(Panel parent, string labelText, string valueText, int x, ref int y, out Label valueLabel)
        {
            var lbl = new Label
            {
                Text = labelText,
                Location = new Point(x, y),
                Size = new Size(130, 18),
                Font = new Font("Segoe UI", 8F),
                ForeColor = Color.FromArgb(40, 40, 40),
                TextAlign = ContentAlignment.MiddleLeft,
            };
            parent.Controls.Add(lbl);
            valueLabel = new Label
            {
                Text = valueText,
                Location = new Point(x + 130, y),
                Size = new Size(110, 18),
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 130, 50),
                TextAlign = ContentAlignment.MiddleRight,
            };
            parent.Controls.Add(valueLabel);
            y += 24;
        }

        /// <summary>
        /// Builds the bottom panel: left = camera preview area (orange camera
        /// icon), right = activity log DataGridView (Time/Title/Url/Applic/PC).
        /// </summary>
        private void BuildBottomPanel()
        {
            _bottomPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                // FIX AUDIT-FIX-FINAL Bug B: was 100 px tall but the camera
                // preview panel inside it is 172 px tall — the screenshot
                // button at y=134 was invisible below the panel's bottom
                // edge. Restored to 180 so the whole camera preview + the
                // screenshot button are visible.
                Height = 180,
                BackColor = Color.FromArgb(20, 20, 31),
                Padding = new Padding(4, 4, 4, 4),
            };

            _cameraPreview = new Panel
            {
                Location = new Point(4, 4),
                Size = new Size(220, 172),
                BackColor = Color.FromArgb(255, 255, 255),
                BorderStyle = BorderStyle.FixedSingle,
            };
            var camIcon = new PictureBox
            {
                Image = IconPainter.Get("camera", 40),
                SizeMode = PictureBoxSizeMode.CenterImage,
                Location = new Point(8, 6),
                Size = new Size(40, 40),
                BackColor = Color.Transparent,
            };
            _cameraLabel = new Label
            {
                Text = "📷 پیش‌نمایش دوربین\n(انتخاب کلاینت برای مشاهده)",
                Location = new Point(52, 8),
                Size = new Size(160, 60),
                Font = new Font("Segoe UI", 8F),
                ForeColor = Color.FromArgb(200, 100, 30),
                TextAlign = ContentAlignment.MiddleLeft,
            };
            var camShotBtn = new Button
            {
                Text = "📷 اسکرین‌شات",
                Location = new Point(40, 134),
                Size = new Size(140, 30),
                BackColor = Color.FromArgb(137, 180, 250),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
                Cursor = Cursors.Hand,
            };
            camShotBtn.FlatAppearance.BorderSize = 0;
            camShotBtn.Click += (s, e) =>
            {
                try
                {
                    var conns = _communicator?.GetAllRawConnections();
                    if (conns == null || conns.Count == 0)
                    {
                        MessageBox.Show("هیچ کلاینتی متصل نیست.", "اسکرین‌شات",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    var target = conns.FirstOrDefault(c => c.StationName == _selectedStation);
                    if (target.StationName == null)
                        target = conns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                    if (target.StationName == null) target = conns[0];
                    _communicator.RequestScreenshot(target.StationName, 50);
                    // ADD-TOAST-THEME Feature 1: replace modal MessageBox with
                    // a non-blocking Toast. The screenshot will arrive in the
                    // preview pane via the OnScreenshotReceived handler — no
                    // modal needed.
                    ToastNotification.Show(this,
                        $"📸 درخواست اسکرین‌شات ارسال شد\n{target.StationName}",
                        ToastType.Info, 2500);
                }
                catch (Exception ex) { AuditLog.Log("MainForm", "CameraShot error: " + ex.Message); }
            };
            _cameraPreview.Controls.Add(camIcon);
            _cameraPreview.Controls.Add(_cameraLabel);
            _cameraPreview.Controls.Add(camShotBtn);
            _bottomPanel.Controls.Add(_cameraPreview);

            var lblActivity = new Label
            {
                Text = "📋 لاگ فعالیت کلاینت‌ها",
                Location = new Point(232, 4),
                Size = new Size(600, 18),
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
            };
            _bottomPanel.Controls.Add(lblActivity);

            _activityGrid = new DataGridView
            {
                Location = new Point(232, 24),
                Size = new Size(_bottomPanel.Width - 240, 148),
                BackgroundColor = Color.FromArgb(255, 255, 255),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 8F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 8F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 24,
                RowTemplate = { Height = 22 },
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            };
            _activityGrid.Columns.Add("colTime", "زمان");
            _activityGrid.Columns.Add("colTitle", "عنوان");
            // FIX L1: removed the always-"—" Url column. The kiosk does not
            // currently report browser URLs (the visited-websites-request
            // path is a one-shot operator query, not a continuous feed), so
            // the column was always empty. Removing it de-clutters the grid
            // and lets the Title / Application columns use the freed width.
            _activityGrid.Columns.Add("colApplic", "برنامه");
            _activityGrid.Columns.Add("colPC", "سیستم");
            _activityGrid.Columns[0].Width = 70;
            _activityGrid.Columns[1].Width = 240;
            _activityGrid.Columns[2].Width = 160;
            _activityGrid.Columns[3].Width = 70;
            _bottomPanel.Controls.Add(_activityGrid);

            _activityGrid.Rows.Add("12:30:05", "Counter-Strike 2", "cs2.exe", "PC_1");
            _activityGrid.Rows.Add("12:31:12", "Chrome — YouTube", "chrome.exe", "PC_2");

            _bottomPanel.Resize += (s, e) => { _activityGrid.Width = _bottomPanel.Width - 240; };

            this.Controls.Add(_bottomPanel);
        }

        /// <summary>
        /// Builds the bottom status strip: ADMIN | Clients | Idle | Unreachable |
        /// datetime (matches reference image — Demo and Online removed per
        /// user request).
        /// </summary>
        private void BuildStatusStrip()
        {
            _statusStrip = new StatusStrip
            {
                BackColor = Color.FromArgb(225, 225, 230),
                Font = new Font("Segoe UI", 8F),
            };
            

            _ssRole = new ToolStripStatusLabel { Text = "مدیر", ForeColor = Color.FromArgb(180, 140, 20), Font = new Font("Segoe UI", 8F, FontStyle.Bold), Margin = new Padding(8, 0, 8, 0) };
            _ssClients = new ToolStripStatusLabel { Text = "کلاینت‌ها: 0", ForeColor = Color.FromArgb(40, 40, 40), Margin = new Padding(8, 0, 8, 0) };
            _ssOnline = new ToolStripStatusLabel { Text = "آنلاین: 0", ForeColor = Color.FromArgb(20, 130, 50), Margin = new Padding(8, 0, 8, 0) };
            _ssIdle = new ToolStripStatusLabel { Text = "بیکار: 0", ForeColor = Color.FromArgb(180, 140, 20), Margin = new Padding(8, 0, 8, 0) };
            _ssUnreachable = new ToolStripStatusLabel { Text = "غیرقابل دسترس: 0", ForeColor = Color.FromArgb(200, 30, 60), Margin = new Padding(8, 0, 8, 0) };
            _ssDateTime = new ToolStripStatusLabel { Text = "", ForeColor = Color.FromArgb(40, 40, 40), Spring = true, TextAlign = ContentAlignment.MiddleRight, Margin = new Padding(8, 0, 8, 0) };

            _statusStrip.Items.Add(_ssRole);
            _statusStrip.Items.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            _statusStrip.Items.Add(_ssClients);
            _statusStrip.Items.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            _statusStrip.Items.Add(_ssOnline);
            _statusStrip.Items.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            _statusStrip.Items.Add(_ssIdle);
            _statusStrip.Items.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            _statusStrip.Items.Add(_ssUnreachable);
            _statusStrip.Items.Add(new ToolStripSeparator { BackColor = Color.FromArgb(220, 220, 225) });
            _statusStrip.Items.Add(_ssDateTime);

            _clockTimer = new Timer { Interval = 2000 };
            _clockTimer.Tick += (s, e) =>
            {
                try
                {
                    _ssDateTime.Text = DateTime.Now.ToString("dd/MM/yyyy - HH:mm:ss");
                    // FIX H8: count unreachable separately from online/idle.
                    // Previously unreachable was always `total - online - idle`
                    // which evaluated to 0 because every connection was bucketed
                    // as online or idle. Now we use the heartbeat age: a client
                    // whose last heartbeat is > 90s old is unreachable.
                    int total = 0, online = 0, idle = 0, unreachable = 0;
                    try
                    {
                        var conns = _communicator?.GetAllRawConnections();
                        if (conns != null)
                        {
                            foreach (var c in conns)
                            {
                                total++;
                                var heartbeatAge = DateTime.UtcNow - c.LastHeartbeat;
                                if (heartbeatAge > TimeSpan.FromSeconds(90))
                                    unreachable++;
                                else if (!string.IsNullOrEmpty(c.User) && c.User != "-") online++;
                                else if (c.Minutes > 0) online++;
                                else idle++;
                            }
                        }
                    }
                    catch { }
                    _ssClients.Text = $"کلاینت‌ها: {total}";
                    _ssOnline.Text = $"آنلاین: {online}";
                    _ssIdle.Text = $"بیکار: {idle}";
                    _ssUnreachable.Text = $"غیرقابل دسترس: {unreachable}";
                    // Refresh the left sidebar with REAL session data for the
                    // selected (or first connected) station.
                    RefreshSidebarLive();
                    // Refresh the camera preview in the bottom panel.
                    RefreshCameraPreview();
                    // Refresh the activity log with real client windows/games.
                    RefreshActivityLog();
                }
                catch { }
            };
            _clockTimer.Start();

            this.Controls.Add(_statusStrip);
        }

        /// <summary>
        /// Refreshes the left sidebar with REAL session data from the currently
        /// selected station (or the first connected client if none is selected).
        /// Shows actual start time, used time, remaining time (if a fixed
        /// duration was set), and the live cost from the billing engine —
        /// instead of the "00:00:00" / "۰ ریال" placeholders.
        /// </summary>
        private void RefreshSidebarLive()
        {
            try
            {
                var conns = _communicator?.GetAllRawConnections();
                if (conns == null || conns.Count == 0)
                {
                    if (_lblSelectedStation != null) _lblSelectedStation.Text = "🎯 ایستگاه انتخابی: ---";
                    if (_lblStartTime != null) _lblStartTime.Text = "00:00:00";
                    if (_lblEndTime != null) _lblEndTime.Text = "00:00:00";
                    if (_lblUsedTime != null) _lblUsedTime.Text = "00:00:00";
                    if (_lblRemainingTime != null) _lblRemainingTime.Text = "00:00:00";
                    if (_lblPrice != null) _lblPrice.Text = "۰ تومان";
                    return;
                }

                // Pick the target: the explicitly-selected station, else the
                // first station with an active user, else the first station.
                var target = conns.FirstOrDefault(c => c.StationName == _selectedStation);
                if (target.StationName == null)
                    target = conns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                if (target.StationName == null)
                    target = conns[0];

                if (_lblSelectedStation != null)
                    _lblSelectedStation.Text = $"🎯 ایستگاه انتخابی: {target.StationName}";

                bool inSession = !string.IsNullOrEmpty(target.User) && target.User != "-" &&
                                 target.State != ClientState.Disconnected;
                if (!inSession)
                {
                    // Connected but not logged in / idle
                    if (_lblStartTime != null) _lblStartTime.Text = "—";
                    if (_lblEndTime != null) _lblEndTime.Text = "—";
                    if (_lblUsedTime != null) _lblUsedTime.Text = "00:00:00";
                    if (_lblRemainingTime != null) _lblRemainingTime.Text = "—";
                    if (_lblPrice != null) _lblPrice.Text = "۰ تومان";
                    return;
                }

                // REAL session data
                // FIX H2: use SessionStart (set in CompleteLogin) instead of
                // ConnectedAt (the TCP connect time). The two can differ by
                // minutes if the kiosk sat on the login screen before the
                // user typed credentials — using ConnectedAt made the
                // "Used Time" counter start before the session was actually
                // active, overcharging the operator's perception of usage.
                DateTime start = target.SessionStart != default(DateTime) ? target.SessionStart : target.ConnectedAt;
                DateTime now = DateTime.UtcNow;
                TimeSpan used = now - start;
                if (used.TotalSeconds < 0) used = TimeSpan.Zero;

                if (_lblStartTime != null)
                    _lblStartTime.Text = start.ToLocalTime().ToString("HH:mm:ss");

                // FIX L14: compute end time / remaining from the per-station
                // TimeCapMinutes set via ServerSetSessionTime. 0 = unlimited.
                if (target.TimeCapMinutes > 0)
                {
                    DateTime end = start.AddMinutes(target.TimeCapMinutes);
                    TimeSpan remaining = end - now;
                    if (remaining.TotalSeconds < 0) remaining = TimeSpan.Zero;
                    if (_lblEndTime != null)
                        _lblEndTime.Text = end.ToLocalTime().ToString("HH:mm:ss");
                    if (_lblRemainingTime != null)
                        _lblRemainingTime.Text = $"{(int)remaining.TotalHours:00}:{remaining.Minutes:00}:{remaining.Seconds:00}";
                }
                else
                {
                    if (_lblEndTime != null) _lblEndTime.Text = "نامحدود";
                    if (_lblRemainingTime != null) _lblRemainingTime.Text = "نامحدود";
                }

                if (_lblUsedTime != null)
                    _lblUsedTime.Text = $"{(int)used.TotalHours:00}:{used.Minutes:00}:{used.Seconds:00}";

                // REAL price from the billing engine (SessionCost updates on
                // every BillingCycle tick — see ClientCommunicator line ~1300).
                if (_lblPrice != null)
                    _lblPrice.Text = $"{target.Cost:N0} تومان";

                // Reflect Play and Pay state from the live connection
                if (_chkPlayAndPay != null && _chkPlayAndPay.Checked != target.PlayAndPay)
                    _chkPlayAndPay.Checked = target.PlayAndPay;
            }
            catch { }
        }

        /// <summary>
        /// FIX 6 — Refreshes the live camera preview panel in the bottom
        /// panel. Since we don't have a screenshot cache on the server side
        /// (screenshots arrive async via OnScreenshotReceived and are only
        /// consumed by the ScreenshotViewerForm), we instead show the
        /// selected station's live state as a text label inside the camera
        /// panel: station name + active game + active window title. The
        /// "📷 اسکرین‌شات" button still calls RequestScreenshot for the
        /// selected station so the operator can pull a fresh frame.
        /// </summary>
        private void RefreshCameraPreview()
        {
            if (_cameraLabel == null) return;
            try
            {
                var conns = _communicator?.GetAllRawConnections();
                if (conns == null || conns.Count == 0)
                {
                    _cameraLabel.Text = "📷 پیش‌نمایش دوربین\n(کلاینتی متصل نیست)";
                    return;
                }

                // Same selection logic as RefreshSidebarLive — prefer the
                // explicitly-selected station, then the first user-active
                // connection, then the first connection.
                var target = conns.FirstOrDefault(c => c.StationName == _selectedStation);
                if (target.StationName == null)
                    target = conns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                if (target.StationName == null) target = conns[0];

                string station = string.IsNullOrEmpty(target.StationName) ? "—" : target.StationName;
                string game = !string.IsNullOrEmpty(target.Game) ? target.Game : "—";
                string window = !string.IsNullOrEmpty(target.ActiveWindow) ? target.ActiveWindow : "—";

                // Truncate long window titles so the label stays readable in
                // the 220px-wide camera panel.
                if (window.Length > 28) window = window.Substring(0, 27) + "…";

                _cameraLabel.Text = $"🖥️ {station}\n🎮 {game}\n🪟 {window}";
            }
            catch { }
        }

        /// <summary>
        /// FIX H3 — Renders a screenshot received from a kiosk into the
        /// bottom-panel _cameraPreview pane. Replaces the static camera icon
        /// with the live image and updates the label with the capture time.
        /// The previous static icon is hidden while a screenshot is on display.
        /// </summary>
        private void DisplayScreenshotInPreview(string station, ScreenshotResponsePayload payload)
        {
            if (_cameraPreview == null) return;
            if (payload == null || !payload.Success || string.IsNullOrEmpty(payload.ImageBase64)) return;
            try
            {
                byte[] bytes = Convert.FromBase64String(payload.ImageBase64);
                Image img;
                // FIX (FIX-FINAL-10 B3): do NOT dispose the MemoryStream.
                // Image.FromStream keeps a reference to the stream and reads
                // from it lazily on later draw operations. Disposing the
                // stream (via `using`) immediately after FromStream returns
                // leaves the Image holding a disposed stream — the next
                // PictureBox paint throws ArgumentException ("Parameter is
                // not valid") on some GDI+ paths and silently renders a
                // blank box on others. Let the Image own the stream; it
                // will be disposed when the PictureBox.Image is replaced
                // (the previous Image.Dispose() call above) or when the
                // form closes.
                var ms = new System.IO.MemoryStream(bytes);
                img = Image.FromStream(ms);
                if (img == null) return;

                // Reuse a single PictureBox — dispose the previous image.
                var pb = _cameraPreview.Controls.OfType<PictureBox>().FirstOrDefault();
                if (pb == null)
                {
                    pb = new PictureBox
                    {
                        Location = new Point(8, 6),
                        Size = new Size(_cameraPreview.Width - 16, _cameraPreview.Height - 50),
                        SizeMode = PictureBoxSizeMode.Zoom,
                        BackColor = Color.Black,
                    };
                    _cameraPreview.Controls.Add(pb);
                    pb.BringToFront();
                }
                if (pb.Image != null) { try { pb.Image.Dispose(); } catch { } }
                pb.Image = img;

                if (_cameraLabel != null)
                    _cameraLabel.Text = $"📷 {station}\n{payload.CapturedAt.ToLocalTime():HH:mm:ss}  •  {bytes.Length / 1024} KB";
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "DisplayScreenshotInPreview error: " + ex.Message); }
        }

        /// <summary>
        /// Refreshes the bottom activity log with REAL data from connected
        /// clients: each row shows the time, the active window title, the
        /// current game (as Application column), and the station name.
        /// FIX L1: the Url column was removed (always "—" before).
        /// </summary>
        private void RefreshActivityLog()
        {
            if (_activityGrid == null) return;
            try
            {
                var conns = _communicator?.GetAllRawConnections();
                if (conns == null) return;

                // Build rows only for clients that have an active window or game.
                var rows = new List<(DateTime Time, string Title, string Applic, string PC)>();
                foreach (var c in conns)
                {
                    if (string.IsNullOrEmpty(c.User) || c.User == "-") continue;
                    string title = !string.IsNullOrEmpty(c.ActiveWindow) ? c.ActiveWindow :
                                   !string.IsNullOrEmpty(c.Game) ? c.Game : "—";
                    string applic = !string.IsNullOrEmpty(c.Game) ? c.Game : "—";
                    rows.Add((c.LastHeartbeat, title, applic, c.StationName));
                }

                // Only rebuild if the data actually changed (avoids flicker).
                if (_activityGrid.RowCount != rows.Count)
                {
                    _activityGrid.Rows.Clear();
                    foreach (var r in rows)
                        _activityGrid.Rows.Add(r.Time.ToString("HH:mm:ss"), r.Title, r.Applic, r.PC);
                }
                else
                {
                    for (int i = 0; i < rows.Count; i++)
                    {
                        _activityGrid.Rows[i].Cells[0].Value = rows[i].Time.ToString("HH:mm:ss");
                        _activityGrid.Rows[i].Cells[1].Value = rows[i].Title;
                        _activityGrid.Rows[i].Cells[2].Value = rows[i].Applic;
                        _activityGrid.Rows[i].Cells[3].Value = rows[i].PC;
                    }
                }
            }
            catch { }
        }

        /// <summary>Acts on the first connected station (selected client).</summary>
        private void ActOnSelectedStation(Action<string> action)
        {
            try
            {
                var conns = _communicator?.GetAllRawConnections();
                if (conns == null) return;
                // FIX 11: guard against empty list — conns[0] below would throw IndexOutOfRangeException.
                if (conns.Count == 0)
                {
                    MessageBox.Show("هیچ کلاینتی متصل نیست.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                string target = null;
                // Prefer the explicitly-selected station.
                if (!string.IsNullOrEmpty(_selectedStation))
                {
                    target = conns.FirstOrDefault(c => c.StationName == _selectedStation).StationName;
                }
                // Fall back to the label text (legacy).
                if (string.IsNullOrEmpty(target))
                {
                    string sel = _lblSelectedStation?.Text ?? "";
                    if (sel.Contains(":"))
                    {
                        var part = sel.Substring(sel.IndexOf(':') + 1).Trim();
                        if (!string.IsNullOrEmpty(part) && part != "---") target = part;
                    }
                }
                // Fall back to first station with an active user, else first.
                if (string.IsNullOrEmpty(target))
                {
                    var first = conns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                    if (first.StationName == null) first = conns[0];
                    target = first.StationName;
                }
                if (string.IsNullOrEmpty(target))
                {
                    MessageBox.Show("هیچ کلاینتی انتخاب نشده است.", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _selectedStation = target;
                action(target);
            }
            catch (Exception ex) { AuditLog.Log("MainForm", "ActOnSelectedStation error: " + ex.Message); }
        }

        private void AddTimeToSelected(int minutes)
        {
            if (minutes <= 0) return;
            ActOnSelectedStation(st => _communicator.SetSessionTime(st, 1, minutes, "افزایش زمان از نوار کناری"));
        }

        private class DarkStatusRenderer : ToolStripProfessionalRenderer
        {
            public DarkStatusRenderer() : base(new DarkColorTable()) { }
        }

        /// <summary>
        /// Handles clicks on the secondary action toolbar buttons. Each icon
        /// name maps to a quick action — either switching to a tab, refreshing
        /// the client list, or invoking a per-client operation via the
        /// communicator.
        /// </summary>
        private void HandleSecondaryAction(string iconName)
        {
            try
            {
                switch (iconName)
                {
                    case "play":
                    case "stop":
                    case "refresh":
                    case "undo":
                    case "redo":
                    case "smiley":
                    case "profile":
                    case "camera":
                    case "screen":
                    case "globe":
                    case "close":
                    case "record":
                    case "power":
                        // Per-client actions: pick the first connected station
                        // as the "selected" one (so the sidebar shows its live
                        // data) and switch to the clients tab.
                        try
                        {
                            var conns = _communicator?.GetAllRawConnections();
                            if (conns != null && conns.Count > 0)
                            {
                                var first = conns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                                if (first.StationName == null) first = conns[0];
                                _selectedStation = first.StationName;
                            }
                        }
                        catch { }
                        SwitchToTab("clients");
                        RefreshSidebarLive();
                        UpdateStatusBar();
                        break;
                    case "printer":
                        SwitchToTab("print");
                        break;
                    case "save":
                        SwitchToTab("backup");
                        break;
                    case "folder":
                        SwitchToTab("backup");
                        break;
                    case "newpage":
                        SwitchToTab("dashboard");
                        break;
                    case "search":
                        SwitchToTab("users");
                        break;
                    case "database":
                        SwitchToTab("backup");
                        break;
                    case "refresh_user":
                        SwitchToTab("users");
                        break;
                    case "sync":
                        // Distribute update to all connected clients.
                        DistributeUpdateToAllClients();
                        break;
                    case "help":
                        MessageBox.Show(
                            "🎮 markazbazi\n\n" +
                            "نوار ابزار بالا (۸ دکمه): ماژول‌های اصلی\n" +
                            "نوار ابزار پایین (۲۱ دکمه): عملیات سریع روی کلاینت\n" +
                            "منوی Tools: همه ماژول‌های دیگر\n\n" +
                            "برای راهنمایی بیشتر با پشتیبانی تماس بگیرید.",
                            "راهنما", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }
            }
            catch { }
        }

        /// <summary>Switches the hidden TabControl to the tab with the given key.</summary>
        private void SwitchToTab(string key)
        {
            foreach (TabPage page in _tabs.TabPages)
            {
                if ((string)page.Tag == key) { _tabs.SelectedTab = page; return; }
            }
        }

        /// <summary>
        /// Distributes the latest client update (from the "updates" folder
        /// next to the server exe) to ALL connected clients. The operator
        /// drops the new markazbazi.Client.exe into the "updates" folder, then
        /// clicks the "🔄 آپدیت همه کلاینت‌ها" button — every connected
        /// kiosk downloads and installs the new version over the network.
        ///
        /// FIX-MINOR-UPDATE IMPROVE A: the method is now smarter:
        ///  - If no update file is staged, instead of just showing a help
        ///    MessageBox, it offers a file picker (📁 انتخاب فایل...) so the
        ///    operator can pick a client exe from anywhere on disk. The
        ///    picked file is copied into updates/markazbazi.Client.exe and its
        ///    embedded FileVersion is written to updates/version.txt.
        ///  - The confirmation dialog also has a "📁 انتخاب فایل..." button
        ///    (MessageBox.YesNoCancel repurposed) so the operator can swap
        ///    the staged exe even when one is already present.
        ///  - After successful distribution, a Toast is shown with the
        ///    count (was already a Toast; kept as a Toast, not a MessageBox).
        /// </summary>
        private void DistributeUpdateToAllClients()
        {
            try
            {
                // Check how many clients are connected.
                var conns = _communicator?.GetAllRawConnections();
                int count = conns?.Count ?? 0;
                if (count == 0)
                {
                    MessageBox.Show(
                        "❌ هیچ کلاینتی متصل نیست.\n" +
                        "ابتدا کلاینت‌ها را روشن کنید تا به سرور متصل شوند، سپس دوباره تلاش کنید.",
                        "توزیع آپدیت", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var upd = new UpdateDistributor();
                var offer = upd.GetLatestUpdate();

                // If no update file is staged, offer the file picker right away.
                if (offer == null)
                {
                    string updatesDir = upd.GetUpdatesDir();
                    var pickResult = MessageBox.Show(
                        "❌ هیچ فایل آپدیتی در پوشه updates پیدا نشد.\n\n" +
                        "📁 می‌خواهید یک فایل GameNet.Client.exe انتخاب کنید؟\n" +
                        "(فایل انتخاب‌شده به‌صورت خودکار در پوشه updates کپی می‌شود)\n\n" +
                        "پوشه updates:\n" + updatesDir,
                        "توزیع آپدیت",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button1);
                    if (pickResult != DialogResult.Yes) return;
                    if (!PickAndStageClientExe(upd)) return;
                    offer = upd.GetLatestUpdate();
                    if (offer == null)
                    {
                        ToastNotification.Show(this,
                            "❌ هنوز هیچ فایل آپدیتی موجود نیست.",
                            ToastType.Error, 4000);
                        return;
                    }
                }

                // Confirm with the operator. Yes = distribute now; Cancel = pick
                // a different file; No = abort.
                var result = MessageBox.Show(
                    $"🔄 آماده توزیع آپدیت به {count} کلاینت متصل.\n\n" +
                    $"📦 نسخه: {offer.Version}\n" +
                    $"📊 حجم: {offer.FileSize:N0} بایت\n" +
                    $"📝 توضیح: {offer.ReleaseNotes ?? "(بدون توضیح)"}\n" +
                    $"⚠️ اجباری: {(offer.IsMandatory ? "بله" : "خیر")}\n\n" +
                    "✅ بله = ارسال همین آپدیت\n" +
                    "📁 انصراف = لغو\n" +
                    "(برای انتخاب فایل دیگر، ابتدا فایل را در پوشه updates کپی کنید)",
                    "تأیید توزیع آپدیت",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2);

                if (result != DialogResult.Yes) return;

                // Distribute! This runs in a background thread so the UI
                // doesn't freeze while streaming large files.
                System.Threading.Tasks.Task.Run(() =>
                {
                    try
                    {
                        _communicator.OfferUpdateToAll();
                        AuditLog.Log("Update", $"Distributed update v{offer.Version} to {count} clients");
                        this.BeginInvoke((Action)(() =>
                        {
                            // ADD-TOAST-THEME Feature 1: success toast instead
                            // of a modal MessageBox. The distribution runs in
                            // the background; a non-blocking toast lets the
                            // operator keep monitoring while clients download.
                            ToastNotification.Show(this,
                                $"✅ آپدیت توزیع شد\nv{offer.Version} → {count} کلاینت",
                                ToastType.Success, 4000);
                        }));
                    }
                    catch (Exception ex)
                    {
                        AuditLog.Log("Update", "Distribute error: " + ex.Message);
                        this.BeginInvoke((Action)(() =>
                        {
                            // ADD-TOAST-THEME Feature 1: error toast for non-
                            // critical distribution failures. The exception is
                            // already logged to the audit trail; a modal dialog
                            // would just block the operator from continuing.
                            ToastNotification.Show(this,
                                "❌ خطا در توزیع آپدیت: " + ex.Message,
                                ToastType.Error, 5000);
                        }));
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا: " + ex.Message, "توزیع آپدیت",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// FIX-MINOR-UPDATE IMPROVE A: shows a file picker, copies the
        /// selected client exe to updates/markazbazi.Client.exe, and writes
        /// its embedded FileVersion to updates/version.txt. Returns true
        /// if a file was staged; false if the user cancelled or the copy
        /// failed.
        /// </summary>
        private bool PickAndStageClientExe(UpdateDistributor upd)
        {
            try
            {
                using (var ofd = new OpenFileDialog())
                {
                    ofd.Title = "انتخاب GameNet.Client.exe";
                    ofd.Filter = "Client executable (*.exe)|*.exe|All files (*.*)|*.*";
                    ofd.FileName = "GameNet.Client.exe";
                    if (ofd.ShowDialog() != DialogResult.OK) return false;
                    string updatesDir = upd.GetUpdatesDir();
                    try { System.IO.Directory.CreateDirectory(updatesDir); } catch { }
                    // The name must match UpdateDistributor's "GameNet.Client*.exe" search.
                    string destPath = System.IO.Path.Combine(updatesDir, "GameNet.Client.exe");
                    System.IO.File.Copy(ofd.FileName, destPath, true);
                    // Fix 2: an update is offered only together with its detached signature
                    // (GameNet.Client.exe.sig, written by tools\Sign-Update.ps1). Carry it along.
                    string srcSig = ofd.FileName + ".sig";
                    string dstSig = destPath + ".sig";
                    if (System.IO.File.Exists(srcSig))
                    {
                        System.IO.File.Copy(srcSig, dstSig, true);
                    }
                    else
                    {
                        try { if (System.IO.File.Exists(dstSig)) System.IO.File.Delete(dstSig); } catch { }
                        ToastNotification.Show(this,
                            "⚠️ فایل .sig کنار exe پیدا نشد؛ آپدیت توزیع نمی‌شود.\nابتدا tools\\Sign-Update.ps1 را اجرا کنید.",
                            ToastType.Warning, 6000);
                        return false;
                    }
                    // Auto-detect the version from the exe's FileVersionInfo
                    // and persist it to version.txt so the next call to
                    // GetLatestUpdate reports the right version.
                    try
                    {
                        var ver = System.Diagnostics.FileVersionInfo.GetVersionInfo(destPath);
                        string version = ver.FileVersion;
                        if (string.IsNullOrEmpty(version)) version = ver.ProductVersion;
                        if (string.IsNullOrEmpty(version)) version = "1.0";
                        string versionFile = System.IO.Path.Combine(updatesDir, "version.txt");
                        System.IO.File.WriteAllText(versionFile, version);
                        AuditLog.Log("Update", $"Staged client exe from {ofd.FileName} → updates/markazbazi.Client.exe (v{version})");
                        ToastNotification.Show(this,
                            $"✅ فایل کلاینت کپی شد\nنسخه: {version}",
                            ToastType.Success, 3000);
                    }
                    catch
                    {
                        AuditLog.Log("Update", $"Staged client exe from {ofd.FileName} (version detection failed)");
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در کپی فایل: " + ex.Message,
                    "توزیع آپدیت", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Adds a ToolStripMenuItem that opens the given module tab when clicked.
        /// Used to populate the File/Reporting/Tools menus.
        /// </summary>
        // BUG FIX (language switching): every dropdown item's label used to
        // be a fixed string typed once at menu-construction time, with no
        // English/Arabic variant, and even the few that had translations
        // only evaluated them once, never again when the language changed
        // afterward. Now every item's Tag is its tab key, and its Text
        // comes from the existing GetTabTitle(key, lang) table, both at
        // creation time and again whenever ApplyLanguage()/LocalizeMenuTree
        // runs.
        private void AddMenuModule(ToolStripMenuItem parent, string key, Color accent)
        {
            var item = new ToolStripMenuItem(GetTabTitle(key, _localization.CurrentLanguage), null, (s, e) =>
            {
                OpenModuleByKey(key);
            }) { ForeColor = ThemeManager.ThemedAccent(accent), BackColor = ThemeManager.SurfaceColor, Tag = key };
            parent.DropDownItems.Add(item);
        }

        /// <summary>
        /// Recursively walks a menu's items (including nested DropDownItems,
        /// e.g. a "More…" submenu) and re-localizes every item whose Tag is
        /// a tab key. Static chrome items (File, Reporting, PRO, etc.) carry
        /// a (fa,en,ar) tuple in Tag instead.
        /// </summary>
        private void LocalizeMenuTree(ToolStripItemCollection items, string lang)
        {
            bool isFaLoc = (lang == "fa");
            bool isEnLoc = (lang == "en");
            foreach (ToolStripItem it in items)
            {
                if (!(it is ToolStripMenuItem mi)) continue;
                if (mi.Tag is string key)
                    mi.Text = GetTabTitle(key, lang);
                else if (mi.Tag is ValueTuple<string, string, string> t)
                    mi.Text = isFaLoc ? t.Item1 : isEnLoc ? t.Item2 : t.Item3;
                if (mi.DropDownItems.Count > 0)
                    LocalizeMenuTree(mi.DropDownItems, lang);
            }
        }

        /// <summary>
        /// Opens (switches to + loads) the module identified by key.
        /// FIX PRO-NOT-WORKING: calls EnsureTabContent DIRECTLY after setting
        /// SelectedTab instead of relying on SelectedIndexChanged.
        /// </summary>
        private void OpenModuleByKey(string key)
        {
            try
            {
                // FIX PRO-DEBUG: log every click so we can see if the menu
                // item is actually being clicked.
                try { AuditLog.Log("MainForm", "OpenModuleByKey called for key: " + key); } catch { }

                foreach (TabPage page in _tabs.TabPages)
                {
                    if ((string)page.Tag == key)
                    {
                        _tabs.SelectedTab = page;
                        EnsureTabContent(page, key);
                        return;
                    }
                }
                // FIX PRO-DEBUG: if we get here, the tab page wasn't found.
                try { AuditLog.Log("MainForm", "WARNING: tab page not found for key: " + key); } catch { }
            }
            catch (Exception ex)
            {
                try { AuditLog.Log("MainForm", "OpenModuleByKey failed for '" + key + "': " + ex.Message); } catch { }
            }
        }

        // ============================================================
        //  Helpers for the new View / Tools / Help menu items
        // ============================================================

        /// <summary>
        /// Switches the monitoring view mode (Iconic / Detailed / Grid).
        /// For now this just stores the mode and shows a confirmation, since
        /// the actual ClientMonitorForm already provides its own view modes
        /// via its toolbar. Real view switching can be wired later by reading
        /// _monitoringMode from the embedded form.
        /// </summary>
        private string _monitoringMode = "iconic";
        private void SetMonitoringMode(string mode)
        {
            _monitoringMode = mode;
            string labelFa = mode == "iconic" ? "آیکونی" : mode == "detailed" ? "جزئیات" : "شبکه‌ای";
            try { AuditLog.Log("MainForm", "Monitoring view mode set to " + mode); } catch { }
            MessageBox.Show("نمایش مانیتورینگ به حالت «" + labelFa + "» تغییر یافت.",
                "نمایش", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>Shortcuts tab view mode (same idea as monitoring mode).</summary>
        private string _shortcutsViewMode = "iconic";
        private void SetShortcutsViewMode(string mode)
        {
            _shortcutsViewMode = mode;
            string labelFa = mode == "iconic" ? "آیکونی" : mode == "detailed" ? "جزئیات" : "شبکه‌ای";
            try { AuditLog.Log("MainForm", "Shortcuts view mode set to " + mode); } catch { }
            MessageBox.Show("نمایش میانبرها به حالت «" + labelFa + "» تغییر یافت.",
                "نمایش", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Sends a Wake-on-LAN magic packet to a single station identified by
        /// its name. Looks up the MAC in the stations table; if not found,
        /// also accepts a raw MAC address typed by the operator.
        /// </summary>
        private void WakeStationByName(string station)
        {
            try
            {
                string mac = null;
                try
                {
                    // First: look up by station name in the DB.
                    mac = Database.Instance.QueryOne(
                        "SELECT mac_address FROM stations WHERE name = @n AND mac_address IS NOT NULL AND mac_address != ''",
                        cmd => cmd.Parameters.AddWithValue("@n", station),
                        r => r.GetString(0));
                }
                catch { /* not found */ }

                // If not found in DB, allow the operator to pass a raw MAC.
                if (string.IsNullOrEmpty(mac) && WakeOnLan.IsValidMacAddress(station))
                    mac = station;

                if (string.IsNullOrEmpty(mac))
                {
                    MessageBox.Show(
                        "❌ ایستگاهی با نام «" + station + "» پیدا نشد،\n" +
                        "و مقدار واردشده یک آدرس MAC معتبر نیست.\n\n" +
                        "نکته: می‌توانید مستقیماً آدرس MAC (مثل 00:11:22:33:44:55) وارد کنید.",
                        "روشن کردن کلاینت", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool ok = WakeOnLan.SendMagicPacket(mac);
                if (ok)
                {
                    try { AuditLog.Log("Network", "WakeOne: sent to " + station + " (MAC " + mac + ")"); } catch { }
                    MessageBox.Show("✅ دستور Wake-on-LAN به ایستگاه «" + station + "» ارسال شد.\nMAC: " + mac,
                        "روشن کردن کلاینت", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("⚠️ ارسال بسته جادویی ناموفق بود.", "خطا",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Applies the chosen font to the MainForm's title, menu strip,
        /// toolbars, sidebar, tabs and status strip. Does NOT recurse into
        /// embedded child forms — those keep their own fonts.
        /// </summary>
        private void ApplyFontToMainControls(Font font)
        {
            try
            {
                this.Font = font;
                // Walk top-level controls; only restyle the chrome (menu,
                // toolbars, sidebar, tabs, status strip). Skip embedded forms
                // so each module keeps its own typographic identity.
                foreach (Control c in this.Controls)
                {
                    if (c is MenuStrip || c is StatusStrip || c is TabControl)
                    { c.Font = font; continue; }

                    if (c is Panel)
                    {
                        // Toolbar / sidebar / bottom panel — apply and recurse
                        // one level for labels & buttons only (skip DataGridViews).
                        ApplyFontRecursive(c, font, depth: 0);
                    }
                }
            }
            catch { }
        }

        private static void ApplyFontRecursive(Control parent, Font font, int depth)
        {
            if (depth > 3) return;
            try
            {
                if (!(parent is DataGridView))
                    parent.Font = font;
                foreach (Control c in parent.Controls)
                    ApplyFontRecursive(c, font, depth + 1);
            }
            catch { }
        }

        /// <summary>
        /// Custom renderer for the MenuStrip so dropdowns match the dark
        /// glassmorphism theme (otherwise WinForms draws them white).
        /// </summary>
        private class DarkMenuRenderer : ToolStripProfessionalRenderer
        {
            public DarkMenuRenderer() : base(new DarkColorTable()) { }
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                Color bg = e.Item.Selected ? Color.FromArgb(220, 220, 225) : Color.FromArgb(230, 230, 235);
                using (var b = new SolidBrush(bg))
                    e.Graphics.FillRectangle(b, rc);
            }
        }

        private class DarkColorTable : ProfessionalColorTable
        {
            public override Color MenuBorder => Color.FromArgb(220, 220, 225);
            public override Color MenuItemBorder => Color.FromArgb(220, 220, 225);
            public override Color MenuItemSelected => Color.FromArgb(220, 220, 225);
            public override Color MenuStripGradientBegin => Color.FromArgb(225, 225, 230);
            public override Color MenuStripGradientEnd => Color.FromArgb(225, 225, 230);
            public override Color ToolStripDropDownBackground => Color.FromArgb(230, 230, 235);
            public override Color ImageMarginGradientBegin => Color.FromArgb(230, 230, 235);
            public override Color ImageMarginGradientMiddle => Color.FromArgb(230, 230, 235);
            public override Color ImageMarginGradientEnd => Color.FromArgb(230, 230, 235);
        }

        /// <summary>
        /// Creates the embedded form for the given tab key if it hasn't been
        /// created yet, and docks it to fill the tab page.
        /// </summary>
        // Round 14: buttons whose text says they change something (save, apply, add,
        // delete, edit, reset, enable/disable) are journalled with the tab's name.
        private static readonly string[] JournalButtonWords =
        {
            "ذخیره", "اعمال", "تأیید", "تایید", "ثبت", "افزودن", "اضافه", "حذف", "ویرایش", "بازنشانی",
            "فعال", "غیرفعال", "لغو", "تغییر", "شارژ", "پرداخت", "بازگردانی", "ارسال",
            "Save", "Apply", "Add", "Delete", "Remove", "Edit", "Reset", "Enable", "Disable", "Restore", "Send",
        };

        private void HookJournalButtons(Control root, string tabTitle)
        {
            foreach (Control c in root.Controls)
            {
                var b = c as Button;
                if (b != null && !string.IsNullOrWhiteSpace(b.Text))
                {
                    string t = b.Text;
                    bool match = false;
                    foreach (var w in JournalButtonWords)
                        if (t.IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0) { match = true; break; }
                    if (match)
                    {
                        var btn = b;
                        btn.Click += (s, e) =>
                        {
                            try { ActivityJournal.Record(ActivityJournal.Settings, "«" + tabTitle + "» › دکمهٔ «" + btn.Text.Trim() + "»"); } catch { }
                        };
                    }
                }
                if (c.HasChildren) HookJournalButtons(c, tabTitle);
            }
        }

        // Round 14: who is logged in, for the journal; and the "since you left" notice.
        private static string JournalName(Operator op)
        {
            if (op == null) return "";
            return string.IsNullOrWhiteSpace(op.DisplayName) ? op.Username : op.DisplayName + " (" + op.Username + ")";
        }

        private void JournalLogin(Operator op)
        {
            try
            {
                string name = JournalName(op);
                DateTime? left = ActivityJournal.LastLeaveOf(name);
                ActivityJournal.CurrentOperator = name;
                ActivityJournal.Record(ActivityJournal.Operator, "ورود اپراتور «" + name + "»");
                if (left.HasValue)
                {
                    int n = ActivityJournal.CountSince(left.Value.AddTicks(1)) - 1; // after the leave line, minus this login
                    if (n > 0)
                    {
                        var shown = left.Value.ToLocalTime();
                        BeginInvoke((Action)(() =>
                        {
                            try
                            {
                                ToastNotification.Show(this, "🕵️ از آخرین خروج شما (" + shown.ToString("MM/dd HH:mm") + ") " + n +
                                    " رخداد ثبت شده.\nتب «🕵️ وقتی نبودم» در گروه گزارش.", ToastType.Info, 9000);
                            }
                            catch { }
                        }));
                    }
                }
            }
            catch { }
        }

        // Round 14: tabs that currently show the "no access" text.
        private readonly HashSet<string> _deniedTabs = new HashSet<string>();
        private DateTime _lastTabLogAt = DateTime.MinValue;
        private string _lastTabLogKey;

        private void EnsureTabContent(TabPage page, string key)
        {
            if (_embeddedForms.ContainsKey(key)) return;

            // Permission check
            var def = _tabDefs.Find(t => t.Key == key);
            if (def == null) return;
            // Round 14: a tab that showed "no access" before is cleared first. The old
            // label used to stay on top of the page and hid the module even after a
            // proper login (the PRO tabs looked dead), and every visit added another
            // label and another message box.
            if (_deniedTabs.Remove(key)) page.Controls.Clear();
            bool allowed = _currentOperator != null && _currentOperator.IsActive &&
                           _operatorManager.HasPermission(_currentOperator, def.Permission);
            if (!allowed)
            {
                _deniedTabs.Add(key);
                try { AuditLog.Log("MainForm", $"Access denied: operator {_currentOperator?.Username ?? "(none)"} lacks permission {def.Permission}"); } catch { }
                try { if (_currentOperator != null) IntrusionDetectionSystem.RecordPermissionDenied(_currentOperator.Username, def.Permission.ToString()); } catch { }
                // Show an access-denied message inside the tab
                var lbl = new Label
                {
                    Text = _currentOperator == null
                        ? "🔒 ابتدا به عنوان اپراتور وارد شوید (دکمهٔ بالای صفحه)."
                        : "🔒 حساب «" + _currentOperator.DisplayName + "» به این بخش دسترسی ندارد.\nمدیر سیستم می‌تواند در «اپراتورها» این دسترسی را بدهد: " + def.Permission,
                    Font = new Font("Segoe UI", 12F),
                    ForeColor = Color.FromArgb(200, 30, 60),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Dock = DockStyle.Fill,
                };
                page.Controls.Add(lbl);
                return;
            }

            Form form = null;
            try
            {
                form = CreateFormForKey(key);
            }
            catch (Exception ex)
            {
                var lbl = new Label
                {
                    Text = "خطا در بارگذاری این بخش:\n" + ex.Message,
                    Font = new Font("Segoe UI", 11F),
                    ForeColor = Color.FromArgb(200, 30, 60),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Dock = DockStyle.Fill,
                };
                page.Controls.Add(lbl);
                _deniedTabs.Add(key); // round 14: cleared and retried on the next visit
                AuditLog.Log("MainForm", "Error loading tab " + key + ": " + ex.Message);
                return;
            }

            if (form == null)
            {
                var lbl = new Label
                {
                    Text = "این بخش هنوز پیاده‌سازی نشده است.",
                    Tag = "placeholder",
                    Font = new Font("Segoe UI", 11F),
                    ForeColor = Color.FromArgb(180, 140, 20),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Dock = DockStyle.Fill,
                };
                page.Controls.Add(lbl);
                _deniedTabs.Add(key); // round 14: no second label on the next visit
                return;
            }

            // Embed the form inside the tab page.
            //
            // BUG FIX (layout — "boxes not centered / off to one side /
            // sticking out past the edge of the screen"): every one of
            // these forms was originally designed as an independent,
            // top-level dialog (its own StartPosition, and — critically —
            // its own MinimumSize/MaximumSize baked in by the designer).
            // Setting Dock = DockStyle.Fill on the form (below) is supposed
            // to make it resize to exactly match this tab's content area,
            // but Windows Forms will NEVER shrink a Fill-docked control
            // below its own MinimumSize, and never grows it past
            // MaximumSize if one is set. Those constraints were never
            // cleared when a form got repurposed as embedded content, so
            // any form whose original dialog size (e.g. 1000x600) was
            // larger than the actual tab area kept that size regardless of
            // Dock=Fill — overflowing past the visible area, or sitting at
            // whatever position the AutoScroll host happened to place a
            // too-large child. Clearing both constraints here lets
            // Dock=Fill do what its own comment already claimed it did.
            //
            // This also removes the previous "drag handle" — a title bar
            // that let the operator manually drag the form to reposition
            // it. That was a workaround for this exact sizing bug, but it
            // could never actually work: a control with Dock=Fill has its
            // Location recalculated by the layout engine on every layout
            // pass, so assigning form.Location from a MouseMove handler was
            // a silent no-op. It also permanently consumed 22px at the top
            // of every single tab for a control that did nothing.
            form.TopLevel = false;
            // Round 5 (FIX EMBEDDED-VISIBILITY, ported from the other source line):
            // some module forms set WindowState = Maximized in their own constructors
            // (ClientMonitorForm does). The other line's live test showed that such a
            // form stays invisible inside its TabPage (Visible = false, screen-sized),
            // so the "clients" tab looked empty. Every embedded form is reset to
            // Normal before it is hosted.
            form.WindowState = FormWindowState.Normal;
            form.FormBorderStyle = FormBorderStyle.None;
            form.MinimumSize = Size.Empty;
            form.MaximumSize = Size.Empty;
            form.AutoScroll = false;
            form.Visible = true;

            // === Scrollable content host ===
            var host = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(255, 255, 255),
                AutoScroll = true,
            };

            form.Dock = DockStyle.Fill;
            host.Controls.Add(form);
            // Round 14: journal the module's own save/apply/add/delete buttons.
            try { HookJournalButtons(form, def.Title); } catch { }

            // === Decide whether this module needs a confirmation bar ===
            // Only modules that EDIT settings (and have a save method or
            // save button) get the "تایید / بازنشانی / بستن" bar. View-only
            // modules (dashboard, client monitor, reports, chat, etc.) just
            // get a single "بستن" button so the user can navigate away.
            var needsConfirm = new HashSet<string>
            {
                "extensions",   // ExtensionsForm — has Save (birthday rewards, referral, telegram, theme, billing, backup, report)
                "backup",       // BackupForm — JSON backup + restore
                "theme",        // ThemeForm — server theme settings
                "loyalty",      // LoyaltyForm — loyalty + discount settings
                "payment",      // PaymentForm — payment gateway config
                "api",          // ApiPanelForm — API key + endpoints
                "features",     // FeatureToggleForm — 28 client feature toggles
                "pricing",      // PricingForm — pricing tiers
                "smartprice",   // SmartPricingForm — smart pricing rules
                "security",     // SecurityForm — security settings
                "secdash",      // SecurityDashboardForm — security dashboard config
                "licenses",     // ClientLicenseForm — license management
                "branches",     // BranchForm — branch management
                "tiers",        // MemberTierForm — membership tier config
                "packages",     // SessionPackageForm — session package config
                "winharden",    // WindowsHardeningForm — Windows hardening settings
                "restrictions", // RestrictionsForm — Windows restrictions editor (saves to restrictions.json)
                "clientoptions",// ClientOptionsForm — client kiosk settings (saves to client_options.json)
                "updates",      // UpdateDistributionForm — update settings
                "stations",     // StationManagementForm — station config
                "equipment",    // EquipmentForm — equipment config
                "consoles",     // ConsoleReservationForm — console config
            };
            // View-only modules (no confirmation bar, just a close button):
            //   dashboard, clients, users, tickets, debt, print, chat,
            //   announce, queue, reports, advreports, revenue, secalerts

            if (needsConfirm.Contains(key))
            {
                // === Confirmation bar (bottom of tab page) ===
                // Shows "✅ تایید" + "↩️ بازنشانی" + "✖️ بستن" — only for modules
                // that edit settings.
                var confirmBar = new Panel
                {
                    Dock = DockStyle.Bottom,
                    Height = 40,
                    BackColor = Color.FromArgb(225, 225, 230),
                    Padding = new Padding(12, 4, 12, 4),
                };

                var btnConfirm = new Button
                {
                    Text = "✅ تایید تنظیمات",
                    Size = new Size(160, 34),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(166, 227, 161),
                    ForeColor = Color.FromArgb(225, 225, 230),
                    Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    TextAlign = ContentAlignment.MiddleCenter,
                };
                btnConfirm.FlatAppearance.BorderSize = 0;

                var btnReset = new Button
                {
                    Text = "↩️ بازنشانی",
                    Size = new Size(120, 34),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(249, 226, 175),
                    ForeColor = Color.FromArgb(225, 225, 230),
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    TextAlign = ContentAlignment.MiddleCenter,
                };
                btnReset.FlatAppearance.BorderSize = 0;

                var btnClose = new Button
                {
                    Text = "✖️ بستن",
                    Size = new Size(100, 34),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(243, 139, 168),
                    ForeColor = Color.FromArgb(225, 225, 230),
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    TextAlign = ContentAlignment.MiddleCenter,
                };
                btnClose.FlatAppearance.BorderSize = 0;

                EventHandler layoutButtons = (s, e) =>
                {
                    int y = (confirmBar.Height - 34) / 2;
                    btnClose.Location = new Point(12, y);
                    btnReset.Location = new Point(12 + 100 + 8, y);
                    btnConfirm.Location = new Point(confirmBar.Width - 160 - 12, y);
                };
                confirmBar.Resize += layoutButtons;
                confirmBar.Controls.Add(btnConfirm);
                confirmBar.Controls.Add(btnReset);
                confirmBar.Controls.Add(btnClose);

                btnConfirm.Click += (s, e) =>
                {
                    try { ActivityJournal.Record(ActivityJournal.Settings, "تأیید تنظیمات تب «" + def.Title + "»"); } catch { } // round 14
                    try
                    {
                        bool saved = false;
                        string[] methodNames = { "Save", "SaveAll", "Apply", "SaveSettings",
                                                  "SaveChanges", "Commit", "Submit", "ذخیره" };
                        foreach (var name in methodNames)
                        {
                            var mi = form.GetType().GetMethod(name,
                                System.Reflection.BindingFlags.Public |
                                System.Reflection.BindingFlags.NonPublic |
                                System.Reflection.BindingFlags.Instance);
                            if (mi != null && mi.GetParameters().Length == 0)
                            {
                                mi.Invoke(form, null);
                                saved = true;
                                break;
                            }
                        }
                        if (saved)
                            MessageBox.Show("✅ تنظیمات با موفقیت ذخیره شد.", "تایید",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(
                                "✅ تغییرات اعمال شد.\n(این فرم دکمه ذخیره مستقل دارد — از دکمه‌های داخل فرم استفاده کنید.)",
                                "تایید", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("خطا در ذخیره‌سازی: " + ex.Message, "خطا",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                };

                btnReset.Click += (s, e) =>
                {
                    try
                    {
                        form.Dispose();
                        _embeddedForms.Remove(key);
                        page.Controls.Clear();
                        EnsureTabContent(page, key);
                    }
                    catch { }
                };

                btnClose.Click += (s, e) => SwitchToTab("dashboard");

                page.Controls.Add(confirmBar);
                page.Controls.Add(host);
                page.Controls.SetChildIndex(host, 1);       // back (Fill)
                page.Controls.SetChildIndex(confirmBar, 0); // front (Bottom)

                form.BringToFront();
                _embeddedForms[key] = form;
                try { Core.ThemeManager.ApplyTheme(form); } catch { }
                layoutButtons(null, null);
            }
            else
            {
                // === View-only module: just a "✖️ بستن" button at the bottom ===
                // No confirm/reset — these modules don't edit settings.
                var closeBar = new Panel
                {
                    Dock = DockStyle.Bottom,
                    Height = 36,
                    BackColor = Color.FromArgb(225, 225, 230),
                    Padding = new Padding(12, 6, 12, 6),
                };
                var btnCloseView = new Button
                {
                    Text = "✖️ بستن",
                    Size = new Size(100, 32),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(243, 139, 168),
                    ForeColor = Color.FromArgb(225, 225, 230),
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Anchor = AnchorStyles.Top | AnchorStyles.Right,
                };
                btnCloseView.FlatAppearance.BorderSize = 0;
                btnCloseView.Click += (s, e) => SwitchToTab("dashboard");
                closeBar.Resize += (s, e) =>
                {
                    btnCloseView.Location = new Point(closeBar.Width - 100 - 12, 6);
                };
                closeBar.Controls.Add(btnCloseView);

                page.Controls.Add(closeBar);
                page.Controls.Add(host);
                page.Controls.SetChildIndex(host, 1);      // back (Fill)
                page.Controls.SetChildIndex(closeBar, 0);  // front (Bottom)

                form.BringToFront();
                _embeddedForms[key] = form;
                try { Core.ThemeManager.ApplyTheme(form); } catch { }
            }
        }

        /// <summary>
        /// Factory that instantiates the correct child form for a tab key.
        /// Centralized here so adding a new module is a one-line change.
        /// </summary>
        private Form CreateFormForKey(string key)
        {
            switch (key)
            {
                case "dashboard":  return new DashboardForm(_communicator);
                case "clients":    return new ClientMonitorForm(_communicator, _currentOperator != null && _currentOperator.Username == "admin");
                case "ipmonitor":  return new IpMonitorForm(_communicator);
                case "serverstatus": return new ServerStatusForm(_communicator, _mobileApi != null, _webSocket != null);
                case "users":      return new UserManagementForm();
                case "pricing":    return new PricingForm();
                case "stations":   return new StationManagementForm();
                case "equipment":  return new EquipmentForm();
                case "tickets":    return new TicketManagerForm();
                case "packages":   return new SessionPackageForm();
                case "tiers":      return new MemberTierForm();
                case "loyalty":    return new LoyaltyForm();
                case "vip":        return new VipForm();
                case "queue":      return new QueueForm();
                case "debt":       return new DebtForm();
                case "print":      return new PrintForm();
                case "chat":       return new ChatForm(_communicator);
                case "announce":   return new AnnouncementForm();
                case "reports":    return new ReportForm();
                case "advreports": return new AdvancedReportForm();
                case "revenue":    return new RevenueChartForm();
                case "journal":    return new ActivityJournalForm(); // round 14
                case "conndoctor": return new ConnectionDoctorForm(_communicator); // round 15
                case "backup":     return new BackupForm();
                case "security":   return new SecurityForm();
                case "secdash":    return new SecurityDashboardForm();
                case "licenses":   return new ClientLicenseForm();
                case "secalerts":  return new SecurityAlertsForm();
                case "winharden":  return new WindowsHardeningForm();
                case "theme":      return new ThemeForm();
                case "smartprice": return new SmartPricingForm();
                case "payment":    return new PaymentForm();
                case "branches":   return new BranchForm();
                case "features":   return new FeatureToggleForm();
                case "extensions": return new ExtensionsForm();
                case "consoles":   return new ConsoleReservationForm();
                case "updates":    return new UpdateDistributionForm(_communicator);
                case "api":        return new ApiPanelForm(_communicator, this);
                // New HandyCafe-inspired modules
                case "orders":       return new OrdersForm(_communicator);
                case "timers":       return new TimersForm(_communicator);
                case "shortcuts":    return new ShortcutsForm();
                case "syslog":       return new SystemLogForm();
                case "sync":         return new SyncForm(_communicator);
                case "cash":         return new CashForm();
                case "schedshutdown": return new ScheduledShutdownForm(_communicator);
                case "restrictions":  return new RestrictionsForm(_communicator);
                case "clientoptions": return new ClientOptionsForm();
                case "tournaments": return new TournamentForm();
                // === PRO ماژول‌ها ===
                case "staff": return new StaffManagementForm();
                case "discount": return new DiscountForm();
                case "analytics": return new AnalyticsForm();
                case "aiprice": return new AIPriceForm();
                case "livedash": return new LiveDashboardForm(_communicator);
                case "advloyalty": return new AdvancedLoyaltyForm();
                case "smartloyalty": return new SmartLoyaltyForm();
                case "aianalytics": return new AIAnalyticsForm();
                case "gamemgr": return new GameManagementForm();
                case "tournamentpro": return new TournamentProForm();
                case "advsecurity": return new AdvancedSecurityForm();
                case "mobileapi":
                    // BUG FIX: this PRO module had no real form — it only
                    // popped a MessageBox saying the API was "active on port
                    // 8082" and returned null, showing "not implemented" in
                    // the tab. ApiPanelForm already is the full mobile-API
                    // management screen (the "api" key above already opens
                    // it) — route mobileapi to the same real form.
                    return new ApiPanelForm(_communicator, this);
                default:           return null;
            }
        }

        /// <summary>
        /// Applies the current language to all visible UI elements (title,
        /// status, button, sidebar categories). Called on language change.
        /// </summary>
        private void ApplyLanguage()
        {
            string lang = _localization.CurrentLanguage;
            bool isFa = (lang == "fa");
            bool isEn = (lang == "en");

            // Form title
            this.Text = isFa ? "مرکز بازی - مدیریت گیم‌نت" :
                        isEn ? "مرکز بازی - مدیریت گیم‌نت" :
                        "خادم مرکز بازی - إدارة مقهى الألعاب";

            // Right-to-left
            this.RightToLeft = isEn ? RightToLeft.No : RightToLeft.Yes;

            // Title label
            _lblTitle.Text = "🎮 مرکز بازی";

            // Login button
            _btnLogin.Text = isFa ? "👤 ورود اپراتور" :
                             isEn ? "👤 Operator Login" :
                             "👤 دخول المشغل";

            // Status (will be overwritten by UpdateStatusBar on next tick)
            _lblStatus.Text = isFa ? "🟢 فعال | در حال بارگذاری..." :
                              isEn ? "🟢 Active | Loading..." :
                              "🟢 نشط | جار التحميل...";

            // Active system label
            if (_lblActiveSystem != null)
                _lblActiveSystem.Text = isFa ? "🖥️ سیستم فعال: ---" :
                                        isEn ? "🖥️ Active: ---" :
                                        "🖥️ النشط: ---";

            // === Primary toolbar buttons (8 flat icon+text buttons) ===
            for (int i = 0; i < _primaryButtons.Count && i < _primaryDefs.Count; i++)
            {
                var def = _primaryDefs[i];
                _primaryButtons[i].Text = isEn ? def.En :
                                          lang == "ar" ? def.Ar : def.Fa;
            }

            // === Left sidebar labels ===
            if (_leftSidebar != null)
            {
                foreach (Control sc in _leftSidebar.Controls)
                {
                    // Selected station label
                    if (sc == _lblSelectedStation)
                    {
                        string name = _lblSelectedStation.Text;
                        // Preserve the actual station name after the colon.
                        string stationPart = name.Contains(":") ? name.Substring(name.IndexOf(':') + 1).Trim() : "---";
                        _lblSelectedStation.Text = isFa ? $"🎯 ایستگاه انتخابی: {stationPart}" :
                                                   isEn ? $"🎯 Selected: {stationPart}" :
                                                   $"🎯 المحدد: {stationPart}";
                    }

                    // Tab buttons (Time / Orders / Queue)
                    if (sc is Button tb && tb.Text.Length > 0)
                    {
                        if (tb.Text.Contains("زمان") || tb.Text.Contains("Time") || tb.Text.Contains("وقت"))
                            tb.Text = isFa ? "⏱️ زمان" : isEn ? "⏱️ Time" : "⏱️ وقت";
                        else if (tb.Text.Contains("سفارش") || tb.Text.Contains("Order"))
                            tb.Text = isFa ? "📋 سفارش" : isEn ? "📋 Orders" : "📋 الطلبات";
                        else if (tb.Text.Contains("صف") || tb.Text.Contains("Queue"))
                            tb.Text = isFa ? "🎟️ صف" : isEn ? "🎟️ Queue" : "🎟️ قائمة";
                    }

                    // Info panel rows (Start/End/Used/Remaining labels)
                    if (sc is Panel infoPanel)
                    {
                        foreach (Control row in infoPanel.Controls)
                        {
                            if (!(row is Label lbl)) continue;
                            if (lbl.Text.Contains("شروع") || lbl.Text.Contains("Start") || lbl.Text.Contains("بدء"))
                                lbl.Text = isFa ? "زمان شروع:" : isEn ? "Start Time:" : "وقت البدء:";
                            else if (lbl.Text.Contains("پایان") || lbl.Text.Contains("End"))
                                lbl.Text = isFa ? "زمان پایان:" : isEn ? "End Time:" : "وقت الانتهاء:";
                            else if (lbl.Text.Contains("استفاده") || lbl.Text.Contains("Used"))
                                lbl.Text = isFa ? "زمان استفاده:" : isEn ? "Used Time:" : "الوقت المستخدم:";
                            else if (lbl.Text.Contains("باقی") || lbl.Text.Contains("Remain"))
                                lbl.Text = isFa ? "زمان باقی‌مانده:" : isEn ? "Remaining:" : "المتبقي:";
                        }
                    }

                    // Custom time label
                    if (sc is Label cl && (cl.Text.Contains("دلخواه") || cl.Text.Contains("Custom") || cl.Text.Contains("مخصص")))
                        cl.Text = isFa ? "زمان دلخواه (دقیقه):" : isEn ? "Custom time (min):" : "وقت مخصص (دقيقة):";

                    // Custom add button
                    if (sc is Button ab && (ab.Text.Contains("افزودن") || ab.Text.Contains("Add") || ab.Text.Contains("إضافة")))
                        ab.Text = isFa ? "➕ افزودن" : isEn ? "➕ Add" : "➕ إضافة";

                    // Limit / Unlimited buttons
                    if (sc is Button lb && (lb.Text.Contains("محدود") || lb.Text.Contains("Limit")))
                        lb.Text = isFa ? "⏱️ محدود کردن زمان" : isEn ? "⏱️ Limit Time" : "⏱️ حد الوقت";
                    if (sc is Button ub && (ub.Text.Contains("نامحدود") || ub.Text.Contains("Unlim")))
                        ub.Text = isFa ? "♾️ نامحدود" : isEn ? "♾️ Unlimited" : "♾️ غير محدود";

                    // Play and Pay checkbox
                    if (sc is CheckBox pp)
                        pp.Text = isFa ? "🎮 Play and Pay (بازی کن، بعد پرداخت کن)" :
                                  isEn ? "🎮 Play and Pay" :
                                  "🎮 العب ثم ادفع";
                }
            }

            // === Bottom panel label ===
            // Find the activity log label in _bottomPanel
            if (_bottomPanel != null)
            {
                foreach (Control bc in _bottomPanel.Controls)
                {
                    if (bc is Label bl && (bl.Text.Contains("لاگ") || bl.Text.Contains("Activity") || bl.Text.Contains("سجل")))
                        bl.Text = isFa ? "📋 لاگ فعالیت کلاینت‌ها" : isEn ? "📋 Client Activity Log" : "📋 سجل نشاط العملاء";
                }
            }

            // === Status strip ===
            if (_statusStrip != null)
            {
                _ssRole.Text = "ADMIN"; // unchanged
                // Clients/Idle/Unreachable labels are set by the timer; just
                // update the datetime format is locale-independent.
            }

            // === MenuStrip items ===
            // BUG FIX: previously this only matched the 5 top-level headers
            // by comparing item.Text against hardcoded strings, and never
            // touched anything inside a dropdown (Reporting's items, Tools'
            // items, PRO's items, any nested submenu) — so every module item
            // stayed in whatever language it happened to be created in.
            // LocalizeMenuTree walks the whole menu tree recursively and
            // re-localizes every tagged item.
            foreach (Control c in this.Controls)
            {
                if (!(c is MenuStrip ms)) continue;
                LocalizeMenuTree(ms.Items, lang);
            }

            // Force UI refresh
            this.Invalidate(true);
            this.Refresh();
        }

        /// <summary>Returns the localized title for a tab key.</summary>
        private string GetTabTitle(string key, string lang)
        {
            bool isFa = (lang == "fa");
            bool isEn = (lang == "en");

            switch (key)
            {
                case "dashboard":  return isEn ? "📊 Dashboard" : isFa ? "📊 داشبورد" : "📊 لوحة التحكم";
                case "clients":    return isEn ? "📡 Clients" : isFa ? "📡 کلاینت‌ها" : "📡 العملاء";
                case "users":      return isEn ? "👥 Users" : isFa ? "👥 کاربران" : "👥 المستخدمون";
                case "pricing":    return isEn ? "💰 Pricing" : isFa ? "💰 تعرفه‌ها" : "💰 الأسعار";
                case "stations":   return isEn ? "💻 Stations" : isFa ? "💻 ایستگاه‌ها" : "💻 المحطات";
                case "equipment":  return isEn ? "🔧 Equipment" : isFa ? "🔧 تجهیزات" : "🔧 المعدات";
                case "consoles":   return isEn ? "🎮 Consoles" : isFa ? "🎮 کنسول PS4/PS5" : "🎮 أجهزة الألعاب";
                case "tickets":    return isEn ? "🎫 Tickets" : isFa ? "🎫 تیکت‌ها" : "🎫 التذاكر";
                case "packages":   return isEn ? "📦 Packages" : isFa ? "📦 بسته‌ها" : "📦 الباقات";
                case "debt":       return isEn ? "💳 Debts" : isFa ? "💳 بدهی" : "💳 الديون";
                case "print":      return isEn ? "🖨️ Print" : isFa ? "🖨️ پرینت" : "🖨️ الطباعة";
                case "payment":    return isEn ? "💳 Payment" : isFa ? "💳 درگاه پرداخت" : "💳 بوابة الدفع";
                case "tiers":      return isEn ? "🏅 Membership" : isFa ? "🏅 عضویت" : "🏅 العضوية";
                case "loyalty":    return isEn ? "🏆 Loyalty" : isFa ? "🏆 وفاداری + تخفیف" : "🏆 الولاء";
                case "queue":      return isEn ? "🎟️ Queue" : isFa ? "🎟️ صف انتظار" : "🎟️ قائمة الانتظار";
                case "chat":       return isEn ? "💬 Chat" : isFa ? "💬 چت" : "💬 الدردشة";
                case "announce":   return isEn ? "📢 Announcements" : isFa ? "📢 اطلاعیه‌ها" : "📢 الإعلانات";
                case "reports":    return isEn ? "📈 Reports" : isFa ? "📈 گزارش‌ها" : "📈 التقارير";
                case "advreports": return isEn ? "📊 Advanced Reports" : isFa ? "📊 گزارش پیشرفته" : "📊 تقارير متقدمة";
                case "revenue":    return isEn ? "💰 Revenue Chart" : isFa ? "💰 نمودار درآمد" : "💰 مخطط الإيرادات";
                case "journal":    return isEn ? "🕵️ While I Was Away" : isFa ? "🕵️ وقتی نبودم" : "🕵️ أثناء غيابي";
                case "conndoctor": return isEn ? "🩺 Connection Doctor" : isFa ? "🩺 عیب‌یابی اتصال" : "🩺 تشخيص الاتصال";
                case "security":   return isEn ? "🛡️ Security" : isFa ? "🛡️ امنیت" : "🛡️ الأمان";
                case "secdash":    return isEn ? "🔐 Security Dashboard" : isFa ? "🔐 داشبورد امنیت" : "🔐 لوحة الأمان";
                case "licenses":   return isEn ? "🔑 Licenses" : isFa ? "🔑 لایسنس" : "🔑 التراخيص";
                case "secalerts":  return isEn ? "🚨 Alerts" : isFa ? "🚨 هشدارها" : "🚨 التنبيهات";
                case "winharden":  return isEn ? "🪟 Windows Hardening" : isFa ? "🪟 سخت‌سازی ویندوز" : "🪟 تقوية ويندوز";
                case "backup":     return isEn ? "💾 Backup" : isFa ? "💾 پشتیبان" : "💾 النسخ الاحتياطي";
                case "updates":    return isEn ? "📦 Updates" : isFa ? "📦 آپدیت + انتقال" : "📦 التحديثات";
                case "api":        return isEn ? "📱 API" : isFa ? "📱 API" : "📱 API";
                case "theme":      return isEn ? "🎨 Theme" : isFa ? "🎨 ظاهر" : "🎨 المظهر";
                case "smartprice": return isEn ? "🤖 Smart Pricing" : isFa ? "🤖 قیمت هوشمند" : "🤖 التسعير الذكي";
                case "branches":   return isEn ? "🏪 Branches" : isFa ? "🏪 شعب" : "🏪 الفروع";
                case "features":   return isEn ? "🎛️ Client Features" : isFa ? "🎛️ قابلیت کلاینت" : "🎛️ ميزات العميل";
                case "extensions": return isEn ? "⚙️ Settings" : isFa ? "⚙️ تنظیمات+افزونه" : "⚙️ الإعدادات";
                case "orders":       return isEn ? "🥤 Orders"        : isFa ? "🥤 بوفه/کافه‌تریا"   : "🥤 الطلبات";
                case "timers":       return isEn ? "⏱️ Timers"        : isFa ? "⏱️ تایمرها"        : "⏱️ المؤقتات";
                case "shortcuts":    return isEn ? "⭐ Shortcuts"     : isFa ? "⭐ میانبرها"        : "⭐ اختصارات";
                case "syslog":       return isEn ? "📋 System Log"    : isFa ? "📋 گزارش سیستم"    : "📋 سجل النظام";
                case "sync":         return isEn ? "🔄 Sync"          : isFa ? "🔄 همگام‌سازی"      : "🔄 مزامنة";
                case "cash":         return isEn ? "💵 Cash"          : isFa ? "💵 صندوق"          : "💵 الصندوق";
                case "ipmonitor":    return isEn ? "🌐 IP Monitor"    : isFa ? "🌐 مانیتور IP"     : "🌐 مراقبة IP";
                case "serverstatus": return isEn ? "📊 Server Status" : isFa ? "📊 وضعیت سرور"     : "📊 حالة الخادم";
                case "schedshutdown":return isEn ? "⏰ Sched. Shutdown": isFa ? "⏰ خاموشی زمان‌بندی" : "⏰ إيقاف مجدول";
                case "restrictions": return isEn ? "🚫 Restrictions"  : isFa ? "🚫 محدودیت‌ها"        : "🚫 القيود";
                case "clientoptions":return isEn ? "💻 Client Options": isFa ? "💻 تنظیمات کلاینت"   : "💻 خيارات العميل";
                case "tournaments":  return isEn ? "🏆 Tournaments"  : isFa ? "🏆 مسابقات"          : "🏆 البطولات";
                case "vip":          return isEn ? "💎 VIP"          : isFa ? "💎 VIP"              : "💎 VIP";
                // PRO modules — previously only had a plain label typed at
                // their AddMenuModule call site, so language switching
                // never touched them. Centralized here like every other
                // tab so LocalizeMenuTree can refresh them too.
                case "staff":         return isEn ? "👤 Staff"          : isFa ? "👤 پرسنل"           : "👤 الموظفون";
                case "discount":      return isEn ? "🎟️ Discount"       : isFa ? "🎟️ تخفیف"           : "🎟️ الخصم";
                case "analytics":     return isEn ? "📊 Analytics"      : isFa ? "📊 تحلیل"           : "📊 التحليل";
                case "aiprice":       return isEn ? "🤖 AI Price"       : isFa ? "🤖 قیمت هوشمند"     : "🤖 سعر الذكاء";
                case "livedash":      return isEn ? "📊 Live Dashboard" : isFa ? "📊 داشبورد زنده"    : "📊 لوحة حية";
                case "advloyalty":    return isEn ? "🏆 Loyalty+"       : isFa ? "🏆 وفاداری+"        : "🏆 الولاء+";
                case "smartloyalty":  return isEn ? "🤝 Smart Loyalty"  : isFa ? "🤝 وفاداری هوشمند"  : "🤝 الولاء الذكي";
                case "aianalytics":   return isEn ? "📈 AI Analytics"   : isFa ? "📈 تحلیل AI"        : "📈 تحليل الذكاء";
                case "gamemgr":       return isEn ? "🎮 Game Manager"   : isFa ? "🎮 مدیریت بازی‌ها"  : "🎮 إدارة الألعاب";
                case "tournamentpro": return isEn ? "🏆 Tournaments+"   : isFa ? "🏆 مسابقات+"        : "🏆 البطولات+";
                case "advsecurity":   return isEn ? "🔒 Adv Security"   : isFa ? "🔒 امنیت پیشرفته"   : "🔒 الأمن المتقدم";
                case "mobileapi":     return isEn ? "📱 Mobile API"     : isFa ? "📱 API موبایل"      : "📱 واجهة الهاتف";
                default:           return key;
            }
        }

        private void UpdateStatusBar()
        {
            try
            {
                string apiStatus = _mobileApi != null ? "فعال" : "غیرفعال";
                string wsStatus = _webSocket != null ? "فعال" : "غیرفعال";
                string opStatus = _currentOperator != null ? _currentOperator.Username : "لاگین نشده";
                int clients = _communicator?.ConnectedClientCount ?? 0;

                // Today's income
                decimal todayIncome = 0;
                try
                {
                    todayIncome = Database.Instance.QueryOne(
                        "SELECT COALESCE(SUM(total_cost), 0) FROM client_sessions WHERE end_time IS NOT NULL AND date(start_time) = date('now')",
                        null, r => r.GetDecimal(0));
                }
                catch { }

                _lblStatus.Text = $"🟢 فعال | 💰 درآمد امروز: {todayIncome:N0} ت | 📡 آنلاین: {clients} | API: {apiStatus} | WS: {wsStatus} | 👤 {opStatus}";

                // Update active system display
                if (_lblActiveSystem != null)
                {
                    try
                    {
                        var allConns = _communicator?.GetAllRawConnections();
                        if (allConns != null)
                        {
                            var active = allConns.FirstOrDefault(c => !string.IsNullOrEmpty(c.User) && c.User != "-");
                            if (active.StationName != null)
                                _lblActiveSystem.Text = $"🖥️ فعال: {active.StationName} | ⏱️ {active.Minutes}د";
                            else
                                _lblActiveSystem.Text = "🖥️ فعال: ---";
                        }
                    }
                    catch { }
                }

                if (_btnLogin != null && _currentOperator != null)
                {
                    _btnLogin.Text = "👤 " + _currentOperator.DisplayName;
                    _btnLogin.BackColor = Color.FromArgb(166, 227, 161);
                }
            }
            catch { }
        }

        private void DoOperatorLogin()
        {
            var f = new OperatorLoginForm();
            if (f.ShowDialog(this) == DialogResult.OK && f.CurrentOperator != null)
            {
                // Round 14: the previous operator leaves, the new one arrives.
                if (_currentOperator != null)
                    try { ActivityJournal.Record(ActivityJournal.Operator, "خروج اپراتور «" + JournalName(_currentOperator) + "» (تغییر اپراتور)"); } catch { }
                _currentOperator = f.CurrentOperator;
                JournalLogin(_currentOperator);
                MessageBox.Show($"خوش آمدید {_currentOperator.DisplayName}", "ورود", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AuditLog.Log("MainForm", $"Operator {_currentOperator.Username} logged in to MainForm");
                UpdateStatusBar();

                // Refresh the current tab content now that we have permissions
                var page = _tabs.SelectedTab;
                if (page != null)
                {
                    string key = (string)page.Tag;
                    if (_embeddedForms.ContainsKey(key))
                    {
                        // Already loaded — but might have been the access-denied label.
                        // Remove it so it can be recreated.
                        var existing = _embeddedForms[key];
                        _embeddedForms.Remove(key);
                        page.Controls.Clear();
                        if (existing != null) existing.Dispose();
                        EnsureTabContent(page, key);
                    }
                    else
                    {
                        // It may have an access-denied label — clear and retry
                        page.Controls.Clear();
                        EnsureTabContent(page, key);
                    }
                }
            }
        }

        private bool RequireLogin()
        {
            if (_currentOperator == null || !_currentOperator.IsActive)
            {
                MessageBox.Show("ابتدا به عنوان اپراتور وارد شوید (دکمه «ورود اپراتور» در بالا).", "دسترسی ندارید", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private bool RequirePermission(OperatorPermission perm)
        {
            if (!RequireLogin()) return false;
            if (!_operatorManager.HasPermission(_currentOperator, perm))
            {
                MessageBox.Show("شما اجازه دسترسی به این بخش را ندارید.", "دسترسی ندارید", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                AuditLog.Log("MainForm", $"Access denied: operator {_currentOperator.Username} lacks permission {perm}");
                try { IntrusionDetectionSystem.RecordPermissionDenied(_currentOperator.Username, perm.ToString()); } catch { }
                return false;
            }
            return true;
        }

        /// <summary>Called by the API tab to start the mobile API and report status.</summary>
        public string StartMobileApi()
        {
            if (_mobileApi == null)
            {
                _mobileApi = new MobileApiController(_communicator);
                _mobileApi.Start();
            }
            return _mobileApi.GetApiKey();
        }

        /// <summary>Called by the API tab to start the WebSocket server.</summary>
        public void StartWebSocket()
        {
            if (_webSocket == null)
            {
                // FIX SEC-3: WebSocketServer supports an apiToken param and
                // enforces it in HandleConnection — but this call site never
                // passed one, so the server always ran fully open: anyone
                // who could reach the port (bound to all interfaces, not
                // just localhost — see WebSocketServer.Start) got a live
                // feed of station names, usernames, and session costs with
                // zero authentication. Reuses the mobile API's persisted
                // readonly_key (see ApiKeyStore) since this feed is
                // read-only data, same trust level.
                string wsToken = Core.ApiKeyStore.LoadOrGenerateKeys().ReadonlyKey;
                _webSocket = new WebSocketServer(_communicator, apiToken: wsToken);
                _webSocket.Start();
                // ADD-MULTI-FEATURES Feature 8: register the WebSocketServer
                // with LiveUpdates so client/session events are pushed to web
                // dashboard subscribers.
                LiveUpdates.Register(_webSocket);
            }
        }

        /// <summary>Returns the admin API key (or empty if API not started).</summary>
        public string GetAdminApiKeySafe()
        {
            return _mobileApi?.GetAdminApiKey() ?? "";
        }

        /// <summary>Stops the mobile API if running.</summary>
        public void StopMobileApiSafe()
        {
            try { _mobileApi?.Dispose(); } catch { }
            _mobileApi = null;
        }

        /// <summary>Stops the WebSocket server if running.</summary>
        public void StopWebSocketSafe()
        {
            try { LiveUpdates.Unregister(_webSocket); } catch { }
            try { _webSocket?.Dispose(); } catch { }
            _webSocket = null;
        }

        /// <summary>
        /// FIX DEAD-CONFIG-1: creates the tray icon when
        /// OptionsData.ShowTrayIcon is on. Double-click restores the window;
        /// the context menu offers "نمایش" (show) and "خروج" (exit, which
        /// goes through the normal OnFormClosing confirmation).
        /// </summary>
        private void BuildTrayIcon()
        {
            _trayIcon?.Dispose();
            _trayIcon = null;
            if (!_showTrayIcon) return;

            var menu = new ContextMenuStrip();
            menu.Items.Add("نمایش پنجره", null, (s, e) => RestoreFromTray());
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("خروج", null, (s, e) => { RestoreFromTray(); Close(); });

            // Round 11: this.Icon is never null — without an icon of its own it is
            // the WinForms default icon, so the tray showed that generic icon.
            // Use the program icon (server.ico next to the exe, else the exe's own).
            Icon icon = GameNet.Shared.AppIcon.Get("server.ico");
            if (icon == null)
            {
                try { icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { icon = SystemIcons.Application; }
            }
            _trayIcon = new NotifyIcon
            {
                Icon = icon,
                Text = "GameNet Server",
                Visible = true,
                ContextMenuStrip = menu
            };
            _trayIcon.DoubleClick += (s, e) => RestoreFromTray();
        }

        private void RestoreFromTray()
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.Activate();
        }

        /// <summary>
        /// Self-repair (FMEA): Error and Critical faults are announced as toasts while the
        /// server runs, and the explanation of a crash from the previous run is shown once
        /// when the window appears. The full record is in diagnostics.log (Tools → عیب‌یابی).
        /// </summary>
        private void WireDiagnostics()
        {
            FaultJournal.FaultRaised += OnFaultRaisedForToast;
            this.FormClosed += (s, e) => FaultJournal.FaultRaised -= OnFaultRaisedForToast;
            this.Shown += (s, e) =>
            {
                try
                {
                    string pending = FaultJournal.TakePendingReport();
                    if (string.IsNullOrEmpty(pending)) return;
                    if (pending.Length > 400) pending = pending.Substring(0, 400) + "...";
                    ToastNotification.Show(this, pending, ToastType.Error, 12000);
                }
                catch { }
            };
        }

        private void OnFaultRaisedForToast(FaultRecord rec)
        {
            try
            {
                if (rec == null) return;
                if (rec.Severity != FaultSeverity.Error && rec.Severity != FaultSeverity.Critical) return;
                if (!IsHandleCreated || IsDisposed) return;
                BeginInvoke((Action)(() =>
                {
                    try
                    {
                        ToastNotification.Show(this, rec.Code + " - " + rec.Title + "\n" + rec.Cause,
                            rec.Severity == FaultSeverity.Critical ? ToastType.Error : ToastType.Warning, 8000);
                    }
                    catch { }
                }));
            }
            catch { }
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            // FIX MINIMIZE-HIDE: the old behavior called this.Hide() on
            // minimize when a tray icon was present (which is the default —
            // ShowTrayIcon defaults to true). That made the form VANISH from
            // the taskbar with no obvious way back except double-clicking the
            // tiny tray icon. The operator reported this as "the server
            // disappears / becomes unusable after a while".
            //
            // New behavior: minimize to the taskbar NORMALLY (like every
            // other Windows app). The tray icon still exists for right-click
            // actions (Show / Exit), but the form no longer hides itself
            // just because the user clicked the minimize button.
            //
            // Also pause the heavy UI timers while minimized to prevent
            // the "after a few minutes becomes sluggish" symptom.
            if (this.WindowState == FormWindowState.Minimized)
            {
                try { _clockTimer?.Stop(); } catch { }
                try { _statusTimer?.Stop(); } catch { }
            }
            else
            {
                // Restored — restart the UI timers.
                try { _clockTimer?.Start(); } catch { }
                try { _statusTimer?.Start(); } catch { }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            // Ask for confirmation before closing — prevents accidental closure
            // when the operator misclicks the X button.
            if (e.CloseReason == CloseReason.UserClosing || e.CloseReason == CloseReason.TaskManagerClosing)
            {
                var result = MessageBox.Show(
                    "⚠️ آیا واقعاً می‌خواهید سرور مرکز بازی را ببندید؟\n\n" +
                    "🔴 بستن سرور باعث می‌شود:\n" +
                    "  • تمام کلاینت‌ها قطع شوند\n" +
                    "  • نشست‌های فعال پایان یابند\n" +
                    "  • ارتباط با همه کیوسک‌ها قطع شود\n\n" +
                    "آیا مطمئن هستید؟",
                    "بستن سرور مرکز بازی",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2); // No = default (prevent accidental close)

                if (result != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }
            }

            try
            {
                // FIX DEAD-CONFIG-1: hide + dispose the tray icon so it
                // doesn't linger in the notification area after the process
                // exits (a stale NotifyIcon otherwise sticks around until
                // the user mouses over it).
                if (_trayIcon != null) { _trayIcon.Visible = false; _trayIcon.Dispose(); _trayIcon = null; }
                _syncScheduler?.Stop();
                _dbMaintenance?.Stop();
                _statusTimer?.Stop();
                _autoRechargeTimer?.Stop();
                // FIX AUDIT-FIX-FINAL Bug C: stop+dispose the clock timer so
                // it doesn't keep firing after the form is closed.
                _clockTimer?.Stop();
                // FIX-MONITOR-ADD5 TASK B2: stop+dispose the backup timer so
                // it doesn't fire its Tick handler (which captures `this`
                // indirectly via the AuditLog / Database singletons) after
                // the form is closed.
                _backupTimer?.Stop();
                // FIX M4: dispose the timers so their underlying handles
                // (and the multicast-delegate refs to this form) are released
                // immediately, rather than waiting for GC finalization. Each
                // Timer's Tick handler captures `this` (via UpdateStatusBar),
                // so leaving them undisposed keeps the form alive in memory
                // until the next GC.
                _statusTimer?.Dispose();
                _autoRechargeTimer?.Dispose();
                _clockTimer?.Dispose();
                _backupTimer?.Dispose();
                foreach (var kvp in _embeddedForms)
                {
                    try { kvp.Value?.Dispose(); } catch { }
                }
                _embeddedForms.Clear();

                // FIX B3: stop the REST API server so its HttpListener + the
                // background `HandleLoop` thread shut down cleanly. Without
                // this, the listener keeps accepting connections (and the
                // background thread keeps running) after the form is closed,
                // which keeps the process alive and leaks a port reservation.
                try { Core.RestApiServer.Stop(); } catch { }

                // FIX B9: unregister the WebSocketServer from LiveUpdates
                // BEFORE disposing it. Otherwise LiveUpdates._server still
                // holds the reference and any subsequent Broadcast() call
                // would try to send through the disposed server, throwing
                // ObjectDisposedException on a background thread.
                try { Core.LiveUpdates.Unregister(_webSocket); } catch { }

                _mobileApi?.Dispose();
                _webSocket?.Dispose();
                _communicator?.Stop();
            }
            catch { }
            // Round 14: journal the close (also the operator's "leave" time for the notice).
            if (!e.Cancel)
                try { ActivityJournal.Record(ActivityJournal.Server, "سرور بسته شد — خروج «" + JournalName(_currentOperator) + "»"); } catch { }
            base.OnFormClosing(e);
        }

        /// <summary>Simple tab definition record.</summary>
        private class TabDef
        {
            public string Key;
            public string Title;
            public string Category;
            public OperatorPermission Permission;
            public Func<object> Factory;

            public TabDef(string key, string title, string category, OperatorPermission perm, Func<object> factory)
            {
                Key = key; Title = title; Category = category; Permission = perm; Factory = factory;
            }
        }
    }
}
