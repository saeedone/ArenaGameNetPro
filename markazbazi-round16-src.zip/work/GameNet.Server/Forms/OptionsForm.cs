using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Drawing.Printing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;
using Newtonsoft.Json;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Comprehensive HandyCafe-style settings dialog.
    /// Layout: TreeView on the left (categories + sub-categories), panel on
    /// the right (settings for the selected category), OK/Cancel buttons at
    /// the bottom. Settings persist to options.json next to the server exe.
    ///
    /// Real panels: General / Sounds / Client / Language / Backup (existing),
    /// plus Security / Sync / Network / Badwords / Administrator / Operator
    /// Levels / Pricing (Timers / Prepaid / Play-and-Pay / Custom Pricing /
    /// Pricing By Day / Pricing By Time / Buttons) / Printer (Receipt /
    /// Ticket / Bulk Tickets) / System (Monitoring / Banners / Bandwidth) /
    /// Advanced. All panels are now implemented — no placeholders remain.
    /// </summary>
    public class OptionsForm : Form
    {
        // === Layout pieces ===
        private TreeView _tree;
        private Panel _rightHost;
        private readonly Dictionary<string, Panel> _panels = new Dictionary<string, Panel>();
        private Panel _currentPanel;

        // === General panel controls ===
        private TextBox _txtGuestUser;
        private DateTimePicker _dtpReportsStart;
        private TextBox _txtDateFormat;
        private ComboBox _cboStyle;
        private CheckBox[] _generalChks;     // 14 checkboxes
        private ComboBox _cboDoubleClick;

        // === Sounds panel controls ===
        private TextBox _txtSndLogin, _txtSndTimer, _txtSndOrder;

        // === Client panel controls ===
        private TextBox _txtClientUser, _txtClientPass, _txtWarnMsg;
        private CheckBox _chkIdleShutdown, _chkWarnUser;
        private NumericUpDown _numIdleMinutes;
        private ComboBox _cboClientStyle;
        private CheckBox[] _clientChks;       // 15 checkboxes

        // === Security panel controls ===
        private TextBox _txtTimefreeze, _txtDeepfreeze, _txtShadowDefender;
        private readonly List<CheckBox> _driveChks = new List<CheckBox>();
        private CheckBox _chkUsbIn, _chkUsbOut;

        // === Sync panel controls ===
        private CheckBox _chkSyncEnabled, _chkShowSyncLog, _chkScheduledSync;
        private ComboBox _cboSyncTarget;
        private ListBox _lstSyncAvail, _lstSyncSelected;
        private NumericUpDown _numSyncMins;

        // === Network panel controls ===
        private DataGridView _netGrid;
        private Label _netSelectedLabel;

        // === Badwords panel controls ===
        private TextBox _txtBadwords, _txtBadExtra;
        private CheckBox _chkAutoCloseBad, _chkShowBadMsg;

        // === Operators (Administrator) panel controls ===
        private ListBox _lstOperators;
        private TextBox _txtOpUser, _txtOpPass, _txtOpFirst, _txtOpLast, _txtOpHintQ, _txtOpHintA, _txtOpEmail;
        private ComboBox _cboOpLevel;
        private Label _lblOpCount;

        // === Pricing panels ===
        private NumericUpDown _numDefaultHourPrice;
        private CheckBox _chkPrepaidEnabled;
        private TextBox _txtPrepaidMin;
        private CheckBox _chkPnpEnabled;
        private TextBox _txtPnpMaxDebt;
        private CheckBox _chkPnpWarn;

        // --- Pricing — Timers (enhanced with ListView) ---
        private TextBox _txtTimerDuration, _txtTimerHourPrice, _txtTimerMinCost;
        private ListView _lvTimers;
        private Button _btnTimerAdd, _btnTimerDel;

        // --- Pricing — Prepaid (enhanced with ListView) ---
        private TextBox _txtPrepName, _txtPrepCost;
        private NumericUpDown _numPrepTime, _numPrepBonus;
        private ListView _lvPrepaid;
        private Button _btnPrepAdd, _btnPrepClear, _btnPrepDel;

        // --- Pricing — Play and Pay (enhanced with ListView) ---
        private TextBox _txtPnpName, _txtPnpCost;
        private NumericUpDown _numPnpTime, _numPnpBonus;
        private ListView _lvPnp;
        private Button _btnPnpAdd, _btnPnpClear, _btnPnpDel;

        // --- Pricing — Custom Pricing ---
        private TextBox _txtCustName, _txtCustHourPrice;
        private ListView _lvCustom;
        private Button _btnCustAdd, _btnCustDel;

        // --- Pricing — Pricing By Day ---
        private ListBox _lstDays;
        private NumericUpDown _numDayDiscount;
        private TextBox _txtDayHourPrice, _txtDayGamePrice;
        private Button _btnDayApply;
        private ListView _lvDays;
        private readonly string[] _dayNames = { "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه" };

        // --- Pricing — Pricing By Time ---
        private ListBox _lstTimes;
        private NumericUpDown _numTimeDiscount;
        private TextBox _txtTimeHourPrice, _txtTimeGamePrice;
        private Button _btnTimeApply;
        private ListView _lvTimes;
        private readonly string[] _timeSlots = { "08:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "22:00" };

        // --- Pricing — Buttons (9 quick-time presets) ---
        private readonly NumericUpDown[] _numButtons = new NumericUpDown[9];

        // --- Operators — Operator Levels ---
        private ListBox _lstOpLevelOperators, _lstOpLevels;
        private Button _btnLevelAdd, _btnLevelEdit, _btnLevelDel;
        private Button _btnLevelOpAdd, _btnLevelOpRemove;
        private Label _lblOpLevelCount;

        // --- Printer — Main ---
        private ComboBox _cboDefaultPrinter;
        private CheckBox _chkPrintMonitoring, _chkNeverAskPrintConfirm;

        // --- Printer — Receipt ---
        private TextBox _txtReceiptTemplate;

        // --- Printer — Ticket ---
        private TextBox _txtTicketPrefix;
        private NumericUpDown _numTicketUserLen, _numTicketPassLen, _numTicketExpireDays;
        private TextBox _txtTicketTemplate;
        private Button _btnTicketTest, _btnTicketReset, _btnTicketDesign, _btnTicketDeleteUsed;

        // --- Printer — Bulk Tickets ---
        private TextBox _txtBulkCompany, _txtBulkPrefix, _txtBulkAmount;
        private DateTimePicker _dtpBulkExpire;
        private NumericUpDown _numBulkQty, _numBulkTime, _numBulkUserLen, _numBulkPassLen, _numBulkJobId;
        private Button _btnBulkGenerate, _btnBulkPrint;
        private ListView _lvBulkTickets;

        // === System panels ===
        private CheckBox _chkShowCpuRam, _chkShowTimeMon, _chkBandwidthLimit;
        private NumericUpDown _numMonRefresh, _numBandwidthMax;
        private TextBox _txtBannerTop;
        private Button _btnBannerColor;
        private Color _bannerColor = Color.FromArgb(137, 180, 250);

        // --- System — Monitoring (enhanced) ---
        private CheckBox _chkAutoArrangeIcons;
        private ComboBox _cboMonBgColor;
        private Button _btnMonFont;
        private Font _monitoringFont;
        private Panel _pnlZebra1, _pnlZebra2, _pnlZebraFont1, _pnlZebraFont2;
        private Color _zebraColor1 = Color.FromArgb(220, 220, 225);
        private Color _zebraColor2 = Color.FromArgb(230, 230, 235);
        private Color _zebraFontColor1 = Color.FromArgb(40, 40, 40);
        private Color _zebraFontColor2 = Color.FromArgb(148, 226, 213);

        // --- System — Banners (enhanced with ListView) ---
        private ListView _lvBanners;
        private Button _btnBannerAdd, _btnBannerEdit, _btnBannerDel;
        private Label _lblBannerCount;

        // --- System — Bandwidth (enhanced warning) ---
        private CheckBox _chkBwWarningEnabled;
        private NumericUpDown _numBwDownload, _numBwUpload;
        private CheckBox _chkBwWarnUser90, _chkBwWarnServer80;
        private TextBox _txtBwUserMsg, _txtBwServerMsg;

        // --- System — Language (enhanced with ListView) ---
        private ListView _lvLangs;
        private Label _lblLangFile;
        private Button _btnLangApply;

        // === Advanced panel controls ===
        private NumericUpDown _numUdpServer, _numUdpClient, _numTcpServer, _numWebServer;
        private TextBox _txtServerClientPass;
        // FIX B10: TLS / API port / MySQL provider UI controls. Previously
        // these options existed in OptionsData (and were read by MainForm)
        // but had no UI — the operator could only set them by hand-editing
        // options.json. Now they're first-class controls on the Advanced
        // panel.
        private CheckBox _chkUseTls;
        private NumericUpDown _numApiPort;
        private ComboBox _cboDbProvider;
        private TextBox _txtMySqlConnString;
        private Label _lblMySqlConnString;
        // FIX-MONITOR-ADD5 TASK B5: Telegram bot token + chat id UI controls.
        // Exposed on the Advanced panel so the operator can paste the values
        // from @BotFather without hand-editing options.json.
        private TextBox _txtTelegramBotToken;
        private TextBox _txtTelegramChatId;

        // === Language panel controls ===
        private ComboBox _cboLang;

        // === Backup panel controls ===
        private CheckBox _chkAutoBackup;
        private NumericUpDown _numBackupInterval;
        private TextBox _txtBackupPath;

        // === Settings model ===
        private readonly OptionsData _data;
        private readonly string _savePath;

        public OptionsForm()
        {
            this.Text = "⚙️ تنظیمات کلی";
            this.Size = new Size(900, 640);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.Font = new Font("Segoe UI", 9F);

            _savePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
            _data = LoadOptions();

            BuildTree();
            BuildRightHost();
            BuildButtons();

            // Select General by default
            if (_tree.Nodes.Count > 0 && _tree.Nodes[0].Nodes.Count > 0)
                _tree.SelectedNode = _tree.Nodes[0].Nodes[0];
            else if (_tree.Nodes.Count > 0)
                _tree.SelectedNode = _tree.Nodes[0];
        }

        // =================================================================
        //  Tree
        // =================================================================

        private void BuildTree()
        {
            _tree = new TreeView
            {
                Dock = DockStyle.Left,
                Width = 220,
                BackColor = Color.FromArgb(230, 230, 235),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 9F),
                BorderStyle = BorderStyle.None,
                ItemHeight = 24,
            };
            _tree.AfterSelect += (s, e) => ShowPanel(e.Node?.Tag as string);

            var menu = AddNode(_tree, "📁 منو (Menu)", null);
            AddNode(menu, "General",            "general");
            AddNode(menu, "Sounds",             "sounds");
            AddNode(menu, "Client",             "client");
            AddNode(menu, "Security",           "security");
            AddNode(menu, "Sync",               "sync");
            AddNode(menu, "Network",            "network");
            AddNode(menu, "Badwords",           "badwords");

            var ops = AddNode(_tree, "👤 اپراتورها (Operators)", null);
            AddNode(ops, "Operator Levels",     "oplevels");
            AddNode(ops, "Administrator",       "administrator");

            var pricing = AddNode(_tree, "💰 تعرفه‌ها (Pricing)", null);
            AddNode(pricing, "Timers",          "pricing_timers");
            AddNode(pricing, "Prepaid",         "pricing_prepaid");
            AddNode(pricing, "Play and Pay",    "pricing_pnp");
            AddNode(pricing, "Custom Pricing",  "pricing_custom");
            AddNode(pricing, "Pricing By Day",  "pricing_day");
            AddNode(pricing, "Pricing By Time", "pricing_time");
            AddNode(pricing, "Buttons",         "pricing_buttons");

            var prt = AddNode(_tree, "🖨️ پرینتر/تیکت (Printer)", null);
            AddNode(prt, "Printer",             "prt_main");
            AddNode(prt, "Receipt",             "prt_receipt");
            AddNode(prt, "Ticket",              "prt_ticket");
            AddNode(prt, "Bulk Tickets",        "prt_bulk");

            var sys = AddNode(_tree, "🖥️ سیستم (System)", null);
            AddNode(sys, "Monitoring",          "sys_monitoring");
            AddNode(sys, "Banners",             "sys_banners");
            AddNode(sys, "Bandwidth",           "sys_bandwidth");
            AddNode(sys, "Language",            "language");

            var adv = AddNode(_tree, "⚙️ پیشرفته (Advanced)", null);
            AddNode(adv, "Backup",              "backup");
            AddNode(adv, "Advanced",            "advanced");

            _tree.ExpandAll();
            this.Controls.Add(_tree);
        }

        private static TreeNode AddNode(object parent, string text, string tag)
        {
            var node = new TreeNode(text) { Tag = tag };
            if (parent is TreeView tv) tv.Nodes.Add(node);
            else if (parent is TreeNode tn) tn.Nodes.Add(node);
            return node;
        }

        // =================================================================
        //  Right host panel + category panels
        // =================================================================

        private void BuildRightHost()
        {
            _rightHost = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(16),
                AutoScroll = true,
            };
            this.Controls.Add(_rightHost);
            _rightHost.BringToFront();

            // Real panels
            BuildPanelGeneral();
            BuildPanelSounds();
            BuildPanelClient();
            BuildPanelLanguage();
            BuildPanelBackup();
            BuildPanelSecurity();
            BuildPanelSync();
            BuildPanelNetwork();
            BuildPanelBadwords();
            BuildPanelAdministrator();
            BuildPanelPricingTimers();
            BuildPanelPricingPrepaid();
            BuildPanelPricingPnP();
            BuildPanelPrinterMain();
            BuildPanelReceipt();
            BuildPanelTicket();
            BuildPanelMonitoring();
            BuildPanelBanners();
            BuildPanelBandwidth();
            BuildPanelAdvanced();
            BuildPanelOperatorLevels();
            BuildPanelPricingCustom();
            BuildPanelPricingByDay();
            BuildPanelPricingByTime();
            BuildPanelPricingButtons();
            BuildPanelBulkTickets();
        }

        private Panel NewPanel(string key, string title)
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(240, 240, 240),
                Visible = false,
            };
            var lbl = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(8, 8),
                AutoSize = true,
            };
            p.Controls.Add(lbl);
            _panels[key] = p;
            _rightHost.Controls.Add(p);
            return p;
        }

        private void BuildPanelPlaceholder(string key)
        {
            string display = key.Replace("_", " ");
            if (display.Length > 0)
                display = char.ToUpper(display[0]) + display.Substring(1);
            var p = NewPanel(key, "🔧 " + display);
            var note = new Label
            {
                Text = $"تنظیمات {display}\n\nاین بخش هنوز پیاده‌سازی نشده است.\nدر نسخه‌های بعدی اضافه خواهد شد.",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(180, 140, 20),
                Location = new Point(16, 60),
                Size = new Size(500, 80),
            };
            p.Controls.Add(note);
        }

        // =================================================================
        //  Shared ListView factory — dark themed Details view with columns
        // =================================================================

        private static ListView MkListView(string[] columns, int[] widths)
        {
            var lv = new ListView
            {
                View = View.Details,
                FullRowSelect = true,
                MultiSelect = false,
                GridLines = true,
                BackColor = Color.FromArgb(230, 230, 235),
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 9F),
                HeaderStyle = ColumnHeaderStyle.Nonclickable,
            };
            for (int i = 0; i < columns.Length; i++)
            {
                var ch = lv.Columns.Add(columns[i]);
                if (i < widths.Length) ch.Width = widths[i];
            }
            return lv;
        }

        // =================================================================
        //  Shared control factories
        // =================================================================

        private static CheckBox MkCheck(string text, bool isChecked)
        {
            return new CheckBox
            {
                Text = text,
                Checked = isChecked,
                AutoSize = true,
                ForeColor = Color.FromArgb(40, 40, 40),
                BackColor = Color.FromArgb(230, 230, 235),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F),
            };
        }

        private static TextBox MkText(string text, bool multi = false)
        {
            var t = new TextBox
            {
                Text = text ?? "",
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 9F),
            };
            if (multi) { t.Multiline = true; t.ScrollBars = ScrollBars.Vertical; }
            return t;
        }

        private static NumericUpDown MkNum(int min, int max, decimal val)
        {
            var n = new NumericUpDown
            {
                Minimum = min, Maximum = max, Value = val,
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            return n;
        }

        private static ComboBox MkCombo(params string[] items)
        {
            var c = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
                FlatStyle = FlatStyle.Flat,
            };
            c.Items.AddRange(items);
            return c;
        }

        private static Label MkLabel(string text)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 9F),
            };
        }

        private static Button MkBtn(string text, Color bg)
        {
            var b = new Button
            {
                Text = text,
                FlatStyle = FlatStyle.Flat,
                BackColor = bg,
                ForeColor = Color.FromArgb(225, 225, 230),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        // =================================================================
        //  General (enhanced with 14 checkboxes + DoubleClick combo)
        // =================================================================

        private void BuildPanelGeneral()
        {
            var p = NewPanel("general", "🔧 تنظیمات عمومی");
            int y = 60;

            // --- Existing fields ---
            var lblGuest = MkLabel("نام کاربری مهمان (Guest):"); lblGuest.Location = new Point(16, y);
            _txtGuestUser = MkText(_data.GuestUsername); _txtGuestUser.Location = new Point(220, y - 3); _txtGuestUser.Size = new Size(220, 28);
            p.Controls.Add(lblGuest); p.Controls.Add(_txtGuestUser);
            y += 36;

            var lblStart = MkLabel("زمان شروع گزارش‌ها:"); lblStart.Location = new Point(16, y);
            _dtpReportsStart = new DateTimePicker
            {
                Format = DateTimePickerFormat.Time, ShowUpDown = true,
                Value = DateTime.Today.Add(_data.ReportsStartTime),
                Location = new Point(220, y - 3), Size = new Size(220, 28),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
            };
            p.Controls.Add(lblStart); p.Controls.Add(_dtpReportsStart);
            y += 36;

            var lblDate = MkLabel("فرمت تاریخ:"); lblDate.Location = new Point(16, y);
            _txtDateFormat = MkText(_data.DateFormat); _txtDateFormat.Location = new Point(220, y - 3); _txtDateFormat.Size = new Size(220, 28);
            var btnDefault = MkBtn("پیش‌فرض", Color.FromArgb(220, 220, 225)); btnDefault.Location = new Point(450, y - 3); btnDefault.Size = new Size(90, 28);
            btnDefault.Click += (s, e) => _txtDateFormat.Text = "yyyy/MM/dd";
            p.Controls.Add(lblDate); p.Controls.Add(_txtDateFormat); p.Controls.Add(btnDefault);
            y += 36;

            var lblStyle = MkLabel("سبک ظاهری (Style):"); lblStyle.Location = new Point(16, y);
            _cboStyle = MkCombo("Windows", "Dark", "Modern"); _cboStyle.Location = new Point(220, y - 3); _cboStyle.Size = new Size(220, 28);
            // FIX L6: if the saved style isn't in the predefined list (e.g. a
            // custom theme name saved by a previous build, or a user-edited
            // options.json), add it as a temporary combo item instead of
            // silently resetting to "Dark". The previous code did
            // `_cboStyle.SelectedItem = _data.Style` which, when the item
            // wasn't found, set SelectedIndex = -1 and Save() then wrote
            // "Dark" (the fallback) — silently destroying the user's choice.
            if (!string.IsNullOrEmpty(_data.Style) &&
                !_cboStyle.Items.Contains(_data.Style))
            {
                _cboStyle.Items.Add(_data.Style);
            }
            _cboStyle.SelectedItem = string.IsNullOrEmpty(_data.Style) ? "Dark" : _data.Style;
            p.Controls.Add(lblStyle); p.Controls.Add(_cboStyle);
            y += 44;

            // --- 14 General checkboxes in two columns ---
            var generalItems = new[]
            {
                new { Key = nameof(OptionsData.RunServerAtStartup),    Text = "اجرای سرور در استارتاپ" },
                new { Key = nameof(OptionsData.DoubleClickLogin),      Text = "دابل‌کلیک = ورود/پرداخت" },
                new { Key = nameof(OptionsData.ShowTrayIcon),          Text = "نمایش آیکون در system tray" },
                new { Key = nameof(OptionsData.PrintReceiptOnPayment), Text = "پرینت رسید پس از پرداخت" },
                new { Key = nameof(OptionsData.NeverAskConfirm),       Text = "عدم پرسش تایید" },
                new { Key = nameof(OptionsData.AutoHideOnMinimize),    Text = "مخفی‌سازی خودکار هنگام minimize" },
                new { Key = nameof(OptionsData.ShowErrorMessages),     Text = "نمایش پیام‌های خطا" },
                new { Key = nameof(OptionsData.ShowDateTime),          Text = "نمایش تاریخ/زمان" },
                new { Key = nameof(OptionsData.CaseSensitive),         Text = "حساسیت به حروف بزرگ/کوچک" },
                new { Key = nameof(OptionsData.LogEvents),             Text = "ثبت رویدادها" },
                new { Key = nameof(OptionsData.AutoReLogin),           Text = "ورود خودکار مجدد" },
                new { Key = nameof(OptionsData.IgnoreLoginRequests),   Text = "نادیده گرفتن درخواست‌های ورود" },
                new { Key = nameof(OptionsData.UseZebraStyle),         Text = "استفاده از سبک Zebra" },
                new { Key = nameof(OptionsData.AskPasswordOnStartup),  Text = "پرسش رمز در استارتاپ" },
            };
            _generalChks = new CheckBox[generalItems.Length];
            int colWidth = 360;
            for (int i = 0; i < generalItems.Length; i++)
            {
                int col = i % 2;
                int row = i / 2;
                bool val = GetBool(_data, generalItems[i].Key);
                var chk = MkCheck(generalItems[i].Text, val);
                chk.Location = new Point(16 + col * colWidth, y + row * 28);
                // FIX L2: tag each checkbox with the OptionsData property name
                // it controls, so Save() can iterate by Tag instead of relying
                // on positional indexing (was _generalChks[0..13] hard-coded
                // to specific properties — fragile: reordering the items array
                // above silently desynced the checkboxes from the saved
                // properties, with no compile-time error).
                chk.Tag = generalItems[i].Key;
                _generalChks[i] = chk;
                p.Controls.Add(chk);
            }
            y += (generalItems.Length / 2 + 1) * 28 + 6;

            // Double-click combo
            var lblDc = MkLabel("دابل‌کلیک:"); lblDc.Location = new Point(16, y);
            _cboDoubleClick = MkCombo("ورود (Login)", "پرداخت (Payment)"); _cboDoubleClick.Location = new Point(220, y - 3); _cboDoubleClick.Size = new Size(220, 28);
            _cboDoubleClick.SelectedIndex = _data.DoubleClickAction == "payment" ? 1 : 0;
            p.Controls.Add(lblDc); p.Controls.Add(_cboDoubleClick);
        }

        // =================================================================
        //  Sounds
        // =================================================================

        private void BuildPanelSounds()
        {
            var p = NewPanel("sounds", "🔊 صداها");
            int y = 60;
            _txtSndLogin = AddSoundRow(p, "پخش صدا هنگام درخواست ورود:", _data.SoundLogin, ref y);
            _txtSndTimer = AddSoundRow(p, "پخش صدا هنگام پایان تایمر:", _data.SoundTimer, ref y);
            _txtSndOrder = AddSoundRow(p, "پخش صدا هنگام سفارش:", _data.SoundOrder, ref y);
        }

        private TextBox AddSoundRow(Panel p, string label, string initial, ref int y)
        {
            var lbl = MkLabel(label); lbl.Location = new Point(16, y);
            var txt = MkText(initial); txt.Location = new Point(280, y - 3); txt.Size = new Size(260, 28);
            var btn = MkBtn("browse", Color.FromArgb(220, 220, 225)); btn.Location = new Point(550, y - 3); btn.Size = new Size(80, 28);
            btn.Click += (s, e) =>
            {
                using (var ofd = new OpenFileDialog { Filter = "WAV files (*.wav)|*.wav|All files (*.*)|*.*" })
                    if (ofd.ShowDialog(this) == DialogResult.OK) txt.Text = ofd.FileName;
            };
            p.Controls.Add(lbl); p.Controls.Add(txt); p.Controls.Add(btn);
            y += 40;
            return txt;
        }

        // =================================================================
        //  Client (existing fields + 15 new checkboxes)
        // =================================================================

        private void BuildPanelClient()
        {
            var p = NewPanel("client", "💻 کلاینت");
            int y = 60;

            // Existing admin user/pass
            var lblU = MkLabel("نام کاربری ادمین کلاینت:"); lblU.Location = new Point(16, y);
            _txtClientUser = MkText(_data.ClientAdminUser); _txtClientUser.Location = new Point(260, y - 3); _txtClientUser.Size = new Size(220, 28);
            p.Controls.Add(lblU); p.Controls.Add(_txtClientUser);
            y += 32;

            var lblP = MkLabel("رمز ادمین کلاینت:"); lblP.Location = new Point(16, y);
            _txtClientPass = MkText(_data.ClientAdminPass); _txtClientPass.Location = new Point(260, y - 3); _txtClientPass.Size = new Size(220, 28);
            _txtClientPass.UseSystemPasswordChar = true;
            p.Controls.Add(lblP); p.Controls.Add(_txtClientPass);
            y += 36;

            // 15 client checkboxes — two columns
            var clientItems = new[]
            {
                new { Key = nameof(OptionsData.DisableWinShutdown),       Text = "غیرفعال کردن خاموش ویندوز" },
                new { Key = nameof(OptionsData.ShowPcNameOnScreen),       Text = "نمایش نام PC روی صفحه" },
                new { Key = nameof(OptionsData.EnableOrdering),           Text = "فعال‌سازی سفارش از کلاینت‌ها" },
                new { Key = nameof(OptionsData.EnableAdminLoginFromServer), Text = "فعال‌سازی ورود ادمین از سرور" },
                new { Key = nameof(OptionsData.TerminateAppsOnLogout),    Text = "بستن برنامه‌ها هنگام خروج" },
                new { Key = nameof(OptionsData.RebootClientOnPayment),    Text = "ری‌استارت کلاینت پس از پرداخت" },
                new { Key = nameof(OptionsData.ShutdownClientOnPayment),  Text = "خاموش کلاینت پس از پرداخت" },
                new { Key = nameof(OptionsData.DisableCafeteria),         Text = "غیرفعال کردن بوفه" },
                new { Key = nameof(OptionsData.DisableHide),              Text = "غیرفعال کردن مخفی‌سازی" },
                new { Key = nameof(OptionsData.DisableLogout),            Text = "غیرفعال کردن خروج" },
                new { Key = nameof(OptionsData.DisableLoginRequest),      Text = "غیرفعال کردن درخواست ورود" },
                new { Key = nameof(OptionsData.HideRemainingTime),        Text = "مخفی کردن زمان باقی‌مانده" },
                new { Key = nameof(OptionsData.HideStartTime),            Text = "مخفی کردن زمان شروع" },
                new { Key = nameof(OptionsData.HideUsedTime),             Text = "مخفی کردن زمان استفاده" },
                new { Key = nameof(OptionsData.HideCost),                 Text = "مخفی کردن هزینه" },
            };
            _clientChks = new CheckBox[clientItems.Length];
            int colWidth = 320;
            for (int i = 0; i < clientItems.Length; i++)
            {
                int col = i % 2;
                int row = i / 2;
                var chk = MkCheck(clientItems[i].Text, GetBool(_data, clientItems[i].Key));
                chk.Location = new Point(16 + col * colWidth, y + row * 26);
                // FIX L2: tag with the OptionsData property name (see Save()).
                chk.Tag = clientItems[i].Key;
                _clientChks[i] = chk;
                p.Controls.Add(chk);
            }
            y += (clientItems.Length / 2 + 1) * 26 + 10;

            // Existing idle shutdown controls
            _chkIdleShutdown = MkCheck("خاموش کردن کامپیوترها در بیکاری زمان‌بندی شده", _data.IdleShutdownEnabled);
            _chkIdleShutdown.Location = new Point(16, y);
            p.Controls.Add(_chkIdleShutdown);
            y += 28;

            var lblMin = MkLabel("دقایق بیکاری:"); lblMin.Location = new Point(40, y);
            _numIdleMinutes = MkNum(1, 600, _data.IdleShutdownMinutes <= 0 ? 15 : _data.IdleShutdownMinutes);
            _numIdleMinutes.Location = new Point(260, y - 3); _numIdleMinutes.Size = new Size(80, 28);
            p.Controls.Add(lblMin); p.Controls.Add(_numIdleMinutes);
            y += 36;

            _chkWarnUser = MkCheck("هشدار به کاربر قبل از خاموشی", _data.WarnUserEnabled);
            _chkWarnUser.Location = new Point(16, y);
            p.Controls.Add(_chkWarnUser);
            y += 28;

            var lblMsg = MkLabel("متن هشدار:"); lblMsg.Location = new Point(40, y);
            _txtWarnMsg = MkText(_data.WarnUserMessage); _txtWarnMsg.Location = new Point(260, y - 3); _txtWarnMsg.Size = new Size(380, 28);
            p.Controls.Add(lblMsg); p.Controls.Add(_txtWarnMsg);
            y += 36;

            var lblSt = MkLabel("سبک ظاهری کلاینت:"); lblSt.Location = new Point(16, y);
            _cboClientStyle = MkCombo("Windows", "Dark", "Modern"); _cboClientStyle.Location = new Point(260, y - 3); _cboClientStyle.Size = new Size(220, 28);
            _cboClientStyle.SelectedItem = string.IsNullOrEmpty(_data.ClientStyle) ? "Dark" : _data.ClientStyle;
            p.Controls.Add(lblSt); p.Controls.Add(_cboClientStyle);
        }

        // =================================================================
        //  Security
        // =================================================================

        private void BuildPanelSecurity()
        {
            var p = NewPanel("security", "🔒 امنیت");
            int y = 60;

            // Three password fields
            _txtTimefreeze     = AddPasswordField(p, "رمز Timefreeze:",       _data.TimefreezePassword,     ref y);
            _txtDeepfreeze     = AddPasswordField(p, "رمز Deepfreeze:",       _data.DeepfreezePassword,     ref y);
            _txtShadowDefender = AddPasswordField(p, "رمز Shadow Defender:",  _data.ShadowDefenderPassword, ref y);
            y += 10;

            var lblDrives = MkLabel("پوشه‌های Shadow Defender (درایوها):"); lblDrives.Location = new Point(16, y);
            p.Controls.Add(lblDrives);
            y += 28;

            // Build a grid of drive letters A..Z (4 cols × 7 rows)
            var selectedDrives = (_data.ShadowDefenderDrives ?? "").ToUpper();
            for (char c = 'A'; c <= 'Z'; c++)
            {
                int idx = c - 'A';
                int col = idx % 7;
                int row = idx / 7;
                var chk = new CheckBox
                {
                    Text = c.ToString(),
                    Checked = selectedDrives.IndexOf(c) >= 0,
                    Location = new Point(16 + col * 60, y + row * 26),
                    Size = new Size(50, 24),
                    ForeColor = Color.FromArgb(40, 40, 40),
                    BackColor = Color.FromArgb(230, 230, 235),
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 9F),
                };
                _driveChks.Add(chk);
                p.Controls.Add(chk);
            }
            y += 4 * 26 + 12;

            _chkUsbIn = MkCheck("هشدار هنگام وصل USB", _data.UsbPlugInWarning); _chkUsbIn.Location = new Point(16, y);
            p.Controls.Add(_chkUsbIn);
            y += 28;
            _chkUsbOut = MkCheck("هشدار هنگام قطع USB", _data.UsbPlugOutWarning); _chkUsbOut.Location = new Point(16, y);
            p.Controls.Add(_chkUsbOut);
        }

        private TextBox AddPasswordField(Panel p, string label, string initial, ref int y)
        {
            var lbl = MkLabel(label); lbl.Location = new Point(16, y);
            var txt = MkText(initial); txt.Location = new Point(220, y - 3); txt.Size = new Size(260, 28);
            txt.UseSystemPasswordChar = true;
            p.Controls.Add(lbl); p.Controls.Add(txt);
            y += 34;
            return txt;
        }

        // =================================================================
        //  Sync
        // =================================================================

        private void BuildPanelSync()
        {
            var p = NewPanel("sync", "🔄 همگام‌سازی");
            int y = 60;

            _chkSyncEnabled = MkCheck("فعال‌سازی همگام‌سازی", _data.SyncEnabled); _chkSyncEnabled.Location = new Point(16, y);
            p.Controls.Add(_chkSyncEnabled);
            y += 32;

            var lblTarget = MkLabel("فعال برای:"); lblTarget.Location = new Point(16, y);
            _cboSyncTarget = MkCombo("همه کامپیوترها (All)", "کامپیوترهای انتخاب‌شده (Selected)");
            _cboSyncTarget.Location = new Point(220, y - 3); _cboSyncTarget.Size = new Size(280, 28);
            _cboSyncTarget.SelectedIndex = _data.SyncTarget == "selected" ? 1 : 0;
            p.Controls.Add(lblTarget); p.Controls.Add(_cboSyncTarget);
            y += 40;

            // Available computers (left) and Selected computers (right) with >> and X between
            var lblAvail = MkLabel("کامپیوترهای موجود:"); lblAvail.Location = new Point(16, y);
            var lblSel = MkLabel("کامپیوترهای انتخاب‌شده:"); lblSel.Location = new Point(380, y);
            p.Controls.Add(lblAvail); p.Controls.Add(lblSel);
            y += 24;

            _lstSyncAvail = new ListBox
            {
                Location = new Point(16, y), Size = new Size(280, 140),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle, SelectionMode = SelectionMode.MultiExtended,
            };
            _lstSyncSelected = new ListBox
            {
                Location = new Point(380, y), Size = new Size(280, 140),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle, SelectionMode = SelectionMode.MultiExtended,
            };
            p.Controls.Add(_lstSyncAvail); p.Controls.Add(_lstSyncSelected);

            var btnAdd = MkBtn(">>", Color.FromArgb(166, 227, 161)); btnAdd.Location = new Point(310, y + 30); btnAdd.Size = new Size(60, 30);
            btnAdd.Click += (s, e) =>
            {
                var taken = new List<string>();
                foreach (var it in _lstSyncAvail.SelectedItems) taken.Add(it.ToString());
                foreach (var it in taken) { _lstSyncAvail.Items.Remove(it); if (!_lstSyncSelected.Items.Contains(it)) _lstSyncSelected.Items.Add(it); }
            };
            var btnRemove = MkBtn("X", Color.FromArgb(243, 139, 168)); btnRemove.Location = new Point(310, y + 70); btnRemove.Size = new Size(60, 30);
            btnRemove.Click += (s, e) =>
            {
                var taken = new List<string>();
                foreach (var it in _lstSyncSelected.SelectedItems) taken.Add(it.ToString());
                foreach (var it in taken) { _lstSyncSelected.Items.Remove(it); if (!_lstSyncAvail.Items.Contains(it)) _lstSyncAvail.Items.Add(it); }
            };
            p.Controls.Add(btnAdd); p.Controls.Add(btnRemove);
            y += 150;

            // Populate from DB (best-effort)
            try
            {
                var names = Database.Instance.Query("SELECT DISTINCT name FROM stations WHERE name IS NOT NULL ORDER BY name", null, r => r.IsDBNull(0) ? "" : r.GetString(0));
                var sel = (_data.SyncSelectedComputers ?? "").Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim()).ToList();
                foreach (var n in names)
                {
                    if (string.IsNullOrEmpty(n)) continue;
                    if (sel.Contains(n)) _lstSyncSelected.Items.Add(n); else _lstSyncAvail.Items.Add(n);
                }
            }
            catch { }

            _chkShowSyncLog = MkCheck("نمایش لاگ همگام‌سازی", _data.ShowSyncLog); _chkShowSyncLog.Location = new Point(16, y);
            p.Controls.Add(_chkShowSyncLog);
            y += 30;

            _chkScheduledSync = MkCheck("همگام‌سازی زمان‌بندی‌شده", _data.ScheduledSync); _chkScheduledSync.Location = new Point(16, y);
            p.Controls.Add(_chkScheduledSync);
            var lblMin = MkLabel("هر"); lblMin.Location = new Point(260, y);
            _numSyncMins = MkNum(1, 1440, _data.ScheduledSyncMinutes <= 0 ? 5 : _data.ScheduledSyncMinutes);
            _numSyncMins.Location = new Point(300, y - 3); _numSyncMins.Size = new Size(70, 28);
            var lblMin2 = MkLabel("دقیقه"); lblMin2.Location = new Point(380, y);
            p.Controls.Add(lblMin); p.Controls.Add(_numSyncMins); p.Controls.Add(lblMin2);
        }

        // =================================================================
        //  Network
        // =================================================================

        private void BuildPanelNetwork()
        {
            var p = NewPanel("network", "🌐 شبکه");
            int y = 60;

            var lbl = MkLabel("انتخاب آداپتور شبکه:"); lbl.Location = new Point(16, y);
            p.Controls.Add(lbl);
            y += 30;

            _netGrid = new DataGridView
            {
                Location = new Point(16, y),
                Size = new Size(760, 280),
                BackgroundColor = Color.FromArgb(230, 230, 235),
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                EnableHeadersVisualStyles = false,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) },
                DefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
            };
            _netGrid.Columns.Add("colMac", "MAC آدرس");
            _netGrid.Columns.Add("colDesc", "توضیحات");
            _netGrid.Columns.Add("colIp", "IP آدرس");
            _netGrid.SelectionChanged += (s, e) =>
            {
                if (_netGrid.CurrentRow != null)
                {
                    var mac = _netGrid.CurrentRow.Cells[0].Value?.ToString() ?? "";
                    _netSelectedLabel.Text = "آداپتور انتخاب‌شده: " + mac;
                }
            };
            p.Controls.Add(_netGrid);
            y += 295;

            _netSelectedLabel = MkLabel("آداپتور انتخاب‌شده: (بدون انتخاب)");
            _netSelectedLabel.Location = new Point(16, y); _netSelectedLabel.Size = new Size(700, 24);
            p.Controls.Add(_netSelectedLabel);

            PopulateNetworkAdapters();
        }

        private void PopulateNetworkAdapters()
        {
            try
            {
                _netGrid.Rows.Clear();
                string saved = _data.NetworkAdapterId ?? "";
                foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.OperationalStatus != OperationalStatus.Up) continue;
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    string mac = nic.GetPhysicalAddress().ToString();
                    if (mac.Length > 0) mac = string.Join(":", Enumerable.Range(0, mac.Length / 2).Select(i => mac.Substring(i * 2, 2)));
                    string ip = "";
                    try
                    {
                        var props = nic.GetIPProperties();
                        var unis = props.UnicastAddresses;
                        foreach (var u in unis)
                        {
                            if (u.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                            { ip = u.Address.ToString(); break; }
                        }
                    }
                    catch { }
                    int idx = _netGrid.Rows.Add(mac, nic.Description, ip);
                    if (!string.IsNullOrEmpty(saved) && (mac == saved || nic.Description == saved))
                        _netGrid.Rows[idx].Selected = true;
                }
            }
            catch { }
        }

        // =================================================================
        //  Badwords
        // =================================================================

        private void BuildPanelBadwords()
        {
            var p = NewPanel("badwords", "🚫 کلمات ممنوعه");
            int y = 60;

            var lblList = MkLabel("لیست کلمات ممنوعه (هر خط یک کلمه):"); lblList.Location = new Point(16, y);
            p.Controls.Add(lblList);
            y += 28;

            _txtBadwords = MkText(_data.BadwordList ?? "", multi: true);
            _txtBadwords.Location = new Point(16, y); _txtBadwords.Size = new Size(760, 200);
            _txtBadwords.ScrollBars = ScrollBars.Both; _txtBadwords.WordWrap = false;
            p.Controls.Add(_txtBadwords);
            y += 210;

            _chkAutoCloseBad = MkCheck("بستن خودکار برنامه", _data.AutoCloseAppOnBadword); _chkAutoCloseBad.Location = new Point(16, y);
            p.Controls.Add(_chkAutoCloseBad);
            y += 30;

            var btnClear = MkBtn("پاک کردن", Color.FromArgb(243, 139, 168)); btnClear.Location = new Point(16, y); btnClear.Size = new Size(120, 30);
            btnClear.Click += (s, e) => _txtBadwords.Text = "";
            p.Controls.Add(btnClear);
            y += 40;

            var lblExtra = MkLabel("پیام/تنظیمات اضافی:"); lblExtra.Location = new Point(16, y);
            p.Controls.Add(lblExtra);
            y += 28;

            _txtBadExtra = MkText(_data.BadwordExtraSettings ?? "", multi: true);
            _txtBadExtra.Location = new Point(16, y); _txtBadExtra.Size = new Size(760, 100);
            p.Controls.Add(_txtBadExtra);
            y += 110;

            _chkShowBadMsg = MkCheck("نمایش پیام به کاربر", _data.ShowMessageOnBadword); _chkShowBadMsg.Location = new Point(16, y);
            p.Controls.Add(_chkShowBadMsg);
            y += 30;

            var btnApply = MkBtn("اعمال تغییرات", Color.FromArgb(166, 227, 161)); btnApply.Location = new Point(16, y); btnApply.Size = new Size(160, 34);
            btnApply.Click += (s, e) =>
            {
                Save();
                MessageBox.Show("✅ تغییرات ذخیره شد.", "اعمال تغییرات", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            p.Controls.Add(btnApply);
        }

        // =================================================================
        //  Operators (Administrator)
        // =================================================================

        private void BuildPanelAdministrator()
        {
            var p = NewPanel("administrator", "👤 مدیر / اپراتورها");
            int y = 60;

            var lblCount = MkLabel("اپراتورها: 0"); lblCount.Location = new Point(16, y); lblCount.Size = new Size(300, 24);
            _lblOpCount = lblCount;
            p.Controls.Add(lblCount);
            y += 28;

            _lstOperators = new ListBox
            {
                Location = new Point(16, y), Size = new Size(280, 200),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            _lstOperators.SelectedIndexChanged += (s, e) =>
            {
                if (_lstOperators.SelectedItem is OpListEntry entry)
                {
                    _txtOpUser.Text = entry.Username;
                    _txtOpFirst.Text = entry.DisplayName;
                    _cboOpLevel.SelectedItem = entry.Role;
                }
            };
            p.Controls.Add(_lstOperators);

            int rx = 320;
            int ry = y;
            _txtOpUser   = AddOpField(p, "نام کاربری:", "", rx, ref ry);
            _txtOpPass   = AddOpField(p, "رمز عبور:", "", rx, ref ry);
            _txtOpPass.UseSystemPasswordChar = true;
            _txtOpFirst  = AddOpField(p, "نام:", "", rx, ref ry);
            _txtOpLast   = AddOpField(p, "نام خانوادگی:", "", rx, ref ry);
            _txtOpHintQ  = AddOpField(p, "سؤال Hint:", "", rx, ref ry);
            _txtOpHintA  = AddOpField(p, "پاسخ Hint:", "", rx, ref ry);
            _txtOpEmail  = AddOpField(p, "ایمیل:", "", rx, ref ry);

            var lblLvl = MkLabel("سطح اپراتور:"); lblLvl.Location = new Point(rx, ry);
            _cboOpLevel = MkCombo("SuperAdmin", "Manager", "Operator");
            _cboOpLevel.Location = new Point(rx + 130, ry - 3); _cboOpLevel.Size = new Size(220, 28);
            _cboOpLevel.SelectedIndex = 2;
            p.Controls.Add(lblLvl); p.Controls.Add(_cboOpLevel);
            ry += 36;

            var btnAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); btnAdd.Location = new Point(rx, ry); btnAdd.Size = new Size(100, 32);
            btnAdd.Click += (s, e) =>
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(_txtOpUser.Text) || string.IsNullOrWhiteSpace(_txtOpPass.Text))
                    { MessageBox.Show("نام کاربری و رمز عبور را وارد کنید.", "اعتبارسنجی", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    var mgr = new OperatorManager();
                    OperatorPermission perm = OperatorPermission.FullAccess;
                    string role = _cboOpLevel.SelectedItem?.ToString() ?? "Operator";
                    if (role == "Manager") perm = OperatorPermission.ManageUsers | OperatorPermission.ManagePricing | OperatorPermission.ViewClients | OperatorPermission.ViewReports | OperatorPermission.StartStopSession | OperatorPermission.AddCredit | OperatorPermission.ManagePayments;
                    if (role == "Operator") perm = OperatorPermission.ViewClients | OperatorPermission.ViewReports | OperatorPermission.StartStopSession | OperatorPermission.AddCredit;
                    mgr.CreateOperator(_txtOpUser.Text, _txtOpPass.Text, _txtOpFirst.Text, perm, role);
                    try { AuditLog.Log("Options", "Operator added: " + _txtOpUser.Text); } catch { }
                    MessageBox.Show("✅ اپراتور اضافه شد.", "افزودن", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ReloadOperators();
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            var btnRemove = MkBtn("حذف", Color.FromArgb(243, 139, 168)); btnRemove.Location = new Point(rx + 110, ry); btnRemove.Size = new Size(100, 32);
            btnRemove.Click += (s, e) =>
            {
                try
                {
                    if (_lstOperators.SelectedItem is OpListEntry entry)
                    {
                        Database.Instance.Execute("DELETE FROM operators WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", entry.Id));
                        try { AuditLog.Log("Options", "Operator removed: " + entry.Username); } catch { }
                        ReloadOperators();
                    }
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            var btnApply = MkBtn("اعمال تغییرات", Color.FromArgb(137, 180, 250)); btnApply.Location = new Point(rx + 220, ry); btnApply.Size = new Size(140, 32);
            btnApply.ForeColor = Color.FromArgb(225, 225, 230);
            btnApply.Click += (s, e) =>
            {
                try
                {
                    if (_lstOperators.SelectedItem is OpListEntry entry)
                    {
                        var role = _cboOpLevel.SelectedItem?.ToString() ?? "Operator";
                        OperatorPermission perm = OperatorPermission.FullAccess;
                        if (role == "Manager") perm = OperatorPermission.ManageUsers | OperatorPermission.ManagePricing | OperatorPermission.ViewClients | OperatorPermission.ViewReports | OperatorPermission.StartStopSession | OperatorPermission.AddCredit | OperatorPermission.ManagePayments;
                        if (role == "Operator") perm = OperatorPermission.ViewClients | OperatorPermission.ViewReports | OperatorPermission.StartStopSession | OperatorPermission.AddCredit;
                        new OperatorManager().UpdateOperator(entry.Id, displayName: _txtOpFirst.Text, perms: perm, role: role);
                        try { AuditLog.Log("Options", "Operator updated: " + entry.Username); } catch { }
                        ReloadOperators();
                        MessageBox.Show("✅ تغییرات اعمال شد.", "اعمال", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            // ADD-MULTI-FEATURES Feature 7: 2FA setup button. Opens the
            // existing TwoFactorSetupForm (which generates a secret, shows
            // it for manual entry into an Authenticator app, and verifies
            // the first 6-digit code before persisting the secret).
            var btn2FA = MkBtn("🔐 فعال‌سازی 2FA", Color.FromArgb(203, 166, 247)); btn2FA.Location = new Point(rx + 370, ry); btn2FA.Size = new Size(170, 32);
            btn2FA.ForeColor = Color.FromArgb(225, 225, 230);
            btn2FA.Click += (s, e) =>
            {
                if (_lstOperators.SelectedItem is OpListEntry entry)
                {
                    try
                    {
                        using (var f = new TwoFactorSetupForm(entry.Id)) f.ShowDialog(this);
                        ReloadOperators();
                    }
                    catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "2FA", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
                else
                {
                    MessageBox.Show("ابتدا یک اپراتور از لیست انتخاب کنید.", "2FA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };
            p.Controls.Add(btnAdd); p.Controls.Add(btnRemove); p.Controls.Add(btnApply); p.Controls.Add(btn2FA);

            ReloadOperators();
        }

        private TextBox AddOpField(Panel p, string label, string initial, int x, ref int y)
        {
            var lbl = MkLabel(label); lbl.Location = new Point(x, y);
            var txt = MkText(initial); txt.Location = new Point(x + 130, y - 3); txt.Size = new Size(220, 28);
            p.Controls.Add(lbl); p.Controls.Add(txt);
            y += 32;
            return txt;
        }

        private struct OpListEntry
        {
            public int Id;
            public string Username;
            public string DisplayName;
            public string Role;
            public override string ToString() => Username + "  —  " + Role;
        }

        private void ReloadOperators()
        {
            try
            {
                _lstOperators.Items.Clear();
                var list = new OperatorManager().GetAllOperators();
                foreach (var op in list)
                {
                    _lstOperators.Items.Add(new OpListEntry
                    {
                        Id = op.Id,
                        Username = op.Username,
                        DisplayName = op.DisplayName ?? op.Username,
                        Role = op.RoleName ?? "Operator"
                    });
                }
                _lblOpCount.Text = "اپراتورها: " + list.Count;
            }
            catch (Exception ex)
            {
                _lblOpCount.Text = "اپراتورها: (خطا در بارگذاری)";
                try { AuditLog.Log("Options", "Operator list load failed: " + ex.Message); } catch { }
            }
        }

        // =================================================================
        //  Pricing — Timers / Prepaid / Play and Pay (enhanced with ListView)
        // =================================================================

        private void BuildPanelPricingTimers()
        {
            var p = NewPanel("pricing_timers", "⏱️ تایمرها (Timers)");
            int y = 60;

            // Default hour price (kept from previous version)
            var lbl = MkLabel("قیمت ساعتی پیش‌فرض (تومان):"); lbl.Location = new Point(16, y);
            _numDefaultHourPrice = new NumericUpDown
            {
                Minimum = 0, Maximum = 1000000, Value = _data.DefaultHourPrice <= 0 ? 5000 : _data.DefaultHourPrice,
                Location = new Point(280, y - 3), Size = new Size(150, 28),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                DecimalPlaces = 0, ThousandsSeparator = true,
            };
            p.Controls.Add(lbl); p.Controls.Add(_numDefaultHourPrice);
            y += 44;

            // Add new timer row
            var lblDur = MkLabel("مدت زمان تایمر (دقیقه):"); lblDur.Location = new Point(16, y);
            _txtTimerDuration = MkText(""); _txtTimerDuration.Location = new Point(220, y - 3); _txtTimerDuration.Size = new Size(120, 28);
            var lblHp = MkLabel("قیمت ساعتی:"); lblHp.Location = new Point(360, y);
            _txtTimerHourPrice = MkText(""); _txtTimerHourPrice.Location = new Point(450, y - 3); _txtTimerHourPrice.Size = new Size(120, 28);
            p.Controls.Add(lblDur); p.Controls.Add(_txtTimerDuration); p.Controls.Add(lblHp); p.Controls.Add(_txtTimerHourPrice);
            y += 36;

            var lblMin = MkLabel("حداقل هزینه:"); lblMin.Location = new Point(16, y);
            _txtTimerMinCost = MkText(""); _txtTimerMinCost.Location = new Point(220, y - 3); _txtTimerMinCost.Size = new Size(120, 28);
            _btnTimerAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnTimerAdd.Location = new Point(360, y - 3); _btnTimerAdd.Size = new Size(100, 28);
            _btnTimerDel = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnTimerDel.Location = new Point(470, y - 3); _btnTimerDel.Size = new Size(100, 28);
            p.Controls.Add(lblMin); p.Controls.Add(_txtTimerMinCost); p.Controls.Add(_btnTimerAdd); p.Controls.Add(_btnTimerDel);
            y += 44;

            _lvTimers = MkListView(new[] { "تایمر (دقیقه)", "قیمت ساعتی", "حداقل هزینه" }, new[] { 180, 180, 180 });
            _lvTimers.Location = new Point(16, y); _lvTimers.Size = new Size(760, 280);
            p.Controls.Add(_lvTimers);

            // Wire Add/Delete
            _btnTimerAdd.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtTimerDuration.Text) || string.IsNullOrWhiteSpace(_txtTimerHourPrice.Text))
                { MessageBox.Show("مدت زمان و قیمت ساعتی را وارد کنید.", "اعتبارسنجی", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                var item = new ListViewItem(_txtTimerDuration.Text.Trim());
                item.SubItems.Add(_txtTimerHourPrice.Text.Trim());
                item.SubItems.Add(string.IsNullOrWhiteSpace(_txtTimerMinCost.Text) ? "0" : _txtTimerMinCost.Text.Trim());
                _lvTimers.Items.Add(item);
                _txtTimerDuration.Text = ""; _txtTimerHourPrice.Text = ""; _txtTimerMinCost.Text = "";
            };
            _btnTimerDel.Click += (s, e) =>
            {
                if (_lvTimers.SelectedItems.Count > 0) _lvTimers.Items.Remove(_lvTimers.SelectedItems[0]);
            };

            // Load saved timer entries
            LoadTimersFromData();
        }

        private void LoadTimersFromData()
        {
            _lvTimers.Items.Clear();
            foreach (var row in ParseCsvRows(_data.TimerEntries))
            {
                if (row.Length < 3) continue;
                var item = new ListViewItem(row[0]);
                item.SubItems.Add(row[1]);
                item.SubItems.Add(row[2]);
                _lvTimers.Items.Add(item);
            }
        }

        private void BuildPanelPricingPrepaid()
        {
            var p = NewPanel("pricing_prepaid", "💳 پیش‌پرداخت (Prepaid)");
            int y = 60;

            _chkPrepaidEnabled = MkCheck("فعال‌سازی پیش‌پرداخت", _data.PrepaidEnabled); _chkPrepaidEnabled.Location = new Point(16, y);
            p.Controls.Add(_chkPrepaidEnabled);
            y += 32;

            var lblMin = MkLabel("حداقل شارژ (تومان):"); lblMin.Location = new Point(16, y);
            _txtPrepaidMin = MkText(_data.PrepaidMinCharge); _txtPrepaidMin.Location = new Point(280, y - 3); _txtPrepaidMin.Size = new Size(150, 28);
            p.Controls.Add(lblMin); p.Controls.Add(_txtPrepaidMin);
            y += 44;

            // New entry row
            var lblName = MkLabel("نام:"); lblName.Location = new Point(16, y);
            _txtPrepName = MkText(""); _txtPrepName.Location = new Point(110, y - 3); _txtPrepName.Size = new Size(150, 28);
            var lblTime = MkLabel("زمان (دقیقه):"); lblTime.Location = new Point(280, y);
            _numPrepTime = MkNum(0, 100000, 60); _numPrepTime.Location = new Point(390, y - 3); _numPrepTime.Size = new Size(90, 28);
            p.Controls.Add(lblName); p.Controls.Add(_txtPrepName); p.Controls.Add(lblTime); p.Controls.Add(_numPrepTime);
            y += 36;

            var lblCost = MkLabel("هزینه:"); lblCost.Location = new Point(16, y);
            _txtPrepCost = MkText(""); _txtPrepCost.Location = new Point(110, y - 3); _txtPrepCost.Size = new Size(150, 28);
            var lblBonus = MkLabel("زمان جایزه (دقیقه):"); lblBonus.Location = new Point(280, y);
            _numPrepBonus = MkNum(0, 100000, 0); _numPrepBonus.Location = new Point(420, y - 3); _numPrepBonus.Size = new Size(90, 28);
            p.Controls.Add(lblCost); p.Controls.Add(_txtPrepCost); p.Controls.Add(lblBonus); p.Controls.Add(_numPrepBonus);
            y += 36;

            _btnPrepAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnPrepAdd.Location = new Point(16, y); _btnPrepAdd.Size = new Size(100, 30);
            _btnPrepClear = MkBtn("پاک کردن", Color.FromArgb(137, 180, 250)); _btnPrepClear.Location = new Point(130, y); _btnPrepClear.Size = new Size(110, 30); _btnPrepClear.ForeColor = Color.FromArgb(225, 225, 230);
            _btnPrepDel = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnPrepDel.Location = new Point(250, y); _btnPrepDel.Size = new Size(100, 30);
            p.Controls.Add(_btnPrepAdd); p.Controls.Add(_btnPrepClear); p.Controls.Add(_btnPrepDel);
            y += 40;

            _lvPrepaid = MkListView(new[] { "نام", "زمان (دقیقه)", "هزینه", "زمان جایزه" }, new[] { 180, 180, 180, 180 });
            _lvPrepaid.Location = new Point(16, y); _lvPrepaid.Size = new Size(760, 240);
            p.Controls.Add(_lvPrepaid);

            // Wire buttons
            _btnPrepAdd.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtPrepCost.Text))
                { MessageBox.Show("هزینه را وارد کنید.", "اعتبارسنجی", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                var item = new ListViewItem(string.IsNullOrWhiteSpace(_txtPrepName.Text) ? "Custom" : _txtPrepName.Text.Trim());
                item.SubItems.Add(((int)_numPrepTime.Value).ToString());
                item.SubItems.Add(_txtPrepCost.Text.Trim());
                item.SubItems.Add(((int)_numPrepBonus.Value).ToString());
                _lvPrepaid.Items.Add(item);
                _txtPrepName.Text = ""; _txtPrepCost.Text = ""; _numPrepTime.Value = 60; _numPrepBonus.Value = 0;
            };
            _btnPrepClear.Click += (s, e) =>
            {
                _txtPrepName.Text = ""; _txtPrepCost.Text = ""; _numPrepTime.Value = 60; _numPrepBonus.Value = 0;
            };
            _btnPrepDel.Click += (s, e) =>
            {
                if (_lvPrepaid.SelectedItems.Count > 0) _lvPrepaid.Items.Remove(_lvPrepaid.SelectedItems[0]);
            };

            LoadPrepaidFromData();
        }

        private void LoadPrepaidFromData()
        {
            _lvPrepaid.Items.Clear();
            foreach (var row in ParseCsvRows(_data.PrepaidEntries))
            {
                if (row.Length < 4) continue;
                var item = new ListViewItem(row[0]);
                item.SubItems.Add(row[1]);
                item.SubItems.Add(row[2]);
                item.SubItems.Add(row[3]);
                _lvPrepaid.Items.Add(item);
            }
        }

        private void BuildPanelPricingPnP()
        {
            var p = NewPanel("pricing_pnp", "🎮 Play and Pay");
            int y = 60;

            _chkPnpEnabled = MkCheck("فعال‌سازی Play and Pay", _data.PnpEnabled); _chkPnpEnabled.Location = new Point(16, y);
            p.Controls.Add(_chkPnpEnabled);
            y += 32;

            var lblDebt = MkLabel("حداکثر بدهی مجاز:"); lblDebt.Location = new Point(16, y);
            _txtPnpMaxDebt = MkText(_data.PnpMaxDebt); _txtPnpMaxDebt.Location = new Point(220, y - 3); _txtPnpMaxDebt.Size = new Size(150, 28);
            p.Controls.Add(lblDebt); p.Controls.Add(_txtPnpMaxDebt);
            y += 32;

            _chkPnpWarn = MkCheck("هشدار قبل از قطع", _data.PnpWarnBeforeDisconnect); _chkPnpWarn.Location = new Point(16, y);
            p.Controls.Add(_chkPnpWarn);
            y += 44;

            // New entry row
            var lblName = MkLabel("نام:"); lblName.Location = new Point(16, y);
            _txtPnpName = MkText(""); _txtPnpName.Location = new Point(110, y - 3); _txtPnpName.Size = new Size(150, 28);
            var lblTime = MkLabel("زمان (دقیقه):"); lblTime.Location = new Point(280, y);
            _numPnpTime = MkNum(0, 100000, 60); _numPnpTime.Location = new Point(390, y - 3); _numPnpTime.Size = new Size(90, 28);
            p.Controls.Add(lblName); p.Controls.Add(_txtPnpName); p.Controls.Add(lblTime); p.Controls.Add(_numPnpTime);
            y += 36;

            var lblCost = MkLabel("هزینه:"); lblCost.Location = new Point(16, y);
            _txtPnpCost = MkText(""); _txtPnpCost.Location = new Point(110, y - 3); _txtPnpCost.Size = new Size(150, 28);
            var lblBonus = MkLabel("زمان جایزه (دقیقه):"); lblBonus.Location = new Point(280, y);
            _numPnpBonus = MkNum(0, 100000, 0); _numPnpBonus.Location = new Point(420, y - 3); _numPnpBonus.Size = new Size(90, 28);
            p.Controls.Add(lblCost); p.Controls.Add(_txtPnpCost); p.Controls.Add(lblBonus); p.Controls.Add(_numPnpBonus);
            y += 36;

            _btnPnpAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnPnpAdd.Location = new Point(16, y); _btnPnpAdd.Size = new Size(100, 30);
            _btnPnpClear = MkBtn("پاک کردن", Color.FromArgb(137, 180, 250)); _btnPnpClear.Location = new Point(130, y); _btnPnpClear.Size = new Size(110, 30); _btnPnpClear.ForeColor = Color.FromArgb(225, 225, 230);
            _btnPnpDel = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnPnpDel.Location = new Point(250, y); _btnPnpDel.Size = new Size(100, 30);
            p.Controls.Add(_btnPnpAdd); p.Controls.Add(_btnPnpClear); p.Controls.Add(_btnPnpDel);
            y += 40;

            _lvPnp = MkListView(new[] { "نام", "زمان (دقیقه)", "هزینه", "زمان جایزه" }, new[] { 180, 180, 180, 180 });
            _lvPnp.Location = new Point(16, y); _lvPnp.Size = new Size(760, 220);
            p.Controls.Add(_lvPnp);

            _btnPnpAdd.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtPnpCost.Text))
                { MessageBox.Show("هزینه را وارد کنید.", "اعتبارسنجی", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                var item = new ListViewItem(string.IsNullOrWhiteSpace(_txtPnpName.Text) ? "Custom" : _txtPnpName.Text.Trim());
                item.SubItems.Add(((int)_numPnpTime.Value).ToString());
                item.SubItems.Add(_txtPnpCost.Text.Trim());
                item.SubItems.Add(((int)_numPnpBonus.Value).ToString());
                _lvPnp.Items.Add(item);
                _txtPnpName.Text = ""; _txtPnpCost.Text = ""; _numPnpTime.Value = 60; _numPnpBonus.Value = 0;
            };
            _btnPnpClear.Click += (s, e) =>
            {
                _txtPnpName.Text = ""; _txtPnpCost.Text = ""; _numPnpTime.Value = 60; _numPnpBonus.Value = 0;
            };
            _btnPnpDel.Click += (s, e) =>
            {
                if (_lvPnp.SelectedItems.Count > 0) _lvPnp.Items.Remove(_lvPnp.SelectedItems[0]);
            };

            LoadPnpFromData();
        }

        private void LoadPnpFromData()
        {
            _lvPnp.Items.Clear();
            foreach (var row in ParseCsvRows(_data.PnpEntries))
            {
                if (row.Length < 4) continue;
                var item = new ListViewItem(row[0]);
                item.SubItems.Add(row[1]);
                item.SubItems.Add(row[2]);
                item.SubItems.Add(row[3]);
                _lvPnp.Items.Add(item);
            }
        }

        // =================================================================
        //  Pricing — Custom Pricing
        // =================================================================

        private void BuildPanelPricingCustom()
        {
            var p = NewPanel("pricing_custom", "🏷️ تعرفه دلخواه (Custom Pricing)");
            int y = 60;

            var lblName = MkLabel("نام:"); lblName.Location = new Point(16, y);
            _txtCustName = MkText(""); _txtCustName.Location = new Point(110, y - 3); _txtCustName.Size = new Size(180, 28);
            var lblHp = MkLabel("قیمت ساعتی:"); lblHp.Location = new Point(310, y);
            _txtCustHourPrice = MkText(""); _txtCustHourPrice.Location = new Point(420, y - 3); _txtCustHourPrice.Size = new Size(140, 28);
            _btnCustAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnCustAdd.Location = new Point(580, y - 3); _btnCustAdd.Size = new Size(100, 28);
            _btnCustDel = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnCustDel.Location = new Point(690, y - 3); _btnCustDel.Size = new Size(80, 28);
            p.Controls.Add(lblName); p.Controls.Add(_txtCustName); p.Controls.Add(lblHp); p.Controls.Add(_txtCustHourPrice);
            p.Controls.Add(_btnCustAdd); p.Controls.Add(_btnCustDel);
            y += 44;

            _lvCustom = MkListView(new[] { "نام", "قیمت ساعتی" }, new[] { 360, 360 });
            _lvCustom.Location = new Point(16, y); _lvCustom.Size = new Size(760, 320);
            p.Controls.Add(_lvCustom);

            _btnCustAdd.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtCustName.Text) || string.IsNullOrWhiteSpace(_txtCustHourPrice.Text))
                { MessageBox.Show("نام و قیمت ساعتی را وارد کنید.", "اعتبارسنجی", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                var item = new ListViewItem(_txtCustName.Text.Trim());
                item.SubItems.Add(_txtCustHourPrice.Text.Trim());
                _lvCustom.Items.Add(item);
                _txtCustName.Text = ""; _txtCustHourPrice.Text = "";
            };
            _btnCustDel.Click += (s, e) =>
            {
                if (_lvCustom.SelectedItems.Count > 0) _lvCustom.Items.Remove(_lvCustom.SelectedItems[0]);
            };

            LoadCustomFromData();
        }

        private void LoadCustomFromData()
        {
            _lvCustom.Items.Clear();
            foreach (var row in ParseCsvRows(_data.CustomPricingEntries))
            {
                if (row.Length < 2) continue;
                var item = new ListViewItem(row[0]);
                item.SubItems.Add(row[1]);
                _lvCustom.Items.Add(item);
            }
        }

        // =================================================================
        //  Pricing — Pricing By Day
        // =================================================================

        private void BuildPanelPricingByDay()
        {
            var p = NewPanel("pricing_day", "📅 تعرفه بر اساس روز (Pricing By Day)");
            int y = 60;

            var lblPick = MkLabel("انتخاب روز:"); lblPick.Location = new Point(16, y);
            p.Controls.Add(lblPick);
            y += 28;

            _lstDays = new ListBox
            {
                Location = new Point(16, y), Size = new Size(200, 180),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            foreach (var d in _dayNames) _lstDays.Items.Add(d);
            _lstDays.SelectedIndexChanged += (s, e) => LoadDaySettingsToFields();
            p.Controls.Add(_lstDays);

            int rx = 250;
            var lblDisc = MkLabel("تخفیف (٪):"); lblDisc.Location = new Point(rx, y);
            _numDayDiscount = MkNum(0, 100, 0); _numDayDiscount.Location = new Point(rx + 110, y - 3); _numDayDiscount.Size = new Size(80, 28);
            p.Controls.Add(lblDisc); p.Controls.Add(_numDayDiscount);
            y += 36;

            var lblHp = MkLabel("قیمت ساعتی:"); lblHp.Location = new Point(rx, y);
            _txtDayHourPrice = MkText(""); _txtDayHourPrice.Location = new Point(rx + 110, y - 3); _txtDayHourPrice.Size = new Size(140, 28);
            p.Controls.Add(lblHp); p.Controls.Add(_txtDayHourPrice);
            y += 36;

            var lblGp = MkLabel("قیمت بازی:"); lblGp.Location = new Point(rx, y);
            _txtDayGamePrice = MkText(""); _txtDayGamePrice.Location = new Point(rx + 110, y - 3); _txtDayGamePrice.Size = new Size(140, 28);
            p.Controls.Add(lblGp); p.Controls.Add(_txtDayGamePrice);
            y += 36;

            _btnDayApply = MkBtn("اعمال", Color.FromArgb(166, 227, 161)); _btnDayApply.Location = new Point(rx, y); _btnDayApply.Size = new Size(120, 32);
            _btnDayApply.Click += (s, e) => ApplyDaySettings();
            p.Controls.Add(_btnDayApply);
            y += 50;

            _lvDays = MkListView(new[] { "روز", "تخفیف (٪)", "قیمت ساعتی", "قیمت بازی" }, new[] { 140, 120, 180, 180 });
            _lvDays.Location = new Point(16, y); _lvDays.Size = new Size(760, 220);
            p.Controls.Add(_lvDays);

            LoadDaysFromData();
            if (_lstDays.Items.Count > 0) _lstDays.SelectedIndex = 0;
        }

        private void LoadDaySettingsToFields()
        {
            int i = _lstDays.SelectedIndex;
            if (i < 0 || i >= _dayNames.Length) return;
            var rows = ParseCsvRows(_data.PricingByDayRows);
            if (i < rows.Length && rows[i].Length >= 4)
            {
                int.TryParse(rows[i][1], out int disc);
                _numDayDiscount.Value = disc;
                _txtDayHourPrice.Text = rows[i][2];
                _txtDayGamePrice.Text = rows[i][3];
            }
            else
            {
                _numDayDiscount.Value = 0;
                _txtDayHourPrice.Text = "";
                _txtDayGamePrice.Text = "";
            }
        }

        private void ApplyDaySettings()
        {
            int i = _lstDays.SelectedIndex;
            if (i < 0 || i >= _dayNames.Length) return;
            var rows = ParseCsvRows(_data.PricingByDayRows);
            // Ensure 7 rows
            var list = rows.ToList();
            while (list.Count < 7)
                list.Add(new[] { _dayNames[list.Count], "0", "", "" });
            list[i] = new[]
            {
                _dayNames[i],
                ((int)_numDayDiscount.Value).ToString(),
                string.IsNullOrWhiteSpace(_txtDayHourPrice.Text) ? "0" : _txtDayHourPrice.Text.Trim(),
                string.IsNullOrWhiteSpace(_txtDayGamePrice.Text) ? "0" : _txtDayGamePrice.Text.Trim(),
            };
            _data.PricingByDayRows = SerializeCsvRows(list);
            LoadDaysFromData();
        }

        private void LoadDaysFromData()
        {
            _lvDays.Items.Clear();
            var rows = ParseCsvRows(_data.PricingByDayRows);
            for (int i = 0; i < _dayNames.Length; i++)
            {
                string disc = "0", hp = "0", gp = "0";
                if (i < rows.Length && rows[i].Length >= 4)
                {
                    disc = rows[i][1]; hp = rows[i][2]; gp = rows[i][3];
                }
                var item = new ListViewItem(_dayNames[i]);
                item.SubItems.Add(disc);
                item.SubItems.Add(hp);
                item.SubItems.Add(gp);
                _lvDays.Items.Add(item);
            }
        }

        // =================================================================
        //  Pricing — Pricing By Time
        // =================================================================

        private void BuildPanelPricingByTime()
        {
            var p = NewPanel("pricing_time", "⏰ تعرفه بر اساس زمان (Pricing By Time)");
            int y = 60;

            var lblPick = MkLabel("انتخاب بازه زمانی:"); lblPick.Location = new Point(16, y);
            p.Controls.Add(lblPick);
            y += 28;

            _lstTimes = new ListBox
            {
                Location = new Point(16, y), Size = new Size(200, 180),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            foreach (var t in _timeSlots) _lstTimes.Items.Add(t);
            _lstTimes.SelectedIndexChanged += (s, e) => LoadTimeSettingsToFields();
            p.Controls.Add(_lstTimes);

            int rx = 250;
            var lblDisc = MkLabel("تخفیف (٪):"); lblDisc.Location = new Point(rx, y);
            _numTimeDiscount = MkNum(0, 100, 0); _numTimeDiscount.Location = new Point(rx + 110, y - 3); _numTimeDiscount.Size = new Size(80, 28);
            p.Controls.Add(lblDisc); p.Controls.Add(_numTimeDiscount);
            y += 36;

            var lblHp = MkLabel("قیمت ساعتی:"); lblHp.Location = new Point(rx, y);
            _txtTimeHourPrice = MkText(""); _txtTimeHourPrice.Location = new Point(rx + 110, y - 3); _txtTimeHourPrice.Size = new Size(140, 28);
            p.Controls.Add(lblHp); p.Controls.Add(_txtTimeHourPrice);
            y += 36;

            var lblGp = MkLabel("قیمت بازی:"); lblGp.Location = new Point(rx, y);
            _txtTimeGamePrice = MkText(""); _txtTimeGamePrice.Location = new Point(rx + 110, y - 3); _txtTimeGamePrice.Size = new Size(140, 28);
            p.Controls.Add(lblGp); p.Controls.Add(_txtTimeGamePrice);
            y += 36;

            _btnTimeApply = MkBtn("اعمال", Color.FromArgb(166, 227, 161)); _btnTimeApply.Location = new Point(rx, y); _btnTimeApply.Size = new Size(120, 32);
            _btnTimeApply.Click += (s, e) => ApplyTimeSettings();
            p.Controls.Add(_btnTimeApply);
            y += 50;

            _lvTimes = MkListView(new[] { "بازه زمانی", "تخفیف (٪)", "قیمت ساعتی", "قیمت بازی" }, new[] { 140, 120, 180, 180 });
            _lvTimes.Location = new Point(16, y); _lvTimes.Size = new Size(760, 220);
            p.Controls.Add(_lvTimes);

            LoadTimesFromData();
            if (_lstTimes.Items.Count > 0) _lstTimes.SelectedIndex = 0;
        }

        private void LoadTimeSettingsToFields()
        {
            int i = _lstTimes.SelectedIndex;
            if (i < 0 || i >= _timeSlots.Length) return;
            var rows = ParseCsvRows(_data.PricingByTimeRows);
            if (i < rows.Length && rows[i].Length >= 4)
            {
                int.TryParse(rows[i][1], out int disc);
                _numTimeDiscount.Value = disc;
                _txtTimeHourPrice.Text = rows[i][2];
                _txtTimeGamePrice.Text = rows[i][3];
            }
            else
            {
                _numTimeDiscount.Value = 0;
                _txtTimeHourPrice.Text = "";
                _txtTimeGamePrice.Text = "";
            }
        }

        private void ApplyTimeSettings()
        {
            int i = _lstTimes.SelectedIndex;
            if (i < 0 || i >= _timeSlots.Length) return;
            var rows = ParseCsvRows(_data.PricingByTimeRows);
            var list = rows.ToList();
            while (list.Count < _timeSlots.Length)
                list.Add(new[] { _timeSlots[list.Count], "0", "", "" });
            list[i] = new[]
            {
                _timeSlots[i],
                ((int)_numTimeDiscount.Value).ToString(),
                string.IsNullOrWhiteSpace(_txtTimeHourPrice.Text) ? "0" : _txtTimeHourPrice.Text.Trim(),
                string.IsNullOrWhiteSpace(_txtTimeGamePrice.Text) ? "0" : _txtTimeGamePrice.Text.Trim(),
            };
            _data.PricingByTimeRows = SerializeCsvRows(list);
            LoadTimesFromData();
        }

        private void LoadTimesFromData()
        {
            _lvTimes.Items.Clear();
            var rows = ParseCsvRows(_data.PricingByTimeRows);
            for (int i = 0; i < _timeSlots.Length; i++)
            {
                string disc = "0", hp = "0", gp = "0";
                if (i < rows.Length && rows[i].Length >= 4)
                {
                    disc = rows[i][1]; hp = rows[i][2]; gp = rows[i][3];
                }
                var item = new ListViewItem(_timeSlots[i]);
                item.SubItems.Add(disc);
                item.SubItems.Add(hp);
                item.SubItems.Add(gp);
                _lvTimes.Items.Add(item);
            }
        }

        // =================================================================
        //  Pricing — Buttons (9 quick-time presets)
        // =================================================================

        private void BuildPanelPricingButtons()
        {
            var p = NewPanel("pricing_buttons", "🔘 دکمه‌های زمان سریع (Buttons)");
            int y = 60;

            var lblIntro = MkLabel("این مقادیر برای دکمه‌های سریع زمان در سایدبار کلاینت استفاده می‌شوند:");
            lblIntro.Location = new Point(16, y); lblIntro.Size = new Size(700, 24);
            lblIntro.ForeColor = Color.FromArgb(180, 140, 20);
            p.Controls.Add(lblIntro);
            y += 40;

            int[] defaults = { 10, 15, 30, 45, 60, 90, 120, 180, 240 };
            var saved = ParseCsvRow(_data.PricingButtons);
            for (int i = 0; i < 9; i++)
            {
                int col = i % 3;
                int row = i / 3;
                int x = 16 + col * 250;
                int yy = y + row * 50;
                var lbl = MkLabel("#" + (i + 1) + ":"); lbl.Location = new Point(x, yy);
                int val = i < saved.Length && int.TryParse(saved[i], out int v) ? v : defaults[i];
                var num = MkNum(1, 1440, val); num.Location = new Point(x + 50, yy - 3); num.Size = new Size(120, 28);
                var lblMin = MkLabel("دقیقه"); lblMin.Location = new Point(x + 180, yy);
                p.Controls.Add(lbl); p.Controls.Add(num); p.Controls.Add(lblMin);
                _numButtons[i] = num;
            }
        }

        // =================================================================
        //  Operators — Operator Levels
        // =================================================================

        private void BuildPanelOperatorLevels()
        {
            var p = NewPanel("oplevels", "🎚️ سطوح اپراتور (Operator Levels)");
            int y = 60;

            // Operators list (left) + Levels list (right)
            var lblOp = MkLabel("اپراتورها:"); lblOp.Location = new Point(16, y);
            _lblOpLevelCount = MkLabel("اپراتورها: 0"); _lblOpLevelCount.Location = new Point(120, y); _lblOpLevelCount.Size = new Size(200, 24);
            var lblLvl = MkLabel("سطوح اپراتور:"); lblLvl.Location = new Point(440, y);
            p.Controls.Add(lblOp); p.Controls.Add(_lblOpLevelCount); p.Controls.Add(lblLvl);
            y += 28;

            _lstOpLevelOperators = new ListBox
            {
                Location = new Point(16, y), Size = new Size(360, 200),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            _lstOpLevels = new ListBox
            {
                Location = new Point(440, y), Size = new Size(340, 200),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
            };
            p.Controls.Add(_lstOpLevelOperators); p.Controls.Add(_lstOpLevels);
            y += 210;

            // Levels buttons (right column)
            _btnLevelAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnLevelAdd.Location = new Point(440, y); _btnLevelAdd.Size = new Size(100, 30);
            _btnLevelEdit = MkBtn("ویرایش", Color.FromArgb(137, 180, 250)); _btnLevelEdit.Location = new Point(550, y); _btnLevelEdit.Size = new Size(100, 30); _btnLevelEdit.ForeColor = Color.FromArgb(225, 225, 230);
            _btnLevelDel = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnLevelDel.Location = new Point(660, y); _btnLevelDel.Size = new Size(100, 30);
            p.Controls.Add(_btnLevelAdd); p.Controls.Add(_btnLevelEdit); p.Controls.Add(_btnLevelDel);

            // Operators buttons (left column)
            _btnLevelOpAdd = MkBtn("افزودن", Color.FromArgb(166, 227, 161)); _btnLevelOpAdd.Location = new Point(16, y); _btnLevelOpAdd.Size = new Size(120, 30);
            _btnLevelOpRemove = MkBtn("حذف", Color.FromArgb(243, 139, 168)); _btnLevelOpRemove.Location = new Point(150, y); _btnLevelOpRemove.Size = new Size(120, 30);
            p.Controls.Add(_btnLevelOpAdd); p.Controls.Add(_btnLevelOpRemove);

            // Wire Levels buttons
            _btnLevelAdd.Click += (s, e) =>
            {
                var name = PromptDialog.Show(this, "نام سطح جدید:", "افزودن سطح اپراتور");
                if (string.IsNullOrWhiteSpace(name)) return;
                if (!_lstOpLevels.Items.Contains(name)) _lstOpLevels.Items.Add(name.Trim());
            };
            _btnLevelEdit.Click += (s, e) =>
            {
                if (_lstOpLevels.SelectedItem == null) return;
                int idx = _lstOpLevels.SelectedIndex;
                var name = PromptDialog.Show(this, "نام جدید:", "ویرایش سطح", _lstOpLevels.SelectedItem.ToString());
                if (string.IsNullOrWhiteSpace(name)) return;
                _lstOpLevels.Items[idx] = name.Trim();
            };
            _btnLevelDel.Click += (s, e) =>
            {
                if (_lstOpLevels.SelectedItem != null) _lstOpLevels.Items.Remove(_lstOpLevels.SelectedItem);
            };

            // Operators Add/Remove (delegate to same flow as Administrator panel)
            _btnLevelOpAdd.Click += (s, e) =>
            {
                try
                {
                    using (var dlg = new QuickOperatorDialog())
                    {
                        if (dlg.ShowDialog(this) == DialogResult.OK)
                        {
                            new OperatorManager().CreateOperator(dlg.Username, dlg.Password, dlg.DisplayName, OperatorPermission.ViewClients | OperatorPermission.StartStopSession | OperatorPermission.AddCredit, "Operator");
                            ReloadOpLevelOperators();
                            try { AuditLog.Log("Options", "Operator added (Operator Levels): " + dlg.Username); } catch { }
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            _btnLevelOpRemove.Click += (s, e) =>
            {
                try
                {
                    if (_lstOpLevelOperators.SelectedItem is OpListEntry entry)
                    {
                        Database.Instance.Execute("DELETE FROM operators WHERE id = @id", cmd => cmd.Parameters.AddWithValue("@id", entry.Id));
                        ReloadOpLevelOperators();
                        try { AuditLog.Log("Options", "Operator removed (Operator Levels): " + entry.Username); } catch { }
                    }
                }
                catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            LoadOpLevelsFromData();
            ReloadOpLevelOperators();
        }

        private void ReloadOpLevelOperators()
        {
            try
            {
                _lstOpLevelOperators.Items.Clear();
                var list = new OperatorManager().GetAllOperators();
                foreach (var op in list)
                {
                    _lstOpLevelOperators.Items.Add(new OpListEntry
                    {
                        Id = op.Id,
                        Username = op.Username,
                        DisplayName = op.DisplayName ?? op.Username,
                        Role = op.RoleName ?? "Operator"
                    });
                }
                if (_lblOpLevelCount != null) _lblOpLevelCount.Text = "اپراتورها: " + list.Count;
            }
            catch (Exception ex)
            {
                if (_lblOpLevelCount != null) _lblOpLevelCount.Text = "اپراتورها: (خطا)";
                try { AuditLog.Log("Options", "Operator levels list load failed: " + ex.Message); } catch { }
            }
        }

        private void LoadOpLevelsFromData()
        {
            _lstOpLevels.Items.Clear();
            foreach (var name in ParseCsvRow(_data.OperatorLevels))
            {
                if (!string.IsNullOrWhiteSpace(name)) _lstOpLevels.Items.Add(name);
            }
        }

        // =================================================================
        //  Printer — Main / Receipt / Ticket / Bulk Tickets
        //  (enhanced to match HandyCafe: default printer picker, monitoring
        //   toggles, multiline templates with placeholders, full bulk-ticket
        //   generator form with company/prefix/expire/amount/qty/time/lengths
        //   + job id and a results ListView.)
        // =================================================================

        private void BuildPanelPrinterMain()
        {
            var p = NewPanel("prt_main", "🖨️ پرینتر (Printer)");
            int y = 60;

            var lblPrinter = MkLabel("پرینتر پیش‌فرض:"); lblPrinter.Location = new Point(16, y);
            _cboDefaultPrinter = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(220, y - 3),
                Size = new Size(360, 28),
            };
            try
            {
                // System.Drawing.Printing.PrinterSettings.InstalledPrinters
                // returns a StringCollection of every printer known to the
                // local spooler (installed printers + network printers).
                foreach (string printer in PrinterSettings.InstalledPrinters)
                    _cboDefaultPrinter.Items.Add(printer);
            }
            catch { /* no printers / spooler not running — leave the combo empty */ }
            if (!string.IsNullOrEmpty(_data.DefaultPrinter) && _cboDefaultPrinter.Items.Contains(_data.DefaultPrinter))
                _cboDefaultPrinter.SelectedItem = _data.DefaultPrinter;
            else if (_cboDefaultPrinter.Items.Count > 0)
                _cboDefaultPrinter.SelectedIndex = 0;
            p.Controls.Add(lblPrinter); p.Controls.Add(_cboDefaultPrinter);
            y += 44;

            _chkPrintMonitoring = MkCheck("فعال‌سازی مانیتورینگ پرینت", _data.EnablePrintMonitoring);
            _chkPrintMonitoring.Location = new Point(16, y);
            p.Controls.Add(_chkPrintMonitoring);
            y += 32;

            _chkNeverAskPrintConfirm = MkCheck("عدم پرسش تایید", _data.NeverAskPrintConfirm);
            _chkNeverAskPrintConfirm.Location = new Point(16, y);
            p.Controls.Add(_chkNeverAskPrintConfirm);
        }

        // --- default templates (used when options.json has no saved value) ---

        private static string DefaultReceiptTemplate()
        {
            return
                "%DATE%\n" +
                "GameNet Internet Club\n" +
                "آدرس: خیابان اصلی، پلاک ۱\n" +
                "تلفن: ۰۲۱-۱۲۳۴۵۶۷۸\n" +
                "----------------------------\n" +
                "زمان شروع: %START_TIME%\n" +
                "زمان پایان: %END_TIME%\n" +
                "هزینه استفاده: %USAGE_COST%\n" +
                "----------------------------\n" +
                "با تشکر از حضور شما";
        }

        private static string DefaultTicketTemplate()
        {
            return
                "GameNet\n" +
                "آدرس: خیابان اصلی، پلاک ۱\n" +
                "تلفن: ۰۲۱-۱۲۳۴۵۶۷۸\n" +
                "----------------------------\n" +
                "تاریخ: %DATE% %TIME%\n" +
                "انقضا: %EXPIRE%\n" +
                "نام کاربری: %USERNAME%\n" +
                "رمز عبور: %PASSWORD%";
        }

        private void BuildPanelReceipt()
        {
            var p = NewPanel("prt_receipt", "🧾 رسید (Receipt)");
            int y = 60;

            var lblTpl = MkLabel("قالب رسید:"); lblTpl.Location = new Point(16, y);
            p.Controls.Add(lblTpl);
            y += 28;

            // Multiline monospace textbox — the receipt body with placeholders
            // that the printing layer will substitute at print time.
            _txtReceiptTemplate = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                AcceptsReturn = true,
                WordWrap = false,
                Text = string.IsNullOrEmpty(_data.ReceiptTemplate) ? DefaultReceiptTemplate() : _data.ReceiptTemplate,
                Font = new Font("Consolas", 10F),
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Location = new Point(16, y),
                Size = new Size(760, 260),
            };
            p.Controls.Add(_txtReceiptTemplate);
            y += 270;

            var btnDesign = MkBtn("طراحی رسید", Color.FromArgb(220, 220, 225));
            btnDesign.Location = new Point(16, y); btnDesign.Size = new Size(160, 32);
            // HandyCafe opens a dedicated visual editor here; for now we just
            // focus the template textbox so the user can edit it in place.
            btnDesign.Click += (s, e) => { _txtReceiptTemplate.Focus(); _txtReceiptTemplate.SelectAll(); };
            p.Controls.Add(btnDesign);
            y += 42;

            // Placeholder legend — explains the %XXX% tokens the printing
            // layer substitutes when a receipt is actually printed.
            var lblHelp = new Label
            {
                Text = "متغیرها:  %DATE% (تاریخ)   |   %START_TIME% (زمان شروع)   |   %END_TIME% (زمان پایان)   |   %USAGE_COST% (هزینه استفاده)",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(16, y),
                MaximumSize = new Size(760, 0),
                AutoSize = true,
            };
            p.Controls.Add(lblHelp);
        }

        private void BuildPanelTicket()
        {
            var p = NewPanel("prt_ticket", "🎫 تیکت (Ticket)");
            int y = 60;

            var lblPrefix = MkLabel("پیشوند نام کاربری:"); lblPrefix.Location = new Point(16, y);
            _txtTicketPrefix = MkText(string.IsNullOrEmpty(_data.TicketUsernamePrefix) ? "TK" : _data.TicketUsernamePrefix);
            _txtTicketPrefix.Location = new Point(220, y - 3); _txtTicketPrefix.Size = new Size(120, 28);
            p.Controls.Add(lblPrefix); p.Controls.Add(_txtTicketPrefix);
            y += 36;

            var lblUserLen = MkLabel("طول نام کاربری:"); lblUserLen.Location = new Point(16, y);
            _numTicketUserLen = MkNum(3, 20, _data.TicketUsernameLength <= 0 ? 5 : _data.TicketUsernameLength);
            _numTicketUserLen.Location = new Point(220, y - 3); _numTicketUserLen.Size = new Size(80, 28);
            p.Controls.Add(lblUserLen); p.Controls.Add(_numTicketUserLen);
            y += 36;

            var lblPassLen = MkLabel("طول رمز عبور:"); lblPassLen.Location = new Point(16, y);
            _numTicketPassLen = MkNum(3, 20, _data.TicketPasswordLength <= 0 ? 5 : _data.TicketPasswordLength);
            _numTicketPassLen.Location = new Point(220, y - 3); _numTicketPassLen.Size = new Size(80, 28);
            p.Controls.Add(lblPassLen); p.Controls.Add(_numTicketPassLen);
            y += 36;

            var lblExpire = MkLabel("انقضا (روز):"); lblExpire.Location = new Point(16, y);
            _numTicketExpireDays = MkNum(0, 3650, (decimal)_data.TicketExpireDays);
            _numTicketExpireDays.Location = new Point(220, y - 3); _numTicketExpireDays.Size = new Size(80, 28);
            var lblExpireHint = MkLabel("(۰ = بدون انقضا)"); lblExpireHint.Location = new Point(310, y); lblExpireHint.ForeColor = Color.FromArgb(20, 140, 130);
            p.Controls.Add(lblExpire); p.Controls.Add(_numTicketExpireDays); p.Controls.Add(lblExpireHint);
            y += 40;

            var lblTpl = MkLabel("قالب تیکت:"); lblTpl.Location = new Point(16, y);
            p.Controls.Add(lblTpl);
            y += 28;

            _txtTicketTemplate = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                AcceptsReturn = true,
                WordWrap = false,
                Text = string.IsNullOrEmpty(_data.TicketTemplate) ? DefaultTicketTemplate() : _data.TicketTemplate,
                Font = new Font("Consolas", 10F),
                BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Location = new Point(16, y),
                Size = new Size(760, 190),
            };
            p.Controls.Add(_txtTicketTemplate);
            y += 200;

            // Action buttons — Test / Reset / Design / Delete Used.
            _btnTicketTest = MkBtn("تست", Color.FromArgb(166, 227, 161));
            _btnTicketTest.Location = new Point(16, y); _btnTicketTest.Size = new Size(110, 32);
            _btnTicketTest.Click += (s, e) => TestTicketTemplate();
            p.Controls.Add(_btnTicketTest);

            _btnTicketReset = MkBtn("بازنشانی", Color.FromArgb(137, 180, 250));
            _btnTicketReset.Location = new Point(134, y); _btnTicketReset.Size = new Size(110, 32);
            _btnTicketReset.Click += (s, e) => _txtTicketTemplate.Text = DefaultTicketTemplate();
            p.Controls.Add(_btnTicketReset);

            _btnTicketDesign = MkBtn("طراحی تیکت", Color.FromArgb(220, 220, 225));
            _btnTicketDesign.Location = new Point(252, y); _btnTicketDesign.Size = new Size(110, 32);
            _btnTicketDesign.Click += (s, e) => { _txtTicketTemplate.Focus(); _txtTicketTemplate.SelectAll(); };
            p.Controls.Add(_btnTicketDesign);

            _btnTicketDeleteUsed = MkBtn("حذف استفاده‌شده‌ها", Color.FromArgb(243, 139, 168));
            _btnTicketDeleteUsed.Location = new Point(370, y); _btnTicketDeleteUsed.Size = new Size(160, 32);
            _btnTicketDeleteUsed.Click += (s, e) => DeleteUsedTickets();
            p.Controls.Add(_btnTicketDeleteUsed);
        }

        // --- Ticket panel button handlers ---

        /// <summary>
        /// Substitutes the template placeholders with sample values and shows
        /// the rendered ticket in a MessageBox so the operator can preview
        /// the layout before printing.
        /// </summary>
        private void TestTicketTemplate()
        {
            try
            {
                int expireDays = (int)_numTicketExpireDays.Value;
                string expireText = expireDays == 0
                    ? "بدون انقضا"
                    : DateTime.Now.AddDays(expireDays).ToString("yyyy/MM/dd");
                string prefix = string.IsNullOrEmpty(_txtTicketPrefix.Text) ? "TK" : _txtTicketPrefix.Text.Trim();
                int userLen = (int)_numTicketUserLen.Value;
                int passLen = (int)_numTicketPassLen.Value;
                var rng = new Random();
                string sample = (_txtTicketTemplate.Text ?? "")
                    .Replace("%DATE%", DateTime.Now.ToString("yyyy/MM/dd"))
                    .Replace("%TIME%", DateTime.Now.ToString("HH:mm"))
                    .Replace("%EXPIRE%", expireText)
                    .Replace("%USERNAME%", GenerateRandomCode(prefix, userLen, rng))
                    .Replace("%PASSWORD%", GenerateRandomCode("", passLen, rng));
                MessageBox.Show(sample, "تست قالب تیکت", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در تست قالب: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Deletes every ticket row whose is_used flag is 1. The confirmation
        /// dialog prevents accidental wipes. The actual DELETE is a single
        /// SQL statement so it's atomic and fast even for thousands of rows.
        /// </summary>
        private void DeleteUsedTickets()
        {
            try
            {
                var dr = MessageBox.Show(
                    "آیا از حذف تمام تیکت‌های استفاده‌شده مطمئن هستید؟\nاین عمل قابل بازگشت نیست.",
                    "تایید حذف",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2);
                if (dr != DialogResult.Yes) return;

                int deleted = Database.Instance.ExecuteNonQuery(
                    "DELETE FROM tickets WHERE is_used = 1", null);
                try { AuditLog.Log("Options", $"Deleted {deleted} used tickets"); } catch { }
                MessageBox.Show($"✅ {deleted} تیکت استفاده‌شده حذف شد.",
                    "حذف تیکت", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در حذف تیکت‌ها: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // =================================================================
        //  Printer — Bulk Tickets (enhanced with company / prefix / expire
        //  date / amount / quantity / remaining-time / username+password
        //  lengths / job-id, plus a Print button and a 5-column ListView.)
        // =================================================================

        private void BuildPanelBulkTickets()
        {
            var p = NewPanel("prt_bulk", "🎟️ تیکت‌های گروهی (Bulk Tickets)");
            int y = 60;

            var lblCompany = MkLabel("نام شرکت:"); lblCompany.Location = new Point(16, y);
            _txtBulkCompany = MkText(_data.BulkCompany); _txtBulkCompany.Location = new Point(220, y - 3); _txtBulkCompany.Size = new Size(260, 28);
            p.Controls.Add(lblCompany); p.Controls.Add(_txtBulkCompany);
            y += 36;

            var lblPrefix = MkLabel("پیشوند:"); lblPrefix.Location = new Point(16, y);
            _txtBulkPrefix = MkText(string.IsNullOrEmpty(_data.BulkPrefix) ? "TK" : _data.BulkPrefix);
            _txtBulkPrefix.Location = new Point(220, y - 3); _txtBulkPrefix.Size = new Size(140, 28);
            p.Controls.Add(lblPrefix); p.Controls.Add(_txtBulkPrefix);
            y += 36;

            var lblExpire = MkLabel("تاریخ انقضا:"); lblExpire.Location = new Point(16, y);
            _dtpBulkExpire = new DateTimePicker
            {
                Format = DateTimePickerFormat.Short,
                Value = ParseBulkExpireDate(_data.BulkExpireDate),
                Location = new Point(220, y - 3), Size = new Size(200, 28),
                BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
            };
            p.Controls.Add(lblExpire); p.Controls.Add(_dtpBulkExpire);
            y += 36;

            var lblAmount = MkLabel("مبلغ:"); lblAmount.Location = new Point(16, y);
            _txtBulkAmount = MkText(string.IsNullOrEmpty(_data.BulkAmount) ? "1000" : _data.BulkAmount);
            _txtBulkAmount.Location = new Point(220, y - 3); _txtBulkAmount.Size = new Size(160, 28);
            p.Controls.Add(lblAmount); p.Controls.Add(_txtBulkAmount);
            y += 36;

            var lblQty = MkLabel("تعداد:"); lblQty.Location = new Point(16, y);
            _numBulkQty = MkNum(1, 1000, _data.BulkQuantity <= 0 ? 10 : _data.BulkQuantity);
            _numBulkQty.Location = new Point(220, y - 3); _numBulkQty.Size = new Size(100, 28);
            p.Controls.Add(lblQty); p.Controls.Add(_numBulkQty);
            y += 36;

            var lblTime = MkLabel("زمان (دقیقه):"); lblTime.Location = new Point(16, y);
            _numBulkTime = MkNum(0, 100000, _data.BulkRemainingTime < 0 ? 60 : _data.BulkRemainingTime);
            _numBulkTime.Location = new Point(220, y - 3); _numBulkTime.Size = new Size(100, 28);
            p.Controls.Add(lblTime); p.Controls.Add(_numBulkTime);
            y += 36;

            var lblUserLen = MkLabel("طول نام کاربری:"); lblUserLen.Location = new Point(16, y);
            _numBulkUserLen = MkNum(3, 20, _data.BulkUsernameLength <= 0 ? 5 : _data.BulkUsernameLength);
            _numBulkUserLen.Location = new Point(220, y - 3); _numBulkUserLen.Size = new Size(80, 28);
            p.Controls.Add(lblUserLen); p.Controls.Add(_numBulkUserLen);
            y += 36;

            var lblPassLen = MkLabel("طول رمز عبور:"); lblPassLen.Location = new Point(16, y);
            _numBulkPassLen = MkNum(3, 20, _data.BulkPasswordLength <= 0 ? 5 : _data.BulkPasswordLength);
            _numBulkPassLen.Location = new Point(220, y - 3); _numBulkPassLen.Size = new Size(80, 28);
            p.Controls.Add(lblPassLen); p.Controls.Add(_numBulkPassLen);
            y += 36;

            var lblJob = MkLabel("شناسه کار:"); lblJob.Location = new Point(16, y);
            _numBulkJobId = MkNum(1, 999999, _data.BulkJobId <= 0 ? 1 : _data.BulkJobId);
            _numBulkJobId.Location = new Point(220, y - 3); _numBulkJobId.Size = new Size(100, 28);
            p.Controls.Add(lblJob); p.Controls.Add(_numBulkJobId);
            y += 44;

            // Generate + Print button row.
            _btnBulkGenerate = MkBtn("تولید", Color.FromArgb(166, 227, 161));
            _btnBulkGenerate.Location = new Point(16, y); _btnBulkGenerate.Size = new Size(140, 34);
            _btnBulkGenerate.Click += (s, e) => GenerateBulkTickets();
            p.Controls.Add(_btnBulkGenerate);

            _btnBulkPrint = MkBtn("چاپ", Color.FromArgb(137, 180, 250));
            _btnBulkPrint.Location = new Point(164, y); _btnBulkPrint.Size = new Size(140, 34);
            // FIX 9: actual print spooler integration. Sends one line per
            // ListView row to the default printer via PrintDocument, with
            // pagination for long batches.
            _btnBulkPrint.Click += (s, e) => PrintBulkTickets(_lvBulkTickets);
            p.Controls.Add(_btnBulkPrint);
            y += 50;

            _lvBulkTickets = MkListView(
                new[] { "کد", "نام کاربری", "رمز عبور", "مبلغ", "زمان" },
                new[] { 180, 160, 140, 140, 100 });
            _lvBulkTickets.Location = new Point(16, y); _lvBulkTickets.Size = new Size(760, 200);
            p.Controls.Add(_lvBulkTickets);
        }

        /// <summary>
        /// Generates a batch of tickets via TicketManager.CreateBatch and
        /// fills the ListView with one row per ticket (code, a freshly
        /// generated username/password pair for display, amount and time).
        /// The username/password are random display values — the Ticket row
        /// itself only stores the code, credit and duration; the prefix and
        /// length fields on this panel control how the printable username
        /// and password are formatted.
        /// </summary>
        private void GenerateBulkTickets()
        {
            try
            {
                int count = (int)_numBulkQty.Value;
                int userLen = (int)_numBulkUserLen.Value;
                int passLen = (int)_numBulkPassLen.Value;
                string prefix = string.IsNullOrEmpty(_txtBulkPrefix.Text) ? "TK" : _txtBulkPrefix.Text.Trim();
                decimal amount;
                if (!decimal.TryParse(_txtBulkAmount.Text, out amount)) amount = 0m;
                int duration = (int)_numBulkTime.Value;
                DateTime? expires = _dtpBulkExpire.Value.Date;

                if (count <= 0)
                {
                    MessageBox.Show("تعداد باید بزرگتر از صفر باشد.", "اعتبارسنجی",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (amount <= 0 && duration <= 0)
                {
                    MessageBox.Show("مبلغ یا زمان باید بزرگتر از صفر باشد.", "اعتبارسنجی",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _lvBulkTickets.Items.Clear();
                var mgr = new TicketManager();
                var list = mgr.CreateBatch(count, amount, duration, "credit", expires, null,
                    $"Bulk generation (job {(int)_numBulkJobId.Value}, company='{_txtBulkCompany.Text}')");
                var rng = new Random();
                foreach (var t in list)
                {
                    string username = GenerateRandomCode(prefix, userLen, rng);
                    string password = GenerateRandomCode("", passLen, rng);
                    var item = new ListViewItem(t.Code ?? "");
                    item.SubItems.Add(username);
                    item.SubItems.Add(password);
                    item.SubItems.Add(t.CreditAmount.ToString("N0"));
                    item.SubItems.Add(t.DurationMinutes.ToString());
                    _lvBulkTickets.Items.Add(item);
                }
                try { AuditLog.Log("Options", $"Bulk tickets generated: count={count}, amount={amount}, duration={duration}"); } catch { }
                MessageBox.Show($"✅ {list.Count} تیکت با موفقیت تولید شد.",
                    "تولید تیکت", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در تولید تیکت: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>Builds a random alphanumeric string of the requested length,
        /// prefixed with the given prefix. Uses the same alphabet as
        /// TicketManager (ambiguous chars 0/O, 1/I excluded) so codes can be
        /// read aloud without confusion.</summary>
        private static string GenerateRandomCode(string prefix, int length, Random rng)
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            var sb = new System.Text.StringBuilder(prefix ?? "");
            for (int i = 0; i < length; i++)
                sb.Append(alphabet[rng.Next(alphabet.Length)]);
            return sb.ToString();
        }

        /// <summary>Parses the BulkExpireDate string from options.json. Falls
        /// back to "today + 1 month" so the picker always shows a sane value
        /// on first run.</summary>
        private static DateTime ParseBulkExpireDate(string s)
        {
            if (string.IsNullOrEmpty(s)) return DateTime.Today.AddMonths(1);
            DateTime dt;
            if (DateTime.TryParse(s, out dt)) return dt;
            return DateTime.Today.AddMonths(1);
        }

        /// <summary>
        /// FIX 9 — Spools the bulk-ticket ListView to the default printer
        /// via PrintDocument. One line per ticket: code | user | pass |
        /// amount. Paginates when the y cursor runs past the bottom margin.
        /// The print runs on the UI thread (short documents are fast enough
        /// that this doesn't freeze the form noticeably — a 100-ticket
        /// batch prints in well under a second).
        /// </summary>
        private void PrintBulkTickets(ListView listView)
        {
            if (listView == null || listView.Items.Count == 0)
            {
                MessageBox.Show("هیچ تیکتی برای چاپ وجود نیست. ابتدا تیکت تولید کنید.",
                    "چاپ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Capture the rows up-front so the PrintPage handler doesn't
            // touch the ListView (which could be mutated by another thread
            // between pages).
            var rows = new List<string[]>();
            foreach (ListViewItem item in listView.Items)
            {
                string c0 = item.SubItems.Count > 0 ? item.SubItems[0].Text : "";
                string c1 = item.SubItems.Count > 1 ? item.SubItems[1].Text : "";
                string c2 = item.SubItems.Count > 2 ? item.SubItems[2].Text : "";
                string c3 = item.SubItems.Count > 3 ? item.SubItems[3].Text : "";
                rows.Add(new[] { c0, c1, c2, c3 });
            }

            int rowIndex = 0; // walked across pages
            var pd = new PrintDocument();
            pd.DocumentName = "GameNet Bulk Tickets";
            // Use the configured default printer if one was set on the
            // Printer panel; otherwise the framework picks the OS default.
            try
            {
                if (!string.IsNullOrEmpty(_data?.DefaultPrinter))
                    pd.PrinterSettings.PrinterName = _data.DefaultPrinter;
            }
            catch { }

            pd.PrintPage += (sender, e) =>
            {
                float y = 20;
                float lineH = 20;
                var font = new Font("Consolas", 8F);
                while (rowIndex < rows.Count)
                {
                    var r = rows[rowIndex];
                    string line = $"کد: {r[0]} | کاربر: {r[1]} | رمز: {r[2]} | مبلغ: {r[3]}";
                    e.Graphics.DrawString(line, font, Brushes.Black, 20, y);
                    y += lineH;
                    rowIndex++;
                    if (y > e.MarginBounds.Bottom)
                    {
                        e.HasMorePages = true;
                        return;
                    }
                }
                e.HasMorePages = false;
            };

            try
            {
                pd.Print();
                try { AuditLog.Log("Options", $"Bulk tickets printed: count={rows.Count}"); } catch { }
                MessageBox.Show("چاپ ارسال شد.", "چاپ",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطای چاپ: " + ex.Message, "چاپ",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // =================================================================
        //  CSV helpers — serialize/deserialize multi-row CSV (rows separated
        //  by ';'  and columns by ',' so a single JSON string can hold all
        //  the ListView rows for a panel).
        // =================================================================

        private static string[][] ParseCsvRows(string csv)
        {
            if (string.IsNullOrEmpty(csv)) return new string[0][];
            var parts = csv.Split(';');
            var rows = new List<string[]>();
            foreach (var part in parts)
            {
                if (string.IsNullOrEmpty(part)) continue;
                rows.Add(part.Split(','));
            }
            return rows.ToArray();
        }

        private static string[] ParseCsvRow(string csv)
        {
            if (string.IsNullOrEmpty(csv)) return new string[0];
            return csv.Split(',');
        }

        private static string SerializeCsvRows(List<string[]> rows)
        {
            return string.Join(";", rows.Select(r => string.Join(",", r)));
        }

        private static string SerializeListView(ListView lv, int colCount)
        {
            if (lv == null || lv.Items.Count == 0) return "";
            var rows = new List<string[]>();
            foreach (ListViewItem item in lv.Items)
            {
                var cols = new List<string>();
                cols.Add(item.Text ?? "");
                for (int i = 1; i < colCount; i++)
                {
                    cols.Add(i < item.SubItems.Count ? (item.SubItems[i].Text ?? "") : "");
                }
                rows.Add(cols.ToArray());
            }
            return SerializeCsvRows(rows);
        }

        // =================================================================
        //  System — Monitoring / Banners / Bandwidth
        // =================================================================

        private void BuildPanelMonitoring()
        {
            var p = NewPanel("sys_monitoring", "📊 مانیتورینگ");
            int y = 60;

            // Existing CPU/RAM + Time + refresh controls
            _chkShowCpuRam = MkCheck("نمایش CPU/RAM", _data.MonitoringShowCpuRam); _chkShowCpuRam.Location = new Point(16, y);
            p.Controls.Add(_chkShowCpuRam);
            y += 30;
            _chkShowTimeMon = MkCheck("نمایش زمان", _data.MonitoringShowTime); _chkShowTimeMon.Location = new Point(16, y);
            p.Controls.Add(_chkShowTimeMon);
            y += 30;
            _chkAutoArrangeIcons = MkCheck("چیدمان خودکار آیکون‌ها", _data.AutoArrangeIcons);
            _chkAutoArrangeIcons.Location = new Point(16, y);
            p.Controls.Add(_chkAutoArrangeIcons);
            y += 40;

            var lblBg = MkLabel("رنگ پس‌زمینه مانیتورینگ:"); lblBg.Location = new Point(16, y);
            _cboMonBgColor = MkCombo("Default", "Dark", "Custom...");
            _cboMonBgColor.Location = new Point(260, y - 3); _cboMonBgColor.Size = new Size(180, 28);
            try
            {
                string bc = _data.MonitoringBgColor ?? "Default";
                int ix = bc == "Dark" ? 1 : bc == "Custom..." ? 2 : 0;
                _cboMonBgColor.SelectedIndex = ix;
            }
            catch { _cboMonBgColor.SelectedIndex = 0; }
            p.Controls.Add(lblBg); p.Controls.Add(_cboMonBgColor);
            y += 40;

            var lblRef = MkLabel("فاصله بروزرسانی (ثانیه):"); lblRef.Location = new Point(16, y);
            _numMonRefresh = MkNum(1, 600, _data.MonitoringRefreshSeconds <= 0 ? 2 : _data.MonitoringRefreshSeconds);
            _numMonRefresh.Location = new Point(260, y - 3); _numMonRefresh.Size = new Size(80, 28);
            p.Controls.Add(lblRef); p.Controls.Add(_numMonRefresh);
            y += 44;

            // Buttons row: Load Defaults + Font...
            var btnLoadDefault = MkBtn("بارگذاری پیش‌فرض", Color.FromArgb(137, 180, 250));
            btnLoadDefault.Location = new Point(16, y); btnLoadDefault.Size = new Size(160, 32);
            btnLoadDefault.ForeColor = Color.FromArgb(225, 225, 230);
            btnLoadDefault.Click += (s, e) =>
            {
                _chkShowCpuRam.Checked = true;
                _chkShowTimeMon.Checked = true;
                _chkAutoArrangeIcons.Checked = true;
                _cboMonBgColor.SelectedIndex = 0;
                _numMonRefresh.Value = 2;
                _monitoringFont = new Font("Segoe UI", 9F);
                _btnMonFont.Text = "🔤 فونت: Segoe UI, 9pt";
            };
            p.Controls.Add(btnLoadDefault);

            _btnMonFont = MkBtn("🔤 فونت...", Color.FromArgb(220, 220, 225));
            _btnMonFont.Location = new Point(190, y); _btnMonFont.Size = new Size(220, 32);
            _btnMonFont.ForeColor = Color.FromArgb(40, 40, 40);
            try
            {
                if (!string.IsNullOrEmpty(_data.MonitoringFont))
                {
                    var parts = _data.MonitoringFont.Split('|');
                    if (parts.Length >= 2)
                    {
                        float fsz;
                        if (float.TryParse(parts[1], out fsz) && fsz > 0)
                            _monitoringFont = new Font(parts[0], fsz);
                    }
                }
            }
            catch { }
            if (_monitoringFont == null) _monitoringFont = new Font("Segoe UI", 9F);
            _btnMonFont.Text = $"🔤 فونت: {_monitoringFont.Name}, {(int)_monitoringFont.Size}pt";
            _btnMonFont.Click += (s, e) =>
            {
                using (var fd = new FontDialog { Font = _monitoringFont, ShowColor = false })
                {
                    if (fd.ShowDialog(this) == DialogResult.OK)
                    {
                        _monitoringFont = fd.Font;
                        _btnMonFont.Text = $"🔤 فونت: {_monitoringFont.Name}, {(int)_monitoringFont.Size}pt";
                    }
                }
            };
            p.Controls.Add(_btnMonFont);
            y += 50;

            // Zebra colors section
            var lblZebraHdr = MkLabel("🎨 تنظیمات Zebra:"); lblZebraHdr.Location = new Point(16, y);
            lblZebraHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblZebraHdr.ForeColor = Color.FromArgb(30, 80, 180);
            p.Controls.Add(lblZebraHdr);
            y += 30;

            // Load persisted zebra colors (try parse ARGB int)
            TryParseColor(_data.ZebraColor1, ref _zebraColor1);
            TryParseColor(_data.ZebraColor2, ref _zebraColor2);
            TryParseColor(_data.ZebraFontColor1, ref _zebraFontColor1);
            TryParseColor(_data.ZebraFontColor2, ref _zebraFontColor2);

            _pnlZebra1 = MkColorBox(_zebraColor1);
            _pnlZebra1.Click += (s, e) => PickColor(_pnlZebra1, ref _zebraColor1);
            AddColorRow(p, ref y, "رنگ Zebra #1:", _pnlZebra1);

            _pnlZebra2 = MkColorBox(_zebraColor2);
            _pnlZebra2.Click += (s, e) => PickColor(_pnlZebra2, ref _zebraColor2);
            AddColorRow(p, ref y, "رنگ Zebra #2:", _pnlZebra2);

            _pnlZebraFont1 = MkColorBox(_zebraFontColor1);
            _pnlZebraFont1.Click += (s, e) => PickColor(_pnlZebraFont1, ref _zebraFontColor1);
            AddColorRow(p, ref y, "رنگ فونت Zebra #1:", _pnlZebraFont1);

            _pnlZebraFont2 = MkColorBox(_zebraFontColor2);
            _pnlZebraFont2.Click += (s, e) => PickColor(_pnlZebraFont2, ref _zebraFontColor2);
            AddColorRow(p, ref y, "رنگ فونت Zebra #2:", _pnlZebraFont2);

            y += 10;
            var btnZebraDefault = MkBtn("بارگذاری پیش‌فرض Zebra", Color.FromArgb(148, 226, 213));
            btnZebraDefault.Location = new Point(16, y); btnZebraDefault.Size = new Size(200, 32);
            btnZebraDefault.ForeColor = Color.FromArgb(225, 225, 230);
            btnZebraDefault.Click += (s, e) =>
            {
                _zebraColor1 = Color.FromArgb(220, 220, 225);
                _zebraColor2 = Color.FromArgb(230, 230, 235);
                _zebraFontColor1 = Color.FromArgb(40, 40, 40);
                _zebraFontColor2 = Color.FromArgb(148, 226, 213);
                _pnlZebra1.BackColor = _zebraColor1;
                _pnlZebra2.BackColor = _zebraColor2;
                _pnlZebraFont1.BackColor = _zebraFontColor1;
                _pnlZebraFont2.BackColor = _zebraFontColor2;
            };
            p.Controls.Add(btnZebraDefault);
        }

        private static Panel MkColorBox(Color c)
        {
            var pnl = new Panel
            {
                Size = new Size(40, 24),
                BackColor = c,
                BorderStyle = BorderStyle.FixedSingle,
                Cursor = Cursors.Hand,
            };
            return pnl;
        }

        private void AddColorRow(Panel p, ref int y, string label, Panel colorBox)
        {
            var lbl = MkLabel(label); lbl.Location = new Point(16, y + 3);
            colorBox.Location = new Point(260, y);
            p.Controls.Add(lbl); p.Controls.Add(colorBox);
            y += 34;
        }

        private void PickColor(Panel target, ref Color storage)
        {
            using (var cd = new ColorDialog { Color = storage })
            {
                if (cd.ShowDialog(this) == DialogResult.OK)
                {
                    storage = cd.Color;
                    target.BackColor = cd.Color;
                }
            }
        }

        private static void TryParseColor(string s, ref Color fallback)
        {
            if (string.IsNullOrEmpty(s)) return;
            try
            {
                int argb = int.Parse(s);
                fallback = Color.FromArgb(argb);
            }
            catch { }
        }

        private void BuildPanelBanners()
        {
            var p = NewPanel("sys_banners", "🖼️ بنرها");
            int y = 60;

            // Keep the existing banner-top text + color picker at the top,
            // then add the new banners ListView below.
            var lbl = MkLabel("متن بنر بالای صفحه:"); lbl.Location = new Point(16, y);
            _txtBannerTop = MkText(_data.BannerTopText); _txtBannerTop.Location = new Point(260, y - 3); _txtBannerTop.Size = new Size(400, 28);
            p.Controls.Add(lbl); p.Controls.Add(_txtBannerTop);
            y += 40;
            var lblColor = MkLabel("رنگ بنر:"); lblColor.Location = new Point(16, y);
            try { _bannerColor = Color.FromArgb(int.Parse(_data.BannerColor)); } catch { _bannerColor = Color.FromArgb(137, 180, 250); }
            _btnBannerColor = MkBtn("انتخاب رنگ", _bannerColor); _btnBannerColor.Location = new Point(260, y - 3); _btnBannerColor.Size = new Size(150, 32);
            _btnBannerColor.Click += (s, e) =>
            {
                using (var cd = new ColorDialog { Color = _bannerColor })
                {
                    if (cd.ShowDialog(this) == DialogResult.OK)
                    {
                        _bannerColor = cd.Color;
                        _btnBannerColor.BackColor = cd.Color;
                    }
                }
            };
            p.Controls.Add(lblColor); p.Controls.Add(_btnBannerColor);
            y += 48;

            // Banners list section
            var lblHdr = MkLabel("لیست بنرها:"); lblHdr.Location = new Point(16, y);
            lblHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblHdr.ForeColor = Color.FromArgb(30, 80, 180);
            _lblBannerCount = new Label
            {
                Text = "بنرها: 0",
                Location = new Point(220, y),
                AutoSize = true,
                ForeColor = Color.FromArgb(20, 140, 130),
                Font = new Font("Segoe UI", 9F),
            };
            p.Controls.Add(lblHdr); p.Controls.Add(_lblBannerCount);
            y += 30;

            _lvBanners = MkListView(new[] { "Banner", "Period", "Path" }, new[] { 180, 100, 320 });
            _lvBanners.Location = new Point(16, y);
            _lvBanners.Size = new Size(620, 240);
            // Load persisted banners (CSV serialized)
            try
            {
                var rows = ParseCsvRows(_data.BannersList);
                foreach (var r in rows)
                {
                    if (r == null || r.Length == 0) continue;
                    var item = new ListViewItem(r[0]);
                    item.SubItems.Add(r.Length > 1 ? r[1] : "");
                    item.SubItems.Add(r.Length > 2 ? r[2] : "");
                    _lvBanners.Items.Add(item);
                }
            }
            catch { }
            UpdateBannerCount();
            p.Controls.Add(_lvBanners);
            y += 250;

            _btnBannerAdd = MkBtn("新增", Color.FromArgb(166, 227, 161));
            _btnBannerAdd.Location = new Point(16, y); _btnBannerAdd.Size = new Size(90, 32);
            _btnBannerAdd.ForeColor = Color.FromArgb(225, 225, 230);
            _btnBannerAdd.Click += (s, e) =>
            {
                using (var dlg = new BannerEditDialog())
                {
                    if (dlg.ShowDialog(this) == DialogResult.OK)
                    {
                        var item = new ListViewItem(dlg.BannerName);
                        item.SubItems.Add(dlg.Period);
                        item.SubItems.Add(dlg.FilePath);
                        _lvBanners.Items.Add(item);
                        UpdateBannerCount();
                    }
                }
            };
            p.Controls.Add(_btnBannerAdd);

            _btnBannerEdit = MkBtn("ویرایش", Color.FromArgb(137, 180, 250));
            _btnBannerEdit.Location = new Point(116, y); _btnBannerEdit.Size = new Size(90, 32);
            _btnBannerEdit.ForeColor = Color.FromArgb(225, 225, 230);
            _btnBannerEdit.Click += (s, e) =>
            {
                if (_lvBanners.SelectedItems.Count == 0)
                {
                    MessageBox.Show("ابتدا یک بنر را انتخاب کنید.", "ویرایش",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                var sel = _lvBanners.SelectedItems[0];
                using (var dlg = new BannerEditDialog(sel.Text,
                    sel.SubItems.Count > 1 ? sel.SubItems[1].Text : "",
                    sel.SubItems.Count > 2 ? sel.SubItems[2].Text : ""))
                {
                    if (dlg.ShowDialog(this) == DialogResult.OK)
                    {
                        sel.Text = dlg.BannerName;
                        if (sel.SubItems.Count > 1) sel.SubItems[1].Text = dlg.Period;
                        else sel.SubItems.Add(dlg.Period);
                        if (sel.SubItems.Count > 2) sel.SubItems[2].Text = dlg.FilePath;
                        else sel.SubItems.Add(dlg.FilePath);
                    }
                }
            };
            p.Controls.Add(_btnBannerEdit);

            _btnBannerDel = MkBtn("حذف", Color.FromArgb(243, 139, 168));
            _btnBannerDel.Location = new Point(216, y); _btnBannerDel.Size = new Size(90, 32);
            _btnBannerDel.ForeColor = Color.FromArgb(225, 225, 230);
            _btnBannerDel.Click += (s, e) =>
            {
                if (_lvBanners.SelectedItems.Count == 0) return;
                if (MessageBox.Show("بنر انتخاب‌شده حذف شود؟", "تایید",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                foreach (ListViewItem it in _lvBanners.SelectedItems) _lvBanners.Items.Remove(it);
                UpdateBannerCount();
            };
            p.Controls.Add(_btnBannerDel);
        }

        private void UpdateBannerCount()
        {
            if (_lblBannerCount != null)
                _lblBannerCount.Text = $"بنرها: {_lvBanners.Items.Count}";
        }

        private void BuildPanelBandwidth()
        {
            var p = NewPanel("sys_bandwidth", "📶 پهنای باند (Bandwidth)");
            int y = 60;

            // Keep the existing simple limit toggle + max speed, then add the
            // new HandyCafe-style warning section below.
            _chkBandwidthLimit = MkCheck("محدودیت پهنای باند", _data.BandwidthLimit); _chkBandwidthLimit.Location = new Point(16, y);
            p.Controls.Add(_chkBandwidthLimit);
            y += 30;
            var lbl = MkLabel("حداکثر سرعت (KB/s):"); lbl.Location = new Point(16, y);
            _numBandwidthMax = MkNum(1, 100000, _data.BandwidthMaxKbps <= 0 ? 100 : _data.BandwidthMaxKbps);
            _numBandwidthMax.Location = new Point(260, y - 3); _numBandwidthMax.Size = new Size(120, 28);
            p.Controls.Add(lbl); p.Controls.Add(_numBandwidthMax);
            y += 44;

            // === Warning section (HandyCafe-style) ===
            _chkBwWarningEnabled = MkCheck("فعال‌سازی هشدار پهنای باند", _data.BandwidthWarningEnabled);
            _chkBwWarningEnabled.Location = new Point(16, y);
            p.Controls.Add(_chkBwWarningEnabled);
            y += 34;

            var lblDl = MkLabel("دانلود (MB/ورود):"); lblDl.Location = new Point(16, y);
            _numBwDownload = MkNum(0, 100000, _data.BandwidthDownloadMB <= 0 ? 20 : _data.BandwidthDownloadMB);
            _numBwDownload.Location = new Point(260, y - 3); _numBwDownload.Size = new Size(120, 28);
            p.Controls.Add(lblDl); p.Controls.Add(_numBwDownload);
            y += 36;

            var lblUl = MkLabel("آپلود (MB/ورود):"); lblUl.Location = new Point(16, y);
            _numBwUpload = MkNum(0, 100000, _data.BandwidthUploadMB <= 0 ? 20 : _data.BandwidthUploadMB);
            _numBwUpload.Location = new Point(260, y - 3); _numBwUpload.Size = new Size(120, 28);
            p.Controls.Add(lblUl); p.Controls.Add(_numBwUpload);
            y += 40;

            _chkBwWarnUser90 = MkCheck("هشدار به کاربر در ۹۰٪", _data.BandwidthWarnUser90);
            _chkBwWarnUser90.Location = new Point(16, y);
            p.Controls.Add(_chkBwWarnUser90);
            y += 30;
            var lblUserMsg = MkLabel("پیام کاربر:"); lblUserMsg.Location = new Point(16, y);
            _txtBwUserMsg = MkText(string.IsNullOrEmpty(_data.BandwidthUserMessage)
                ? "شما به ۹۰٪ محدودیت پهنای باند رسیده‌اید" : _data.BandwidthUserMessage);
            _txtBwUserMsg.Location = new Point(260, y - 3); _txtBwUserMsg.Size = new Size(420, 28);
            p.Controls.Add(lblUserMsg); p.Controls.Add(_txtBwUserMsg);
            y += 40;

            _chkBwWarnServer80 = MkCheck("هشدار به سرور در ۸۰٪", _data.BandwidthWarnServer80);
            _chkBwWarnServer80.Location = new Point(16, y);
            p.Controls.Add(_chkBwWarnServer80);
            y += 30;
            var lblSrvMsg = MkLabel("پیام سرور:"); lblSrvMsg.Location = new Point(16, y);
            _txtBwServerMsg = MkText(string.IsNullOrEmpty(_data.BandwidthServerMessage)
                ? "کلاینت به ۸۰٪ محدودیت پهنای باند رسیده است" : _data.BandwidthServerMessage);
            _txtBwServerMsg.Location = new Point(260, y - 3); _txtBwServerMsg.Size = new Size(420, 28);
            p.Controls.Add(lblSrvMsg); p.Controls.Add(_txtBwServerMsg);
        }

        // =================================================================
        //  Advanced
        // =================================================================

        private void BuildPanelAdvanced()
        {
            var p = NewPanel("advanced", "⚙️ پیشرفته (Advanced)");
            int y = 60;

            _numUdpServer = AddAdvPort(p, "پورت UDP سرور:", _data.UdpServerPort <= 0 ? 710 : _data.UdpServerPort, ref y);
            _numUdpClient = AddAdvPort(p, "پورت UDP کلاینت:", _data.UdpClientPort <= 0 ? 711 : _data.UdpClientPort, ref y);
            _numTcpServer = AddAdvPort(p, "پورت TCP سرور:", _data.TcpServerPort <= 0 ? 9090 : _data.TcpServerPort, ref y);
            _numWebServer = AddAdvPort(p, "پورت وب‌سرور:", _data.WebServerPort, ref y);

            var btnLoadDefault = MkBtn("بارگذاری پیش‌فرض", Color.FromArgb(137, 180, 250)); btnLoadDefault.Location = new Point(16, y); btnLoadDefault.Size = new Size(160, 32);
            btnLoadDefault.ForeColor = Color.FromArgb(225, 225, 230);
            btnLoadDefault.Click += (s, e) =>
            {
                _numUdpServer.Value = 710;
                _numUdpClient.Value = 711;
                _numTcpServer.Value = 9090;
                _numWebServer.Value = 0;
            };
            p.Controls.Add(btnLoadDefault);
            y += 44;

            var lblPass = MkLabel("رمز سرور/کلاینت:"); lblPass.Location = new Point(16, y);
            _txtServerClientPass = MkText(_data.ServerClientPassword); _txtServerClientPass.Location = new Point(220, y - 3); _txtServerClientPass.Size = new Size(280, 28);
            _txtServerClientPass.UseSystemPasswordChar = true;
            p.Controls.Add(lblPass); p.Controls.Add(_txtServerClientPass);
            y += 40;

            // ── FIX B10: TLS / API port / MySQL provider UI ──────────────────
            // These options were previously only editable by hand-editing
            // options.json. Now they're exposed on the Advanced panel.

            // TLS toggle
            _chkUseTls = MkCheck("فعال‌سازی TLS (رمزنگاری ارتباط)", _data.UseTls);
            _chkUseTls.Location = new Point(16, y);
            p.Controls.Add(_chkUseTls);
            y += 34;

            // REST API port (0 = disabled, default 8080 when enabled)
            var lblApiPort = MkLabel("پورت API (۰ = غیرفعال):");
            lblApiPort.Location = new Point(16, y);
            _numApiPort = MkNum(0, 65535, _data.ApiPort);
            _numApiPort.Location = new Point(220, y - 3);
            _numApiPort.Size = new Size(120, 28);
            p.Controls.Add(lblApiPort); p.Controls.Add(_numApiPort);
            y += 34;

            // Database provider selector (SQLite / MySQL)
            var lblDbProvider = MkLabel("پایگاه داده:");
            lblDbProvider.Location = new Point(16, y);
            _cboDbProvider = MkCombo("SQLite (پیش‌فرض)", "MySQL");
            _cboDbProvider.Location = new Point(220, y - 3);
            _cboDbProvider.Size = new Size(220, 28);
            // Select the current provider. Default to SQLite if the value
            // is empty or unrecognized.
            string prov = (_data.DatabaseProvider ?? "sqlite").Trim().ToLowerInvariant();
            _cboDbProvider.SelectedIndex = (prov == "mysql") ? 1 : 0;
            p.Controls.Add(lblDbProvider); p.Controls.Add(_cboDbProvider);
            y += 34;

            // MySQL connection string (only visible when MySQL is selected)
            _lblMySqlConnString = MkLabel("اتصال MySQL:");
            _lblMySqlConnString.Location = new Point(16, y);
            _txtMySqlConnString = MkText(_data.MySqlConnectionString);
            _txtMySqlConnString.Location = new Point(220, y - 3);
            _txtMySqlConnString.Size = new Size(420, 28);
            _txtMySqlConnString.Font = new Font("Consolas", 9F);
            p.Controls.Add(_lblMySqlConnString); p.Controls.Add(_txtMySqlConnString);
            // Toggle visibility based on the selected provider.
            UpdateMySqlControlsVisibility();
            _cboDbProvider.SelectedIndexChanged += (s, e) => UpdateMySqlControlsVisibility();
            y += 34;

            // FIX-MONITOR-ADD5 TASK B5: Telegram bot token + chat id UI.
            // Lets the operator paste the values from @BotFather directly
            // into the Advanced panel instead of hand-editing options.json.
            // Both fields are plain TextBoxes (not password-masked) because
            // the bot token is long and the operator needs to verify it
            // visually; the chat id is a small number.
            var lblTgSection = MkLabel("─ اعلان‌های تلگرام ─");
            lblTgSection.Location = new Point(16, y);
            lblTgSection.ForeColor = Color.FromArgb(30, 80, 180);
            p.Controls.Add(lblTgSection);
            y += 30;

            var lblTgToken = MkLabel("Bot Token:");
            lblTgToken.Location = new Point(16, y);
            _txtTelegramBotToken = MkText(_data.TelegramBotToken ?? "");
            _txtTelegramBotToken.Location = new Point(220, y - 3);
            _txtTelegramBotToken.Size = new Size(420, 28);
            _txtTelegramBotToken.Font = new Font("Consolas", 9F);
            p.Controls.Add(lblTgToken); p.Controls.Add(_txtTelegramBotToken);
            y += 34;

            var lblTgChat = MkLabel("Chat ID:");
            lblTgChat.Location = new Point(16, y);
            _txtTelegramChatId = MkText(_data.TelegramChatId ?? "");
            _txtTelegramChatId.Location = new Point(220, y - 3);
            _txtTelegramChatId.Size = new Size(220, 28);
            _txtTelegramChatId.Font = new Font("Consolas", 9F);
            p.Controls.Add(lblTgChat); p.Controls.Add(_txtTelegramChatId);
            y += 34;
        }

        /// <summary>
        /// FIX B10: shows/hides the MySQL connection-string textbox based on
        /// the selected provider in <see cref="_cboDbProvider"/>.
        /// </summary>
        private void UpdateMySqlControlsVisibility()
        {
            if (_cboDbProvider == null || _txtMySqlConnString == null || _lblMySqlConnString == null) return;
            bool isMySql = _cboDbProvider.SelectedIndex == 1;
            _txtMySqlConnString.Visible = isMySql;
            _lblMySqlConnString.Visible = isMySql;
        }

        private NumericUpDown AddAdvPort(Panel p, string label, int val, ref int y)
        {
            var lbl = MkLabel(label); lbl.Location = new Point(16, y);
            var num = MkNum(0, 65535, val); num.Location = new Point(220, y - 3); num.Size = new Size(120, 28);
            p.Controls.Add(lbl); p.Controls.Add(num);
            y += 34;
            return num;
        }

        // =================================================================
        //  Language
        // =================================================================

        private void BuildPanelLanguage()
        {
            var p = NewPanel("language", "🌐 زبان");
            int y = 60;

            var lbl = MkLabel("زبان‌های موجود:"); lbl.Location = new Point(16, y);
            lbl.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lbl.ForeColor = Color.FromArgb(30, 80, 180);
            p.Controls.Add(lbl);
            y += 30;

            _lvLangs = MkListView(new[] { "Language", "Description" }, new[] { 200, 280 });
            _lvLangs.Location = new Point(16, y);
            _lvLangs.Size = new Size(500, 220);
            _lvLangs.MultiSelect = false;
            _lvLangs.FullRowSelect = true;
            _lvLangs.Click += (s, e) => UpdateLangLabel();
            _lvLangs.SelectedIndexChanged += (s, e) => UpdateLangLabel();

            // Languages: code, native name, description
            var langs = new[]
            {
                new { Code = "de", Name = "Deutsch",      Desc = "German" },
                new { Code = "en", Name = "English",      Desc = "English" },
                new { Code = "es", Name = "Español",      Desc = "Spanish" },
                new { Code = "pt", Name = "Português",    Desc = "Portuguese" },
                new { Code = "tr", Name = "Türkçe",       Desc = "Turkish" },
                new { Code = "fa", Name = "فارسی",        Desc = "Persian" },
                new { Code = "ar", Name = "العربية",      Desc = "Arabic" },
            };
            foreach (var l in langs)
            {
                var item = new ListViewItem(l.Name) { Tag = l.Code };
                item.SubItems.Add(l.Desc);
                _lvLangs.Items.Add(item);
                if (_data.Language == l.Code) item.Selected = true;
            }
            if (_lvLangs.SelectedItems.Count == 0 && _lvLangs.Items.Count > 0)
                _lvLangs.Items[0].Selected = true;
            p.Controls.Add(_lvLangs);
            y += 232;

            var lblFile = MkLabel("فایل زبان:"); lblFile.Location = new Point(16, y);
            _lblLangFile = new Label
            {
                Location = new Point(180, y),
                AutoSize = true,
                ForeColor = Color.FromArgb(20, 140, 130),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Text = "[-]",
            };
            p.Controls.Add(lblFile); p.Controls.Add(_lblLangFile);
            UpdateLangLabel();
            y += 30;

            _btnLangApply = MkBtn("اعمال", Color.FromArgb(166, 227, 161));
            _btnLangApply.Location = new Point(16, y); _btnLangApply.Size = new Size(120, 32);
            _btnLangApply.ForeColor = Color.FromArgb(225, 225, 230);
            _btnLangApply.Click += (s, e) =>
            {
                string code = SelectedLangCode();
                if (string.IsNullOrEmpty(code)) return;
                _data.Language = code;
                try
                {
                    File.WriteAllText(_savePath, JsonConvert.SerializeObject(_data, Formatting.Indented));
                    try { AuditLog.Log("Options", $"Language applied immediately: {code}"); } catch { }
                }
                catch { }
                MessageBox.Show("✅ زبان انتخاب‌شده اعمال شد. تغییرات پس از راه‌اندازی مجدد نرم‌افزار کامل اعمال خواهد شد.",
                    "اعمال زبان", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            p.Controls.Add(_btnLangApply);

            // Keep _cboLang hidden & in sync so the existing Save() switch case
            // (which reads _cboLang.SelectedIndex) keeps working.
            _cboLang = MkCombo("فارسی (FA)", "English (EN)", "العربية (AR)");
            _cboLang.Visible = false;
            p.Controls.Add(_cboLang);
        }

        private string SelectedLangCode()
        {
            if (_lvLangs == null || _lvLangs.SelectedItems.Count == 0) return "fa";
            return _lvLangs.SelectedItems[0].Tag as string ?? "fa";
        }

        private void UpdateLangLabel()
        {
            if (_lblLangFile == null || _lvLangs == null) return;
            if (_lvLangs.SelectedItems.Count == 0)
            {
                _lblLangFile.Text = "[-]";
                if (_cboLang != null) _cboLang.SelectedIndex = 0;
                return;
            }
            var item = _lvLangs.SelectedItems[0];
            string code = item.Tag as string ?? "fa";
            _lblLangFile.Text = $"[{code}] {item.Text}";
            // Mirror to hidden combo so Save()'s legacy switch case stays valid.
            if (_cboLang != null)
            {
                int idx = code == "en" ? 1 : code == "ar" ? 2 : 0;
                _cboLang.SelectedIndex = idx;
            }
        }

        // =================================================================
        //  Backup
        // =================================================================

        private void BuildPanelBackup()
        {
            var p = NewPanel("backup", "💾 پشتیبان‌گیری");
            int y = 60;

            _chkAutoBackup = MkCheck("پشتیبان‌گیری خودکار", _data.AutoBackup); _chkAutoBackup.Location = new Point(16, y);
            p.Controls.Add(_chkAutoBackup);
            y += 35;

            var lblInt = MkLabel("بازه پشتیبان‌گیری (ساعت):"); lblInt.Location = new Point(16, y);
            _numBackupInterval = MkNum(1, 168, _data.BackupIntervalHours <= 0 ? 24 : _data.BackupIntervalHours);
            _numBackupInterval.Location = new Point(260, y - 3); _numBackupInterval.Size = new Size(80, 28);
            p.Controls.Add(lblInt); p.Controls.Add(_numBackupInterval);
            y += 40;

            var lblPath = MkLabel("مسیر ذخیره:"); lblPath.Location = new Point(16, y);
            _txtBackupPath = MkText(_data.BackupPath); _txtBackupPath.Location = new Point(260, y - 3); _txtBackupPath.Size = new Size(340, 28);
            var btnBrowse = MkBtn("browse", Color.FromArgb(220, 220, 225)); btnBrowse.Location = new Point(610, y - 3); btnBrowse.Size = new Size(80, 28);
            btnBrowse.Click += (s, e) =>
            {
                using (var fbd = new FolderBrowserDialog())
                    if (fbd.ShowDialog(this) == DialogResult.OK) _txtBackupPath.Text = fbd.SelectedPath;
            };
            p.Controls.Add(lblPath); p.Controls.Add(_txtBackupPath); p.Controls.Add(btnBrowse);
            y += 45;

            var btnNow = MkBtn("📦 پشتیبان‌گیری اکنون", Color.FromArgb(166, 227, 161)); btnNow.Location = new Point(16, y); btnNow.Size = new Size(200, 36);
            btnNow.Click += (s, e) =>
            {
                try
                {
                    string dir = string.IsNullOrWhiteSpace(_txtBackupPath.Text)
                        ? AppDomain.CurrentDomain.BaseDirectory : _txtBackupPath.Text;
                    if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                    string file = Path.Combine(dir, "gamenet_backup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".db");
                    var src = Database.Instance.DatabaseFilePath;
                    if (File.Exists(src)) File.Copy(src, file, true);
                    MessageBox.Show("✅ پشتیبان در مسیر زیر ذخیره شد:\n" + file, "پشتیبان",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try { AuditLog.Log("Options", "Manual backup taken: " + file); } catch { }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطا در پشتیبان‌گیری: " + ex.Message, "خطا",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            p.Controls.Add(btnNow);
        }

        // =================================================================
        //  Bottom buttons (OK / Cancel)
        // =================================================================

        private void BuildButtons()
        {
            var bar = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = Color.FromArgb(225, 225, 230),
                Padding = new Padding(12, 8, 12, 8),
            };
            var btnCancel = new Button
            {
                Text = "انصراف",
                DialogResult = DialogResult.Cancel,
                Size = new Size(120, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(243, 139, 168),
                ForeColor = Color.FromArgb(225, 225, 230),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            var btnOk = new Button
            {
                Text = "✅ تأیید",
                DialogResult = DialogResult.OK,
                Size = new Size(120, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(166, 227, 161),
                ForeColor = Color.FromArgb(225, 225, 230),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            btnOk.FlatAppearance.BorderSize = 0;
            // FIX L3 (KNOWN LIMITATION): the OK ("تأیید") button's Save()
            // handler reaches each panel's controls via reflection (SetBool /
            // GetBool call PropertyInfo.GetValue/SetValue by name). This is
            // fragile — a renamed property silently desyncs the checkbox from
            // the saved value, and there's no compile-time check that every
            // OptionsData field has a matching UI control. A proper fix
            // requires an ISaveableForm interface that each panel implements
            // (LoadFrom(model) / SaveTo(model)), so the Save() body becomes
            // a typed foreach over panels with no reflection. Out of scope
            // for this pass — the L2 Tag-based change above already closes
            // the worst hole (positional indexing). Revisit when the panel
            // count grows further or when a rename causes a real bug.
            btnOk.Click += (s, e) => Save();

            bar.Resize += (s, e) =>
            {
                btnCancel.Location = new Point(bar.Width - 120 - 12, 8);
                btnOk.Location = new Point(bar.Width - 240 - 20, 8);
            };
            bar.Controls.Add(btnOk);
            bar.Controls.Add(btnCancel);
            this.Controls.Add(bar);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }

        // =================================================================
        //  Panel switching
        // =================================================================

        private void ShowPanel(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (!_panels.TryGetValue(key, out var p)) return;
            if (_currentPanel != null) _currentPanel.Visible = false;
            _currentPanel = p;
            p.Visible = true;
            p.BringToFront();
        }

        // =================================================================
        //  Persistence
        // =================================================================

        private void Save()
        {
            // General
            _data.GuestUsername       = _txtGuestUser.Text;
            _data.ReportsStartTime    = _dtpReportsStart.Value.TimeOfDay;
            _data.DateFormat          = _txtDateFormat.Text;
            _data.Style               = _cboStyle.SelectedItem?.ToString() ?? "Dark";
            if (_generalChks != null)
            {
                // FIX L2: iterate by Tag (the OptionsData property name set in
                // BuildPanelGeneral) so the order of the items array can change
                // without desyncing Save() from the properties it writes.
                foreach (var chk in _generalChks)
                {
                    if (chk?.Tag is string key) SetBool(_data, key, chk.Checked);
                }
            }
            _data.DoubleClickAction   = _cboDoubleClick.SelectedIndex == 1 ? "payment" : "login";

            // Sounds
            _data.SoundLogin = _txtSndLogin.Text;
            _data.SoundTimer = _txtSndTimer.Text;
            _data.SoundOrder = _txtSndOrder.Text;

            // Client
            _data.ClientAdminUser     = _txtClientUser.Text;
            _data.ClientAdminPass     = _txtClientPass.Text;
            _data.IdleShutdownEnabled = _chkIdleShutdown.Checked;
            _data.IdleShutdownMinutes = (int)_numIdleMinutes.Value;
            _data.WarnUserEnabled     = _chkWarnUser.Checked;
            _data.WarnUserMessage     = _txtWarnMsg.Text;
            _data.ClientStyle         = _cboClientStyle.SelectedItem?.ToString() ?? "Dark";
            if (_clientChks != null)
            {
                // FIX L2: iterate by Tag (same pattern as _generalChks above).
                foreach (var chk in _clientChks)
                {
                    if (chk?.Tag is string key) SetBool(_data, key, chk.Checked);
                }
            }

            // Security
            _data.TimefreezePassword     = _txtTimefreeze.Text;
            _data.DeepfreezePassword     = _txtDeepfreeze.Text;
            _data.ShadowDefenderPassword = _txtShadowDefender.Text;
            var drives = new List<string>();
            foreach (var c in _driveChks) if (c.Checked) drives.Add(c.Text);
            _data.ShadowDefenderDrives   = string.Join(",", drives);
            _data.UsbPlugInWarning       = _chkUsbIn.Checked;
            _data.UsbPlugOutWarning      = _chkUsbOut.Checked;

            // Sync
            _data.SyncEnabled        = _chkSyncEnabled.Checked;
            _data.SyncTarget         = _cboSyncTarget.SelectedIndex == 1 ? "selected" : "all";
            var sel = new List<string>();
            foreach (var it in _lstSyncSelected.Items) sel.Add(it.ToString());
            _data.SyncSelectedComputers = string.Join(",", sel);
            _data.ShowSyncLog        = _chkShowSyncLog.Checked;
            _data.ScheduledSync      = _chkScheduledSync.Checked;
            _data.ScheduledSyncMinutes = (int)_numSyncMins.Value;

            // Network
            if (_netGrid.CurrentRow != null)
                _data.NetworkAdapterId = _netGrid.CurrentRow.Cells[0].Value?.ToString() ?? "";

            // Badwords
            _data.BadwordList           = _txtBadwords.Text;
            _data.AutoCloseAppOnBadword = _chkAutoCloseBad.Checked;
            _data.BadwordExtraSettings  = _txtBadExtra.Text;
            _data.ShowMessageOnBadword  = _chkShowBadMsg.Checked;

            // Pricing
            _data.DefaultHourPrice   = (long)_numDefaultHourPrice.Value;
            _data.PrepaidEnabled     = _chkPrepaidEnabled.Checked;
            _data.PrepaidMinCharge   = _txtPrepaidMin.Text;
            _data.PnpEnabled         = _chkPnpEnabled.Checked;
            _data.PnpMaxDebt         = _txtPnpMaxDebt.Text;
            _data.PnpWarnBeforeDisconnect = _chkPnpWarn.Checked;

            // Pricing — Timers / Prepaid / PnP / Custom ListViews
            _data.TimerEntries       = SerializeListView(_lvTimers, 3);
            _data.PrepaidEntries     = SerializeListView(_lvPrepaid, 4);
            _data.PnpEntries         = SerializeListView(_lvPnp, 4);
            _data.CustomPricingEntries = SerializeListView(_lvCustom, 2);

            // Pricing — Pricing By Day / By Time are persisted on Apply click,
            // but also re-flush here in case the user changed fields without Apply.
            // (Apply already wrote to _data, so nothing else to do here.)

            // Pricing — Buttons
            var btnVals = new List<string>();
            for (int i = 0; i < 9; i++) btnVals.Add(((int)_numButtons[i].Value).ToString());
            _data.PricingButtons = string.Join(",", btnVals);

            // Operators — Operator Levels (levels list is in-memory; persist on Save)
            var levels = new List<string>();
            foreach (var it in _lstOpLevels.Items) levels.Add(it.ToString());
            _data.OperatorLevels = string.Join(",", levels);

            // Printer (main) — default printer + monitoring toggles
            _data.DefaultPrinter          = _cboDefaultPrinter.SelectedItem?.ToString() ?? "";
            _data.EnablePrintMonitoring   = _chkPrintMonitoring.Checked;
            _data.NeverAskPrintConfirm    = _chkNeverAskPrintConfirm.Checked;

            // Receipt — multiline template with placeholders
            _data.ReceiptTemplate         = _txtReceiptTemplate.Text;

            // Ticket — generator settings + multiline template
            _data.TicketUsernamePrefix    = _txtTicketPrefix.Text;
            _data.TicketUsernameLength    = (int)_numTicketUserLen.Value;
            _data.TicketPasswordLength    = (int)_numTicketPassLen.Value;
            _data.TicketExpireDays        = (int)_numTicketExpireDays.Value;
            _data.TicketTemplate          = _txtTicketTemplate.Text;

            // Bulk Tickets — full generator form
            _data.BulkCompany             = _txtBulkCompany.Text;
            _data.BulkPrefix              = _txtBulkPrefix.Text;
            _data.BulkExpireDate          = _dtpBulkExpire.Value.ToString("yyyy-MM-dd");
            _data.BulkAmount              = _txtBulkAmount.Text;
            _data.BulkQuantity            = (int)_numBulkQty.Value;
            _data.BulkRemainingTime       = (int)_numBulkTime.Value;
            _data.BulkUsernameLength      = (int)_numBulkUserLen.Value;
            _data.BulkPasswordLength      = (int)_numBulkPassLen.Value;
            _data.BulkJobId               = (int)_numBulkJobId.Value;

            // System
            _data.MonitoringShowCpuRam     = _chkShowCpuRam.Checked;
            _data.MonitoringShowTime       = _chkShowTimeMon.Checked;
            _data.MonitoringRefreshSeconds = (int)_numMonRefresh.Value;
            _data.BannerTopText            = _txtBannerTop.Text;
            _data.BannerColor              = _bannerColor.ToArgb().ToString();
            _data.BandwidthLimit           = _chkBandwidthLimit.Checked;
            _data.BandwidthMaxKbps         = (int)_numBandwidthMax.Value;

            // System — Monitoring (enhanced)
            _data.AutoArrangeIcons         = _chkAutoArrangeIcons.Checked;
            _data.MonitoringBgColor        = _cboMonBgColor.SelectedItem?.ToString() ?? "Default";
            _data.MonitoringFont           = (_monitoringFont != null)
                ? (_monitoringFont.Name + "|" + _monitoringFont.Size.ToString(System.Globalization.CultureInfo.InvariantCulture))
                : "";
            _data.ZebraColor1              = _zebraColor1.ToArgb().ToString();
            _data.ZebraColor2              = _zebraColor2.ToArgb().ToString();
            _data.ZebraFontColor1          = _zebraFontColor1.ToArgb().ToString();
            _data.ZebraFontColor2          = _zebraFontColor2.ToArgb().ToString();

            // System — Banners list
            _data.BannersList              = SerializeListView(_lvBanners, 3);

            // System — Bandwidth warning (enhanced)
            _data.BandwidthWarningEnabled  = _chkBwWarningEnabled.Checked;
            _data.BandwidthDownloadMB      = (int)_numBwDownload.Value;
            _data.BandwidthUploadMB        = (int)_numBwUpload.Value;
            _data.BandwidthWarnUser90      = _chkBwWarnUser90.Checked;
            _data.BandwidthUserMessage     = _txtBwUserMsg.Text;
            _data.BandwidthWarnServer80    = _chkBwWarnServer80.Checked;
            _data.BandwidthServerMessage   = _txtBwServerMsg.Text;

            // Advanced
            _data.UdpServerPort       = (int)_numUdpServer.Value;
            _data.UdpClientPort       = (int)_numUdpClient.Value;
            _data.TcpServerPort       = (int)_numTcpServer.Value;
            _data.WebServerPort       = (int)_numWebServer.Value;
            _data.ServerClientPassword = _txtServerClientPass.Text;

            // FIX B10: persist the new TLS / API port / MySQL provider fields
            // from the Advanced panel controls.
            if (_chkUseTls != null) _data.UseTls = _chkUseTls.Checked;
            if (_numApiPort != null) _data.ApiPort = (int)_numApiPort.Value;
            if (_cboDbProvider != null)
            {
                _data.DatabaseProvider = _cboDbProvider.SelectedIndex == 1 ? "mysql" : "sqlite";
            }
            if (_txtMySqlConnString != null) _data.MySqlConnectionString = _txtMySqlConnString.Text;

            // FIX-MONITOR-ADD5 TASK B5: persist Telegram bot token + chat id.
            // Trim whitespace because operators sometimes paste with trailing
            // newlines from @BotFather's "Copy" button.
            if (_txtTelegramBotToken != null) _data.TelegramBotToken = _txtTelegramBotToken.Text.Trim();
            if (_txtTelegramChatId != null) _data.TelegramChatId = _txtTelegramChatId.Text.Trim();

            // Language (read from ListView selection; fall back to hidden combo)
            string langCode = SelectedLangCode();
            if (!string.IsNullOrEmpty(langCode)) _data.Language = langCode;
            else switch (_cboLang.SelectedIndex)
            {
                case 1:  _data.Language = "en"; break;
                case 2:  _data.Language = "ar"; break;
                default: _data.Language = "fa"; break;
            }

            // Backup
            _data.AutoBackup          = _chkAutoBackup.Checked;
            _data.BackupIntervalHours = (int)_numBackupInterval.Value;
            _data.BackupPath          = _txtBackupPath.Text;

            try
            {
                File.WriteAllText(_savePath, JsonConvert.SerializeObject(_data, Formatting.Indented));
                try { AuditLog.Log("Options", "Settings saved to options.json"); } catch { }
                try { ActivityJournal.Record(ActivityJournal.Settings, "ذخیرهٔ تنظیمات سرور (پنجرهٔ Options)"); } catch { } // round 14
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ذخیره تنظیمات: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private OptionsData LoadOptions()
        {
            try
            {
                if (File.Exists(_savePath))
                {
                    var json = File.ReadAllText(_savePath);
                    var data = JsonConvert.DeserializeObject<OptionsData>(json);
                    if (data != null) return data;
                }
            }
            catch { }
            return new OptionsData();
        }

        /// <summary>
        /// FIX H1 — Static accessor that loads options.json from the server's
        /// base directory without instantiating the (heavy) OptionsForm. Used
        /// by MainForm at startup so the saved TcpServerPort, DefaultHourPrice,
        /// and AutoBackup settings are actually applied before the
        /// ClientCommunicator is constructed.
        /// </summary>
        public static OptionsData LoadStaticOptions()
        {
            try
            {
                var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
                if (File.Exists(path))
                {
                    var json = File.ReadAllText(path);
                    var data = JsonConvert.DeserializeObject<OptionsData>(json);
                    if (data != null) return data;
                }
            }
            catch { }
            return new OptionsData();
        }

        /// <summary>
        /// FIX-MONITOR-ADD5 TASK B5: static saver for callers that don't
        /// have an OptionsForm instance open (e.g. ExtensionsForm's Telegram
        /// tab Save button). Loads the current options.json, applies the
        /// caller's modifications to the passed-in <paramref name="data"/>
        /// (caller is expected to populate the FULL OptionsData — typically
        /// by calling LoadStaticOptions() first and then mutating the
        /// desired fields), and writes it back atomically.
        /// </summary>
        public static void SaveStaticOptions(OptionsData data)
        {
            try
            {
                var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "options.json");
                File.WriteAllText(path, JsonConvert.SerializeObject(data, Formatting.Indented));
            }
            catch { }
        }

        // Reflection helpers — read/write bool properties by name on OptionsData.
        private static bool GetBool(OptionsData d, string name)
        {
            try
            {
                var prop = typeof(OptionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    return (bool)prop.GetValue(d);
            }
            catch { }
            return false;
        }

        private static void SetBool(OptionsData d, string name, bool value)
        {
            try
            {
                var prop = typeof(OptionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    prop.SetValue(d, value);
            }
            catch { }
        }

        /// <summary>Settings model serialized to options.json.</summary>
        public class OptionsData
        {
            // --- General (existing) ---
            public string   GuestUsername       { get; set; } = "guest";
            public TimeSpan ReportsStartTime    { get; set; } = TimeSpan.FromHours(8);
            public string   DateFormat          { get; set; } = "yyyy/MM/dd";
            public string   Style               { get; set; } = "Dark";

            // --- General (new checkboxes) ---
            public bool     RunServerAtStartup      { get; set; } = false;
            public bool     DoubleClickLogin        { get; set; } = true;
            public bool     ShowTrayIcon            { get; set; } = true;
            public bool     PrintReceiptOnPayment   { get; set; } = false;
            public bool     NeverAskConfirm         { get; set; } = false;
            public bool     AutoHideOnMinimize      { get; set; } = false;
            public bool     ShowErrorMessages       { get; set; } = true;
            public bool     ShowDateTime            { get; set; } = true;
            public bool     CaseSensitive           { get; set; } = false;
            public bool     LogEvents               { get; set; } = true;
            public bool     AutoReLogin             { get; set; } = false;
            public bool     IgnoreLoginRequests     { get; set; } = false;
            public bool     UseZebraStyle           { get; set; } = true;
            public bool     AskPasswordOnStartup    { get; set; } = false;
            public string   DoubleClickAction       { get; set; } = "login";

            // --- Sounds ---
            public string   SoundLogin          { get; set; } = "";
            public string   SoundTimer          { get; set; } = "";
            public string   SoundOrder          { get; set; } = "";

            // --- Client (existing) ---
            public string   ClientAdminUser     { get; set; } = "admin";
            public string   ClientAdminPass     { get; set; } = "";
            public bool     IdleShutdownEnabled { get; set; } = false;
            public int      IdleShutdownMinutes { get; set; } = 15;
            public bool     WarnUserEnabled     { get; set; } = true;
            public string   WarnUserMessage     { get; set; } = "سیستم تا ۱ دقیقه دیگر خاموش می‌شود.";
            public string   ClientStyle         { get; set; } = "Dark";

            // --- Client (new checkboxes) ---
            public bool     DisableWinShutdown         { get; set; } = false;
            public bool     ShowPcNameOnScreen         { get; set; } = true;
            public bool     EnableOrdering             { get; set; } = true;
            public bool     EnableAdminLoginFromServer { get; set; } = true;
            public bool     TerminateAppsOnLogout      { get; set; } = true;
            public bool     RebootClientOnPayment      { get; set; } = false;
            public bool     ShutdownClientOnPayment    { get; set; } = false;
            public bool     DisableCafeteria           { get; set; } = false;
            public bool     DisableHide                { get; set; } = false;
            public bool     DisableLogout              { get; set; } = false;
            public bool     DisableLoginRequest        { get; set; } = false;
            public bool     HideRemainingTime          { get; set; } = false;
            public bool     HideStartTime              { get; set; } = false;
            public bool     HideUsedTime               { get; set; } = false;
            public bool     HideCost                   { get; set; } = false;

            // --- Security ---
            public string   TimefreezePassword     { get; set; } = "";
            public string   DeepfreezePassword     { get; set; } = "";
            public string   ShadowDefenderPassword { get; set; } = "";
            public string   ShadowDefenderDrives   { get; set; } = "";
            public bool     UsbPlugInWarning       { get; set; } = true;
            public bool     UsbPlugOutWarning      { get; set; } = false;

            // --- Sync ---
            // FIX DEAD-CONFIG-6: default changed false → true, for the same
            // reason as ShowSyncLog above — "همگام‌سازی الان" always worked
            // before this flag had a consumer; leaving the default at false
            // would silently disable that button for every existing
            // install the moment this fix ships, with no checkbox ever
            // having been touched.
            public bool     SyncEnabled            { get; set; } = true;
            public string   SyncTarget             { get; set; } = "all";
            public string   SyncSelectedComputers  { get; set; } = "";
            // FIX DEAD-CONFIG-6: default changed false → true. The log panel
            // was unconditionally visible before ShowSyncLog had any
            // consumer; defaulting the option itself to false would have
            // hidden it for every existing install the first time this
            // setting actually took effect, even though nobody unchecked
            // anything. true preserves prior behavior for everyone who
            // hasn't touched this checkbox.
            public bool     ShowSyncLog            { get; set; } = true;
            public bool     ScheduledSync          { get; set; } = false;
            public int      ScheduledSyncMinutes   { get; set; } = 5;

            // --- Network ---
            public string   NetworkAdapterId       { get; set; } = "";

            // --- Badwords ---
            public string   BadwordList            { get; set; } = "";
            public bool     AutoCloseAppOnBadword  { get; set; } = false;
            public string   BadwordExtraSettings   { get; set; } = "";
            public bool     ShowMessageOnBadword   { get; set; } = true;

            // --- Pricing ---
            public long     DefaultHourPrice       { get; set; } = 5000;
            public bool     PrepaidEnabled         { get; set; } = true;
            public string   PrepaidMinCharge       { get; set; } = "1000";
            public bool     PnpEnabled             { get; set; } = false;
            public string   PnpMaxDebt             { get; set; } = "5000";
            public bool     PnpWarnBeforeDisconnect { get; set; } = true;

            // --- Pricing — Timers / Prepaid / PnP / Custom / By Day / By Time / Buttons ---
            public string   TimerEntries           { get; set; } = "";
            public string   PrepaidEntries         { get; set; } = "";
            public string   PnpEntries             { get; set; } = "";
            public string   CustomPricingEntries   { get; set; } = "";
            public string   PricingByDayRows       { get; set; } = "";
            public string   PricingByTimeRows      { get; set; } = "";
            public string   PricingButtons         { get; set; } = "10,15,30,45,60,90,120,180,240";

            // --- Operators — Operator Levels ---
            public string   OperatorLevels         { get; set; } = "";

            // --- Printer (legacy, retained for backward-compat with older options.json) ---
            public bool     PrintReceipt           { get; set; } = false;
            public string   ReceiptPaperSize       { get; set; } = "A5";
            public string   ReceiptHeaderText      { get; set; } = "";
            public string   ReceiptFooterText      { get; set; } = "";
            public bool     PrintTicket            { get; set; } = false;
            public string   TicketPaperSize        { get; set; } = "Thermal (58mm)";
            public int      TicketColumns          { get; set; } = 1;

            // --- Printer (main) — HandyCafe default-printer + monitoring toggles ---
            public string   DefaultPrinter         { get; set; } = "";
            public bool     EnablePrintMonitoring  { get; set; } = false;
            public bool     NeverAskPrintConfirm   { get; set; } = false;

            // --- Receipt — multiline template with placeholders ---
            public string   ReceiptTemplate        { get; set; } = "";

            // --- Ticket — generator settings + multiline template ---
            public string   TicketUsernamePrefix   { get; set; } = "TK";
            public int      TicketUsernameLength   { get; set; } = 5;
            public int      TicketPasswordLength   { get; set; } = 5;
            public int      TicketExpireDays       { get; set; } = 0;
            public string   TicketTemplate         { get; set; } = "";

            // --- Bulk Tickets — full generator form ---
            public string   BulkCompany            { get; set; } = "";
            public string   BulkPrefix             { get; set; } = "TK";
            public string   BulkExpireDate         { get; set; } = "";
            public string   BulkAmount             { get; set; } = "1000";
            public int      BulkQuantity           { get; set; } = 10;
            public int      BulkRemainingTime      { get; set; } = 60;
            public int      BulkUsernameLength     { get; set; } = 5;
            public int      BulkPasswordLength     { get; set; } = 5;
            public int      BulkJobId              { get; set; } = 1;

            // --- System ---
            public bool     MonitoringShowCpuRam       { get; set; } = true;
            public bool     MonitoringShowTime         { get; set; } = true;
            public int      MonitoringRefreshSeconds   { get; set; } = 2;
            public string   BannerTopText              { get; set; } = "";
            public string   BannerColor                { get; set; } = "";
            public bool     BandwidthLimit             { get; set; } = false;
            public int      BandwidthMaxKbps           { get; set; } = 100;

            // --- System — Monitoring (enhanced) ---
            public bool     AutoArrangeIcons           { get; set; } = true;
            public string   MonitoringBgColor          { get; set; } = "Default";
            public string   MonitoringFont             { get; set; } = "";
            public string   ZebraColor1                { get; set; } = "";
            public string   ZebraColor2                { get; set; } = "";
            public string   ZebraFontColor1            { get; set; } = "";
            public string   ZebraFontColor2            { get; set; } = "";

            // --- System — Banners list (CSV-serialized rows: Banner,Period,Path) ---
            public string   BannersList                { get; set; } = "";

            // --- System — Bandwidth warning (enhanced) ---
            public bool     BandwidthWarningEnabled    { get; set; } = false;
            public int      BandwidthDownloadMB        { get; set; } = 20;
            public int      BandwidthUploadMB          { get; set; } = 20;
            public bool     BandwidthWarnUser90        { get; set; } = true;
            public string   BandwidthUserMessage       { get; set; } = "شما به ۹۰٪ محدودیت پهنای باند رسیده‌اید";
            public bool     BandwidthWarnServer80      { get; set; } = true;
            public string   BandwidthServerMessage     { get; set; } = "کلاینت به ۸۰٪ محدودیت پهنای باند رسیده است";

            // --- Advanced ---
            public int      UdpServerPort          { get; set; } = 710;
            public int      UdpClientPort          { get; set; } = 711;
            public int      TcpServerPort          { get; set; } = 9090;
            public int      WebServerPort          { get; set; } = 0;
            public string   ServerClientPassword   { get; set; } = "";

            // --- Language ---
            public string   Language            { get; set; } = "fa";

            // --- Backup ---
            public bool     AutoBackup          { get; set; } = false;
            public int      BackupIntervalHours { get; set; } = 24;
            public string   BackupPath          { get; set; } = "";

            // --- ADD-MULTI-FEATURES Feature 1: MySQL backend ---
            // Default "sqlite" so existing installs keep working. Set to
            // "mysql" (with a non-empty MySqlConnectionString) to enable the
            // MySQL backend — see Database.InitializeMySQL for caveats.
            public string   DatabaseProvider        { get; set; } = "sqlite";
            public string   MySqlConnectionString   { get; set; } = "";

            // --- ADD-MULTI-FEATURES Feature 2: REST API server port ---
            // Default 0 = the RestApiServer is not auto-started. Set to 8080
            // (or any free port) to expose /api/clients, /api/users, /api/status
            // etc. for external mobile/web integrations.
            public int      ApiPort                 { get; set; } = 0;

            // --- ADD-MULTI-FEATURES Feature 6: TLS encryption ---
            // Default ON (Fix 1) — TLS server-side wrapping of the TCP client
            // stream. When true, the server uses TlsWrapper (auto-generated
            // self-signed cert on first run) and the client must also enable
            // TLS in its connection settings.
            public bool     UseTls                  { get; set; } = true;

            // --- FIX-MONITOR-ADD5 TASK B5: Telegram bot notifications ---
            // Both default to empty so Telegram is disabled out-of-the-box.
            // The operator enables it via OptionsForm → Advanced → Telegram:
            //   1. Create a bot via @BotFather, copy the bot token.
            //   2. Start a chat with the bot, send any message, then visit
            //      https://api.telegram.org/bot<TOKEN>/getUpdates to find
            //      the chat id (numerical).
            //   3. Paste both into OptionsForm. MainForm reads them on
            //      startup and calls TelegramNotifier.Configure().
            // Notifications (topup / session-end / disconnect) are then
            // pushed to the operator's Telegram so they don't have to watch
            // the server UI continuously.
            public string   TelegramBotToken        { get; set; } = "";
            public string   TelegramChatId          { get; set; } = "";
        }
    }

    // ====================================================================
    //  Helper dialogs used by the OptionsForm pricing/operators panels.
    //  PromptDialog — simple text-input modal (for naming operator levels).
    //  QuickOperatorDialog — username/password/display-name form used by
    //  the Operator Levels panel when adding an operator on the fly.
    // ====================================================================

    internal static class PromptDialog
    {
        public static string Show(IWin32Window owner, string label, string title, string initial = "")
        {
            using (var f = new Form
            {
                Text = title,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                ClientSize = new Size(380, 130),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 9F),
                RightToLeft = RightToLeft.Yes,
                MinimizeBox = false, MaximizeBox = false,
            })
            {
                var lbl = new Label
                {
                    Text = label, Location = new Point(16, 16), AutoSize = true,
                    ForeColor = Color.FromArgb(40, 40, 40),
                };
                var txt = new TextBox
                {
                    Text = initial, Location = new Point(16, 44), Size = new Size(340, 28),
                    BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40),
                    BorderStyle = BorderStyle.FixedSingle,
                };
                var btnOk = new Button
                {
                    Text = "تأیید", DialogResult = DialogResult.OK,
                    Location = new Point(180, 84), Size = new Size(80, 32),
                    FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(166, 227, 161),
                    ForeColor = Color.FromArgb(225, 225, 230),
                };
                btnOk.FlatAppearance.BorderSize = 0;
                var btnCancel = new Button
                {
                    Text = "انصراف", DialogResult = DialogResult.Cancel,
                    Location = new Point(270, 84), Size = new Size(80, 32),
                    FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(243, 139, 168),
                    ForeColor = Color.FromArgb(225, 225, 230),
                };
                btnCancel.FlatAppearance.BorderSize = 0;
                f.Controls.AddRange(new Control[] { lbl, txt, btnOk, btnCancel });
                f.AcceptButton = btnOk; f.CancelButton = btnCancel;
                return f.ShowDialog(owner) == DialogResult.OK ? txt.Text : null;
            }
        }
    }

    internal class QuickOperatorDialog : Form
    {
        public string Username { get; private set; } = "";
        public string Password { get; private set; } = "";
        public string DisplayName { get; private set; } = "";

        private readonly TextBox _txtUser, _txtPass, _txtDisplay;

        public QuickOperatorDialog()
        {
            this.Text = "افزودن اپراتور";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ClientSize = new Size(380, 200);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.Font = new Font("Segoe UI", 9F);
            this.RightToLeft = RightToLeft.Yes;
            this.MinimizeBox = false; this.MaximizeBox = false;

            var lblU = new Label { Text = "نام کاربری:", Location = new Point(16, 16), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtUser = new TextBox { Location = new Point(150, 13), Size = new Size(200, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            var lblP = new Label { Text = "رمز عبور:", Location = new Point(16, 56), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPass = new TextBox { Location = new Point(150, 53), Size = new Size(200, 28), UseSystemPasswordChar = true, BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            var lblD = new Label { Text = "نام نمایشی:", Location = new Point(16, 96), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtDisplay = new TextBox { Location = new Point(150, 93), Size = new Size(200, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            var btnOk = new Button
            {
                Text = "تأیید", DialogResult = DialogResult.OK,
                Location = new Point(180, 144), Size = new Size(80, 32),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(166, 227, 161),
                ForeColor = Color.FromArgb(225, 225, 230),
            };
            btnOk.FlatAppearance.BorderSize = 0;
            var btnCancel = new Button
            {
                Text = "انصراف", DialogResult = DialogResult.Cancel,
                Location = new Point(270, 144), Size = new Size(80, 32),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(243, 139, 168),
                ForeColor = Color.FromArgb(225, 225, 230),
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            this.Controls.AddRange(new Control[] { lblU, _txtUser, lblP, _txtPass, lblD, _txtDisplay, btnOk, btnCancel });
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
            this.FormClosing += (s, e) =>
            {
                if (this.DialogResult == DialogResult.OK)
                {
                    Username = _txtUser.Text.Trim();
                    Password = _txtPass.Text;
                    DisplayName = _txtDisplay.Text.Trim();
                }
            };
        }
    }

    // ====================================================================
    //  BannerEditDialog — modal used by the Banners panel to add/edit a
    //  banner entry (name / period / file path). Matches the dark theme.
    // ====================================================================
    internal class BannerEditDialog : Form
    {
        public string BannerName { get; private set; } = "";
        public string Period     { get; private set; } = "";
        public string FilePath   { get; private set; } = "";

        private readonly TextBox _txtName, _txtPeriod, _txtPath;

        public BannerEditDialog() : this("", "", "") { }

        public BannerEditDialog(string name, string period, string path)
        {
            this.Text = string.IsNullOrEmpty(name) ? "افزودن بنر" : "ویرایش بنر";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ClientSize = new Size(460, 220);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.Font = new Font("Segoe UI", 9F);
            this.RightToLeft = RightToLeft.Yes;
            this.MinimizeBox = false; this.MaximizeBox = false;

            var lblN = new Label { Text = "نام بنر:", Location = new Point(16, 16), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtName = new TextBox { Text = name, Location = new Point(150, 13), Size = new Size(280, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            var lblP = new Label { Text = "دوره (ثانیه):", Location = new Point(16, 56), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPeriod = new TextBox { Text = period, Location = new Point(150, 53), Size = new Size(280, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };

            var lblPath = new Label { Text = "مسیر فایل:", Location = new Point(16, 96), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            _txtPath = new TextBox { Text = path, Location = new Point(150, 93), Size = new Size(280, 28), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40), BorderStyle = BorderStyle.FixedSingle };
            var btnBrowse = new Button
            {
                Text = "browse", Location = new Point(150, 124), Size = new Size(80, 28),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(220, 220, 225),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            btnBrowse.FlatAppearance.BorderSize = 0;
            btnBrowse.Click += (s, e) =>
            {
                using (var ofd = new OpenFileDialog { Filter = "Image files|*.jpg;*.jpeg;*.png;*.bmp;*.gif|All files|*.*" })
                {
                    if (ofd.ShowDialog(this) == DialogResult.OK) _txtPath.Text = ofd.FileName;
                }
            };

            var btnOk = new Button
            {
                Text = "تأیید", DialogResult = DialogResult.OK,
                Location = new Point(240, 168), Size = new Size(90, 32),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(166, 227, 161),
                ForeColor = Color.FromArgb(225, 225, 230),
            };
            btnOk.FlatAppearance.BorderSize = 0;
            var btnCancel = new Button
            {
                Text = "انصراف", DialogResult = DialogResult.Cancel,
                Location = new Point(340, 168), Size = new Size(90, 32),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(243, 139, 168),
                ForeColor = Color.FromArgb(225, 225, 230),
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            this.Controls.AddRange(new Control[] { lblN, _txtName, lblP, _txtPeriod, lblPath, _txtPath, btnBrowse, btnOk, btnCancel });
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
            this.FormClosing += (s, e) =>
            {
                if (this.DialogResult == DialogResult.OK)
                {
                    BannerName = _txtName.Text.Trim();
                    Period     = _txtPeriod.Text.Trim();
                    FilePath   = _txtPath.Text.Trim();
                }
            };
        }
    }
}
