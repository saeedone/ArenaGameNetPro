using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class TwoFactorSetupForm : Form
    {
        private readonly TwoFactorAuth _2fa = new TwoFactorAuth();
        private readonly int _operatorId;
        private string _secret;

        public TwoFactorSetupForm(int operatorId)
        {
            _operatorId = operatorId;
            this.Text = "تنظیم احراز هویت دو مرحله‌ای";
            this.Size = new Size(500, 520);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            var lblTitle = new Label { Text = "🔐 احراز هویت دو مرحله‌ای (2FA)", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 15), AutoSize = true };

            bool alreadyEnabled = _2fa.Is2FAEnabled(_operatorId);

            _secret = _2fa.GenerateSecret();
            var uri = _2fa.GenerateOtpAuthUri("operator", _secret);

            var lblStep1 = new Label { Text = "مرحله ۱: اپلیکیشن Authenticator را نصب کنید", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(20, 60), AutoSize = true };
            var lblApps = new Label { Text = "Google Authenticator / Microsoft Authenticator / Authy", Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(40, 40, 40), Location = new Point(30, 85), AutoSize = true };

            var lblStep2 = new Label { Text = "مرحله ۲: این کد مخفی را وارد کنید:", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(20, 120), AutoSize = true };
            var txtSecret = new TextBox { Text = _secret, Location = new Point(20, 145), Size = new Size(440, 30), Font = new Font("Consolas", 11F), BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(180, 140, 20), ReadOnly = true };
            var btnCopy = new Button { Text = "📋 کپی", Location = new Point(350, 180), Size = new Size(110, 30), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnCopy.Click += (s, e) => { Clipboard.SetText(_secret); MessageBox.Show("کپی شد!"); };

            var lblStep3 = new Label { Text = "مرحله ۳: کد ۶ رقمی را وارد کنید:", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(20, 130, 50), Location = new Point(20, 225), AutoSize = true };
            var txtCode = new TextBox { Location = new Point(20, 250), Size = new Size(200, 35), Font = new Font("Consolas", 16F), MaxLength = 6, BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };

            var btnVerify = new Button { Text = "✅ تأیید و فعال‌سازی", Location = new Point(20, 300), Size = new Size(200, 42), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnVerify.Click += (s, e) =>
            {
                if (string.IsNullOrEmpty(txtCode.Text) || txtCode.Text.Length != 6)
                { MessageBox.Show("لطفاً کد ۶ رقمی را وارد کنید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (_2fa.ValidateCode(_secret, txtCode.Text))
                {
                    _2fa.Enable2FAForOperator(_operatorId, _secret);
                    MessageBox.Show("احراز هویت دو مرحله‌ای با موفقیت فعال شد!", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else MessageBox.Show("کد نامعتبر است. دوباره تلاش کنید.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            // ---- Disable 2FA section (gated behind a current TOTP code) ----
            // Previously this was a single Yes/No confirmation - now the operator
            // MUST supply a valid TOTP code from their existing authenticator to
            // disable 2FA. This stops a passer-by (or a hijacked session) from
            // trivially turning 2FA off by clicking through a MessageBox.
            var lblDisable = new Label { Text = "غیرفعال‌سازی 2FA (نیاز به کد فعلی):", Font = new Font("Segoe UI", 10F), ForeColor = Color.FromArgb(200, 30, 60), Location = new Point(20, 360), AutoSize = true };
            var txtDisableCode = new TextBox { Location = new Point(20, 388), Size = new Size(200, 35), Font = new Font("Consolas", 16F), MaxLength = 6, BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnDisable = new Button { Text = "❌ غیرفعال‌سازی", Location = new Point(240, 388), Size = new Size(150, 38), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)) };
            btnDisable.Click += (s, e) =>
            {
                if (!alreadyEnabled && !_2fa.Is2FAEnabled(_operatorId))
                { MessageBox.Show("احراز هویت دو مرحله‌ای فعال نیست.", "اطلاع", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

                string code = txtDisableCode.Text.Trim();
                if (string.IsNullOrEmpty(code) || code.Length != 6)
                { MessageBox.Show("برای غیرفعال‌سازی، کد ۶ رقمی فعلی اپلیکیشن Authenticator را وارد کنید.", "کد لازم", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                // Validate against the CURRENTLY PERSISTED secret (not the new
                // _secret being shown above). Reject on any failure - no fallback
                // to password, no Yes/No shortcut.
                if (!_2fa.ValidateOperator2FA(_operatorId, code))
                {
                    MessageBox.Show("کد وارد شده نامعتبر است. غیرفعال‌سازی انجام نشد.", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    AuditLog.Log("2FA", $"2FA disable rejected for operator {_operatorId}: invalid TOTP code");
                    txtDisableCode.Clear();
                    return;
                }

                _2fa.Disable2FAForOperator(_operatorId);
                MessageBox.Show("احراز هویت دو مرحله‌ای غیرفعال شد.");
                AuditLog.Log("2FA", $"2FA disabled for operator {_operatorId} (verified with current TOTP)");
                this.DialogResult = DialogResult.OK;
                this.Close();
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblStep1, lblApps, lblStep2, txtSecret, btnCopy, lblStep3, txtCode, btnVerify, lblDisable, txtDisableCode, btnDisable });
        }
    }
}
