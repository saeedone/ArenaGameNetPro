using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Round 11: small always-on-top card for what a customer asks from the kiosk:
    /// extra time, ending the session, shutdown, or a message to the operator.
    /// One card per station: a new request from the same station updates its card
    /// instead of opening another one. The card does not take the keyboard focus,
    /// so it never interrupts what the operator is typing.
    /// </summary>
    internal sealed class CustomerRequestPrompt : Form
    {
        private static readonly Dictionary<string, CustomerRequestPrompt> _open =
            new Dictionary<string, CustomerRequestPrompt>(StringComparer.OrdinalIgnoreCase);

        private readonly ClientCommunicator _comm;
        private readonly string _station;
        private string _user, _kind;
        private int _minutes;
        private readonly Label _lblTitle, _lblBody;
        private readonly Button _btnYes, _btnNo;
        private readonly List<string> _messages = new List<string>();

        /// <summary>Shows (or updates) the card for a request. UI thread only.</summary>
        public static void ShowRequest(Form owner, ClientCommunicator comm, string station, string user, string kind, int minutes)
        {
            var p = GetOrCreate(owner, comm, station);
            p.SetRequest(user, kind, minutes);
        }

        /// <summary>Shows (or updates) the card for a customer's message. UI thread only.</summary>
        public static void ShowMessage(Form owner, ClientCommunicator comm, string station, string user, string text)
        {
            var p = GetOrCreate(owner, comm, station);
            p.AddMessage(user, text);
        }

        private static CustomerRequestPrompt GetOrCreate(Form owner, ClientCommunicator comm, string station)
        {
            station = station ?? "";
            CustomerRequestPrompt p;
            if (_open.TryGetValue(station, out p) && !p.IsDisposed) return p;
            p = new CustomerRequestPrompt(comm, station);
            _open[station] = p;
            p.FormClosed += (s, e) => { CustomerRequestPrompt cur; if (_open.TryGetValue(station, out cur) && cur == p) _open.Remove(station); };
            p.PlaceOnScreen();
            p.Show();
            return p;
        }

        private CustomerRequestPrompt(ClientCommunicator comm, string station)
        {
            _comm = comm;
            _station = station;
            Text = "درخواست مشتری — " + station;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            ClientSize = new Size(360, 170);
            BackColor = Color.FromArgb(250, 250, 252);
            RightToLeft = RightToLeft.Yes;
            RightToLeftLayout = true;
            Font = new Font("Segoe UI", 10F);

            var strip = new Panel { Dock = DockStyle.Top, Height = 6, BackColor = Color.FromArgb(255, 152, 0) };
            _lblTitle = new Label { Location = new Point(12, 14), Size = new Size(336, 26), Font = new Font("Segoe UI", 12F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 30, 46) };
            _lblBody = new Label { Location = new Point(12, 44), Size = new Size(336, 70), ForeColor = Color.FromArgb(50, 50, 60) };
            _btnYes = new Button { Location = new Point(12, 122), Size = new Size(165, 36), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(46, 160, 67), ForeColor = Color.White, Font = new Font("Segoe UI", 10F, FontStyle.Bold) };
            _btnNo = new Button { Location = new Point(183, 122), Size = new Size(165, 36), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(225, 225, 230), ForeColor = Color.FromArgb(40, 40, 40) };
            _btnYes.FlatAppearance.BorderSize = 0; _btnNo.FlatAppearance.BorderSize = 0;
            _btnYes.Click += (s, e) => OnYes();
            _btnNo.Click += (s, e) => OnNo();
            Controls.AddRange(new Control[] { strip, _lblTitle, _lblBody, _btnYes, _btnNo });
        }

        // Do not steal focus from the operator's current window. Topmost is set through
        // the window style: setting the TopMost property would activate the card.
        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x00000008; // WS_EX_TOPMOST
                return cp;
            }
        }

        private void PlaceOnScreen()
        {
            var wa = Screen.PrimaryScreen.WorkingArea;
            int n = 0;
            foreach (var kv in _open) if (kv.Value != this && !kv.Value.IsDisposed) n++;
            int y = wa.Bottom - Height - 12 - (n % 4) * (Height + 8);
            Location = new Point(wa.Right - Width - 12 - (n / 4) * (Width + 8), Math.Max(wa.Top, y));
        }

        private void SetRequest(string user, string kind, int minutes)
        {
            _user = user; _kind = kind; _minutes = minutes; _messages.Clear();
            string who = _station + (string.IsNullOrEmpty(user) ? "" : " · " + user);
            switch (kind)
            {
                case "time":
                    _lblTitle.Text = "⏱️ درخواست زمان اضافه";
                    _lblBody.Text = who + "\nمی‌خواهد " + minutes + " دقیقه به زمانش اضافه شود.";
                    _btnYes.Text = "✅ اضافه کن +" + minutes;
                    _btnNo.Text = "❌ رد";
                    break;
                case "end":
                    _lblTitle.Text = "⏹️ درخواست پایان نشست";
                    _lblBody.Text = who + "\nمی‌خواهد نشستش تمام شود.";
                    _btnYes.Text = "✅ پایان نشست";
                    _btnNo.Text = "❌ رد";
                    break;
                case "shutdown":
                    _lblTitle.Text = "⏻ درخواست خاموش کردن";
                    _lblBody.Text = who + "\nمی‌خواهد سیستم خاموش شود.";
                    _btnYes.Text = "✅ خاموش کن";
                    _btnNo.Text = "❌ رد";
                    break;
                default: // lock and anything else: information only
                    _lblTitle.Text = "🔔 درخواست مشتری";
                    _lblBody.Text = who + "\nدرخواست: " + kind;
                    _btnYes.Text = "✔ دیدم";
                    _btnNo.Text = "بستن";
                    break;
            }
            Flash();
        }

        private void AddMessage(string user, string text)
        {
            if (_kind != "message") { _messages.Clear(); }
            _user = user; _kind = "message";
            _messages.Add(text);
            while (_messages.Count > 3) _messages.RemoveAt(0);
            _lblTitle.Text = "💬 پیام مشتری — " + _station + (string.IsNullOrEmpty(user) ? "" : " · " + user);
            _lblBody.Text = string.Join("\n", _messages);
            _btnYes.Text = "↩️ پاسخ";
            _btnNo.Text = "✔ دیدم";
            Flash();
        }

        private void Flash()
        {
            try { if (!Visible) Show(); BringToFront(); } catch { }
        }

        private void Tell(string body, string level)
        {
            try
            {
                _comm.SendToStation(_station, new NetMessage(MessageType.ServerMessage,
                    new ServerMessagePayload { Title = "پیام اپراتور", Body = body, Level = level }));
            }
            catch (Exception ex) { AuditLog.Log("Request", "Reply to " + _station + " failed: " + ex.Message); }
        }

        private void OnYes()
        {
            try
            {
                switch (_kind)
                {
                    case "time":
                        _comm.SetSessionTime(_station, 1, _minutes, "+" + _minutes + " (درخواست مشتری، تأیید اپراتور)");
                        AuditLog.Log("Request", $"Approved +{_minutes} min for {_station}");
                        break;
                    case "end":
                        _comm.SetSessionTime(_station, 3, 0, "پایان (درخواست مشتری)");
                        break;
                    case "shutdown":
                        _comm.ShutdownStation(_station);
                        break;
                    case "message":
                        string reply = Microsoft.VisualBasic.Interaction.InputBox("پاسخ به " + _station + ":", "پاسخ به مشتری", "");
                        if (string.IsNullOrWhiteSpace(reply)) return; // keep the card open
                        Tell(reply.Trim(), "info");
                        try { ActivityJournal.Record(ActivityJournal.Request, "پاسخ اپراتور: " + reply.Trim(), _station); } catch { } // round 14
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Close();
        }

        private void OnNo()
        {
            if (_kind == "time" || _kind == "end" || _kind == "shutdown")
            {
                Tell("درخواست شما در حال حاضر پذیرفته نشد. برای توضیح به پیشخوان مراجعه کنید.", "warning");
                try { ActivityJournal.Record(ActivityJournal.Request, "رد درخواست مشتری (" + _kind + (_kind == "time" ? " " + _minutes + " دقیقه" : "") + ")", _station); } catch { } // round 14
                AuditLog.Log("Request", $"Rejected {_kind} for {_station}");
            }
            Close();
        }
    }
}
