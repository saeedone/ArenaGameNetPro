using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameNet.Server.Core;
using Newtonsoft.Json;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// HandyCafe-style Windows restrictions editor. Lets the operator
    /// toggle a comprehensive set of client-side Windows policy restrictions
    /// (general, Internet Explorer, Control Panel, drive visibility/access)
    /// that the server pushes to connected kiosks. Persists to
    /// restrictions.json next to the server exe so the same restriction
    /// set is re-applied on every server restart.
    ///
    /// Tabs:
    ///   1. General        — 15 checkboxes (Start Menu, Desktop, Network, etc.)
    ///   2. Internet Explorer — 10 checkboxes (Options dialog tab hiding, etc.)
    ///   3. Control Panel  — 20 checkboxes (Add/Remove Programs, wallpaper, etc.)
    ///   4. Disk Restrictions — two parallel groups (Hide / Prevent Access) for
    ///                          drives A: through Z: (26 drives each — FIX 4).
    /// </summary>
    public class RestrictionsForm : Form
    {
        /// <summary>
        /// Optional communicator reference. When set, the form relays the
        /// saved restriction set to every connected kiosk on Save(). When
        /// null, Save() just persists to restrictions.json without relaying.
        /// </summary>
        private readonly ClientCommunicator _comm;

        // === Theme palette (matches the rest of GameNet) ===
        private static readonly Color _bg        = Color.FromArgb(240, 240, 240);
        private static readonly Color _panel     = Color.FromArgb(230, 230, 235);
        private static readonly Color _input     = Color.FromArgb(220, 220, 225);
        private static readonly Color _fg        = Color.FromArgb(40, 40, 40);
        private static readonly Color _accent    = Color.FromArgb(137, 180, 250);
        private static readonly Color _muted     = Color.FromArgb(148, 226, 213);
        private static readonly Color _ok        = Color.FromArgb(166, 227, 161);
        private static readonly Color _warn      = Color.FromArgb(249, 226, 175);
        private static readonly Color _danger    = Color.FromArgb(243, 139, 168);
        private static readonly Font  _f         = new Font("Segoe UI", 9F);
        private static readonly Font  _fb        = new Font("Segoe UI", 9F, FontStyle.Bold);
        private static readonly Font  _fh        = new Font("Segoe UI", 11F, FontStyle.Bold);

        private readonly string _savePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "restrictions.json");

        // === Persisted state ===
        private RestrictionsData _data;

        // === General tab checkboxes ===
        private readonly List<CheckBox> _generalChks = new List<CheckBox>();

        // === IE tab checkboxes ===
        private readonly List<CheckBox> _ieChks = new List<CheckBox>();

        // === Control Panel tab checkboxes ===
        private readonly List<CheckBox> _cpChks = new List<CheckBox>();

        // === Disk tab — left group (hide) + right group (prevent access) ===
        private readonly List<CheckBox> _hideChks = new List<CheckBox>();
        private readonly List<CheckBox> _denyChks = new List<CheckBox>();

        // Drives A: through Z: (26 drives total — FIX 4 expanded from
        // the original A:-S: range so the operator can also hide / deny
        // access to the removable / network drive letters T:, U:, V:, W:,
        // X:, Y:, Z:).
        private static readonly string[] _drives =
        {
            "A:", "B:", "C:", "D:", "E:", "F:", "G:", "H:", "I:", "J:",
            "K:", "L:", "M:", "N:", "O:", "P:", "Q:", "R:", "S:", "T:",
            "U:", "V:", "W:", "X:", "Y:", "Z:"
        };

        // === General tab item keys + labels (15 + 27 spec items = 42 items).
        //  Keys match RestrictionsData bool property names.
        private static readonly string[] _generalItems =
        {
            // --- Existing 15 ( HandyCafe — General Windows policies) ---
            "RemoveAccessControlPage",
            "DisableFilePrinterSharing",
            "HideFilePrinterSharingPage",
            "DisableNetworkControlPanelIcon",
            "DisableAddNewPrinter",
            "HidePrinterDetails",
            "PreventPrinterDeletion",
            "PreventStartMenuChanges",
            "DisableActiveDesktop",
            "RemoveSecurityHardwareTabs",
            "DisableRightClick",
            "CustomizeToolbars",
            "HideOptionNetworkSearchFolderMenu",
            "HideSearchButton",
            "RemovePropertiesMyComputer",
            // --- New 27 spec items (HandyCafe — Explorer/IE toolbars) ---
            "RemoveToolbarChangeAbility",
            "RemoveInternetDesktopIcon",
            "RemoveWindowsUpdateFromStartMenu",
            "HideRunCommand",
            "HideBackButton",
            "HideForwardButton",
            "HideStopButton",
            "HideRefreshButton",
            "HideHomeButton",
            "HideSearchButtonIE",
            "HideHistoryButton",
            "HideFavoritesButton",
            "HideFoldersButton",
            "HideFullscreenButton",
            "HideToolsButton",
            "HideMailNewsButton",
            "HideFontSizeButton",
            "HidePrintButton",
            "HidePrintPreview",
            "HideEditButton",
            "HideDiscussionsButton",
            "HideCutButton",
            "HideCopyButton",
            "HidePasteButton",
            "HideEncodingButton",
            "HideMediaBar",
            "ShowSmallIconsOnToolbar"
        };
        private static readonly string[] _generalLabels =
        {
            // --- Existing 15 ---
            "حذف دسترسی به صفحه Access Control",
            "غیرفعال‌سازی اشتراک فایل و پرینتر",
            "مخفی‌سازی صفحه اشتراک فایل و پرینتر",
            "غیرفعال‌سازی آیکون Network Control Panel",
            "غیرفعال‌سازی افزودن پرینتر جدید",
            "مخفی‌کردن جزئیات پرینتر",
            "جلوگیری از حذف پرینتر",
            "جلوگیری از تغییر تنظیمات Start Menu",
            "غیرفعال‌سازی Active Desktop",
            "حذف تب Security/Hardware از System properties",
            "غیرفعال‌سازی Right-Click",
            "سفارشی‌سازی Toolbars",
            "مخفی‌کردن منوی Option/Network/Search/Folder",
            "مخفی‌کردن دکمه Search",
            "حذف Properties از My Computer/Desktop",
            // --- New 27 spec items ---
            "حذف توانایی تغییر toolbars در Explorer/IE",
            "حذف آیکون Internet از دسکتاپ",
            "حذف Windows Update از Start Menu",
            "مخفی‌کردن دستور Run",
            "مخفی‌کردن دکمه Back",
            "مخفی‌کردن دکمه Forward",
            "مخفی‌کردن دکمه Stop",
            "مخفی‌کردن دکمه Refresh",
            "مخفی‌کردن دکمه Home",
            "مخفی‌کردن دکمه Search",
            "مخفی‌کردن دکمه History",
            "مخفی‌کردن دکمه Favorites",
            "مخفی‌کردن دکمه Folders",
            "مخفی‌کردن دکمه Fullscreen",
            "مخفی‌کردن دکمه Tools",
            "مخفی‌کردن دکمه Mail/News",
            "مخفی‌کردن دکمه Font Size",
            "مخفی‌کردن دکمه Print",
            "مخفی‌کردن Print Preview",
            "مخفی‌کردن دکمه Edit",
            "مخفی‌کردن دکمه Discussions",
            "مخفی‌کردن دکمه Cut",
            "مخفی‌کردن دکمه Copy",
            "مخفی‌کردن دکمه Paste",
            "مخفی‌کردن دکمه Encoding",
            "مخفی‌کردن Media Bar",
            "نمایش آیکون‌های کوچک روی toolbar"
        };

        // === IE tab (10 existing + 40 new spec items = 50 items) ===
        private static readonly string[] _ieItems =
        {
            // --- Existing 10 ---
            "DisableInternetOptions",
            "HideGeneralTab",
            "HideSecurityTab",
            "HidePrivacyTab",
            "HideContentTab",
            "HideConnectionsTab",
            "HideProgramsTab",
            "HideAdvancedTab",
            "DisableHomepageChange",
            "DisableHistoryDeletion",
            // --- New 40 spec items ---
            "RemoveStandardButtonsAddressLinksBar",
            "DisableRightClickIE",
            "DisableSaveAs",
            "DisableFavorites",
            "DisableFileNewCtrlN",
            "DisableFileOpenCtrlO",
            "DisableFindFiles",
            "DisableDownloadDirSelection",
            "DisableF11",
            "GreyForwardBack",
            "RemovePrintPreviewPrintFromFile",
            "DisableBrowserBarsChange",
            "GreyOpenFileDownload",
            "DisableNewBrowserWindow",
            "HideAddressBar",
            "HideStandardButtons",
            "DisableRightClickDownload",
            "DisableAdvancedTabChanges",
            "DisableAutoConfiguration",
            "DisableProfileAssistant",
            "DisableAllAccessibility",
            "DisableLinkColorChange",
            "DisableLanguageChange",
            "DisableCertificatesPublishers",
            "DisableMicrosoftWallet",
            "DisableColorsChange",
            "DisableFontsChange",
            "DisableContentAdvisor",
            "DisableTempInternetFilesChange",
            "DisableInternetConnectionWizard",
            "PreventEmailNewsCallChange",
            "PreventCertificateOptionsChange",
            "PreventAddSitesToZone",
            "DisableAutocompleteForms",
            "PreventPasswordSave",
            "DisableResetWebSettings",
            "DisableProxyServerChange",
            "DisableSaveAsWebPageComplete"
        };
        private static readonly string[] _ieLabels =
        {
            // --- Existing 10 ---
            "غیرفعال‌سازی Internet Options",
            "مخفی‌کردن تب General",
            "مخفی‌کردن تب Security",
            "مخفی‌کردن تب Privacy",
            "مخفی‌کردن تب Content",
            "مخفی‌کردن تب Connections",
            "مخفی‌کردن تب Programs",
            "مخفی‌کردن تب Advanced",
            "غیرفعال‌سازی تغییر homepage",
            "غیرفعال‌سازی حذف history",
            // --- New 40 spec items ---
            "حذف Standard Buttons، Address Bar و Links Bar",
            "غیرفعال‌سازی راست‌کلیک",
            "غیرفعال‌سازی Save As",
            "غیرفعال‌سازی Favorites",
            "غیرفعال‌سازی File/New و CTRL+N",
            "غیرفعال‌سازی File/Open و CTRL+O و CTRL+L",
            "غیرفعال‌سازی Find Files",
            "غیرفعال‌سازی انتخاب دایرکتوری دانلود",
            "غیرفعال‌سازی کلید F11",
            "خاکستری کردن دکمه‌های Forward و Back",
            "حذف PrintPreview و Print از منوی File",
            "غیرفعال‌سازی تغییر browser bars",
            "خاکستری کردن دکمه Open در File Download",
            "غیرفعال‌سازی پنجره جدید Browser",
            "مخفی‌کردن Address bar",
            "مخفی‌کردن Standard buttons",
            "غیرفعال‌سازی دانلود با راست‌کلیک",
            "غیرفعال‌سازی تغییرات تب Advanced",
            "غیرفعال‌سازی Auto Configuration",
            "غیرفعال‌سازی Profile Assistant",
            "غیرفعال‌سازی همه گزینه‌های Accessibility",
            "غیرفعال‌سازی تغییر رنگ لینک‌ها",
            "غیرفعال‌سازی تغییر زبان",
            "غیرفعال‌سازی Certificates/Publishers",
            "غیرفعال‌سازی Microsoft Wallet",
            "غیرفعال‌سازی تغییر Colors",
            "غیرفعال‌سازی تغییر فونت‌ها",
            "غیرفعال‌سازی Content Advisor",
            "غیرفعال‌سازی تغییر فضای Temporary Internet Files",
            "غیرفعال‌سازی Internet Connection Wizard",
            "جلوگیری از تغییر E-Mail/Newsgroups/Internet Call",
            "جلوگیری از تغییر Certificate options",
            "جلوگیری از افزودن Sites به هر zone",
            "غیرفعال‌سازی AutoComplete برای فرم‌ها",
            "جلوگیری از ذخیره رمز عبور",
            "غیرفعال‌سازی Reset web Settings",
            "غیرفعال‌سازی تغییر proxy server",
            "غیرفعال‌سازی Save As Web Page Complete"
        };

        // === Control Panel tab (20 existing + 20 new spec items = 40 items) ===
        private static readonly string[] _cpItems =
        {
            // --- Existing 20 ---
            "RemoveFavoritesFromStartMenu",
            "RemoveRecentDocuments",
            "DisableAddRemovePrograms",
            "DisableChangeRemovePrograms",
            "HideSetProgramAccessAndDefaults",
            "HideWindowsComponentsWizard",
            "HideAddProgramFromCdRom",
            "HideAddProgramFromMicrosoft",
            "HideAddProgramFromNetwork",
            "DisableWallpaperChange",
            "DisableComponents",
            "DisableAddComponent",
            "DisableRemoveComponent",
            "DisableEditComponent",
            "RestrictControlPanelApplets",
            "RemoveMyComputerFromStartMenu",
            "HideControlPanelPrinterNetwork",
            "DisableTaskbarContextMenus",
            "DisableShutDown",
            "HideRecycleBin",
            // --- New 20 spec items ---
            "DisableWindowsButtonsStyleChange",
            "DisableColorSchemeChange",
            "DisableFontSizeChange",
            "HideThemesTab",
            "HideDisplayKeyboardNavigator",
            "PreventAnimationSelection",
            "HideDisplaySettings",
            "HideScreenSaverPage",
            "HideDisplayAppearancePage",
            "PreventChangePasswords",
            "DisablePasswordsIcon",
            "DisableUserProfilePage",
            "PreventAdministrationSettingsChange",
            "HideVirtualMemoryPage",
            "HideHardwareProfilesPage",
            "DisableDeviceManager",
            "DisableDisplaySettingsIcon",
            "DisableTaskManager",
            "DisableNetworkIdPage",
            "DisableClearFilePrinterSharing"
        };
        private static readonly string[] _cpLabels =
        {
            // --- Existing 20 ---
            "حذف Favorites از Start Menu",
            "حذف Recent Documents",
            "غیرفعال‌سازی Add/Remove Programs",
            "غیرفعال‌سازی Change/Remove Programs",
            "مخفی‌کردن Set Program Access and Defaults",
            "مخفی‌کردن Windows Components Wizard",
            "مخفی‌کردن افزودن برنامه از CD-ROM",
            "مخفی‌کردن افزودن برنامه از Microsoft",
            "مخفی‌کردن افزودن برنامه از شبکه",
            "غیرفعال‌سازی تغییر wallpaper",
            "غیرفعال‌سازی کامپوننت‌ها",
            "غیرفعال‌سازی افزودن کامپوننت",
            "غیرفعال‌سازی حذف کامپوننت",
            "غیرفعال‌سازی ویرایش کامپوننت",
            "محدودسازی applet‌های Control Panel",
            "حذف My Computer از Start Menu",
            "مخفی‌کردن Control Panel/Printer/Network",
            "غیرفعال‌سازی Taskbar Context Menus",
            "غیرفعال‌سازی Shut Down",
            "مخفی‌کردن Recycle Bin",
            // --- New 20 spec items ---
            "غیرفعال‌سازی تغییر Windows and buttons style",
            "غیرفعال‌سازی تغییر Color scheme",
            "غیرفعال‌سازی تغییر Font size",
            "مخفی‌کردن تب Themes",
            "مخفی‌کردن نمایشگر keyboard navigator",
            "جلوگیری از انتخاب animation",
            "مخفی‌کردن تنظیمات display",
            "مخفی‌کردن صفحه screen saver",
            "مخفی‌کردن صفحه display appearance",
            "جلوگیری از دسترسی به Change Passwords",
            "غیرفعال‌سازی آیکون Passwords",
            "غیرفعال‌سازی User profile page",
            "جلوگیری از تغییر تنظیمات administration",
            "مخفی‌کردن Virtual Memory page",
            "مخفی‌کردن Hardware Profiles page",
            "غیرفعال‌سازی Device Manager",
            "غیرفعال‌سازی آیکون display settings",
            "غیرفعال‌سازی Task Manager",
            "غیرفعال‌سازی Network ID page",
            "غیرفعال‌سازی Clear file and printer sharing"
        };

        public RestrictionsForm() : this(null) { }

        public RestrictionsForm(ClientCommunicator comm)
        {
            _comm = comm;
            this.Text = "🚫 محدودیت‌ها - تنظیمات ویندوز کلاینت";
            this.Size = new Size(820, 660);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = _bg;
            this.ForeColor = _fg;
            this.RightToLeft = RightToLeft.Yes;
            this.MinimumSize = new Size(760, 600);

            _data = LoadData();

            BuildUi();
        }

        // ----------------------------------------------------------------
        //  UI construction
        // ----------------------------------------------------------------
        private void BuildUi()
        {
            // === Header ===
            var lblHeader = new Label
            {
                Text = "🚫 محدودیت‌های ویندوز کلاینت",
                Font = _fh,
                ForeColor = _accent,
                Dock = DockStyle.Top,
                Height = 36,
                TextAlign = ContentAlignment.MiddleCenter,
            };

            // === TabControl ===
            var tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = _f,
                Appearance = TabAppearance.Normal,
                Padding = new Point(14, 8),
                Margin = new Padding(0),
            };
            StyleTabControl(tabs);

            tabs.TabPages.Add(BuildGeneralTab());
            tabs.TabPages.Add(BuildIeTab());
            tabs.TabPages.Add(BuildCpTab());
            tabs.TabPages.Add(BuildDiskTab());

            // === Bottom button bar ===
            var btnBar = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = _panel,
                Padding = new Padding(10, 8, 10, 8),
            };

            var btnClear = new Button
            {
                Text = "🧹 پاک کردن",
                Size = new Size(120, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _warn,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
            };
            btnClear.FlatAppearance.BorderSize = 0;
            btnClear.Click += (s, e) =>
            {
                if (MessageBox.Show("همه محدودیت‌ها پاک شوند؟", "تایید",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                foreach (var c in _generalChks) c.Checked = false;
                foreach (var c in _ieChks) c.Checked = false;
                foreach (var c in _cpChks) c.Checked = false;
                foreach (var c in _hideChks) c.Checked = false;
                foreach (var c in _denyChks) c.Checked = false;
                Log("Cleared all restrictions checkboxes");
            };

            var btnCancel = new Button
            {
                Text = "انصراف",
                Size = new Size(110, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _danger,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
                DialogResult = DialogResult.Cancel,
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            var btnOk = new Button
            {
                Text = "✓ تایید",
                Size = new Size(110, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = _ok,
                ForeColor = _bg,
                Font = _fb,
                Cursor = Cursors.Hand,
                DialogResult = DialogResult.OK,
            };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => Save();

            // Lay buttons out (RTL: arrange from right to left using Anchor).
            btnClear.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnCancel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnOk.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            // Position relative to the right edge.
            btnOk.Location   = new Point(btnBar.Width - 10 - 110, 8);
            btnCancel.Location = new Point(btnOk.Left - 10 - 110, 8);
            btnClear.Location = new Point(btnCancel.Left - 10 - 120, 8);
            // Force layout so Anchor positions settle correctly.
            btnBar.Controls.AddRange(new Control[] { btnClear, btnCancel, btnOk });
            btnBar.Layout += (s, e) =>
            {
                btnOk.Location = new Point(btnBar.Width - 10 - 110, 8);
                btnCancel.Location = new Point(btnOk.Left - 10 - 110, 8);
                btnClear.Location = new Point(btnCancel.Left - 10 - 120, 8);
            };

            // Wire AcceptButton / CancelButton to the form.
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;

            this.Controls.Clear();
            this.Controls.Add(tabs);
            this.Controls.Add(btnBar);
            this.Controls.Add(lblHeader);
            // Order matters: Top label first, then Fill tabs, then bottom bar.
            lblHeader.SendToBack();
        }

        private void StyleTabControl(TabControl tc)
        {
            tc.DrawMode = TabDrawMode.OwnerDrawFixed;
            tc.DrawItem += (s, e) =>
            {
                var g = e.Graphics;
                var tab = tc.TabPages[e.Index];
                bool sel = e.Index == tc.SelectedIndex;
                var bg = sel ? _input : _panel;
                var fg = sel ? _accent : _fg;
                using (var b = new SolidBrush(bg))
                    g.FillRectangle(b, e.Bounds);
                // Top accent strip on selected tab.
                if (sel)
                    using (var p = new Pen(_accent, 3))
                        g.DrawLine(p, e.Bounds.Left, e.Bounds.Top, e.Bounds.Right, e.Bounds.Top);
                var sf = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center,
                    FormatFlags = StringFormatFlags.DirectionRightToLeft
                };
                using (var br = new SolidBrush(fg))
                    g.DrawString(tab.Text, sel ? _fb : _f, br, e.Bounds, sf);
            };
        }

        // ----------------------------------------------------------------
        //  Tab 1: General
        // ----------------------------------------------------------------
        private TabPage BuildGeneralTab()
        {
            var page = NewTab("📋 عمومی", _bg);
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12), AutoScroll = true };

            int y = 12;
            foreach (var c in BuildCheckboxGroup(_generalItems, _generalLabels, _generalChks, ref y))
                host.Controls.Add(c);

            host.Controls.Add(MkLabel("ℹ️ این محدودیت‌ها روی تنظیمات عمومی ویندوز اعمال می‌شوند.",
                12, y + 8, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 2: Internet Explorer
        // ----------------------------------------------------------------
        private TabPage BuildIeTab()
        {
            var page = NewTab("🌐 Internet Explorer", _bg);
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12), AutoScroll = true };

            int y = 12;
            foreach (var c in BuildCheckboxGroup(_ieItems, _ieLabels, _ieChks, ref y))
                host.Controls.Add(c);

            host.Controls.Add(MkLabel("ℹ️ این محدودیت‌ها روی Internet Explorer اعمال می‌شوند.",
                12, y + 8, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 3: Control Panel
        // ----------------------------------------------------------------
        private TabPage BuildCpTab()
        {
            var page = NewTab("⚙️ Control Panel", _bg);
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12), AutoScroll = true };

            int y = 12;
            foreach (var c in BuildCheckboxGroup(_cpItems, _cpLabels, _cpChks, ref y))
                host.Controls.Add(c);

            host.Controls.Add(MkLabel("ℹ️ این محدودیت‌ها روی Control Panel و Add/Remove Programs اعمال می‌شوند.",
                12, y + 8, _muted, _f));

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Tab 4: Disk Restrictions — two groups for drives A: through Z:
        // ----------------------------------------------------------------
        private TabPage BuildDiskTab()
        {
            var page = NewTab("💾 Disk Restrictions", _bg);

            // Outer scroll host (in case the user resizes the window small).
            //
            // FIX (FIX-FINAL-10 B10): the disk tab's content (two 360×480 group
            // boxes side-by-side + a 540-tall info label) totals ~580px tall and
            // ~760px wide, but the form's MinimumSize is 760×600 and the actual
            // tab page client area at the minimum size is only ~478px tall (600
            // minus the title bar, tab strip, top label, and bottom button bar).
            // Without AutoScroll the bottom row of drive checkboxes (rows 6–7 of
            // the 4×7 grid, i.e. drives U–Z) and the "ℹ️ محدودسازی درایوها..."
            // info label were clipped off-screen with no way to reach them —
            // operators on small windows couldn't toggle hide/deny on the last
            // 6–8 drives. The General / IE / Control Panel tabs already had
            // AutoScroll=true on their host panels (lines 547, 566, 585); the
            // disk tab was missed. Setting it here matches the others and lets
            // the tab page show a vertical scrollbar when content exceeds the
            // visible area.
            var host = new Panel { Dock = DockStyle.Fill, BackColor = _bg, Padding = new Padding(12), AutoScroll = true };

            // Left group — "مخفی‌کردن درایو" (Hide drive)
            var leftBox = MkGroupBox("مخفی‌کردن درایو (Hide Drive)", 12, 12, 360, 480);
            // Right group — "جلوگیری از دسترسی به درایو" (Prevent access)
            var rightBox = MkGroupBox("جلوگیری از دسترسی به درایو (Prevent Access)", 390, 12, 360, 480);

            // 26 drives (A:-Z:) laid out in 4 cols × 7 rows inside each
            // group box (FIX 4 expanded from the original 19 drives / 5 rows
            // × 4 cols layout). The last column only has 5 drives (V/W/X/Y/Z).
            int ix = 16, iy = 32;
            for (int i = 0; i < _drives.Length; i++)
            {
                var drive = _drives[i];
                var cb = new CheckBox
                {
                    Text = drive,
                    Font = _fb,
                    ForeColor = _fg,
                    BackColor = _panel,
                    AutoSize = false,
                    Size = new Size(72, 28),
                    Location = new Point(ix, iy),
                    Checked = _data.HideDrive.Contains(drive),
                };
                cb.CheckedChanged += (s, e) => ToggleDrive(_data.HideDrive, drive, cb.Checked);
                leftBox.Controls.Add(cb);
                _hideChks.Add(cb);

                var cb2 = new CheckBox
                {
                    Text = drive,
                    Font = _fb,
                    ForeColor = _fg,
                    BackColor = _panel,
                    AutoSize = false,
                    Size = new Size(72, 28),
                    Location = new Point(ix, iy),
                    Checked = _data.DenyDrive.Contains(drive),
                };
                cb2.CheckedChanged += (s, e) => ToggleDrive(_data.DenyDrive, drive, cb2.Checked);
                rightBox.Controls.Add(cb2);
                _denyChks.Add(cb2);

                iy += 32;
                if ((i + 1) % 7 == 0) // new column every 7 rows (4 cols × 7 rows)
                {
                    iy = 32;
                    ix += 78;
                }
            }

            // Per-group select-all / clear buttons.
            var btnHideAll = MkSmallBtn("انتخاب همه", _accent, 12, 500);
            btnHideAll.Click += (s, e) => { foreach (var c in _hideChks) c.Checked = true; };
            var btnHideNone = MkSmallBtn("هیچ‌کدام", _danger, 100, 500);
            btnHideNone.Click += (s, e) => { foreach (var c in _hideChks) c.Checked = false; };

            var btnDenyAll = MkSmallBtn("انتخاب همه", _accent, 390, 500);
            btnDenyAll.Click += (s, e) => { foreach (var c in _denyChks) c.Checked = true; };
            var btnDenyNone = MkSmallBtn("هیچ‌کدام", _danger, 478, 500);
            btnDenyNone.Click += (s, e) => { foreach (var c in _denyChks) c.Checked = false; };

            host.Controls.AddRange(new Control[]
            {
                leftBox, rightBox, btnHideAll, btnHideNone, btnDenyAll, btnDenyNone,
                MkLabel("ℹ️ محدودسازی درایوها بر اساس Group Policy هنگام لاگ‌این کاربر اعمال می‌شود.",
                    12, 540, _muted, _f)
            });

            page.Controls.Add(host);
            return page;
        }

        // ----------------------------------------------------------------
        //  Helpers — checkboxes, labels, group boxes, small buttons
        // ----------------------------------------------------------------
        private List<CheckBox> BuildCheckboxGroup(string[] keys, string[] labels,
            List<CheckBox> sink, ref int y)
        {
            var list = new List<CheckBox>();
            for (int i = 0; i < keys.Length; i++)
            {
                var cb = new CheckBox
                {
                    Text = labels[i],
                    Name = "chk_" + keys[i],
                    Tag = keys[i],
                    AutoSize = false,
                    Size = new Size(720, 26),
                    Location = new Point(12, y),
                    Font = _f,
                    ForeColor = _fg,
                    BackColor = _panel,
                    Checked = GetBool(_data, keys[i]),
                    CheckAlign = ContentAlignment.MiddleLeft,
                    TextAlign = ContentAlignment.MiddleLeft,
                };
                cb.CheckedChanged += (s, e) => SetBool(_data, keys[i], cb.Checked);
                sink.Add(cb);
                list.Add(cb);
                y += 30;
            }
            return list;
        }

        private static TabPage NewTab(string title, Color back)
        {
            var p = new TabPage(title)
            {
                BackColor = back,
                ForeColor = _fg,
                Font = _f,
                Padding = new Padding(0),
                UseVisualStyleBackColor = false,
            };
            return p;
        }

        private static Label MkLabel(string text, int x, int y, Color color, Font font)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = color,
                Font = font,
                BackColor = Color.Transparent,
            };
        }

        private static GroupBox MkGroupBox(string title, int x, int y, int w, int h)
        {
            var gb = new GroupBox
            {
                Text = title,
                Location = new Point(x, y),
                Size = new Size(w, h),
                Font = _fb,
                ForeColor = _accent,
                BackColor = _panel,
            };
            return gb;
        }

        private static Button MkSmallBtn(string text, Color accent, int x, int y)
        {
            var b = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(80, 28),
                FlatStyle = FlatStyle.Flat,
                BackColor = accent,
                ForeColor = _bg,
                Font = _f,
                Cursor = Cursors.Hand,
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        // ----------------------------------------------------------------
        //  Drive toggle (kept both as JSON list + cross-deduplication)
        // ----------------------------------------------------------------
        private static void ToggleDrive(List<string> list, string drive, bool on)
        {
            if (on)
            {
                if (!list.Contains(drive)) list.Add(drive);
            }
            else
            {
                list.RemoveAll(d => d == drive);
            }
        }

        // ----------------------------------------------------------------
        //  Reflection helpers — read/write bool properties by name.
        // ----------------------------------------------------------------
        private static bool GetBool(RestrictionsData d, string name)
        {
            try
            {
                var prop = typeof(RestrictionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    return (bool)prop.GetValue(d);
            }
            catch { }
            return false;
        }

        private static void SetBool(RestrictionsData d, string name, bool value)
        {
            try
            {
                var prop = typeof(RestrictionsData).GetProperty(name);
                if (prop != null && prop.PropertyType == typeof(bool))
                    prop.SetValue(d, value);
            }
            catch { }
        }

        // ----------------------------------------------------------------
        //  Persistence — restrictions.json next to the server exe.
        // ----------------------------------------------------------------
        private RestrictionsData LoadData()
        {
            try
            {
                if (File.Exists(_savePath))
                {
                    var json = File.ReadAllText(_savePath);
                    var data = JsonConvert.DeserializeObject<RestrictionsData>(json);
                    if (data != null)
                    {
                        if (data.HideDrive == null) data.HideDrive = new List<string>();
                        if (data.DenyDrive == null) data.DenyDrive = new List<string>();
                        return data;
                    }
                }
            }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine("LoadData: " + ex.Message); }
            return new RestrictionsData();
        }

        private void Save()
        {
            try
            {
                File.WriteAllText(_savePath, JsonConvert.SerializeObject(_data, Formatting.Indented));
                try { AuditLog.Log("Restrictions", "Saved restrictions.json"); } catch { }
                try { PushRestrictionsToClients(); } catch { }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ذخیره محدودیت‌ها: " + ex.Message, "خطا",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Broadcasts the current restriction set to every connected client
        /// so the kiosk re-applies the registry policies immediately. The
        /// full RestrictionsData is serialized to JSON and sent as the Body
        /// of a ServerMessage titled "apply-restrictions" — the kiosk's
        /// HandleServerMessage recognises this title and calls
        /// ApplyClientRestrictions(json) to flip the HKCU policy registry
        /// keys (FIX 10).
        /// </summary>
        private void PushRestrictionsToClients()
        {
            if (_comm == null) return;
            try
            {
                // Serialize the full restriction set so the kiosk can apply
                // every policy (not just a "settings updated" notice).
                string json = JsonConvert.SerializeObject(_data, Formatting.None);
                int n = 0;
                foreach (var c in _comm.GetAllRawConnections())
                {
                    try
                    {
                        _comm.SendToStation(c.StationName,
                            new GameNet.Shared.NetMessage(GameNet.Shared.MessageType.ServerMessage,
                                new GameNet.Shared.ServerMessagePayload
                                {
                                    Title = "apply-restrictions",
                                    Body = json,
                                    Level = "info"
                                }));
                        n++;
                    }
                    catch { }
                }
                if (n > 0)
                    MessageBox.Show($"✅ محدودیت‌ها ذخیره شد و به {n} کلاینت متصل ارسال شد.",
                        "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch { /* ignore relay errors — the file was already saved */ }
        }

        private void Log(string msg) { try { AuditLog.Log("Restrictions", msg); } catch { } }

        // ----------------------------------------------------------------
        //  Persisted model
        // ----------------------------------------------------------------
        /// <summary>
        /// Persisted model — serialized to restrictions.json. Each boolean
        /// toggles one Windows policy. The HideDrive / DenyDrive lists store
        /// the drive letters ("A:".."S:") the operator wants hidden /
        /// access-restricted.
        /// </summary>
        public class RestrictionsData
        {
            // --- General tab (15 existing + 27 new spec fields = 42 bool fields) ---
            public bool RemoveAccessControlPage         { get; set; }
            public bool DisableFilePrinterSharing       { get; set; }
            public bool HideFilePrinterSharingPage      { get; set; }
            public bool DisableNetworkControlPanelIcon  { get; set; }
            public bool DisableAddNewPrinter            { get; set; }
            public bool HidePrinterDetails              { get; set; }
            public bool PreventPrinterDeletion          { get; set; }
            public bool PreventStartMenuChanges         { get; set; }
            public bool DisableActiveDesktop            { get; set; }
            public bool RemoveSecurityHardwareTabs      { get; set; }
            public bool DisableRightClick               { get; set; }
            public bool CustomizeToolbars               { get; set; }
            public bool HideOptionNetworkSearchFolderMenu { get; set; }
            public bool HideSearchButton                { get; set; }
            public bool RemovePropertiesMyComputer      { get; set; }
            // --- General tab — new 27 spec items (Explorer/IE toolbars) ---
            public bool RemoveToolbarChangeAbility      { get; set; }
            public bool RemoveInternetDesktopIcon       { get; set; }
            public bool RemoveWindowsUpdateFromStartMenu { get; set; }
            public bool HideRunCommand                  { get; set; }
            public bool HideBackButton                  { get; set; }
            public bool HideForwardButton               { get; set; }
            public bool HideStopButton                  { get; set; }
            public bool HideRefreshButton               { get; set; }
            public bool HideHomeButton                  { get; set; }
            public bool HideSearchButtonIE              { get; set; }
            public bool HideHistoryButton               { get; set; }
            public bool HideFavoritesButton             { get; set; }
            public bool HideFoldersButton               { get; set; }
            public bool HideFullscreenButton            { get; set; }
            public bool HideToolsButton                 { get; set; }
            public bool HideMailNewsButton              { get; set; }
            public bool HideFontSizeButton              { get; set; }
            public bool HidePrintButton                 { get; set; }
            public bool HidePrintPreview                { get; set; }
            public bool HideEditButton                  { get; set; }
            public bool HideDiscussionsButton           { get; set; }
            public bool HideCutButton                   { get; set; }
            public bool HideCopyButton                  { get; set; }
            public bool HidePasteButton                 { get; set; }
            public bool HideEncodingButton              { get; set; }
            public bool HideMediaBar                    { get; set; }
            public bool ShowSmallIconsOnToolbar         { get; set; }

            // --- Internet Explorer tab (10 existing + 40 new spec fields = 50) ---
            public bool DisableInternetOptions          { get; set; }
            public bool HideGeneralTab                  { get; set; }
            public bool HideSecurityTab                 { get; set; }
            public bool HidePrivacyTab                  { get; set; }
            public bool HideContentTab                  { get; set; }
            public bool HideConnectionsTab              { get; set; }
            public bool HideProgramsTab                 { get; set; }
            public bool HideAdvancedTab                 { get; set; }
            public bool DisableHomepageChange           { get; set; }
            public bool DisableHistoryDeletion          { get; set; }
            // --- IE tab — new 40 spec items ---
            public bool RemoveStandardButtonsAddressLinksBar { get; set; }
            public bool DisableRightClickIE             { get; set; }
            public bool DisableSaveAs                   { get; set; }
            public bool DisableFavorites                { get; set; }
            public bool DisableFileNewCtrlN             { get; set; }
            public bool DisableFileOpenCtrlO            { get; set; }
            public bool DisableFindFiles                { get; set; }
            public bool DisableDownloadDirSelection     { get; set; }
            public bool DisableF11                      { get; set; }
            public bool GreyForwardBack                 { get; set; }
            public bool RemovePrintPreviewPrintFromFile { get; set; }
            public bool DisableBrowserBarsChange        { get; set; }
            public bool GreyOpenFileDownload            { get; set; }
            public bool DisableNewBrowserWindow         { get; set; }
            public bool HideAddressBar                  { get; set; }
            public bool HideStandardButtons             { get; set; }
            public bool DisableRightClickDownload       { get; set; }
            public bool DisableAdvancedTabChanges       { get; set; }
            public bool DisableAutoConfiguration        { get; set; }
            public bool DisableProfileAssistant         { get; set; }
            public bool DisableAllAccessibility         { get; set; }
            public bool DisableLinkColorChange          { get; set; }
            public bool DisableLanguageChange           { get; set; }
            public bool DisableCertificatesPublishers   { get; set; }
            public bool DisableMicrosoftWallet          { get; set; }
            public bool DisableColorsChange             { get; set; }
            public bool DisableFontsChange              { get; set; }
            public bool DisableContentAdvisor           { get; set; }
            public bool DisableTempInternetFilesChange  { get; set; }
            public bool DisableInternetConnectionWizard { get; set; }
            public bool PreventEmailNewsCallChange      { get; set; }
            public bool PreventCertificateOptionsChange { get; set; }
            public bool PreventAddSitesToZone           { get; set; }
            public bool DisableAutocompleteForms        { get; set; }
            public bool PreventPasswordSave             { get; set; }
            public bool DisableResetWebSettings         { get; set; }
            public bool DisableProxyServerChange        { get; set; }
            public bool DisableSaveAsWebPageComplete    { get; set; }

            // --- Control Panel tab (20 existing + 20 new spec fields = 40) ---
            public bool RemoveFavoritesFromStartMenu    { get; set; }
            public bool RemoveRecentDocuments           { get; set; }
            public bool DisableAddRemovePrograms        { get; set; }
            public bool DisableChangeRemovePrograms     { get; set; }
            public bool HideSetProgramAccessAndDefaults { get; set; }
            public bool HideWindowsComponentsWizard     { get; set; }
            public bool HideAddProgramFromCdRom         { get; set; }
            public bool HideAddProgramFromMicrosoft     { get; set; }
            public bool HideAddProgramFromNetwork       { get; set; }
            public bool DisableWallpaperChange          { get; set; }
            public bool DisableComponents               { get; set; }
            public bool DisableAddComponent             { get; set; }
            public bool DisableRemoveComponent          { get; set; }
            public bool DisableEditComponent            { get; set; }
            public bool RestrictControlPanelApplets     { get; set; }
            public bool RemoveMyComputerFromStartMenu   { get; set; }
            public bool HideControlPanelPrinterNetwork  { get; set; }
            public bool DisableTaskbarContextMenus      { get; set; }
            public bool DisableShutDown                 { get; set; }
            public bool HideRecycleBin                  { get; set; }
            // --- Control Panel tab — new 20 spec items ---
            public bool DisableWindowsButtonsStyleChange { get; set; }
            public bool DisableColorSchemeChange        { get; set; }
            public bool DisableFontSizeChange           { get; set; }
            public bool HideThemesTab                   { get; set; }
            public bool HideDisplayKeyboardNavigator    { get; set; }
            public bool PreventAnimationSelection       { get; set; }
            public bool HideDisplaySettings             { get; set; }
            public bool HideScreenSaverPage             { get; set; }
            public bool HideDisplayAppearancePage       { get; set; }
            public bool PreventChangePasswords          { get; set; }
            public bool DisablePasswordsIcon            { get; set; }
            public bool DisableUserProfilePage          { get; set; }
            public bool PreventAdministrationSettingsChange { get; set; }
            public bool HideVirtualMemoryPage           { get; set; }
            public bool HideHardwareProfilesPage        { get; set; }
            public bool DisableDeviceManager            { get; set; }
            public bool DisableDisplaySettingsIcon      { get; set; }
            public bool DisableTaskManager              { get; set; }
            public bool DisableNetworkIdPage            { get; set; }
            public bool DisableClearFilePrinterSharing  { get; set; }

            // --- Additional HandyCafe policy flags consumed by the client's
            //     ApplyClientRestrictions handler (FIX AUDIT-FIX-FINAL Bug D).
            //     These mirror the HKCU\Software\Microsoft\Windows\
            //     CurrentVersion\Policies registry value names so the
            //     kiosk can flip the corresponding policy on/off. They
            //     live in their own group so the General/CP tab item
            //     arrays don't need to be reshuffled. ---
            public bool DisableRegistryTools            { get; set; }
            public bool DisableControlPanel             { get; set; }

            // --- Disk Restrictions tab — two drive lists ---
            public List<string> HideDrive { get; set; } = new List<string>();
            public List<string> DenyDrive { get; set; } = new List<string>();
        }
    }
}
