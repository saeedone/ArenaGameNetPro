using GameNet.Server.Core;
using System; using System.Drawing; using System.Windows.Forms;
namespace GameNet.Server.Forms {
    public class StaffManagementForm : Form {
        private DataGridView dgv;
        public StaffManagementForm() {
            this.Text = "👤 مدیریت پرسنل - markazbazi"; this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor; this.ForeColor = Color.FromArgb(40, 40, 40);
            this.Font = new Font("Segoe UI", 9F);
            dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect, RowHeadersVisible = false, BorderStyle = BorderStyle.None };
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(40, 40, 40);
            dgv.DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 255);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 230, 235);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(30, 80, 180);
            var pnl = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.FromArgb(230, 230, 235) };
            var btnAdd = new Button { Text = "➕ افزودن", Location = new Point(10, 10), Size = new Size(90, 30), BackColor = Color.FromArgb(0, 240, 255), ForeColor = Color.Black, FlatStyle = FlatStyle.Flat };
            var btnDelete = new Button { Text = "🗑️ حذف", Location = new Point(110, 10), Size = new Size(80, 30), BackColor = Color.FromArgb(255, 59, 92), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var btnRefresh = new Button { Text = "🔄 بارگذاری", Location = new Point(200, 10), Size = new Size(90, 30), BackColor = Color.FromArgb(137, 180, 250), ForeColor = Color.Black, FlatStyle = FlatStyle.Flat };
            btnAdd.Click += (s, e) => { try { new StaffManager().AddStaff("پرسنل جدید", "", StaffRole.Operator); } catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); } LoadData(); };
            btnDelete.Click += (s, e) => { if (dgv.SelectedRows.Count == 0) { MessageBox.Show("ابتدا یک ردیف را انتخاب کنید.", "توجه"); return; } try { new StaffManager().DeleteStaff((int)dgv.SelectedRows[0].Cells[0].Value); } catch (Exception ex) { MessageBox.Show("خطا: " + ex.Message); } LoadData(); };
            btnRefresh.Click += (s, e) => LoadData();
            pnl.Controls.AddRange(new Control[] { btnAdd, btnDelete, btnRefresh });
            this.Controls.Add(dgv); this.Controls.Add(pnl); LoadData();
        }
        private void LoadData() { try { dgv.Rows.Clear(); dgv.Columns.Clear(); dgv.Columns.Add("Id","ID"); dgv.Columns.Add("Name","نام"); dgv.Columns.Add("Phone","تلفن"); dgv.Columns.Add("Role","نقش"); dgv.Columns.Add("CheckedIn","حضور"); foreach (var s in new StaffManager().GetAllStaff()) dgv.Rows.Add(s.Id, s.Name, s.Phone, s.Role, s.CheckedIn ? "✅" : "❌"); } catch (Exception ex) { try { dgv.Rows.Clear(); dgv.Columns.Clear(); dgv.Columns.Add("Error", "خطا"); dgv.Rows.Add("⚠️ خطا در بارگذاری اطلاعات: " + ex.Message); } catch { } } }
    }
}
