using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Member management form. Combines the original user CRUD with the
    /// HandyCafe-style pricing/payment options: pricing mode (standard /
    /// member price / charge free / custom), payment type (prepaid / play
    /// and pay), used/remaining time, debt, discount %, and member price.
    /// Navigation buttons (Prior / Next) cycle through the loaded users.
    /// </summary>
    public class UserManagementForm : Form
    {
        private UserManager _mgr = new UserManager();
        private DataGridView dgv;
        private TextBox txtSearch, txtUsername, txtDisplay, txtPhone, txtBalance;
        private Button btnAdd, btnEdit, btnAddCredit, btnTransfer, btnDelete;
        private Label _lblCount;

        // === New pricing / payment / navigation fields ===
        private RadioButton _rbPriceStandard, _rbPriceMember, _rbPriceFree, _rbPriceCustom;
        private RadioButton _rbPayPrepaid, _rbPayPlayAndPay;
        private TextBox _txtUsedTime, _txtRemainingTime, _txtDebt, _txtDiscount, _txtMemberPrice;
        private Button _btnNew, _btnApply, _btnCancel, _btnPrior, _btnNext;

        public UserManagementForm()
        {
            this.Text = "مدیریت کاربران - GameNet";
            this.Size = new Size(1100, 720);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            // ---------------- Left panel - User list ----------------
            var pnlLeft = new Panel { Dock = DockStyle.Fill };
            dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("colId", "شناسه"); dgv.Columns["colId"].Visible = false;
            dgv.Columns.Add("colUser", "نام کاربری"); dgv.Columns.Add("colDisp", "نام نمایشی");
            dgv.Columns.Add("colBal", "اعتبار (تومان)"); dgv.Columns.Add("colActive", "فعال");
            dgv.Columns.Add("colPhone", "تلفن"); dgv.Columns.Add("colDate", "تاریخ عضویت");
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(220, 220, 225);
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(40, 40, 40);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 230, 235);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(30, 80, 180);

            txtSearch = new TextBox { Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 11F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            SetPlaceholder(txtSearch, "جستجو...");
            txtSearch.TextChanged += (s, e) => LoadUsers();
            _lblCount = new Label { Dock = DockStyle.Bottom, Height = 25, ForeColor = Color.FromArgb(166, 173, 200), Font = new Font("Segoe UI", 9F) };

            pnlLeft.Controls.AddRange(new Control[] { dgv, txtSearch, _lblCount });

            // ---------------- Right panel - Actions + pricing ----------------
            var pnlRight = new Panel { Dock = DockStyle.Right, Width = 360, BackColor = Color.FromArgb(255, 255, 255), Padding = new Padding(10), AutoScroll = true };

            int y = 12;

            // Identity group
            AddSection(pnlRight, "👤 اطلاعات کاربر", ref y);
            AddLabel(pnlRight, "نام کاربری:", 10, ref y); y += 4;
            txtUsername = AddTextBox(pnlRight, 10, ref y, 330);

            AddLabel(pnlRight, "نام نمایشی:", 10, ref y); y += 4;
            txtDisplay = AddTextBox(pnlRight, 10, ref y, 330);

            AddLabel(pnlRight, "شماره تلفن:", 10, ref y); y += 4;
            txtPhone = AddTextBox(pnlRight, 10, ref y, 330);

            AddLabel(pnlRight, "اعتبار اولیه (تومان):", 10, ref y); y += 4;
            txtBalance = AddTextBox(pnlRight, 10, ref y, 330, "0");
            y += 10;

            // Pricing group (HandyCafe-style radio buttons)
            AddSection(pnlRight, "💰 نوع قیمت‌گذاری", ref y);
            _rbPriceStandard = new RadioButton { Text = "استاندارد", Location = new Point(10, y), Size = new Size(150, 22), ForeColor = Color.FromArgb(40, 40, 40), Checked = true };
            _rbPriceMember   = new RadioButton { Text = "قیمت عضو", Location = new Point(180, y), Size = new Size(150, 22), ForeColor = Color.FromArgb(40, 40, 40) };
            y += 24;
            _rbPriceFree     = new RadioButton { Text = "رایگان (Charge Free)", Location = new Point(10, y), Size = new Size(160, 22), ForeColor = Color.FromArgb(40, 40, 40) };
            _rbPriceCustom   = new RadioButton { Text = "سفارشی", Location = new Point(180, y), Size = new Size(150, 22), ForeColor = Color.FromArgb(40, 40, 40) };
            y += 28;

            // Payment type group
            AddSection(pnlRight, "💳 نوع پرداخت", ref y);
            _rbPayPrepaid     = new RadioButton { Text = "پیش‌پرداخت (Prepaid)", Location = new Point(10, y), Size = new Size(160, 22), ForeColor = Color.FromArgb(40, 40, 40), Checked = true };
            _rbPayPlayAndPay  = new RadioButton { Text = "Play and Pay", Location = new Point(180, y), Size = new Size(150, 22), ForeColor = Color.FromArgb(40, 40, 40) };
            y += 30;

            // Time / debt fields
            AddSection(pnlRight, "⏱️ زمان و بدهی", ref y);
            AddLabel(pnlRight, "زمان استفاده:", 10, ref y); y += 4;
            _txtUsedTime = AddTextBox(pnlRight, 10, ref y, 330, "00:00:00");

            AddLabel(pnlRight, "زمان باقی‌مانده:", 10, ref y); y += 4;
            _txtRemainingTime = AddTextBox(pnlRight, 10, ref y, 330, "00:00:00");

            AddLabel(pnlRight, "بدهی (تومان):", 10, ref y); y += 4;
            _txtDebt = AddTextBox(pnlRight, 10, ref y, 330, "0");

            AddLabel(pnlRight, "تخفیف (٪):", 10, ref y); y += 4;
            _txtDiscount = AddTextBox(pnlRight, 10, ref y, 330, "0");

            AddLabel(pnlRight, "قیمت عضو (تومان/ساعت):", 10, ref y); y += 4;
            _txtMemberPrice = AddTextBox(pnlRight, 10, ref y, 330, "0");
            y += 12;

            // Action buttons (existing)
            btnAdd       = CreateBtn("ایجاد کاربر",        Color.FromArgb(137, 180, 250), y); btnAdd.Click += DoAdd;       y += 36;
            btnAddCredit = CreateBtn("افزایش اعتبار",      Color.FromArgb(166, 227, 161), y); btnAddCredit.Click += DoAddCredit; y += 36;
            btnTransfer  = CreateBtn("انتقال اعتبار",      Color.FromArgb(249, 226, 175), y); btnTransfer.Click += DoTransfer;  y += 36;
            btnEdit      = CreateBtn("ویرایش",             Color.FromArgb(148, 226, 213), y); btnEdit.Click += DoEdit;      y += 36;
            btnDelete    = CreateBtn("حذف کاربر",          Color.FromArgb(243, 139, 168), y); btnDelete.Click += DoDelete;  y += 40;

            // HandyCafe-style bottom action buttons
            AddSection(pnlRight, "🧭 عملیات رکورد", ref y);
            _btnNew    = CreateBtn("جدید (New)",    Color.FromArgb(166, 227, 161), y); _btnNew.Click += DoNew;       y += 32;
            _btnApply  = CreateBtn("اعمال (Apply)", Color.FromArgb(137, 180, 250), y); _btnApply.Click += DoApply;   y += 32;
            _btnCancel = CreateBtn("لغو (Cancel)",  Color.FromArgb(249, 226, 175), y); _btnCancel.Click += DoCancel; y += 32;
            var pnlNav = new Panel { Location = new Point(10, y), Size = new Size(330, 36), BackColor = Color.Transparent };
            _btnPrior = new Button { Text = "⏮ قبلی", Location = new Point(0, 0), Size = new Size(160, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(203, 166, 247)) };
            _btnNext  = new Button { Text = "بعدی ⏭", Location = new Point(170, 0), Size = new Size(160, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(203, 166, 247)) };
            _btnPrior.Click += DoPrior;
            _btnNext.Click  += DoNext;
            pnlNav.Controls.AddRange(new Control[] { _btnPrior, _btnNext });
            pnlRight.Controls.Add(pnlNav);

            pnlRight.Controls.AddRange(new Control[] {
                btnAdd, btnAddCredit, btnTransfer, btnEdit, btnDelete,
                _btnNew, _btnApply, _btnCancel,
                _rbPriceStandard, _rbPriceMember, _rbPriceFree, _rbPriceCustom,
                _rbPayPrepaid, _rbPayPlayAndPay,
                _txtUsedTime, _txtRemainingTime, _txtDebt, _txtDiscount, _txtMemberPrice
            });

            Controls.AddRange(new Control[] { pnlLeft, pnlRight });

            dgv.SelectionChanged += (s, e) => LoadSelectedIntoFields();
            LoadUsers();
        }

        private void AddSection(Panel parent, string text, ref int y)
        {
            var lbl = new Label
            {
                Text = text,
                Location = new Point(8, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
            };
            parent.Controls.Add(lbl);
            y += 22;
        }

        private void AddLabel(Panel parent, string text, int x, ref int y)
        {
            var lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(40, 40, 40),
            };
            parent.Controls.Add(lbl);
            y += 20;
        }

        private TextBox AddTextBox(Panel parent, int x, ref int y, int width, string initial = "")
        {
            var tb = new TextBox
            {
                Location = new Point(x, y),
                Size = new Size(width, 27),
                BackColor = Color.FromArgb(245, 245, 248),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                Text = initial ?? "",
            };
            parent.Controls.Add(tb);
            y += 32;
            return tb;
        }

        private Button CreateBtn(string text, Color bg, int y)
        {
            return new Button
            {
                Text = text,
                Location = new Point(10, y),
                Size = new Size(330, 30),
                BackColor = bg,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(240, 240, 240),
                Cursor = Cursors.Hand,
            };
        }

        private void LoadUsers()
        {
            dgv.Rows.Clear();
            var users = _mgr.GetAllUsers();
            string q = (txtSearch.Text ?? "").Trim();
            if (q == "جستجو...") q = "";
            foreach (var u in users)
            {
                if (!string.IsNullOrEmpty(q) &&
                    !(u.Username ?? "").ToLowerInvariant().Contains(q.ToLowerInvariant()) &&
                    !(u.DisplayName ?? "").ToLowerInvariant().Contains(q.ToLowerInvariant()) &&
                    !(u.Phone ?? "").ToLowerInvariant().Contains(q.ToLowerInvariant()))
                    continue;
                dgv.Rows.Add(u.Id, u.Username, u.DisplayName, u.Balance.ToString("N0"), u.IsActive ? "بله" : "خیر", u.Phone, u.CreatedAt.ToLocalTime().ToString("yyyy/MM/dd"));
            }
            _lblCount.Text = $"مجموع: {users.Count} کاربر";
        }

        private void LoadSelectedIntoFields()
        {
            if (dgv.SelectedRows.Count == 0) return;
            var row = dgv.SelectedRows[0];
            txtUsername.Text = row.Cells[1].Value?.ToString() ?? "";
            txtDisplay.Text  = row.Cells[2].Value?.ToString() ?? "";
            txtBalance.Text  = (row.Cells[3].Value?.ToString() ?? "0").Replace(",", "");
            txtPhone.Text    = row.Cells[5].Value?.ToString() ?? "";

            // Pull real debt + used time + remaining time + member price +
            // discount from the DB so the form reflects actual state.
            try
            {
                string username = txtUsername.Text;
                var user = _mgr.FindByUsername(username);
                if (user != null)
                {
                    // Debt
                    decimal debt = 0;
                    try
                    {
                        debt = Database.Instance.QueryOne(
                            "SELECT COALESCE(SUM(amount), 0) FROM debts WHERE username = @u AND is_paid = 0",
                            cmd => cmd.Parameters.AddWithValue("@u", username),
                            r => r.GetDecimal(0));
                    }
                    catch { }
                    _txtDebt.Text = debt.ToString("N0");

                    // Used + remaining time from active session
                    int usedMin = 0, remainingMin = 0;
                    try
                    {
                        var session = Database.Instance.QueryOne(
                            "SELECT start_time, end_time, duration_minutes FROM client_sessions WHERE username = @u AND state = 1 ORDER BY id DESC LIMIT 1",
                            cmd => cmd.Parameters.AddWithValue("@u", username),
                            r => new { Start = r.GetDateTime(0), End = r.IsDBNull(1) ? (DateTime?)null : r.GetDateTime(1), Dur = r.GetInt32(2) });
                        if (session != null)
                        {
                            usedMin = (int)(DateTime.UtcNow - session.Start).TotalMinutes;
                            if (session.Dur > 0)
                                remainingMin = Math.Max(0, session.Dur - usedMin);
                        }
                    }
                    catch { }
                    _txtUsedTime.Text     = $"{usedMin / 60:00}:{usedMin % 60:00}:00";
                    _txtRemainingTime.Text = remainingMin > 0 ? $"{remainingMin / 60:00}:{remainingMin % 60:00}:00" : "نامحدود";

                    // Discount + member price from tier if present
                    decimal discount = 0, memberPrice = 0;
                    try
                    {
                        var tier = Database.Instance.QueryOne(
                            "SELECT mt.discount_percent, mt.required_points FROM member_tiers mt " +
                            "JOIN user_tier_progress utp ON utp.tier_id = mt.id WHERE utp.username = @u",
                            cmd => cmd.Parameters.AddWithValue("@u", username),
                            r => new { Discount = r.GetDecimal(0), Points = r.GetInt32(1) });
                        if (tier != null) discount = tier.Discount;
                    }
                    catch { }
                    try
                    {
                        memberPrice = Database.Instance.QueryOne(
                            "SELECT COALESCE(price_per_hour, 0) FROM pricing WHERE is_default = 1 LIMIT 1",
                            null, r => r.GetDecimal(0));
                    }
                    catch { }
                    _txtDiscount.Text = discount.ToString("0");
                    _txtMemberPrice.Text = memberPrice.ToString("N0");
                }
            }
            catch { }
        }

        private void DoAdd(object s, EventArgs e)
        {
            try
            {
                _mgr.CreateUser(txtUsername.Text.Trim(), "1234", txtDisplay.Text.Trim(), decimal.Parse(txtBalance.Text), txtPhone.Text.Trim());
                LoadUsers();
                MessageBox.Show("کاربر ایجاد شد. رمز عبور پیش‌فرض: 1234", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DoAddCredit(object s, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            string amount = Microsoft.VisualBasic.Interaction.InputBox("مبلغ (تومان):", "افزایش اعتبار", "50000");
            if (!string.IsNullOrEmpty(amount))
                try { _mgr.AddCredit(dgv.SelectedRows[0].Cells[1].Value?.ToString(), decimal.Parse(amount)); LoadUsers(); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DoTransfer(object s, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            string from = dgv.SelectedRows[0].Cells[1].Value?.ToString();
            string to = Microsoft.VisualBasic.Interaction.InputBox("نام کاربری مقصد:", "انتقال اعتبار");
            if (string.IsNullOrEmpty(to)) return;
            string amount = Microsoft.VisualBasic.Interaction.InputBox("مبلغ (تومان):", "انتقال اعتبار", "10000");
            if (!string.IsNullOrEmpty(amount))
                try { _mgr.TransferCredit(from, to, decimal.Parse(amount)); LoadUsers(); MessageBox.Show("اعتبار منتقل شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DoEdit(object s, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            int id = Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value);
            try
            {
                bool isActive = (dgv.SelectedRows[0].Cells[4].Value?.ToString() == "بله");
                _mgr.UpdateUser(id, txtDisplay.Text.Trim(), txtPhone.Text.Trim(), isActive);
                LoadUsers();
                MessageBox.Show("ویرایش شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DoNew(object s, EventArgs e)
        {
            txtUsername.Clear();
            txtDisplay.Clear();
            txtPhone.Clear();
            txtBalance.Text = "0";
            _txtUsedTime.Text = "00:00:00";
            _txtRemainingTime.Text = "00:00:00";
            _txtDebt.Text = "0";
            _txtDiscount.Text = "0";
            _txtMemberPrice.Text = "0";
            _rbPriceStandard.Checked = true;
            _rbPayPrepaid.Checked = true;
            if (dgv.Rows.Count > 0) dgv.ClearSelection();
            txtUsername.Focus();
        }

        private void DoApply(object s, EventArgs e)
        {
            // Apply both edits to the user record AND persist the pricing-mode
            // + payment-type + discount as settings on the user (stored in
            // the settings table keyed by user_pricing_<username>).
            if (dgv.SelectedRows.Count == 0)
            {
                DoAdd(s, e);
                return;
            }
            try
            {
                int id = Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value);
                string username = dgv.SelectedRows[0].Cells[1].Value?.ToString() ?? "";
                bool isActive = (dgv.SelectedRows[0].Cells[4].Value?.ToString() == "بله");
                _mgr.UpdateUser(id, txtDisplay.Text.Trim(), txtPhone.Text.Trim(), isActive);

                // Persist HandyCafe-style pricing metadata into the settings
                // table so other modules can read it. Stored as JSON-ish key/value.
                string pricingMode = _rbPriceStandard.Checked ? "standard" :
                                     _rbPriceMember.Checked   ? "member"   :
                                     _rbPriceFree.Checked     ? "free"     : "custom";
                string payType = _rbPayPrepaid.Checked ? "prepaid" : "playandpay";

                Database.Instance.Execute(
                    "INSERT OR REPLACE INTO settings (key, value) VALUES (@k, @v)",
                    cmd =>
                    {
                        cmd.Parameters.AddWithValue("@k", "user_pricing_" + username);
                        cmd.Parameters.AddWithValue("@v",
                            $"mode={pricingMode};pay={payType};discount={_txtDiscount.Text};member_price={_txtMemberPrice.Text}");
                    });

                AuditLog.Log("UserManagement", $"Applied pricing for {username}: mode={pricingMode}, pay={payType}");
                LoadUsers();
                MessageBox.Show("تغییرات اعمال شد", "اعمال", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void DoCancel(object s, EventArgs e)
        {
            DoNew(s, e);
        }

        private void DoPrior(object s, EventArgs e)
        {
            if (dgv.Rows.Count == 0) return;
            int idx = dgv.SelectedRows.Count > 0 ? dgv.SelectedRows[0].Index : 0;
            idx = (idx - 1 + dgv.Rows.Count) % dgv.Rows.Count;
            dgv.ClearSelection();
            dgv.Rows[idx].Selected = true;
        }

        private void DoNext(object s, EventArgs e)
        {
            if (dgv.Rows.Count == 0) return;
            int idx = dgv.SelectedRows.Count > 0 ? dgv.SelectedRows[0].Index : -1;
            idx = (idx + 1) % dgv.Rows.Count;
            dgv.ClearSelection();
            dgv.Rows[idx].Selected = true;
        }

        private void SetPlaceholder(TextBox ctrl, string text)
        {
            ctrl.Text = text;
            ctrl.ForeColor = Color.FromArgb(128, 128, 128);
            ctrl.GotFocus += (s, e) => { if (ctrl.Text == text) { ctrl.Text = ""; ctrl.ForeColor = Color.FromArgb(40, 40, 40); } };
            ctrl.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(ctrl.Text)) { ctrl.Text = text; ctrl.ForeColor = Color.FromArgb(128, 128, 128); } };
        }

        private void DoDelete(object s, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            if (MessageBox.Show("حذف این کاربر؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                try { _mgr.DeleteUser(Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value)); LoadUsers(); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
