using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Round 11: live monitoring with the operator's mouse and keyboard.
    ///
    /// Picture: the kiosk's ffmpeg sends H.264 (up to 30 fps, Full HD) on its own TCP
    /// connection; ffmpeg on the server decodes it to JPEG frames on its standard
    /// output; this window shows them. The frames never use the control connection,
    /// so they do not run into the server's 30-messages-per-minute limit.
    /// Control: when "کنترل" is on, mouse moves (about 60 per second at most), clicks,
    /// the wheel and every key are sent with ServerRemoteInput. Keys that are held
    /// down are released when control is turned off, the window loses focus or closes.
    /// Fallback: without FFmpeg (on the server or the kiosk) the window shows a
    /// screenshot every 3 seconds — slow, but it stays inside the rate limit — and
    /// says how to get the smooth picture.
    /// </summary>
    internal sealed class LiveControlForm : Form
    {
        private sealed class Quality
        {
            public string Name; public int Fps, Kbps, Scale;
            public override string ToString() { return Name; }
        }

        private static readonly Quality[] Qualities =
        {
            new Quality { Name = "فوق‌العاده — ۶۰ فریم، کیفیت کامل", Fps = 60, Kbps = 16000, Scale = 100 }, // round 13
            new Quality { Name = "عالی — ۳۰ فریم، کیفیت کامل", Fps = 30, Kbps = 8000, Scale = 100 },
            new Quality { Name = "خوب — ۲۵ فریم", Fps = 25, Kbps = 4000, Scale = 100 },
            new Quality { Name = "سبک — ۱۵ فریم (شبکه یا سیستم ضعیف)", Fps = 15, Kbps = 1500, Scale = 75 },
        };

        private readonly string _station;
        private readonly ClientCommunicator _comm;
        private readonly FramePanel _view;
        private readonly Label _lblStatus;
        private readonly Button _btnControl, _btnFull;
        private readonly ComboBox _cboQuality;
        private readonly System.Windows.Forms.Timer _timer;

        private Process _decoder;
        private volatile bool _closing;
        private volatile int _generation;              // bumps on every (re)start
        private readonly StringBuilder _decoderErr = new StringBuilder();
        private string _lastError;

        private Bitmap _frame;
        private readonly object _frameLock = new object();
        // Round 13: the reader hands the newest JPEG to one decoder thread; frames that
        // arrive while it is busy are skipped, so the picture never falls behind (at 60 fps
        // a slow PC shows fewer frames instead of a growing delay).
        private byte[] _pendingJpeg;
        private int _pendingGen;
        private readonly AutoResetEvent _jpegReady = new AutoResetEvent(false);
        private Thread _decodeThread;
        private int _paintQueued;
        private int _frameCount;
        private DateTime _fpsSince = DateTime.UtcNow;
        private double _fps;
        private DateTime _startedAt, _lastFrameAt = DateTime.MinValue;

        private bool _control;
        private bool _fallback;
        private bool _shotPending;
        private DateTime _lastShotAt = DateTime.MinValue;
        private Point? _pendingMove;
        private readonly HashSet<int> _keysDown = new HashSet<int>();
        private readonly HashSet<string> _buttonsDown = new HashSet<string>();
        private FormWindowState _prevState;
        private FormBorderStyle _prevBorder;

        public LiveControlForm(string stationName, ClientCommunicator comm)
        {
            _station = stationName;
            _comm = comm;
            Text = "🖥️ مانیتورینگ زنده و کنترل: " + stationName;
            Size = new Size(1280, 800);
            MinimumSize = new Size(640, 420);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(24, 24, 32);
            KeyPreview = true;
            RightToLeft = RightToLeft.Yes;

            var bar = new Panel { Dock = DockStyle.Top, Height = 46, BackColor = Color.FromArgb(36, 36, 48), RightToLeft = RightToLeft.Yes };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new Padding(6, 6, 6, 0), BackColor = Color.Transparent };
            _btnControl = MkButton("🖱️⌨️ کنترل: خاموش", 170, Color.FromArgb(70, 70, 90));
            _btnControl.Click += (s, e) => SetControl(!_control);
            _cboQuality = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 230, Font = new Font("Segoe UI", 9.5F), Margin = new Padding(4, 4, 4, 0) };
            _cboQuality.Items.AddRange(Qualities);
            _cboQuality.SelectedIndex = 0;
            _cboQuality.SelectionChangeCommitted += (s, e) => Restart();
            var btnReconnect = MkButton("🔄 اتصال دوباره", 120, Color.FromArgb(70, 70, 90));
            btnReconnect.Click += (s, e) => Restart();
            _btnFull = MkButton("⛶ تمام‌صفحه", 110, Color.FromArgb(70, 70, 90));
            _btnFull.Click += (s, e) => ToggleFullScreen();
            var btnWin = MkButton("⊞ Win", 70, Color.FromArgb(70, 70, 90));
            btnWin.Click += (s, e) => { if (!_control) { Hint(); return; } TapKey(Keys.LWin); FocusView(); };
            var btnAltTab = MkButton("Alt+Tab", 80, Color.FromArgb(70, 70, 90));
            btnAltTab.Click += (s, e) => { if (!_control) { Hint(); return; } SendKey((int)Keys.Menu, true); TapKey(Keys.Tab); SendKey((int)Keys.Menu, false); FocusView(); };
            var btnSnap = MkButton("📷 ذخیره عکس", 110, Color.FromArgb(70, 70, 90));
            btnSnap.Click += (s, e) => SaveSnapshot();
            _lblStatus = new Label { AutoSize = true, ForeColor = Color.FromArgb(200, 200, 215), Font = new Font("Segoe UI", 9.5F), Margin = new Padding(10, 10, 4, 0), Text = "⏳ در حال اتصال..." };
            flow.Controls.AddRange(new Control[] { _btnControl, _cboQuality, btnReconnect, _btnFull, btnWin, btnAltTab, btnSnap, _lblStatus });
            bar.Controls.Add(flow);

            _view = new FramePanel(this) { Dock = DockStyle.Fill, BackColor = Color.Black, RightToLeft = RightToLeft.No };
            _view.MouseMove += (s, e) => { if (_control) _pendingMove = e.Location; };
            _view.MouseDown += OnViewMouseDown;
            _view.MouseUp += OnViewMouseUp;
            _view.MouseWheel += OnViewWheel;
            _view.MouseEnter += (s, e) => { if (_control) FocusView(); };
            _view.MouseClick += (s, e) => { if (!_control) Hint(); };

            Controls.Add(_view);
            Controls.Add(bar);

            KeyUp += OnFormKeyUp;
            Deactivate += (s, e) => ReleaseAll();

            _timer = new System.Windows.Forms.Timer { Interval = 15 };
            _timer.Tick += OnTick;
            _timer.Start();

            try { _comm.OnVideoStreamStatus += OnVideoStatus; } catch { }
            try { _comm.OnScreenshotReceived += OnScreenshot; } catch { }

            Shown += (s, e) => Start();
        }

        private static Button MkButton(string text, int width, Color back)
        {
            var b = new Button
            {
                Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = back,
                ForeColor = Color.White, Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), Margin = new Padding(4, 0, 4, 0),
                TabStop = false,
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        // ----------------------------------------------------------- stream
        private Quality CurrentQuality { get { return (_cboQuality.SelectedItem as Quality) ?? Qualities[0]; } }

        private void Start()
        {
            int gen = ++_generation;
            _fallback = false;
            _lastError = null;
            lock (_decoderErr) _decoderErr.Length = 0;
            _startedAt = DateTime.UtcNow;
            _lastFrameAt = DateTime.MinValue;
            var q = CurrentQuality;
            string err;
            var p = _comm.StartLiveView(_station, q.Fps, q.Scale, q.Kbps, out err);
            if (p == null) { GoFallback(err); return; }
            _decoder = p;
            try
            {
                p.ErrorDataReceived += (s, e) =>
                {
                    if (e.Data == null) return;
                    lock (_decoderErr) { _decoderErr.AppendLine(e.Data); if (_decoderErr.Length > 2000) _decoderErr.Remove(0, _decoderErr.Length - 2000); }
                };
                p.BeginErrorReadLine();
            }
            catch { }
            var t = new Thread(() => ReadLoop(p, gen)) { IsBackground = true, Name = "LiveView " + _station };
            t.Start();
            SetStatus("⏳ در حال اتصال به " + _station + " ...");
        }

        private void StopStream()
        {
            _generation++;
            var p = _decoder; _decoder = null;
            try { _comm.StopLiveView(_station, p); } catch { }
        }

        private void Restart()
        {
            ReleaseAll();
            StopStream();
            Start();
        }

        private void GoFallback(string reason)
        {
            if (_closing) return;
            if (!_fallback) StopStream();
            _fallback = true;
            _lastError = reason;
            SetStatus("⚠️ تصویر روان در دسترس نیست — هر ۳ ثانیه یک عکس");
            if (!string.IsNullOrEmpty(reason))
            {
                try
                {
                    ToastNotification.Show(this, "تصویر روان شروع نشد:\n" + Trim(reason, 220) +
                        "\nبرای تصویر ۳۰ فریم، FFmpeg را روی سرور و این کلاینت نصب و به PATH اضافه کنید.", ToastType.Warning, 9000);
                }
                catch { }
            }
        }

        private static string Trim(string s, int max) { s = s ?? ""; return s.Length <= max ? s : s.Substring(0, max) + "…"; }

        /// <summary>Splits ffmpeg's MJPEG output into JPEG frames (FFD8 ... FFD9).</summary>
        private void ReadLoop(Process p, int gen)
        {
            var buf = new byte[1 << 16];
            var frame = new MemoryStream(1 << 20);
            bool inFrame = false;
            int prev = -1;
            try
            {
                var s = p.StandardOutput.BaseStream;
                int n;
                while (!_closing && gen == _generation && (n = s.Read(buf, 0, buf.Length)) > 0)
                {
                    int segStart = 0;
                    for (int i = 0; i < n; i++)
                    {
                        int b = buf[i];
                        if (!inFrame)
                        {
                            if (prev == 0xFF && b == 0xD8)
                            {
                                inFrame = true;
                                frame.SetLength(0);
                                frame.WriteByte(0xFF); frame.WriteByte(0xD8);
                                segStart = i + 1;
                            }
                        }
                        else if (prev == 0xFF && b == 0xD9)
                        {
                            frame.Write(buf, segStart, i + 1 - segStart);
                            inFrame = false;
                            OnJpeg(frame.ToArray(), gen);
                            if (frame.Capacity > (8 << 20)) frame = new MemoryStream(1 << 20);
                        }
                        prev = b;
                    }
                    if (inFrame && segStart < n) frame.Write(buf, segStart, n - segStart);
                    if (frame.Length > (16 << 20)) { frame.SetLength(0); inFrame = false; } // corrupt stream guard
                }
            }
            catch { }
            if (_closing || gen != _generation) return;
            string err;
            lock (_decoderErr) err = _decoderErr.ToString().Trim();
            try
            {
                BeginInvoke((Action)(() =>
                {
                    if (gen != _generation) return;
                    if (_lastFrameAt == DateTime.MinValue) GoFallback(string.IsNullOrEmpty(err) ? "اتصال تصویر بسته شد." : err);
                    else SetStatus("⚠️ اتصال تصویر قطع شد — «اتصال دوباره» را بزنید");
                }));
            }
            catch { }
        }

        private void OnJpeg(byte[] data, int gen)
        {
            lock (_frameLock)
            {
                _pendingJpeg = data; _pendingGen = gen;
                if (_decodeThread == null)
                {
                    _decodeThread = new Thread(DecodeLoop) { IsBackground = true, Name = "LiveView decode " + _station };
                    _decodeThread.Start();
                }
            }
            try { _jpegReady.Set(); } catch { }
        }

        private void DecodeLoop()
        {
            while (!_closing)
            {
                try { _jpegReady.WaitOne(500); } catch { return; }
                byte[] data; int gen;
                lock (_frameLock) { data = _pendingJpeg; gen = _pendingGen; _pendingJpeg = null; }
                if (data == null) continue;
                Bitmap bmp;
                try
                {
                    using (var ms = new MemoryStream(data))
                    using (var img = Image.FromStream(ms, false, false))
                    {
                        // Premultiplied pixels: the fastest format for GDI+ to draw.
                        bmp = new Bitmap(img.Width, img.Height, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                        using (var g = Graphics.FromImage(bmp))
                        {
                            g.CompositingMode = CompositingMode.SourceCopy;
                            g.InterpolationMode = InterpolationMode.NearestNeighbor;
                            g.DrawImageUnscaled(img, 0, 0);
                        }
                    }
                }
                catch { continue; }
                SetFrame(bmp, gen);
            }
        }

        private void SetFrame(Bitmap bmp, int gen)
        {
            if (_closing || gen != _generation) { bmp.Dispose(); return; }
            Bitmap old;
            lock (_frameLock) { old = _frame; _frame = bmp; }
            old?.Dispose();
            _lastFrameAt = DateTime.UtcNow;
            Interlocked.Increment(ref _frameCount);
            if (Interlocked.Exchange(ref _paintQueued, 1) == 0)
            {
                try { BeginInvoke((Action)(() => { _paintQueued = 0; _view.Invalidate(); })); }
                catch { _paintQueued = 0; }
            }
        }

        private void OnVideoStatus(string station, VideoStreamStatusPayload status)
        {
            if (!string.Equals(station, _station, StringComparison.OrdinalIgnoreCase) || status == null || status.Started) return;
            try { BeginInvoke((Action)(() => GoFallback("کلاینت: " + status.Error))); } catch { }
        }

        private void OnScreenshot(string station, ScreenshotResponsePayload payload)
        {
            if (!_fallback || !string.Equals(station, _station, StringComparison.OrdinalIgnoreCase)) return;
            _shotPending = false;
            if (payload == null || !payload.Success || string.IsNullOrEmpty(payload.ImageBase64)) return;
            try
            {
                var data = Convert.FromBase64String(payload.ImageBase64);
                OnJpeg(data, _generation);
            }
            catch { }
        }

        // ----------------------------------------------------------- timer
        private DateTime _lastStatusAt = DateTime.MinValue;

        private void OnTick(object sender, EventArgs e)
        {
            if (_closing) return;
            // coalesced mouse move (at most one per tick)
            if (_control && _pendingMove.HasValue)
            {
                var pt = _pendingMove.Value; _pendingMove = null;
                double nx, ny;
                if (_view.ToNormalized(pt, false, out nx, out ny)) Send("mousemove", nx, ny, null, 0);
            }

            var now = DateTime.UtcNow;
            if (!_fallback && _decoder != null && _lastFrameAt == DateTime.MinValue && (now - _startedAt).TotalSeconds > 12)
            {
                string err; lock (_decoderErr) err = _decoderErr.ToString().Trim();
                GoFallback(string.IsNullOrEmpty(err) ? "تا ۱۲ ثانیه تصویری نرسید (فایروال ویندوز سرور اجازهٔ ffmpeg را می‌دهد؟)" : err);
            }
            if (_fallback && (!_shotPending || (now - _lastShotAt).TotalSeconds > 8) && (now - _lastShotAt).TotalSeconds >= 3)
            {
                _lastShotAt = now; _shotPending = true;
                try { _comm.RequestScreenshot(_station, 75); } catch { }
            }

            if ((now - _lastStatusAt).TotalMilliseconds < 500) return;
            _lastStatusAt = now;
            double secs = (now - _fpsSince).TotalSeconds;
            if (secs >= 1)
            {
                _fps = Interlocked.Exchange(ref _frameCount, 0) / secs;
                _fpsSince = now;
            }
            if (!_fallback && _lastFrameAt != DateTime.MinValue)
            {
                Size sz; lock (_frameLock) sz = _frame != null ? _frame.Size : Size.Empty;
                bool stale = (now - _lastFrameAt).TotalSeconds > 3;
                SetStatus((stale ? "🟡 بدون تصویر جدید" : "🟢 زنده") + $"  ·  {_fps:0} فریم/ثانیه  ·  {sz.Width}×{sz.Height}" + (_control ? "  ·  کنترل روشن" : ""));
            }
            else if (_fallback)
            {
                SetStatus("⚠️ حالت عکس (هر ۳ ثانیه)" + (_control ? "  ·  کنترل روشن" : ""));
            }
        }

        private void SetStatus(string text) { if (_lblStatus.Text != text) _lblStatus.Text = text; }

        // ----------------------------------------------------------- control
        private void SetControl(bool on)
        {
            if (!on) ReleaseAll();
            if (on && !_control)
                try { ActivityJournal.Record(ActivityJournal.Remote, "کنترل موس و کیبورد روشن شد", _station); } catch { } // round 14
            _control = on;
            _btnControl.Text = on ? "🖱️⌨️ کنترل: روشن" : "🖱️⌨️ کنترل: خاموش";
            _btnControl.BackColor = on ? Color.FromArgb(200, 50, 70) : Color.FromArgb(70, 70, 90);
            _view.Cursor = on ? Cursors.Cross : Cursors.Default;
            if (on) FocusView();
        }

        private void Hint()
        {
            try { ToastNotification.Show(this, "برای استفاده از موس و کیبورد، دکمهٔ «کنترل» را روشن کنید.", ToastType.Info, 2500); } catch { }
        }

        private void FocusView() { try { _view.Focus(); } catch { } }

        private static string ButtonName(MouseButtons b)
        {
            return b == MouseButtons.Right ? "right" : b == MouseButtons.Middle ? "middle" : "left";
        }

        private void OnViewMouseDown(object sender, MouseEventArgs e)
        {
            if (!_control) return;
            FocusView();
            double nx, ny;
            if (!_view.ToNormalized(e.Location, false, out nx, out ny)) return; // on the black bars
            _pendingMove = null;
            string btn = ButtonName(e.Button);
            _buttonsDown.Add(btn);
            Send("mousedown", nx, ny, btn, 0);
        }

        private void OnViewMouseUp(object sender, MouseEventArgs e)
        {
            if (!_control) return;
            string btn = ButtonName(e.Button);
            if (!_buttonsDown.Remove(btn)) return;
            double nx, ny;
            _view.ToNormalized(e.Location, true, out nx, out ny); // clamp: always release
            _pendingMove = null;
            Send("mouseup", nx, ny, btn, 0);
        }

        private void OnViewWheel(object sender, MouseEventArgs e)
        {
            if (!_control) return;
            double nx, ny;
            if (!_view.ToNormalized(e.Location, true, out nx, out ny)) return;
            Send("mousewheel", nx, ny, null, e.Delta);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            const int WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104;
            if (_control && (msg.Msg == WM_KEYDOWN || msg.Msg == WM_SYSKEYDOWN))
            {
                int vk = (int)(keyData & Keys.KeyCode);
                if (vk != 0)
                {
                    _keysDown.Add(vk);
                    SendKey(vk, true);
                    return true; // every key goes to the station, also Tab, arrows, Alt+F4
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void OnFormKeyUp(object sender, KeyEventArgs e)
        {
            if (!_control) return;
            int vk = (int)e.KeyCode;
            if (_keysDown.Remove(vk)) SendKey(vk, false);
            e.Handled = true;
        }

        private void TapKey(Keys k) { SendKey((int)k, true); SendKey((int)k, false); }

        private void SendKey(int vk, bool down)
        {
            try { _comm.SendRemoteInput(_station, down ? "keydown" : "keyup", 0, 0, keyCode: vk); } catch { }
        }

        private void Send(string type, double nx, double ny, string button, int delta)
        {
            try { _comm.SendRemoteInput(_station, type, nx, ny, button, delta); } catch { }
        }

        /// <summary>Lets go of every key and mouse button still held on the station.</summary>
        private void ReleaseAll()
        {
            foreach (var vk in new List<int>(_keysDown)) SendKey(vk, false);
            _keysDown.Clear();
            foreach (var b in new List<string>(_buttonsDown)) Send("mouseup", 0.5, 0.5, b, 0);
            _buttonsDown.Clear();
            _pendingMove = null;
        }

        // ----------------------------------------------------------- misc
        private void ToggleFullScreen()
        {
            if (FormBorderStyle != FormBorderStyle.None)
            {
                _prevBorder = FormBorderStyle; _prevState = WindowState;
                FormBorderStyle = FormBorderStyle.None;
                WindowState = FormWindowState.Normal; // re-maximize to cover the taskbar
                WindowState = FormWindowState.Maximized;
                _btnFull.Text = "🗗 خروج از تمام‌صفحه";
            }
            else
            {
                FormBorderStyle = _prevBorder;
                WindowState = _prevState;
                _btnFull.Text = "⛶ تمام‌صفحه";
            }
            if (_control) FocusView();
        }

        private void SaveSnapshot()
        {
            Bitmap copy = null;
            lock (_frameLock) { if (_frame != null) copy = new Bitmap(_frame); }
            if (copy == null) { MessageBox.Show(this, "هنوز تصویری نرسیده است."); return; }
            using (copy)
            using (var dlg = new SaveFileDialog { Filter = "JPEG|*.jpg|PNG|*.png", FileName = $"live_{_station}_{DateTime.Now:yyyyMMdd_HHmmss}.jpg" })
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    var fmt = dlg.FileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ? System.Drawing.Imaging.ImageFormat.Png : System.Drawing.Imaging.ImageFormat.Jpeg;
                    copy.Save(dlg.FileName, fmt);
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "خطا"); }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            ReleaseAll();
            _closing = true;
            try { _timer.Stop(); _timer.Dispose(); } catch { }
            try { _comm.OnVideoStreamStatus -= OnVideoStatus; } catch { }
            try { _comm.OnScreenshotReceived -= OnScreenshot; } catch { }
            StopStream();
            lock (_frameLock) { _frame?.Dispose(); _frame = null; _pendingJpeg = null; }
            try { _jpegReady.Set(); } catch { }
            base.OnFormClosing(e);
        }

        /// <summary>Double-buffered picture area that keeps the station's aspect ratio.</summary>
        private sealed class FramePanel : Panel
        {
            private readonly LiveControlForm _owner;
            private static readonly Font WaitFont = new Font("Segoe UI", 14F);

            public FramePanel(LiveControlForm owner)
            {
                _owner = owner;
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Selectable, true);
                TabStop = true;
            }

            protected override bool IsInputKey(Keys keyData) { return true; }

            protected override void OnMouseDown(MouseEventArgs e) { Focus(); base.OnMouseDown(e); }

            private Rectangle ImageRect(Size img)
            {
                if (img.Width <= 0 || img.Height <= 0 || Width <= 0 || Height <= 0) return Rectangle.Empty;
                double s = Math.Min((double)Width / img.Width, (double)Height / img.Height);
                int w = (int)Math.Round(img.Width * s), h = (int)Math.Round(img.Height * s);
                return new Rectangle((Width - w) / 2, (Height - h) / 2, w, h);
            }

            public bool ToNormalized(Point p, bool clamp, out double nx, out double ny)
            {
                nx = ny = 0;
                Size img;
                lock (_owner._frameLock) img = _owner._frame != null ? _owner._frame.Size : Size.Empty;
                var r = ImageRect(img);
                if (r.Width <= 0 || r.Height <= 0) return false;
                nx = (p.X - r.X) / (double)r.Width;
                ny = (p.Y - r.Y) / (double)r.Height;
                if (nx < 0 || ny < 0 || nx > 1 || ny > 1)
                {
                    if (!clamp) return false;
                    nx = Math.Max(0, Math.Min(1, nx));
                    ny = Math.Max(0, Math.Min(1, ny));
                }
                return true;
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.Clear(Color.Black);
                lock (_owner._frameLock)
                {
                    var f = _owner._frame;
                    if (f == null)
                    {
                        TextRenderer.DrawText(e.Graphics, "⏳ در انتظار تصویر...", WaitFont, ClientRectangle, Color.Gray,
                            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                        return;
                    }
                    var r = ImageRect(f.Size);
                    e.Graphics.CompositingMode = CompositingMode.SourceCopy;
                    if (r.Width == f.Width && r.Height == f.Height)
                    {
                        e.Graphics.DrawImageUnscaled(f, r.X, r.Y); // 1:1, fastest
                    }
                    else
                    {
                        // Round 13: high-quality filtering costs too much at 60 fps; bilinear
                        // is used then, high quality at 30 fps and below.
                        e.Graphics.InterpolationMode = _owner.CurrentQuality.Fps >= 50 ? InterpolationMode.Bilinear : InterpolationMode.HighQualityBilinear;
                        e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;
                        e.Graphics.DrawImage(f, r);
                    }
                }
            }
        }
    }
}
