using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class SecurityForm : Form
    {
        public SecurityForm()
        {
            this.Text = "امنیت و پایداری";
            this.Size = new Size(700, 630);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;

            var lblTitle = new Label { Text = "🛡️ مرکز امنیت", Font = new Font("Segoe UI", 16F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 15), AutoSize = true };

            // TLS Section
            var grpTls = new GroupBox { Text = "رمزنگاری TLS/SSL", Location = new Point(20, 60), Size = new Size(310, 180), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var lblCert = new Label { Text = "فایل گواهی:", Location = new Point(10, 30), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtCert = new TextBox { Location = new Point(10, 50), Size = new Size(290, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var lblPass = new Label { Text = "رمز گواهی:", Location = new Point(10, 85), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var txtPass = new TextBox { Location = new Point(10, 105), Size = new Size(290, 25), UseSystemPasswordChar = true, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnGenCert = new Button { Text = "🔑 تولید گواهی خودامضا", Location = new Point(10, 140), Size = new Size(290, 30), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnGenCert.Click += (s, e) =>
            {
                using (var dlg = new SaveFileDialog { Filter = "PFX|*.pfx", FileName = "gamenet-cert.pfx" })
                {
                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        // BUG FIX: this used to ignore txtPass entirely and
                        // always encrypt the generated .pfx with the
                        // hardcoded default password ("gamenet"), so
                        // whatever the operator typed into "رمز گواهی" was
                        // silently discarded and had no effect.
                        string pw = string.IsNullOrWhiteSpace(txtPass.Text) ? "gamenet" : txtPass.Text;
                        new TlsWrapper().GenerateSelfSigned(dlg.FileName, pw);
                        MessageBox.Show(string.IsNullOrWhiteSpace(txtPass.Text)
                            ? "گواهی تولید شد! (رمز پیش‌فرض: gamenet — پیشنهاد می‌شود رمز اختصاصی وارد کنید)"
                            : "گواهی تولید شد!");
                    }
                }
            };
            grpTls.Controls.AddRange(new Control[] { lblCert, txtCert, lblPass, txtPass, btnGenCert });

            // Rate Limiter Section
            var grpRate = new GroupBox { Text = "محدودکننده نرخ درخواست", Location = new Point(350, 60), Size = new Size(310, 180), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var lblMaxMin = new Label { Text = "حداکثر درخواست/دقیقه:", Location = new Point(10, 30), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var numMaxMin = new NumericUpDown { Location = new Point(10, 50), Size = new Size(290, 25), Minimum = 5, Maximum = 200, Value = 30, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var lblMaxHr = new Label { Text = "حداکثر درخواست/ساعت:", Location = new Point(10, 85), AutoSize = true, ForeColor = Color.FromArgb(40, 40, 40) };
            var numMaxHr = new NumericUpDown { Location = new Point(10, 105), Size = new Size(290, 25), Minimum = 50, Maximum = 5000, Value = 500, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnBlockList = new Button { Text = "📋 لیست بلاک‌شده‌ها", Location = new Point(10, 140), Size = new Size(290, 30), BackColor = Color.FromArgb(249, 226, 175), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            grpRate.Controls.AddRange(new Control[] { lblMaxMin, numMaxMin, lblMaxHr, numMaxHr, btnBlockList });

            // Audit Log
            var grpAudit = new GroupBox { Text = "لاگ تفصیلی امنیتی", Location = new Point(20, 260), Size = new Size(640, 230), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var dgvAudit = new DataGridView { Location = new Point(10, 25), Size = new Size(620, 160), BackgroundColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), EnableHeadersVisualStyles = false, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(30, 80, 180) }, GridColor = Color.FromArgb(69, 71, 90), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            dgvAudit.Columns.AddRange(new[] { new DataGridViewTextBoxColumn { HeaderText = "زمان", Width = 130 }, new DataGridViewTextBoxColumn { HeaderText = "دسته", Width = 80 }, new DataGridViewTextBoxColumn { HeaderText = "عملیات", Width = 120 }, new DataGridViewTextBoxColumn { HeaderText = "جزئیات", Width = 200 }, new DataGridViewTextBoxColumn { HeaderText = "سطح", Width = 60 } });
            var btnRefresh = new Button { Text = "🔄 بروزرسانی", Location = new Point(10, 190), Size = new Size(120, 30), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnRefresh.Click += (s, e) =>
            {
                dgvAudit.Rows.Clear();
                try
                {
                    var entries = EnhancedAuditLog.Query(limit: 50);
                    foreach (var entry in entries)
                        dgvAudit.Rows.Add(entry.Timestamp.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"), entry.Category, entry.Action, entry.Details, entry.Level);
                }
                catch { }
            };
            var btnCleanup = new Button { Text = "🧹 پاکسازی قدیمی‌ها", Location = new Point(140, 190), Size = new Size(150, 30), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnCleanup.Click += (s, e) => { var del = EnhancedAuditLog.CleanupOldEntries(); MessageBox.Show($"{del} رکورد قدیمی حذف شد"); };
            grpAudit.Controls.AddRange(new Control[] { dgvAudit, btnRefresh, btnCleanup });

            // FIX FEATURE-2: "بازگرداندن به حالت اولیه" (settings-only reset —
            // pricing/appearance/configuration; never touches customer or
            // financial data — see SettingsResetManager for the exact scope
            // and the mandatory pre-reset backup).
            var grpReset = new GroupBox { Text = "بازگرداندن به حالت اولیه", Location = new Point(20, 500), Size = new Size(640, 100), ForeColor = Color.FromArgb(200, 30, 60), BackColor = Color.FromArgb(220, 220, 225) };
            var lblResetInfo = new Label { Text = "فقط تنظیمات (قیمت‌گذاری، ظاهر، پیکربندی) به پیش‌فرض برمی‌گردد. حساب‌ها و تاریخچه‌ی مالی دست نمی‌خورد. قبلش یک بکاپ خودکار گرفته می‌شود.", Location = new Point(10, 25), Size = new Size(460, 60), ForeColor = Color.FromArgb(186, 194, 222), Font = new Font("Segoe UI", 8F) };
            var btnReset = new Button { Text = "🔄 بازنشانی تنظیمات", Location = new Point(490, 30), Size = new Size(140, 30), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            btnReset.Click += (s, e) =>
            {
                if (MessageBox.Show("تمام تنظیمات (قیمت‌گذاری، ظاهر، پیکربندی) به حالت پیش‌فرض برمی‌گردد.\nحساب مشتری‌ها و تاریخچه‌ی مالی دست نمی‌خورد.\nیک بکاپ خودکار قبل از این کار گرفته می‌شود.\n\nادامه می‌دهید؟", "تایید بازنشانی", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                if (MessageBox.Show("این عملیات باید بعد از اجرا، برنامه دوباره راه‌اندازی شود. مطمئنید؟", "تایید نهایی", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

                this.Cursor = Cursors.WaitCursor;
                var result = SettingsResetManager.ResetToDefaults();
                this.Cursor = Cursors.Default;

                if (result.Success)
                    MessageBox.Show($"بازنشانی انجام شد.\nبکاپ ذخیره‌شده در: {result.BackupPath}\n\nلطفاً برنامه را ببندید و دوباره باز کنید.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("بازنشانی ناموفق بود: " + result.ErrorMessage, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            grpReset.Controls.AddRange(new Control[] { lblResetInfo, btnReset });

            this.Controls.AddRange(new Control[] { lblTitle, grpTls, grpRate, grpAudit, grpReset });
        }
    }
}
