using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Session Package management form: create, edit, delete time packages.
    /// </summary>
    public class SessionPackageForm : Form
    {
        private ListView _lvPackages;
        private TextBox _txtName, _txtDesc, _txtPrice;
        private NumericUpDown _nudDuration, _nudMaxUses;
        private ComboBox _cmbCategory;
        private SessionPackageManager _pkgMgr;

        public SessionPackageForm()
        {
            _pkgMgr = new SessionPackageManager();

            this.Text = "بسته‌های زمانی - GameNet";
            this.Size = new Size(900, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.RightToLeft = RightToLeft.Yes;

            // Title
            var lblTitle = new Label
            {
                Text = "مدیریت بسته‌های زمانی",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Input fields
            var lblName = new Label { Text = "نام:", Location = new Point(20, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtName = new TextBox { Location = new Point(80, 48), Size = new Size(180, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblDuration = new Label { Text = "مدت (دقیقه):", Location = new Point(280, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _nudDuration = new NumericUpDown { Location = new Point(380, 48), Size = new Size(80, 30), Minimum = 1, Maximum = 1440, Value = 60, Font = new Font("Segoe UI", 10F) };

            var lblPrice = new Label { Text = "قیمت:", Location = new Point(480, 50), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtPrice = new TextBox { Location = new Point(530, 48), Size = new Size(120, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblDesc = new Label { Text = "توضیحات:", Location = new Point(20, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _txtDesc = new TextBox { Location = new Point(90, 88), Size = new Size(300, 30), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

            var lblCategory = new Label { Text = "دسته:", Location = new Point(410, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _cmbCategory = new ComboBox
            {
                Location = new Point(460, 88), Size = new Size(120, 30), DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            _cmbCategory.Items.AddRange(new object[] { "عادی", "ویژه", "شبانه", "آخر هفته", "طلایی" });
            _cmbCategory.SelectedIndex = 0;

            var lblMaxUses = new Label { Text = "حد استفاده:", Location = new Point(600, 90), AutoSize = true, Font = new Font("Segoe UI", 10F) };
            _nudMaxUses = new NumericUpDown { Location = new Point(690, 88), Size = new Size(80, 30), Minimum = 0, Maximum = 10000, Value = 0, Font = new Font("Segoe UI", 10F) };

            // Buttons
            var btnCreate = new Button
            {
                Text = "ایجاد بسته", Location = new Point(20, 130), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            btnCreate.Click += (s, e) => CreatePackage();

            var btnUpdate = new Button
            {
                Text = "بروزرسانی", Location = new Point(150, 130), Size = new Size(110, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            btnUpdate.Click += (s, e) => UpdatePackage();

            var btnToggle = new Button
            {
                Text = "فعال/غیرفعال", Location = new Point(270, 130), Size = new Size(120, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175))
            };
            btnToggle.Click += (s, e) => TogglePackage();

            var btnDelete = new Button
            {
                Text = "حذف", Location = new Point(400, 130), Size = new Size(80, 35),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            btnDelete.Click += (s, e) => DeletePackage();

            // List
            _lvPackages = new ListView
            {
                Location = new Point(20, 180),
                Size = new Size(840, 360),
                BackColor = Color.FromArgb(240, 240, 240),
                ForeColor = Color.FromArgb(40, 40, 40),
                Font = new Font("Segoe UI", 10F),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            _lvPackages.Columns.Add("ID", 40);
            _lvPackages.Columns.Add("نام", 150);
            _lvPackages.Columns.Add("مدت (دقیقه)", 90);
            _lvPackages.Columns.Add("قیمت", 90);
            _lvPackages.Columns.Add("دسته", 80);
            _lvPackages.Columns.Add("وضعیت", 60);
            _lvPackages.Columns.Add("استفاده", 60);
            _lvPackages.Columns.Add("توضیحات", 200);

            _lvPackages.SelectedIndexChanged += (s, e) =>
            {
                if (_lvPackages.SelectedItems.Count == 0) return;
                var item = _lvPackages.SelectedItems[0];
                _txtName.Text = item.SubItems[1].Text;
                _nudDuration.Value = int.Parse(item.SubItems[2].Text);
                _txtPrice.Text = item.SubItems[3].Text.Replace(",", "");
                _txtDesc.Text = item.SubItems[7].Text;
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblName, _txtName, lblDuration, _nudDuration, lblPrice, _txtPrice, lblDesc, _txtDesc, lblCategory, _cmbCategory, lblMaxUses, _nudMaxUses, btnCreate, btnUpdate, btnToggle, btnDelete, _lvPackages });
            RefreshList();
        }

        private void CreatePackage()
        {
            try
            {
                decimal price = decimal.Parse(_txtPrice.Text);
                _pkgMgr.CreatePackage(_txtName.Text, _txtDesc.Text, (int)_nudDuration.Value, price, _cmbCategory.SelectedItem?.ToString(), (int)_nudMaxUses.Value);
                ClearInputs();
                RefreshList();
                MessageBox.Show("بسته ایجاد شد", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void UpdatePackage()
        {
            if (_lvPackages.SelectedItems.Count == 0) return;
            int id = (int)_lvPackages.SelectedItems[0].Tag;
            try
            {
                decimal price = decimal.Parse(_txtPrice.Text);
                bool isActive = _lvPackages.SelectedItems[0].SubItems[5].Text == "فعال";
                _pkgMgr.UpdatePackage(id, _txtName.Text, _txtDesc.Text, (int)_nudDuration.Value, price, isActive, _cmbCategory.SelectedItem?.ToString());
                RefreshList();
                MessageBox.Show("بسته بروزرسانی شد");
            }
            catch (Exception ex) { MessageBox.Show($"خطا: {ex.Message}"); }
        }

        private void TogglePackage()
        {
            if (_lvPackages.SelectedItems.Count == 0) return;
            int id = (int)_lvPackages.SelectedItems[0].Tag;
            var pkg = _pkgMgr.GetPackage(id);
            if (pkg != null)
            {
                _pkgMgr.UpdatePackage(id, pkg.Name, pkg.Description, pkg.DurationMinutes, pkg.Price, !pkg.IsActive, pkg.Category);
                RefreshList();
            }
        }

        private void DeletePackage()
        {
            if (_lvPackages.SelectedItems.Count == 0) return;
            int id = (int)_lvPackages.SelectedItems[0].Tag;
            if (MessageBox.Show("آیا از حذف مطمئن هستید؟", "تایید", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _pkgMgr.DeletePackage(id);
                RefreshList();
            }
        }

        private void ClearInputs()
        {
            _txtName.Clear(); _txtDesc.Clear(); _txtPrice.Clear();
            _nudDuration.Value = 60; _nudMaxUses.Value = 0; _cmbCategory.SelectedIndex = 0;
        }

        private void RefreshList()
        {
            _lvPackages.Items.Clear();
            var packages = _pkgMgr.GetAllPackages();
            foreach (var p in packages)
            {
                var item = new ListViewItem(p.Id.ToString());
                item.SubItems.Add(p.Name);
                item.SubItems.Add(p.DurationMinutes.ToString());
                item.SubItems.Add($"{p.Price:N0}");
                item.SubItems.Add(p.Category);
                item.SubItems.Add(p.IsActive ? "فعال" : "غیرفعال");
                item.SubItems.Add($"{p.CurrentUses}/{(p.MaxUses == 0 ? "∞" : p.MaxUses.ToString())}");
                item.SubItems.Add(p.Description);
                item.Tag = p.Id;

                if (!p.IsActive) item.ForeColor = Color.FromArgb(147, 153, 178);
                _lvPackages.Items.Add(item);
            }
        }
    }
}
