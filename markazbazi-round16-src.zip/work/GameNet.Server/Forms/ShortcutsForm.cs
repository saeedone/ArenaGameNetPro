using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameNet.Server.Core;
using Newtonsoft.Json;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Shortcuts management form (HandyCafe-style). Lets the operator define
    /// arbitrary shortcut buttons (name + path/command) that can be launched
    /// from the server UI. Shortcuts are persisted to shortcuts.json next to
    /// the server exe so they survive restarts.
    /// </summary>
    public class ShortcutsForm : Form
    {
        private DataGridView _dgv;
        private Button _btnNew, _btnDelete, _btnRun;
        private readonly string _savePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "shortcuts.json");
        private readonly List<ShortcutDef> _shortcuts = new List<ShortcutDef>();

        public ShortcutsForm()
        {
            this.Text = "میانبرها - GameNet";
            this.Size = new Size(800, 560);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Top label
            var lblTitle = new Label
            {
                Text = "⭐ مدیریت میانبرها",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 12),
                AutoSize = true,
            };

            // Buttons bar
            _btnNew = new Button
            {
                Text = "➕ میانبر جدید", Location = new Point(20, 50), Size = new Size(160, 36),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161))
            };
            _btnNew.Click += (s, e) => NewShortcut();

            _btnDelete = new Button
            {
                Text = "❌ حذف میانبر", Location = new Point(190, 50), Size = new Size(160, 36),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168))
            };
            _btnDelete.Click += (s, e) => DeleteShortcut();

            _btnRun = new Button
            {
                Text = "▶ اجرا", Location = new Point(360, 50), Size = new Size(120, 36),
                BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250))
            };
            _btnRun.Click += (s, e) => RunShortcut();

            // Grid
            _dgv = new DataGridView
            {
                Location = new Point(20, 96),
                Size = new Size(740, 400),
                BackgroundColor = Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(230, 230, 235), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                DefaultCellStyle = { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(220, 220, 225), Font = new Font("Segoe UI", 9F) },
                GridColor = Color.FromArgb(220, 220, 225),
                ColumnHeadersHeight = 28,
                RowTemplate = { Height = 26 },
            };
            _dgv.Columns.Add("colName", "نام");
            _dgv.Columns.Add("colPath", "مسیر / دستور");
            _dgv.Columns.Add("colIcon", "آیکن");
            _dgv.CellDoubleClick += (s, e) => RunShortcut();

            Controls.AddRange(new Control[] { lblTitle, _btnNew, _btnDelete, _btnRun, _dgv });

            LoadShortcuts();
            RefreshGrid();
        }

        private void LoadShortcuts()
        {
            try
            {
                if (File.Exists(_savePath))
                {
                    var json = File.ReadAllText(_savePath);
                    var list = JsonConvert.DeserializeObject<List<ShortcutDef>>(json);
                    if (list != null)
                    {
                        _shortcuts.Clear();
                        _shortcuts.AddRange(list);
                    }
                }
            }
            catch (Exception ex)
            {
                AuditLog.Log("ShortcutsForm", "Load failed: " + ex.Message);
            }
        }

        private void SaveShortcuts()
        {
            try
            {
                var json = JsonConvert.SerializeObject(_shortcuts, Formatting.Indented);
                File.WriteAllText(_savePath, json);
                AuditLog.Log("ShortcutsForm", $"Saved {_shortcuts.Count} shortcuts");
            }
            catch (Exception ex)
            {
                AuditLog.Log("ShortcutsForm", "Save failed: " + ex.Message);
            }
        }

        private void RefreshGrid()
        {
            _dgv.Rows.Clear();
            foreach (var s in _shortcuts)
            {
                _dgv.Rows.Add(s.Name, s.Path, s.Icon ?? "📦");
            }
        }

        private void NewShortcut()
        {
            using (var dlg = new ShortcutEditDialog())
            {
                if (dlg.ShowDialog(this) == DialogResult.OK && !string.IsNullOrWhiteSpace(dlg.ShortcutName))
                {
                    _shortcuts.Add(new ShortcutDef
                    {
                        Name = dlg.ShortcutName,
                        Path = dlg.ShortcutPath,
                        Icon = string.IsNullOrWhiteSpace(dlg.ShortcutIcon) ? "📦" : dlg.ShortcutIcon
                    });
                    SaveShortcuts();
                    RefreshGrid();
                }
            }
        }

        private void DeleteShortcut()
        {
            if (_dgv.SelectedRows.Count == 0) return;
            int idx = _dgv.SelectedRows[0].Index;
            if (idx < 0 || idx >= _shortcuts.Count) return;
            if (MessageBox.Show("حذف این میانبر؟", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _shortcuts.RemoveAt(idx);
                SaveShortcuts();
                RefreshGrid();
            }
        }

        private void RunShortcut()
        {
            if (_dgv.SelectedRows.Count == 0) return;
            int idx = _dgv.SelectedRows[0].Index;
            if (idx < 0 || idx >= _shortcuts.Count) return;
            var s = _shortcuts[idx];
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = s.Path,
                    UseShellExecute = true,
                };
                Process.Start(psi);
                AuditLog.Log("ShortcutsForm", $"Ran shortcut '{s.Name}': {s.Path}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("اجرای میانبر ناموفق بود:\n" + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                AuditLog.Log("ShortcutsForm", $"Run failed for '{s.Name}': {ex.Message}");
            }
        }

        // ---------- DTO + edit dialog ----------

        private class ShortcutDef
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public string Icon { get; set; }
        }

        private class ShortcutEditDialog : Form
        {
            public string ShortcutName { get; private set; }
            public string ShortcutPath { get; private set; }
            public string ShortcutIcon { get; private set; }

            private readonly TextBox _txtName, _txtPath, _txtIcon;
            private readonly Button _btnBrowse;

            public ShortcutEditDialog()
            {
                this.Text = "میانبر جدید";
                this.Size = new Size(440, 230);
                this.BackColor = ThemeManager.BackgroundColor;
                this.ForeColor = Color.FromArgb(40, 40, 40);
                this.RightToLeft = RightToLeft.Yes;
                this.StartPosition = FormStartPosition.CenterParent;
                this.FormBorderStyle = FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;

                var lblName = new Label { Text = "نام:", Location = new Point(15, 18), AutoSize = true, Font = new Font("Segoe UI", 10F) };
                _txtName = new TextBox { Location = new Point(80, 15), Size = new Size(330, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };

                var lblPath = new Label { Text = "مسیر:", Location = new Point(15, 58), AutoSize = true, Font = new Font("Segoe UI", 10F) };
                _txtPath = new TextBox { Location = new Point(80, 55), Size = new Size(250, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F) };
                _btnBrowse = new Button { Text = "…", Location = new Point(340, 54), Size = new Size(70, 32), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)) };
                _btnBrowse.Click += (s, e) =>
                {
                    using (var ofd = new OpenFileDialog())
                    {
                        ofd.Filter = "همه فایلها (*.*)|*.*|برنامه (*.exe)|*.exe|دستورات (*.bat;*.cmd)|*.bat;*.cmd";
                        if (ofd.ShowDialog(this) == DialogResult.OK)
                            _txtPath.Text = ofd.FileName;
                    }
                };

                var lblIcon = new Label { Text = "آیکن:", Location = new Point(15, 98), AutoSize = true, Font = new Font("Segoe UI", 10F) };
                _txtIcon = new TextBox { Location = new Point(80, 95), Size = new Size(330, 28), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Font = new Font("Segoe UI", 10F), Text = "📦" };

                var btnSave = new Button
                {
                    Text = "ذخیره", Location = new Point(80, 140), Size = new Size(150, 36),
                    BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)),
                    DialogResult = DialogResult.OK
                };
                var btnCancel = new Button
                {
                    Text = "انصراف", Location = new Point(240, 140), Size = new Size(120, 36),
                    BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)),
                    DialogResult = DialogResult.Cancel
                };

                btnSave.Click += (s, e) =>
                {
                    ShortcutName = _txtName.Text.Trim();
                    ShortcutPath = _txtPath.Text.Trim();
                    ShortcutIcon = _txtIcon.Text.Trim();
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                };

                Controls.AddRange(new Control[] { lblName, _txtName, lblPath, _txtPath, _btnBrowse, lblIcon, _txtIcon, btnSave, btnCancel });
                this.AcceptButton = btnSave;
                this.CancelButton = btnCancel;
            }
        }
    }
}
