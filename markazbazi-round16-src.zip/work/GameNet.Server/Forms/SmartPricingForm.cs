using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class SmartPricingForm : Form
    {
        private readonly SmartPricing _engine = new SmartPricing();
        private DataGridView _dgvRules;

        public SmartPricingForm()
        {
            this.Text = "قیمت‌گذاری هوشمند";
            this.Size = new Size(750, 600);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.StartPosition = FormStartPosition.CenterScreen;

            var lblTitle = new Label { Text = "🤖 قیمت‌گذاری هوشمند", Font = new Font("Segoe UI", 16F, FontStyle.Bold), ForeColor = Color.FromArgb(30, 80, 180), Location = new Point(20, 15), AutoSize = true };

            var grpNew = new GroupBox { Text = "قانون جدید", Location = new Point(20, 55), Size = new Size(690, 150), ForeColor = Color.FromArgb(20, 130, 50), BackColor = Color.FromArgb(220, 220, 225) };
            var lblName = new Label { Text = "نام:", Location = new Point(10, 25), ForeColor = Color.FromArgb(40, 40, 40), AutoSize = true };
            var txtName = new TextBox { Location = new Point(70, 22), Size = new Size(200, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            var lblType = new Label { Text = "نوع:", Location = new Point(290, 25), ForeColor = Color.FromArgb(40, 40, 40), AutoSize = true };
            var cmbType = new ComboBox { Location = new Point(330, 22), Size = new Size(150, 25), DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };
            cmbType.Items.AddRange(new object[] { "time_of_day", "day_of_week", "low_traffic", "loyalty", "station_category" });
            cmbType.SelectedIndex = 0;
            var lblDiscount = new Label { Text = "تخفیف٪:", Location = new Point(500, 25), ForeColor = Color.FromArgb(40, 40, 40), AutoSize = true };
            var numDiscount = new NumericUpDown { Location = new Point(560, 22), Size = new Size(80, 25), Minimum = 1, Maximum = 50, Value = 10, BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40) };

            var lblCond = new Label { Text = "شرط (JSON):", Location = new Point(10, 60), ForeColor = Color.FromArgb(40, 40, 40), AutoSize = true };
            var txtCond = new TextBox { Location = new Point(100, 57), Size = new Size(580, 25), BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), Text = @"{""StartHour"":22,""EndHour"":8}" };

            var btnAdd = new Button { Text = "➕ افزودن قانون", Location = new Point(10, 100), Size = new Size(670, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)) };
            btnAdd.Click += (s, e) =>
            {
                try
                {
                    _engine.CreateRule(txtName.Text, cmbType.SelectedItem.ToString(), txtCond.Text, numDiscount.Value);
                    RefreshRules();
                    MessageBox.Show("قانون اضافه شد!");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            };
            grpNew.Controls.AddRange(new Control[] { lblName, txtName, lblType, cmbType, lblDiscount, numDiscount, lblCond, txtCond, btnAdd });

            _dgvRules = new DataGridView { Location = new Point(20, 220), Size = new Size(690, 280), BackgroundColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(40, 40, 40), EnableHeadersVisualStyles = false, ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(220, 220, 225), ForeColor = Color.FromArgb(30, 80, 180) }, GridColor = Color.FromArgb(69, 71, 90), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            _dgvRules.Columns.AddRange(new[] { new DataGridViewTextBoxColumn { HeaderText = "ID", Width = 40 }, new DataGridViewTextBoxColumn { HeaderText = "نام", Width = 150 }, new DataGridViewTextBoxColumn { HeaderText = "نوع", Width = 120 }, new DataGridViewTextBoxColumn { HeaderText = "تخفیف٪", Width = 60 }, new DataGridViewTextBoxColumn { HeaderText = "فعال", Width = 50 } });
            var btnDelete = new Button { Text = "🗑️ حذف قانون", Location = new Point(20, 510), Size = new Size(150, 35), BackColor = Color.FromArgb(243, 139, 168), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F) };
            btnDelete.Click += (s, e) =>
            {
                if (_dgvRules.SelectedRows.Count > 0)
                {
                    int id = (int)_dgvRules.SelectedRows[0].Cells[0].Value;
                    _engine.DeleteRule(id); RefreshRules();
                }
            };

            var btnTraffic = new Button { Text = "📈 پیش‌بینی ترافیک", Location = new Point(560, 510), Size = new Size(150, 35), BackColor = Color.FromArgb(137, 180, 250), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9F) };
            btnTraffic.Click += (s, e) => { var pred = _engine.PredictTraffic(); MessageBox.Show($"پیش‌بینی ۲۴ ساعت آینده:\nساعت اوج: {pred.HourlyPredictions.OrderByDescending(p => p.PredictedClients).First().Hour}:۰۰\nساعت خلوت: {pred.HourlyPredictions.OrderBy(p => p.PredictedClients).First().Hour}:۰۰"); };

            this.Controls.AddRange(new Control[] { lblTitle, grpNew, _dgvRules, btnDelete, btnTraffic });
            RefreshRules();
        }

        private void RefreshRules()
        {
            _dgvRules.Rows.Clear();
            try { foreach (var r in _engine.GetActiveRules()) _dgvRules.Rows.Add(r.Id, r.Name, r.RuleType, r.DiscountPercent, r.IsActive ? "✓" : "✗"); } catch { }
        }
    }
}
