﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    public class TicketManagerForm : Form
    {
        private TicketManager _mgr = new TicketManager();
        private DataGridView dgv; private TextBox txtCredit, txtDuration, txtBatch;

        public TicketManagerForm()
        {
            this.Text = "مدیریت تیکت‌ها"; this.Size = new Size(900, 500);
            this.BackColor = ThemeManager.BackgroundColor; this.ForeColor = Color.FromArgb(40, 40, 40);

            var pnlCreate = new Panel { Dock = DockStyle.Left, Width = 300, BackColor = Color.FromArgb(255, 255, 255) };
            pnlCreate.Controls.Add(new Label { Text = "اعتبار (تومان):", Location = new Point(15, 15), ForeColor = Color.FromArgb(40, 40, 40) });
            txtCredit = new TextBox { Location = new Point(15, 40), Size = new Size(260, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "50000" };
            pnlCreate.Controls.Add(txtCredit);
            pnlCreate.Controls.Add(new Label { Text = "مدت (دقیقه):", Location = new Point(15, 75), ForeColor = Color.FromArgb(40, 40, 40) });
            txtDuration = new TextBox { Location = new Point(15, 100), Size = new Size(260, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "0" };
            pnlCreate.Controls.Add(txtDuration);
            pnlCreate.Controls.Add(new Label { Text = "تعداد دسته‌ای:", Location = new Point(15, 135), ForeColor = Color.FromArgb(40, 40, 40) });
            txtBatch = new TextBox { Location = new Point(15, 160), Size = new Size(260, 27), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40), Text = "1" };
            pnlCreate.Controls.Add(txtBatch);

            var btnCreate = new Button { Text = "ایجاد تیکت", Location = new Point(15, 200), Size = new Size(125, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)), Font = new Font("Segoe UI", 10F, FontStyle.Bold) };
            btnCreate.Click += (s, e) => { try { _mgr.CreateTicket(decimal.Parse(txtCredit.Text), int.Parse(txtDuration.Text)); LoadTickets(); MessageBox.Show("تیکت ایجاد شد"); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            var btnBatch = new Button { Text = "ایجاد دسته‌ای", Location = new Point(150, 200), Size = new Size(125, 35), BackColor = ThemeManager.SurfaceColor, FlatStyle = FlatStyle.Flat, ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)), Font = new Font("Segoe UI", 10F, FontStyle.Bold) };
            btnBatch.Click += (s, e) => { try { _mgr.CreateBatch(int.Parse(txtBatch.Text), decimal.Parse(txtCredit.Text), int.Parse(txtDuration.Text)); LoadTickets(); MessageBox.Show("تیکت‌ها ایجاد شدند"); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            pnlCreate.Controls.Add(btnCreate); pnlCreate.Controls.Add(btnBatch);

            dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(255, 255, 255), AllowUserToAddRows = false, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("colCode", "کد"); dgv.Columns.Add("colCredit", "اعتبار"); dgv.Columns.Add("colDuration", "مدت"); dgv.Columns.Add("colUsed", "استفاده شده"); dgv.Columns.Add("colUsedBy", "کاربر");

            Controls.AddRange(new Control[] { dgv, pnlCreate });
            LoadTickets();
        }

        private void LoadTickets()
        {
            dgv.Rows.Clear();
            foreach (var t in _mgr.GetAllTickets())
                dgv.Rows.Add(t.Code, t.CreditAmount.ToString("N0"), t.DurationMinutes > 0 ? t.DurationMinutes + " دقیقه" : "-", t.IsUsed ? "بله" : "خیر", t.UsedByUsername ?? "-");
        }
    }
}
