using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// Admin panel to enable/disable client features. Changes are saved to
    /// the client_feature_flags table and applied on the client's next
    /// ConfigSync (reconnect or manual refresh).
    /// </summary>
    public class FeatureToggleForm : Form
    {
        private readonly Dictionary<string, CheckBox> _checkboxes = new Dictionary<string, CheckBox>();
        private Timer _timer;

        // Feature display names (key → Persian label + icon)
        private readonly Dictionary<string, string> _labels = new Dictionary<string, string>
        {
            { "games",         "🎮 بازی‌ها" },
            { "chat",          "💬 چت با اپراتور" },
            { "announcements", "📢 اطلاعیه‌ها" },
            { "loyalty",       "🏆 امتیازات وفاداری" },
            { "profile",       "👤 پروفایل کاربر" },
            { "stats",         "📊 آمار شخصی" },
            { "topup",         "💳 شارژ سریع" },
            { "ticket",        "🎫 تیکت" },
            { "settings",      "⚙️ تنظیمات اتصال" },
            { "food",          "🍔 سفارش غذا" },
            { "pause",         "⏸️ توقف موقت نشست" },
            { "history",       "📋 تاریخچه نشست‌ها" },
            { "leaderboard",   "🏆 رتبه‌بندی برترین‌ها" },
            { "volume",        "🔊 تنظیم صدا" },
            { "guest",         "🔐 ورود مهمان" },
            { "night_mode",    "🌑 حالت شب" },
            // Phase 14
            { "ups_monitor",   "🔌 مانیتور برق (UPS)" },
            { "screensaver",   "💤 اسکرین‌سیور" },
            { "card_reader",   "💳 ورود با کارت (RFID)" },
            { "game_tracker",  "🎮 ردیابی زمان بازی" },
            { "multi_monitor", "🖥️ پشتیبانی چند مانیتور" },
            { "save_backup",   "💾 بکاپ save بازی‌ها" },
            { "speed_test",    "📊 تست سرعت شبکه" },
            { "qr_login",      "📱 ورود با QR کد" },
            { "wallpaper",     "🖼️ والپیپر از سرور" },
            { "ambient_music", "🎵 موسیقی محیطی" },
            { "temp_display",  "🌡️ نمایش دمای CPU/GPU" },
        };

        public FeatureToggleForm()
        {
            this.Text = "🎛️ فعال/غیرفعال کردن قابلیت‌های کلاینت";
            this.Size = new Size(500, 680);
            this.BackColor = Color.FromArgb(255, 255, 255);
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterParent;

            BuildUi();
            LoadState();

            // Auto-refresh every 10s (in case another admin changes something)
            _timer = new Timer { Interval = 10000 };
            _timer.Tick += (s, e) => LoadState();
            _timer.Start();
        }

        private void BuildUi()
        {
            var lblTitle = new Label
            {
                Text = "🎛️ قابلیت‌های کلاینت",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(15, 10),
                AutoSize = true,
            };

            var lblInfo = new Label
            {
                Text = "قابلیت‌های فعال به کلاینت‌ها نمایش داده می‌شوند.\nغیرفعال کردن باعث مخفی شدن دکمه/پنل در کیوسک می‌شود.\nتغییرات در اتصال بعدی کلاینت اعمال می‌شوند.",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(15, 40),
                Size = new Size(450, 45),
            };

            var scrollPanel = new Panel
            {
                Location = new Point(15, 95),
                Size = new Size(450, 480),
                AutoScroll = true,
                BackColor = Color.FromArgb(225, 225, 230),
            };

            int y = 10;
            foreach (var key in FeatureFlagManager.AllFeatures)
            {
                string label = _labels.ContainsKey(key) ? _labels[key] : key;

                var chk = new CheckBox
                {
                    Text = label,
                    Location = new Point(20, y),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 11F),
                    ForeColor = Color.FromArgb(40, 40, 40),
                    Checked = true, // default
                    Tag = key,
                };
                chk.CheckedChanged += (s, e) =>
                {
                    string k = (string)((CheckBox)s).Tag;
                    FeatureFlagManager.SetEnabled(k, ((CheckBox)s).Checked);
                };

                _checkboxes[key] = chk;
                scrollPanel.Controls.Add(chk);
                y += 32;
            }

            var btnAllOn = new Button
            {
                Text = "✅ فعال کردن همه",
                Location = new Point(15, 590),
                Size = new Size(150, 35),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(166, 227, 161)),
            };
            btnAllOn.Click += (s, e) =>
            {
                foreach (var key in FeatureFlagManager.AllFeatures)
                    FeatureFlagManager.SetEnabled(key, true);
                LoadState();
                MessageBox.Show("همه قابلیت‌ها فعال شدند.", "موفق", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            var btnAllOff = new Button
            {
                Text = "🚫 غیرفعال کردن همه",
                Location = new Point(175, 590),
                Size = new Size(160, 35),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(243, 139, 168)),
            };
            btnAllOff.Click += (s, e) =>
            {
                if (MessageBox.Show("غیرفعال کردن همه قابلیت‌ها؟\n(تنها صفحه ورود باقی می‌ماند)", "تایید", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    foreach (var key in FeatureFlagManager.AllFeatures)
                        FeatureFlagManager.SetEnabled(key, false);
                    LoadState();
                }
            };

            this.Controls.AddRange(new Control[] { lblTitle, lblInfo, scrollPanel, btnAllOn, btnAllOff });
        }

        private void LoadState()
        {
            var flags = FeatureFlagManager.GetAll();
            foreach (var kvp in flags)
            {
                if (_checkboxes.ContainsKey(kvp.Key))
                {
                    // Temporarily unsubscribe to avoid triggering SetEnabled
                    var chk = _checkboxes[kvp.Key];
                    chk.CheckedChanged -= OnCheckedChanged;
                    chk.Checked = kvp.Value;
                    chk.CheckedChanged += OnCheckedChanged;
                }
            }
        }

        private void OnCheckedChanged(object sender, EventArgs e)
        {
            var chk = (CheckBox)sender;
            string key = (string)chk.Tag;
            FeatureFlagManager.SetEnabled(key, chk.Checked);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _timer?.Stop();
            _timer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
