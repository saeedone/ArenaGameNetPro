using System;
using System.Drawing;
using System.Windows.Forms;
using GameNet.Server.Core;
using GameNet.Shared;

namespace GameNet.Server.Forms
{
    /// <summary>
    /// ADD-MULTI-FEATURES Feature 3: VIP membership panel.
    ///
    /// Shows:
    ///   • Top 10 VIP members (by points) — grid with username, points, tier, discount
    ///   • Per-user lookup: enter a username → see their current points + tier
    ///   • Manual point adjustment: +/- N points to the looked-up user
    ///
    /// Distinct from MemberTierForm (which manages the configurable
    /// member_tiers table) and LoyaltyForm (which manages redeemable
    /// loyalty_points). VipForm surfaces the simple vip_points column
    /// added by Feature 3.
    /// </summary>
    public class VipForm : Form
    {
        private DataGridView _dgv;
        private TextBox _txtUser, _txtDelta;
        private Label _lblUserPoints, _lblUserTier, _lblUserDiscount;

        public VipForm()
        {
            this.Text = "💎 پنل VIP";
            this.Size = new Size(900, 640);
            this.BackColor = ThemeManager.BackgroundColor;
            this.ForeColor = Color.FromArgb(40, 40, 40);
            this.RightToLeft = RightToLeft.Yes;
            this.StartPosition = FormStartPosition.CenterScreen;

            BuildUi();
            LoadTopMembers();
        }

        private void BuildUi()
        {
            var lblTitle = new Label
            {
                Text = "💎 پنل اعضای VIP",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 12),
                AutoSize = true,
            };

            var lblRules = new Label
            {
                Text = "۱ امتیاز به ازای هر ۱۰۰۰ تومان هزینه\n" +
                       "🥉 برنزی ۰٪ · 🥈 نقره‌ای (۱۰۰+) ۵٪ · 🥇 طلایی (۵۰۰+) ۱۰٪ · 💎 پلاتین (۲۰۰۰+) ۱۵٪",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(20, 140, 130),
                Location = new Point(20, 50),
                AutoSize = true,
            };

            // === Top members grid ===
            var lblGrid = new Label
            {
                Text = "🏆 برترین اعضای VIP",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 130, 50),
                Location = new Point(20, 100),
                AutoSize = true,
            };

            _dgv = new DataGridView
            {
                Location = new Point(20, 130),
                Size = new Size(840, 280),
                BackgroundColor = Color.FromArgb(255, 255, 255),
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 255, 255), ForeColor = Color.FromArgb(40, 40, 40), SelectionBackColor = Color.FromArgb(69, 71, 90), SelectionForeColor = Color.White },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 240, 240), ForeColor = Color.FromArgb(30, 80, 180), Font = new Font("Segoe UI", 9F, FontStyle.Bold) },
                EnableHeadersVisualStyles = false,
            };
            _dgv.Columns.Add("colU", "نام کاربری");
            _dgv.Columns.Add("colD", "نام نمایشی");
            _dgv.Columns.Add("colP", "امتیاز");
            _dgv.Columns.Add("colT", "سطح");
            _dgv.Columns.Add("colDis", "تخفیف");

            var btnRefresh = new Button
            {
                Text = "🔄 بازخوانی",
                Location = new Point(20, 420),
                Size = new Size(140, 34),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)),
            };
            btnRefresh.Click += (s, e) => LoadTopMembers();

            // === User lookup ===
            var lblLookup = new Label
            {
                Text = "🔍 جستجوی کاربر",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 180),
                Location = new Point(20, 470),
                AutoSize = true,
            };

            var lblUser = new Label { Text = "نام کاربری:", Location = new Point(20, 505), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _txtUser = new TextBox { Location = new Point(110, 502), Size = new Size(220, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            var btnLookup = new Button
            {
                Text = "🔍 نمایش",
                Location = new Point(340, 500),
                Size = new Size(100, 32),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(137, 180, 250)),
            };
            btnLookup.Click += (s, e) => LookupUser();

            _lblUserPoints = new Label { Text = "امتیاز: ---", Location = new Point(460, 505), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(20, 130, 50) };
            _lblUserTier = new Label { Text = "سطح: ---", Location = new Point(600, 505), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(180, 140, 20) };
            _lblUserDiscount = new Label { Text = "تخفیف: ---", Location = new Point(720, 505), AutoSize = true, Font = new Font("Segoe UI", 10F, FontStyle.Bold), ForeColor = Color.FromArgb(130, 50, 180) };

            var lblDelta = new Label { Text = "تغییر امتیاز (±N):", Location = new Point(20, 545), AutoSize = true, Font = new Font("Segoe UI", 9F) };
            _txtDelta = new TextBox { Location = new Point(140, 542), Size = new Size(120, 28), Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(245, 245, 248), ForeColor = Color.FromArgb(40, 40, 40) };
            _txtDelta.Text = "0";

            var btnAdjust = new Button
            {
                Text = "✏️ اعمال تغییر",
                Location = new Point(280, 540),
                Size = new Size(160, 34),
                BackColor = ThemeManager.SurfaceColor,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = ThemeManager.ThemedAccent(Color.FromArgb(249, 226, 175)),
            };
            btnAdjust.Click += (s, e) => Adjust();

            this.Controls.AddRange(new Control[] {
                lblTitle, lblRules,
                lblGrid, _dgv, btnRefresh,
                lblLookup, lblUser, _txtUser, btnLookup, _lblUserPoints, _lblUserTier, _lblUserDiscount,
                lblDelta, _txtDelta, btnAdjust,
            });

            this.AcceptButton = btnLookup;
        }

        private void LoadTopMembers()
        {
            try
            {
                _dgv.Rows.Clear();
                var members = VipManager.GetAllVipMembers(10);
                foreach (var m in members)
                {
                    _dgv.Rows.Add(m.Username, m.DisplayName, m.Points, VipManager.TierIcon(m.Tier) + " " + m.Tier, m.DiscountPercent.ToString("0") + "٪");
                }
                if (members.Count == 0)
                {
                    ToastNotification.Show(this, "هنوز هیچ امتیاز VIP ثبت نشده است.", ToastType.Info, 2500);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در بارگذاری اعضای VIP: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LookupUser()
        {
            string user = _txtUser.Text.Trim();
            if (string.IsNullOrEmpty(user)) { MessageBox.Show("نام کاربری را وارد کنید."); return; }
            try
            {
                int pts = VipManager.GetPoints(user);
                string tier = VipManager.GetTier(user);
                decimal disc = VipManager.GetDiscountPercent(user);
                _lblUserPoints.Text = $"امتیاز: {pts:N0}";
                _lblUserTier.Text = $"سطح: {VipManager.TierIcon(tier)} {tier}";
                _lblUserDiscount.Text = $"تخفیف: {disc:0}٪";
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Adjust()
        {
            string user = _txtUser.Text.Trim();
            if (string.IsNullOrEmpty(user)) { MessageBox.Show("ابتدا نام کاربری را وارد کنید."); return; }
            if (!int.TryParse(_txtDelta.Text, out int delta) || delta == 0) { MessageBox.Show("یک عدد صحیح غیر از صفر وارد کنید (مثبت یا منفی)."); return; }
            try
            {
                VipManager.AdjustPoints(user, delta);
                LookupUser();
                LoadTopMembers();
                ToastNotification.Show(this, $"امتیاز {user} به اندازه {delta:+#;-#;0} تغییر کرد.", ToastType.Success, 2500);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا: " + ex.Message, "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
