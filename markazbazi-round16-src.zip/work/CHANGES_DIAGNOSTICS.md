# Self-repair and diagnostics: change record (FMEA)

**Status: not compiled and not run.** The sandbox used for this work has no .NET Framework toolchain and no Windows. Everything here was checked by reading the code and by static scripts only (section 7). Build and run before deploying (section 8).

## 1. Method

The failure modes were analysed with FMEA (Failure Mode and Effects Analysis, IEC 60812). Every way the client or the server can break is one row of a single catalogue, `GameNet.Shared/Diagnostics/FaultCatalog.cs`. Each row has:

- a stable code (for example `NET-001`), never reused,
- a severity (Info, Warning, Error, Critical),
- a plain-language title, the most likely cause, and the manual action,
- what the software repairs by itself (or an explicit "nothing").

Every fault goes through three steps:

1. **Detect.** The code that sees the failure calls `FaultJournal.Raise(code, detail, throttleKey)`.
2. **Explain.** The record is appended to `diagnostics.log` (one JSON object per line). The operator or the kiosk user sees the title, cause and action (kiosk status label, toast, or the diagnostics viewer).
3. **Repair.** Only the automatic repairs listed in section 3 run. Security decisions are never changed automatically.

Repair rules:

- **R1, retry with backoff and jitter, never in a tight loop.** `RecoveryPolicy.Backoff` returns `initial * 2^(attempt-1)`, capped. `RecoveryPolicy.WithJitter` removes up to 20 % of the delay at random, so kiosks restarted together do not retry at the same instant.
- **R2, supervised listener.** The server's listening socket runs in its own supervisor loop. It re-binds after a busy-port error and rebuilds the socket after three consecutive accept errors.

## 2. Files

New, in `GameNet.Shared/Diagnostics/`:

- `FaultCatalog.cs`: the 32 codes; `ClassifyTlsReason` maps the existing TLS reason text to a code (the text itself is unchanged); `ClassifyException` maps exceptions to `APP-0xx` codes.
- `FaultJournal.cs`: `diagnostics.log` (JSON lines, rotated to `.1` at 1 MB, shared-access reads); throttling per code and key; `FaultRaised` event; `RecordCrash` and `TakePendingReport` for the explanation shown on the next start.
- `RecoveryPolicy.cs`: `Backoff` and `WithJitter`.
- `DiagnosticsViewer.cs`: read-only, right-to-left viewer (list, detail, reload, copy report, open folder).

New test: `GameNet.Server.Tests/DiagnosticsTests.cs`, 28 NUnit tests (backoff and jitter bounds, catalogue completeness, TLS and exception classification, journal writing, throttling, rotation, crash explanation).

Changed:

- `GameNet.Shared/GameNet.Shared.csproj`: references `System.Windows.Forms` and `System.Drawing` for the viewer.
- `GameNet.Client/ClientEngine.cs`: welcome watchdog (NET-005); drop diagnosis (NET-007, NET-008); reconnect backoff with jitter; give-up after 50 fast attempts (NET-006); recovery notice (NET-900); login challenge after ClientReconnect is treated as a restored link; connect-failure classification (NET-001 to NET-004, CFG-003).
- `GameNet.Client/NetworkClient.cs`: keeps `LastError`; `LastTlsError` is reset per connect. TLS behaviour and reason texts are unchanged.
- `GameNet.Client/ConnectionSettings.cs`: a settings file with no recognised key is renamed (quarantined) and defaults are used (CFG-001). Nothing is deleted.
- `GameNet.Client/CrashReporter.cs`: crashes are also recorded in the journal.
- `GameNet.Client/Program.cs`: journal initialised first; `GameNet.Client.exe --diagnose` opens the viewer.
- `GameNet.Client/KioskForm.cs`: fault status label and toasts; the same server message (same title and text) within 5 minutes shows as a toast instead of a new modal box; crash explanation shown at start.
- `GameNet.Server/Core/ClientCommunicator.cs`: listener supervisor (SRV-001, SRV-003, SRV-900); records refusals (AUTH-001, AUTH-002, AUTH-003), TLS faults (TLS-001, NET-010, NET-011), DB-002 and CFG-002 fail-open paths, and rate-limit drops (SRV-004). Decisions are unchanged.
- `GameNet.Server/Program.cs`: journal initialised first; crash handlers; DB-001; CFG-002.
- `GameNet.Server/Forms/MainForm.cs`: Tools menu item "عیب‌یابی و گزارش خطاها"; toasts for Error and Critical faults; crash explanation at start.

## 3. Automatic repair

| Situation | Code | What the software does |
|---|---|---|
| Client cannot reach the server | NET-001 | Retries after 1 s, 2 s, 4 s, ... up to 30 s, with jitter. After 50 fast attempts: NET-006 once, then every 60 s. |
| Link open but no ServerWelcome in 30 s | NET-005 | Drops the link and reconnects (welcome watchdog). |
| Link dropped after welcome / before welcome | NET-007 / NET-008 | Reports the reason once per drop, then reconnects with R1. The server's refusal text is kept in the detail. |
| Reconnect succeeds | NET-900 | Information notice. |
| ClientReconnect answered by a login challenge | (none) | The link counts as restored: the watchdog stops, the backoff resets, NET-900 is recorded. The message goes to the login panel as before. |
| Server port busy | SRV-003 | Retries with backoff (1 s to 30 s) until the port is free, then SRV-900. |
| Server accept errors | SRV-001 | Retries with backoff; after three in a row the socket is rebuilt; SRV-900 when accepting again. |
| Damaged client settings file | CFG-001 | Renames the file to `*.damaged-<timestamp>` and uses defaults. Never deletes. |
| Unhandled crash | APP-0xx | Recorded; a Persian explanation is written to `pending_report.txt` and shown at the next start. |

## 4. Behaviour changes to review

1. A refusal before ServerWelcome (AUTH-001, AUTH-002, AUTH-003) now appears as a station notice (title "دسترسی کیوسک", text from the server, unchanged) instead of the login panel. It is recorded as NET-008. The server closes the link about 2 s after the refusal.
2. OnConnected on a fresh connect is now raised when ServerWelcome arrives. It used to be raised right after ClientHello was sent. A refused station no longer receives OnConnected.
3. The server's `Start()` no longer throws when the port is busy. It keeps retrying (SRV-003).
4. Repeated server messages within 5 minutes show as a toast instead of a modal box.

## 5. Deliberately NOT changed (these need explicit approval)

- TLS default, TLS and pin behaviour, certificate handling.
- Protected wording, verified identical to the original tree: the H3/P5 strings in `TlsWrapper.cs`, `KeyRotationManager.cs` and `SecurityDashboardForm.cs`, and the "— using plaintext" line in `ClientCommunicator.cs`.
- Access control (ACL), the integrity check (still fail-open, DB-002), and the station password check (still fail-open, CFG-002).
- Rate-limit values. SRV-004 logs the drop; the limit is unchanged. The keying of pre-hello messages was changed in round 3, on your instruction; see 9.6.
- Update trust: `UpdateTrust.cs` still contains the placeholder, so every update is refused (fail closed) until the public key printed by `tools\New-UpdateKey.ps1` is pasted in. The private key stays on the developer machine.

## 6. Findings in existing code (reported, not changed)

- `GameNet.Server/docker-compose.yml`: a literal `POSTGRES_PASSWORD`.
- `GameNet.Client/ClientOptions.cs`: default `ServerClientPassword = "HANDYCAFE"` is compiled into the kiosk program.
- `GameNet.Server/Core/OperatorManager.cs` and `UserManager.cs`: default admin accounts with password `password`. The audit-log text names that password. Changing that text needs approval.
- `GameNet.Server/Core/TlsWrapper.cs`: `GenerateSelfSigned` defaults to password `gamenet`.

## 7. Verification (static only)

- Bracket balance: 184 of 184 `.cs` files OK (`review/cs_balance_check_selfrepair.py`; parentheses, square and curly brackets, with comments and string literals skipped).
- Codes: 32 codes used in code, 32 defined in the catalogue. No undefined code, no unused definition.
- Added lines were scanned for C# 8+ and net472-incompatible syntax and APIs. Matches were reviewed by hand; they were comments, `StringAssert`, or `HashSet.Contains`, which are valid.
- Protected strings compared against the original tree: identical.
- Secret scan of the tree: no private key, database, password file, `options.json`, or build output. `UpdateTrust.cs` holds only the placeholder.

Not verified: compilation, NUnit results, runtime behaviour on a real network, UI layout, and the existing 105 tests in `AllTests.cs`.

## 8. Build and test on Windows

1. Open `GameNet.sln` in Visual Studio 2019 or 2022 with the .NET Framework 4.7.2 targeting pack.
2. Restore NuGet packages: Newtonsoft.Json 13.0.3 (Shared); NUnit 3.14.0, NUnit3TestAdapter 4.5.0, System.Data.SQLite.Core 1.0.118 (tests).
3. Build, then Rebuild Solution. Expect 0 errors. Read the warnings for the new files and for `ClientEngine.cs` and `ClientCommunicator.cs`.
4. Test Explorer, Run All. Expect the 28 `DiagnosticsTests` and the 105 `AllTests` to pass. If an existing test starts the communicator, note that `Start()` now retries instead of throwing.
5. Scenarios on a test server and a kiosk:
   - a. Stop the server. The kiosk shows NET-001 and retries at growing intervals.
   - b. Start the server. The kiosk reconnects and shows NET-900.
   - c. Start a second server on the same port: SRV-003 toast. Close the first server: the second binds by itself (SRV-900).
   - d. Set a station password on the server and a wrong one on the kiosk: station notice, then NET-008 about 2 s later; the server shows AUTH-003.
   - e. Write junk into `server_settings.txt`: CFG-001 and a renamed `*.damaged-*` file.
   - f. Kill `GameNet.Client.exe`: the `GameNetClientWatchdog` task restarts it within 60 s (if installed).
   - g. Run `GameNet.Client.exe --diagnose`: the viewer opens.
   - h. Open `diagnostics.log` next to the exe: one JSON record per line.
6. Server: Tools menu, "عیب‌یابی و گزارش خطاها".

## 9. Round 2: kiosk dialogs and settings push

Reported on the kiosk and the server: settings applied in the server do not take
effect; the kiosk is still not listed on the server; the kiosk settings menu is not
shown, or the desktop is shown when it is opened.

**Status: not compiled and not run.** Checked by reading the code and with the balance
checker (section 7 method) only.

### 9.1 Findings

| # | Symptom | Cause found in code | Status |
|---|---|---|---|
| 1 | Kiosk not listed, no settings | Rate limiter. `ProcessMessage` keys each message by `ClientInfo.ClientIp`. Before ClientHello, `ClientInfo` is null, so every pre-hello message from every kiosk shares the key `anonymous` in `RateLimiter.CheckLimit`: 30 per minute for all kiosks together. When that is exceeded, the shared key is blocked for 15 minutes. A dropped hello gets no ServerWelcome, so the kiosk reaches NET-005 after 30 s, reconnects, and the cycle repeats. The server monitor shows such sockets as "(در حال اتصال...)". | **Changed in round 3** (9.3, 9.6), on your instruction. Its trade-off needs your confirmation. |
| 2 | Settings do not take effect | `ServerConfigSync` was sent only inside `HandleHello`. A later change never reached a connected kiosk, and a kiosk that was never welcomed (row 1) never received the settings at all. | Changed (9.2). |
| 3 | Kiosk settings menu not shown; desktop shown | The desktop button (`btnNavHome`) minimizes the kiosk window. Every kiosk dialog (F3 settings, the offline maintenance menu and its settings button, food order, time warning, screensaver, and 24 `MessageBox.Show(this, ...)` calls) was owned by that window. A dialog owned by a minimized window is not shown, and a hidden modal also blocks the kiosk UI thread. The mechanism is inferred from the code; it is to be confirmed with the test in 9.4. | Changed (9.2). |

### 9.2 Changed files

- `GameNet.Client/KioskForm.cs`
  - `ShowKioskDialog(Form)`: shows the dialog owned by the kiosk while the kiosk is visible (unchanged behaviour). While it is minimized, shows the dialog as a topmost, centred, top-level window. Used by the food order, the time warning, F3 settings (`OpenClientOptions`), the offline maintenance menu and its settings button.
  - `DialogOwner()`: owner for the 24 message boxes that used `this`. The kiosk while it is visible; no owner while it is minimized.
  - The screensaver does not start while the kiosk is minimized.
- `GameNet.Server/Core/ClientCommunicator.cs`
  - `BuildConfigSyncPayload()`: the one place that builds the settings payload. It was inline in `HandleHello`; the content is unchanged.
  - `StartConfigPushTimer()` (called from `Start`, disposed in `Stop`) and `PushConfigIfChanged()` every 30 s: send `ServerConfigSync` to each station with `ClientInfo != null` (set only after the hello checks pass) when the payload differs from the last one sent. `ConfigSignature()` is the comparison key.

Behaviour changes to review:

1. A settings change reaches connected, welcomed kiosks within 30 seconds (before: only at their next connect).
2. While a kiosk is minimized, its dialogs appear centred on screen (before: not visible, and the UI thread blocked until restored). Message boxes have no owner in that state, so Windows may show them in the taskbar rather than in front.
3. The screensaver does not start while the kiosk is minimized.

Unchanged, as required: TLS, pins, certificates, ACL, integrity and station-password checks; every message text, including the protected H3/P5 strings and the "— using plaintext" line; every rate-limit value. The keying of pre-hello messages changed in round 3 (see 9.6).

### 9.3 Proposal (applied in round 3, see 9.6)

Key the pre-hello messages by the remote address. In `ClientCommunicator.ProcessMessage`:

```csharp
// current
var clientIp = conn.ClientInfo?.ClientIp ?? "";
// proposed
var clientIp = conn.ClientInfo?.ClientIp ?? ClientIpOf(conn);
```

Effect: each kiosk's hellos are counted under its own address, so one kiosk's reconnect
storm can no longer lock out every other kiosk for 15 minutes. The limits (30 per minute,
500 per hour, 15-minute block) are unchanged. It was applied on your instruction to carry out the proposal. The trade-off
in 9.6 was not part of this proposal; it is set out there for your confirmation.

### 9.4 How to confirm finding 1 (no code change needed)

- Server, Tools → عیب‌یابی و گزارش خطاها: SRV-004 entries with kiosk addresses, and the
  audit-log line "Rate limit exceeded (minute) for anonymous" means finding 1 is active on a build before round 3. From round 3 the same line names the kiosk's address (9.6).
- Kiosk, `diagnostics.log`: repeated NET-005 ("no ServerWelcome in 30 s") means the hello
  is not being answered.
- Desktop test on a kiosk: click the desktop button, then press F3. Before this round:
  no settings window. After: the window appears above the desktop.

Notices such as "دسترسی کیوسک" or the AUTH-001..003 refusals are a different cause; the
kiosk shows them, and the diagnostics list records them.

### 9.5 Verification

- Balance checker: both changed files OK, re-run in round 3 after the comment fix in ClientCommunicator.cs.
- Names used by the round-2 and round-3 code were checked against their declarations: the OptionsData members in OptionsForm.cs, Protocol.HeartbeatIntervalSeconds (const int), Protocol.ServerVersion (const string), the ConfigSyncPayload fields, and ClientIp (the same address that ClientIpOf returns). The new code uses no LINQ and no System.Text, so the using lists need no change.
- Added lines scanned for C# 8+ syntax and net472-incompatible APIs: none found.
- Not verified: compilation, runtime behaviour, the 30-second push on a live network, and
  the new dialog placement on a real screen.

### 9.6 Round 3: pre-hello rate-limit key (applied on your instruction; trade-off to confirm)

**What changed.** One line in `ClientCommunicator.ProcessMessage`, with a four-line comment above it:

```csharp
// before round 3
var clientIp = conn.ClientInfo?.ClientIp ?? "";
// round 3
var clientIp = conn.ClientInfo?.ClientIp ?? ClientIpOf(conn);
```

`ClientIpOf` returns the remote IP address without the port. It is the same value that
`ClientInfo.ClientIp` holds after the hello, so a station is counted under its own address
from its first message, and the same budget carries on into the hello. The limits (30 per
minute, 500 per hour, 15-minute block) are unchanged, and so is the fallback to `anonymous`
for an empty address. Messages after the hello were already keyed by address and are unchanged.

**Effect.** With 40 kiosks starting together (scenario 1 below), all 40 are welcomed at 1 s.
Before, 30 were welcomed at once and the rest only at about 902 s. A station whose hellos
keep failing no longer blocks the others (scenario 3).

**Trade-off, not stated in the original proposal.** The shared `anonymous` budget was also
the only overall limit on traffic from stations that have not said hello. With per-address
keying there is no overall limit:

- One address is still limited to 30 messages a minute, 500 an hour, and a 15-minute block.
- The total allowed before hello now grows with the number of distinct source addresses.
  If a host controlled 400 addresses it could send up to about 12,000 pre-hello messages a minute.

A TCP connection needs a real source address, so this requires a host that controls many
addresses. On a café LAN the risk is small. If the server's port can be reached from outside
the LAN, option B below is the better choice.

**Option B (NOT applied; needs approval of its numbers).** Keep the per-address budget and add
a shared pre-hello budget of 300 messages a minute and 5,000 an hour, with a 1-minute block.
Scenario 2 shows that this restores an overall ceiling, but a flood from 300 or more addresses
also blocks new kiosks for one minute.

**Revert (round 3 only).** Change the line back to `var clientIp = conn.ClientInfo?.ClientIp ?? "";`
and delete the four comment lines above it. Nothing else in round 3 needs reverting.

#### 9.6.1 Simulation

`tools/ratelimit_sim.py` is a line-by-line Python port of `RateLimiter.CheckLimit`, with the three
keying choices. It checks the policy only; it does not run the C# code. Output of the run for this round:

```
== Scenario 1: 40 kiosks start together ==
config  welcomed<=1s  welcomed<=60s  welcomed<=1000s  welcomed<=1h  all welcomed at
current 30            30             40               40            902 s
A       40            40             40               40            1 s
B       40            40             40               40            1 s

== Scenario 2: 400 addresses flood one minute, then kiosks try ==
config  flood messages allowed  kiosk at 61 s  kiosk at 1000 s
current 30                      BLOCKED        allowed
A       400                     allowed        allowed
B       300                     BLOCKED        allowed

== Scenario 3: one failing kiosk sends 40 hellos in a minute ==
config  its messages allowed  healthy kiosk at 61 s
current 30                    BLOCKED
A       30                    allowed
B       30                    allowed
```

Scenario 2 counts 400 addresses that each send one message within one minute. "A" is the change
applied in round 3; "B" is option B above; "current" is the code before round 3.

## 10. Round 4: PRO tabs and "client not shown" (code review, two small fixes)

Scope: static review of the source plus three small code changes. No compiler, no runtime test,
and no access to the operator's database or machines. Line numbers refer to the tree in this round.

### 10.1 Changed in round 4

- `GameNet.Server/Forms/MainForm.cs`
  - Primary toolbar buttons call `OpenModuleByKey(key)`, the same path the menus use. Before, the
    button only selected the tab. When that tab was already selected there is no
    `SelectedIndexChanged`, so `EnsureTabContent` never ran and a module refused before login kept
    its lock message until another tab was selected.
  - `CreateFormForKey`: `"livedash"` passes `_communicator` to `LiveDashboardForm`.
- `GameNet.Server/Forms/LiveDashboardForm.cs` (rewritten): rows come from
  `ClientCommunicator.GetAllRawConnections()` (welcomed stations only), refreshed every 3 s.
  Before, the form created columns and never added rows. Column headers are unchanged.
- `GameNet.Server/Forms/TournamentProForm.cs` (rewritten): rows come from
  `TournamentManager.GetAllTournaments()` with `CountParticipants`. "Add" opens `TournamentForm`
  (it was a placeholder message box). Two columns were added (Game, Start); the original headers
  are unchanged.

Not changed in round 4: TLS default, pin behaviour, certificate handling, the rate limit (the
round-3 keying is still pending your approval, see 9.6), protocol message text, the signing key,
and the kiosk.

### 10.2 Findings (not changed; need a decision or evidence)

- F10.1 With TLS on and no certificate loaded, the server closes every connection before it is
  published (`ClientCommunicator.HandleClient`, lines 348-355). `TlsWrapper.LoadCertificate` opens
  `server.pfx` with an empty password (`ClientCommunicator` line 124) and resolves the path against
  the process working directory, not `AppDomain.BaseDirectory`.
- F10.2 The kiosk Options screen's server IP (`ClientOptionsForm` line 913) is saved only to
  `client_options.json`. The engine uses `_serverHost`, which comes from `ConnectionSettings` (DPAPI
  file, read in `Program.cs`). So the Options IP does not change the connection.
- F10.3 The `KioskForm` constructor overwrites `ConnectionSettings.ServerHost` with
  `ClientOptions.ServerHost` (default 127.0.0.1), lines 120-121. `SpeedTestPanel` pings
  `ConnectionSettings.ServerHost` (`ClientExtras.cs` line 290), so its result can describe loopback.
- F10.4 UDP discovery is one-sided. The kiosk sends `GAME_NET_DISCOVERY` (`KioskForm` 2027-2031),
  but no server code listens for it, so the kiosk waits 2 s on every start with the default host.
  Even a reply would only change the two settings objects, not the engine host (`SetupEngine`, line 701).
- F10.5 `UseTls` is assigned after `_communicator.Start()` (`MainForm` 306 vs 378). A connection in
  that window uses the class default (true).
- F10.6 The server's Client Options TLS checkbox writes `client_options.json` (`ClientOptionsForm`
  418, 728, 753); nothing reads that value for TLS.
- F10.7 `ConnectionSettings.ReadDecryptedOrPlain` falls back to plain text when DPAPI decryption
  fails (for example a different Windows user). The host then falls back to 127.0.0.1 with no log line.
- F10.8 `NetworkAccessControl.IsAllowed` is open only while there is no whitelist entry and no CIDR.
  Once one entry exists, every unlisted kiosk is refused (`HandleHello` 488-496, AUTH-001). The UI gives no warning.
- F10.9 The built-in admin receives `FullAccess` only when the operators table is empty
  (`OperatorManager` 303-307). No migration adds bits introduced later. `RestApiServer` line 318
  requires `ApiAccess` for the mobile API.
- F10.10 The station password default `HANDYCAFE` is compiled into the kiosk (`ClientOptions` 146).
  It is enforced only when the server password is set (`HandleHello` 559-586).
- F10.11 The toolbar button "⚡ پرو" uses key `staff` and opens personnel management (`MainForm` 1249).
- F10.12 `AIPriceOptimizer` is a fixed table (`basePrice = 15000`, fixed multipliers), not a model.
- F10.13 Correction to 9.x: a rate-limited message is dropped (`ClientCommunicator` 408-413), but the
  socket stays connected and visible. The rate limit cannot by itself hide a kiosk from the monitor.
  (Round 5 correction, see 11.3: before round 5 a socket without a completed hello was not listed;
  it made `GetAllRawConnections` throw, so the list was empty for every station.)

### 10.3 Proposals (not applied; need your approval)

- P10.1 Certificate: resolve `server.pfx` and `server_cert.pem` under `AppDomain.BaseDirectory`; warn
  when the PFX is password-protected; never regenerate a certificate that kiosks pin without a warning.
  (Certificate handling: approval required.)
- P10.2 Kiosk host: one source of truth. The Options IP must update `ConnectionSettings` and be saved,
  but only when the operator changed it and it is not the default 127.0.0.1. A naive save would break
  a working kiosk. Use the same host for the engine, the ping and discovery. (Connection behaviour.)
- P10.3 UDP discovery: either add a responder on the server (a new UDP listener) or remove the feature.
- P10.4 Move the `UseTls` assignment before `Start()`. (TLS configuration: approval required.)
- P10.5 Wire or remove the server Client Options TLS checkbox. (TLS configuration: approval required.)
- P10.6 Default station password: empty default and a setup prompt instead of the compiled-in `HANDYCAFE`.
- P10.7 Warning in the security dashboard when a whitelist or CIDR filter would refuse connected kiosks.
- P10.8 Permission migration: add missing bits to the built-in admin only, after explicit approval.
- P10.9 Toolbar "⚡ پرو": rename it, or open a real PRO hub.
- P10.10 Log a warning when DPAPI decryption of `server_settings.txt` fails.

### 10.4 Static verification

- Bracket balance: `LiveDashboardForm.cs`, `TournamentProForm.cs` and `MainForm.cs` are balanced.
  MainForm lost one lambda (3 brace pairs and 3 parenthesis pairs) and gained one call, as expected.
- Names checked against their definitions: `ClientCommunicator.GetAllRawConnections` (tuple fields
  StationName, User, State, Minutes, Cost, Cpu, Ram), `TournamentManager.GetAllTournaments`,
  `CountParticipants`, the `TournamentInfo` fields, the `TournamentForm()` constructor,
  `ThemeManager.ThemedAccent`, `GameNet.Shared.ClientState.Disconnected`.
- No C# 8+ syntax (target C# 7.3, .NET Framework 4.7.2).
- Not verified: compilation (no compiler here, and the package index is unreachable from this
  sandbox), WinForms layout, and runtime behaviour.

## 11. Round 5: three fixes ported from the other source line

Origin: `markazbazi-src` (uploaded 2026-10-22; newest file 2026-10-12; its own `CHANGES.md`,
sections 1, 9 and 10). It is a separate line of development from the same original
(`markazbazi-source-v5-fixed_10`, newest file 2026-09-23), not a later copy of this tree:
188 shared files, 83 identical, 104 different in content, 12 files only on each side, and none
of rounds 1-4 is in it. Each fix below was first located in this tree and checked line by line.
Line numbers refer to this tree after the change.

### 11.1 Changed

- `GameNet.Server/Core/ClientCommunicator.cs`, `GetAllRawConnections` (lines 118-119, comment
  110-117). Before: `info?.SessionStart != default(DateTime) ? info.SessionStart : (info?.ConnectedAt
  != default(DateTime) ? info.ConnectedAt : c.LastHeartbeat)`. When `info` (`ClientInfo`) is null the
  lifted comparison is `null != MinValue`, which is true, so `info.SessionStart` threw
  `NullReferenceException`. While any connection without `ClientInfo` was open (after TLS and before a
  successful hello, or after a rejected `ClientReconnect`, see the third item), every caller got an
  exception instead of a list: the client monitor, the live dashboard (round 4 shows the error text in
  its grid) and the REST API. After: both branches test `info != null` first.
- `GameNet.Server/Forms/MainForm.cs`, `EnsureTabContent` (line 2845):
  `form.WindowState = FormWindowState.Normal;` right after `form.TopLevel = false;`.
  `ClientMonitorForm` sets `WindowState = Maximized` in its constructor (`ClientMonitorForm.cs` line 65).
  The other line reports from a live run that the embedded form then stayed `Visible = false` and
  screen-sized, so the clients tab looked empty. Not reproduced here (no Windows runtime); this tree
  has the same pattern, and `EnsureTabContent` is the only place that sets `TopLevel = false`.
- `GameNet.Client/ClientEngine.cs`:
  - New `SendClientHello()` (line 758). The ClientHello statement moved out of `TryConnect` unchanged
    (checked: the 31 lines are identical apart from indentation), so both callers send the same
    registration data, including the selected MAC, the self-hash and the station password.
    `TryConnect` calls it at line 659.
  - `Dispatch(ServerLoginFail)`, branch `!_welcomed && _resumeSent` (line 979), a rejected resume.
    Before: the branch stopped the welcome watchdog, set `_welcomed = true` and kept
    `_lastSessionId`. The station never sent ClientHello again, so the server never created its
    `ClientInfo` and it was not in the monitor; every later reconnect was another `ClientReconnect`
    that `HandleReconnect` rejected the same way (lines 910-932). Only restarting the kiosk program
    ended it, because `_lastSessionId` lives in memory only. Trigger: the server program restarted
    while kiosks stayed on, or a kiosk was offline for more than 180 s (line 926).
    After: `_lastSessionId`, `_sessionId` and `_sessionStart` are cleared, `_resumeSent` is cleared,
    the welcome watchdog is re-armed and `SendClientHello()` runs on the same link (line 1007). The
    server runs the normal hello path (ACL, integrity, station password) and answers with
    `ServerWelcome`, which takes the fresh-connect branch (OnConnected, retry state cleared, NET-900
    when retries were needed). A refusal of that hello goes to the existing `!_welcomed` branch as a
    station refusal. Clearing `_sessionId` stops `OnNetDisconnected` from copying the old id back into
    `_lastSessionId` if the link drops before that welcome. The kiosk still shows the server's message
    through `OnLoginResult`, as before (message text unchanged).
  - The `TryConnect` comment now says that this server answers a rejected resume with
    `ServerLoginFail`, not with a `ServerWelcome` carrying a new id.

### 11.2 Not ported, and why

- The other line also sends a `ServerWelcome` with the new connection id in each reject branch of
  `HandleReconnect`. With this tree's client that second message would arrive before the hello is
  answered: `_welcomed` would become true early, OnConnected would fire twice, and a refusal of the
  hello would be shown as a failed user login instead of a station refusal. The client-side change
  above registers the station without it. Consequence: fix 3 needs the new kiosk build; a server-only
  update does not end the loop on old kiosks. Workaround for an old kiosk: restart the kiosk program
  after the server restarts.
- Available later, one at a time, on request: the server UDP discovery responder
  (`MARKAZBAZI_DISCOVER` / `MARKAZBAZI_HERE`, related to P10.3), the two-tab client monitor, the full
  TournamentPro form (create, delete, auto-refresh), the new icons, the integration test harness.
  Not recommended as is: the kiosk maintenance menu (`MaintenanceAuth.cs` sets the first-run password
  `password`, finding SEC-01 in that line's own audit).
- Unchanged in round 5: TLS default, pin behaviour, certificate handling, protocol and kiosk message
  text, the rate limit (round 3 still waits for your decision, 9.6), the signing key.

### 11.3 Corrections to earlier statements

- 10.2 F10.13 and the round-4 report (4.1, row 10 of 4.2, section 9 items 1-2) said that a socket that
  has finished TLS but not the hello is listed as "(در حال اتصال...)". Before round 5 that was wrong:
  the line fixed in 11.1 threw for exactly that socket, so the whole list was empty. It is right from
  round 5 on. For the same reason a rate-limited or stuck pre-hello socket could hide every kiosk.
- The round-4 review missed the reconnect dead-loop (11.1, `ClientEngine`).

### 11.4 Static verification

- Bracket balance: `ClientEngine.cs` 418/418 braces and 834/834 parentheses (one new method);
  `ClientCommunicator.cs` (496/496, 1174/1174) and `MainForm.cs` (554/554, 1671/1671) keep their counts.
- Names checked against their declarations: `_sessionId` and `_lastSessionId` (string fields, line 76),
  `_sessionStart` (`DateTime?`, line 78), `_resumeSent`, `_welcomed`, `StartWelcomeWatchdog`,
  `WelcomeTimeoutSeconds` (30 s), `SendSafe`, `OnLoginResult`, `FormWindowState`. `SendClientHello` is
  declared once and called twice.
- The pattern `x?.Member != value ? x.Member` was searched for in every `.cs` file;
  `GetAllRawConnections` was the only place with it.
- No C# 8+ syntax. Not verified: compilation and runtime (no compiler in this sandbox).

### 11.5 How to test on Windows

1. Build both projects, then install the new server and the new kiosk on at least one station.
2. Fix 2: open the clients tab. The grid must be visible and fill the tab.
3. Fixes 3 and 1: with a kiosk connected, close and restart the server program and log in as operator.
   The kiosk shows the server's message once ("نشست معتبر نیست. لطفاً دوباره وارد شوید") and then
   appears in the clients tab without restarting the kiosk program.
4. Fix 1 alone: leave one kiosk on the old build, restart the server. The other kiosks must stay in the
   list, and the old one is listed as "(در حال اتصال...)" instead of emptying the list.

## 12. Round 6: right-column switches in the kiosk Options dialog

Request: turn each item of the kiosk's right column on or off from the kiosk's own menu, and bring
back the features that had no button since the original v5 source (chat, announcements, loyalty,
profile, stats, balance, food order, music). Kiosk only; the server is unchanged.

### 12.1 Changed

- `GameNet.Client/ClientOptions.cs`: 19 new `public static bool` fields, default false = shown:
  HideIpAddress, HidePricePerHour, HideBalance, HideLoyaltyPoints, HideBtnAdd10, HideBtnAdd30,
  HideBtnAdd60, HideBtnEndSession, HideBtnScreenshot, HideBtnMessage, HideBtnChat,
  HideBtnAnnouncements, HideBtnLoyalty, HideBtnProfile, HideBtnStats, HideBtnFood, HideBtnMusic,
  HideBtnOptions, HideBtnExit. Load and Save already handle every public static field by reflection,
  so `client_options.json` needs nothing else, and a file without these keys shows every item.
- `GameNet.Client/ClientOptionsForm.cs`: new third tab "ستون راست" with 25 check boxes, checked =
  shown: 8 info rows (IP, price per hour, start, remaining, used, cost, balance, loyalty points) and
  17 buttons in column order. Six are existing settings (Disable Hide, Disable Cafeteria, Hide
  Start/Remaining/Used Time, Hide Cost). Their box on the Options tab and the new box are kept
  opposite each other in both directions (`_syncingTwins` stops the echo), so OnOk writes one value.
  A note on the tab covers the server switches, the ⚙️ button and when changes apply.
- `GameNet.Client/KioskForm.cs`:
  - `LayoutSessionControls`: the info panel has 8 rows (balance and loyalty points added). The rows
    that are on are stacked from the top, and the panel height follows. The grid holds up to 17
    buttons: the 10 existing ones (labels unchanged, copied from the old code), 7 restored features
    (🗨️ چت, 📢 اطلاعیه‌ها, 🏆 امتیازات, 👤 پروفایل, 📊 آمار, 🍔 سفارش غذا, 🎵 موسیقی), then
    ⚙️ تنظیمات and ⏻ خروج last. Only visible buttons are placed; an odd last button spans both
    columns; the cell height shrinks from 40 to 28 px when the column is short. The grid start uses
    the computed row count, not `_sidebarTimer.Visible`, which reads false while pnlSession is hidden.
  - The restored features open in their own window (`ShowFeatureWindow`: up to 880 x 630 px, or the
    screen minus 40 px, with scroll bars when needed, shown through `ShowKioskDialog`). Closing it
    disposes the panel, which unsubscribes its engine events (the panels already do this in Dispose).
  - Food order and music: the existing handlers are kept in `_foodOrderHandler` and
    `_musicToggleHandler` and still attached to btnFood and btnMusic. The column buttons call them at
    click time, so construction order does not matter. The music button copies btnMusic's play/stop
    text after each toggle and is hidden in low-performance mode, like btnMusic.
  - Balance row: `_engine.Balance` (set at login and on each credit, the value the old balance label
    showed). Points row: the last `OnTierInfo` value.
  - Server feature switches (ConfigSync `feat_*`) are stored by name in `_serverFeatureOn` and applied
    to the item with the same meaning: chat, announcements, loyalty (button and points row), profile,
    stats, topup (➕ اعتبار), food, ambient_music (🎵) and settings (⚙️ تنظیمات). Before, they were
    wired to the repurposed buttons by their old names: games hid "+10 min", chat "+30 min",
    announcements "+60 min", loyalty "end session", profile "screenshot", stats "message", settings
    the exit button, and topup was overwritten by DisableCafeteria. "games" has no item any more. An
    item is shown when its Options switch is on and its server switch is not off; a missing key
    counts as on, as before.
  - F4-F9 open their screen through `ShowFeatureWindow` instead of `SwapToPanel`, which sized it to
    `pnlSession.Width - 230`, about 50 px in the 280 px column. F4 (announcements), F5 (top-up) and
    F6 (profile) do nothing when the matching item is switched off. `SwapToPanel` is no longer called.
  - `_showGames` and `_showSettings` removed.

### 12.2 Not changed; needs your decision

- The Options dialog has no password. The ⚙️ تنظیمات button and F3 open it directly, and F3 works
  during a customer session (KeyPreview is on), so a customer can change these switches too. Hiding
  the ⚙️ button is possible from the new tab; F3 still works. Proposal: ask for the offline admin
  password (`ClientOptions.VerifySuperAdmin`) before opening the dialog from the column or F3, as the
  maintenance menu already does. Not applied: it changes how operators reach the menu.
  Applied in round 7 as part of admin mode (13.1).
- The server's feature list still shows switches that do nothing on the kiosk (games, ticket, pause,
  history, leaderboard, volume, guest, night_mode, and the Phase-14 ones except UPS, screensaver and
  splash). Not changed.
- Unchanged: the ten existing button labels, all message text, TLS, pin, certificates, rate limit.

### 12.3 Static verification

- Bracket balance: KioskForm.cs 413/413 braces and 877/877 parentheses; ClientOptionsForm.cs
  142/142 and 318/318; ClientOptions.cs keeps its counts.
- Names checked against their declarations: ChatPanel(ClientEngine), AnnouncementsPanel(ClientEngine),
  LoyaltyPanel(ClientEngine, string), ProfilePanel(ClientEngine, string, decimal),
  StatsPanel(string, decimal), TopupPanel(ClientEngine), HistoryPanel(ClientEngine), VolumePanel(),
  PausePanel(ClientEngine), ClientEngine.Balance (decimal) and Username, TierInfoPayload.CurrentPoints
  (int), ShowKioskDialog(Form), DialogOwner, AmbientMusic. Only the two lines at the top of
  LayoutSessionControls also set these buttons' visibility; the grid then sets the same values plus
  the server switch.
- The KioskForm edits were applied by a script that stops unless every anchor occurs exactly once;
  the ten existing button labels were copied from the old block, not retyped.
- C# 7.3: target-typed tuple literals with null elements, lambdas as Func/Action; no C# 8 features.
- Not verified: compilation, runtime layout on Windows, DPI scaling.

### 12.4 How to test on Windows

1. Log in at a kiosk: the right column shows 8 rows and 17 buttons (on a 768-px-high screen the
   buttons are slightly shorter).
2. ⚙️ تنظیمات, tab "ستون راست": untick a few items and press OK. They disappear and the rest close
   up. Tick them again and they return. The Options tab's matching boxes follow.
3. 🗨️ چت, 📢 اطلاعیه‌ها, 🏆 امتیازات, 👤 پروفایل, 📊 آمار each open a window; close it with X.
4. 🍔 سفارش غذا opens the food order dialog; 🎵 موسیقی toggles music (needs a .wav file in the
   `music` folder next to the exe).
5. On the server, feature list: switch off "💬 چت با اپراتور". Within 30 s only the kiosk's 🗨️ چت
   button disappears. Switch it back on.

## 13. Round 7: admin mode in the right column (replaces the maintenance dialog)

Request: after the offline admin login (admin and its password on the kiosk's login screen), show an
admin right column with its settings instead of the two-option dialog "حالت نگهداری (دسترسی محلی)".
Kiosk only; the server is unchanged.

### 13.1 Changed

- `GameNet.Client/KioskForm.cs`:
  - `btnLogin_Click`: a successful `ClientOptions.VerifySuperAdmin` calls `EnterAdminMode` instead of
    `OpenMaintenanceMenu`. `OpenMaintenanceMenu` is removed.
  - `EnterAdminMode`: `_adminMode = true`, `_isLocked = false`, clears the login boxes (the typed
    admin password used to stay in them behind the old dialog), writes "Admin mode started" to the
    activity log, shows the 280 px column (`ShowSessionPanel`) and starts the idle check.
  - The admin column (`LayoutSessionControls` and the new `LayoutAdminControls`): orange header
    "🛠️ حالت مدیر" and orange footer; only the IP row; a status line that repeats the login screen's
    connection status (`lblStatus`, kept in step through its TextChanged event); four full-width
    buttons: ⚙️ تنظیمات کلاینت (`OpenClientOptions`, no password), 🖥️ دسکتاپ (کوچک کردن ستون)
    (minimizes; the taskbar icon brings it back), 🔒 قفل و بازگشت به صفحه ورود (`LeaveAdminMode`),
    🚪 خروج کامل از کیوسک (`ExitKioskFromAdmin`); and a note on the idle lock. Every customer row and
    button is hidden in admin mode; leaving it restores the normal column.
  - `ExitKioskFromAdmin`: the exit steps of the old dialog, unchanged: the same confirmation (the call
    was moved by the edit script, not retyped), `SecurityLock.RestoreAll`, the same activity-log text
    ("Kiosk unlocked via offline maintenance login."), `Application.Exit`. New: it does nothing if
    admin mode ended while the question was open.
  - Leaving admin mode: the lock button, F1, the idle lock, or anything that shows the login screen
    (server lock, `ShowLoginPanel`) returns to the locked login screen. If a customer session is
    running (admin mode reached through F1 during a session), the lock button and the idle lock return
    to the customer column instead. A customer login result ends admin mode. Leaving closes the
    settings dialog if it is open (unsaved changes are dropped) and writes "Admin mode ended: reason".
  - Idle lock: checked every 15 s. After `ClientOptions.AdminIdleLockMinutes` (default 10, 0 = never)
    without keyboard or mouse input anywhere on the PC (`SystemMonitor.GetIdleSeconds`, the value the
    heartbeat already reports), admin mode ends. An open settings dialog is closed first and the lock
    follows on the next check.
  - `KioskForm_FormClosing`: in admin mode a close message is cancelled. The exit button uses
    `Application.Exit`, which the handler already allows.
  - ⚙️ تنظیمات in the customer column, and F3: in admin mode they open the settings directly;
    otherwise they first ask for the admin username and password (`AskAdminCredentials`, checked with
    `VerifySuperAdmin`). Before, both opened the settings without a password, also for a customer
    during a session (12.2).
  - F2: works only during a session or in admin mode. On the locked login screen it called
    `ShowSessionPanel`, which shrinks the kiosk to the 280 px column and leaves the desktop usable
    beside it, without any login. Present since the original v5 source.
  - F10: works only during a customer session. On the locked login screen it ran `btnLogout_Click`,
    which closes the kiosk and restores Windows (unless DisableLogout is on), without any login.
    Present since the original v5 source. During a session it behaves as before.
  - `OpenClientOptions`: the dialog opens centred on the screen; from the 280 px column, CenterParent
    pushed it against the right edge. While open it is kept in `_openSettingsDialog`.
  - `OnFormClosed` disposes the idle timer.
- `GameNet.Client/Watchdog.cs`: new `public static volatile bool SuspendFocusSteal`, set by
  `EnterAdminMode` and cleared by `ClearAdminMode`. While it is set, the 3-second check does not pull
  focus back to the kiosk. Without this, cmd, PowerShell and regedit lost focus every 3 s in admin
  mode. The autostart check and the keyboard-hook check still run.
- `GameNet.Client/ClientOptions.cs`: `public static int AdminIdleLockMinutes = 10;`. Saved and loaded
  by the existing reflection code; not on the Options dialog (edit `client_options.json`).

### 13.2 Unchanged

- Windows locks stay on in admin mode: Task Manager disabled by policy, and the keyboard hook (Win
  key, Alt+Tab, Ctrl+Esc, Ctrl+Shift+Esc). The full exit releases them, as before.
- The ⏻ خروج button of the customer column: unchanged. It logs out and closes the kiosk without a
  password, as in v5.
- Server, TLS, pin, certificates, rate limit, protocol messages and existing texts. New texts only on
  the new controls.

### 13.3 Findings (not changed; need your decision)

- Every normal close of the kiosk (customer ⏻ خروج, F10 during a session, admin full exit) runs
  `AutoStartup.Uninstall` in the `finally` block of `Program.Main`. That removes the Run keys (HKLM and
  HKCU), the scheduled task `GameNetClientWatchdog` and `gamenet_watchdog.bat`. The kiosk then does not
  start at the next Windows logon until it is started once by hand (`Install` runs at every start).
  Not verified: whether the same happens at a Windows shutdown, which depends on whether the `finally`
  block runs before the process is ended. Proposal: remove autostart only on an explicit uninstall
  (for example a `--uninstall` argument), not on every exit.
- The ⏻ خروج button closes the kiosk program and leaves Windows unlocked. For a game cafe a customer's
  logout should probably end the session and return to the login screen. Proposal only.
- `client_options.json` lives in `%APPDATA%\GameNet` of the Windows user the kiosk runs as, and
  `ClientOptions.Load` applies every public static field it finds there, including
  `SuperAdminUsername` and `SuperAdminPasswordHash` (default admin / SHA-256 of "password"). A
  customer with desktop access during a session can edit the file and so change the admin password
  or any setting, which also bypasses the new password prompt in front of the settings dialog.
  Proposal: keep the file (or at least the admin hash) where the kiosk user can only read it, for
  example ProgramData with a restrictive ACL written by an elevated step, and add a field to change
  the admin password in the settings dialog.

### 13.4 Static verification

- Bracket balance: KioskForm.cs 475/475 braces, 982/982 parentheses, 50/50 brackets; Watchdog.cs
  30/30, 47/47; ClientOptions.cs 27/27, 79/79.
- Each of the 13 new methods is declared once; every new field is declared once and used. Checked
  against their declarations: `SystemMonitor.GetIdleSeconds()` (public static int),
  `LocalNetworkInfo.GetLocalIp()`, `ActivityLogger.Log(string, string)`, `ResetLoginFields()` (public,
  KioskForm.Designer.cs), `SecurityLock.RestoreAll()`, `ClientEngine.State`, `ClientState.InSession`,
  `Watchdog` (public static class), `Label.PreferredWidth`.
- The KioskForm edits were applied by a script that stops unless every anchor occurs exactly once.
- C# 7.3: added lines scanned for `using var`, `??=`, switch expressions, ranges, `is not` and
  target-typed `new()`; none used.
- `OpenMaintenanceMenu` has no remaining caller.
- No C# compiler or parser is available in this environment (the package index is not reachable), so
  compilation and runtime behaviour on Windows are not verified.

### 13.5 How to test on Windows

1. Login screen: admin and its password. The right column shows the orange header "🛠️ حالت مدیر",
   the IP, the connection status and four buttons, with the desktop beside it. No dialog appears.
2. ⚙️ تنظیمات کلاینت: the settings dialog opens centred; OK applies as before.
3. Open cmd beside the column and type in it for 10 seconds: it keeps the focus.
4. 🖥️ دسکتاپ: the column minimizes; the taskbar icon brings it back.
5. 🔒 قفل و بازگشت به صفحه ورود: locked login screen. Press F2 and F10: nothing happens.
6. 🚪 خروج کامل از کیوسک: the same confirmation as before; Yes closes the kiosk and Task Manager works
   again.
7. Idle lock: set `"AdminIdleLockMinutes": "1"` in `%APPDATA%\GameNet\client_options.json`, start the
   kiosk, log in as admin and touch nothing for about 75 s. The login screen comes back.
8. As a customer: ⚙️ تنظیمات and F3 ask for the admin username and password. A wrong password shows a
   message; the right one opens the settings.

## 14. Round 8: customer-page switches inside the admin column's settings

Request: every item of the customer column inside the admin column's "تنظیمات کلاینت", each with a tick
that decides whether customers see it.

These switches have existed since round 6 (12.1) on the third tab of the Options dialog, which the
admin column's ⚙️ تنظیمات کلاینت already opened. This round makes them easier to reach.

### 14.1 Changed

- `GameNet.Client/ClientOptionsForm.cs`:
  - The tab is renamed from "ستون راست" to "صفحهٔ مشتری". The admin column (round 7) is also on the right
    of the screen, so the old name was ambiguous.
  - Header label: "(تیک = نمایش در صفحهٔ مشتری)", narrowed to 395 px to make room for two new buttons,
    "تیک همه" and "برداشتن همه", which set all 25 boxes. The twin boxes on the Options tab follow
    through their existing CheckedChanged handlers.
  - Note lines 2 and 3 updated for round 7: in the customer column, ⚙️ and F3 ask for the admin
    password; the admin column opens the dialog without one.
  - New public method `ShowCustomerPageTab()`.
- `GameNet.Client/KioskForm.cs`: `OpenClientOptions(bool customerPageTab = false)`. The admin column's
  ⚙️ تنظیمات کلاینت passes true, so the dialog opens on "صفحهٔ مشتری". The customer column's ⚙️ and F3
  still open it on the first tab.

### 14.2 Unchanged

- The 25 items (8 info rows, 17 buttons), their order, the default (all shown), the ClientOptions
  fields and the keys in `client_options.json`. Changes still apply on OK.

### 14.3 Static verification

- Bracket balance: ClientOptionsForm.cs 147/147 braces, 332/332 parentheses; KioskForm.cs 475/475,
  984/984.
- The new lambdas' names (`s`, `e`, `c`) do not clash with locals of `BuildColumnTab`.
- The edit script matched the old texts exactly (ZWNJ and U+0654 written as escapes) and stops unless
  every anchor occurs once.
- Not compiled.

### 14.4 How to test on Windows

1. Admin login, then ⚙️ تنظیمات کلاینت: the dialog opens on "صفحهٔ مشتری".
2. "برداشتن همه", tick three or four items, OK. Lock, log in as a customer: only those items show.
3. Admin again, "تیک همه", OK: every item is back.
4. On the Options tab, "Disable Hide" and the other twins follow the boxes.

## 15. Round 9: no Uninstall button in the kiosk Options dialog

### 15.1 Changed

- `GameNet.Client/ClientOptionsForm.cs`: the "Uninstall Client" button at the left of the bottom bar is
  removed. It only showed a message (uninstall is done from the server console or Add/Remove
  Programs) and changed nothing. The bottom bar now holds the version label, Cancel and OK. The class
  and section comments say so.
- Unchanged: the server's Client Options form keeps its own "🗑️ حذف کلاینت" button. It writes one
  audit line and nothing else, although its confirmation says an uninstall order is sent to the
  stations. Not requested, so not changed.

### 15.2 Finding (not changed; needs your decision)

- General tab: "Admin Username" and "Admin Password" do not set the offline admin login, which is
  `SuperAdminUsername` / `SuperAdminPasswordHash` (default admin / password). They only pre-fill the
  login screen's boxes (`CenterLoginControls`, unless the username is "ADMIN"). At that moment the
  password box is in its placeholder state, where `UseSystemPasswordChar` is false (`SetPlaceholder`,
  `ResetLoginFields`), so the pre-filled password is shown in plain text. `ShowLoginPanel` clears the
  boxes right after its own call, but the two `Shown` handlers and later Resize events while the
  login screen is visible fill them again, so the pre-fill is visible after start-up. An operator who
  types the admin credentials here, expecting to change them, offers admin mode to anyone at the
  login screen. Proposal: make these three fields set the offline admin credentials (stored as a
  hash) and drop the pre-fill.

### 15.3 Static verification

- ClientOptionsForm.cs 146/146 braces, 328/328 parentheses; no remaining reference to `btnUninstall`.
- Docking of the bottom bar: OK (last added) is docked first at the right, Cancel left of it, the
  version label at the left; the same as before without the button.

## 16. Round 10: every kiosk setting that did not work is fixed or removed

The audit (report section 0.5) traced each setting of the kiosk Options dialog to its effect. On the
user's instruction, everything it found broken or misleading was fixed. Kiosk only; the server is
unchanged.

### 16.1 Changed

- General tab (`ClientOptionsForm`, `ClientOptions`, `KioskForm`, `Program`):
  - "Admin Username / Admin Password / Re-type Password" now set the offline admin login
    (`ClientOptions.SetSuperAdmin`: username, SHA-256 hash of the password, bidi marks stripped as in
    `VerifySuperAdmin`). Empty password boxes keep the current password; an empty username or a
    password shorter than 4 characters is refused. The fields `AdminUsername` / `AdminPassword` and
    the login-box pre-fill in `CenterLoginControls` are removed, so no password is shown on the login
    screen any more. Their old keys in `client_options.json` are ignored by Load and dropped by the
    next Save.
  - "Server IP / Host" now shows and edits `ConnectionSettings.ServerHost` and saves
    `server_settings.txt` (the address the engine really uses). `Uri.CheckHostName` rejects an
    invalid entry. After OK, `KioskForm.ApplyServerAddress` disposes the engine and runs
    `SetupEngine` again with the new address, unless a customer session is running; then the address
    applies from the next start. `ClientOptions.ServerHost` is removed, together with the constructor
    code that copied its "127.0.0.1" default into `ConnectionSettings.ServerHost`.
  - "Auto (Server Discovery)" now decides whether `Program.cs` searches the LAN
    (`ConnectionSettingsForm.FindServerOnLan`) when the saved server does not answer at start-up.
    `ApplyAutoDiscovery` (a UDP broadcast no server answered, 2 s delay at every start) is removed.
  - Two grey hint lines explain the admin fields and Auto.
  - Side effect: the kiosk's ping test (`ClientExtras` 290) now pings the real server. It reads
    `ConnectionSettings.ServerHost`, which the constructor no longer overwrites with "127.0.0.1".
- Options tab: new "Game Folders" field (`ClientOptions.GameFolders`, ';'-separated; default
  `C:\Games;D:\Games;C:\Program Files (x86)\Steam\steamapps\common;C:\Program Files\Epic Games;C:\Riot Games`).
  `GameKiller.KillAllGames` (Terminate on Logout and the end of time) uses it; each folder must match
  with a trailing backslash, and a bare drive root is skipped.
- Disable Alt+Enter: blocked in the system-wide keyboard hook (`SecurityLock.HookCallback`, VK_RETURN
  with Alt), so it works inside games. The kiosk window's old KeyDown handler is left; it is now
  redundant.
- USB Protection: `ApplyUsbProtection` returns whether it could write the registry. When the setting
  was changed in the dialog, the kiosk shows "set, restart Windows" or "not applied: the kiosk has no
  administrator rights". It still needs administrator rights.
- Events tab:
  - On Last Minutes: the warning now has its own crossing check (`_prevRemForTimeEnd`, reset at login).
    It fires once when the remaining minutes fall to the set value, once at the start when a session
    begins below it, and again after a top-up lifts the time above it. Simulated for 1 to 15 minutes.
    Before it depended on the sound tracker, which only moves at 10, 5 and 2 minutes.
  - On Logout message/sound: when one is set, the kiosk waits 3 s before closing (`_closePending`
    blocks a second logout meanwhile). Before it closed at once and cut both off.
  - Play Sound: files other than .wav (for example .mp3) play through the Windows MCI player
    (`winmm.dll` `mciSendString`, alias `gamenet_sound`). .wav still uses SoundPlayer.
- Advanced tab: the "Server UDP Port" and "Client UDP Port" fields and their warning are removed
  (`ClientOptions.ServerUdpPort` / `ClientUdpPort` too). A hint says the station password must match
  the server's "رمز سرور/کلاینت" and is not checked while that is empty.
- Language tab removed: there are no translations, so it only changed number and date formats.
  `ClientOptions.Language` stays (default Persian formats).
- Customer page: F10 does nothing while the exit button is hidden. The second-monitor timer
  (`SecondaryTimerForm`) hides used time, cost and balance with their Hide settings, and stops colouring
  by remaining time when that is hidden.

### 16.2 Unchanged (open)

- Every normal close of the kiosk still removes its autostart (13.3, P11).
- The customer's exit button still closes the kiosk program (13.3, P12).
- `client_options.json`, including the admin password hash, is still writable by the Windows user the
  kiosk runs as (13.3, P13). The password can now at least be changed from the dialog.
- USB Protection still needs administrator rights; the kiosk runs with limited rights.
- The balance row shows the balance at login (by design since round 6).
- The Network tab still cannot clear a chosen adapter.

### 16.3 Static verification

- Bracket balance OK for all eight changed files.
- Removed names (`ClientOptions.AdminUsername`, `AdminPassword`, `ServerHost`, `ServerUdpPort`,
  `ClientUdpPort`, `ApplyAutoDiscovery`, the Language and UDP controls) have no remaining reference in
  code; every new name is declared once and used.
- The edits were applied by one script that stops before writing unless every anchor occurs once.
- C# 7.3 only. Not compiled; no Windows run.

### 16.4 How to test on Windows

1. General: type a new admin password twice, OK. Lock, then log in with admin and the new password;
   the old one must fail. Leave the boxes empty and OK: the password stays.
2. General: enter the server's real IP, OK, outside a session. The status line shows the new
   connection within seconds; restart the kiosk: it connects to the same address.
3. Options: tick Disable Alt+Enter, start a game, press Alt+Enter: nothing happens.
4. Events: On Last Minutes = 8, log in a customer with 12 minutes: one warning at 8 minutes, not
   repeated.
5. Events: a logout message and an .mp3 sound; press ⏻ خروج: the message shows and the sound plays
   for 3 s before the program closes.
6. Options: Game Folders with your game folder; Terminate on Logout on; start a game, log out: the
   game closes.
7. USB Protection: change it; a message says whether it was applied.

## 17. Round 11: 3D icons, sound cues, customer requests, quick reservation, live control

Request: a 3D gaming icon that really shows, sounds for the station starting, 5 minutes left, time
over, a customer message and a customer asking for more time, a simple reservation item in the
right-click menu, high-quality monitoring with the operator's mouse and keyboard, and a check that
everything is in the project and works.

### 17.1 Changed

Icons
- `client.ico` / `server.ico` redrawn: ray-traced 3D gamepad (client: cyan pad on a violet tile;
  server: server rack + gold pad on a dark tile). 9 frames each: 16–64 px as 32-bit BMP (works in
  every Windows icon API), 128 and 256 px as PNG.
- New `GameNet.Shared/AppIcon.cs`. `Program.Main` of both apps installs the icon as the default for
  every window (title bar, taskbar, Alt+Tab); before, only the .exe file had it and every window
  showed the WinForms default icon. The server's tray icon used `this.Icon`, which is never null, so
  it also showed the default icon; it now uses the program icon. The .ico files are copied next to
  the exe.

Sounds (WAV files in `Sounds\`, copied by the build; replace a file with your own .wav of the same name)
- Kiosk: `startup.wav` when the kiosk window first shows (the PC was switched on), `warn10.wav`,
  `warn5.wav`, `warn1.wav`, `timeend.wav`. Events tab: "پخش صداهای داخلی" on/off and a test button
  for each sound. Asynchronous: the old `Console.Beep` calls blocked the UI thread for up to 1.5 s.
- Kiosk timer: the sounds moved into the threshold-crossing checks. The exact-minute check missed a
  threshold when the minute jumped, and two sounds at once cut each other off. With the default
  "On Last Minutes" = 5 the operator's warning and the built-in 5-minute banner both showed a toast
  at the same second; now only the operator's one shows. Simulated second by second for
  thresholds 0, 3, 5 and 10 and for a time jump: every warning fires once.
- Server: `client_online.wav` (station connected, at most once per station per 30 s),
  `customer_message.wav`, `time_request.wav`, `warn5.wav`, `time_end.wav` (once per station when
  its time runs out). `Console.Beep(800, 300)` on the UI thread replaced.
- Server 5-minute warning: the "last warned minute" was one value for all stations, so with two
  stations in their last 5 minutes only one was warned. Now per station.

Customer requests and messages
- The kiosk's +10/+30/+60, "end", "lock" and "shutdown" buttons send `[REQ] ...` through
  `ClientChatSend`. The server stored them as chat lines addressed to nobody: the operator never saw
  them. `HandleChatSend` now raises `OnCustomerRequest` (and no longer stores them as chat).
  Messages from a customer to the operator raise `OnCustomerMessage` (still stored as before).
- New `CustomerRequestPrompt`: a small always-on-top card per station that does not take the
  keyboard focus. Time request: "✅ اضافه کن +N" (SetSessionTime action 1) or "❌ رد" (the kiosk gets
  a polite message). End / shutdown likewise. Message: "↩️ پاسخ" sends the reply as ServerMessage.
  No protocol change: same message types and texts.

Reservation
- Right-click menu: new top-level "📅 رزرو" (the two old items at the bottom of the time submenu are
  gone). It lists "➕ رزرو جدید…", the next reservations of the PC (click one to cancel it) and
  "📋 همه رزروها…".
- New `QuickReservationDialog`: customer name, optional phone, today/tomorrow + time, a duration
  button (30 min … 3 h). `ReservationManager.CreateQuick` does not require an account or a row in
  the stations table (the old window refused walk-in customers and most connected PCs); the overlap
  check is the same. `GetUpcoming` lists active reservations that have not ended.
- The old window's text boxes were dark grey with dark text (unreadable); now white.
- Tests: `GameNet.Server.Tests/Round11Tests.cs` (create, overlap, past/empty, cancel).

Monitoring and control
- Finding: the server's rate limiter allows 30 messages per minute per station and then drops all of
  that station's messages for 15 minutes. The screenshot viewer asked for a frame every 400 ms
  (150 a minute): after about 12 seconds of watching the station was blocked, its heartbeats were
  dropped and it looked offline. The limiter itself is unchanged (needs approval, see 17.2).
- New `LiveControlForm` ("🖥️ مانیتورینگ زنده + کنترل" in the right-click menu and the side panel):
  the kiosk's ffmpeg sends H.264 (quality presets: 30 fps 8 Mbit/s, 25 fps 4 Mbit/s, 15 fps 75 %)
  on its own TCP connection; `ClientCommunicator.StartLiveView` runs ffmpeg on the server to decode
  it to JPEG frames on stdout; the window shows them (aspect kept, double-buffered). Frames do not use
  the control connection. Control on: mouse moves (coalesced, at most ~60/s), buttons, wheel and every
  key (also Tab, arrows, Alt combinations) go out as ServerRemoteInput; held keys and buttons are
  released when control goes off, the window loses focus or closes. Buttons for Win and Alt+Tab
  (those are taken by the server's own Windows otherwise). Full screen, snapshot, reconnect. Without
  FFmpeg the window falls back to one screenshot every 3 s and says why.
- The old screenshot viewer polls every 3 s instead of 400 ms (inside the limit) at JPEG quality 75.
- Kiosk capture: per-monitor DPI awareness for the capture thread, so 125 %/150 % scaling no longer
  crops the screenshot; the reported width/height are the picture's real size (the mouse mapping
  uses them); the mouse pointer is drawn into the picture.
- Kiosk input: keys carry the hardware scan code and the extended flag (games reading scan codes
  ignored the keys; arrows/Insert/Delete arrived as keypad keys).
- Kiosk stream: fps/bitrate/scale clamped, scaled size kept even (x264 refused odd sizes, e.g. 1366
  at 75 %), keyframe every 2 s, no B-frames, bitrate cap with buffer. The stream's server address is
  the server card this station already uses (first card was wrong on multi-card servers).
- Kiosk: a toast "اپراتور در حال استفاده از موس و کیبورد این سیستم است" when remote control starts
  (once per minute of use).
- Video+audio dialog defaults: 30 fps, 6000 kbit/s (max 60 fps, 20000).

### 17.2 Unchanged (open, needs your decision)

- Rate limit (P18): 30 messages/minute and a 15-minute block per station. Normal traffic is far
  below it, but any burst (screenshots, a script, many quick requests) blocks the whole station.
  Not changed: constraint "no rate-limit change without approval".
- Remote input still has no consent step on the kiosk (H5); the customer now sees a notice.
- The video stream is plain TCP on the LAN (not TLS), as before.
- Multi-monitor kiosks: the video shows all screens, the mouse maps to the primary one.
- FFmpeg must be installed on the server and on each kiosk (on PATH); Windows Firewall on the server
  must allow ffmpeg.exe (it asks the first time).

### 17.3 Static verification

- Bracket/string balance OK for every .cs file of the solution, including the 20 changed or new ones.
- Every name used by the new code was looked up (Log, Mi, ActOnSelected, ToastNotification.Show,
  SafeInvoke overloads, Database.Query/QueryOne/Execute overloads, SendRemoteInput, RequestScreenshot).
- csproj files are valid XML. ICO files: all 9 frames decode. WAV files: 44.1 kHz 16-bit mono.
- JPEG frame splitter: re-implemented in Python, 20 frames split byte-identical under 30 random
  chunkings (1 byte to 64 KB).
- Kiosk warning logic: simulated second by second (see above).
- C# 7.3 only. Not compiled; no Windows run.

### 17.4 How to test on Windows

1. Build; the title bars, taskbar and tray show the new icons. The output folder has `Sounds\`.
2. Kiosk Options > Events: press each "▶" test button.
3. Start a kiosk: start-up sound. Customer with 12 minutes: sounds at 10, 5, 1 and 0; one toast each.
4. Kiosk "+30": the server plays a sound and shows the card; "✅ اضافه کن +30" adds the time.
5. Kiosk "💬 پیام": sound + card on the server; "↩️ پاسخ" reaches the kiosk.
6. Right-click a PC > 📅 رزرو > رزرو جدید; it appears in the same menu; click it to cancel.
7. Install FFmpeg on server and kiosk. Right-click > 🖥️ مانیتورینگ زنده + کنترل: picture within a
   few seconds, ~30 fps. Turn on control; click, type, use arrows inside a game.
8. Watch a PC with the old screenshot viewer for 2 minutes: the PC stays online.

### 17.5 Splash screens removed (user request)

- `SplashForm` (client and server) showed `splash.png` and then waited a fixed 2 s
  (`Thread.Sleep(2000)`) before anything was loaded: every start of the kiosk and the server was 2 s
  slower. Removed with `splash.png`, its csproj entry and the call in `Program.Main`.
- The client's second splash (`SplashScreen` in `ClientExtras.cs`, a 1.7 s progress bar before the
  server-address dialog) removed; the dialog opens at once.
- `KioskForm._splashEnabled` (set in four places, never read) and the server's "🖥️ صفحه شروع"
  feature switch (it controlled nothing) removed. An old `feat_splash_screen` row in the database is
  ignored.

## 18. Round 12: the programs repair themselves

### 18.1 Changed

Guard (new `GameNet.Shared/SelfHeal/Guardian.cs`)
- Each program starts a copy of its own exe as `--guard <pid>` (no window, mutex
  `Global\GameNet-<Client|Server>-Guard`). It waits for the program and:
  - exit not marked as intentional (crash, killed, customer's exit button) → starts it again after 2 s (HEAL-001);
  - main window not answering for 45 s (kiosk) / 120 s (server) → ends it and starts it again (HEAL-002);
  - 3 restarts within 5 min → puts the last-good settings files back first (HEAL-003);
    6 within 10 min → 60 s between attempts;
  - Windows shutting down / logging off → lets it go.
- Intentional exits: kiosk — admin column exit (also sets maintenance, so the scheduled task
  leaves it closed until it is started again), self-update, Windows session end, a refused
  second copy; server — operator closing it, login cancelled/failed, database not opened,
  start-up failure, a refused second copy.
- The program checks every 30 s that its guard exists and starts a new one if not.
- What the guard did is written to `%ProgramData%\GameNet\<Key>\guard_event.txt`; the program
  records it in the fault journal at the next start. The kiosk also sends it to the server
  through the existing crash-report message; the server now shows crash and restart reports
  to the operator (toast and sound). They were stored before but nobody saw them.
- Guard log: `%ProgramData%\GameNet\<Key>\guard_log.txt`.

Crash handling (kiosk)
- An error on the UI thread no longer unlocks the PC. Before, the first such error restored Task
  Manager and the taskbar while the kiosk kept running, and showed a message box. Now it is
  recorded; three within a minute end the kiosk and the guard opens it again.
- The fatal-error message boxes (kiosk and server) were removed. The dying process stayed open
  until someone clicked them, so nothing could restart it. The reason is shown at the next start.

P11 (automatic start removed on every exit)
- `AutoStartup.Uninstall()` no longer runs on exit; `GameNet.Client.exe --uninstall` removes the
  automatic start. The scheduled task and the watchdog batch skip their start while the
  maintenance flag exists. Together with the guard this also covers P12: the customer's exit
  button no longer leaves the PC unlocked; the kiosk comes back in about 2 s.

Last-good settings (new `GameNet.Shared/SelfHeal/LastGoodConfig.cs`)
- `name.lastgood` is kept next to a settings file when it was last known to work: kiosk
  `server_settings.txt` when the server accepts the kiosk, kiosk `client_options.json` when it
  is read, server `options.json` at start when it parses.
- A damaged file gets that copy back (HEAL-004); the damaged file is kept as
  `*.damaged-<time>`. Server `options.json` used to fall back to defaults silently, and the next
  save overwrote the operator's settings with the defaults.

Database (new `GameNet.Server/Core/DatabaseSelfRepair.cs`)
- `PRAGMA quick_check` before the server opens `gamenet.db` (SQLite only).
- If it is damaged, the newest file in `Backups\` that passes the same check is offered with its
  date. On Yes: the damaged file and its -wal/-shm are renamed `*.damaged-<time>`, the backup is
  copied in (HEAL-005). No good backup → HEAL-006 and a clear message.
- Once a day after a healthy start: a consistent copy `Backups\gamenet_selfheal_yyyyMMdd.db`
  (SQLite online backup API, checked after writing; the three newest are kept).

Fault catalogue: HEAL-001 … HEAL-006 added; the catalogue test lists them.
Tests: `GameNet.Server.Tests/Round12Tests.cs` (last-good copy, database check, guard arguments).

### 18.2 Not automatic (by design)

- After a restart the server stops at the operator login, as before. Skipping the login would
  let anyone at the server PC kill the program to get in. Kiosks reconnect once someone logs in.
- A damaged database is replaced only after the operator says Yes, because changes made after
  the backup are lost.
- Code errors, hardware faults, router/firewall settings and Windows itself.

### 18.3 Static verification

- Bracket/string balance OK for every .cs file.
- The guard's decisions were simulated: single crash, admin exit, stale intent file of a refused
  copy, hang, and a crash loop (restore from the 3rd, 60 s wait from the 6th).
- SQLite's answers on a zeroed file ("file is not a database") and a damaged page ("database
  disk image is malformed") were confirmed with SQLite itself; both count as damaged.
- Not compiled; no Windows run.

### 18.4 How to test on Windows

1. Start a kiosk. In Task Manager (from the server's remote session or with the kiosk in
   maintenance) end `GameNet.Client.exe` (the one with a window): it is back within ~3 s; the
   server shows "بسته شده بود و خودکار دوباره باز شد".
2. Admin column → exit: the kiosk stays closed (also after a minute: scheduled task). Start it by
   hand: maintenance ends.
3. Customer exit button: the kiosk comes back.
4. Write `{garbage` into `options.json` of the server and start it: the settings are back;
   `options.json.damaged-*` exists.
5. Copy `gamenet.db` aside, overwrite the first 4 KB of `gamenet.db` with zeros, start the server:
   it offers the newest good backup.

## 19. Round 13: live view at 60 fps

- Live view preset "فوق‌العاده — ۶۰ فریم، کیفیت کامل" (60 fps, 16 Mbit/s, full size), now the
  default; 30 / 25 / 15 fps presets stay.
- Kiosk capture: Windows Desktop Duplication (`-f lavfi -i ddagrab=...`, FFmpeg 6.0+, Windows 8+)
  first. It reaches 60 fps at Full HD with little CPU and captures full-screen games (gdigrab
  managed ~30-40 fps and often showed full-screen games black). If ddagrab fails to start (older
  FFmpeg, no GPU driver, remote-desktop session), the old gdigrab command runs. Both attempts
  run on a worker thread; a stop during the attempts cancels them. Bit-rate cap raised to 25000.
  ddagrab captures one monitor (output 0), which matches the mouse mapping on the primary screen.
- Server decoder: two threads; JPEG quality step 5 at 50-60 fps (3 below).
- Viewer: one decoder thread always takes the newest frame and skips older ones, so the picture
  never lags behind on a slower server (fewer frames instead of growing delay). Frames are
  premultiplied ARGB, drawn 1:1 when they fit, bilinear scaling at 60 fps (high-quality at 30).
- Not compiled; ffmpeg command lines checked against the ffmpeg documentation syntax.
- Real 60 fps needs: FFmpeg 6.0 or newer on the kiosk; a kiosk CPU with room for encoding while a
  game runs (libx264 ultrafast at 1080p60 takes roughly one core); a server that decodes and
  re-encodes 60 frames a second. The status line of the window shows the real frame rate.

## 20. Round 14: PRO tabs work for the administrator; "🕵️ وقتی نبودم" activity journal

### 20.1 PRO tabs
- Cause 1: the default admin ("مدیر سیستم", role SuperAdmin) is created once with the rights that
  existed at that time; rights added later (ApiAccess, SmartPricing, ...) were never given to it,
  so several PRO modules were closed to the owner (see 5.5, P8).
  `OperatorManager.HasPermission` now gives every right to an active account with role SuperAdmin
  or with ManageOperators (it could grant itself everything anyway). Other operators keep their
  limits. The REST API token checks are unchanged.
- Cause 2: when a tab showed "🔒 no access" once, the label stayed on the page and covered the
  module even after a proper login, and every visit added another label and another message box.
  `EnsureTabContent` now clears such a tab before retrying, shows the reason inside the tab
  (which right is missing) and no longer pops a message box. The same applies to the
  "load error" and "not implemented" placeholders.
- The operator login button stays (see the reply to the user: without login every action in the
  journal would be anonymous and anyone at the counter could change money and settings).

### 20.2 Activity journal
- New `GameNet.Server/Core/ActivityJournal.cs` (table `activity_journal`, created on first use,
  kept 180 days; the technical audit_log is unchanged) and tab "🕵️ وقتی نبودم" (group گزارش,
  `ActivityJournalForm`): ranges since my last exit / today / yesterday / 7 / 30 days / custom,
  kind filter, search, a count per kind, CSV export (UTF-8 BOM, opens in Excel), Persian dates.
- Recorded: operator login, change and server close (with the operator), server start (also
  after an automatic restart) and guard repairs, every tab opened (same tab again after 2 min),
  the confirm bar and every module button that saves/applies/adds/deletes/edits/resets,
  the Options dialog save; stations connected/disconnected, sessions started/ended (customer,
  minutes, cost); time and credit changes, top-ups; commands (shutdown, restart, unlock, forced
  logout, USB, internet, sound, close game, Wake on LAN); customer requests, messages, rejections
  and replies; live view, video stream, remote desktop, "control on"; reservations and
  cancellations; kiosk crashes and self-repairs.
- Kiosk-side events (admin mode entered/left on the kiosk, full exit by the admin, kiosk settings
  changed — "Name: old ← new", passwords and hashes only as "changed") travel on the existing
  ClientCrashReport message with ExceptionType "Event:<kind>"; the server routes them to the
  journal, not to the crash table. They are saved on the kiosk first, so an offline kiosk delivers
  them when it reconnects. Report files now have unique names (two in the same second used to
  overwrite each other) and are sent oldest first, one flush at a time.
- At login the operator gets "از آخرین خروج شما N رخداد ثبت شده".
- Tests: `GameNet.Server.Tests/Round14Tests.cs`. The journal SQL was also run against SQLite.
- Not compiled; no Windows run.

## 21. Round 15: "clients not shown" — four more causes, and a connection doctor on both sides

### 21.1 Found and fixed
- S57 (critical) — kiosk "🚫 نت قطع": `netsh advfirewall firewall add rule ... dir=out action=block`
  with no address blocks every outgoing connection, the GameNet server included, and survives a
  reboot. When the kiosk runs with administrator rights, one click made the station disappear for
  good (it could not even receive "نت روشن"). Now `FirewallHelper.SetKioskInternet` blocks only
  public IPv4 ranges (private/LAN, loopback, link-local, CGNAT, multicast and the server's own
  address stay open) and IPv6 2000::/3. At kiosk start an existing GameNet_BlockInternet rule is
  replaced by the internet-only one (HEAL-007); without admin rights NET-012 explains the manual
  fix.
- S58 (critical, environment) — no Windows Firewall rule for the server. A cancelled Windows
  "allow access" prompt leaves a BLOCK rule; "Private" only on a "Public" network blocks too.
  `ServerFirewall.CheckAtStartup` checks (netsh, no admin needed) and, if needed, fixes silently
  when elevated or asks once (Yes / not now / never): deletes all rules for the server exe, adds
  allow rules for the exe and the TCP port (and ffmpeg.exe for the live view), profile=any, with
  one Windows administrator prompt. NET-013.
- S59 (high) — the kiosk sent all saved reports at once on every connect (up to 20 crash files +
  events); with the server's 30-messages/minute limit that blocked the station for 15 minutes.
  Now at most 5 on connect, 3 after a kiosk event, 2 per heartbeat.

### 21.2 Found, needs your approval (not changed)
- P1 / S1 / S3 — the certificate is `server.pfx` relative to the working folder. Started by
  Windows autostart (Run key: working folder System32) or a shortcut with another "Start in", the
  server does not find its certificate: it creates a new one (every kiosk then refuses the changed
  key) or cannot (TLS on → every connection refused). Proposed: set the working folder to the exe
  folder at the top of `Program.Main`. The doctor tab shows this case.
- P18 — the 30/minute limit and the 15-minute block.

### 21.3 Connection doctor
- Kiosk admin column "🩺 تست اتصال به سرور" (`ConnectionDoctor`): address and DNS, same subnet,
  the internet-off rule, TCP connect with the meaning of timeout / refused / unreachable, a TLS
  probe on a second connection (TLS on/off mismatch both ways, missing server certificate), the
  server key against `server_pin.txt` (changed key = server reinstalled or started from another
  folder), and the kiosk's last NET/TLS/AUTH/CFG records. Read-only; the copy button gives the text
  for support.
- Server tab "🩺 عیب‌یابی اتصال" (`ConnectionDoctorForm`, group سیستم): port, this server's IP
  addresses, TLS state, where the certificate is read from vs the exe folder, firewall state with a
  fix button, stations welcomed / still connecting, stations ignored by the message limit, the
  station-password state, and the refused connections and network faults of the last 6 hours with
  cause and action.
- New read-only accessors on ClientCommunicator: Port, CertificateLoaded, CertificateFullPath,
  WelcomedCount, RateLimitedNow(). `NetworkClient.ComputePublicKeySha256` is internal now.
- Tests: `Round15Tests.cs` (block ranges). Not compiled; no Windows run.

## 22. Round 16: full trace of "kiosk → visible on the server", four more fixes

Trace (current code): kiosk start → settings → firewall rule → engine connect (TCP, TLS, pin) →
hello / reconnect → server accept → TLS → read loop → rate limit → HandleHello (ACL, integrity
hash, station password, numbering) → ServerWelcome → OnClientConnected → monitor grid
(GetAllRawConnections, also "در حال اتصال..." rows) → heartbeat 30 s / timeout 90 s.

Fixed in this round:
- S60 (high) — kiosk start: a saved server that did not answer within 2 s opened the modal
  "server address" window. After a power cut kiosks boot before the server and every kiosk waited
  at that window; none connected until someone clicked it. Now only a first install (no settings
  file) asks; otherwise the kiosk starts and retries in the background (LAN search still runs
  when Auto is on).
- S61 (high) — server: every station's read loop ran on a thread-pool thread for the station's
  whole life; with 20-30 stations the pool was mostly blocked and timers and new connections
  waited for it to grow (~2 threads/s). Now one dedicated background thread per station.
- S62 (medium) — no timeout on the TLS handshake on either side: a peer that connected and
  stalled held a server thread, and a kiosk whose server never answered waited forever without
  retrying. 15 s for the handshake on both sides; after it, reads wait as before; server sends
  time out after 30 s (a stuck send used to hold the station's send lock forever).
- S63 (low) — a connection that never sent a hello raised OnClientDisconnected with its session
  GUID as the station name (dashboard, Telegram, journal). Now only welcomed stations raise it.
- Kiosk connection test: one connection only (TLS probe when the kiosk uses TLS, a plain heartbeat
  otherwise), so the test no longer adds a false "TLS handshake failed" line on the server; a
  slow / rate-limited server is told apart from a TLS mismatch.

Still open: P1 (certificate path follows the working folder) and P18 (rate limit) — approval.
Not compiled; no Windows run.
