# GameNet — سیستم مدیریت گیم‌نت

سیستم کامل مدیریت گیم‌نت شامل سرور + کلاینت (کیوسک) با C# .NET Framework 4.7.2 WinForms.

## ساختار پروژه

```
GameNet.sln
├── GameNet.Shared/          — لایه مشترک (Protocol, DTOs, نوع‌های پیام)
│   ├── Protocol.cs          — تعریف MessageType + Payload DTOs
│   └── GameNet.Shared.csproj
│
├── GameNet.Server/          — نرم‌افزار سرور (اپراتور)
│   ├── Program.cs           — نقطه ورود، exception handlers، QuickSetup
│   ├── Core/                — 50+ کلاس هسته
│   │   ├── Database.cs      — SQLite با 44+ جدول + migrations v1-v19
│   │   ├── ClientCommunicator.cs — TCP handler، billing، reconnect، HandleHello
│   │   ├── ThemeManager.cs  — تم تاریک/روشن با recursive control walk
│   │   ├── IconPainter.cs   — 52+ آیکن vector GDI+ (4x supersampling)
│   │   ├── ToastNotification.cs — اعلان‌های غیرمودال
│   │   ├── RestApiServer.cs — 12 endpoint با token auth
│   │   ├── TlsWrapper.cs    — TLS با self-signed cert
│   │   ├── VipManager.cs    — 4 سطح VIP (Bronze/Silver/Gold/Platinum)
│   │   ├── TournamentManager.cs — مسابقات
│   │   ├── UpdateDistributor.cs — توزیع آپدیت کلاینت از طریق شبکه
│   │   ├── WebSocketServer.cs — آپدیت‌های زنده
│   │   └── ... (44 کلاس دیگر)
│   └── Forms/               — 48 فرم (MainForm، OptionsForm، RestrictionsForm و ...)
│
├── GameNet.Client/          — نرم‌افزار کلاینت (کیوسک فول‌اسکرین)
│   ├── Program.cs           — نقطه ورود، single-instance mutex، global exception handlers
│   ├── KioskForm.cs         — فرم اصلی کیوسک (فول‌اسکرین + TopMost)
│   ├── KioskForm.Designer.cs — طراحی UI (login + session + sidebar)
│   ├── ClientEngine.cs      — موتور ارتباطی کلاینت (connect/reconnect/billing)
│   ├── NetworkClient.cs     — TCP/TLS + length-prefixed framing + keepalive
│   ├── SecurityLock.cs      — keyboard hook + TaskMgr disable + RestoreAll
│   ├── Watchdog.cs          — مانیتور 3 ثانیه‌ای + CheckHookHealth
│   ├── AutoStartup.cs       — Run key + scheduled task + watchdog batch
│   ├── ClientIntegrity.cs   — self-hash + anti-debug
│   ├── ClientLicenseFingerprint.cs — اثر انگشت ماشین (SHA256)
│   ├── ConnectionSettings.cs — تنظیمات IP با DPAPI encryption
│   ├── CrashReporter.cs     — گزارش crash محلی + flush به سرور
│   └── ... (19 کلاس دیگر)
│
└── GameNet.Server.Tests/    — تست‌های واحد
    └── AllTests.cs
```

## پیش‌نیازها

- **Visual Studio 2019/2022** (یا .NET Framework 4.7.2 SDK + msbuild)
- **.NET Framework 4.7.2** Developer Pack
- ویندوز 7 SP1 یا بالاتر (سرور + کلاینت)
- SQLite (به صورت خودکار با System.Data.SQLite NuGet نصب می‌شود)

## نحوه Build

1. پوشه را از حالت فشرده خارج کنید.
2. `GameNet.sln` را در Visual Studio باز کنید.
3. NuGet packages را restore کنید (Tools → NuGet Package Manager → Restore).
4. Configuration را روی `Release` و Platform را روی `Any CPU` (یا `x64`) بگذارید.
5. Build Solution (Ctrl+Shift+B).
6. خروجی‌ها:
   - سرور: `GameNet.Server/bin/Release/net472/GameNet.Server.exe`
   - کلاینت: `GameNet.Client/bin/Release/net472/GameNet.Client.exe`
   - Shared: `GameNet.Shared/bin/Release/net472/GameNet.Shared.dll` (هر دو به آن نیاز دارند)

> **ترتیب Build مهم است:** Shared → Server → Client (Visual Studio به‌طور خودکار با dependency ها این ترتیب را رعایت می‌کند).

## اجرا

### سرور
- `GameNet.Server.exe` را اجرا کنید.
- اولین بار: QuickSetup wizard → تنظیم IP/پورت + ساخت اپراتور پیش‌فرض (admin/password).
- بعد از لاگین، داشبورد اصلی با تمام قابلیت‌ها نمایش داده می‌شود.

### کلاینت
- `GameNet.Client.exe` را روی سیستم مشتری اجرا کنید.
- اولین بار: دیالوگ «تنظیمات اتصال» → IP سرور + پورت (پیش‌فرض 9090).
- کلاینت فول‌اسکرین + TopMost می‌شود.
- صفحه لاگین: نام کاربری + رمز عبور (admin/password پیش‌فرض).
- بعد از لاگین: نمایش تایمر، اعتبار، منوی بازی‌ها.

## حساب پیش‌فرض
- **نام کاربری:** `admin`
- **رمز عبور:** `password`

## قابلیت‌های کلیدی

### سرور
- 48 فرم + 50+ کلاس Core
- داشبورد زنده با چارت‌ها
- مانیتورینگ کلاینت (19 ستون + context menu 30 آیتم)
- 26 پنل تنظیمات (OptionsForm)
- RestrictionsForm با 132+ checkbox (4 تب)
- تم تاریک/روشن
- REST API (12 endpoint، token auth)
- WebSocket برای آپدیت‌های زنده
- TLS با self-signed cert
- 2FA، VIP، مسابقات، Telegram bot
-multi-branch support
- 25+ بهبود کلاینت (ADD-CLIENT-25)
- Auto-backup، crash logger، sound notifications
- DataCache (in-memory caching)

### کلاینت
- فول‌اسکرین + TopMost (کیوسک)
- keyboard hook (Win/Alt+Tab/Ctrl+Esc/Ctrl+Shift+Esc)
- DisableTaskManager
- Auto-startup (Run key + scheduled task + watchdog batch)
- Anti-debug (self-hash + debugger detection)
- License fingerprint (SHA256(machineName|mac|windowsSerial))
- Crash reporter (محلی + flush به سرور)
- Reconnect با exponential backoff + OnReconnectGaveUp
- DPAPI-encrypted connection settings
- LowPerformanceMode (حالت کم‌مصرف)
- Secondary timer (مانیتور دوم)
- Ambient music + news ticker
- Toast banners (5min/1min/0min)

## امنیت
- PBKDF2 password hashing
- HMAC-SHA256 license tokens
- AES-256-CBC data encryption
- TLS 1.2 (optional)
- DPAPI برای تنظیمات کلاینت
- Path traversal protection (file transfer)
- Self-hash integrity check (client)
- Anti-debug watchdog
- Rate limiter + IDS

## حلقه‌های خرابی (Recovery)
- `recovery.bat` — بازگردانی Task Manager + taskbar + desktop icons + Run dialog بعد از خرابی کلاینت
- `SecurityLock.RestoreAll()` — cleanup کامل در خروج (شامل crash recovery)
- `AutoStartup.Uninstall()` — حذف scheduled task + Run key + batch

## تکنولوژی‌ها
- C# .NET Framework 4.7.2
- WinForms
- SQLite (System.Data.SQLite)
- Newtonsoft.Json
- TCP/IP + TLS (SslStream)
- HttpListener (REST API)
- WebSocket (socket.io-like)
- GDI+ (IconPainter)
- P/Invoke (SetWindowsHookEx, Process.Start, Registry)

## نسخه
تمام 46 مشکل شناسایی‌شده در ممیزی کامل اصلاح شده است:
- ✅ 9 CRITICAL (C1-C9)
- ✅ 10 HIGH (H1-H10)
- ✅ 12 MEDIUM (M1-M12)
- ✅ 15 LOW (L1-L15)
